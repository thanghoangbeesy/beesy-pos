import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { DbError, getAllowedWarehouses, getDailyBreakdown, getDailyExpenses, getHourlyBreakdown, getRangeReport } from '../lib/db';
import {
  addDaysVN,
  endOfMonthVN,
  formatDMY,
  formatVND,
  startOfMonthVN,
  startOfWeekVN,
  todayVN,
} from '../lib/format';
import { useToast } from '../components/Toast';
import { LowStockPanel, useStockOverview } from '../components/StockOverview';
import { DayCloseSheet } from './DayCloseSheet';
import { useAuth } from '../lib/auth';
import { TIcon } from '../components/TIcon';
import type { DailyReport, Warehouse } from '../lib/types';

type PresetKey = 'today' | 'yesterday' | 'thisWeek' | 'lastWeek' | 'thisMonth' | 'lastMonth';

const PRESETS: { key: PresetKey; label: string }[] = [
  { key: 'today', label: 'Hôm nay' },
  { key: 'yesterday', label: 'Hôm qua' },
  { key: 'thisWeek', label: 'Tuần này' },
  { key: 'lastWeek', label: 'Tuần trước' },
  { key: 'thisMonth', label: 'Tháng này' },
  { key: 'lastMonth', label: 'Tháng trước' },
];

function presetRange(key: PresetKey): [string, string] {
  const t = todayVN();
  switch (key) {
    case 'today': return [t, t];
    case 'yesterday': { const y = addDaysVN(t, -1); return [y, y]; }
    case 'thisWeek': return [startOfWeekVN(t), t];
    case 'lastWeek': {
      const mondayThis = startOfWeekVN(t);
      const mondayLast = addDaysVN(mondayThis, -7);
      return [mondayLast, addDaysVN(mondayLast, 6)];
    }
    case 'thisMonth': return [startOfMonthVN(t), t];
    case 'lastMonth': {
      const firstThisMonth = startOfMonthVN(t);
      const lastDayPrev = addDaysVN(firstThisMonth, -1);
      return [startOfMonthVN(lastDayPrev), lastDayPrev];
    }
  }
}

function prevRange(key: PresetKey): [string, string] {
  const t = todayVN();
  switch (key) {
    case 'today': { const y = addDaysVN(t, -1); return [y, y]; }
    case 'yesterday': { const y = addDaysVN(t, -2); return [y, y]; }
    case 'thisWeek': {
      const mondayThis = startOfWeekVN(t);
      const mondayLast = addDaysVN(mondayThis, -7);
      return [mondayLast, addDaysVN(mondayLast, 6)];
    }
    case 'lastWeek': {
      const mondayThis = startOfWeekVN(t);
      const mondayLast2 = addDaysVN(mondayThis, -14);
      return [mondayLast2, addDaysVN(mondayLast2, 6)];
    }
    case 'thisMonth': {
      const firstThisMonth = startOfMonthVN(t);
      const lastDayPrev = addDaysVN(firstThisMonth, -1);
      return [startOfMonthVN(lastDayPrev), lastDayPrev];
    }
    case 'lastMonth': {
      const firstThisMonth = startOfMonthVN(t);
      const lastDayPrev = addDaysVN(firstThisMonth, -1);
      const firstPrev = startOfMonthVN(lastDayPrev);
      const lastDayPrev2 = addDaysVN(firstPrev, -1);
      return [startOfMonthVN(lastDayPrev2), lastDayPrev2];
    }
  }
}

/** Nhãn kỳ này / kỳ trước cho tiêu đề biểu đồ so sánh (kỳ trước viết thường
 *  để ghép câu "Kỳ này so với kỳ trước", ví dụ "Hôm nay so với hôm qua"). */
function chartLabels(key: PresetKey): { cur: string; prev: string } {
  switch (key) {
    case 'today': return { cur: 'Hôm nay', prev: 'hôm qua' };
    case 'yesterday': return { cur: 'Hôm qua', prev: 'hôm kia' };
    case 'thisWeek': return { cur: 'Tuần này', prev: 'tuần trước' };
    case 'lastWeek': return { cur: 'Tuần trước', prev: 'tuần trước nữa' };
    case 'thisMonth': return { cur: 'Tháng này', prev: 'tháng trước' };
    case 'lastMonth': return { cur: 'Tháng trước', prev: 'tháng trước nữa' };
  }
}

function cap(s: string): string {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

type LineKey = 'revCur' | 'revPrev' | 'profCur' | 'profPrev' | 'expCur' | 'expPrev';

/** 6 duong bieu do: mau theo loai, net theo ky (ky nay net lien dam,
 *  ky truoc net dut nhat cung mau). */
const LINES: { key: LineKey; label: string; color: string; dash: boolean; period: 'cur' | 'prev' }[] = [
  { key: 'revCur', label: 'Doanh thu', color: '#00B14F', dash: false, period: 'cur' },
  { key: 'revPrev', label: 'Doanh thu', color: '#86EFAC', dash: true, period: 'prev' },
  { key: 'profCur', label: 'Loi nhuan', color: '#2563EB', dash: false, period: 'cur' },
  { key: 'profPrev', label: 'Loi nhuan', color: '#93C5FD', dash: true, period: 'prev' },
  { key: 'expCur', label: 'Chi phi', color: '#DC2626', dash: false, period: 'cur' },
  { key: 'expPrev', label: 'Chi phi', color: '#FCA5A5', dash: true, period: 'prev' },
];

/** 1 điểm trên biểu đồ so sánh: nhãn trục + chi tiết tooltip + 2 cặp số.
 *  Chi phí = chi phí vận hành (tách riêng, không phải giá vốn). */
interface ChartPoint {
  key: string;
  label: string;
  detail: string;
  thisRevenue: number;
  thisProfit: number;
  thisExpense: number;
  lastRevenue: number;
  lastProfit: number;
  lastExpense: number;
}

type ChartMode = 'hour' | 'week' | 'month';

function pctChange(cur: number, prev: number): number | null {
  if (prev === 0) return cur > 0 ? 100 : null;
  return ((cur - prev) / prev) * 100;
}

export function ReportsPC() {
  const toast = useToast();
  const { can, user } = useAuth();
  const navigate = useNavigate();
  const [preset, setPreset] = useState<PresetKey>('today');
  const [report, setReport] = useState<DailyReport | null>(null);
  const [prevReport, setPrevReport] = useState<DailyReport | null>(null);
  const [chartData, setChartData] = useState<ChartPoint[]>([]);
  const [chartMeta, setChartMeta] = useState<{ mode: ChartMode; cur: string; prev: string }>({ mode: 'hour', cur: 'Hôm nay', prev: 'hôm qua' });
  const [hiddenLines, setHiddenLines] = useState<Set<LineKey>>(new Set());
  const [selectedIdx, setSelectedIdx] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [isOwner, setIsOwner] = useState(false);
  const [dayCloseOpen, setDayCloseOpen] = useState(false);
  const { low } = useStockOverview(warehouses);

  const load = useCallback(async (key: PresetKey, ids?: string[]) => {
    setBusy(true);
    try {
      const [s, e] = presetRange(key);
      const [ps, pe] = prevRange(key);
      const t = todayVN();
      const [cur, prev] = await Promise.all([
        getRangeReport(s, e, ids),
        getRangeReport(ps, pe, ids),
      ]);
      setReport(cur);
      setPrevReport(prev);
      // Biểu đồ so sánh chạy theo kỳ đã chọn (v6.4): kỳ 1 ngày -> theo giờ
      // (24 giờ, kỳ trước là ngày liền trước); kỳ nhiều ngày -> theo ngày
      // (tuần: T2-CN, kỳ trước là tuần liền trước; tháng: ngày 1-31, kỳ trước
      // là tháng liền trước, ngày không có trong tháng trước tính 0).
      const meta = chartLabels(key);
      if (key === 'today' || key === 'yesterday') {
        const [day] = presetRange(key);
        const [prevDay] = prevRange(key);
        const hours = await getHourlyBreakdown(day, prevDay, ids);
        setChartData(hours.map((h) => ({
          key: String(h.hour),
          label: String(h.hour),
          detail: `${h.hour}h`,
          thisRevenue: h.curRevenue,
          thisProfit: h.curProfit,
          thisExpense: h.curExpense,
          lastRevenue: h.prevRevenue,
          lastProfit: h.prevProfit,
          lastExpense: h.prevExpense,
        })));
        setChartMeta({ mode: 'hour', ...meta });
      } else if (key === 'thisWeek' || key === 'lastWeek') {
        const mondayThis = startOfWeekVN(t);
        const curMon = key === 'thisWeek' ? mondayThis : addDaysVN(mondayThis, -7);
        const prevMon = addDaysVN(curMon, -7);
        const dayLabels = ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'];
        const [curDays, prevDays, curExp, prevExp] = await Promise.all([
          getDailyBreakdown(curMon, addDaysVN(curMon, 6), ids),
          getDailyBreakdown(prevMon, addDaysVN(prevMon, 6), ids),
          getDailyExpenses(curMon, addDaysVN(curMon, 6), ids),
          getDailyExpenses(prevMon, addDaysVN(prevMon, 6), ids),
        ]);
        setChartData(dayLabels.map((dayLabel, i) => ({
          key: addDaysVN(curMon, i),
          label: dayLabel,
          detail: `${dayLabel} ${formatDMY(addDaysVN(curMon, i))}`,
          thisRevenue: curDays[i]?.revenue ?? 0,
          thisProfit: curDays[i]?.profit ?? 0,
          thisExpense: curExp[i]?.expense ?? 0,
          lastRevenue: prevDays[i]?.revenue ?? 0,
          lastProfit: prevDays[i]?.profit ?? 0,
          lastExpense: prevExp[i]?.expense ?? 0,
        })));
        setChartMeta({ mode: 'week', ...meta });
      } else {
        const firstThisMonth = startOfMonthVN(t);
        const curFirst = key === 'thisMonth' ? firstThisMonth : startOfMonthVN(addDaysVN(firstThisMonth, -1));
        const curLast = endOfMonthVN(curFirst);
        const prevFirst = startOfMonthVN(addDaysVN(curFirst, -1));
        const prevLast = addDaysVN(curFirst, -1);
        const [curDays, prevDays, curExp, prevExp] = await Promise.all([
          getDailyBreakdown(curFirst, curLast, ids),
          getDailyBreakdown(prevFirst, prevLast, ids),
          getDailyExpenses(curFirst, curLast, ids),
          getDailyExpenses(prevFirst, prevLast, ids),
        ]);
        setChartData(curDays.map((d, i) => ({
          key: d.date,
          label: String(i + 1),
          detail: formatDMY(d.date),
          thisRevenue: d.revenue,
          thisProfit: d.profit,
          thisExpense: curExp[i]?.expense ?? 0,
          lastRevenue: prevDays[i]?.revenue ?? 0,
          lastProfit: prevDays[i]?.profit ?? 0,
          lastExpense: prevExp[i]?.expense ?? 0,
        })));
        setChartMeta({ mode: 'month', ...meta });
      }
    } catch (err) {
      toast.show(err instanceof DbError ? err.message : 'Không tải được báo cáo');
    } finally {
      setBusy(false);
    }
  }, [toast]);

  useEffect(() => {
    getAllowedWarehouses()
      .then(({ warehouses: ws, isOwner: ow }) => {
        setWarehouses(ws);
        setIsOwner(ow);
        const ids = ow ? undefined : ws.map((w) => w.id);
        void load('today', ids);
      })
      .catch(() => { void load('today'); });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const pickPreset = (key: PresetKey) => {
    setPreset(key);
    setSelectedIdx(null);
    const ids = isOwner ? undefined : warehouses.map((w) => w.id);
    void load(key, ids);
  };

  const toggleLine = (key: LineKey) => {
    setHiddenLines((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  const kpis = useMemo(() => {
    if (!report) return [];
    const p = prevReport;
    return [
      { label: 'Doanh thu', value: formatVND(report.revenue), icon: '💰', bg: '#EFF4FF', change: p ? pctChange(report.revenue, p.revenue) : null },
      { label: 'Lợi nhuận', value: formatVND(report.profit), icon: '📈', bg: '#ECFDF5', change: p ? pctChange(report.profit, p.profit) : null },
      { label: 'Số đơn', value: String(report.order_count), icon: '🧾', bg: '#F5F0FF', change: p ? pctChange(report.order_count, p.order_count) : null },
      { label: 'TB/đơn', value: formatVND(Math.round(report.avg_order)), icon: '🧮', bg: '#FFFBEB', change: p ? pctChange(report.avg_order, p.avg_order) : null },
    ];
  }, [report, prevReport]);


  // Tong 3 loai cua ky nay / ky truoc tren toan bo cac moc dang hien thi.
  const chartTotals = {
    revCur: chartData.reduce((s, d) => s + d.thisRevenue, 0),
    revPrev: chartData.reduce((s, d) => s + d.lastRevenue, 0),
    profCur: chartData.reduce((s, d) => s + d.thisProfit, 0),
    profPrev: chartData.reduce((s, d) => s + d.lastProfit, 0),
    expCur: chartData.reduce((s, d) => s + d.thisExpense, 0),
    expPrev: chartData.reduce((s, d) => s + d.lastExpense, 0),
  };
  const maxPos = Math.max(1, ...chartData.flatMap((d) => [d.thisRevenue, d.lastRevenue, d.thisProfit, d.lastProfit]));
  const maxNeg = Math.max(1, ...chartData.flatMap((d) => [d.thisExpense, d.lastExpense]));

  // Hinh hoc bieu do duong (v6.4): THANG TUYEN TINH DUY NHAT tu -max(chi phi)
  // den +max(doanh thu/loi nhuan), truc 0 o giua, cung ti le px/dong ca 2
  // phia nen chieu cao khong danh lua mat. Chi phi ve voi gia tri am nen
  // luon nam duoi truc 0; doanh thu/loi nhuan luon tren truc 0.
  const svgW = 640;
  const svgH = 260;
  const svgPadT = 16;
  const svgPadB = 24;
  const svgPadX = 10;
  const svgPlotH = svgH - svgPadT - svgPadB;
  const svgStep = chartData.length > 1 ? (svgW - 2 * svgPadX) / (chartData.length - 1) : 0;
  const svgX = (i: number) => chartData.length > 1 ? svgPadX + i * svgStep : svgW / 2;
  const svgY = (v: number) => svgPadT + ((maxPos - v) / (maxPos + maxNeg)) * svgPlotH;
  const svgZeroY = svgY(0);
  const lineSeries = LINES.map((ln) => ({ ...ln, values: chartData.map((d) =>
    ln.key === 'revCur' ? d.thisRevenue : ln.key === 'revPrev' ? d.lastRevenue
    : ln.key === 'profCur' ? d.thisProfit : ln.key === 'profPrev' ? d.lastProfit
    : ln.key === 'expCur' ? -d.thisExpense : -d.lastExpense) }));
  const linePath = (vals: number[]) => vals.map((v, i) => `${i === 0 ? 'M' : 'L'}${svgX(i).toFixed(1)},${svgY(v).toFixed(1)}`).join(' ');
  const showXLabel = (d: ChartPoint, i: number): boolean => {
    if (chartMeta.mode === 'week') return true;
    if (chartMeta.mode === 'hour') return Number(d.label) % 3 === 0;
    const day = i + 1;
    return day === 1 || day % 5 === 0;
  };
  const xLabelText = (d: ChartPoint) => chartMeta.mode === 'hour' ? `${d.label}h` : d.label;
  const sel = selectedIdx !== null ? chartData[selectedIdx] : undefined;
  const topProducts = useMemo(() => (report?.top_products ?? []).slice(0, 8), [report]);

  // Khung "Top món theo doanh thu": xếp theo DOANH THU thật trên toàn bộ món,
  // tỉ lệ tính trên tổng doanh thu mọi món. (Trước đây lấy nhầm nhóm top theo
  // SỐ LƯỢNG nên món doanh thu cao nhưng bán ít không lọt vào khung này.)
  const catData = useMemo(() => {
    const all = report?.top_products ?? [];
    const total = all.reduce((s, p) => s + p.revenue, 0) || 1;
    return [...all]
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 5)
      .map((p, i) => ({
        name: p.name,
        value: p.revenue,
        pct: (p.revenue / total) * 100,
        color: ['#00B14F', '#00D15F', '#10B981', '#F59E0B', '#9CA3AF'][i % 5],
      }));
  }, [report]);

  if (!can('reports')) {
    return <div className="page"><div className="card">🔒 Chỉ Quản lý trở lên mới được xem báo cáo.</div></div>;
  }

  return (
    <div className="pc-ov">
      {/* Top bar PC */}
      <div className="pc-ov-topbar">
        <h1>Tổng quan</h1>
        <div className="pc-ov-topbar-right">
          <select value={preset} onChange={(e) => pickPreset(e.target.value as PresetKey)} className="pc-select" aria-label="Chọn kỳ">
            {PRESETS.map((p) => <option key={p.key} value={p.key}>{p.label}</option>)}
          </select>
          <button className="pc-btn-primary" onClick={() => setDayCloseOpen(true)}>
            <TIcon emoji="💰" size={16} /> Chốt két
          </button>
          <span className="pc-user">{user?.full_name || user?.email}</span>
        </div>
      </div>

      {/* 4 KPI cards */}
      <div className="pc-kpis">
        {kpis.map((k) => (
          <div className="pc-kpi" key={k.label}>
            <div className="pc-kpi-icon" style={{ background: k.bg }}><TIcon emoji={k.icon} size={24} /></div>
            <div className="pc-kpi-info">
              <div className="pc-kpi-label">{k.label}</div>
              <div className="pc-kpi-value">{busy && !report ? '…' : k.value}</div>
              {k.change !== null && k.change !== undefined && (
                <div className={`pc-kpi-change ${k.change >= 0 ? 'up' : 'down'}`}>
                  {k.change >= 0 ? '↑' : '↓'} {Math.abs(Math.round(k.change))}% so với kỳ trước
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Chart + Donut */}
      <div className="pc-ov-grid2">
        <div className="pc-card">
          <div className="pc-card-head">
            <h3>{chartMeta.cur} so với {chartMeta.prev}</h3>
          </div>
          <div style={{ padding: '0 20px', display: 'flex', flexDirection: 'column', gap: 8 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 2, fontSize: 13 }}>
              <div>Doanh thu: {chartMeta.cur}: <b>{formatVND(chartTotals.revCur)}</b> · {cap(chartMeta.prev)}: <b>{formatVND(chartTotals.revPrev)}</b></div>
              <div>Lợi nhuận: {chartMeta.cur}: <b>{formatVND(chartTotals.profCur)}</b> · {cap(chartMeta.prev)}: <b>{formatVND(chartTotals.profPrev)}</b></div>
              <div>Chi phí: {chartMeta.cur}: <b>{formatVND(chartTotals.expCur)}</b> · {cap(chartMeta.prev)}: <b>{formatVND(chartTotals.expPrev)}</b></div>
            </div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px 8px' }}>
              {LINES.map((ln) => {
                const hidden = hiddenLines.has(ln.key);
                return (
                  <button key={ln.key} onClick={() => toggleLine(ln.key)} style={{ display: 'flex', alignItems: 'center', gap: 5, background: 'none', border: '1px solid #E2E8F0', borderRadius: 999, padding: '4px 8px', fontSize: 12, cursor: 'pointer', opacity: hidden ? 0.45 : 1, textDecoration: hidden ? 'line-through' : 'none' }}>
                    <span style={{ width: 14, height: 0, borderTop: `3px ${ln.dash ? 'dashed' : 'solid'} ${ln.color}` }} />
                    {ln.label} {ln.period === 'cur' ? chartMeta.cur : cap(chartMeta.prev)}
                  </button>
                );
              })}
              {hiddenLines.size > 0 && (
                <button onClick={() => setHiddenLines(new Set())} style={{ background: 'none', border: 'none', color: '#00B14F', fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>Hiện tất cả</button>
              )}
            </div>
          </div>                    <div style={{ padding: '0 12px 4px' }}>
            <svg width="100%" viewBox={`0 0 ${svgW} ${svgH}`} role="img" aria-label="Biểu đồ so sánh theo kỳ">
              {chartData.map((d, idx) => showXLabel(d, idx) && (
                <line key={`g${d.key}`} x1={svgX(idx)} y1={svgPadT} x2={svgX(idx)} y2={svgH - svgPadB} stroke="#E2E8F0" strokeWidth={1} />
              ))}
              <line x1={svgPadX} y1={svgZeroY} x2={svgW - svgPadX} y2={svgZeroY} stroke="#64748B" strokeWidth={2} />
              <text x={svgPadX} y={svgPadT + 10} fontSize={10} fill="#94A3B8">{formatVND(maxPos)}</text>
              <text x={svgPadX} y={svgH - 4} fontSize={10} fill="#94A3B8">{`-${formatVND(maxNeg)}`}</text>
              {lineSeries.filter((s) => !hiddenLines.has(s.key)).map((s) => (
                <path key={s.key} d={linePath(s.values)} fill="none" stroke={s.color} strokeWidth={s.dash ? 2 : 2.5} strokeDasharray={s.dash ? '6 4' : undefined} strokeLinejoin="round" strokeLinecap="round" />
              ))}
              {chartData.map((d, idx) => (
                <rect key={`h${d.key}`} x={Math.max(svgPadX, svgX(idx) - svgStep / 2)} y={svgPadT} width={svgStep || svgW - 2 * svgPadX} height={svgPlotH} fill="transparent" pointerEvents="all" style={{ cursor: 'pointer' }} onClick={() => setSelectedIdx(idx)} />
              ))}
              {sel && selectedIdx !== null && (
                <line x1={svgX(selectedIdx)} y1={svgPadT} x2={svgX(selectedIdx)} y2={svgH - svgPadB} stroke="#64748B" strokeWidth={1} strokeDasharray="3 3" />
              )}
              {chartData.map((d, idx) => showXLabel(d, idx) && (
                <text key={`x${d.key}`} x={svgX(idx)} y={svgH - 6} fontSize={11} fill="#64748B" textAnchor="middle">{xLabelText(d)}</text>
              ))}
            </svg>
            {sel ? (
              <div style={{ fontSize: 13, display: 'flex', flexDirection: 'column', gap: 2, padding: '6px 8px', background: '#F8FAFC', borderRadius: 8 }}>
                <div><b>{sel.detail}</b></div>
                <div>Doanh thu: {chartMeta.cur} {formatVND(sel.thisRevenue)} · {cap(chartMeta.prev)} {formatVND(sel.lastRevenue)}</div>
                <div>Lợi nhuận: {chartMeta.cur} {formatVND(sel.thisProfit)} · {cap(chartMeta.prev)} {formatVND(sel.lastProfit)}</div>
                <div>Chi phí: {chartMeta.cur} {formatVND(sel.thisExpense)} · {cap(chartMeta.prev)} {formatVND(sel.lastExpense)}</div>
              </div>
            ) : (
              <div style={{ fontSize: 12, color: '#64748B', padding: '6px 8px' }}>Chạm vào biểu đồ để xem đủ 6 số tại 1 mốc.</div>
            )}
          </div>
        </div>
        <div className="pc-card">
          <div className="pc-card-head"><h3>Top món theo doanh thu</h3></div>
          <div className="pc-donut-wrap">
            <div className="pc-cat-list">
              {catData.map((c) => (
                <div className="pc-cat-row" key={c.name}>
                  <span className="pc-dot" style={{ background: c.color }} />
                  <span className="pc-cat-name">{c.name}</span>
                  <span className="pc-cat-val">{formatVND(c.value)}</span>
                  <span className="pc-cat-pct">{c.pct.toFixed(1)}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Bảng món bán chạy */}
      <div className="pc-card">
        <div className="pc-card-head">
          <h3>Món bán chạy</h3>
          <button className="pc-link" onClick={() => navigate('/pos')}>Bán hàng →</button>
        </div>
        <table className="pc-table">
          <thead>
            <tr>
              <th>#</th>
              <th>Món</th>
              <th className="r">Số lượng</th>
              <th className="r">Doanh thu</th>
              <th className="r">Giá vốn</th>
              <th className="r">Lợi nhuận gộp</th>
            </tr>
          </thead>
          <tbody>
            {topProducts.map((p, i) => (
              <tr key={p.product_id}>
                <td>{i + 1}</td>
                <td><b>{p.name}</b></td>
                <td className="r">{p.qty}</td>
                <td className="r">{formatVND(p.revenue)}</td>
                <td className="r">{formatVND(p.cost)}</td>
                <td className="r" style={{ color: '#16A34A', fontWeight: 600 }}>{formatVND(p.profit)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {topProducts.length === 0 && <p className="muted small" style={{ padding: 12 }}>Chưa có dữ liệu</p>}
      </div>

      {/* Cảnh báo tồn kho — chuyển xuống cuối trang (Hoàng yêu cầu v5.14) */}
      <LowStockPanel low={low} multiWarehouse={warehouses.length > 1} variant="pc" />

      {dayCloseOpen && <DayCloseSheet onClose={() => setDayCloseOpen(false)} />}
    </div>
  );
}
