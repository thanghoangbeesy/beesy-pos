import { useRef, useState } from 'react';
import { LineIcon } from './LineIcon';
import { BarcodeScanner } from './BarcodeScanner';

// O nhap ma vach dung chung cho ban hang va nhap/xuat kho:
// - Go tay ma vach roi Enter.
// - May quet USB: may go ma nhu ban phim roi tu Enter — chi can de con tro
//   o o nay la quet duoc, khong can cai dat gi them.
// - Nut camera: mo quet bang camera dien thoai/may tinh.
// Quet xong thi xoa o va giu focus de quet lien tiep mon tiep theo.
export function BarcodeScanBox({
  placeholder,
  onCode,
  autoFocus,
}: {
  placeholder?: string;
  onCode: (code: string) => void;
  autoFocus?: boolean;
}) {
  const [value, setValue] = useState('');
  const [showScanner, setShowScanner] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const submit = () => {
    const code = value.trim();
    if (!code) return;
    setValue('');
    onCode(code);
    inputRef.current?.focus();
  };

  return (
    <div className="barcode-box">
      <div className="sb-search grow">
        <span className="sico" aria-hidden>
          <LineIcon name="barcode" size={18} />
        </span>
        <input
          ref={inputRef}
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              e.preventDefault();
              submit();
            }
          }}
          placeholder={placeholder ?? 'Quét hoặc nhập mã vạch…'}
          aria-label="Mã vạch"
          autoFocus={autoFocus}
          autoComplete="off"
          autoCapitalize="off"
          autoCorrect="off"
          spellCheck={false}
        />
      </div>
      <button
        type="button"
        className="btn btn-outline"
        style={{ minHeight: 48, minWidth: 48, padding: '0 12px' }}
        onClick={() => setShowScanner(true)}
        aria-label="Quét mã vạch bằng camera"
        title="Quét mã vạch bằng camera"
      >
        <LineIcon name="camera" size={20} />
      </button>
      {showScanner && (
        <BarcodeScanner
          onScan={(code) => {
            setShowScanner(false);
            onCode(code);
          }}
          onClose={() => setShowScanner(false)}
        />
      )}
    </div>
  );
}
