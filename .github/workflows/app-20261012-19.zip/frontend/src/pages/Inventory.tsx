// Tồn kho multi-kho — quản lý nguyên liệu theo từng kho: nhập/xuất, chuyển kho,
// cảnh báo sắp hết, lịch sử. Bán 1 món tự trừ kho đang chọn ở POS.
import { useCallback, useEffect, useState } from 'react';
import {
  DbError,
  applyStockCheck,
  createIngredient,
  createWarehouse,
  deleteIngredient,
  deleteProductionOrder,
  ensureWarehousesSeeded,
  getDefaultWarehouseId,
  getMyProfile,
  listIngredients,
  listProductionOrders,
  listStockLogs,
  listWarehouseStock,
  listWarehouses,
  produceSemiFinished,
  setDefaultWarehouse,
  transferStock,
  updateIngredient,
  updateIngredientProductionRecipe,
  updateWarehouse,
} from '../lib/db';

import {
  addDaysVN,
  formatDMY,
  formatTime,
  formatVND,
  startOfMonthVN,
  startOfWeekVN,
  todayVN,
} from '../lib/format';
import { PageHead } from '../components/PageHead';
import { Sheet } from '../components/Sheet';
import { useToast } from '../components/Toast';
import { useAuth } from '../lib/auth';
import type { Ingredient, IngredientWithStock, ProductionOrder, StockLog, Warehouse } from '../lib/types';

const UNIT_SUGGESTIONS = ['g', 'kg', 'ml', 'lít', 'cái', 'hộp', 'túi', 'gói'];
const LS_WID = 'beesy_warehouse_id';

/** Hiển thị số lượng gọn: bỏ số 0 thừa do float (VD 0.30000000004 → 0.3). */
function formatQty(v: number): string {
  const n = parseFloat(v.toFixed(3));
  return n.toLocaleString('vi-VN', { maximumFractionDigits: 3 });
}

export function Inventory() {
  const toast = useToast();
  const { can } = useAuth();
  const canManage = can('inventory.manage');
  const isOwner = can('cashbook.settings');
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [wid, setWid] = useState('');
  const [tab, setTab] = useState<'stock' | 'ledger' | 'check' | 'transfer' | 'production' | 'warehouses'>('stock');
  const [items, setItems] = useState<IngredientWithStock[]>([]);
  const [busy, setBusy] = useState(true);
  const [noAccess, setNoAccess] = useState(false);
  const [formIng, setFormIng] = useState<Ingredient | 'new' | null>(null);
  const [produceIng, setProduceIng] = useState<IngredientWithStock | null>(null);

  const load = useCallback(
    async (focusWid?: string) => {
      setBusy(true);
      try {
        const me = await getMyProfile();
        const privileged = me.role === 'owner'; // CHỈ chủ quán thấy mọi kho
        let ws = await listWarehouses();
        if (privileged && ws.length === 0) {
          ws = await ensureWarehousesSeeded();
          toast.show('Đã tạo kho mặc định "Kho quầy"');
        }
        const allowed = privileged ? ws : ws.filter((w) => me.warehouse_ids.includes(w.id));
        setWarehouses(allowed);
        if (allowed.length === 0) {
          setNoAccess(true);
          setBusy(false);
          return;
        }
        setNoAccess(false);
        const saved = localStorage.getItem(LS_WID);
        const def = await getDefaultWarehouseId();
        const pick =
          focusWid && allowed.some((w) => w.id === focusWid)
            ? focusWid
            : saved && allowed.some((w) => w.id === saved)
              ? saved
              : def && allowed.some((w) => w.id === def)
                ? def
                : allowed[0].id;
        setWid(pick);
        localStorage.setItem(LS_WID, pick);
        // Tải tồn kho và lịch sử ĐỘC LẬP: lịch sử lỗi (VD: index đang build)
        // không được làm mất danh sách nguyên liệu.
        let stock: IngredientWithStock[] = [];
        try {
          stock = await listWarehouseStock(pick);
        } catch (e) {
          toast.show(e instanceof DbError ? e.message : 'Không tải được tồn kho');
        }
        setItems(stock);
      } catch (e) {
        toast.show(e instanceof DbError ? e.message : 'Không tải được tồn kho');
      } finally {
        setBusy(false);
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    },
    [],
  );

  useEffect(() => {
    void load();
  }, [load]);

  if (!busy && !noAccess && !can('inventory')) {
    return (
      <div className="page">
        <PageHead title="Tồn kho" />
        <div className="card">🔒 Chỉ Quản lý trở lên mới được quản lý tồn kho.</div>
      </div>
    );
  }

  if (noAccess && !busy) {
    return (
      <div className="page">
        <PageHead title="Tồn kho" />
        <div className="card">🔒 Tài khoản chưa được gán kho nào. Nhờ chủ quán vào Cài đặt → Nhân viên để gán kho.</div>
      </div>
    );
  }

  const lowCount = items.filter((i) => i.active && i.stock <= i.min_stock).length;
  const curWarehouse = warehouses.find((w) => w.id === wid);

  return (
    <div className="page">
      <PageHead title="Tồn kho" />

      {warehouses.length > 1 && (
        <div className="row" style={{ gap: 8, marginBottom: 12, flexWrap: 'wrap' }}>
          {warehouses.map((w) => (
            <button
              key={w.id}
              type="button"
              className={`sb-chip${wid === w.id ? ' selected' : ''}`}
              style={{ minHeight: 36, padding: '4px 12px', fontSize: 13 }}
              onClick={() => void load(w.id)}
            >
              🗃️ {w.name}
              {w.is_default ? ' ★' : ''}
            </button>
          ))}
        </div>
      )}

      <div className="sb-tabs">
        <button className={`sb-tab${tab === 'stock' ? ' active' : ''}`} onClick={() => setTab('stock')}>
          Nguyên liệu
        </button>
        <button className={`sb-tab${tab === 'ledger' ? ' active' : ''}`} onClick={() => setTab('ledger')}>
          Sổ kho
        </button>
        <button className={`sb-tab${tab === 'check' ? ' active' : ''}`} onClick={() => setTab('check')}>
          Kiểm kho
        </button>
        <button className={`sb-tab${tab === 'transfer' ? ' active' : ''}`} onClick={() => setTab('transfer')}>
          Chuyển kho
        </button>
        {canManage && (
          <button className={`sb-tab${tab === 'production' ? ' active' : ''}`} onClick={() => setTab('production')}>
            🧪 Sản xuất
          </button>
        )}
        {canManage && (
          <button className={`sb-tab${tab === 'warehouses' ? ' active' : ''}`} onClick={() => setTab('warehouses')}>
            Kho
          </button>
        )}
      </div>

      {busy ? (
        <div className="card">Đang tải…</div>
      ) : tab === 'stock' ? (
        <>
          <div className="row" style={{ gap: 12, marginBottom: 12 }}>
            <div className="card pastel-blue grow" style={{ boxShadow: 'none' }}>
              <div className="small muted">Nguyên liệu{curWarehouse ? ` · ${curWarehouse.name}` : ''}</div>
              <div className="money" style={{ fontSize: 22 }}>{items.filter((i) => i.active).length}</div>
            </div>
            <div className="card pastel-yellow grow" style={{ boxShadow: 'none' }}>
              <div className="small muted">Sắp hết / hết</div>
              <div className={`money ${lowCount > 0 ? 'text-orange' : ''}`} style={{ fontSize: 22 }}>
                {lowCount}
              </div>
            </div>
          </div>

          {canManage && (
            <div className="row only-desktop" style={{ marginBottom: 12 }}>
              <button className="btn" onClick={() => setFormIng('new')}>
                ＋ Thêm nguyên liệu
              </button>
            </div>
          )}

          {items.length === 0 ? (
            <div className="sb-empty">
              <div className="eico">🗃️</div>
              <p>Chưa có nguyên liệu nào.<br />Bấm + để thêm nguyên liệu đầu tiên.</p>
            </div>
          ) : (
            <div className="sb-section" style={{ padding: '4px 16px' }}>
              {items.map((ing) => {
                const low = ing.stock <= ing.min_stock;
                return (
                  <div key={ing.id} className="sb-row" style={{ cursor: 'default', opacity: ing.active ? 1 : 0.55 }}>
                    <span className="rbody">
                      <span className="rtitle" style={{ fontWeight: 600 }}>
                        {ing.is_product_stock && <span style={{ marginRight: 4 }}>📦</span>}
                        {ing.name}
                        {ing.is_product_stock && (
                          <span className="sb-status-pill" style={{ marginLeft: 6, fontSize: 11 }}>Hàng hóa</span>
                        )}
                        {ing.production_recipe && ing.production_recipe.length > 0 && (
                          <span className="sb-status-pill" style={{ marginLeft: 6, fontSize: 11, background: 'var(--pastel-purple, #f0e6ff)' }}>🧪 Bán thành phẩm</span>
                        )}
                        {!ing.active && (
                          <span className="sb-status-pill" style={{ marginLeft: 6, fontSize: 11 }}>Đang ẩn</span>
                        )}
                      </span>
                      <span className="rsub">
                        Tối thiểu: {formatQty(ing.min_stock)} {ing.unit}
                        {ing.cost_per_unit > 0 && <> · {formatVND(ing.cost_per_unit)}/{ing.unit}</>}
                        {low && <span style={{ color: 'var(--orange)', fontWeight: 700 }}> · sắp hết!</span>}
                      </span>
                    </span>
                    <span className="row" style={{ gap: 6, alignItems: 'center', flex: '0 0 auto' }}>
                      <span className="rbody" style={{ alignItems: 'flex-end' }}>
                        <span className={`ramount ${low ? 'text-orange' : 'text-green'}`}>{formatQty(ing.stock)}</span>
                        <span className="rsub">{ing.unit}</span>
                      </span>
                      {canManage && ing.production_recipe && ing.production_recipe.length > 0 && (
                        <button
                          type="button"
                          className="sb-chip"
                          style={{ borderColor: 'var(--brand)', color: 'var(--brand-dark)' }}
                          onClick={() => setProduceIng(ing)}
                        >
                          🧪 SX
                        </button>
                      )}
                      {canManage && (
                        <button type="button" className="sb-chip" onClick={() => setFormIng(ing)}>
                          Sửa
                        </button>
                      )}
                    </span>
                  </div>
                );
              })}
            </div>
          )}

          {canManage && (
            <button className="fab" onClick={() => setFormIng('new')} aria-label="Thêm nguyên liệu">
              +
            </button>
          )}
        </>
      ) : tab === 'transfer' ? (
        <TransferForm
          warehouses={warehouses}
          fromWid={wid}
          items={items}
          onDone={() => void load()}
        />
      ) : tab === 'production' ? (
        <ProductionTab
          warehouseId={wid}
          warehouseName={curWarehouse?.name ?? ''}
          items={items}
          isOwner={isOwner}
          onDone={() => void load()}
        />
      ) : tab === 'ledger' ? (
        <LedgerTab warehouseId={wid} warehouseName={curWarehouse?.name ?? ''} items={items} />
      ) : tab === 'check' ? (
        <CheckTab warehouseId={wid} warehouseName={curWarehouse?.name ?? ''} items={items} onDone={() => void load()} />
      ) : (
        <WarehouseManager onChanged={() => void load()} />
      )}

      {produceIng && (
        <ProduceSheet
          ingredient={produceIng}
          items={items}
          warehouseId={wid}
          warehouseName={curWarehouse?.name ?? ''}
          onClose={() => setProduceIng(null)}
          onDone={() => {
            setProduceIng(null);
            void load();
          }}
        />
      )}

      {formIng && (
        <IngredientForm
          ingredient={formIng === 'new' ? null : formIng}
          warehouseId={wid}
          warehouseName={curWarehouse?.name ?? ''}
          onClose={() => setFormIng(null)}
          onDone={() => {
            setFormIng(null);
            void load();
          }}
        />
      )}

    </div>
  );
}

type LedgerFilterKey = 'today' | 'yesterday' | 'week' | 'lastweek' | 'month' | 'lastmonth' | 'custom';
const LEDGER_FILTERS: { key: LedgerFilterKey; label: string }[] = [
  { key: 'today', label: 'Hôm nay' },
  { key: 'yesterday', label: 'Hôm qua' },
  { key: 'week', label: 'Tuần này' },
  { key: 'lastweek', label: 'Tuần trước' },
  { key: 'month', label: 'Tháng này' },
  { key: 'lastmonth', label: 'Tháng trước' },
  { key: 'custom', label: 'Tùy chọn' },
];

/** Sổ kho: tổng hợp tồn đầu/nhập/xuất/tồn cuối theo kỳ + lịch sử giao dịch. */
// ------------------------------------------------------------- sản xuất ---
/** Tab lịch sử phiếu sản xuất bán thành phẩm. */
function ProductionTab({
  warehouseId,
  warehouseName,
  items,
  isOwner,
  onDone,
}: {
  warehouseId: string;
  warehouseName: string;
  items: IngredientWithStock[];
  isOwner: boolean;
  onDone: () => void;
}) {
  const toast = useToast();
  const [orders, setOrders] = useState<ProductionOrder[]>([]);
  const [busy, setBusy] = useState(true);
  const [produceIng, setProduceIng] = useState<IngredientWithStock | null>(null);
  const [confirmDel, setConfirmDel] = useState<string | null>(null);

  const semis = items.filter((i) => i.active && i.production_recipe && i.production_recipe.length > 0);

  const load = useCallback(async () => {
    setBusy(true);
    try {
      setOrders(await listProductionOrders(100));
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tải được phiếu sản xuất');
    } finally {
      setBusy(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [warehouseId]);

  useEffect(() => {
    void load();
  }, [load]);

  const del = async (id: string) => {
    try {
      await deleteProductionOrder(id);
      toast.show('Đã xóa phiếu sản xuất (đã hoàn tác tồn kho)');
      setConfirmDel(null);
      void load();
      onDone();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Xóa thất bại');
    }
  };

  return (
    <>
      {semis.length > 0 ? (
        <div className="field">
          <label>Sản xuất bán thành phẩm tại {warehouseName || 'kho đang chọn'}</label>
          <div className="row" style={{ flexWrap: 'wrap', gap: 8 }}>
            {semis.map((sm) => (
              <button key={sm.id} type="button" className="sb-chip" onClick={() => setProduceIng(sm)}>
                🧪 {sm.name}
              </button>
            ))}
          </div>
        </div>
      ) : (
        <div className="card" style={{ marginBottom: 12 }}>
          <p className="small muted" style={{ margin: 0 }}>
            Chưa có bán thành phẩm nào. Vào tab <b>Nguyên liệu</b> → <b>Sửa</b> nguyên liệu → thêm
            <b> 🧪 Công thức sản xuất</b> để bắt đầu.
          </p>
        </div>
      )}

      <div className="small muted" style={{ marginBottom: 8, fontWeight: 700 }}>
        Lịch sử sản xuất ({orders.length})
      </div>
      {busy ? (
        <div className="card">Đang tải…</div>
      ) : orders.length === 0 ? (
        <div className="sb-empty">
          <div className="eico">🧪</div>
          <p>Chưa có phiếu sản xuất nào.</p>
        </div>
      ) : (
        <div className="sb-section" style={{ padding: '4px 16px' }}>
          {orders.map((o) => (
            <div key={o.id} className="sb-row" style={{ cursor: 'default', paddingRight: isOwner ? 42 : undefined, position: 'relative' }}>
              <span className="rbody">
                <span className="rtitle" style={{ fontWeight: 700 }}>
                  {o.code} <span className="rsub">· {o.business_date}</span>
                </span>
                <span className="rsub">
                  🧪 {formatQty(o.qty_produced)} {o.product_unit} {o.product_name} · {o.warehouse_name}
                </span>
                <span className="rsub">
                  Dùng: {o.ingredients_used.map((u) => `${u.ingredient_name} ${formatQty(u.qty)}${u.unit}`).join(' · ')}
                </span>
                {o.note && <span className="rsub">📝 {o.note}</span>}
              </span>
              {isOwner &&
                (confirmDel === o.id ? (
                  <span className="row" style={{ gap: 6, position: 'absolute', right: 8, top: 8 }}>
                    <button type="button" className="sb-chip" onClick={() => void del(o.id)}>
                      Xóa
                    </button>
                    <button type="button" className="sb-chip" onClick={() => setConfirmDel(null)}>
                      Hủy
                    </button>
                  </span>
                ) : (
                  <button
                    type="button"
                    className="sb-row-del"
                    aria-label={`Xóa ${o.code}`}
                    onClick={() => setConfirmDel(o.id)}
                  >
                    ×
                  </button>
                ))}
            </div>
          ))}
        </div>
      )}

      {produceIng && (
        <ProduceSheet
          ingredient={produceIng}
          items={items}
          warehouseId={warehouseId}
          warehouseName={warehouseName}
          onClose={() => setProduceIng(null)}
          onDone={() => {
            setProduceIng(null);
            void load();
            onDone();
          }}
        />
      )}
    </>
  );
}

/** Sheet sản xuất: nhập số lượng → xem nguyên liệu thô sẽ trừ → xác nhận. */
function ProduceSheet({
  ingredient,
  items,
  warehouseId,
  warehouseName,
  onClose,
  onDone,
}: {
  ingredient: IngredientWithStock;
  items: IngredientWithStock[];
  warehouseId: string;
  warehouseName: string;
  onClose: () => void;
  onDone: () => void;
}) {
  const toast = useToast();
  const [qty, setQty] = useState('');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);

  const num = (v: string) => parseFloat(String(v).replace(',', '.'));
  const q = num(qty);
  const recipe = ingredient.production_recipe ?? [];

  const needs = recipe.map((r) => {
    const raw = items.find((i) => i.id === r.ingredient_id);
    const needQty = Number.isFinite(q) && q > 0 ? r.qty * q : 0;
    return {
      ingredient_id: r.ingredient_id,
      name: raw?.name ?? 'Nguyên liệu?',
      unit: raw?.unit ?? '',
      perUnit: r.qty,
      needQty,
      stock: raw?.stock ?? 0,
      ok: (raw?.stock ?? 0) >= needQty,
    };
  });
  const allOk = Number.isFinite(q) && q > 0 && needs.every((n) => n.ok) && needs.length > 0;

  const confirm = async () => {
    if (!Number.isFinite(q) || q <= 0) {
      toast.show('Nhập số lượng cần sản xuất');
      return;
    }
    const lacking = needs.filter((n) => !n.ok);
    if (lacking.length > 0) {
      toast.show(`Không đủ: ${lacking.map((n) => n.name).join(', ')}`);
      return;
    }
    setBusy(true);
    try {
      const po = await produceSemiFinished({
        ingredientId: ingredient.id,
        qty: q,
        warehouseId,
        note: note.trim() || null,
      });
      toast.show(`Đã sản xuất ${formatQty(po.qty_produced)} ${po.product_unit} ${po.product_name} (${po.code})`);
      onDone();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Sản xuất thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet
      title={`🧪 Sản xuất ${ingredient.name}`}
      onClose={onClose}
      footer={
        <button className="btn btn-block btn-lg" disabled={busy || !allOk} onClick={confirm}>
          {busy ? 'Đang sản xuất…' : `Xác nhận sản xuất`}
        </button>
      }
    >
      <p className="small muted" style={{ marginTop: 0 }}>
        Kho: <b>{warehouseName}</b> · Tồn hiện tại: <b>{formatQty(ingredient.stock)} {ingredient.unit}</b>
      </p>
      <div className="field">
        <label>Số lượng cần làm ({ingredient.unit}) *</label>
        <input
          className="input"
          inputMode="decimal"
          value={qty}
          onChange={(e) => setQty(e.target.value)}
          placeholder={`VD: 1000`}
          autoFocus
        />
      </div>
      {needs.length > 0 && (
        <div className="field">
          <label>Nguyên liệu thô sẽ trừ</label>
          <div className="card" style={{ padding: '8px 12px' }}>
            {needs.map((n) => (
              <div key={n.ingredient_id} className="row" style={{ padding: '6px 0', borderBottom: '1px solid var(--line)' }}>
                <span className="grow">
                  {n.ok ? '✅' : '❌'} {n.name}
                  <span className="small muted">
                    {' '}({formatQty(n.perUnit)}/{ingredient.unit})
                  </span>
                </span>
                <span style={{ fontWeight: 700, color: n.ok ? undefined : 'var(--red)' }}>
                  {formatQty(n.needQty)} {n.unit}
                </span>
                <span className="small muted">/ còn {formatQty(n.stock)}</span>
              </div>
            ))}
          </div>
        </div>
      )}
      <div className="field">
        <label>Ghi chú</label>
        <input
          className="input"
          value={note}
          onChange={(e) => setNote(e.target.value)}
          maxLength={500}
          placeholder="VD: làm mẻ kem muối chiều"
        />
      </div>
    </Sheet>
  );
}

function LedgerTab({
  warehouseId,
  warehouseName,
  items,
}: {
  warehouseId: string;
  warehouseName: string;
  items: IngredientWithStock[];
}) {
  const toast = useToast();
  const [logs, setLogs] = useState<StockLog[]>([]);
  const [busy, setBusy] = useState(true);
  const [filter, setFilter] = useState<LedgerFilterKey>('month');
  const [customFrom, setCustomFrom] = useState(() => todayVN());
  const [customTo, setCustomTo] = useState(() => todayVN());

  const load = useCallback(async () => {
    if (!warehouseId) return;
    setBusy(true);
    try {
      const lg = await listStockLogs(warehouseId, 500);
      setLogs(lg);
    } catch (err) {
      toast.show(err instanceof DbError ? err.message : 'Không tải được sổ kho');
    } finally {
      setBusy(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [warehouseId]);

  useEffect(() => {
    void load();
  }, [load]);

  const t = todayVN();
  const [rangeFrom, rangeTo] = (() => {
    switch (filter) {
      case 'today':
        return [t, t];
      case 'yesterday': {
        const y = addDaysVN(t, -1);
        return [y, y];
      }
      case 'week':
        return [startOfWeekVN(t), t];
      case 'lastweek': {
        const mondayThis = startOfWeekVN(t);
        const mondayLast = addDaysVN(mondayThis, -7);
        return [mondayLast, addDaysVN(mondayLast, 6)];
      }
      case 'month':
        return [startOfMonthVN(t), t];
      case 'lastmonth': {
        const firstThis = startOfMonthVN(t);
        const lastPrev = addDaysVN(firstThis, -1);
        return [startOfMonthVN(lastPrev), lastPrev];
      }
      case 'custom':
        return [customFrom <= customTo ? customFrom : customTo, customFrom <= customTo ? customTo : customFrom];
    }
  })();

  // Log trong kỳ
  const inRange = logs.filter((l) => {
    const k = l.created_at.slice(0, 10);
    return k >= rangeFrom && k <= rangeTo;
  });

  // Nhóm log theo ngày
  const grouped = new Map<string, StockLog[]>();
  for (const l of inRange) {
    const k = l.created_at.slice(0, 10);
    if (!grouped.has(k)) grouped.set(k, []);
    grouped.get(k)!.push(l);
  }
  const dates = [...grouped.keys()].sort().reverse();

  // Tổng hợp theo từng nguyên liệu: tồn đầu/nhập/xuất/tồn cuối (theo đơn vị riêng)
  const productSummaries = (() => {
    const map = new Map<string, { ingredient_id: string; ingredient_name: string; unit: string; opening: number; importQty: number; exportQty: number; closing: number }>();
    // Khởi tạo từ items hiện tại (tồn cuối kỳ = tồn hiện tại)
    for (const it of items) {
      map.set(it.id, {
        ingredient_id: it.id,
        ingredient_name: it.name,
        unit: it.unit,
        opening: it.stock,
        importQty: 0,
        exportQty: 0,
        closing: it.stock,
      });
    }
    // Cộng dồn biến động trong kỳ, suy ra tồn đầu kỳ
    for (const l of inRange) {
      let ps = map.get(l.ingredient_id);
      if (!ps) {
        ps = {
          ingredient_id: l.ingredient_id,
          ingredient_name: l.ingredient_name,
          unit: '',
          opening: l.balance_after,
          importQty: 0,
          exportQty: 0,
          closing: l.balance_after,
        };
        map.set(l.ingredient_id, ps);
      }
      if (l.change > 0) ps.importQty += l.change;
      else ps.exportQty += Math.abs(l.change);
    }
    // Tồn đầu kỳ = tồn cuối - nhập + xuất
    for (const ps of map.values()) {
      ps.opening = Math.round((ps.closing - ps.importQty + ps.exportQty) * 100) / 100;
    }
    return [...map.values()]
      .filter((ps) => ps.importQty > 0 || ps.exportQty > 0)
      .sort((a, b) => a.ingredient_name.localeCompare(b.ingredient_name, 'vi'));
  })();

  const dateLabel = (ymd: string) => {
    const d = new Date(ymd + 'T00:00:00');
    const wd = d.toLocaleDateString('vi-VN', { weekday: 'long' });
    const [, m, day] = ymd.split('-');
    return `${wd.charAt(0).toUpperCase() + wd.slice(1)}, ${day}/${m}`;
  };

  return (
    <>
      <div className="row" style={{ gap: 8, marginBottom: 12 }}>
        <select
          className="input"
          style={{ flex: 1, minWidth: 0 }}
          value={filter}
          onChange={(e) => setFilter(e.target.value as LedgerFilterKey)}
          aria-label="Lọc theo thời gian"
        >
          {LEDGER_FILTERS.map((f) => (
            <option key={f.key} value={f.key}>
              {f.label}
            </option>
          ))}
        </select>
      </div>
      {filter === 'custom' && (
        <div className="row" style={{ gap: 8, marginBottom: 12, alignItems: 'center' }}>
          <input type="date" className="input" style={{ flex: 1 }} value={customFrom} max={customTo} onChange={(e) => e.target.value && setCustomFrom(e.target.value)} aria-label="Từ ngày" />
          <span className="small muted">→</span>
          <input type="date" className="input" style={{ flex: 1 }} value={customTo} min={customFrom} onChange={(e) => e.target.value && setCustomTo(e.target.value)} aria-label="Đến ngày" />
        </div>
      )}

      <div className="sb-section" style={{ marginBottom: 12, padding: '12px 16px' }}>
        <div className="small muted" style={{ marginBottom: 8 }}>
          {warehouseName} · {formatDMY(rangeFrom)} → {formatDMY(rangeTo)}
        </div>
        <div className="small" style={{ fontWeight: 700, marginBottom: 4 }}>
          Tồn đầu → Nhập → Xuất → Tồn cuối (theo đơn vị từng món)
        </div>
        {productSummaries.length === 0 ? (
          <p className="small muted">Chưa có biến động nào trong kỳ.</p>
        ) : (
          productSummaries.map((ps) => (
            <div key={ps.ingredient_id} className="row" style={{ justifyContent: 'space-between', padding: '6px 0', borderTop: '1px solid var(--line)' }}>
              <span>
                <span style={{ fontWeight: 600 }}>{ps.ingredient_name}</span>
                <span className="small muted" style={{ display: 'block' }}>
                  Đầu: {formatQty(ps.opening)} · Nhập: <span className="text-green">+{formatQty(ps.importQty)}</span> · Xuất:{' '}
                  <span className="text-orange">-{formatQty(ps.exportQty)}</span>
                </span>
              </span>
              <span style={{ textAlign: 'right' }}>
                <b className="money" style={{ fontSize: 16 }}>
                  {formatQty(ps.closing)}
                </b>
                <span className="small muted" style={{ display: 'block' }}>{ps.unit}</span>
              </span>
            </div>
          ))
        )}
      </div>

      {busy ? (
        <div className="card">Đang tải…</div>
      ) : dates.length === 0 ? (
        <div className="sb-empty">
          <div className="eico">📜</div>
          <p>Chưa có giao dịch nào trong kỳ.</p>
        </div>
      ) : (
        dates.map((d) => (
          <div key={d} style={{ marginBottom: 12 }}>
            <div className="small muted" style={{ padding: '6px 4px', fontWeight: 600 }}>
              {dateLabel(d)}
            </div>
            <div className="sb-section" style={{ padding: '4px 16px' }}>
              {grouped.get(d)!.map((l) => (
                <div key={l.id} className="sb-row" style={{ cursor: 'default' }}>
                  <span
                    className="avatar"
                    style={
                      l.change > 0
                        ? { background: 'var(--green-bg)', color: 'var(--brand-dark)' }
                        : { background: 'var(--orange-bg)', color: 'var(--orange)' }
                    }
                  >
                    {l.change > 0 ? '↓' : '↑'}
                  </span>
                  <span className="rbody">
                    <span className="rtitle" style={{ fontWeight: 600 }}>
                      {l.ingredient_name}
                    </span>
                    <span className="rsub">
                      {l.note ? `${l.note} · ` : ''}
                      {formatTime(l.created_at)}
                    </span>
                  </span>
                  <span style={{ textAlign: 'right' }}>
                    <span className={`ramount ${l.change > 0 ? 'text-green' : 'text-orange'}`}>
                      {l.change > 0 ? '+' : ''}
                      {formatQty(l.change)}
                    </span>
                    <span className="small muted" style={{ display: 'block' }}>
                      còn {formatQty(l.balance_after)}
                    </span>
                  </span>
                </div>
              ))}
            </div>
          </div>
        ))
      )}
    </>
  );
}

/** Kiểm kho: đếm thực tế, so với hệ thống, cân bằng chênh lệch. */
function CheckTab({
  warehouseId,
  warehouseName,
  items,
  onDone,
}: {
  warehouseId: string;
  warehouseName: string;
  items: IngredientWithStock[];
  onDone: () => void;
}) {
  const toast = useToast();
  const [q, setQ] = useState('');
  const [counts, setCounts] = useState<Record<string, string>>({});
  const [note, setNote] = useState('');
  const [saving, setSaving] = useState(false);

  const needle = q.trim().toLowerCase();
  const list = items.filter((it) => it.active && (!needle || it.name.toLowerCase().includes(needle)));

  const diffOf = (it: IngredientWithStock) => {
    const raw = counts[it.id];
    if (raw === undefined || raw === '') return null;
    const actual = parseFloat(raw);
    if (!Number.isFinite(actual)) return null;
    return Math.round((actual - it.stock) * 100) / 100;
  };

  const diffs = list
    .map((it) => ({ it, diff: diffOf(it) }))
    .filter((x) => x.diff !== null && x.diff !== 0) as { it: IngredientWithStock; diff: number }[];

  const setCount = (id: string, v: string) => setCounts((prev) => ({ ...prev, [id]: v }));

  const submit = async () => {
    if (diffs.length === 0) return toast.show('Chưa có chênh lệch nào cần cân bằng');
    if (!window.confirm(`Cân bằng ${diffs.length} nguyên liệu về số thực tế?`)) return;
    setSaving(true);
    try {
      const res = await applyStockCheck(
        warehouseId,
        diffs.map((d) => ({ ingredientId: d.it.id, actualQty: parseFloat(counts[d.it.id]) })),
        note.trim() || null,
      );
      toast.show(`Đã cân bằng ${res.adjusted} nguyên liệu ✅`);
      setCounts({});
      setNote('');
      onDone();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Cân bằng kho thất bại');
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <div className="small muted" style={{ marginBottom: 8 }}>
        {warehouseName} · Đếm thực tế rồi nhập vào, hệ thống sẽ tính chênh lệch.
      </div>
      <div className="field" style={{ marginBottom: 12 }}>
        <input
          className="input"
          placeholder="🔍 Tìm nguyên liệu…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          aria-label="Tìm nguyên liệu"
        />
      </div>
      {list.length === 0 ? (
        <div className="sb-empty">
          <div className="eico">📦</div>
          <p>Không tìm thấy nguyên liệu.</p>
        </div>
      ) : (
        <div className="sb-section" style={{ padding: '4px 16px', marginBottom: 12 }}>
          {list.map((it) => {
            const diff = diffOf(it);
            return (
              <div key={it.id} className="sb-row" style={{ cursor: 'default', alignItems: 'center' }}>
                <span className="rbody">
                  <span className="rtitle" style={{ fontWeight: 600 }}>
                    {it.name}
                  </span>
                  <span className="rsub">
                    Hệ thống: {formatQty(it.stock)} {it.unit}
                    {diff !== null && diff !== 0 && (
                      <span style={{ color: diff > 0 ? 'var(--brand-dark)' : 'var(--orange)', fontWeight: 700 }}>
                        {' '}· Lệch {diff > 0 ? '+' : ''}
                        {formatQty(diff)}
                      </span>
                    )}
                  </span>
                </span>
                <span className="row" style={{ gap: 4, flex: '0 0 auto', alignItems: 'center' }}>
                  <button
                    type="button"
                    className="btn btn-outline"
                    style={{ minWidth: 36, minHeight: 36, padding: '4px 8px' }}
                    onClick={() => {
                      const cur = parseFloat(counts[it.id] ?? String(it.stock)) || 0;
                      setCount(it.id, String(Math.max(0, Math.round((cur - 1) * 100) / 100)));
                    }}
                    aria-label="Giảm"
                  >
                    −
                  </button>
                  <input
                    className="input"
                    inputMode="decimal"
                    style={{ width: 76, textAlign: 'center' }}
                    placeholder={String(it.stock)}
                    value={counts[it.id] ?? ''}
                    onChange={(e) => setCount(it.id, e.target.value.replace(/[^\d.]/g, ''))}
                    aria-label={`Số thực tế ${it.name}`}
                  />
                  <button
                    type="button"
                    className="btn btn-outline"
                    style={{ minWidth: 36, minHeight: 36, padding: '4px 8px' }}
                    onClick={() => {
                      const cur = parseFloat(counts[it.id] ?? String(it.stock)) || 0;
                      setCount(it.id, String(Math.round((cur + 1) * 100) / 100));
                    }}
                    aria-label="Tăng"
                  >
                    +
                  </button>
                </span>
              </div>
            );
          })}
        </div>
      )}
      {diffs.length > 0 && (
        <div className="sb-section" style={{ marginBottom: 12, padding: '12px 16px' }}>
          <div className="row" style={{ justifyContent: 'space-between', padding: '4px 0' }}>
            <span className="muted">Số dòng lệch</span>
            <b>{diffs.length}</b>
          </div>
          <div className="field" style={{ marginTop: 8 }}>
            <label>Ghi chú kiểm kho</label>
            <input
              className="input"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="VD: kiểm cuối ngày…"
            />
          </div>
          <button className="btn btn-block btn-lg" disabled={saving} onClick={() => void submit()} style={{ marginTop: 8 }}>
            {saving ? 'Đang lưu…' : `⚖️ Cân bằng kho (${diffs.length})`}
          </button>
        </div>
      )}
    </>
  );
}

function IngredientForm({
  ingredient,
  warehouseId,
  warehouseName,
  onClose,
  onDone,
}: {
  ingredient: Ingredient | null;
  warehouseId: string;
  warehouseName: string;
  onClose: () => void;
  onDone: () => void;
}) {
  const toast = useToast();
  const [name, setName] = useState(ingredient?.name ?? '');
  const [unit, setUnit] = useState(ingredient?.unit ?? 'g');
  const [stock, setStock] = useState('');
  const [minStock, setMinStock] = useState(ingredient?.min_stock ? String(ingredient.min_stock) : '');
  const [cost, setCost] = useState(ingredient?.cost_per_unit ? String(ingredient.cost_per_unit) : '');
  const [active, setActive] = useState(ingredient?.active ?? true);
  const [busy, setBusy] = useState(false);
  const [confirmDel, setConfirmDel] = useState(false);
  // Công thức sản xuất bán thành phẩm (định lượng cho 1 đơn vị)
  const [showRecipe, setShowRecipe] = useState(
    !!ingredient?.production_recipe && ingredient.production_recipe.length > 0,
  );
  const [recipeRows, setRecipeRows] = useState<Array<{ ingredient_id: string; qty: string }>>(
    ingredient?.production_recipe?.map((r) => ({ ingredient_id: r.ingredient_id, qty: String(r.qty) })) ?? [],
  );
  const [allIngs, setAllIngs] = useState<Ingredient[]>([]);
  const [ingsLoaded, setIngsLoaded] = useState(false);

  const num = (v: string) => parseFloat(String(v).replace(',', '.'));

  const openRecipe = async () => {
    const next = !showRecipe;
    setShowRecipe(next);
    if (next && !ingsLoaded) {
      try {
        const list = await listIngredients();
        setAllIngs(list.filter((i) => i.active && (!ingredient || i.id !== ingredient.id)));
      } catch {
        /* bỏ qua */
      } finally {
        setIngsLoaded(true);
      }
    }
  };

  const save = async () => {
    if (!name.trim()) {
      toast.show('Nhập tên nguyên liệu');
      return;
    }
    setBusy(true);
    try {
      if (ingredient) {
        await updateIngredient(ingredient.id, {
          name: name.trim(),
          unit: unit.trim() || 'đơn vị',
          min_stock: Number.isFinite(num(minStock)) ? Math.max(0, num(minStock)) : 0,
          cost_per_unit: Number.isFinite(num(cost)) ? Math.max(0, Math.round(num(cost))) : 0,
          active,
        });
        // Lưu công thức sản xuất (nếu có thay đổi ở section)
        if (showRecipe || (ingredient.production_recipe?.length ?? 0) > 0) {
          const recipe = recipeRows
            .map((r) => ({ ingredient_id: r.ingredient_id, qty: num(r.qty) }))
            .filter((r) => r.ingredient_id && Number.isFinite(r.qty) && r.qty > 0);
          await updateIngredientProductionRecipe(ingredient.id, recipe);
        }
        toast.show('Đã cập nhật nguyên liệu');
      } else {
        const s = stock.trim() === '' ? 0 : num(stock);
        if (!Number.isFinite(s)) {
          toast.show('Tồn đầu không hợp lệ');
          setBusy(false);
          return;
        }
        const created = await createIngredient(
          {
            name: name.trim(),
            unit: unit.trim() || 'đơn vị',
            stock: s,
            min_stock: Number.isFinite(num(minStock)) ? Math.max(0, num(minStock)) : 0,
            cost_per_unit: Number.isFinite(num(cost)) ? Math.max(0, Math.round(num(cost))) : 0,
          },
          warehouseId,
        );
        if (showRecipe) {
          const recipe = recipeRows
            .map((r) => ({ ingredient_id: r.ingredient_id, qty: num(r.qty) }))
            .filter((r) => r.ingredient_id && Number.isFinite(r.qty) && r.qty > 0);
          if (recipe.length > 0) await updateIngredientProductionRecipe(created.id, recipe);
        }
        toast.show('Đã thêm nguyên liệu');
      }
      onDone();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    if (!ingredient) return;
    setBusy(true);
    try {
      await deleteIngredient(ingredient.id);
      toast.show('Đã xóa nguyên liệu');
      onDone();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Xóa thất bại');
    } finally {
      setBusy(false);
      setConfirmDel(false);
    }
  };

  return (
    <Sheet
      title={ingredient ? 'Sửa nguyên liệu' : 'Thêm nguyên liệu'}
      onClose={onClose}
      footer={
        <button className="btn btn-block btn-lg" disabled={busy} onClick={save}>
          {busy ? 'Đang lưu…' : 'Lưu'}
        </button>
      }
    >
      <div className="field">
        <label>Tên nguyên liệu *</label>
        <input
          className="input"
          value={name}
          onChange={(e) => setName(e.target.value)}
          maxLength={60}
          placeholder="VD: Cà phê bột"
          autoFocus={!ingredient}
        />
      </div>
      <div className="field">
        <label>Đơn vị</label>
        <div className="row" style={{ flexWrap: 'wrap', gap: 8, marginBottom: 8 }}>
          {UNIT_SUGGESTIONS.map((u) => (
            <button
              key={u}
              type="button"
              className={`sb-chip${unit === u ? ' selected' : ''}`}
              onClick={() => setUnit(u)}
            >
              {u}
            </button>
          ))}
        </div>
        <input
          className="input"
          value={unit}
          onChange={(e) => setUnit(e.target.value)}
          maxLength={20}
          placeholder="Hoặc nhập đơn vị khác…"
        />
      </div>
      {!ingredient && (
        <div className="field">
          <label>Tồn đầu tại {warehouseName || 'kho đang chọn'}</label>
          <input
            className="input"
            inputMode="decimal"
            value={stock}
            onChange={(e) => setStock(e.target.value)}
            placeholder="0"
          />
        </div>
      )}
      <div className="field">
        <label>Tồn tối thiểu (cảnh báo sắp hết)</label>
        <input
          className="input"
          inputMode="decimal"
          value={minStock}
          onChange={(e) => setMinStock(e.target.value)}
          placeholder="0"
        />
      </div>
      <div className="field">
        <label>Giá vốn / đơn vị (VND, tham khảo)</label>
        <input
          className="input"
          inputMode="numeric"
          value={cost}
          onChange={(e) => setCost(e.target.value)}
          placeholder="0"
        />
      </div>
      <div className="card" style={{ marginBottom: 16, background: 'var(--pastel-purple, #f7f2ff)' }}>
        <button
          type="button"
          className="btn btn-block btn-outline"
          onClick={openRecipe}
          style={{ borderStyle: 'dashed' }}
        >
          🧪 {showRecipe ? 'Ẩn công thức sản xuất' : 'Thêm công thức sản xuất (bán thành phẩm)'}
        </button>
        {showRecipe && (
          <div style={{ marginTop: 12 }}>
            <p className="small muted" style={{ marginBottom: 8 }}>
              Định lượng nguyên liệu thô cần để tạo ra <b>1 {unit.trim() || 'đơn vị'}</b> “{name.trim() || 'thành phẩm này'}”.
              <br />
              VD: 1 ml kem muối cần 0.8 ml kem béo.
            </p>
            {recipeRows.map((row, idx) => {
              const picked = allIngs.find((i) => i.id === row.ingredient_id);
              return (
                <div key={idx} className="row" style={{ gap: 8, marginBottom: 8 }}>
                  <select
                    className="input grow"
                    value={row.ingredient_id}
                    onChange={(e) => {
                      const next = [...recipeRows];
                      next[idx] = { ...next[idx], ingredient_id: e.target.value };
                      setRecipeRows(next);
                    }}
                  >
                    <option value="">— Chọn nguyên liệu thô —</option>
                    {allIngs.map((i) => (
                      <option key={i.id} value={i.id}>
                        {i.name} ({i.unit})
                      </option>
                    ))}
                  </select>
                  <input
                    className="input"
                    style={{ width: 110 }}
                    inputMode="decimal"
                    placeholder="SL"
                    value={row.qty}
                    onChange={(e) => {
                      const next = [...recipeRows];
                      next[idx] = { ...next[idx], qty: e.target.value };
                      setRecipeRows(next);
                    }}
                  />
                  <span className="small muted" style={{ alignSelf: 'center', minWidth: 32 }}>
                    {picked ? `/${picked.unit}` : ''}
                  </span>
                  <button
                    type="button"
                    className="sb-chip"
                    onClick={() => setRecipeRows(recipeRows.filter((_, i) => i !== idx))}
                    aria-label="Xóa dòng"
                  >
                    ×
                  </button>
                </div>
              );
            })}
            <button
              type="button"
              className="btn btn-outline btn-block"
              onClick={() => setRecipeRows([...recipeRows, { ingredient_id: '', qty: '' }])}
            >
              ＋ Thêm nguyên liệu thô
            </button>
            {recipeRows.length === 0 && (
              <p className="small muted" style={{ marginTop: 8 }}>
                Để trống và lưu = xóa công thức (trở thành nguyên liệu thường).
              </p>
            )}
          </div>
        )}
      </div>
      {ingredient && (
        <div className="row" style={{ marginBottom: 16 }}>
          <span className="grow" style={{ fontWeight: 600, fontSize: 15 }}>Đang dùng</span>
          <label className="switch" aria-label="Đang dùng">
            <input type="checkbox" checked={active} onChange={(e) => setActive(e.target.checked)} />
            <span className="track" />
          </label>
        </div>
      )}
      {ingredient &&
        (confirmDel ? (
          <div className="row" style={{ gap: 8 }}>
            <button type="button" className="btn grow" style={{}} disabled={busy} onClick={remove}>
              Chắc chắn xóa
            </button>
            <button type="button" className="btn btn-outline grow" onClick={() => setConfirmDel(false)}>
              Hủy
            </button>
          </div>
        ) : (
          <button
            type="button"
            className="btn btn-ghost btn-block"
            onClick={() => setConfirmDel(true)}
          >
            Xóa nguyên liệu
          </button>
        ))}
    </Sheet>
  );
}

function TransferForm({
  warehouses,
  fromWid,
  items,
  onDone,
}: {
  warehouses: Warehouse[];
  fromWid: string;
  items: IngredientWithStock[];
  onDone: () => void;
}) {
  const toast = useToast();
  const [ingId, setIngId] = useState('');
  const [from, setFrom] = useState(fromWid);
  const [to, setTo] = useState('');
  const [qty, setQty] = useState('');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    setFrom(fromWid);
  }, [fromWid]);
  useEffect(() => {
    if (!to) {
      const other = warehouses.find((w) => w.id !== from);
      if (other) setTo(other.id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [warehouses, from]);

  const ing = items.find((i) => i.id === ingId);

  const submit = async () => {
    if (!ing) {
      toast.show('Chọn nguyên liệu cần chuyển');
      return;
    }
    const v = parseFloat(String(qty).replace(',', '.'));
    if (!Number.isFinite(v) || v <= 0) {
      toast.show('Nhập số lượng hợp lệ');
      return;
    }
    if (!from || !to || from === to) {
      toast.show('Chọn kho nguồn và kho đích khác nhau');
      return;
    }
    setBusy(true);
    try {
      await transferStock(from, to, ing.id, v, note.trim() || null);
      const fromName = warehouses.find((w) => w.id === from)?.name ?? '';
      const toName = warehouses.find((w) => w.id === to)?.name ?? '';
      toast.show(`Đã chuyển ${formatQty(v)} ${ing.unit} ${ing.name}: ${fromName} → ${toName}`);
      setQty('');
      setNote('');
      onDone();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Chuyển kho thất bại');
    } finally {
      setBusy(false);
    }
  };

  if (warehouses.length < 2) {
    return <div className="card">Cần ít nhất 2 kho đang dùng mới chuyển kho được. Chủ quán tạo thêm kho ở tab "Kho".</div>;
  }

  return (
    <div className="sb-section">
      <div className="field">
        <label>Nguyên liệu</label>
        <select className="input" value={ingId} onChange={(e) => setIngId(e.target.value)}>
          <option value="">— Chọn nguyên liệu —</option>
          {items
            .filter((i) => i.active)
            .map((i) => (
              <option key={i.id} value={i.id}>
                {i.name} ({formatQty(i.stock)} {i.unit})
              </option>
            ))}
        </select>
      </div>
      <div className="row" style={{ gap: 8 }}>
        <div className="field grow">
          <label>Từ kho</label>
          <select className="input" value={from} onChange={(e) => setFrom(e.target.value)}>
            {warehouses.map((w) => (
              <option key={w.id} value={w.id}>
                {w.name}
              </option>
            ))}
          </select>
        </div>
        <div className="field grow">
          <label>Đến kho</label>
          <select className="input" value={to} onChange={(e) => setTo(e.target.value)}>
            {warehouses.map((w) => (
              <option key={w.id} value={w.id}>
                {w.name}
              </option>
            ))}
          </select>
        </div>
      </div>
      <div className="field">
        <label>Số lượng{ing ? ` (${ing.unit})` : ''}</label>
        <input
          className="sb-money-input"
          inputMode="decimal"
          placeholder="0"
          value={qty}
          onChange={(e) => setQty(e.target.value)}
        />
      </div>
      <div className="field">
        <label>Ghi chú (không bắt buộc)</label>
        <input
          className="input"
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="VD: bổ sung kho quầy…"
        />
      </div>
      <button className="btn btn-block btn-lg" disabled={busy} onClick={submit}>
        {busy ? 'Đang chuyển…' : 'Chuyển kho'}
      </button>
    </div>
  );
}

function WarehouseManager({ onChanged }: { onChanged: () => void }) {
  const toast = useToast();
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [busy, setBusy] = useState(true);
  const [editing, setEditing] = useState<Warehouse | 'new' | null>(null);

  const load = useCallback(async () => {
    setBusy(true);
    try {
      setWarehouses(await listWarehouses(false));
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tải được danh sách kho');
    } finally {
      setBusy(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const setDefault = async (w: Warehouse) => {
    try {
      await setDefaultWarehouse(w.id);
      toast.show(`"${w.name}" là kho bán hàng mặc định`);
      await load();
      onChanged();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Thao tác thất bại');
    }
  };

  const toggleActive = async (w: Warehouse) => {
    if (!w.active) {
      // bật lại
      try {
        await updateWarehouse(w.id, { active: true });
        await load();
        onChanged();
      } catch (e) {
        toast.show(e instanceof DbError ? e.message : 'Thao tác thất bại');
      }
      return;
    }
    const actives = warehouses.filter((x) => x.active);
    if (actives.length <= 1) {
      toast.show('Phải giữ ít nhất 1 kho đang dùng');
      return;
    }
    if (w.is_default) {
      toast.show('Kho mặc định không ẩn được — hãy đặt kho khác làm mặc định trước');
      return;
    }
    try {
      await updateWarehouse(w.id, { active: false });
      toast.show(`Đã ẩn kho "${w.name}"`);
      await load();
      onChanged();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Thao tác thất bại');
    }
  };

  if (busy) return <div className="card">Đang tải…</div>;

  return (
    <>
      <div className="row only-desktop" style={{ marginBottom: 12 }}>
        <button className="btn" onClick={() => setEditing('new')}>
          ＋ Thêm kho
        </button>
      </div>
      {warehouses.map((w) => (
        <div className="sb-section" key={w.id} style={{ marginBottom: 10, opacity: w.active ? 1 : 0.55 }}>
          <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <div style={{ fontWeight: 600, fontSize: 16 }}>
                🗃️ {w.name}
                {w.is_default && (
                  <span className="sb-status-pill" style={{ marginLeft: 6, fontSize: 11 }}>Mặc định ★</span>
                )}
                {!w.active && (
                  <span className="sb-status-pill" style={{ marginLeft: 6, fontSize: 11 }}>Đang ẩn</span>
                )}
              </div>
              {w.note && <div className="small muted">{w.note}</div>}
            </div>
          </div>
          <div className="row" style={{ gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
            {!w.is_default && w.active && (
              <button className="btn btn-outline grow" onClick={() => void setDefault(w)}>
                Đặt làm mặc định
              </button>
            )}
            <button className="btn btn-ghost grow" onClick={() => setEditing(w)}>
              Sửa
            </button>
            <button className="btn btn-ghost grow" onClick={() => void toggleActive(w)}>
              {w.active ? 'Ẩn' : 'Hiện'}
            </button>
          </div>
        </div>
      ))}
      <button className="fab" onClick={() => setEditing('new')} aria-label="Thêm kho">
        +
      </button>
      {editing && (
        <WarehouseForm
          warehouse={editing === 'new' ? null : editing}
          onClose={() => setEditing(null)}
          onDone={() => {
            setEditing(null);
            void load();
            onChanged();
          }}
        />
      )}
    </>
  );
}

function WarehouseForm({
  warehouse,
  onClose,
  onDone,
}: {
  warehouse: Warehouse | null;
  onClose: () => void;
  onDone: () => void;
}) {
  const toast = useToast();
  const [name, setName] = useState(warehouse?.name ?? '');
  const [note, setNote] = useState(warehouse?.note ?? '');
  const [busy, setBusy] = useState(false);

  const save = async () => {
    if (!name.trim()) {
      toast.show('Nhập tên kho');
      return;
    }
    setBusy(true);
    try {
      if (warehouse) {
        await updateWarehouse(warehouse.id, { name: name.trim(), note: note.trim() || null });
        toast.show('Đã cập nhật kho');
      } else {
        await createWarehouse(name.trim(), note.trim() || null);
        toast.show(`Đã thêm kho "${name.trim()}"`);
      }
      onDone();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet
      title={warehouse ? 'Sửa kho' : 'Thêm kho'}
      onClose={onClose}
      footer={
        <button className="btn btn-block btn-lg" disabled={busy} onClick={save}>
          {busy ? 'Đang lưu…' : 'Lưu'}
        </button>
      }
    >
      <div className="field">
        <label>Tên kho *</label>
        <input
          className="input"
          value={name}
          onChange={(e) => setName(e.target.value)}
          maxLength={60}
          placeholder="VD: Kho quầy, Kho tổng…"
          autoFocus={!warehouse}
        />
      </div>
      <div className="field">
        <label>Ghi chú (không bắt buộc)</label>
        <input
          className="input"
          value={note}
          onChange={(e) => setNote(e.target.value)}
          maxLength={500}
          placeholder="VD: kho ở quầy pha chế…"
        />
      </div>
    </Sheet>
  );
}
