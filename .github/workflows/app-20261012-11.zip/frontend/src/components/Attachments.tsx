import { useRef, useState } from 'react';
import { useToast } from './Toast';

const MAX_FILES = 3;
const MAX_SIZE = 800 * 1024; // 800KB mỗi file

/** Đính kèm ảnh chứng từ (tối đa 3 ảnh, mỗi ảnh ≤ 800KB, lưu dạng data URL). */
export function AttachmentsInput({
  value,
  onChange,
}: {
  value: string[];
  onChange: (v: string[]) => void;
}) {
  const toast = useToast();
  const fileRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);

  const onPick = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    if (value.length + files.length > MAX_FILES) {
      toast.show(`Tối đa ${MAX_FILES} ảnh`);
      return;
    }
    setBusy(true);
    try {
      const out: string[] = [];
      for (const f of Array.from(files)) {
        if (!f.type.startsWith('image/')) {
          toast.show('Chỉ nhận file ảnh');
          continue;
        }
        if (f.size > MAX_SIZE) {
          toast.show(`Ảnh "${f.name}" quá lớn (>800KB)`);
          continue;
        }
        const dataUrl = await new Promise<string>((resolve, reject) => {
          const r = new FileReader();
          r.onload = () => resolve(String(r.result));
          r.onerror = reject;
          r.readAsDataURL(f);
        });
        out.push(dataUrl);
      }
      if (out.length > 0) onChange([...value, ...out].slice(0, MAX_FILES));
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  return (
    <div className="field">
      <label>📎 Ảnh chứng từ ({value.length}/{MAX_FILES})</label>
      <div className="row" style={{ gap: 8, flexWrap: 'wrap', marginBottom: 8 }}>
        {value.map((url, i) => (
          <div key={i} style={{ position: 'relative', width: 72, height: 72 }}>
            <img
              src={url}
              alt={`Chứng từ ${i + 1}`}
              style={{ width: 72, height: 72, objectFit: 'cover', borderRadius: 8, border: '1px solid var(--line)' }}
              onClick={() => window.open(url, '_blank')}
            />
            <button
              type="button"
              onClick={() => onChange(value.filter((_, j) => j !== i))}
              style={{
                position: 'absolute', top: -8, right: -8, width: 24, height: 24,
                borderRadius: '50%', background: 'var(--red)', color: '#fff',
                border: 'none', fontSize: 14, lineHeight: 1, cursor: 'pointer',
              }}
              aria-label="Xóa ảnh"
            >
              ×
            </button>
          </div>
        ))}
        {value.length < MAX_FILES && (
          <button
            type="button"
            className="btn btn-outline"
            style={{ width: 72, height: 72, minHeight: 72, padding: 0, fontSize: 24 }}
            disabled={busy}
            onClick={() => fileRef.current?.click()}
            aria-label="Thêm ảnh chứng từ"
          >
            {busy ? '…' : '+'}
          </button>
        )}
      </div>
      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        multiple
        style={{ display: 'none' }}
        onChange={(e) => void onPick(e.target.files)}
      />
    </div>
  );
}

/** Hiển thị ảnh đính kèm (xem). */
export function AttachmentsView({ value }: { value?: string[] | null }) {
  if (!value || value.length === 0) return null;
  return (
    <div className="row" style={{ gap: 8, flexWrap: 'wrap', marginTop: 8 }}>
      {value.map((url, i) => (
        <img
          key={i}
          src={url}
          alt={`Chứng từ ${i + 1}`}
          style={{ width: 64, height: 64, objectFit: 'cover', borderRadius: 8, border: '1px solid var(--line)', cursor: 'pointer' }}
          onClick={() => window.open(url, '_blank')}
        />
      ))}
    </div>
  );
}
