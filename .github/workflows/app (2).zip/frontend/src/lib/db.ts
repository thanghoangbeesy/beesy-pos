// Lớp dữ liệu Firestore cho Beesy POS (gói miễn phí Spark — không dùng Cloud Functions).
// Mọi tính toán giá/tích tem thực hiện client-side, mirror logic backend self-hosted
// (backend/src/routes/orders.js + lib/pricing.js), với validation thêm ở firestore.rules.
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  writeBatch,
  query,
  where,
  orderBy,
  limit,
  runTransaction,
  serverTimestamp,
  Timestamp,
  FirestoreError,
  type DocumentSnapshot,
  type QueryDocumentSnapshot,
} from 'firebase/firestore';
import { auth, db } from './firebase';
import { todayVN, unsignVietnamese, uuid } from './format';
import type {
  CashbookEntry,
  CashbookType,
  Category,
  Customer,
  DailyReport,
  DebtLog,
  FundRefType,
  FundSettings,
  ModifierGroup,
  ModifierOption,
  Order,
  OrderItem,
  OrderStatus,
  PaymentMethod,
  PaymentMethodDef,
  PaymentMethodKind,
  Product,
  SelectedModifier,
} from './types';

// ---------------------------------------------------------------- DbError ---
export class DbError extends Error {
  code: string;
  constructor(code: string, message: string) {
    super(message);
    this.name = 'DbError';
    this.code = code;
  }
}

const FIRESTORE_CODE_MAP: Record<string, string> = {
  'deadline-exceeded': 'unavailable',
  unavailable: 'unavailable',
  'permission-denied': 'permission-denied',
  'not-found': 'not-found',
  'invalid-argument': 'invalid-argument',
};

export function toDbError(e: unknown): DbError {
  if (e instanceof DbError) return e;
  if (e instanceof FirestoreError) {
    const code = FIRESTORE_CODE_MAP[e.code] ?? 'unknown';
    const message =
      code === 'unavailable'
        ? 'Mất kết nối mạng. Vui lòng kiểm tra internet rồi thử lại.'
        : code === 'permission-denied'
          ? 'Bạn không có quyền thực hiện thao tác này.'
          : e.message;
    return new DbError(code, message);
  }
  return new DbError('unknown', e instanceof Error ? e.message : 'Lỗi không xác định.');
}

// ------------------------------------------------------------- converters ---
function tsToIso(v: unknown): string {
  if (v instanceof Timestamp) return v.toDate().toISOString();
  if (typeof v === 'string' && v) return v;
  return new Date().toISOString();
}

function activeOf(d: Record<string, unknown>): boolean {
  return d.active !== false;
}

function toCategory(id: string, d: Record<string, unknown>): Category {
  return {
    id,
    name: String(d.name ?? ''),
    sort_order: Number(d.sort_order ?? 0),
    active: activeOf(d),
  };
}

function toProduct(id: string, d: Record<string, unknown>): Product {
  return {
    id,
    name: String(d.name ?? ''),
    category_id: (d.category_id as string | null) ?? null,
    base_price: Number(d.base_price ?? 0),
    image_url: (d.image_url as string | null) ?? null,
    active: activeOf(d),
    sort_order: Number(d.sort_order ?? 0),
  };
}

function toModifierOption(id: string, d: Record<string, unknown>): ModifierOption {
  return {
    id,
    group_id: String(d.group_id ?? ''),
    name: String(d.name ?? ''),
    price_delta: Number(d.price_delta ?? 0),
    sort_order: Number(d.sort_order ?? 0),
    active: activeOf(d),
  };
}

function toModifierGroup(
  id: string,
  d: Record<string, unknown>,
  options: ModifierOption[],
): ModifierGroup {
  return {
    id,
    name: String(d.name ?? ''),
    selection_type: d.selection_type === 'multi' ? 'multi' : 'single',
    required: d.required === true,
    sort_order: Number(d.sort_order ?? 0),
    active: activeOf(d),
    options,
  };
}

function toCustomer(id: string, d: Record<string, unknown>): Customer {
  return {
    id,
    name: String(d.name ?? ''),
    phone: String(d.phone ?? ''),
    birthday: (d.birthday as string | null) ?? null,
    address: (d.address as string | null) ?? null,
    stamps: Number(d.stamps ?? 0),
    reward_available: d.reward_available === true,
    debt: Number(d.debt ?? 0),
    note: (d.note as string | null) ?? null,
    created_at: tsToIso(d.created_at),
  };
}

function toPaymentMethod(id: string, d: Record<string, unknown>): PaymentMethodDef {
  const kind = d.kind as string;
  return {
    id,
    name: String(d.name ?? ''),
    kind: kind === 'transfer' || kind === 'debt' ? kind : 'cash',
    icon: String(d.icon ?? ''),
    bank_bin: (d.bank_bin as string | null) ?? null,
    bank_account: (d.bank_account as string | null) ?? null,
    bank_account_name: (d.bank_account_name as string | null) ?? null,
    active: activeOf(d),
    sort_order: Number(d.sort_order ?? 0),
  };
}

function toDebtLog(id: string, d: Record<string, unknown>): DebtLog {
  return {
    id,
    amount: Number(d.amount ?? 0),
    balance_after: Number(d.balance_after ?? 0),
    note: (d.note as string | null) ?? null,
    created_by: (d.created_by as string | null) ?? null,
    created_at: tsToIso(d.created_at),
  };
}

// Convert 1 document orders → Order (dùng chung cho db.ts và realtime.ts)
export function orderFromDoc(
  snap: DocumentSnapshot | QueryDocumentSnapshot,
): Order | null {
  if (!snap.exists()) return null;
  const d = snap.data() as Record<string, unknown>;
  const rawItems = Array.isArray(d.items) ? d.items : [];
  const items: OrderItem[] = rawItems.map((it: Record<string, unknown>, i: number) => ({
    id: String(it.id ?? `${snap.id}-item-${i}`),
    order_id: String(it.order_id ?? snap.id),
    product_id: String(it.product_id ?? ''),
    product_name: String(it.product_name ?? ''),
    qty: Number(it.qty ?? 0),
    unit_price: Number(it.unit_price ?? 0),
    modifiers: (Array.isArray(it.modifiers) ? it.modifiers : []).map(
      (m: Record<string, unknown>): SelectedModifier => ({
        option_id: String(m.option_id ?? ''),
        group: String(m.group ?? ''),
        option: String(m.option ?? ''),
        price_delta: Number(m.price_delta ?? 0),
      }),
    ),
    line_total: Number(it.line_total ?? 0),
    ...(typeof it.note === 'string' && it.note ? { note: it.note } : {}),
  }));
  return {
    id: snap.id,
    client_uuid: String(d.client_uuid ?? snap.id),
    code: String(d.code ?? ''),
    business_date: String(d.business_date ?? ''),
    customer_id: (d.customer_id as string | null) ?? null,
    status: d.status as OrderStatus,
    payment_method: String(d.payment_method ?? ''),
    payment_method_name: (d.payment_method_name as string | null) ?? null,
    subtotal: Number(d.subtotal ?? 0),
    discount: Number(d.discount ?? 0),
    total: Number(d.total ?? 0),
    amount_received: d.amount_received == null ? null : Number(d.amount_received),
    change_amount: d.change_amount == null ? null : Number(d.change_amount),
    note: (d.note as string | null) ?? null,
    created_by: (d.created_by as string | null) ?? null,
    created_at: tsToIso(d.created_at),
    items,
  };
}

// Giờ VN (0-23) từ chuỗi ISO — mirror backend lib/dates.js#vnHour
function vnHour(iso: string): number {
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Asia/Ho_Chi_Minh',
    hour: 'numeric',
    hourCycle: 'h23',
  }).formatToParts(new Date(iso));
  return Number(parts.find((p) => p.type === 'hour')?.value ?? 0);
}

// ------------------------------------------------------------- categories ---
export async function listCategories(): Promise<Category[]> {
  try {
    const snap = await getDocs(query(collection(db, 'categories'), orderBy('sort_order', 'asc')));
    return snap.docs.map((d) => toCategory(d.id, d.data()));
  } catch (e) {
    throw toDbError(e);
  }
}

export async function createCategory(name: string): Promise<Category> {
  const trimmed = String(name ?? '').trim();
  if (!trimmed) throw new DbError('invalid-argument', 'Vui lòng nhập tên danh mục.');
  try {
    const existing = await listCategories();
    const maxSort = existing.reduce((m, c) => Math.max(m, c.sort_order), 0);
    const id = uuid();
    const data = { id, name: trimmed, sort_order: maxSort + 1, active: true };
    await setDoc(doc(db, 'categories', id), data);
    return toCategory(id, data);
  } catch (e) {
    throw toDbError(e);
  }
}

export async function updateCategory(
  id: string,
  patch: { name?: string; active?: boolean; sort_order?: number },
): Promise<void> {
  const data: Record<string, unknown> = {};
  if (patch.name !== undefined) {
    const trimmed = String(patch.name).trim();
    if (!trimmed) throw new DbError('invalid-argument', 'Tên danh mục không được để trống.');
    data.name = trimmed;
  }
  if (patch.active !== undefined) data.active = patch.active;
  if (patch.sort_order !== undefined) data.sort_order = patch.sort_order;
  if (Object.keys(data).length === 0) return;
  try {
    await updateDoc(doc(db, 'categories', id), data);
  } catch (e) {
    throw toDbError(e);
  }
}

// Xóa danh mục. Các món đang thuộc danh mục này được chuyển sang "chưa phân loại"
// (giữ lại món để vẫn bán được). Trả về số món đã chuyển.
export async function deleteCategory(id: string): Promise<{ moved: number }> {
  try {
    const products = await listProducts();
    const affected = products.filter((p) => p.category_id === id);
    const batch = writeBatch(db);
    for (const p of affected) {
      batch.update(doc(db, 'products', p.id), { category_id: null });
    }
    batch.delete(doc(db, 'categories', id));
    await batch.commit();
    return { moved: affected.length };
  } catch (e) {
    throw toDbError(e);
  }
}

// -------------------------------------------------------------- products ---
export async function listProducts(): Promise<Product[]> {
  try {
    const snap = await getDocs(query(collection(db, 'products'), orderBy('sort_order', 'asc')));
    return snap.docs.map((d) => toProduct(d.id, d.data()));
  } catch (e) {
    throw toDbError(e);
  }
}

export async function createProduct(d: {
  name: string;
  base_price: number;
  category_id: string | null;
}): Promise<Product> {
  const name = String(d.name ?? '').trim();
  if (!name) throw new DbError('invalid-argument', 'Vui lòng nhập tên món.');
  const price = Math.round(Number(d.base_price));
  if (!Number.isFinite(price) || price <= 0) {
    throw new DbError('invalid-argument', 'Giá bán phải là số dương.');
  }
  try {
    if (d.category_id) {
      const cat = await getDoc(doc(db, 'categories', d.category_id));
      if (!cat.exists()) throw new DbError('invalid-argument', 'Danh mục không tồn tại.');
    }
    const existing = await listProducts();
    const maxSort = existing.reduce((m, p) => Math.max(m, p.sort_order), 0);
    const id = uuid();
    const data = {
      id,
      name,
      category_id: d.category_id ?? null,
      base_price: price,
      image_url: null,
      active: true,
      sort_order: maxSort + 1,
    };
    await setDoc(doc(db, 'products', id), data);
    return toProduct(id, data);
  } catch (e) {
    throw toDbError(e);
  }
}

export async function updateProduct(
  id: string,
  patch: Partial<Pick<Product, 'name' | 'base_price' | 'category_id' | 'active' | 'sort_order' | 'image_url'>>,
): Promise<void> {
  const data: Record<string, unknown> = {};
  if (patch.name !== undefined) {
    const trimmed = String(patch.name).trim();
    if (!trimmed) throw new DbError('invalid-argument', 'Tên món không được để trống.');
    data.name = trimmed;
  }
  if (patch.base_price !== undefined) {
    const price = Math.round(Number(patch.base_price));
    if (!Number.isFinite(price) || price <= 0) {
      throw new DbError('invalid-argument', 'Giá bán phải là số dương.');
    }
    data.base_price = price;
  }
  if (patch.category_id !== undefined) {
    if (patch.category_id) {
      try {
        const cat = await getDoc(doc(db, 'categories', patch.category_id));
        if (!cat.exists()) throw new DbError('invalid-argument', 'Danh mục không tồn tại.');
      } catch (e) {
        throw toDbError(e);
      }
    }
    data.category_id = patch.category_id;
  }
  if (patch.active !== undefined) data.active = patch.active;
  if (patch.sort_order !== undefined) data.sort_order = patch.sort_order;
  if (patch.image_url !== undefined) data.image_url = patch.image_url;
  if (Object.keys(data).length === 0) return;
  try {
    await updateDoc(doc(db, 'products', id), data);
  } catch (e) {
    throw toDbError(e);
  }
}

// Xóa hẳn một món khỏi menu. Đơn hàng cũ không bị ảnh hưởng vì đã lưu tên/giá riêng.
export async function deleteProduct(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'products', id));
  } catch (e) {
    throw toDbError(e);
  }
}

// Thêm nhiều món cùng lúc (từ màn hình "Thêm hàng loạt").
// Mỗi phần tử: { name, base_price, category_id }. Bỏ qua các dòng lỗi, trả về số món đã thêm.
export async function createProductsBulk(
  items: { name: string; base_price: number; category_id: string | null }[],
): Promise<{ added: number }> {
  const valid = items.filter(
    (it) =>
      String(it.name ?? '').trim() &&
      Number.isFinite(Math.round(Number(it.base_price))) &&
      Math.round(Number(it.base_price)) > 0,
  );
  if (valid.length === 0) throw new DbError('invalid-argument', 'Không có món hợp lệ để thêm.');
  try {
    const existing = await listProducts();
    let sort = existing.reduce((m, p) => Math.max(m, p.sort_order), 0);
    const batch = writeBatch(db);
    for (const it of valid) {
      const id = uuid();
      sort += 1;
      batch.set(doc(db, 'products', id), {
        id,
        name: String(it.name).trim(),
        category_id: it.category_id ?? null,
        base_price: Math.round(Number(it.base_price)),
        image_url: null,
        active: true,
        sort_order: sort,
      });
    }
    await batch.commit();
    return { added: valid.length };
  } catch (e) {
    throw toDbError(e);
  }
}

// -------------------------------------------------------- modifier groups ---
export async function listModifierGroups(): Promise<ModifierGroup[]> {
  try {
    const [gSnap, oSnap] = await Promise.all([
      getDocs(query(collection(db, 'modifierGroups'), orderBy('sort_order', 'asc'))),
      getDocs(query(collection(db, 'modifierOptions'), orderBy('sort_order', 'asc'))),
    ]);
    const byGroup = new Map<string, ModifierOption[]>();
    for (const d of oSnap.docs) {
      const opt = toModifierOption(d.id, d.data());
      const arr = byGroup.get(opt.group_id) ?? [];
      arr.push(opt);
      byGroup.set(opt.group_id, arr);
    }
    return gSnap.docs.map((d) => toModifierGroup(d.id, d.data(), byGroup.get(d.id) ?? []));
  } catch (e) {
    throw toDbError(e);
  }
}

export async function createModifierOption(
  groupId: string,
  d: { name: string; price_delta: number },
): Promise<ModifierOption> {
  const name = String(d.name ?? '').trim();
  if (!name) throw new DbError('invalid-argument', 'Vui lòng nhập tên tùy chọn.');
  const delta = Math.round(Number(d.price_delta));
  if (!Number.isFinite(delta) || delta < 0) {
    throw new DbError('invalid-argument', 'Phụ thu phải là số không âm.');
  }
  try {
    const groupSnap = await getDoc(doc(db, 'modifierGroups', groupId));
    if (!groupSnap.exists()) throw new DbError('not-found', 'Nhóm tùy chọn không tồn tại.');
    const oSnap = await getDocs(
      query(collection(db, 'modifierOptions'), where('group_id', '==', groupId)),
    );
    const maxSort = oSnap.docs.reduce(
      (m, x) => Math.max(m, Number(x.data().sort_order ?? 0)),
      0,
    );
    const id = uuid();
    const data = {
      id,
      group_id: groupId,
      name,
      price_delta: delta,
      sort_order: maxSort + 1,
      active: true,
    };
    await setDoc(doc(db, 'modifierOptions', id), data);
    return toModifierOption(id, data);
  } catch (e) {
    throw toDbError(e);
  }
}

export async function updateModifierOption(
  id: string,
  patch: { name?: string; price_delta?: number; active?: boolean },
): Promise<void> {
  const data: Record<string, unknown> = {};
  if (patch.name !== undefined) {
    const trimmed = String(patch.name).trim();
    if (!trimmed) throw new DbError('invalid-argument', 'Tên tùy chọn không được để trống.');
    data.name = trimmed;
  }
  if (patch.price_delta !== undefined) {
    const delta = Math.round(Number(patch.price_delta));
    if (!Number.isFinite(delta) || delta < 0) {
      throw new DbError('invalid-argument', 'Phụ thu phải là số không âm.');
    }
    data.price_delta = delta;
  }
  if (patch.active !== undefined) data.active = patch.active;
  if (Object.keys(data).length === 0) return;
  try {
    await updateDoc(doc(db, 'modifierOptions', id), data);
  } catch (e) {
    throw toDbError(e);
  }
}

// Xóa hẳn một lựa chọn (VD: topping). Đơn hàng cũ không bị ảnh hưởng vì đã lưu tên/giá riêng.
export async function deleteModifierOption(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'modifierOptions', id));
  } catch (e) {
    throw toDbError(e);
  }
}

// -------------------------------------------------------- payment methods ---
const SYSTEM_METHOD_IDS = ['cash', 'transfer', 'debt'];

const KIND_LABEL: Record<PaymentMethodKind, string> = {
  cash: 'Tiền mặt',
  transfer: 'Chuyển khoản',
  debt: 'Ghi nợ',
};

export function paymentKindLabel(kind: PaymentMethodKind): string {
  return KIND_LABEL[kind] ?? kind;
}

// Tạo 3 phương thức mặc định nếu collection còn trống.
// Đồng thời chuyển cấu hình ngân hàng cũ (settings bank_*) sang phương thức chuyển khoản.
export async function ensurePaymentMethodsSeeded(): Promise<void> {
  try {
    const snap = await getDocs(query(collection(db, 'payment_methods'), limit(1)));
    if (!snap.empty) return;
    const settings = await getSettings();
    const batch = writeBatch(db);
    const defaults: Array<Omit<PaymentMethodDef, 'active'>> = [
      {
        id: 'cash', name: 'Tiền mặt', kind: 'cash', icon: '💵',
        bank_bin: null, bank_account: null, bank_account_name: null, sort_order: 1,
      },
      {
        id: 'transfer', name: 'Chuyển khoản', kind: 'transfer', icon: '📱',
        bank_bin: settings.bank_bin || null,
        bank_account: settings.bank_account || null,
        bank_account_name: settings.bank_account_name || null,
        sort_order: 2,
      },
      {
        id: 'debt', name: 'Ghi nợ', kind: 'debt', icon: '📒',
        bank_bin: null, bank_account: null, bank_account_name: null, sort_order: 3,
      },
    ];
    for (const m of defaults) {
      batch.set(doc(db, 'payment_methods', m.id), { ...m, active: true });
    }
    await batch.commit();
  } catch (e) {
    throw toDbError(e);
  }
}

export async function listPaymentMethods(activeOnly = true): Promise<PaymentMethodDef[]> {
  try {
    await ensurePaymentMethodsSeeded();
    const snap = await getDocs(collection(db, 'payment_methods'));
    const all = snap.docs.map((d) => toPaymentMethod(d.id, d.data()));
    const filtered = activeOnly ? all.filter((m) => m.active) : all;
    filtered.sort((a, b) => a.sort_order - b.sort_order || a.name.localeCompare(b.name, 'vi'));
    return filtered;
  } catch (e) {
    throw toDbError(e);
  }
}

export async function createPaymentMethod(d: {
  name: string;
  kind: PaymentMethodKind;
  icon?: string;
  bank_bin?: string | null;
  bank_account?: string | null;
  bank_account_name?: string | null;
}): Promise<PaymentMethodDef> {
  const name = String(d.name ?? '').trim();
  if (!name) throw new DbError('invalid-argument', 'Vui lòng nhập tên phương thức.');
  if (d.kind !== 'cash' && d.kind !== 'transfer' && d.kind !== 'debt') {
    throw new DbError('invalid-argument', 'Loại phương thức không hợp lệ.');
  }
  try {
    const snap = await getDocs(collection(db, 'payment_methods'));
    const sort_order = snap.docs.reduce((mx, x) => Math.max(mx, Number(x.data().sort_order ?? 0)), 0) + 1;
    const id = uuid();
    const data = {
      id,
      name,
      kind: d.kind,
      icon: String(d.icon ?? '').trim() || '💳',
      bank_bin: d.bank_bin?.trim() || null,
      bank_account: d.bank_account?.trim() || null,
      bank_account_name: d.bank_account_name?.trim() || null,
      active: true,
      sort_order,
    };
    await setDoc(doc(db, 'payment_methods', id), data);
    return { ...data };
  } catch (e) {
    throw toDbError(e);
  }
}

export async function updatePaymentMethod(
  id: string,
  patch: Partial<Pick<PaymentMethodDef, 'name' | 'kind' | 'icon' | 'bank_bin' | 'bank_account' | 'bank_account_name' | 'active' | 'sort_order'>>,
): Promise<void> {
  const data: Record<string, unknown> = {};
  if (patch.name !== undefined) {
    const name = String(patch.name).trim();
    if (!name) throw new DbError('invalid-argument', 'Tên phương thức không được để trống.');
    data.name = name;
  }
  if (patch.kind !== undefined) {
    if (patch.kind !== 'cash' && patch.kind !== 'transfer' && patch.kind !== 'debt') {
      throw new DbError('invalid-argument', 'Loại phương thức không hợp lệ.');
    }
    data.kind = patch.kind;
  }
  if (patch.icon !== undefined) data.icon = String(patch.icon).trim() || '💳';
  if (patch.bank_bin !== undefined) data.bank_bin = patch.bank_bin?.trim() || null;
  if (patch.bank_account !== undefined) data.bank_account = patch.bank_account?.trim() || null;
  if (patch.bank_account_name !== undefined) data.bank_account_name = patch.bank_account_name?.trim() || null;
  if (patch.active !== undefined) data.active = patch.active === true;
  if (patch.sort_order !== undefined) data.sort_order = Number(patch.sort_order) || 0;
  if (Object.keys(data).length === 0) return;
  try {
    await updateDoc(doc(db, 'payment_methods', id), data);
  } catch (e) {
    throw toDbError(e);
  }
}

// Phương thức hệ thống (cash/transfer/debt) chỉ được ẩn, không được xóa hẳn.
export async function deletePaymentMethod(id: string): Promise<void> {
  if (SYSTEM_METHOD_IDS.includes(id)) {
    throw new DbError('invalid-argument', 'Phương thức mặc định chỉ có thể Ẩn, không xóa được.');
  }
  try {
    await deleteDoc(doc(db, 'payment_methods', id));
  } catch (e) {
    throw toDbError(e);
  }
}

export function isSystemPaymentMethod(id: string): boolean {
  return SYSTEM_METHOD_IDS.includes(id);
}

// ------------------------------------------------------------------ orders ---
export interface CreateOrderItemInput {
  productId: string;
  qty: number;
  modifierOptionIds: string[];
  note?: string;
}

export interface CreateOrderInput {
  clientUuid: string;
  customerId: string | null;
  items: CreateOrderItemInput[];
  paymentMethod: PaymentMethod;
  amountReceived?: number | null;
  note?: string | null;
}

interface CatalogMaps {
  products: Map<string, Record<string, unknown>>;
  groups: Map<string, Record<string, unknown>>;
  options: Map<string, Record<string, unknown>>;
}

async function loadCatalog(): Promise<CatalogMaps> {
  const [pSnap, gSnap, oSnap] = await Promise.all([
    getDocs(collection(db, 'products')),
    getDocs(collection(db, 'modifierGroups')),
    getDocs(collection(db, 'modifierOptions')),
  ]);
  return {
    products: new Map(pSnap.docs.map((d) => [d.id, d.data()])),
    groups: new Map(gSnap.docs.map((d) => [d.id, d.data()])),
    options: new Map(oSnap.docs.map((d) => [d.id, d.data()])),
  };
}

// Tính giá client-side — mirror backend lib/pricing.js#calculateOrderPricing.
// Snapshot mỗi dòng gồm option_id (theo schema orders.items của bản Firebase).
function priceOrderLines(items: CreateOrderItemInput[], catalog: CatalogMaps) {
  const lines = items.map((item, idx) => {
    const n = idx + 1;
    const product = catalog.products.get(item.productId);
    if (!product) throw new DbError('invalid-argument', `Món thứ ${n}: sản phẩm không tồn tại.`);
    if (product.active === false) {
      throw new DbError('invalid-argument', `Món thứ ${n}: "${String(product.name)}" hiện không bán.`);
    }
    const qty = Number(item.qty);
    if (!Number.isInteger(qty) || qty < 1 || qty > 99) {
      throw new DbError('invalid-argument', `Món thứ ${n}: số lượng phải là số nguyên từ 1 đến 99.`);
    }
    const optionIds = Array.isArray(item.modifierOptionIds) ? item.modifierOptionIds : [];
    const byGroup = new Map<string, { group: Record<string, unknown>; opts: Record<string, unknown>[] }>();
    for (const optId of optionIds) {
      const opt = catalog.options.get(optId) as (Record<string, unknown> & { id?: string }) | undefined;
      if (!opt) throw new DbError('invalid-argument', `Món thứ ${n}: tùy chọn không tồn tại.`);
      if (opt.active === false) {
        throw new DbError('invalid-argument', `Món thứ ${n}: tùy chọn "${String(opt.name)}" đã ngừng dùng.`);
      }
      const group = catalog.groups.get(String(opt.group_id));
      if (!group) throw new DbError('invalid-argument', `Món thứ ${n}: nhóm tùy chọn không tồn tại.`);
      if (group.active === false) {
        throw new DbError('invalid-argument', `Món thứ ${n}: nhóm "${String(group.name)}" đã ngừng dùng.`);
      }
      const gid = String(opt.group_id);
      const entry = byGroup.get(gid) ?? { group, opts: [] };
      entry.opts.push({ ...opt, id: optId });
      byGroup.set(gid, entry);
    }
    const modifiers: SelectedModifier[] = [];
    for (const { group, opts } of byGroup.values()) {
      if (group.selection_type === 'single' && opts.length > 1) {
        throw new DbError(
          'invalid-argument',
          `Món thứ ${n}: nhóm "${String(group.name)}" chỉ được chọn 1 tùy chọn.`,
        );
      }
      for (const opt of opts) {
        modifiers.push({
          option_id: String(opt.id ?? ''),
          group: String(group.name),
          option: String(opt.name),
          price_delta: Number(opt.price_delta) || 0,
        });
      }
    }
    // Nhóm bắt buộc (VD: Size) phải được chọn — riêng group Size phải chọn đúng 1 option
    for (const [gid, group] of catalog.groups) {
      if (group.required === true && group.active !== false && !byGroup.has(gid)) {
        throw new DbError('invalid-argument', `Món thứ ${n}: Vui lòng chọn ${String(group.name)}.`);
      }
    }
    const unit_price =
      Number(product.base_price) + modifiers.reduce((s, m) => s + m.price_delta, 0);
    const line_total = unit_price * qty;
    return {
      id: uuid(),
      product_id: String(product.id ?? item.productId),
      product_name: String(product.name),
      qty,
      unit_price,
      modifiers,
      line_total,
      note: typeof item.note === 'string' && item.note ? item.note.slice(0, 500) : undefined,
    };
  });
  const subtotal = lines.reduce((s, l) => s + l.line_total, 0);
  return { lines, subtotal, discount: 0, total: subtotal };
}

// Kiểm tra tiền mặt — mirror backend lib/pricing.js#calculateChange
function checkCash(kind: PaymentMethodKind, total: number, amountReceived?: number | null) {
  if (kind === 'cash') {
    const got = Number(amountReceived);
    if (!Number.isInteger(got) || got <= 0) {
      throw new DbError('invalid-argument', 'Tiền mặt: vui lòng nhập số tiền khách đưa.');
    }
    if (got < total) {
      throw new DbError(
        'invalid-argument',
        `Tiền khách đưa (${got}) nhỏ hơn tổng tiền (${total}).`,
      );
    }
    return { amount_received: got, change_amount: got - total };
  }
  return { amount_received: null, change_amount: null };
}

export async function createOrder(input: CreateOrderInput): Promise<Order> {
  const clientUuid = String(input.clientUuid ?? '').trim();
  if (!clientUuid) throw new DbError('invalid-argument', 'Thiếu clientUuid (mã chống trùng đơn).');
  if (clientUuid.length > 100) throw new DbError('invalid-argument', 'clientUuid quá dài.');
  if (!Array.isArray(input.items) || input.items.length === 0) {
    throw new DbError('invalid-argument', 'Đơn hàng phải có ít nhất một món.');
  }
  if (input.items.length > 50) {
    throw new DbError('invalid-argument', 'Đơn hàng vượt quá 50 dòng món.');
  }
  const methodId = String(input.paymentMethod ?? '').trim();
  if (!methodId) throw new DbError('invalid-argument', 'Thiếu phương thức thanh toán.');

  try {
    // 1. Idempotent: đơn đã tồn tại → trả về luôn
    const orderRef = doc(db, 'orders', clientUuid);
    const existing = await getDoc(orderRef);
    if (existing.exists()) {
      const o = orderFromDoc(existing);
      if (o) return o;
    }

    // 2. Tính giá client-side từ catalog (không tin giá client gửi) + kiểm tra phương thức
    const [catalog, methods] = await Promise.all([loadCatalog(), listPaymentMethods(true)]);
    const method = methods.find((m) => m.id === methodId);
    if (!method) throw new DbError('invalid-argument', 'Phương thức thanh toán không hợp lệ hoặc đã bị ẩn.');
    const kind = method.kind;
    const pricing = priceOrderLines(input.items, catalog);
    const cash = checkCash(kind, pricing.total, input.amountReceived);
    const business_date = todayVN();
    const createdBy = auth.currentUser?.uid ?? null;
    const note = typeof input.note === 'string' && input.note ? input.note.slice(0, 1000) : null;
    const customerId = input.customerId ?? null;
    if (kind === 'debt' && !customerId) {
      throw new DbError('invalid-argument', 'Ghi nợ cần chọn khách hàng cho đơn này.');
    }

    // 3. Transaction: mã đơn A001 + ghi đơn + tích tem + cộng công nợ
    await runTransaction(db, async (tx) => {
      // Đua idempotency trong transaction: đơn đã có → bỏ qua ghi
      const oSnap = await tx.get(orderRef);
      if (oSnap.exists()) return;

      const counterRef = doc(db, 'counters', business_date);
      const cSnap = await tx.get(counterRef);
      const next = cSnap.exists() ? Number(cSnap.data().last ?? 0) + 1 : 1;
      const code = 'A' + String(next).padStart(3, '0');

      let stampUpdate: { stamps: number; reward_available?: boolean } | null = null;
      let debtAfter = -1;
      if (customerId) {
        const custRef = doc(db, 'customers', customerId);
        const custSnap = await tx.get(custRef);
        if (!custSnap.exists()) throw new DbError('invalid-argument', 'Khách hàng không tồn tại.');
        const setSnap = await tx.get(doc(db, 'settings', 'stamps_target'));
        const target = Number(setSnap.exists() ? setSnap.data().value : 9) || 9;
        const stamps = Number(custSnap.data().stamps ?? 0) + 1;
        stampUpdate = stamps >= target ? { stamps: 0, reward_available: true } : { stamps };
        if (kind === 'debt') debtAfter = Number(custSnap.data().debt ?? 0) + pricing.total;
      }

      if (cSnap.exists()) tx.update(counterRef, { last: next });
      else tx.set(counterRef, { last: 1 });

      tx.set(orderRef, {
        id: clientUuid,
        client_uuid: clientUuid,
        code,
        business_date,
        customer_id: customerId,
        status: 'new',
        payment_method: method.id,
        payment_method_name: method.name,
        subtotal: pricing.subtotal,
        discount: pricing.discount,
        total: pricing.total,
        amount_received: cash.amount_received,
        change_amount: cash.change_amount,
        note,
        created_by: createdBy,
        created_at: serverTimestamp(),
        items: pricing.lines.map((l) => ({
          id: l.id,
          order_id: clientUuid,
          product_id: l.product_id,
          product_name: l.product_name,
          qty: l.qty,
          unit_price: l.unit_price,
          modifiers: l.modifiers,
          line_total: l.line_total,
          ...(l.note ? { note: l.note } : {}),
        })),
      });

      if (customerId) {
        const custUpdate: Record<string, unknown> = {};
        if (stampUpdate) Object.assign(custUpdate, stampUpdate);
        if (debtAfter >= 0) {
          custUpdate.debt = debtAfter;
          const logRef = doc(collection(db, 'customers', customerId, 'debt_logs'));
          tx.set(logRef, {
            id: logRef.id,
            amount: pricing.total,
            balance_after: debtAfter,
            note: `Ghi nợ đơn ${code}`,
            created_by: createdBy,
            created_at: serverTimestamp(),
          });
        }
        if (Object.keys(custUpdate).length > 0) {
          tx.update(doc(db, 'customers', customerId), custUpdate);
        }
      }

      // Sổ quỹ: đơn đã thu tiền (tiền mặt/chuyển khoản) → tự ghi khoản thu "Doanh thu bán hàng".
      // Đơn ghi nợ chưa thu tiền nên KHÔNG ghi. Id doc fund cố định theo đơn để idempotent.
      // Đơn cũ trước tính năng này không backfill.
      if (kind === 'cash' || kind === 'transfer') {
        const fundRef = doc(db, 'cashbook_entries', `fund_${clientUuid}`);
        tx.set(fundRef, {
          id: fundRef.id,
          type: 'thu',
          amount: pricing.total,
          note: 'Doanh thu bán hàng',
          category: 'Bán hàng',
          fund_id: 'cash',
          ref_type: 'order',
          ref_id: clientUuid,
          ref_code: code,
          method: kind,
          created_by: createdBy,
          created_at: serverTimestamp(),
        });
      }
    });

    // 4. Đọc lại → Timestamp → ISO string
    const after = await getDoc(orderRef);
    const order = orderFromDoc(after);
    if (!order) throw new DbError('unknown', 'Không đọc được đơn vừa tạo.');
    return order;
  } catch (e) {
    throw toDbError(e);
  }
}

export async function getOrder(id: string): Promise<Order | null> {
  try {
    return orderFromDoc(await getDoc(doc(db, 'orders', id)));
  } catch (e) {
    throw toDbError(e);
  }
}

export async function listOrdersByDate(date: string, limitN?: number): Promise<Order[]> {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    throw new DbError('invalid-argument', 'Tham số date phải có dạng YYYY-MM-DD.');
  }
  const n = Math.min(Math.max(limitN ?? 100, 1), 500);
  try {
    const snap = await getDocs(
      query(
        collection(db, 'orders'),
        where('business_date', '==', date),
        orderBy('created_at', 'desc'),
        limit(n),
      ),
    );
    return snap.docs
      .map((d) => orderFromDoc(d))
      .filter((o): o is Order => o !== null);
  } catch (e) {
    throw toDbError(e);
  }
}

// new → preparing → ready → done; bất kỳ trạng thái nào (trừ done/cancelled) → cancelled
const ORDER_FLOW: Record<OrderStatus, OrderStatus[]> = {
  new: ['preparing'],
  preparing: ['ready'],
  ready: ['done'],
  done: [],
  cancelled: [],
};

export async function updateOrderStatus(id: string, status: OrderStatus): Promise<Order> {
  const valid: OrderStatus[] = ['new', 'preparing', 'ready', 'done', 'cancelled'];
  if (!valid.includes(status)) {
    throw new DbError('invalid-argument', `Trạng thái "${status}" không hợp lệ.`);
  }
  try {
    const ref = doc(db, 'orders', id);
    const snap = await getDoc(ref);
    const current = orderFromDoc(snap);
    if (!current) throw new DbError('not-found', 'Đơn hàng không tồn tại.');
    const from = current.status;
    if (from !== status) {
      const forwardOk = (ORDER_FLOW[from] ?? []).includes(status);
      const cancelOk = status === 'cancelled' && from !== 'done' && from !== 'cancelled';
      if (!forwardOk && !cancelOk) {
        throw new DbError(
          'invalid-argument',
          `Không thể chuyển đơn từ trạng thái "${from}" sang "${status}".`,
        );
      }
      await updateDoc(ref, { status });
    }
    const after = orderFromDoc(await getDoc(ref));
    if (!after) throw new DbError('not-found', 'Đơn hàng không tồn tại.');
    return after;
  } catch (e) {
    throw toDbError(e);
  }
}

// --------------------------------------------------------------- đơn hàng ---
export interface ListOrdersOpts {
  from: string; // YYYY-MM-DD
  to: string; // YYYY-MM-DD
  limitN?: number;
}

/** Liệt kê đơn theo khoảng ngày (mới nhất trước). Lọc theo mã đơn/khách làm ở client. */
export async function listOrders(opts: ListOrdersOpts): Promise<Order[]> {
  const { from, to } = opts;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(from) || !/^\d{4}-\d{2}-\d{2}$/.test(to)) {
    throw new DbError('invalid-argument', 'Khoảng ngày không hợp lệ.');
  }
  const n = Math.min(Math.max(opts.limitN ?? 300, 1), 1000);
  try {
    const snap = await getDocs(
      query(
        collection(db, 'orders'),
        where('business_date', '>=', from),
        where('business_date', '<=', to),
        orderBy('business_date', 'desc'),
        limit(n),
      ),
    );
    const list = snap.docs
      .map((d) => orderFromDoc(d))
      .filter((o): o is Order => o !== null);
    list.sort((a, b) => (a.created_at < b.created_at ? 1 : -1));
    return list;
  } catch (e) {
    throw toDbError(e);
  }
}

/**
 * Sửa đơn đã bán — CHỈ cho sửa ghi chú + khách hàng (không sửa món/giá để báo cáo không sai).
 * Rules phía server cũng chỉ cho phép 3 field: status, note, customer_id.
 */
export async function updateOrderMeta(
  id: string,
  patch: { note?: string | null; customerId?: string | null },
): Promise<Order> {
  const data: Record<string, unknown> = {};
  if (patch.note !== undefined) {
    const n = typeof patch.note === 'string' ? patch.note.trim() : '';
    data.note = n ? n.slice(0, 1000) : null;
  }
  if (patch.customerId !== undefined) {
    const cid = patch.customerId ? String(patch.customerId) : null;
    if (cid) {
      const cSnap = await getDoc(doc(db, 'customers', cid));
      if (!cSnap.exists()) throw new DbError('not-found', 'Khách hàng không tồn tại.');
    }
    data.customer_id = cid;
  }
  if (Object.keys(data).length === 0) {
    const cur = await getOrder(id);
    if (!cur) throw new DbError('not-found', 'Đơn hàng không tồn tại.');
    return cur;
  }
  try {
    await updateDoc(doc(db, 'orders', id), data);
    const after = await getOrder(id);
    if (!after) throw new DbError('not-found', 'Đơn hàng không tồn tại.');
    return after;
  } catch (e) {
    throw toDbError(e);
  }
}

/**
 * Xóa đơn đã bán — chỉ chủ quán (rules + UI đều chặn nhân viên).
 * - Đơn ghi nợ → hoàn công nợ tương ứng (ghi log "Hoàn nợ do xóa đơn A001").
 * - Xóa luôn khoản quỹ tự động của đơn (cashbook_entries/fund_<orderId>).
 * - Tem tích điểm KHÔNG hoàn (không có đường hoàn sạch khi đã đổi thưởng/reset tem).
 */
export async function deleteOrder(id: string): Promise<void> {
  try {
    await runTransaction(db, async (tx) => {
      const orderRef = doc(db, 'orders', id);
      const oSnap = await tx.get(orderRef);
      const order = oSnap.exists() ? orderFromDoc(oSnap) : null;
      if (!order) throw new DbError('not-found', 'Đơn hàng không tồn tại.');

      // Hoàn công nợ nếu đơn ghi nợ
      const methodSnap = await tx.get(doc(db, 'payment_methods', order.payment_method));
      const kind = methodSnap.exists() ? String(methodSnap.data().kind ?? '') : '';
      if (kind === 'debt' && order.customer_id) {
        const custRef = doc(db, 'customers', order.customer_id);
        const cSnap = await tx.get(custRef);
        if (cSnap.exists()) {
          const curDebt = Number(cSnap.data().debt ?? 0);
          const reverse = Math.min(order.total, Math.max(curDebt, 0));
          if (reverse > 0) {
            const next = curDebt - reverse;
            tx.update(custRef, { debt: next });
            const logRef = doc(collection(db, 'customers', order.customer_id, 'debt_logs'));
            tx.set(logRef, {
              id: logRef.id,
              amount: -reverse,
              balance_after: next,
              note: `Hoàn nợ do xóa đơn ${order.code}`,
              created_by: auth.currentUser?.uid ?? null,
              created_at: serverTimestamp(),
            });
          }
        }
      }

      // Xóa khoản quỹ tự động của đơn (nếu có)
      tx.delete(doc(db, 'cashbook_entries', `fund_${order.id}`));

      tx.delete(orderRef);
    });
  } catch (e) {
    throw toDbError(e);
  }
}

// --------------------------------------------------------------- customers ---
export async function searchCustomers(q: string): Promise<Customer[]> {
  try {
    const snap = await getDocs(collection(db, 'customers'));
    const all = snap.docs.map((d) => toCustomer(d.id, d.data()));
    const needle = unsignVietnamese(String(q ?? '')).toLowerCase();
    const filtered = needle
      ? all.filter((c) => {
          const hay = unsignVietnamese(`${c.name} ${c.phone}`).toLowerCase();
          return hay.includes(needle);
        })
      : all;
    filtered.sort((a, b) => a.name.localeCompare(b.name, 'vi'));
    return filtered;
  } catch (e) {
    throw toDbError(e);
  }
}

export async function getCustomer(
  id: string,
): Promise<(Customer & { recent_orders: Order[] }) | null> {
  try {
    const snap = await getDoc(doc(db, 'customers', id));
    if (!snap.exists()) return null;
    const customer = toCustomer(snap.id, snap.data());
    const oSnap = await getDocs(
      query(
        collection(db, 'orders'),
        where('customer_id', '==', id),
        orderBy('created_at', 'desc'),
        limit(20),
      ),
    );
    const recent_orders = oSnap.docs
      .map((d) => orderFromDoc(d))
      .filter((o): o is Order => o !== null);
    return { ...customer, recent_orders };
  } catch (e) {
    throw toDbError(e);
  }
}

export async function createCustomer(d: {
  name: string;
  phone: string;
  birthday?: string | null;
  address?: string | null;
  note?: string | null;
}): Promise<Customer> {
  const name = String(d.name ?? '').trim();
  const phone = String(d.phone ?? '').trim();
  if (!name) throw new DbError('invalid-argument', 'Vui lòng nhập tên khách hàng.');
  if (!phone) throw new DbError('invalid-argument', 'Vui lòng nhập số điện thoại.');
  try {
    const dup = await getDocs(query(collection(db, 'customers'), where('phone', '==', phone), limit(1)));
    if (!dup.empty) {
      throw new DbError('invalid-argument', `Số điện thoại ${phone} đã được đăng ký cho khách khác.`);
    }
    const id = uuid();
    const data = {
      id,
      name,
      phone,
      birthday: d.birthday ?? null,
      address: typeof d.address === 'string' && d.address ? d.address.slice(0, 500) : null,
      stamps: 0,
      reward_available: false,
      debt: 0,
      note: typeof d.note === 'string' && d.note ? d.note.slice(0, 1000) : null,
      created_at: serverTimestamp(),
    };
    await setDoc(doc(db, 'customers', id), data);
    const snap = await getDoc(doc(db, 'customers', id));
    const c = snap.exists() ? toCustomer(snap.id, snap.data()) : null;
    if (!c) throw new DbError('unknown', 'Không đọc được khách hàng vừa tạo.');
    return c;
  } catch (e) {
    throw toDbError(e);
  }
}

export async function updateCustomer(
  id: string,
  patch: Partial<Pick<Customer, 'name' | 'phone' | 'birthday' | 'address' | 'note'>>,
): Promise<void> {
  const data: Record<string, unknown> = {};
  if (patch.name !== undefined) {
    const trimmed = String(patch.name).trim();
    if (!trimmed) throw new DbError('invalid-argument', 'Tên khách hàng không được để trống.');
    data.name = trimmed;
  }
  if (patch.phone !== undefined) {
    const trimmed = String(patch.phone).trim();
    if (!trimmed) throw new DbError('invalid-argument', 'Số điện thoại không được để trống.');
    data.phone = trimmed;
  }
  if (patch.birthday !== undefined) data.birthday = patch.birthday;
  if (patch.address !== undefined) data.address = patch.address;
  if (patch.note !== undefined) data.note = patch.note;
  if (Object.keys(data).length === 0) return;
  try {
    if (data.phone !== undefined) {
      const dup = await getDocs(
        query(collection(db, 'customers'), where('phone', '==', data.phone), limit(2)),
      );
      if (dup.docs.some((x) => x.id !== id)) {
        throw new DbError(
          'invalid-argument',
          `Số điện thoại ${data.phone} đã được đăng ký cho khách khác.`,
        );
      }
    }
    await updateDoc(doc(db, 'customers', id), data);
  } catch (e) {
    throw toDbError(e);
  }
}

// --------------------------------------------------------------- công nợ ---
// Điều chỉnh công nợ khách hàng: amount > 0 = ghi nợ thêm, amount < 0 = thu nợ.
// Ghi lịch sử vào subcollection debt_logs để đối chiếu.
export async function adjustDebt(
  customerId: string,
  amount: number,
  note?: string | null,
): Promise<number> {
  const delta = Number(amount);
  if (!Number.isFinite(delta) || delta === 0) {
    throw new DbError('invalid-argument', 'Số tiền điều chỉnh công nợ không hợp lệ.');
  }
  try {
    const balanceAfter = await runTransaction(db, async (tx) => {
      const ref = doc(db, 'customers', customerId);
      const snap = await tx.get(ref);
      if (!snap.exists()) throw new DbError('not-found', 'Khách hàng không tồn tại.');
      const cur = Number(snap.data().debt ?? 0);
      const next = cur + delta;
      if (next < 0) throw new DbError('invalid-argument', `Số tiền thu (${formatVNDLocal(-delta)}) lớn hơn công nợ hiện tại (${formatVNDLocal(cur)}).`);
      tx.update(ref, { debt: next });
      const logRef = doc(collection(db, 'customers', customerId, 'debt_logs'));
      tx.set(logRef, {
        id: logRef.id,
        amount: delta,
        balance_after: next,
        note: typeof note === 'string' && note ? note.slice(0, 500) : null,
        created_by: auth.currentUser?.uid ?? null,
        created_at: serverTimestamp(),
      });
      return next;
    });
    return balanceAfter;
  } catch (e) {
    throw toDbError(e);
  }
}

function formatVNDLocal(n: number): string {
  return new Intl.NumberFormat('vi-VN').format(Math.round(n)) + 'đ';
}

export async function listDebtLogs(customerId: string, limitN = 20): Promise<DebtLog[]> {
  try {
    const snap = await getDocs(
      query(
        collection(db, 'customers', customerId, 'debt_logs'),
        orderBy('created_at', 'desc'),
        limit(limitN),
      ),
    );
    return snap.docs.map((d) => toDebtLog(d.id, d.data()));
  } catch (e) {
    throw toDbError(e);
  }
}

// ------------------------------------------------------------ sổ thu chi ---
// Thu/chi THỦ CÔNG của quán (nhập hàng, mặt bằng, lương...).
// LƯU Ý: đơn bán KHÔNG tự log vào đây — chỉ ghi tay qua màn hình Thu chi.
function toCashbookEntry(id: string, d: Record<string, unknown>): CashbookEntry {
  const rt = d.ref_type;
  return {
    id,
    type: d.type === 'chi' ? 'chi' : 'thu',
    amount: Number(d.amount ?? 0),
    note: (d.note as string | null) ?? null,
    category: String(d.category ?? 'Khác'),
    fund_id: String(d.fund_id ?? 'cash'),
    ref_type: rt === 'order' || rt === 'debt_pay' ? (rt as FundRefType) : 'manual',
    ref_id: (d.ref_id as string | null) ?? null,
    ref_code: (d.ref_code as string | null) ?? null,
    method: d.method === 'cash' || d.method === 'transfer' ? d.method : null,
    created_by: (d.created_by as string | null) ?? null,
    created_at: tsToIso(d.created_at),
  };
}

export interface AddCashbookOpts {
  refType?: FundRefType;
  refId?: string | null;
  method?: 'cash' | 'transfer' | null;
}

export async function addCashbookEntry(
  type: CashbookType,
  amount: number,
  note?: string | null,
  category?: string | null,
  opts?: AddCashbookOpts,
): Promise<CashbookEntry> {
  const v = Math.round(Number(amount));
  if (!Number.isFinite(v) || v <= 0) {
    throw new DbError('invalid-argument', 'Số tiền phải lớn hơn 0.');
  }
  const id = uuid();
  const data = {
    id,
    type,
    amount: v,
    note: typeof note === 'string' && note.trim() ? note.trim().slice(0, 500) : null,
    category: typeof category === 'string' && category.trim() ? category.trim().slice(0, 50) : 'Khác',
    fund_id: 'cash',
    ref_type: opts?.refType ?? 'manual',
    ref_id: opts?.refId ?? null,
    method: opts?.method ?? null,
    created_by: auth.currentUser?.uid ?? null,
    created_at: serverTimestamp(),
  };
  try {
    await setDoc(doc(db, 'cashbook_entries', id), data);
    const snap = await getDoc(doc(db, 'cashbook_entries', id));
    const e = snap.exists() ? toCashbookEntry(snap.id, snap.data() as Record<string, unknown>) : null;
    if (!e) throw new DbError('unknown', 'Không đọc được khoản vừa tạo.');
    return e;
  } catch (e) {
    throw toDbError(e);
  }
}

export async function listCashbookEntries(limitN = 500): Promise<CashbookEntry[]> {
  try {
    const snap = await getDocs(
      query(collection(db, 'cashbook_entries'), orderBy('created_at', 'desc'), limit(limitN)),
    );
    return snap.docs.map((d) => toCashbookEntry(d.id, d.data() as Record<string, unknown>));
  } catch (e) {
    throw toDbError(e);
  }
}

// ------------------------------------------------------------- sổ quỹ ---
const DEFAULT_FUND: FundSettings = {
  fund_name: 'Tiền mặt tại quầy',
  opening_balance: 0,
  opening_date: todayVN(),
};

/** Đọc cài đặt quỹ ở settings/fund (chưa có → dùng mặc định). */
export async function getFundSettings(): Promise<FundSettings> {
  try {
    const snap = await getDoc(doc(db, 'settings', 'fund'));
    if (!snap.exists()) return { ...DEFAULT_FUND };
    const d = snap.data();
    return {
      fund_name: typeof d.fund_name === 'string' && d.fund_name ? d.fund_name : DEFAULT_FUND.fund_name,
      opening_balance: Number.isFinite(Number(d.opening_balance)) ? Math.round(Number(d.opening_balance)) : 0,
      opening_date: /^\d{4}-\d{2}-\d{2}$/.test(String(d.opening_date)) ? String(d.opening_date) : todayVN(),
    };
  } catch (e) {
    throw toDbError(e);
  }
}

/** Lưu cài đặt quỹ — chỉ chủ quán (rules settings/{key} chỉ cho owner ghi). */
export async function setFundSettings(patch: Partial<FundSettings>): Promise<FundSettings> {
  const data: Record<string, unknown> = {};
  if (patch.fund_name !== undefined) {
    const n = String(patch.fund_name ?? '').trim().slice(0, 100);
    if (!n) throw new DbError('invalid-argument', 'Tên quỹ không được để trống.');
    data.fund_name = n;
  }
  if (patch.opening_balance !== undefined) {
    const v = Math.round(Number(patch.opening_balance));
    if (!Number.isFinite(v)) throw new DbError('invalid-argument', 'Số dư đầu kỳ không hợp lệ.');
    data.opening_balance = v;
  }
  if (patch.opening_date !== undefined) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(patch.opening_date))) {
      throw new DbError('invalid-argument', 'Ngày không hợp lệ.');
    }
    data.opening_date = String(patch.opening_date);
  }
  if (Object.keys(data).length === 0) return getFundSettings();
  try {
    await setDoc(doc(db, 'settings', 'fund'), data, { merge: true });
    return getFundSettings();
  } catch (e) {
    throw toDbError(e);
  }
}

// Đổi thưởng mua-N-tặng-1: chỉ reset cờ reward_available (đơn thưởng do POS tạo riêng)
export async function redeemReward(customerId: string): Promise<void> {
  try {
    const ref = doc(db, 'customers', customerId);
    const snap = await getDoc(ref);
    if (!snap.exists()) throw new DbError('not-found', 'Khách hàng không tồn tại.');
    if (snap.data().reward_available !== true) {
      throw new DbError('invalid-argument', 'Khách hàng chưa có lượt đổi thưởng nào.');
    }
    await updateDoc(ref, { reward_available: false });
  } catch (e) {
    throw toDbError(e);
  }
}

// ---------------------------------------------------------------- settings ---
export async function getSettings(): Promise<Record<string, string>> {
  try {
    const snap = await getDocs(collection(db, 'settings'));
    const out: Record<string, string> = {};
    for (const d of snap.docs) out[d.id] = String(d.data().value ?? '');
    return out;
  } catch (e) {
    throw toDbError(e);
  }
}

export async function setSetting(key: string, value: string): Promise<void> {
  if (!String(key ?? '').trim()) throw new DbError('invalid-argument', 'Thiếu key cài đặt.');
  try {
    await setDoc(doc(db, 'settings', key), { key, value: String(value ?? '') }, { merge: true });
  } catch (e) {
    throw toDbError(e);
  }
}

// ----------------------------------------------------------------- reports ---
// Mirror backend GET /api/v1/reports/daily — aggregate client-side.
// Đơn cancelled không tính vào doanh thu.
export async function getDailyReport(date: string): Promise<DailyReport> {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    throw new DbError('invalid-argument', 'Tham số date phải có dạng YYYY-MM-DD.');
  }
  try {
    const snap = await getDocs(
      query(
        collection(db, 'orders'),
        where('business_date', '==', date),
        orderBy('created_at', 'desc'),
        limit(2000),
      ),
    );
    const orders = snap.docs
      .map((d) => orderFromDoc(d))
      .filter((o): o is Order => o !== null && o.status !== 'cancelled');

    const revenue = orders.reduce((s, o) => s + o.total, 0);
    const by_payment: DailyReport['by_payment'] = {};
    for (const o of orders) {
      const key = o.payment_method || 'unknown';
      const slot = by_payment[key] ?? { name: o.payment_method_name || key, count: 0, revenue: 0 };
      slot.count += 1;
      slot.revenue += o.total;
      if (o.payment_method_name) slot.name = o.payment_method_name;
      by_payment[key] = slot;
    }

    const topMap = new Map<string, { product_id: string; name: string; qty: number; revenue: number }>();
    for (const o of orders) {
      for (const it of o.items) {
        const cur = topMap.get(it.product_id) ?? {
          product_id: it.product_id,
          name: it.product_name,
          qty: 0,
          revenue: 0,
        };
        cur.qty += it.qty;
        cur.revenue += it.line_total;
        topMap.set(it.product_id, cur);
      }
    }
    const top_products = [...topMap.values()]
      .sort((a, b) => b.qty - a.qty || b.revenue - a.revenue)
      .slice(0, 10);

    const by_hour = Array.from({ length: 24 }, (_, hour) => ({ hour, count: 0, revenue: 0 }));
    for (const o of orders) {
      const h = vnHour(o.created_at);
      if (h >= 0 && h < 24) {
        by_hour[h].count += 1;
        by_hour[h].revenue += o.total;
      }
    }

    return { date, revenue, order_count: orders.length, by_payment, top_products, by_hour };
  } catch (e) {
    throw toDbError(e);
  }
}

// Báo cáo theo khoảng ngày (dùng cho các mốc lọc: hôm qua, tuần này/tháng này...).
// Truy vấn range trên business_date + orderBy cùng field nên không cần composite index mới.
export async function getRangeReport(start: string, end: string): Promise<DailyReport> {
  const valid = /^\d{4}-\d{2}-\d{2}$/;
  if (!valid.test(start) || !valid.test(end) || start > end) {
    throw new DbError('invalid-argument', 'Khoảng ngày không hợp lệ.');
  }
  try {
    const snap = await getDocs(
      query(
        collection(db, 'orders'),
        where('business_date', '>=', start),
        where('business_date', '<=', end),
        orderBy('business_date', 'desc'),
        limit(5000),
      ),
    );
    const orders = snap.docs
      .map((d) => orderFromDoc(d))
      .filter((o): o is Order => o !== null && o.status !== 'cancelled');

    const revenue = orders.reduce((s, o) => s + o.total, 0);
    const by_payment: DailyReport['by_payment'] = {};
    for (const o of orders) {
      const key = o.payment_method || 'unknown';
      const slot = by_payment[key] ?? { name: o.payment_method_name || key, count: 0, revenue: 0 };
      slot.count += 1;
      slot.revenue += o.total;
      if (o.payment_method_name) slot.name = o.payment_method_name;
      by_payment[key] = slot;
    }

    const topMap = new Map<string, { product_id: string; name: string; qty: number; revenue: number }>();
    for (const o of orders) {
      for (const it of o.items) {
        const cur = topMap.get(it.product_id) ?? {
          product_id: it.product_id,
          name: it.product_name,
          qty: 0,
          revenue: 0,
        };
        cur.qty += it.qty;
        cur.revenue += it.line_total;
        topMap.set(it.product_id, cur);
      }
    }
    const top_products = [...topMap.values()]
      .sort((a, b) => b.qty - a.qty || b.revenue - a.revenue)
      .slice(0, 10);

    const by_hour = Array.from({ length: 24 }, (_, hour) => ({ hour, count: 0, revenue: 0 }));
    for (const o of orders) {
      const h = vnHour(o.created_at);
      if (h >= 0 && h < 24) {
        by_hour[h].count += 1;
        by_hour[h].revenue += o.total;
      }
    }

    return { date: `${start}→${end}`, revenue, order_count: orders.length, by_payment, top_products, by_hour };
  } catch (e) {
    throw toDbError(e);
  }
}

// ------------------------------------------------------------------ backup ---
const EXPORT_TABLES = [
  'categories',
  'products',
  'modifierGroups',
  'modifierOptions',
  'customers',
  'orders',
  'settings',
  'counters',
  'payment_methods',
  'users', // {id, email, full_name, role} — không chứa mật khẩu
] as const;

function plainValue(v: unknown): unknown {
  if (v instanceof Timestamp) return v.toDate().toISOString();
  if (Array.isArray(v)) return v.map(plainValue);
  if (v && typeof v === 'object') {
    const out: Record<string, unknown> = {};
    for (const [k, val] of Object.entries(v)) out[k] = plainValue(val);
    return out;
  }
  return v;
}

export async function exportAllJson(): Promise<Record<string, unknown[]>> {
  try {
    const out: Record<string, unknown[]> = {};
    for (const t of EXPORT_TABLES) {
      const snap = await getDocs(query(collection(db, t), limit(5000)));
      out[t] = snap.docs.map((d) => plainValue({ id: d.id, ...d.data() }) as unknown);
    }
    return out;
  } catch (e) {
    throw toDbError(e);
  }
}

// Header CSV tiếng Việt — mirror backend routes/backup.js#CSV_HEADERS
const CSV_HEADERS: Record<'orders' | 'products' | 'customers' | 'categories' | 'payment_methods', [string, string][]> = {
  orders: [
    ['id', 'Mã nội bộ'], ['client_uuid', 'Mã chống trùng'], ['code', 'Mã đơn'],
    ['business_date', 'Ngày bán'], ['customer_id', 'Mã KH'], ['status', 'Trạng thái'],
    ['payment_method', 'Mã thanh toán'], ['payment_method_name', 'Thanh toán'], ['subtotal', 'Tạm tính (VND)'],
    ['discount', 'Giảm giá (VND)'], ['total', 'Tổng tiền (VND)'],
    ['amount_received', 'Tiền nhận (VND)'], ['change_amount', 'Tiền thừa (VND)'],
    ['note', 'Ghi chú'], ['created_by', 'Người tạo'], ['created_at', 'Thời gian tạo'],
  ],
  products: [
    ['id', 'Mã nội bộ'], ['name', 'Tên món'], ['category_id', 'Mã danh mục'],
    ['base_price', 'Giá bán (VND)'], ['image_url', 'Ảnh'],
    ['active', 'Đang bán'], ['sort_order', 'Thứ tự'], ['created_at', 'Ngày tạo'],
  ],
  customers: [
    ['id', 'Mã nội bộ'], ['name', 'Tên khách'], ['phone', 'Số điện thoại'],
    ['birthday', 'Ngày sinh'], ['address', 'Địa chỉ'], ['stamps', 'Số tem'],
    ['reward_available', 'Có thưởng'], ['debt', 'Công nợ (VND)'], ['note', 'Ghi chú'], ['created_at', 'Ngày tạo'],
  ],
  categories: [
    ['id', 'Mã nội bộ'], ['name', 'Tên danh mục'],
    ['sort_order', 'Thứ tự'], ['active', 'Đang dùng'],
  ],
  payment_methods: [
    ['id', 'Mã nội bộ'], ['name', 'Tên phương thức'], ['kind', 'Loại'],
    ['icon', 'Biểu tượng'], ['bank_bin', 'Mã BIN'], ['bank_account', 'Số tài khoản'],
    ['bank_account_name', 'Chủ tài khoản'], ['active', 'Đang dùng'], ['sort_order', 'Thứ tự'],
  ],
};

function csvCell(v: unknown): string {
  if (v === null || v === undefined) return '';
  const s = typeof v === 'object' ? JSON.stringify(v) : String(v);
  if (/[",\n\r]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

export async function exportTableCsv(
  table: 'orders' | 'products' | 'customers' | 'categories' | 'payment_methods',
): Promise<string> {
  const header = CSV_HEADERS[table];
  if (!header) throw new DbError('invalid-argument', `Bảng không hỗ trợ: ${table}.`);
  try {
    const snap = await getDocs(query(collection(db, table), limit(5000)));
    const lines = [header.map(([, label]) => csvCell(label)).join(',')];
    for (const d of snap.docs) {
      const data = d.data() as Record<string, unknown>;
      lines.push(
        header
          .map(([col]) => {
            if (col === 'id') return csvCell(d.id);
            if (col === 'created_at') {
              // products/categories seed không có created_at → để trống thay vì ngày hiện tại
              return data[col] == null ? '' : csvCell(tsToIso(data[col]));
            }
            return csvCell(data[col]);
          })
          .join(','),
      );
    }
    return '﻿' + lines.join('\r\n'); // BOM để Excel mở đúng tiếng Việt
  } catch (e) {
    throw toDbError(e);
  }
}

export function downloadFile(filename: string, content: string, mime: string): void {
  const blob = new Blob([content], { type: `${mime};charset=utf-8` });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}
