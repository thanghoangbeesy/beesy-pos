import { useNavigate } from 'react-router-dom';
import type { ReactNode } from 'react';

// Header trang kiểu app bán hàng mobile: nút back trái + tiêu đề căn giữa.
// Trang tab chính (Tổng quan, Bán hàng, Khách, Menu, Cài đặt): back=false.
export function PageHead({ title, back, right }: { title: string; back?: boolean; right?: ReactNode }) {
  const navigate = useNavigate();
  return (
    <div className="pg-head">
      {back ? (
        <button className="pg-back" onClick={() => navigate(-1)} aria-label="Quay lại">
          ‹
        </button>
      ) : (
        <span className="pg-side" />
      )}
      <h1 className="pg-title">{title}</h1>
      <span className="pg-side">{right}</span>
    </div>
  );
}
