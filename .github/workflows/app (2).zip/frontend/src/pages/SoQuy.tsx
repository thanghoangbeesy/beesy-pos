// Sổ quỹ — sổ tiền của quán.
// Gồm khoản THỦ CÔNG (nhập tay) và khoản TỰ ĐỘNG:
//  - đơn đã thu tiền (tiền mặt/chuyển khoản) → "Doanh thu bán hàng" (ghi trong transaction tạo đơn)
//  - thu nợ ở Sổ nợ → "Thu nợ — tên khách"
// Đơn ghi nợ lúc bán chưa thu tiền nên không ghi vào quỹ.
// Đơn cũ trước tính năng tự động không backfill.
import { useNavigate } from 'react-router-dom';
import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  DbError,
  addCashbookEntry,
  getFundSettings,
  listCashbookEntries,
  setFundSettings,
} from '../lib/db';
import { formatTime, formatVND, todayVN, unsignVietnamese } from '../lib/format';
import { Sheet } from '../components/Sheet';
import { PageHead } from '../components/PageHead';
import { useToast } from '../components/Toast';
import { useAuth } from '../lib/auth';
import type { CashbookEntry, CashbookType, FundSettings } from '../lib/types';

const CATEGORIES = ['Nguyên liệu', 'Mặt bằng', 'Lương', 'Bán hàng', 'Thu nợ', 'Khác'];

type FilterKey = 'today' | 'month' | 'all';
const FILTERS: { key: FilterKey; label: string }[] = [
  { key: 'today', label: 'Hôm nay' },
  { key: 'month', label: 'Tháng này' },
  { key: 'all', label: 'Tất cả' },
];

/** YYYY-MM-DD theo giờ VN từ chuỗi ISO. */
function vnDateKey(iso: string): string {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Ho_Chi_Minh',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date(iso));
}

/** Nhãn ngày kiểu "Thứ Bảy, 10/10" theo giờ VN. */
function vnDayLabel(iso: string): string {
  return new Date(iso).toLocaleDateString('vi-VN', {
    weekday: 'long',
    day: '2-digit',
    month: '2-digit',
    timeZone: 'Asia/Ho_Chi_Minh',
  });
}

export function SoQuy() {
  const toast = useToast();
  const navigate = useNavigate();
  const { isOwner } = useAuth();
  const [entries, setEntries] = useState<CashbookEntry[]>([]);
  const [fund, setFund] = useState<FundSettings | null>(null);
  const [filter, setFilter] = useState<FilterKey>('month');
  const [q, setQ] = useState('');
  const [busy, setBusy] = useState(true);
  const [sheet, setSheet] = useState<CashbookType | null>(null);
  const [fundSheet, setFundSheet] = useState(false);

  const load = useCallback(async () => {
    setBusy(true);
    try {
      const [list, f] = await Promise.all([listCashbookEntries(500), getFundSettings()]);
      setEntries(list);
      setFund(f);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tải được sổ quỹ');
    } finally {
      setBusy(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const t = todayVN();
  const needle = unsignVietnamese(q.trim()).toLowerCase();
  const filtered = useMemo(
    () =>
      entries.filter((e) => {
        const k = vnDateKey(e.created_at);
        if (filter === 'today' && k !== t) return false;
        if (filter === 'month' && k.slice(0, 7) !== t.slice(0, 7)) return false;
        if (needle) {
          const hay = unsignVietnamese(
            `${e.category} ${e.note ?? ''} ${e.amount} ${formatTime(e.created_at)}`,
          ).toLowerCase();
          if (!hay.includes(needle)) return false;
        }
        return true;
      }),
    [entries, filter, t, needle],
  );

  const totalThu = filtered.filter((e) => e.type === 'thu').reduce((s, e) => s + e.amount, 0);
  const totalChi = filtered.filter((e) => e.type === 'chi').reduce((s, e) => s + e.amount, 0);

  // Số dư quỹ = số dư đầu kỳ + Σ thu − Σ chi (tính trên 500 khoản mới nhất — đủ cho quán nhỏ)
  const balance =
    (fund?.opening_balance ?? 0) +
    entries.filter((e) => e.type === 'thu').reduce((s, e) => s + e.amount, 0) -
    entries.filter((e) => e.type === 'chi').reduce((s, e) => s + e.amount, 0);

  const groups = useMemo(() => {
    const m = new Map<string, CashbookEntry[]>();
    for (const e of filtered) {
      const k = vnDateKey(e.created_at);
      if (!m.has(k)) m.set(k, []);
      m.get(k)!.push(e);
    }
    return [...m.entries()].sort((a, b) => (a[0] < b[0] ? 1 : -1));
  }, [filtered]);

  return (
    <div className="page with-dual-actions">
      <PageHead title="Sổ quỹ" back />

      <div className="sb-search" style={{ marginBottom: 12 }}>
        <span className="sico">🔍</span>
        <input
          placeholder="Tìm ghi chú, số tiền…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          aria-label="Tìm khoản thu chi"
        />
      </div>

      <div className="row" style={{ gap: 8, marginBottom: 12, flexWrap: 'wrap' }}>
        {FILTERS.map((f) => (
          <button
            key={f.key}
            className={`sb-chip${filter === f.key ? ' selected' : ''}`}
            onClick={() => setFilter(f.key)}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Số dư quỹ */}
      <div className="sb-section" style={{ marginBottom: 12, textAlign: 'center' }}>
        <div className="small muted">Số dư {fund?.fund_name ?? 'quỹ'}</div>
        <div className="money text-green" style={{ fontSize: 32, margin: '4px 0' }}>
          {formatVND(balance)}
        </div>
        <button
          type="button"
          className="small"
          style={{
            color: 'var(--brand-dark)',
            fontWeight: 600,
            background: 'none',
            border: 'none',
            padding: 4,
            minHeight: 32,
          }}
          onClick={() => {
            if (!isOwner) {
              toast.show('Chỉ chủ quán mới được sửa số dư đầu kỳ');
              return;
            }
            setFundSheet(true);
          }}
        >
          Số dư đầu kỳ: {formatVND(fund?.opening_balance ?? 0)}
          {isOwner ? ' · Sửa ›' : ''}
        </button>
      </div>

      <div className="sb-section" style={{ marginBottom: 12 }}>
        <div className="row" style={{ justifyContent: 'space-between', marginBottom: 10 }}>
          <span className="muted">Chênh lệch (kỳ lọc)</span>
          <b className="money" style={{ fontSize: 22 }}>
            {formatVND(totalThu - totalChi)}
          </b>
        </div>
        <div className="row" style={{ gap: 12 }}>
          <div className="card pastel-green grow" style={{ boxShadow: 'none' }}>
            <div className="small muted">Tổng thu</div>
            <div className="money text-green" style={{ fontSize: 20 }}>
              {formatVND(totalThu)}
            </div>
          </div>
          <div className="card pastel-yellow grow" style={{ boxShadow: 'none' }}>
            <div className="small muted">Tổng chi</div>
            <div className="money text-orange" style={{ fontSize: 20 }}>
              {formatVND(totalChi)}
            </div>
          </div>
        </div>
      </div>

      {busy ? (
        <div className="sb-section muted" style={{ textAlign: 'center' }}>
          Đang tải…
        </div>
      ) : groups.length === 0 ? (
        <div className="sb-section">
          <div className="sb-empty">
            <div className="eico">💸</div>
            <p>
              Chưa có khoản thu chi nào.
              <br />
              Đơn đã thu tiền và thu nợ sẽ tự ghi vào đây.
            </p>
          </div>
        </div>
      ) : (
        groups.map(([day, list]) => (
          <div className="sb-day-group" key={day}>
            <div className="sb-day-label">{vnDayLabel(list[0].created_at)}</div>
            <div className="sb-section" style={{ padding: '4px 16px' }}>
              {list.map((e) => {
                // Khoản từ đơn bán → bấm để mở chi tiết đơn đó ở màn Đơn hàng
                const openOrder = e.ref_type === 'order' && !!e.ref_id;
                const inner = (
                  <>
                    <span
                      className="avatar"
                      style={
                        e.type === 'thu'
                          ? { background: 'var(--green-bg)', color: 'var(--brand-dark)' }
                          : { background: 'var(--orange-bg)', color: 'var(--orange)' }
                      }
                    >
                      {e.type === 'thu' ? '↓' : '↑'}
                    </span>
                    <span className="rbody">
                      <span className="rtitle">
                        {e.note || e.category}
                        {e.ref_type !== 'manual' && (
                          <span className="sb-status-pill" style={{ marginLeft: 6, fontSize: 11 }}>
                            Tự động
                          </span>
                        )}
                      </span>
                      <span className="rsub">
                        {e.ref_type === 'order' && e.ref_code ? `Đơn ${e.ref_code} · ` : ''}
                        {e.note ? `${e.category} · ` : ''}
                        {formatTime(e.created_at)}
                      </span>
                    </span>
                    <span className={`ramount ${e.type === 'thu' ? 'text-green' : 'text-orange'}`}>
                      {e.type === 'thu' ? '+' : '−'}
                      {formatVND(e.amount)}
                    </span>
                    {openOrder && (
                      <span className="chev muted" style={{ fontSize: 22 }}>
                        ›
                      </span>
                    )}
                  </>
                );
                return openOrder ? (
                  <button key={e.id} className="sb-row" onClick={() => navigate(`/orders?open=${e.ref_id}`)}>
                    {inner}
                  </button>
                ) : (
                  <div key={e.id} className="sb-row" style={{ cursor: 'default' }}>
                    {inner}
                  </div>
                );
              })}
            </div>
          </div>
        ))
      )}

      <div className="sb-dual-actions">
        <div className="inner">
          <button className="btn sb-btn-orange btn-block btn-lg" onClick={() => setSheet('chi')}>
            Khoản chi
          </button>
          <button className="btn btn-block btn-lg" onClick={() => setSheet('thu')}>
            Khoản thu
          </button>
        </div>
      </div>

      {sheet && (
        <FundEntrySheet
          type={sheet}
          onClose={() => setSheet(null)}
          onDone={() => {
            setSheet(null);
            void load();
          }}
        />
      )}

      {fundSheet && fund && (
        <FundSheet
          fund={fund}
          onClose={() => setFundSheet(false)}
          onDone={(f) => {
            setFund(f);
            setFundSheet(false);
          }}
        />
      )}
    </div>
  );
}

function FundSheet({
  fund,
  onClose,
  onDone,
}: {
  fund: FundSettings;
  onClose: () => void;
  onDone: (f: FundSettings) => void;
}) {
  const toast = useToast();
  const [name, setName] = useState(fund.fund_name);
  const [balance, setBalance] = useState(String(fund.opening_balance));
  const [date, setDate] = useState(fund.opening_date);
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    const v = parseInt(balance.replace(/\D/g, ''), 10);
    if (!Number.isFinite(v) || v < 0) {
      toast.show('Nhập số dư hợp lệ');
      return;
    }
    setBusy(true);
    try {
      const f = await setFundSettings({
        fund_name: name.trim() || 'Tiền mặt tại quầy',
        opening_balance: v,
        opening_date: date,
      });
      toast.show('Đã lưu số dư đầu kỳ');
      onDone(f);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet
      title="Số dư đầu kỳ"
      onClose={onClose}
      footer={
        <button className="btn btn-block btn-lg" disabled={busy} onClick={submit}>
          {busy ? 'Đang lưu…' : 'Lưu'}
        </button>
      }
    >
      <div className="field">
        <label>Tên quỹ</label>
        <input className="input" value={name} onChange={(e) => setName(e.target.value)} maxLength={100} />
      </div>
      <div className="field">
        <label>Số dư đầu kỳ</label>
        <input
          className="sb-money-input"
          inputMode="numeric"
          value={balance}
          onChange={(e) => setBalance(e.target.value)}
          placeholder="0"
        />
      </div>
      <div className="field">
        <label>Tính từ ngày</label>
        <input
          type="date"
          className="input"
          value={date}
          max={todayVN()}
          onChange={(e) => setDate(e.target.value)}
        />
      </div>
      <p className="small muted">
        Số dư quỹ = số dư đầu kỳ + tổng thu − tổng chi. Đơn đã thu tiền và thu nợ được tự động ghi
        vào sổ.
      </p>
    </Sheet>
  );
}

function FundEntrySheet({
  type,
  onClose,
  onDone,
}: {
  type: CashbookType;
  onClose: () => void;
  onDone: () => void;
}) {
  const toast = useToast();
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [category, setCategory] = useState(type === 'chi' ? 'Nguyên liệu' : 'Bán hàng');
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    const v = parseInt(amount.replace(/\D/g, ''), 10);
    if (!v || v <= 0) {
      toast.show('Nhập số tiền hợp lệ');
      return;
    }
    setBusy(true);
    try {
      await addCashbookEntry(type, v, note.trim() || null, category);
      toast.show(
        type === 'thu' ? `Đã ghi khoản thu ${formatVND(v)}` : `Đã ghi khoản chi ${formatVND(v)}`,
      );
      onDone();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet
      title={type === 'thu' ? 'Khoản thu' : 'Khoản chi'}
      onClose={onClose}
      footer={
        <button
          className={`btn btn-block btn-lg${type === 'chi' ? ' sb-btn-orange' : ''}`}
          disabled={busy}
          onClick={submit}
        >
          {busy ? 'Đang lưu…' : 'Lưu'}
        </button>
      }
    >
      <div className="field">
        <label>Số tiền</label>
        <input
          className="sb-money-input"
          inputMode="numeric"
          placeholder="0"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          autoFocus
        />
      </div>
      <div className="field">
        <label>Danh mục</label>
        <div className="row" style={{ flexWrap: 'wrap', gap: 8 }}>
          {CATEGORIES.map((c) => (
            <button
              key={c}
              type="button"
              className={`sb-chip${category === c ? ' selected' : ''}`}
              onClick={() => setCategory(c)}
            >
              {c}
            </button>
          ))}
        </div>
      </div>
      <div className="field">
        <label>Ghi chú (không bắt buộc)</label>
        <input
          className="input"
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="VD: nhập sữa tươi…"
        />
      </div>
    </Sheet>
  );
}
