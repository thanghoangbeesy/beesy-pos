import { useCallback, useEffect, useRef, useState } from 'react';
import { DbError, listOrdersByDate, updateOrderStatus } from '../lib/db';
import { formatTime, todayVN } from '../lib/format';
import { playNewOrderSound, useKdsRealtime } from '../lib/realtime';
import { useToast } from '../components/Toast';
import { PageHead } from '../components/PageHead';
import type { Order, OrderStatus } from '../lib/types';

const COLS: { status: OrderStatus; title: string; cls: string; btnCls: string; next: OrderStatus; nextLabel: string }[] = [
  { status: 'new', title: 'Mới', cls: 'col-new', btnCls: 'sb-btn-orange', next: 'preparing', nextLabel: 'Bắt đầu pha' },
  { status: 'preparing', title: 'Đang pha', cls: 'col-prep', btnCls: '', next: 'ready', nextLabel: 'Xong — chờ lấy' },
  { status: 'ready', title: 'Sẵn sàng lấy', cls: 'col-ready', btnCls: 'btn-outline', next: 'done', nextLabel: 'Hoàn tất' },
];

const SOUND_KEY = 'beesy_kds_sound';

export function KDS() {
  const toast = useToast();
  const [orders, setOrders] = useState<Order[]>([]);
  const [soundOn, setSoundOn] = useState(() => localStorage.getItem(SOUND_KEY) !== 'off');
  const [busy, setBusy] = useState<string | null>(null);
  const soundRef = useRef(soundOn);
  soundRef.current = soundOn;

  const fetchOrders = useCallback(async () => {
    try {
      const data = await listOrdersByDate(todayVN(), 200);
      setOrders(data.filter((o) => ['new', 'preparing', 'ready'].includes(o.status)));
    } catch {
      /* giữ danh sách cũ khi mất mạng */
    }
  }, []);

  useEffect(() => {
    void fetchOrders();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fetchOrders]);

  useKdsRealtime(todayVN(), {
    onCreated: (order) => {
      setOrders((prev) => (prev.some((o) => o.id === order.id) ? prev : [order, ...prev]));
      if (soundRef.current) playNewOrderSound();
      toast.show(`🔔 Đơn mới ${order.code}!`);
    },
    onUpdated: (order) => {
      setOrders((prev) => {
        if (['done', 'cancelled'].includes(order.status)) return prev.filter((o) => o.id !== order.id);
        const i = prev.findIndex((o) => o.id === order.id);
        if (i >= 0) {
          const next = [...prev];
          next[i] = order;
          return next;
        }
        return ['new', 'preparing', 'ready'].includes(order.status) ? [order, ...prev] : prev;
      });
    },
  });

  const advance = async (order: Order, next: OrderStatus) => {
    setBusy(order.id);
    try {
      const updated = await updateOrderStatus(order.id, next);
      setOrders((prev) =>
        next === 'done' ? prev.filter((o) => o.id === order.id) : prev.map((o) => (o.id === order.id ? updated : o)),
      );
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Đổi trạng thái thất bại');
    } finally {
      setBusy(null);
    }
  };

  const byStatus = (s: OrderStatus) =>
    orders
      .filter((o) => o.status === s)
      .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());

  const toggleSound = () => {
    const v = !soundOn;
    setSoundOn(v);
    localStorage.setItem(SOUND_KEY, v ? 'on' : 'off');
    if (v) playNewOrderSound();
  };

  return (
    <div className="page">
      <PageHead
        title="Pha chế"
        back
        right={
          <button
            className="btn btn-ghost"
            style={{
              width: 44,
              height: 44,
              minHeight: 44,
              padding: 0,
              borderRadius: '50%',
              fontSize: 22,
            }}
            onClick={toggleSound}
            aria-label={soundOn ? 'Tắt âm báo' : 'Bật âm báo'}
            title={soundOn ? 'Tắt âm báo' : 'Bật âm báo'}
          >
            {soundOn ? '🔔' : '🔕'}
          </button>
        }
      />
      <div className="kds-cols">
        {COLS.map((c) => {
          const list = byStatus(c.status);
          return (
            <div className={`kds-col ${c.cls}`} key={c.status}>
              <h3>
                {c.title} <span className="count">{list.length}</span>
              </h3>
              {list.map((o) => (
                <div
                  className={`order-card${c.status === 'preparing' ? ' preparing' : c.status === 'ready' ? ' ready' : ''}`}
                  key={o.id}
                >
                  <div className="row">
                    <span className="ocode">{o.code}</span>
                    <span className="grow" />
                    <span className="otime">{formatTime(o.created_at)}</span>
                  </div>
                  <div className="oitems">
                    {o.items.map((it) => (
                      <div key={it.id} style={{ marginBottom: 4 }}>
                        <span className="qty">{it.qty}x</span> {it.product_name}
                        {(it.modifiers || []).length > 0 && (
                          <div className="omods">↳ {(it.modifiers || []).map((m) => m.option).join(' · ')}</div>
                        )}
                      </div>
                    ))}
                  </div>
                  {o.note && <div className="onote">{o.note}</div>}
                  <button
                    className={`btn btn-block ${c.btnCls}`}
                    style={{ marginTop: 10 }}
                    disabled={busy === o.id}
                    onClick={() => advance(o, c.next)}
                  >
                    {busy === o.id ? 'Đang xử lý…' : c.nextLabel}
                  </button>
                </div>
              ))}
              {list.length === 0 && <div className="sb-empty">Không có đơn nào</div>}
            </div>
          );
        })}
      </div>
    </div>
  );
}
