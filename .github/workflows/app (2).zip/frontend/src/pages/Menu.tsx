import { useCallback, useEffect, useState } from 'react';
import type { FormEvent } from 'react';
import {
  DbError,
  createCategory,
  createModifierOption,
  createProduct,
  createProductsBulk,
  deleteCategory,
  deleteModifierOption,
  deleteProduct,
  listCategories,
  listModifierGroups,
  listProducts,
  updateCategory,
  updateModifierOption,
  updateProduct,
} from '../lib/db';
import { formatVND } from '../lib/format';
import { Sheet } from '../components/Sheet';
import { useToast } from '../components/Toast';
import { useAuth } from '../lib/auth';
import type { Category, ModifierGroup, Product } from '../lib/types';

type Tab = 'products' | 'categories' | 'modifiers';

export function Menu() {
  const toast = useToast();
  const { isOwner } = useAuth();
  const [tab, setTab] = useState<Tab>('products');
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [groups, setGroups] = useState<ModifierGroup[]>([]);
  const [loading, setLoading] = useState(true);

  const reload = useCallback(async () => {
    try {
      const [cats, prods, gs] = await Promise.all([
        listCategories(),
        listProducts(),
        listModifierGroups(),
      ]);
      setCategories(cats.sort((a, b) => a.sort_order - b.sort_order));
      setProducts(prods.sort((a, b) => a.sort_order - b.sort_order));
      setGroups(gs.sort((a, b) => a.sort_order - b.sort_order));
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tải được menu');
    } finally {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    void reload();
  }, [reload]);

  if (!isOwner) {
    return (
      <div className="page">
        <div className="card">🔒 Chỉ chủ quán mới được quản lý menu.</div>
      </div>
    );
  }

  return (
    <div className="page">
      <h1>📋 Quản lý menu</h1>
      <div className="cat-tabs" style={{ marginBottom: 14 }}>
        <button className={`cat-tab${tab === 'products' ? ' active' : ''}`} onClick={() => setTab('products')}>🍹 Món</button>
        <button className={`cat-tab${tab === 'categories' ? ' active' : ''}`} onClick={() => setTab('categories')}>📂 Danh mục</button>
        <button className={`cat-tab${tab === 'modifiers' ? ' active' : ''}`} onClick={() => setTab('modifiers')}>🧋 Topping / Tùy chọn</button>
      </div>
      {loading ? (
        <div className="card">Đang tải…</div>
      ) : tab === 'products' ? (
        <ProductsTab products={products} categories={categories} reload={reload} />
      ) : tab === 'categories' ? (
        <CategoriesTab categories={categories} reload={reload} />
      ) : (
        <ModifiersTab groups={groups} reload={reload} />
      )}
    </div>
  );
}

/* ---------------- Món ---------------- */
function ProductsTab({ products, categories, reload }: { products: Product[]; categories: Category[]; reload: () => Promise<void> }) {
  const toast = useToast();
  const [editing, setEditing] = useState<Product | 'new' | null>(null);
  const [bulkOpen, setBulkOpen] = useState(false);

  const toggleActive = async (p: Product) => {
    try {
      await updateProduct(p.id, { active: !p.active });
      toast.show(p.active ? `Đã ẩn “${p.name}”` : `Đã hiện “${p.name}”`);
      await reload();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Thất bại');
    }
  };

  const remove = async (p: Product) => {
    if (!window.confirm(`Xóa hẳn món “${p.name}” khỏi menu?\nĐơn hàng cũ không bị ảnh hưởng.`)) return;
    try {
      await deleteProduct(p.id);
      toast.show(`Đã xóa “${p.name}”`);
      await reload();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Xóa thất bại');
    }
  };

  const catName = (id: string | null) => categories.find((c) => c.id === id)?.name ?? '—';

  return (
    <>
      <div className="row" style={{ marginBottom: 12, gap: 8 }}>
        <button className="btn" onClick={() => setEditing('new')}>➕ Thêm món</button>
        <button className="btn btn-outline" onClick={() => setBulkOpen(true)}>📋 Thêm hàng loạt</button>
      </div>
      <div className="card" style={{ padding: 0 }}>
        <div className="table-wrap">
          <table className="tbl">
            <thead>
              <tr><th>Món</th><th>Giá</th><th>Danh mục</th><th>Trạng thái</th><th></th></tr>
            </thead>
            <tbody>
              {products.map((p) => (
                <tr key={p.id} style={p.active ? undefined : { opacity: 0.5 }}>
                  <td><b>{p.name}</b></td>
                  <td className="money">{formatVND(p.base_price)}</td>
                  <td>{catName(p.category_id)}</td>
                  <td>{p.active ? '✅ Đang bán' : '🚫 Đang ẩn'}</td>
                  <td style={{ whiteSpace: 'nowrap' }}>
                    <button className="btn btn-outline" style={{ minHeight: 40, padding: '6px 12px', marginRight: 6 }} onClick={() => toggleActive(p)}>
                      {p.active ? 'Ẩn' : 'Hiện'}
                    </button>
                    <button className="btn btn-ghost" style={{ minHeight: 40, padding: '6px 12px', marginRight: 6 }} onClick={() => setEditing(p)}>
                      Sửa
                    </button>
                    <button className="btn btn-ghost" style={{ minHeight: 40, padding: '6px 12px', color: '#dc2626' }} onClick={() => remove(p)}>
                      🗑️
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      {editing && (
        <ProductForm product={editing === 'new' ? null : editing} categories={categories} onClose={() => setEditing(null)} reload={reload} />
      )}
      {bulkOpen && (
        <BulkAddSheet categories={categories} onClose={() => setBulkOpen(false)} reload={reload} />
      )}
    </>
  );
}

// Thêm nhiều món cùng lúc: mỗi dòng "Tên món | giá | tên danh mục (tùy chọn)".
function BulkAddSheet({ categories, onClose, reload }: { categories: Category[]; onClose: () => void; reload: () => Promise<void> }) {
  const toast = useToast();
  const [text, setText] = useState('');
  const [defaultCat, setDefaultCat] = useState(categories[0]?.id ?? '');
  const [busy, setBusy] = useState(false);

  const catByName = (name: string) => {
    const n = name.trim().toLowerCase();
    return categories.find((c) => c.name.trim().toLowerCase() === n) ?? null;
  };

  const parsed = text
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      const parts = line.split('|').map((s) => s.trim());
      const name = parts[0] ?? '';
      const price = parseInt((parts[1] ?? '').replace(/\D/g, ''), 10);
      const cat = parts[2] ? catByName(parts[2]) : null;
      const ok = !!name && Number.isFinite(price) && price > 0 && (parts[2] ? !!cat : true);
      return { line, name, price, cat, ok, err: !name ? 'thiếu tên' : !Number.isFinite(price) || price <= 0 ? 'giá không hợp lệ' : parts[2] && !cat ? `không có danh mục “${parts[2]}”` : '' };
    });
  const okCount = parsed.filter((p) => p.ok).length;

  const submit = async () => {
    if (okCount === 0) {
      toast.show('Chưa có dòng nào hợp lệ');
      return;
    }
    setBusy(true);
    try {
      const { added } = await createProductsBulk(
        parsed
          .filter((p) => p.ok)
          .map((p) => ({ name: p.name, base_price: p.price, category_id: p.cat ? p.cat.id : defaultCat || null })),
      );
      toast.show(`Đã thêm ${added} món`);
      await reload();
      onClose();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Thêm thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet title="📋 Thêm món hàng loạt" onClose={onClose}>
      <p className="small muted" style={{ marginTop: 0 }}>
        Mỗi dòng một món theo mẫu: <b>Tên món | giá | tên danh mục</b> (danh mục bỏ trống sẽ dùng danh mục mặc định bên dưới).
      </p>
      <div className="field">
        <label>Danh mục mặc định</label>
        <select className="input" value={defaultCat} onChange={(e) => setDefaultCat(e.target.value)}>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </select>
      </div>
      <div className="field">
        <label>Danh sách món</label>
        <textarea
          className="input"
          rows={8}
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder={'Trà Sữa Truyền Thống | 32000 | Trà sữa\nCà Phê Sữa Đá | 25000\nBạc Xỉu | 29000 | Cà phê'}
          style={{ fontFamily: 'inherit' }}
        />
      </div>
      {parsed.length > 0 && (
        <div className="card" style={{ marginBottom: 12, maxHeight: 220, overflow: 'auto' }}>
          <b className="small">Xem trước: {okCount}/{parsed.length} dòng hợp lệ</b>
          {parsed.map((p, i) => (
            <div key={i} className="small" style={{ padding: '4px 0', color: p.ok ? undefined : '#dc2626' }}>
              {p.ok ? '✅' : '❌'} {p.name || <i>(trống)</i>} — {Number.isFinite(p.price) && p.price > 0 ? formatVND(p.price) : '?'} — {p.cat ? p.cat.name : 'mặc định'}
              {!p.ok && p.err && <span> ({p.err})</span>}
            </div>
          ))}
        </div>
      )}
      <button className="btn btn-block btn-lg" onClick={submit} disabled={busy || okCount === 0}>
        {busy ? 'Đang thêm…' : `➕ Thêm ${okCount} món`}
      </button>
    </Sheet>
  );
}

function ProductForm({ product, categories, onClose, reload }: { product: Product | null; categories: Category[]; onClose: () => void; reload: () => Promise<void> }) {
  const toast = useToast();
  const [name, setName] = useState(product?.name ?? '');
  const [price, setPrice] = useState(String(product?.base_price ?? ''));
  const [catId, setCatId] = useState(product?.category_id ?? categories[0]?.id ?? '');
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const p = parseInt(price.replace(/\D/g, ''), 10);
    if (!name.trim() || Number.isNaN(p) || p < 0) {
      toast.show('Nhập tên và giá hợp lệ');
      return;
    }
    setBusy(true);
    try {
      if (product) {
        await updateProduct(product.id, {
          name: name.trim(),
          base_price: p,
          category_id: catId || null,
        });
      } else {
        await createProduct({ name: name.trim(), base_price: p, category_id: catId || null });
      }
      toast.show(product ? 'Đã cập nhật món' : 'Đã thêm món');
      await reload();
      onClose();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet title={product ? `✏️ Sửa món` : '➕ Thêm món'} onClose={onClose}>
      <form onSubmit={submit}>
        <div className="field">
          <label>Tên món</label>
          <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="VD: Trà Sữa Truyền Thống" />
        </div>
        <div className="field">
          <label>Giá bán (VND)</label>
          <input className="input" inputMode="numeric" value={price} onChange={(e) => setPrice(e.target.value)} placeholder="VD: 32000" />
        </div>
        <div className="field">
          <label>Danh mục</label>
          <select className="input" value={catId} onChange={(e) => setCatId(e.target.value)}>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>
        <button type="submit" className="btn btn-block btn-lg" disabled={busy}>{busy ? 'Đang lưu…' : '💾 Lưu'}</button>
      </form>
    </Sheet>
  );
}

/* ---------------- Danh mục ---------------- */
function CategoriesTab({ categories, reload }: { categories: Category[]; reload: () => Promise<void> }) {
  const toast = useToast();
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');

  const add = async (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    setBusy(true);
    try {
      await createCategory(name.trim());
      setName('');
      toast.show('Đã thêm danh mục');
      await reload();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Thêm thất bại');
    } finally {
      setBusy(false);
    }
  };

  const toggle = async (c: Category) => {
    try {
      await updateCategory(c.id, { active: !c.active });
      await reload();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Thất bại');
    }
  };

  const saveEdit = async (c: Category) => {
    if (!editName.trim()) {
      toast.show('Tên danh mục không được để trống');
      return;
    }
    try {
      await updateCategory(c.id, { name: editName.trim() });
      setEditingId(null);
      toast.show('Đã đổi tên danh mục');
      await reload();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Lưu thất bại');
    }
  };

  const remove = async (c: Category) => {
    if (!window.confirm(`Xóa danh mục “${c.name}”?\nCác món trong danh mục sẽ chuyển sang “chưa phân loại” (không bị mất).`)) return;
    try {
      const { moved } = await deleteCategory(c.id);
      toast.show(moved > 0 ? `Đã xóa danh mục, chuyển ${moved} món sang chưa phân loại` : 'Đã xóa danh mục');
      await reload();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Xóa thất bại');
    }
  };

  return (
    <>
      <form onSubmit={add} className="row" style={{ marginBottom: 12 }}>
        <input className="input grow" placeholder="Tên danh mục mới…" value={name} onChange={(e) => setName(e.target.value)} />
        <button className="btn" disabled={busy}>➕ Thêm</button>
      </form>
      <div className="card" style={{ padding: 0 }}>
        <div className="table-wrap">
          <table className="tbl">
            <tbody>
              {categories.map((c) => (
                <tr key={c.id} style={c.active ? undefined : { opacity: 0.5 }}>
                  <td style={{ minWidth: 140 }}>
                    {editingId === c.id ? (
                      <input
                        className="input"
                        value={editName}
                        onChange={(e) => setEditName(e.target.value)}
                        autoFocus
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') void saveEdit(c);
                          if (e.key === 'Escape') setEditingId(null);
                        }}
                      />
                    ) : (
                      <b>{c.name}</b>
                    )}
                  </td>
                  <td>{c.active ? '✅' : '🚫'}</td>
                  <td style={{ textAlign: 'right', whiteSpace: 'nowrap' }}>
                    {editingId === c.id ? (
                      <>
                        <button className="btn btn-sm" style={{ marginRight: 6 }} onClick={() => saveEdit(c)}>Lưu</button>
                        <button className="btn btn-sm btn-ghost" onClick={() => setEditingId(null)}>Hủy</button>
                      </>
                    ) : (
                      <>
                        <button className="btn btn-outline" style={{ minHeight: 40, padding: '6px 12px', marginRight: 6 }} onClick={() => toggle(c)}>
                          {c.active ? 'Ẩn' : 'Hiện'}
                        </button>
                        <button
                          className="btn btn-ghost"
                          style={{ minHeight: 40, padding: '6px 12px', marginRight: 6 }}
                          onClick={() => { setEditingId(c.id); setEditName(c.name); }}
                        >
                          Sửa
                        </button>
                        <button className="btn btn-ghost" style={{ minHeight: 40, padding: '6px 12px', color: '#dc2626' }} onClick={() => remove(c)}>
                          🗑️
                        </button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

/* ---------------- Modifier ---------------- */
function ModifiersTab({ groups, reload }: { groups: ModifierGroup[]; reload: () => Promise<void> }) {
  const toast = useToast();
  const [newOpt, setNewOpt] = useState<{ groupId: string; name: string; delta: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editDelta, setEditDelta] = useState('');

  const toggleOpt = async (optId: string, active: boolean) => {
    try {
      await updateModifierOption(optId, { active: !active });
      await reload();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Thất bại');
    }
  };

  const addOpt = async (e: FormEvent) => {
    e.preventDefault();
    if (!newOpt || !newOpt.name.trim()) return;
    const delta = parseInt(newOpt.delta.replace(/\D/g, ''), 10) || 0;
    setBusy(true);
    try {
      await createModifierOption(newOpt.groupId, { name: newOpt.name.trim(), price_delta: delta });
      toast.show('Đã thêm tùy chọn');
      setNewOpt(null);
      await reload();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Thêm thất bại');
    } finally {
      setBusy(false);
    }
  };

  const saveEdit = async (optId: string) => {
    const delta = parseInt(editDelta.replace(/\D/g, ''), 10);
    if (!editName.trim() || Number.isNaN(delta) || delta < 0) {
      toast.show('Nhập tên và phụ thu hợp lệ (≥ 0)');
      return;
    }
    try {
      await updateModifierOption(optId, { name: editName.trim(), price_delta: delta });
      setEditingId(null);
      toast.show('Đã lưu');
      await reload();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Lưu thất bại');
    }
  };

  const removeOpt = async (name: string, optId: string) => {
    if (!window.confirm(`Xóa hẳn “${name}”?\nĐơn hàng cũ không bị ảnh hưởng.`)) return;
    try {
      await deleteModifierOption(optId);
      toast.show(`Đã xóa “${name}”`);
      await reload();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Xóa thất bại');
    }
  };

  return (
    <>
      {groups.map((g) => (
        <div className="card" key={g.id} style={{ marginBottom: 12 }}>
          <div className="row" style={{ marginBottom: 8 }}>
            <b className="grow">
              {g.name}{' '}
              <span className="small muted">
                ({g.selection_type === 'single' ? 'chọn 1' : 'chọn nhiều'}{g.required ? ', bắt buộc' : ''})
              </span>
            </b>
            <button className="btn btn-ghost" style={{ minHeight: 40, padding: '6px 12px' }} onClick={() => setNewOpt({ groupId: g.id, name: '', delta: '' })}>
              ➕ Thêm lựa chọn
            </button>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {[...g.options].sort((a, b) => a.sort_order - b.sort_order).map((o) => (
              <div
                key={o.id}
                className="row"
                style={{
                  gap: 8,
                  alignItems: 'center',
                  padding: '8px 10px',
                  border: '1px solid var(--border)',
                  borderRadius: 10,
                  opacity: o.active ? 1 : 0.5,
                }}
              >
                {editingId === o.id ? (
                  <>
                    <input
                      className="input grow"
                      style={{ minWidth: 120 }}
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      placeholder="Tên"
                      autoFocus
                    />
                    <input
                      className="input"
                      style={{ width: 110 }}
                      inputMode="numeric"
                      value={editDelta}
                      onChange={(e) => setEditDelta(e.target.value)}
                      placeholder="+giá"
                    />
                    <button className="btn btn-sm" onClick={() => saveEdit(o.id)}>Lưu</button>
                    <button className="btn btn-sm btn-ghost" onClick={() => setEditingId(null)}>Hủy</button>
                  </>
                ) : (
                  <>
                    <span className="grow" style={{ minWidth: 0 }}>
                      <b>{o.name}</b>
                      <span className="small muted"> — {o.price_delta > 0 ? `+${formatVND(o.price_delta)}` : 'miễn phí'}</span>
                      {!o.active && <span className="small muted"> (đang ẩn)</span>}
                    </span>
                    <button className="btn btn-ghost btn-sm" onClick={() => { setEditingId(o.id); setEditName(o.name); setEditDelta(String(o.price_delta)); }}>
                      Sửa
                    </button>
                    <button className="btn btn-outline btn-sm" onClick={() => toggleOpt(o.id, o.active)}>
                      {o.active ? 'Ẩn' : 'Hiện'}
                    </button>
                    <button className="btn btn-ghost btn-sm" style={{ color: '#dc2626' }} onClick={() => removeOpt(o.name, o.id)}>
                      🗑️
                    </button>
                  </>
                )}
              </div>
            ))}
          </div>
          {newOpt?.groupId === g.id && (
            <form onSubmit={addOpt} className="row" style={{ marginTop: 10, flexWrap: 'wrap', gap: 8 }}>
              <input
                className="input grow"
                style={{ minWidth: '100%' }}
                placeholder="Tên lựa chọn (VD: Trân châu đen)"
                value={newOpt.name}
                onChange={(e) => setNewOpt({ ...newOpt, name: e.target.value })}
                autoFocus
              />
              <input
                className="input"
                style={{ width: 130, flexGrow: 1 }}
                inputMode="numeric"
                placeholder="+giá (VD: 8000)"
                value={newOpt.delta}
                onChange={(e) => setNewOpt({ ...newOpt, delta: e.target.value })}
              />
              <button className="btn" disabled={busy}>Lưu</button>
              <button type="button" className="btn btn-ghost" onClick={() => setNewOpt(null)}>Hủy</button>
            </form>
          )}
        </div>
      ))}
    </>
  );
}
