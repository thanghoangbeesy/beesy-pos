import { useCallback, useEffect, useMemo, useState } from 'react';
import { DbError, listCategories, listModifierGroups, listProducts } from '../lib/db';
import { formatVND } from '../lib/format';
import { loadMenuCache, saveMenuCache, useOnlineStatus } from '../lib/offline';
import { useToast } from '../components/Toast';
import { PageHead } from '../components/PageHead';
import { Sheet } from '../components/Sheet';
import { CustomerPickSheet } from '../components/CustomerPickSheet';
import { ModifierModal } from './ModifierModal';
import { CheckoutModal } from './CheckoutModal';
import type {
  CartLine,
  Category,
  Customer,
  ModifierGroup,
  Order,
  Product,
  SelectedModifier,
} from '../lib/types';


function lineKey(productId: string, mods: SelectedModifier[], note: string): string {
  const ids = mods.map((m) => m.option_id).sort().join(',');
  return `${productId}|${ids}|${note}`;
}



export function POS() {
  const toast = useToast();
  const { online, refreshPending } = useOnlineStatus();
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [modGroups, setModGroups] = useState<ModifierGroup[]>([]);
  const [loading, setLoading] = useState(true);
  const [fromCache, setFromCache] = useState(false);
  const [activeCat, setActiveCat] = useState<string>('all');
  const [query, setQuery] = useState('');

  const [cart, setCart] = useState<CartLine[]>([]);
  const [modProduct, setModProduct] = useState<Product | null>(null);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [cartSheetOpen, setCartSheetOpen] = useState(false);
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [customerSheet, setCustomerSheet] = useState(false);

  // Tải menu: ưu tiên db, rớt mạng → dùng cache localStorage
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [cats, prods, groups] = await Promise.all([
          listCategories(),
          listProducts(),
          listModifierGroups(),
        ]);
        if (cancelled) return;
        setCategories(cats.filter((c) => c.active));
        setProducts(prods.filter((p) => p.active));
        setModGroups(groups.filter((x) => x.active));
        saveMenuCache({ categories: cats, products: prods, modifierGroups: groups });
        setFromCache(false);
      } catch (e) {
        const cache = loadMenuCache();
        if (cache && !cancelled) {
          setCategories(cache.categories.filter((c) => c.active));
          setProducts(cache.products.filter((p) => p.active));
          setModGroups(cache.modifierGroups.filter((x) => x.active));
          setFromCache(true);
          if (e instanceof DbError && e.code === 'unavailable') toast.show('Đang offline — dùng menu đã lưu');
          else toast.show('Không tải được menu, dùng bản lưu');
        } else if (!cancelled) {
          toast.show('Không tải được menu');
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const filtered = useMemo(() => {
    let list = products;
    if (activeCat !== 'all') list = list.filter((p) => p.category_id === activeCat);
    const q = query.trim().toLowerCase();
    if (q) list = list.filter((p) => p.name.toLowerCase().includes(q));
    return [...list].sort((a, b) => a.sort_order - b.sort_order);
  }, [products, activeCat, query]);

  const addLine = useCallback((product: Product, modifiers: SelectedModifier[], note: string, qty = 1) => {
    const key = lineKey(product.id, modifiers, note);
    setCart((prev) => {
      const i = prev.findIndex((l) => l.key === key);
      if (i >= 0) {
        const next = [...prev];
        next[i] = { ...next[i], qty: next[i].qty + qty };
        return next;
      }
      return [...prev, { key, product, qty, modifiers, note }];
    });
  }, []);

  const setQty = useCallback((key: string, qty: number) => {
    setCart((prev) =>
      qty <= 0 ? prev.filter((l) => l.key !== key) : prev.map((l) => (l.key === key ? { ...l, qty } : l)),
    );
  }, []);

  const clearCart = useCallback(() => {
    setCart([]);
    setCustomer(null);
  }, []);

  const totalQty = cart.reduce((s, l) => s + l.qty, 0);
  const grandTotal = cart.reduce((s, l) => s + l.qty * (l.product.base_price + l.modifiers.reduce((a, m) => a + m.price_delta, 0)), 0);

  const unitPrice = (l: CartLine) => l.product.base_price + l.modifiers.reduce((a, m) => a + m.price_delta, 0);

  // Tổng số lượng từng món (gộp các dòng cùng product id, kể cả khác topping)
  const qtyByProduct = useMemo(() => {
    const m: Record<string, number> = {};
    for (const l of cart) m[l.product.id] = (m[l.product.id] ?? 0) + l.qty;
    return m;
  }, [cart]);

  const openModifier = (p: Product) => {
    if (!modGroups.length) {
      addLine(p, [], '');
      toast.show(`Đã thêm ${p.name}`);
      return;
    }
    setModProduct(p);
  };

  const cartBody = (inSheet: boolean) => (
    <>
      <div className={inSheet ? 'cart-sheet-lines' : 'cart-lines'}>
        {cart.length === 0 ? (
          <div className="cart-empty">🛒 Giỏ hàng trống<br />Chạm vào món để thêm</div>
        ) : (
          cart.map((l) => (
            <div className="cart-line" key={l.key}>
              <div className="grow">
                <div className="lname">{l.product.name}</div>
                {l.modifiers.length > 0 && (
                  <div className="lmods">
                    {l.modifiers.map((m) => m.option).join(' · ')}
                    {l.modifiers.some((m) => m.price_delta > 0) && (
                      <span className="plus"> (+{formatVND(l.modifiers.reduce((a, m) => a + m.price_delta, 0))})</span>
                    )}
                  </div>
                )}
                {l.note && <div className="lmods">📝 {l.note}</div>}
                <div className="money">{formatVND(unitPrice(l))}</div>
              </div>
              <div className="qty-ctl">
                <button className="qty-btn" onClick={() => setQty(l.key, l.qty - 1)} aria-label="Giảm">−</button>
                <span className="qty-num">{l.qty}</span>
                <button className="qty-btn" onClick={() => setQty(l.key, l.qty + 1)} aria-label="Tăng">+</button>
              </div>
            </div>
          ))
        )}
      </div>
      <div className="cart-total">
        {customer && (
          <div className="trow small">
            <span>👤 {customer.name} ({customer.phone})</span>
            <button className="btn btn-ghost btn-sm" onClick={() => setCustomer(null)}>
              Bỏ
            </button>
          </div>
        )}
        <div className="trow grand">
          <span>Tổng cộng</span>
          <span className="money">{formatVND(grandTotal)}</span>
        </div>
      </div>
      <div className="cart-actions">
        <button className="btn btn-outline btn-block" onClick={() => setCustomerSheet(true)}>
          {customer ? '👤 Đổi khách hàng' : '👤 Chọn khách hàng (tích tem)'}
        </button>
        <button className="btn btn-green btn-block btn-lg" disabled={cart.length === 0} onClick={() => setCheckoutOpen(true)}>
          💳 Thanh toán
        </button>
        {cart.length > 0 && (
          <button className="btn btn-ghost btn-block" onClick={clearCart}>
            Xóa giỏ
          </button>
        )}
      </div>
    </>
  );

  return (
    <div className="pos">
      <div className="pos-left">
        <PageHead title="Bán hàng" />
        <div className="row" style={{ gap: 8, marginBottom: 10 }}>
          <div className="sb-search grow">
            <span className="sico">🔍</span>
            <input
              placeholder="Tìm theo tên món…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>
          {fromCache && <span className="small muted">📦 menu offline</span>}
        </div>
        <div className="chip-row">
          <button
            className={`sb-chip${activeCat === 'all' ? ' selected' : ''}`}
            onClick={() => setActiveCat('all')}
          >
            Tất cả
          </button>
          {categories.map((c) => (
            <button
              key={c.id}
              className={`sb-chip${activeCat === c.id ? ' selected' : ''}`}
              onClick={() => setActiveCat(c.id)}
            >
              {c.name}
            </button>
          ))}
        </div>
        {loading ? (
          <div className="card">Đang tải menu…</div>
        ) : filtered.length === 0 ? (
          <div className="card muted">Không có món nào. {online ? 'Thêm món ở trang Menu.' : 'Kiểm tra mạng.'}</div>
        ) : (
          <div className="product-grid">
            {filtered.map((p) => {
              const q = qtyByProduct[p.id] ?? 0;
              const lastLine = q > 0 ? [...cart].reverse().find((l) => l.product.id === p.id) : undefined;
              return (
                <button
                  key={p.id}
                  className={`product-card${q > 0 ? ' in-cart' : ''}`}
                  onClick={() => openModifier(p)}
                >
                  <span className="pname">{p.name}</span>
                  <span className="pprice">{formatVND(p.base_price)}</span>
                  {q > 0 && (
                    <span className="pstep">
                      <button
                        aria-label="Giảm"
                        onClick={(e) => {
                          e.stopPropagation();
                          if (lastLine) setQty(lastLine.key, lastLine.qty - 1);
                        }}
                      >
                        −
                      </button>
                      <span className="qty-num">{q}</span>
                      <button
                        aria-label="Tăng"
                        onClick={(e) => {
                          e.stopPropagation();
                          openModifier(p);
                        }}
                      >
                        +
                      </button>
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        )}
      </div>

      <aside className="pos-right">
        <div className="cart">
          <div className="cart-head">
            <span>Giỏ hàng</span>
            {totalQty > 0 && <span className="money">{totalQty} món</span>}
          </div>
          {cartBody(false)}
        </div>
      </aside>

      {totalQty > 0 && !checkoutOpen && (
        <button className="sb-cart-bar" onClick={() => setCheckoutOpen(true)}>
          <span>
            Số lượng<span className="qty-badge">{totalQty}</span>
          </span>
          <span className="money">{formatVND(grandTotal)} ›</span>
        </button>
      )}

      {cartSheetOpen && (
        <Sheet title={`🧾 Giỏ hàng (${totalQty} món)`} onClose={() => setCartSheetOpen(false)}>
          {cartBody(true)}
        </Sheet>
      )}

      {modProduct && (
        <ModifierModal
          product={modProduct}
          groups={modGroups}
          onClose={() => setModProduct(null)}
          onAdd={(mods, note, qty) => {
            addLine(modProduct, mods, note, qty);
            setModProduct(null);
            toast.show(`Đã thêm ${modProduct.name}`);
          }}
        />
      )}

      {checkoutOpen && (
        <CheckoutModal
          lines={cart}
          customer={customer}
          total={grandTotal}
          onClose={() => setCheckoutOpen(false)}
          onUpdateQty={setQty}
          onCustomerChange={setCustomer}
          onDone={(order: Order | null, queued: boolean) => {
            setCheckoutOpen(false);
            setCartSheetOpen(false);
            clearCart();
            refreshPending();
            if (queued) toast.show('Đã lưu đơn chờ — sẽ tự đồng bộ khi có mạng');
            else if (order) toast.show(`Tạo đơn ${order.code} thành công`);
          }}
        />
      )}

      {customerSheet && (
        <CustomerPickSheet
          onClose={() => setCustomerSheet(false)}
          onPick={(c) => {
            setCustomer(c);
            setCustomerSheet(false);
            toast.show(`Đã chọn khách: ${c.name}`);
          }}
        />
      )}
    </div>
  );
}
