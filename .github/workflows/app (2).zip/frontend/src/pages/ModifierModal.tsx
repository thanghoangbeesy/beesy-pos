import { useMemo, useState } from 'react';
import { Sheet } from '../components/Sheet';
import { formatVND } from '../lib/format';
import type { ModifierGroup, ModifierOption, Product, SelectedModifier } from '../lib/types';

// Bottom-sheet chọn modifier: single = lưới chọn 1, multi = chọn nhiều + giá, ghi chú, tổng live
export function ModifierModal({
  product,
  groups,
  onAdd,
  onClose,
}: {
  product: Product;
  groups: ModifierGroup[];
  onAdd: (mods: SelectedModifier[], note: string, qty: number) => void;
  onClose: () => void;
}) {
  const active = useMemo(
    () =>
      [...groups]
        .filter((g) => g.active)
        .sort((a, b) => a.sort_order - b.sort_order)
        .map((g) => ({ ...g, options: g.options.filter((o) => o.active).sort((a, b) => a.sort_order - b.sort_order) }))
        .filter((g) => g.options.length > 0),
    [groups],
  );

  // Mặc định: nhóm single bắt buộc → chọn option đầu tiên (giảm tap)
  const [sel, setSel] = useState<Record<string, string[]>>(() => {
    const init: Record<string, string[]> = {};
    for (const g of active) {
      if (g.selection_type === 'single') init[g.id] = g.required && g.options[0] ? [g.options[0].id] : [];
      else init[g.id] = [];
    }
    return init;
  });
  const [note, setNote] = useState('');
  const [qty, setQty] = useState(1);

  const optById = useMemo(() => {
    const m = new Map<string, { opt: ModifierOption; group: ModifierGroup }>();
    for (const g of active) for (const o of g.options) m.set(o.id, { opt: o, group: g });
    return m;
  }, [active]);

  const toggle = (group: ModifierGroup, optionId: string) => {
    setSel((prev) => {
      const cur = prev[group.id] ?? [];
      if (group.selection_type === 'single') return { ...prev, [group.id]: [optionId] };
      return {
        ...prev,
        [group.id]: cur.includes(optionId) ? cur.filter((id) => id !== optionId) : [...cur, optionId],
      };
    });
  };

  const selected: SelectedModifier[] = useMemo(
    () =>
      Object.values(sel)
        .flat()
        .map((id) => optById.get(id))
        .filter((x): x is { opt: ModifierOption; group: ModifierGroup } => !!x)
        .map(({ opt, group }) => ({
          option_id: opt.id,
          group: group.name,
          option: opt.name,
          price_delta: opt.price_delta,
        })),
    [sel, optById],
  );

  const unitTotal = product.base_price + selected.reduce((s, m) => s + m.price_delta, 0);
  const missingRequired = active.some((g) => g.required && (sel[g.id] ?? []).length === 0);

  const submit = () => {
    if (missingRequired) return;
    onAdd(selected, note.trim(), qty);
  };

  return (
    <Sheet
      title={`${product.name} — ${formatVND(product.base_price)}`}
      onClose={onClose}
      footer={
        <div>
          <div className="row" style={{ marginBottom: 10 }}>
            <div className="qty-ctl">
              <button className="qty-btn" onClick={() => setQty((q) => Math.max(1, q - 1))} aria-label="Giảm số lượng">−</button>
              <span className="qty-num">{qty}</span>
              <button className="qty-btn" onClick={() => setQty((q) => q + 1)} aria-label="Tăng số lượng">+</button>
            </div>
            <span className="grow" />
            <span className="money" style={{ fontSize: 22 }}>
              {formatVND(unitTotal * qty)}
            </span>
          </div>
          <button className="btn btn-green btn-block btn-lg" disabled={missingRequired} onClick={submit}>
            ➕ Thêm vào giỏ
          </button>
          {missingRequired && <div className="small text-red" style={{ marginTop: 6, textAlign: 'center' }}>Vui lòng chọn đủ các mục bắt buộc (*)</div>}
        </div>
      }
    >
      {active.map((g) => (
        <div className="mod-group" key={g.id}>
          <h4>
            {g.name}
            {g.required && <span className="req">* bắt buộc</span>}
            {g.selection_type === 'multi' && <span className="req muted">· chọn nhiều</span>}
          </h4>
          <div className="opt-grid">
            {g.options.map((o) => {
              const on = (sel[g.id] ?? []).includes(o.id);
              return (
                <button key={o.id} className={`opt-btn${on ? ' selected' : ''}`} onClick={() => toggle(g, o.id)}>
                  {on ? '✅ ' : ''}{o.name}
                  <span className="delta">{o.price_delta > 0 ? `+${formatVND(o.price_delta)}` : o.price_delta < 0 ? formatVND(o.price_delta) : 'miễn phí'}</span>
                </button>
              );
            })}
          </div>
        </div>
      ))}
      <div className="field">
        <label htmlFor="mod-note">📝 Ghi chú cho pha chế</label>
        <input
          id="mod-note"
          className="input"
          placeholder="VD: ít đá, mang đi xa…"
          value={note}
          onChange={(e) => setNote(e.target.value)}
        />
      </div>
    </Sheet>
  );
}
