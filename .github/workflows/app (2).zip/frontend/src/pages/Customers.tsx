import { useEffect, useState } from 'react';
import type { FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  DbError,
  adjustDebt,
  createCustomer,
  getCustomer,
  getSettings,
  listDebtLogs,
  redeemReward,
  searchCustomers,
  updateCustomer,
} from '../lib/db';
import { formatDateTime, formatVND } from '../lib/format';
import { Sheet } from '../components/Sheet';
import { PageHead } from '../components/PageHead';
import { useToast } from '../components/Toast';
import type { Customer, DebtLog } from '../lib/types';

export function Customers() {
  const navigate = useNavigate();
  const toast = useToast();
  const [q, setQ] = useState('');
  const [list, setList] = useState<Customer[]>([]);
  const [busy, setBusy] = useState(false);
  const [selected, setSelected] = useState<Customer | null>(null);
  const [formOpen, setFormOpen] = useState<Customer | 'new' | null>(null);
  const [stampsTarget, setStampsTarget] = useState(9);

  useEffect(() => {
    getSettings().then((s) => {
      const t = parseInt(s.stamps_target ?? '', 10);
      if (!Number.isNaN(t) && t > 0) setStampsTarget(t);
    }).catch(() => {});
    void search('');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const search = async (keyword: string) => {
    setBusy(true);
    try {
      const data = await searchCustomers(keyword.trim());
      setList(data);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tìm được');
    } finally {
      setBusy(false);
    }
  };

  const openDetail = async (id: string) => {
    try {
      const c = await getCustomer(id);
      setSelected(c);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không mở được');
    }
  };

  return (
    <div className="page">
      <PageHead title="Khách hàng" />

      <div className="sb-search" style={{ marginBottom: 12 }}>
        <span className="sico">🔍</span>
        <input
          placeholder="Tìm tên, số điện thoại…"
          value={q}
          onChange={(e) => {
            setQ(e.target.value);
            void search(e.target.value);
          }}
          aria-label="Tìm khách hàng"
        />
      </div>

      <button className="sb-menu-row" onClick={() => navigate('/debt')} style={{ marginBottom: 12, borderRadius: 14, background: 'var(--surface)', boxShadow: 'var(--shadow)' }}>
        <span className="sb-ico-box" style={{ background: '#F3E8FF' }}>📒</span>
        <span>Sổ nợ</span>
        <span className="chev">›</span>
      </button>

      <div className="sb-section" style={{ padding: '4px 16px' }}>
        {list.map((c) => (
          <button key={c.id} className="sb-row" onClick={() => openDetail(c.id)}>
            <span className="avatar">{c.name.charAt(0).toUpperCase()}</span>
            <span className="rbody">
              <span className="rtitle">
                {c.name}
                {c.reward_available ? ' 🎁' : ''}
              </span>
              <span className="rsub">{c.phone}</span>
            </span>
            <span style={{ textAlign: 'right', flexShrink: 0 }}>
              <span className="small muted" style={{ display: 'block' }}>
                🎟️ {c.stamps}/{stampsTarget}
              </span>
              {c.debt > 0 && (
                <span className="ramount text-orange" style={{ display: 'block', marginTop: 2 }}>
                  {formatVND(c.debt)}
                </span>
              )}
            </span>
            <span className="chev muted" style={{ fontSize: 22 }}>›</span>
          </button>
        ))}
        {list.length === 0 && !busy && (
          <div className="sb-empty">
            <div className="eico">👥</div>
            <p>
              Chưa có khách hàng nào.
              <br />
              Thêm khách để tích tem và theo dõi công nợ.
            </p>
          </div>
        )}
      </div>

      <button className="fab" onClick={() => setFormOpen('new')} aria-label="Thêm khách hàng mới">
        +
      </button>

      {selected && (
        <CustomerDetail
          customer={selected}
          stampsTarget={stampsTarget}
          onClose={() => setSelected(null)}
          onEdit={() => setFormOpen(selected)}
          onChanged={(c) => {
            setSelected(c);
            void search(q);
          }}
        />
      )}
      {formOpen && (
        <CustomerForm
          customer={formOpen === 'new' ? null : formOpen}
          onClose={() => setFormOpen(null)}
          onSaved={() => void search(q)}
        />
      )}
    </div>
  );
}

function CustomerDetail({ customer, stampsTarget, onClose, onEdit, onChanged }: {
  customer: Customer;
  stampsTarget: number;
  onClose: () => void;
  onEdit: () => void;
  onChanged: (c: Customer) => void;
}) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);

  const redeem = async () => {
    const lastOrder = customer.recent_orders?.[0];
    if (!lastOrder) {
      toast.show('Khách chưa có đơn nào để đổi thưởng');
      return;
    }
    if (!window.confirm(`Đổi thưởng cho ${customer.name}? (mua ${stampsTarget} tặng 1)`)) return;
    setBusy(true);
    try {
      await redeemReward(customer.id);
      toast.show('🎁 Đã đổi thưởng thành công!');
      const c = await getCustomer(customer.id);
      if (c) onChanged(c);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Đổi thưởng thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet title={customer.name} onClose={onClose}>
      <div className="sb-section">
        <div className="row" style={{ marginBottom: 8 }}>
          <h3 className="sb-section-title grow" style={{ margin: 0 }}>Thông tin</h3>
          <button className="btn btn-ghost btn-sm" style={{ minHeight: 44, padding: '6px 12px' }} onClick={onEdit}>
            Sửa
          </button>
        </div>
        <div className="row small" style={{ marginBottom: 6 }}>
          <span className="muted grow">Số điện thoại</span>
          <b>{customer.phone}</b>
        </div>
        {customer.birthday && (
          <div className="row small" style={{ marginBottom: 6 }}>
            <span className="muted grow">Ngày sinh</span>
            <b>{customer.birthday}</b>
          </div>
        )}
        {customer.address && (
          <div className="row small" style={{ marginBottom: 6 }}>
            <span className="muted grow">Địa chỉ</span>
            <b>{customer.address}</b>
          </div>
        )}
        {customer.note && <div className="small muted" style={{ marginTop: 6 }}>{customer.note}</div>}
      </div>

      <div className="sb-section">
        <h3 className="sb-section-title">
          Tích tem <span className="muted">({customer.stamps}/{stampsTarget})</span>
        </h3>
        <div className="stamps">
          {Array.from({ length: stampsTarget }).map((_, i) => (
            <span key={i} className={`stamp${i < customer.stamps ? ' on' : ''}`}>{i < customer.stamps ? '☕' : '·'}</span>
          ))}
        </div>
        {customer.reward_available ? (
          <button className="btn btn-green btn-block" style={{ minHeight: 48, marginTop: 8 }} disabled={busy} onClick={redeem}>
            🎁 Đổi thưởng (mua {stampsTarget} tặng 1)
          </button>
        ) : (
          <p className="small muted" style={{ margin: 0 }}>
            Còn {stampsTarget - customer.stamps} tem nữa để nhận 1 ly miễn phí.
          </p>
        )}
      </div>

      <DebtCard
        customer={customer}
        onChanged={async () => {
          const c = await getCustomer(customer.id);
          if (c) onChanged(c);
        }}
      />

      <div className="sb-section" style={{ padding: '8px 16px' }}>
        <h3 className="sb-section-title" style={{ margin: '6px 0 4px' }}>Đơn gần nhất</h3>
        {(customer.recent_orders ?? []).map((o) => (
          <div key={o.id} className="sb-row" style={{ cursor: 'default' }}>
            <span className="rbody">
              <span className="rtitle">{o.code}</span>
              <span className="rsub">{formatDateTime(o.created_at)}</span>
            </span>
            <span className="ramount">{formatVND(o.total)}</span>
          </div>
        ))}
        {(customer.recent_orders ?? []).length === 0 && (
          <p className="muted small" style={{ margin: '8px 0' }}>Chưa có đơn nào</p>
        )}
      </div>
    </Sheet>
  );
}

function DebtCard({ customer, onChanged }: { customer: Customer; onChanged: () => Promise<void> }) {
  const toast = useToast();
  const [logs, setLogs] = useState<DebtLog[]>([]);
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    listDebtLogs(customer.id).then(setLogs).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [customer.id, customer.debt]);

  const submit = async (isPayment: boolean) => {
    const v = parseInt(amount.replace(/\D/g, ''), 10);
    if (!v || v <= 0) {
      toast.show('Nhập số tiền hợp lệ');
      return;
    }
    setBusy(true);
    try {
      await adjustDebt(customer.id, isPayment ? -v : v, note.trim() || null);
      toast.show(isPayment ? `Đã thu ${formatVND(v)}` : `Đã ghi nợ ${formatVND(v)}`);
      setAmount('');
      setNote('');
      await onChanged();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Cập nhật công nợ thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="sb-section">
      <div className="row" style={{ marginBottom: 12 }}>
        <h3 className="sb-section-title grow" style={{ margin: 0 }}>Công nợ</h3>
        <b className="money text-orange" style={{ fontSize: 20 }}>
          {formatVND(customer.debt)}
        </b>
      </div>
      <div className="sb-float">
        <input
          inputMode="numeric"
          placeholder=" "
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
        <label>Số tiền</label>
      </div>
      <div className="sb-float">
        <input
          placeholder=" "
          value={note}
          onChange={(e) => setNote(e.target.value)}
        />
        <label>Ghi chú (không bắt buộc)</label>
      </div>
      <div className="row" style={{ gap: 12, marginBottom: 4 }}>
        <button className="btn sb-btn-orange btn-block" style={{ minHeight: 48 }} disabled={busy} onClick={() => submit(false)}>
          Ghi nợ
        </button>
        <button className="btn btn-block" style={{ minHeight: 48 }} disabled={busy || customer.debt <= 0} onClick={() => submit(true)}>
          Thu nợ
        </button>
      </div>
      {logs.length > 0 && (
        <div style={{ marginTop: 4 }}>
          {logs.map((l) => (
            <div key={l.id} className="sb-row" style={{ cursor: 'default' }}>
              <span className="rbody">
                <span className="rsub" style={{ marginTop: 0 }}>{formatDateTime(l.created_at)}</span>
                {l.note && <span className="rtitle" style={{ fontSize: 14, fontWeight: 500 }}>{l.note}</span>}
              </span>
              <span style={{ textAlign: 'right', flexShrink: 0 }}>
                <b className={l.amount > 0 ? 'text-red' : 'text-green'}>
                  {l.amount > 0 ? '+' : '−'}{formatVND(Math.abs(l.amount))}
                </b>
                <span className="small muted" style={{ display: 'block' }}>Còn {formatVND(l.balance_after)}</span>
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function CustomerForm({ customer, onClose, onSaved }: {
  customer: Customer | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const toast = useToast();
  const [name, setName] = useState(customer?.name ?? '');
  const [phone, setPhone] = useState(customer?.phone ?? '');
  const [birthday, setBirthday] = useState(customer?.birthday ?? '');
  const [address, setAddress] = useState(customer?.address ?? '');
  const [note, setNote] = useState(customer?.note ?? '');
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) {
      toast.show('Nhập tên và SĐT');
      return;
    }
    setBusy(true);
    try {
      const body = { name: name.trim(), phone: phone.trim(), birthday: birthday || null, address: address.trim() || null, note: note.trim() || null };
      if (customer) await updateCustomer(customer.id, body);
      else await createCustomer(body);
      toast.show(customer ? 'Đã cập nhật' : 'Đã thêm khách hàng');
      onSaved();
      onClose();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet title={customer ? 'Sửa khách hàng' : 'Thêm khách hàng'} onClose={onClose}>
      <form onSubmit={submit}>
        <div className="sb-float">
          <input placeholder=" " value={name} onChange={(e) => setName(e.target.value)} />
          <label>Tên <span className="req">*</span></label>
        </div>
        <div className="sb-float">
          <input placeholder=" " inputMode="tel" value={phone} onChange={(e) => setPhone(e.target.value)} />
          <label>SĐT <span className="req">*</span></label>
        </div>
        <div className="sb-float">
          <input placeholder=" " type="date" value={birthday} onChange={(e) => setBirthday(e.target.value)} />
          <label>Ngày sinh</label>
        </div>
        <div className="sb-float">
          <input placeholder=" " value={address} onChange={(e) => setAddress(e.target.value)} />
          <label>Địa chỉ</label>
        </div>
        <div className="sb-float">
          <textarea placeholder=" " value={note} onChange={(e) => setNote(e.target.value)} />
          <label>Ghi chú</label>
        </div>
        <button type="submit" className="btn btn-block btn-lg" style={{ minHeight: 52 }} disabled={busy}>
          {busy ? 'Đang lưu…' : 'Lưu'}
        </button>
      </form>
    </Sheet>
  );
}
