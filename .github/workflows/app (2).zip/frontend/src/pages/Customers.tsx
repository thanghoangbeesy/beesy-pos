import { useEffect, useState } from 'react';
import type { FormEvent } from 'react';
import {
  DbError,
  adjustDebt,
  createCustomer,
  getCustomer,
  getSettings,
  listDebtLogs,
  redeemReward,
  searchCustomers,
  updateCustomer,
} from '../lib/db';
import { formatDateTime, formatVND } from '../lib/format';
import { Sheet } from '../components/Sheet';
import { useToast } from '../components/Toast';
import type { Customer, DebtLog } from '../lib/types';

export function Customers() {
  const toast = useToast();
  const [q, setQ] = useState('');
  const [list, setList] = useState<Customer[]>([]);
  const [busy, setBusy] = useState(false);
  const [selected, setSelected] = useState<Customer | null>(null);
  const [formOpen, setFormOpen] = useState<Customer | 'new' | null>(null);
  const [stampsTarget, setStampsTarget] = useState(9);

  useEffect(() => {
    getSettings().then((s) => {
      const t = parseInt(s.stamps_target ?? '', 10);
      if (!Number.isNaN(t) && t > 0) setStampsTarget(t);
    }).catch(() => {});
    void search('');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const search = async (keyword: string) => {
    setBusy(true);
    try {
      const data = await searchCustomers(keyword.trim());
      setList(data);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tìm được');
    } finally {
      setBusy(false);
    }
  };

  const openDetail = async (id: string) => {
    try {
      const c = await getCustomer(id);
      setSelected(c);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không mở được');
    }
  };

  return (
    <div className="page">
      <div className="row" style={{ marginBottom: 14 }}>
        <h1 style={{ margin: 0 }} className="grow">👥 Khách hàng</h1>
        <button className="btn" onClick={() => setFormOpen('new')}>➕ Thêm khách</button>
      </div>
      <form
        className="row"
        style={{ marginBottom: 12 }}
        onSubmit={(e) => {
          e.preventDefault();
          void search(q);
        }}
      >
        <input className="input grow" placeholder="🔍 Tìm theo tên hoặc SĐT…" value={q} onChange={(e) => setQ(e.target.value)} />
        <button className="btn" disabled={busy}>Tìm</button>
      </form>

      <div className="card" style={{ padding: 0 }}>
        <div className="table-wrap">
          <table className="tbl">
            <thead><tr><th>Tên</th><th>SĐT</th><th>Tem</th><th>Công nợ</th><th></th></tr></thead>
            <tbody>
              {list.map((c) => (
                <tr key={c.id}>
                  <td><b>{c.name}</b>{c.reward_available && ' 🎁'}</td>
                  <td>{c.phone}</td>
                  <td>{c.stamps}/{stampsTarget}</td>
                  <td style={{ textAlign: 'right' }}>
                    {c.debt > 0 ? <span className="money" style={{ color: 'var(--red)' }}>{formatVND(c.debt)}</span> : <span className="muted">—</span>}
                  </td>
                  <td style={{ textAlign: 'right', whiteSpace: 'nowrap' }}>
                    <button className="btn btn-outline" style={{ minHeight: 40, padding: '6px 12px', marginRight: 6 }} onClick={() => openDetail(c.id)}>
                      Chi tiết
                    </button>
                    <button className="btn btn-ghost" style={{ minHeight: 40, padding: '6px 12px' }} onClick={() => setFormOpen(c)}>
                      Sửa
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {list.length === 0 && !busy && <div className="muted" style={{ padding: 16, textAlign: 'center' }}>Chưa có khách hàng nào</div>}
      </div>

      {selected && (
        <CustomerDetail
          customer={selected}
          stampsTarget={stampsTarget}
          onClose={() => setSelected(null)}
          onChanged={(c) => {
            setSelected(c);
            void search(q);
          }}
        />
      )}
      {formOpen && (
        <CustomerForm
          customer={formOpen === 'new' ? null : formOpen}
          onClose={() => setFormOpen(null)}
          onSaved={() => void search(q)}
        />
      )}
    </div>
  );
}

function CustomerDetail({ customer, stampsTarget, onClose, onChanged }: {
  customer: Customer;
  stampsTarget: number;
  onClose: () => void;
  onChanged: (c: Customer) => void;
}) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);

  const redeem = async () => {
    const lastOrder = customer.recent_orders?.[0];
    if (!lastOrder) {
      toast.show('Khách chưa có đơn nào để đổi thưởng');
      return;
    }
    if (!window.confirm(`Đổi thưởng cho ${customer.name}? (mua ${stampsTarget} tặng 1)`)) return;
    setBusy(true);
    try {
      await redeemReward(customer.id);
      toast.show('🎁 Đã đổi thưởng thành công!');
      const c = await getCustomer(customer.id);
      if (c) onChanged(c);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Đổi thưởng thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet title={`👤 ${customer.name}`} onClose={onClose}>
      <div className="card" style={{ marginBottom: 12 }}>
        <div className="row small" style={{ marginBottom: 4 }}><span className="muted">📞 SĐT:</span><b>{customer.phone}</b></div>
        {customer.birthday && <div className="row small" style={{ marginBottom: 4 }}><span className="muted">🎂 Sinh nhật:</span><b>{customer.birthday}</b></div>}
        {customer.address && <div className="row small" style={{ marginBottom: 4 }}><span className="muted">📍 Địa chỉ:</span><b>{customer.address}</b></div>}
        {customer.note && <div className="small" style={{ marginTop: 6 }}>📝 {customer.note}</div>}
      </div>

      <div className="card" style={{ marginBottom: 12 }}>
        <b>🎟️ Tiến trình tích tem ({customer.stamps}/{stampsTarget})</b>
        <div className="stamps">
          {Array.from({ length: stampsTarget }).map((_, i) => (
            <span key={i} className={`stamp${i < customer.stamps ? ' on' : ''}`}>{i < customer.stamps ? '☕' : '·'}</span>
          ))}
        </div>
        {customer.reward_available ? (
          <button className="btn btn-green btn-block" disabled={busy} onClick={redeem}>
            🎁 Đổi thưởng (mua {stampsTarget} tặng 1)
          </button>
        ) : (
          <p className="small muted" style={{ margin: 0 }}>
            Còn {stampsTarget - customer.stamps} tem nữa để nhận 1 ly miễn phí.
          </p>
        )}
      </div>

      <DebtCard
        customer={customer}
        onChanged={async () => {
          const c = await getCustomer(customer.id);
          if (c) onChanged(c);
        }}
      />

      <div className="card">
        <b>🧾 20 đơn gần nhất</b>
        <div className="table-wrap">
          <table className="tbl">
            <tbody>
              {(customer.recent_orders ?? []).map((o) => (
                <tr key={o.id}>
                  <td><b>{o.code}</b><br /><span className="small muted">{formatDateTime(o.created_at)}</span></td>
                  <td style={{ textAlign: 'right' }}><span className="money">{formatVND(o.total)}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {(customer.recent_orders ?? []).length === 0 && <p className="muted small">Chưa có đơn nào</p>}
      </div>
    </Sheet>
  );
}

function DebtCard({ customer, onChanged }: { customer: Customer; onChanged: () => Promise<void> }) {
  const toast = useToast();
  const [logs, setLogs] = useState<DebtLog[]>([]);
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    listDebtLogs(customer.id).then(setLogs).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [customer.id, customer.debt]);

  const submit = async (isPayment: boolean) => {
    const v = parseInt(amount.replace(/\D/g, ''), 10);
    if (!v || v <= 0) {
      toast.show('Nhập số tiền hợp lệ');
      return;
    }
    setBusy(true);
    try {
      await adjustDebt(customer.id, isPayment ? -v : v, note.trim() || null);
      toast.show(isPayment ? `Đã thu ${formatVND(v)}` : `Đã ghi nợ ${formatVND(v)}`);
      setAmount('');
      setNote('');
      await onChanged();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Cập nhật công nợ thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="card" style={{ marginBottom: 12 }}>
      <div className="row" style={{ marginBottom: 8 }}>
        <b>💰 Công nợ</b>
        <span className="grow" />
        <b className="money" style={{ fontSize: 20, color: customer.debt > 0 ? 'var(--red)' : undefined }}>
          {formatVND(customer.debt)}
        </b>
      </div>
      <div className="row" style={{ marginBottom: 8 }}>
        <input
          className="input grow"
          inputMode="numeric"
          placeholder="Số tiền…"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
      </div>
      <div className="row" style={{ marginBottom: 8 }}>
        <input
          className="input grow"
          placeholder="Ghi chú (không bắt buộc)…"
          value={note}
          onChange={(e) => setNote(e.target.value)}
        />
      </div>
      <div className="row">
        <button className="btn btn-outline grow" disabled={busy} onClick={() => submit(false)}>
          ➕ Ghi nợ thêm
        </button>
        <button className="btn btn-green grow" disabled={busy || customer.debt <= 0} onClick={() => submit(true)}>
          ✅ Thu nợ
        </button>
      </div>
      {logs.length > 0 && (
        <div className="table-wrap" style={{ marginTop: 8 }}>
          <table className="tbl">
            <tbody>
              {logs.map((l) => (
                <tr key={l.id}>
                  <td>
                    <span className="small muted">{formatDateTime(l.created_at)}</span>
                    {l.note && <><br /><span className="small">{l.note}</span></>}
                  </td>
                  <td style={{ textAlign: 'right', whiteSpace: 'nowrap' }}>
                    <b style={{ color: l.amount > 0 ? 'var(--red)' : 'var(--green)' }}>
                      {l.amount > 0 ? '+' : '−'}{formatVND(Math.abs(l.amount))}
                    </b>
                    <br />
                    <span className="small muted">Còn {formatVND(l.balance_after)}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function CustomerForm({ customer, onClose, onSaved }: {
  customer: Customer | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const toast = useToast();
  const [name, setName] = useState(customer?.name ?? '');
  const [phone, setPhone] = useState(customer?.phone ?? '');
  const [birthday, setBirthday] = useState(customer?.birthday ?? '');
  const [address, setAddress] = useState(customer?.address ?? '');
  const [note, setNote] = useState(customer?.note ?? '');
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) {
      toast.show('Nhập tên và SĐT');
      return;
    }
    setBusy(true);
    try {
      const body = { name: name.trim(), phone: phone.trim(), birthday: birthday || null, address: address.trim() || null, note: note.trim() || null };
      if (customer) await updateCustomer(customer.id, body);
      else await createCustomer(body);
      toast.show(customer ? 'Đã cập nhật' : 'Đã thêm khách hàng');
      onSaved();
      onClose();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet title={customer ? '✏️ Sửa khách hàng' : '➕ Thêm khách hàng'} onClose={onClose}>
      <form onSubmit={submit}>
        <div className="field"><label>Tên *</label><input className="input" value={name} onChange={(e) => setName(e.target.value)} /></div>
        <div className="field"><label>SĐT *</label><input className="input" inputMode="tel" value={phone} onChange={(e) => setPhone(e.target.value)} /></div>
        <div className="field"><label>Ngày sinh</label><input className="input" type="date" value={birthday} onChange={(e) => setBirthday(e.target.value)} /></div>
        <div className="field"><label>Địa chỉ</label><input className="input" value={address} onChange={(e) => setAddress(e.target.value)} /></div>
        <div className="field"><label>Ghi chú</label><textarea className="input" value={note} onChange={(e) => setNote(e.target.value)} /></div>
        <button type="submit" className="btn btn-block btn-lg" disabled={busy}>{busy ? 'Đang lưu…' : '💾 Lưu'}</button>
      </form>
    </Sheet>
  );
}
