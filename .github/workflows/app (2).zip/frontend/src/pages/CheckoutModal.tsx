import { useEffect, useState } from 'react';
import { Sheet } from '../components/Sheet';
import { DbError, createOrder, getSettings, listPaymentMethods } from '../lib/db';
import type { CreateOrderInput } from '../lib/db';
import { buildVietQRUrl, formatVND, uuid } from '../lib/format';
import { queueOrder } from '../lib/offline';
import { useToast } from '../components/Toast';
import { BillPrint } from './BillPrint';
import type { CartLine, Customer, Order, PaymentMethodDef } from '../lib/types';

const QUICK_CASH = [20000, 50000, 100000, 200000, 500000];

export function CheckoutModal({
  lines,
  customer,
  total,
  onClose,
  onDone,
}: {
  lines: CartLine[];
  customer: Customer | null;
  total: number;
  onClose: () => void;
  onDone: (order: Order | null, queued: boolean) => void;
}) {
  const toast = useToast();
  const [methods, setMethods] = useState<PaymentMethodDef[]>([]);
  const [methodId, setMethodId] = useState('');
  const [received, setReceived] = useState('');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const [fallbackBank, setFallbackBank] = useState({ bin: '', account: '', name: '' });
  const [shopName, setShopName] = useState('Beesy Coffee & Tea');
  const [paidOrder, setPaidOrder] = useState<Order | null>(null);
  const [paidMethod, setPaidMethod] = useState<PaymentMethodDef | null>(null);
  const [queuedUuid, setQueuedUuid] = useState<string | null>(null);

  useEffect(() => {
    listPaymentMethods(true)
      .then((ms) => {
        setMethods(ms);
        const def = ms.find((m) => m.id === 'cash') ?? ms[0] ?? null;
        if (def) setMethodId(def.id);
      })
      .catch(() => toast.show('Không tải được phương thức thanh toán'));
    getSettings()
      .then((s) => {
        setShopName(s.shop_name || 'Beesy Coffee & Tea');
        // Dự phòng cho dữ liệu cũ: cấu hình ngân hàng trong settings
        setFallbackBank({
          bin: s.bank_bin || '',
          account: s.bank_account || '',
          name: s.bank_account_name || '',
        });
      })
      .catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const method = methods.find((m) => m.id === methodId) ?? null;
  const kind = method?.kind ?? 'cash';
  const bankBin = method?.bank_bin || fallbackBank.bin;
  const bankAccount = method?.bank_account || fallbackBank.account;
  const bankName = method?.bank_account_name || fallbackBank.name || shopName;

  const receivedNum = parseInt(received.replace(/\D/g, ''), 10) || 0;
  const change = receivedNum - total;

  const buildInput = (m: PaymentMethodDef, clientUuid: string): CreateOrderInput => ({
    clientUuid,
    customerId: customer?.id ?? null,
    items: lines.map((l) => ({
      productId: l.product.id,
      qty: l.qty,
      modifierOptionIds: l.modifiers.map((x) => x.option_id),
      note: l.note || undefined,
    })),
    paymentMethod: m.id,
    amountReceived: m.kind === 'cash' ? receivedNum : undefined,
    note: note.trim() || null,
  });

  const submit = async (m: PaymentMethodDef) => {
    if (m.kind === 'cash' && receivedNum < total) {
      toast.show('Tiền khách đưa chưa đủ');
      return;
    }
    if (m.kind === 'debt' && !customer) {
      toast.show('Ghi nợ cần chọn khách hàng cho đơn này');
      return;
    }
    setBusy(true);
    const clientUuid = uuid();
    const input = buildInput(m, clientUuid);
    try {
      const order = await createOrder(input);
      setPaidMethod(m);
      setPaidOrder(order);
    } catch (e) {
      if (e instanceof DbError && e.code === 'unavailable') {
        // Offline → lưu outbox, vẫn coi như bán xong
        queueOrder({ clientUuid, createdAt: new Date().toISOString(), payload: input });
        setQueuedUuid(clientUuid);
      } else {
        toast.show(e instanceof DbError ? e.message : 'Tạo đơn thất bại');
      }
    } finally {
      setBusy(false);
    }
  };

  // ---- Màn hình sau thanh toán: QR (chuyển khoản) + in bill ----
  if (paidOrder || queuedUuid) {
    const showQR = paidOrder && paidMethod?.kind === 'transfer' && bankBin && bankAccount;
    return (
      <Sheet
        title={paidOrder ? `✅ Đơn ${paidOrder.code} thành công` : '✅ Đã lưu đơn chờ'}
        onClose={() => onDone(paidOrder, !!queuedUuid)}
        footer={
          <div className="row">
            {paidOrder && (
              <button className="btn btn-outline grow" onClick={() => window.print()}>
                🖨️ In bill
              </button>
            )}
            <button className="btn grow" onClick={() => onDone(paidOrder, !!queuedUuid)}>
              Đơn mới ➜
            </button>
          </div>
        }
      >
        {showQR && paidOrder && (
          <div className="qr-box">
            <img
              src={buildVietQRUrl(bankBin, bankAccount, bankName, paidOrder.total, paidOrder.code)}
              alt={`Mã VietQR đơn ${paidOrder.code}`}
            />
            <p style={{ marginTop: 8 }}>
              <b>{bankName}</b>
              <br />
              <span className="muted">
                STK: {bankAccount} · Số tiền: <span className="money">{formatVND(paidOrder.total)}</span>
                <br />
                Nội dung: <b>{paidOrder.code}</b>
              </span>
            </p>
            <p className="small" style={{ color: 'var(--amber)' }}>
              Khách quét mã để chuyển khoản đúng số tiền &amp; nội dung. Nhân viên xác nhận đã nhận tiền rồi bấm “In bill”.
            </p>
          </div>
        )}
        {paidOrder && paidMethod?.kind === 'debt' && customer && (
          <div className="card" style={{ marginBottom: 8 }}>
            📒 Đã ghi nợ <b className="money">{formatVND(paidOrder.total)}</b> cho <b>{customer.name}</b>.
          </div>
        )}
        {paidOrder ? (
          <BillPrint order={paidOrder} shopName={shopName} />
        ) : (
          <div className="card">
            <p>📶 Đang offline — đơn đã lưu vào hàng chờ và sẽ <b>tự đồng bộ</b> khi có mạng (mã đơn sẽ hiện sau khi đồng bộ).</p>
            <p className="muted small">Tổng: <span className="money">{formatVND(total)}</span> · {lines.length} dòng món</p>
          </div>
        )}
      </Sheet>
    );
  }

  return (
    <Sheet
      title={`💳 Thanh toán — ${formatVND(total)}`}
      onClose={onClose}
      footer={
        method && (
          kind === 'cash' ? (
            <button className="btn btn-green btn-block btn-lg" disabled={busy || receivedNum < total} onClick={() => submit(method)}>
              {busy ? 'Đang xử lý…' : `Xác nhận thu ${formatVND(total)}`}
            </button>
          ) : kind === 'transfer' ? (
            <button
              className="btn btn-green btn-block btn-lg"
              disabled={busy || !bankBin || !bankAccount}
              onClick={() => submit(method)}
            >
              {busy ? 'Đang tạo đơn…' : 'Tạo đơn & lấy mã QR'}
            </button>
          ) : (
            <button
              className="btn btn-green btn-block btn-lg"
              disabled={busy || !customer}
              onClick={() => submit(method)}
            >
              {busy ? 'Đang ghi nợ…' : `Xác nhận ghi nợ ${formatVND(total)}`}
            </button>
          )
        )
      }
    >
      <div className="pay-tabs" style={{ flexWrap: 'wrap' }}>
        {methods.map((m) => (
          <button
            key={m.id}
            className={`pay-tab${m.id === methodId ? ' active' : ''}`}
            onClick={() => setMethodId(m.id)}
          >
            {m.icon} {m.name}
          </button>
        ))}
      </div>

      {kind === 'cash' && (
        <>
          <div className="field">
            <label htmlFor="received">Tiền khách đưa</label>
            <input
              id="received"
              className="input"
              inputMode="numeric"
              placeholder="Nhập số tiền…"
              value={received}
              onChange={(e) => setReceived(e.target.value)}
            />
          </div>
          <div className="quick-cash">
            {QUICK_CASH.map((v) => (
              <button key={v} className="btn btn-outline" style={{ minHeight: 48 }} onClick={() => setReceived(String(v))}>
                {formatVND(v)}
              </button>
            ))}
            <button className="btn btn-outline" style={{ minHeight: 48 }} onClick={() => setReceived(String(total))}>
              Vừa đủ
            </button>
          </div>
          {receivedNum > 0 && (
            <div className="change-box" style={change < 0 ? { background: 'var(--red-bg)', color: 'var(--red)' } : undefined}>
              {change >= 0 ? `Thối lại: ${formatVND(change)}` : `Còn thiếu: ${formatVND(-change)}`}
            </div>
          )}
        </>
      )}

      {kind === 'transfer' && (
        <div className="card" style={{ marginBottom: 8 }}>
          {bankBin && bankAccount ? (
            <p style={{ margin: 0 }}>
              📱 Bấm <b>“Tạo đơn &amp; lấy mã QR”</b> — hệ thống tạo đơn, sinh mã (VD A001) rồi hiện
              mã VietQR đúng số tiền &amp; nội dung để khách quét.
              <br />
              <span className="muted small">{bankName} · {bankAccount}</span>
            </p>
          ) : (
            <p className="muted" style={{ margin: 0 }}>Chưa cấu hình ngân hàng cho phương thức này — vào Cài đặt → Phương thức thanh toán để nhập BIN, số tài khoản.</p>
          )}
        </div>
      )}

      {kind === 'debt' && (
        <div className="card" style={{ marginBottom: 8 }}>
          {customer ? (
            <p style={{ margin: 0 }}>
              📒 Ghi nợ <b className="money">{formatVND(total)}</b> cho <b>{customer.name}</b>.
              <br />
              <span className="muted small">
                Công nợ hiện tại: <span className="money">{formatVND(customer.debt ?? 0)}</span>
                {' '}→ sau đơn này: <span className="money">{formatVND((customer.debt ?? 0) + total)}</span>
              </span>
            </p>
          ) : (
            <p className="muted" style={{ margin: 0 }}>⚠️ Ghi nợ cần chọn khách hàng trước — quay lại giỏ hàng để chọn khách.</p>
          )}
        </div>
      )}

      <div className="field" style={{ marginTop: 8 }}>
        <label htmlFor="order-note">Ghi chú đơn</label>
        <input id="order-note" className="input" placeholder="VD: khách chờ lấy…" value={note} onChange={(e) => setNote(e.target.value)} />
      </div>
      {customer && (
        <p className="small">👤 Khách: <b>{customer.name}</b> — đơn này được +1 tem 🎟️</p>
      )}
    </Sheet>
  );
}
