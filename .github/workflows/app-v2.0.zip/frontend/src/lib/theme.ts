// Quản lý giao diện v1/v2 của app.
// v1: theme xanh lá Sổ Bán Hàng (mặc định cũ)
// v2: theme Kasa POS — nền #F2F4F7, primary #4D81F1, font Plus Jakarta Sans
export type AppTheme = 'v1' | 'v2';

const KEY = 'beesy-theme';

export function getTheme(): AppTheme {
  try {
    return (localStorage.getItem(KEY) as AppTheme) === 'v1' ? 'v1' : 'v2';
  } catch {
    return 'v2';
  }
}

export function setTheme(t: AppTheme): void {
  try {
    localStorage.setItem(KEY, t);
  } catch {
    /* bỏ qua */
  }
  document.documentElement.setAttribute('data-theme', t);
  // Đổi màu thanh trạng thái trình duyệt theo theme
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', t === 'v2' ? '#4D81F1' : '#00B14F');
}

// Gọi sớm khi app khởi động (index.html đã set sẵn để tránh nháy)
export function initTheme(): void {
  setTheme(getTheme());
}
