// Khởi tạo Firebase (dùng gói miễn phí Spark: Firestore + Auth + Hosting)
import { initializeApp, getApps, type FirebaseApp } from 'firebase/app';
import { getAuth, connectAuthEmulator, type Auth } from 'firebase/auth';
import {
  initializeFirestore,
  getFirestore,
  connectFirestoreEmulator,
  persistentLocalCache,
  persistentMultipleTabManager,
  type Firestore,
} from 'firebase/firestore';

function env(name: string): string {
  const v = import.meta.env[name] as string | undefined;
  if (!v) {
    throw new Error(
      `Thiếu biến môi trường ${name}. Copy frontend/.env.example thành frontend/.env rồi điền config của Web app (Firebase console → Project settings).`,
    );
  }
  return v;
}

let app: FirebaseApp;
// Export config để khởi tạo Firebase app phụ (dùng khi chủ quán thêm tài khoản nhân viên
// mà không bị đăng xuất khỏi phiên hiện tại).
export const firebaseConfig = {
  apiKey: env('VITE_FIREBASE_API_KEY'),
  authDomain: env('VITE_FIREBASE_AUTH_DOMAIN'),
  projectId: env('VITE_FIREBASE_PROJECT_ID'),
  storageBucket: env('VITE_FIREBASE_STORAGE_BUCKET'),
  messagingSenderId: env('VITE_FIREBASE_MESSAGING_SENDER_ID'),
  appId: env('VITE_FIREBASE_APP_ID'),
};
if (getApps().length > 0) {
  app = getApps()[0]!;
} else {
  app = initializeApp(firebaseConfig);
}

// Auth: Firebase tự lưu phiên đăng nhập (không cần localStorage thủ công)
export const auth: Auth = getAuth(app);

// Firestore + cache offline bền vững (gói Spark cho phép).
// persistentMultipleTabManager: mở POS + KDS trên nhiều tab vẫn đồng bộ cache.
let firestore: Firestore;
try {
  firestore = initializeFirestore(app, {
    localCache: persistentLocalCache({
      tabManager: persistentMultipleTabManager(),
    }),
  });
} catch {
  // VD: HMR khởi tạo 2 lần, hoặc trình duyệt không hỗ trợ IndexedDB
  firestore = getFirestore(app);
}
export const db: Firestore = firestore;

// LOCAL QA ONLY (chụp màn hình video): nối emulator khi VITE_USE_EMULATOR=1.
// Bản build giao khách không đặt biến này nên không ảnh hưởng.
if ((import.meta.env.VITE_USE_EMULATOR as string | undefined) === '1') {
  try {
    connectAuthEmulator(auth, 'http://127.0.0.1:9099', { disableWarnings: true });
    connectFirestoreEmulator(firestore, '127.0.0.1', 8080);
  } catch {
    // đã kết nối rồi (HMR)
  }
}
