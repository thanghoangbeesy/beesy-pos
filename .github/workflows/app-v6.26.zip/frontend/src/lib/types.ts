// Kiểu dữ liệu dùng chung — khớp CONTRACT mục 4 & 5

// Vai trò tài khoản — phân quyền chi tiết theo nhóm nhân viên.
// 'staff' cũ được chuẩn hóa thành 'seller' (Bán hàng) để tương thích dữ liệu cũ.
export type RoleKey = 'owner' | 'manager' | 'cashier' | 'seller';

export interface User {
  id: string;
  email: string;
  full_name: string;
  role: RoleKey;
  // Multi-kho: danh sách kho tài khoản được phép dùng.
  // - Chủ quán (owner): bỏ qua, luôn dùng được mọi kho.
  // - Nhân viên: chỉ dùng được các kho trong danh sách (rỗng = chưa được gán kho nào).
  warehouse_ids?: string[];
}

// Kho hàng (multi-warehouse). Mỗi nguyên liệu có tồn kho RIÊNG theo từng kho.
export interface Warehouse {
  id: string;
  name: string;
  note: string | null;
  is_default: boolean; // kho bán hàng mặc định (trừ kho này khi bán ở POS)
  active: boolean;
  sort_order: number;
  created_at: string; // ISO
}

// Mức tồn của 1 nguyên liệu tại 1 kho — collection stock_levels, id = `${warehouse_id}_${ingredient_id}`
export interface StockLevel {
  warehouse_id: string;
  ingredient_id: string;
  stock: number;
  avg_cost: number; // giá nhập bình quân / đơn vị (đ) — để tính giá vốn tự động
}

// Nguyên liệu kèm tồn kho tại kho đang xem
export interface IngredientWithStock extends Ingredient {
  stock: number; // tồn tại kho đang xem (ghi đè field stock của Ingredient)
}

export interface Category {
  id: string;
  name: string;
  sort_order: number;
  active: boolean;
}

export interface ModifierOption {
  id: string;
  group_id: string;
  name: string;
  price_delta: number;
  sort_order: number;
  active: boolean;
}

export interface ModifierGroup {
  id: string;
  name: string;
  selection_type: 'single' | 'multi';
  required: boolean;
  sort_order: number;
  active: boolean;
  options: ModifierOption[];
}

export interface Product {
  id: string;
  name: string;
  category_id: string | null;
  base_price: number;
  cost_price: number; // giá vốn / đơn vị (để tính lợi nhuận)
  unit: string; // đơn vị: Ly, Cái, Hộp...
  recipe: RecipeItem[]; // định lượng mặc định
  variant_recipes?: Record<string, RecipeItem[]>; // định lượng riêng theo option ID (Pro) // định lượng nguyên liệu cho 1 đơn vị món
  image_url: string | null;
  active: boolean;
  sort_order: number;
  warehouse_ids: string[]; // kho được bán món này; rỗng = mọi kho
  track_stock?: boolean; // bật theo dõi tồn kho trực tiếp (hàng nhập về bán thẳng)
  stock_ingredient_id?: string | null; // nguyên liệu kho liên kết khi track_stock
}

// Định lượng: lượng nguyên liệu cho 1 đơn vị món
export interface RecipeItem {
  ingredient_id: string;
  qty: number;
}

// Nguyên liệu tồn kho
export interface Ingredient {
  id: string;
  name: string;
  unit: string; // g, ml, cái, hộp...
  stock: number; // tồn kho hiện tại
  min_stock: number; // ngưỡng cảnh báo sắp hết
  alert_enabled: boolean; // bật/tắt cảnh báo sắp hết cho nguyên liệu này (v5.14); mặc định bật
  cost_per_unit: number; // giá vốn / đơn vị nguyên liệu (tham khảo)
  active: boolean;
  sort_order: number;
  is_product_stock?: boolean; // nguyên liệu kho tự tạo cho món bật theo dõi tồn
  product_id?: string | null; // món liên kết (khi is_product_stock)
  // Công thức sản xuất bán thành phẩm: định lượng nguyên liệu thô cho 1 đơn vị
  // thành phẩm này (tính theo đơn vị của chính nó). VD: 1ml kem muối cần 0.8ml kem béo.
  production_recipe?: Array<{ ingredient_id: string; qty: number }>;
  production_batch_qty?: number; // 1 mẻ làm ra bao nhiêu đơn vị thành phẩm (mặc định 1)
}

// Lịch sử nhập/xuất kho
export interface StockLog {
  id: string;
  warehouse_id: string | null; // kho phát sinh (log cũ trước multi-kho có thể null)
  warehouse_name: string | null;
  ingredient_id: string;
  ingredient_name: string;
  change: number; // + nhập, - xuất
  balance_after: number;
  note: string | null;
  unit_cost: number | null; // giá nhập / đơn vị của lần nhập này (đ)
  total_cost: number | null; // thành tiền nhập của lần này (đ)
  ref_type: 'manual' | 'order' | 'transfer' | 'purchase' | 'stock_export' | 'check' | 'production';
  ref_id: string | null;
  created_by: string | null;
  created_at: string; // ISO
}

// ---------- Phiếu sản xuất bán thành phẩm ----------
export interface ProductionOrderItem {
  ingredient_id: string;
  ingredient_name: string;
  unit: string;
  qty: number; // số lượng nguyên liệu thô đã dùng
}

export interface ProductionOrder {
  id: string;
  code: string; // SX001 theo ngày
  product_id: string; // ingredient id của bán thành phẩm
  product_name: string;
  product_unit: string;
  qty_produced: number; // số lượng thành phẩm đã tạo (theo đơn vị của nó)
  ingredients_used: ProductionOrderItem[];
  batch_cost?: number; // tổng giá vốn nguyên liệu thô của mẻ này
  new_cost_per_unit?: number; // giá vốn/đơn vị sau khi tính bình quân
  warehouse_id: string;
  warehouse_name: string;
  note: string | null;
  business_date: string;
  created_by: string | null;
  created_at: string;
}

// Option đã chọn khi bỏ món vào giỏ (snapshot để gửi lên server)
export interface SelectedModifier {
  option_id: string;
  group: string;
  option: string;
  price_delta: number;
}

export interface CartLine {
  key: string;
  product: Product;
  qty: number;
  modifiers: SelectedModifier[];
  note: string;
  comboId?: string | null; // nếu là combo
  unitPrice?: number; // giá bán nhập tay thay base_price (chỉ POS, topping vẫn cộng thêm)
  // Giảm giá riêng cho dòng món này (v5.7): % hoặc số tiền trên tổng dòng
  discountType?: 'percent' | 'amount' | null;
  discountValue?: number | null;
}

/** Số tiền giảm từ (kiểu, giá trị) trên một mốc tiền — trần 100% / không vượt mốc. */
export function discountAmountFor(
  base: number,
  type: 'percent' | 'amount' | null | undefined,
  value: number | null | undefined,
): number {
  const st = Math.max(0, Math.round(Number(base) || 0));
  if (!type || st <= 0) return 0;
  const v = Number(value) || 0;
  if (v <= 0) return 0;
  const d = type === 'percent' ? Math.round((st * Math.min(100, v)) / 100) : Math.round(v);
  return Math.min(st, Math.max(0, d));
}

// Hóa đơn tạm — lưu tạm giỏ hàng để bán tiếp sau (collection draft_orders)
export interface DraftOrderItem {
  product: Product; // snapshot món lúc lưu tạm (giữ giá lúc đó)
  qty: number;
  modifiers: SelectedModifier[];
  note: string;
  unitPrice?: number | null; // giá bán nhập tay (nếu có)
  discountType?: 'percent' | 'amount' | null;
  discountValue?: number | null;
}

export interface DraftOrder {
  id: string;
  items: DraftOrderItem[];
  customer_id: string | null;
  customer_name: string | null;
  created_by: string | null;
  created_at: string; // ISO
}

export interface OrderItem {
  id: string;
  order_id: string;
  product_id: string;
  product_name: string;
  qty: number;
  unit_price: number;
  cost_price: number; // giá vốn lúc bán (snapshot để tính lợi nhuận)
  recipe?: RecipeItem[]; // snapshot định lượng lúc bán (để hoàn kho khi hủy/xóa đơn)
  modifiers: SelectedModifier[];
  line_total: number;
  // Giảm giá riêng của dòng món (v5.7): số tiền đã giảm + kiểu/giá trị gốc.
  // Đơn cũ không có các trường này -> coi như không giảm.
  discount?: number;
  discount_type?: 'percent' | 'amount' | null;
  discount_value?: number | null;
  note?: string;
}

export type OrderStatus = 'new' | 'preparing' | 'ready' | 'done' | 'cancelled';

// id của phương thức thanh toán (collection payment_methods).
// Các id hệ thống: 'cash' (tiền mặt), 'transfer' (chuyển khoản), 'debt' (ghi nợ).
export type PaymentMethod = string;
export type PaymentMethodKind = 'cash' | 'transfer' | 'debt';

export interface PaymentMethodDef {
  id: string;
  name: string;
  kind: PaymentMethodKind;
  icon: string;
  bank_bin: string | null;
  bank_account: string | null;
  bank_account_name: string | null;
  active: boolean;
  hide_pos: boolean; // ẩn khỏi bảng thanh toán trong POS
  hide_reports: boolean; // ẩn khỏi Sổ quỹ, Báo cáo, Chốt két
  sort_order: number;
}

// ---------- Thanh toán hỗn hợp: 1 đơn trả bằng nhiều phương thức ----------
export interface PaymentSplit {
  method_id: string; // id phương thức thanh toán
  method_name: string; // tên hiển thị (snapshot lúc bán)
  kind: PaymentMethodKind; // 'cash' | 'transfer' | 'debt'
  amount: number; // số tiền của phần này (> 0)
}

/** Đoán kind từ id phương thức (cho đơn cũ không lưu payments). */
export function guessMethodKind(methodId: string): PaymentMethodKind {
  if (methodId === 'transfer') return 'transfer';
  if (methodId === 'debt') return 'debt';
  return 'cash';
}

export interface Order {
  id: string;
  client_uuid: string;
  code: string;
  business_date: string;
  customer_id: string | null;
  status: OrderStatus;
  payment_method: PaymentMethod;
  payment_method_name: string | null;
  payments?: PaymentSplit[]; // thanh toán hỗn hợp; đơn cũ không có → 1 split từ payment_method
  warehouse_id: string | null; // kho đã trừ tồn khi bán (multi-kho; đơn cũ có thể null)
  warehouse_name: string | null;
  subtotal: number;
  discount: number;
  discount_type: 'percent' | 'amount' | null;
  discount_value: number | null;
  discount_label: string | null;
  shipping_fee: number; // phí ship cộng vào tổng đơn (v5.15); đơn cũ không có → 0
  total: number;
  amount_received: number | null;
  change_amount: number | null;
  note: string | null;
  source: 'pos' | 'takeaway' | 'delivery' | 'online' | 'grabfood' | 'shopeefood'; // kênh bán: tại quầy ('pos'), mang đi, ship, khách tự đặt online, hoặc đơn sàn GrabFood/ShopeeFood (v6.25)
  online_name: string | null; // tên khách đặt online
  online_phone: string | null; // SĐT khách đặt online
  // --- Đơn sàn GrabFood / ShopeeFood (v6.25, chỉ có khi source là grabfood/shopeefood) ---
  platform_order_code?: string | null; // mã đơn trên sàn, VD GF-300
  platform_fee?: number; // chiết khấu sàn (đ) — Grab thực tế 19,634% tổng đơn
  platform_tax?: number; // thuế sàn (đ) = GTGT 3% + TNCN 1,5% tổng đơn
  platform_tax_vat?: number; // thuế GTGT 3% tổng đơn
  platform_tax_pit?: number; // thuế TNCN 1,5% tổng đơn
  platform_net_expected?: number; // tiền về dự kiến = tổng đơn - phí - thuế
  platform_net_actual?: number | null; // tiền thực về tài khoản (nhập lúc bấm "Đã về tiền")
  platform_status?: 'cho-tien' | 'da-ve'; // chờ tiền sàn chuyển về / đã về
  platform_received_at?: string | null; // ISO lúc ghi nhận tiền về
  voucher_code: string | null; // mã voucher đã áp (nếu có)
  points_earned: number; // điểm tích từ đơn này
  reward_triggered: boolean; // đơn này có kích hoạt thưởng tem (đủ mốc) không
  created_by: string | null;
  created_at: string;
  items: OrderItem[];
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  birthday: string | null;
  address: string | null;
  stamps: number;
  reward_available: boolean;
  points: number; // điểm tích lũy
  total_spent: number; // tổng chi tiêu tích lũy (tính hạng)
  tier: 'member' | 'silver' | 'gold'; // hạng thành viên
  debt: number;
  note: string | null;
  warehouse_id: string | null; // kho của khách; null = mọi kho (dữ liệu cũ)
  zalo_user_id: string | null; // ID Zalo OA (để gửi tin tự động)
  created_at: string;
  recent_orders?: Order[];
}

export interface DebtLog {
  id: string;
  amount: number; // dương = ghi nợ thêm, âm = thu nợ
  balance_after: number;
  note: string | null;
  // Ma don / id don ma log no nay gan vao (ghi tu ban nay tro di, de phat
  // lai FIFO tien thu no theo tung don khi xoa/huy; log cu khong co thi
  // phat lai bang cach tach ma don tu note).
  order_code?: string | null;
  order_id?: string | null;
  created_by: string | null;
  created_at: string;
}

// Khoản thu/chi của quán: gồm khoản THỦ CÔNG (nhập hàng, mặt bằng, lương...)
// và khoản TỰ ĐỘNG (doanh thu đơn đã thu tiền, thu nợ) — xem ref_type.
export type CashbookType = 'thu' | 'chi';

// Nguồn gốc của khoản thu/chi trong sổ quỹ
export type FundRefType = 'manual' | 'order' | 'debt_pay' | 'debt_refund' | 'supplier_pay' | 'transfer' | 'purchase' | 'stock_export' | 'production' | 'check' | 'platform_fee' | 'platform_tax'; // platform_fee/platform_tax (v6.25): phí sàn + thuế sàn khi tiền đơn sàn về

export interface CashbookEntry {
  id: string;
  type: CashbookType;
  amount: number; // > 0
  code: string | null; // số phiếu: PT001/PC001 (thủ công), hoặc mã chứng từ gốc (tự động)
  note: string | null;
  category: string;
  fund_id: string; // quỹ, mặc định 'cash' (Quỹ quán)
  ref_type: FundRefType; // 'manual' = nhập tay; 'order' = từ đơn bán; 'debt_pay' = thu nợ KH; 'supplier_pay' = trả nợ NCC; 'transfer' = chuyển quỹ
  ref_id: string | null; // orderId (order) | customerId (debt_pay) | null (manual)
  ref_code: string | null; // mã đơn (A001) cho ref_type='order' — hiện ở Sổ quỹ, bấm để xem đơn
  method: 'cash' | 'transfer' | null; // phương thức của khoản tự động
  created_by: string | null;
  warehouse_id: string | null; // kho phát sinh khoản này; null = dữ liệu cũ (hiện ở mọi kho)
  created_at: string; // ISO
}

// Danh mục thu/chi của Sổ quỹ (lưu ở settings/fund_categories)
export interface FundCategories {
  thu: string[];
  chi: string[];
}

// Quỹ tiền — MỖI PHƯƠNG THỨC THANH TOÁN (trừ Ghi nợ) LÀ MỘT QUỸ.
// Danh sách quỹ được đồng bộ từ payment_methods: thêm/sửa/ẩn phương thức
// ở Cài đặt thì quỹ tự theo. Số dư đầu kỳ lưu ở settings/funds.
// fund_id trên CashbookEntry = id phương thức thanh toán.
export interface Fund {
  id: string; // = id phương thức thanh toán
  payment_method_id: string;
  kind: 'cash' | 'transfer'; // loại phương thức (không bao gồm ghi nợ)
  name: string; // theo tên phương thức thanh toán
  opening_balance: number; // (legacy) số dư đầu kỳ chung
  opening_date: string; // YYYY-MM-DD; '' = chưa đặt ngày (không lọc giao dịch)
  opening_by_warehouse: Record<string, { opening_balance: number; opening_date: string }>;
  active: boolean; // theo trạng thái phương thức thanh toán
  hide_reports: boolean; // ẩn khỏi Sổ quỹ, Báo cáo, Chốt két
  sort_order: number;
}

// Cài đặt quỹ (lưu ở settings/fund)
export interface FundSettings {
  fund_name: string;
  opening_balance: number;
  opening_date: string; // YYYY-MM-DD
}

export interface DailyReport {
  date: string;
  revenue: number; // doanh thu TIEN HANG (khong gom phi ship, cach B tu 25/10/2026)
  shipping_total: number; // tong phi ship thu ho de tra cho don vi van chuyen (khong tinh vao doanh thu, khong tinh vao loi nhuan)
  profit: number; // lợi nhuận = doanh thu − giá vốn − chi phí
  cost: number; // tổng giá vốn
  expenses: number; // tổng chi phí (từ sổ quỹ)
  purchase_costs: number; // tổng chi nhập hàng + trả NCC trong kỳ (tách khỏi expenses, chỉ cộng vào khi bật công tắc)
  all_chi: number; // tổng MỌI khoản chi trong kỳ (không loại trừ gì: vận hành + nhập hàng + chuyển quỹ + hoàn tiền...)
  order_count: number;
  cancelled_count: number; // số đơn hủy
  promo_count: number; // số đơn có khuyến mại/giảm giá/voucher
  promo_discount: number; // tổng tiền giảm từ khuyến mại
  avg_order: number; // giá trị TB/đơn
  by_payment: Record<string, { name: string; count: number; revenue: number }>;
  top_products: { product_id: string; name: string; qty: number; revenue: number; cost: number; profit: number }[];
  by_hour: { hour: number; count: number; revenue: number }[];
  // --- Đơn sàn (v6.25, tính từ các đơn source grabfood/shopeefood, chưa hủy) ---
  platform_count: number; // số đơn sàn
  platform_revenue: number; // doanh thu đơn sàn (tổng tiền đơn, chưa trừ phí/thuế)
  platform_net_expected: number; // tiền về dự kiến của các đơn sàn
  platform_net_received: number; // tiền thực về của các đơn sàn đã về
  platform_pending: number; // tiền về dự kiến của các đơn sàn còn chờ tiền
}

/** Nhãn kênh bán cho đơn hàng (v6.25). 'pos' = bán tại quầy. */
export const ORDER_SOURCE_LABEL: Record<string, string> = {
  pos: 'Tại quầy',
  takeaway: 'Mang đi',
  delivery: 'Ship',
  online: 'Đặt online',
  grabfood: 'GrabFood',
  shopeefood: 'ShopeeFood',
};

/** Nguồn đơn chọn ở màn Bán hàng (v6.26) — mặc định 'pos'. */
export type SaleSource = 'pos' | 'takeaway' | 'delivery' | 'grabfood' | 'shopeefood';

/** Kênh sàn (chỉ 2 sàn đang bán). */
export type PlatformSource = 'grabfood' | 'shopeefood';

/** Trạng thái tiền về của đơn sàn. */
export type PlatformStatus = 'cho-tien' | 'da-ve';

export const PLATFORM_STATUS_LABEL: Record<PlatformStatus, string> = {
  'cho-tien': 'Chờ tiền',
  'da-ve': 'Đã về',
};

export interface ApiErrorBody {
  error: { code: string; message: string };
}

// ---------- Khuyến mãi (giờ vàng, giảm giá tự động) ----------
export interface Promotion {
  id: string;
  name: string; // VD: "Giờ vàng 14h-17h"
  type: 'percent' | 'amount'; // giảm % hay giảm tiền
  value: number; // % (0-100) hoặc số tiền
  start: string; // "HH:MM"
  end: string; // "HH:MM"
  active: boolean;
}

/** Voucher / mã giảm giá: doc id = mã (chữ thường) để tra nhanh và chống trùng. */
export interface Voucher {
  id: string;
  code: string; // mã hiển thị (chữ hoa)
  name: string;
  type: 'percent' | 'amount';
  value: number; // % (0-100) hoặc số tiền
  max_discount: number | null; // trần giảm khi type=percent
  min_order: number; // đơn tối thiểu
  usage_limit: number | null; // null = không giới hạn
  used_count: number;
  start_date: string | null; // YYYY-MM-DD
  end_date: string | null; // YYYY-MM-DD
  active: boolean;
  created_at: string;
}

// ---------- Nhà cung cấp & phiếu nhập hàng ----------
export interface Supplier {
  id: string;
  name: string;
  phone: string;
  address: string | null;
  note: string | null;
  debt: number; // công nợ còn nợ NCC
  active: boolean;
  created_at: string;
}

export interface PurchaseOrderItem {
  ingredient_id: string;
  ingredient_name: string;
  unit: string;
  qty: number;
  unit_cost: number; // đơn giá nhập
  line_total: number;
}

export interface PurchaseOrder {
  id: string;
  code: string; // PN001 theo ngày
  supplier_id: string | null;
  supplier_name: string;
  warehouse_id: string;
  warehouse_name: string;
  items: PurchaseOrderItem[];
  subtotal: number;
  paid_amount: number; // đã trả ngay
  debt_amount: number; // còn nợ NCC
  fund_id: string | null; // quỹ đã trả
  note: string | null;
  reason_id?: string | null; // lý do nhập (tùy chỉnh)
  attachments?: string[]; // ảnh/file chứng từ (data URL, tối đa 3)
  business_date: string;
  /** v6.3: thời gian thật của phiếu (ISO, giờ VN quy về UTC). Tùy chọn —
   *  phiếu cũ không có field này vẫn đọc bình thường, giờ giữ nguyên tới khi sửa. */
  business_datetime?: string | null;
  created_by: string | null;
  created_at: string;
}

// ---------- Phiếu xuất kho ----------
export type StockExportReason = string; // id lý do xuất (mặc định: 'ban' | 'tra_ncc' | 'huy' | 'khac')
export type StockExportBehavior = 'sale' | 'return_supplier' | 'none';
export interface StockReason {
  id: string;
  label: string;
  behavior?: StockExportBehavior; // chỉ dùng cho lý do xuất
  builtin?: boolean; // lý do mặc định (không cho xóa, chỉ sửa tên)
}
export interface StockReasonsSettings {
  import_reasons: StockReason[];
  export_reasons: StockReason[];
}

export interface StockExportItem {
  ingredient_id: string;
  ingredient_name: string;
  unit: string;
  qty: number;
  unit_price: number; // đơn giá xuất
  line_total: number;
}

export interface StockExport {
  id: string;
  code: string; // XK001 theo ngày
  reason: StockExportReason;
  behavior?: StockExportBehavior; // hành vi khi tạo/xóa phiếu
  supplier_id: string | null;
  supplier_name: string | null;
  // Khach mua phieu xuat ban (nullable, optional — phieu ban le khong can).
  // Them 25/10/2026 de phai thu xuat ban gan duoc vao he thong no khach hang.
  customer_id: string | null;
  customer_name: string | null;
  // Phan phai thu con lai dang duoc ghi vao no khach hang (de khi sua/xoa
  // phieu hoac thu phai thu thi hoan/tru dung so, khong tru am tham vao
  // no cua phieu cu chua tung duoc ghi no). Phieu cu mac dinh 0.
  debt_booked_amount: number;
  warehouse_id: string;
  warehouse_name: string;
  items: StockExportItem[];
  subtotal: number;
  received_amount: number; // đã thu (khi bán)
  receivable_amount: number; // phai thu con lai khi ban thu thieu (chi behavior sale; sua 25/10/2026)
  attachments?: string[]; // ảnh/file chứng từ (data URL, tối đa 3)
  fund_id: string | null; // quỹ đã thu
  note: string | null;
  reason_id?: string | null; // lý do nhập (tùy chỉnh)
  business_date: string;
  /** v6.3: thời gian thật của phiếu (ISO). Tùy chọn, phiếu cũ không có vẫn đọc được. */
  business_datetime?: string | null;
  created_by: string | null;
  created_at: string;
}

// ---------- Đơn đặt online (khách tự đặt, chờ duyệt) ----------
export interface OnlineOrderItem {
  product_id: string;
  product_name: string;
  qty: number;
  unit_price: number;
  modifier_option_ids: string[];
  modifiers: { group: string; option: string; price_delta: number }[];
  line_total: number;
  note?: string;
}

export interface OnlineOrder {
  id: string;
  items: OnlineOrderItem[];
  customer_name: string;
  customer_phone: string;
  note: string | null;
  payment_method_id: string;
  payment_kind: 'cash' | 'transfer';
  voucher_code: string | null;
  subtotal: number;
  discount: number;
  total: number;
  status: 'pending' | 'confirmed' | 'cancelled';
  confirmed_order_id: string | null;
  created_at: string;
}

// ---------- Combo (gói món giá ưu đãi) ----------
export interface ComboItem {
  product_id: string;
  product_name: string;
  qty: number;
}

export interface Combo {
  id: string;
  name: string;
  price: number; // giá bán combo
  items: ComboItem[]; // các món trong combo
  active: boolean;
  sort_order: number;
  created_at: string;
}

// ---------- Đối soát cuối ngày (Z-report) ----------
export interface DayCloseMethod {
  method_id: string;
  name: string;
  kind: PaymentMethodKind;
  amount: number;
  count: number;
}

export interface DayCloseFund {
  fund_id: string;
  name: string;
  expected: number; // số phần mềm tại thời điểm chốt
  actual: number; // tiền thực tế đếm được
  diff: number; // actual - expected
}

export interface DayClose {
  id: string; // business_date YYYY-MM-DD
  business_date: string;
  closed_at: string;
  closed_by: string | null;
  closed_by_name: string | null;
  revenue: number;
  orders_count: number;
  discount_total: number;
  by_method: DayCloseMethod[];
  cash_expected: number; // tiền mặt hệ thống ghi nhận (giữ để tương thích phiếu cũ)
  cash_actual: number; // tiền mặt thực tế trong két (giữ để tương thích phiếu cũ)
  cash_diff: number; // actual - expected
  cash_denoms: Record<string, number> | null; // chi tiết kiểm tiền: mệnh giá -> số tờ
  funds?: DayCloseFund[]; // chốt theo từng quỹ (bản v6.10+); phiếu cũ không có
  total_expected?: number; // tổng số phần mềm tất cả quỹ
  total_actual?: number; // tổng tiền thực tế tất cả quỹ
  total_diff?: number; // total_actual - total_expected
  note: string | null;
}

// ---------- Nhật ký thao tác ----------
export interface AuditLog {
  id: string;
  action: string; // 'order.delete' | 'order.edit' | 'product.price' | ...
  actor_id: string | null;
  actor_name: string | null;
  target_type: string | null;
  target_id: string | null;
  detail: string | null;
  created_at: string;
}

/**
 * Các phần thanh toán của đơn.
 * - Đơn mới (hỗn hợp): trả về payments đã lưu.
 * - Đơn cũ: tổng hợp 1 split duy nhất từ payment_method/payment_method_name.
 */
export function orderPaymentSplits(o: Order): PaymentSplit[] {
  if (o.payments && o.payments.length > 0) return o.payments;
  return [
    {
      method_id: o.payment_method,
      method_name: o.payment_method_name ?? o.payment_method,
      kind: guessMethodKind(o.payment_method),
      amount: o.total,
    },
  ];
}

/** true nếu đơn dùng nhiều phương thức thanh toán. */
export function isSplitPayment(o: Order): boolean {
  return !!o.payments && o.payments.length > 1;
}
