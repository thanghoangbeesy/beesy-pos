import { useEffect, useState } from 'react';
import type { FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  DbError,
  TIER_LABEL,
  adjustDebt,
  collectCustomerDebt,
  createCustomer,
  getCustomer,
  getFunds,
  getSettings,
  listDebtLogs,
  redeemReward,
  getAllowedWarehouses,
  searchCustomers,
  updateCustomer,
} from '../lib/db';
import { formatDateTime, formatVND } from '../lib/format';
import { Sheet } from '../components/Sheet';
import { TIcon } from '../components/TIcon';
import { PageHead } from '../components/PageHead';
import { useToast } from '../components/Toast';
import { LineIcon } from '../components/LineIcon';
import './pc-customers.css';
import type { Customer, DebtLog, Fund, Warehouse } from '../lib/types';

function zaloPhone(phone: string): string {
  const d = phone.replace(/\D/g, '');
  if (d.startsWith('84')) return d;
  if (d.startsWith('0')) return d;
  return d;
}

function upcomingBirthdays(list: Customer[]): { c: Customer; inDays: number; dateLabel: string }[] {
  const now = new Date();
  const out: { c: Customer; inDays: number; dateLabel: string }[] = [];
  for (const c of list) {
    if (!c.birthday || !/^\d{4}-\d{2}-\d{2}$/.test(c.birthday)) continue;
    const [, m, d] = c.birthday.split('-').map(Number);
    const thisYear = new Date(now.getFullYear(), m - 1, d);
    let next = thisYear;
    if (thisYear.getTime() < new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime()) {
      next = new Date(now.getFullYear() + 1, m - 1, d);
    }
    const inDays = Math.round((next.getTime() - new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime()) / 86400000);
    if (inDays <= 30) {
      out.push({
        c,
        inDays,
        dateLabel: `${String(d).padStart(2, '0')}/${String(m).padStart(2, '0')}`,
      });
    }
  }
  return out.sort((a, b) => a.inDays - b.inDays);
}

function BirthdayZaloTab({ list, shopName }: { list: Customer[]; shopName: string }) {
  const [copied, setCopied] = useState<string | null>(null);

  const upcoming = upcomingBirthdays(list);

  const copyMsg = async (key: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(key);
      setTimeout(() => setCopied(null), 2000);
    } catch {
      /* bo qua */
    }
  };

  const openChat = (c: Customer, msg: string) => {
    void copyMsg(`z_${c.id}`, msg);
    if (c.phone) window.open(`https://zalo.me/${zaloPhone(c.phone)}`, '_blank');
  };

  const templates: { key: string; title: string; text: (name: string) => string }[] = [
    {
      key: 'birthday',
      title: '🎂 Chúc mừng sinh nhật',
      text: (name) =>
        `Chúc mừng sinh nhật ${name}! 🎂 ${shopName} tặng bạn voucher giảm 20% nhân dịp đặc biệt này. Ghé quán nhé!`,
    },
    {
      key: 'promo',
      title: '🎁 Khuyến mãi chung',
      text: (name) =>
        `Chào ${name}! ${shopName} đang có ưu đãi mới, ghé quán thưởng thức nhé. Cảm ơn bạn đã ủng hộ!`,
    },
    {
      key: 'gold',
      title: '🥇 Tri ân hạng Vàng',
      text: (name) =>
        `Chào ${name}! Cảm ơn bạn đã là khách hàng Vàng của ${shopName}. Tuần này bạn được giảm thêm 5% mọi hóa đơn đấy!`,
    },
  ];

  return (
    <>
      <div className="card" style={{ marginBottom: 12 }}>
        <div style={{ fontWeight: 700, marginBottom: 8 }}>🎂 Sinh nhật trong 30 ngày tới ({upcoming.length})</div>
        {upcoming.length === 0 ? (
          <p className="small muted" style={{ margin: 0 }}>
            Không có sinh nhật nào sắp tới.
          </p>
        ) : (
          upcoming.map(({ c, inDays, dateLabel }) => {
            const msg = templates[0].text(c.name);
            return (
              <div key={c.id} className="sb-section" style={{ marginBottom: 8 }}>
                <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center' }}>
                  <div style={{ fontWeight: 700 }}>
                    {c.name} <span className="small muted">· {dateLabel}</span>
                  </div>
                  <span className={`sb-chip${inDays === 0 ? ' selected' : ''}`} style={{ minHeight: 28 }}>
                    {inDays === 0 ? 'Hôm nay!' : `còn ${inDays} ngày`}
                  </span>
                </div>
                <div className="row" style={{ gap: 8, marginTop: 8 }}>
                  <button type="button" className="btn" style={{ minHeight: 40 }} onClick={() => openChat(c, msg)}>
                    💬 Nhắn Zalo
                  </button>
                  <button type="button" className="sb-chip" style={{ minHeight: 40 }} onClick={() => void copyMsg(`b_${c.id}`, msg)}>
                    {copied === `b_${c.id}` ? 'Đã chép ✓' : '📋 Chép lời chúc'}
                  </button>
                </div>
                <p className="small muted" style={{ margin: '6px 0 0' }}>
                  Bấm "Nhắn Zalo" sẽ tự chép tin + mở chat — bạn chỉ cần dán và gửi.
                </p>
              </div>
            );
          })
        )}
      </div>

      <div className="card">
        <div style={{ fontWeight: 700, marginBottom: 4 }}>📝 Mẫu tin nhắn</div>
        {templates.map((t) => (
          <div key={t.key} className="sb-section" style={{ marginBottom: 8 }}>
            <div style={{ fontWeight: 600, marginBottom: 4 }}>{t.title}</div>
            <p className="small muted" style={{ margin: '0 0 8px' }}>
              {t.text('{Tên khách}')}
            </p>
            <button type="button" className="sb-chip" style={{ minHeight: 36 }} onClick={() => void copyMsg(t.key, t.text('{Tên khách}'))}>
              {copied === t.key ? 'Đã chép ✓' : '📋 Chép mẫu'}
            </button>
          </div>
        ))}
      </div>
    </>
  );
}

/** Hook phát hiện màn hình PC (>= 1024px), theo mẫu pages/Reports.tsx. */
function useIsPC(): boolean {
  const [isPC, setIsPC] = useState(() => typeof window !== 'undefined' && window.innerWidth >= 1024);
  useEffect(() => {
    const onResize = () => setIsPC(window.innerWidth >= 1024);
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);
  return isPC;
}

/** Nhãn hạng PC: chữ thường, không dùng emoji của TIER_LABEL. */
function pcTierLabel(tier: Customer['tier'] | undefined): string {
  if (tier === 'gold') return 'Vàng';
  if (tier === 'silver') return 'Bạc';
  return 'Thành viên';
}

function pcBirthdayLabel(birthday: string | null): string {
  if (!birthday || !/^\d{4}-\d{2}-\d{2}$/.test(birthday)) return '—';
  const [y, m, d] = birthday.split('-');
  return `${d}/${m}/${y}`;
}

/**
 * Khối tem + đổi thưởng cho panel PC. Logic giống CustomerDetail.redeem
 * (đòi hỏi khách có đơn, xác nhận, gọi redeemReward rồi tải lại khách).
 */
function PcRewardBlock({ customer, stampsTarget, onChanged }: {
  customer: Customer;
  stampsTarget: number;
  onChanged: (c: Customer) => void;
}) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const redeem = async () => {
    const lastOrder = customer.recent_orders?.[0];
    if (!lastOrder) {
      toast.show('Khách chưa có đơn nào để đổi thưởng');
      return;
    }
    if (!window.confirm(`Đổi thưởng cho ${customer.name}? (mua ${stampsTarget} tặng 1)`)) return;
    setBusy(true);
    try {
      await redeemReward(customer.id);
      toast.show('Đã đổi thưởng thành công!');
      const c = await getCustomer(customer.id);
      if (c) onChanged(c);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Đổi thưởng thất bại');
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="pc-customers-block">
      <div className="pc-customers-block-title">Tích tem ({customer.stamps}/{stampsTarget})</div>
      <div className="pc-customers-stamps" aria-label={`Đã tích ${customer.stamps} trên ${stampsTarget} tem`}>
        {Array.from({ length: stampsTarget }).map((_, i) => (
          <span key={i} className={`pc-customers-stamp${i < customer.stamps ? ' on' : ''}`} title={i < customer.stamps ? 'Đã tích' : 'Chưa tích'}>
            {i + 1}
          </span>
        ))}
      </div>
      {customer.reward_available ? (
        <button type="button" className="btn pc-customers-btn-block" disabled={busy} onClick={redeem}>
          <LineIcon name="gift" size={18} /> Đổi thưởng (mua {stampsTarget} tặng 1)
        </button>
      ) : (
        <p className="pc-customers-hint">Còn {stampsTarget - customer.stamps} tem nữa để nhận 1 ly miễn phí.</p>
      )}
    </div>
  );
}

export function Customers() {
  const navigate = useNavigate();
  const toast = useToast();
  const [q, setQ] = useState('');
  const [list, setList] = useState<Customer[]>([]);
  const [busy, setBusy] = useState(false);
  const [selected, setSelected] = useState<Customer | null>(null);
  const [formOpen, setFormOpen] = useState<Customer | 'new' | null>(null);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [whFilter, setWhFilter] = useState('all');
  const [stampsTarget, setStampsTarget] = useState(9);
  const [custTab, setCustTab] = useState<'list' | 'birthday'>('list');
  const [shopName, setShopName] = useState('quán');
  const isPC = useIsPC();
  const [pcFilter, setPcFilter] = useState<'all' | 'debt' | 'gold' | 'silver'>('all');

  useEffect(() => {
    getSettings().then((s) => {
      const t = parseInt(s.stamps_target ?? '', 10);
      if (!Number.isNaN(t) && t > 0) setStampsTarget(t);
      if (s.shop_name) setShopName(s.shop_name);
    }).catch(() => {});
    void search('');
    getAllowedWarehouses().then(({ warehouses: ws }) => setWarehouses(ws)).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const search = async (keyword: string) => {
    setBusy(true);
    try {
      const data = await searchCustomers(keyword.trim());
      setList(data.filter((c) => whFilter === 'all' || !c.warehouse_id || c.warehouse_id === whFilter));
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tìm được');
    } finally {
      setBusy(false);
    }
  };

  const openDetail = async (id: string) => {
    try {
      const c = await getCustomer(id);
      setSelected(c);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không mở được');
    }
  };

  const visible = list.filter(
    (c) => whFilter === 'all' || !c.warehouse_id || c.warehouse_id === whFilter,
  );

  // Nhánh PC: chỉ khác JSX trình bày, dùng chung state/loader/handler/phân quyền
  // của code cũ. JSX mobile phía dưới không sửa một dòng.
  if (isPC) {
    const pcFiltered = visible.filter((c) =>
      pcFilter === 'all' ? true : pcFilter === 'debt' ? c.debt > 0 : c.tier === pcFilter,
    );
    const pcNow = new Date();
    const pcNewThisMonth = visible.filter((c) => {
      const d = new Date(c.created_at);
      return !Number.isNaN(d.getTime()) && d.getFullYear() === pcNow.getFullYear() && d.getMonth() === pcNow.getMonth();
    }).length;
    const pcDebtCount = visible.filter((c) => c.debt > 0).length;
    const pcScrollTo = (cls: string) => {
      document.querySelector(`.${cls}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    };
    const pcRefreshSelected = async (id: string) => {
      const c = await getCustomer(id);
      if (c) setSelected(c);
      void search(q);
    };
    const pcFilters: { key: 'all' | 'debt' | 'gold' | 'silver'; label: string }[] = [
      { key: 'all', label: 'Tất cả' },
      { key: 'debt', label: 'Đang nợ' },
      { key: 'gold', label: 'Vàng' },
      { key: 'silver', label: 'Bạc' },
    ];
    return (
      <div className="page pc-customers-page">
        <div className="pc-customers-head">
          <div className="pc-customers-head-text">
            <h1>Khách hàng</h1>
            <p>Quản lý thông tin khách, công nợ và điểm tích lũy của quán Beesy Coffee &amp; Tea.</p>
          </div>
          <div className="pc-customers-head-actions">
            <button type="button" className="btn btn-outline pc-customers-btn" onClick={() => navigate('/debt')}>
              <LineIcon name="ledger" size={18} /> Sổ nợ
            </button>
            <button type="button" className="btn btn-outline pc-customers-btn" onClick={() => pcScrollTo('pc-customers-birthday')}>
              <LineIcon name="gift" size={18} /> Sinh nhật &amp; Zalo
            </button>
            <button type="button" className="btn pc-customers-btn" onClick={() => setFormOpen('new')}>
              <LineIcon name="plus" size={18} /> Thêm khách hàng
            </button>
          </div>
        </div>

        <div className="pc-customers-toolbar">
          <label className="pc-customers-search">
            <LineIcon name="search" size={18} />
            <input
              placeholder="Tìm khách theo tên hoặc SĐT..."
              value={q}
              onChange={(e) => {
                setQ(e.target.value);
                void search(e.target.value);
              }}
              aria-label="Tìm khách hàng"
            />
          </label>
          <div className="pc-customers-chips" role="group" aria-label="Lọc khách hàng">
            {pcFilters.map((f) => (
              <button key={f.key} type="button" className={`pc-customers-chip${pcFilter === f.key ? ' selected' : ''}`} onClick={() => setPcFilter(f.key)}>
                {f.label}
              </button>
            ))}
          </div>
          {warehouses.length > 1 && (
            <div className="pc-customers-chips" role="group" aria-label="Lọc theo kho">
              <button type="button" className={`pc-customers-chip${whFilter === 'all' ? ' selected' : ''}`} onClick={() => setWhFilter('all')}>
                Mọi kho
              </button>
              {warehouses.map((w) => (
                <button key={w.id} type="button" className={`pc-customers-chip${whFilter === w.id ? ' selected' : ''}`} onClick={() => setWhFilter(w.id)}>
                  {w.name}
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="pc-customers-stats">
          <div className="pc-customers-stat">
            <div className="pc-customers-stat-label">Tổng khách</div>
            <div className="pc-customers-stat-value">{visible.length}</div>
            <div className="pc-customers-stat-sub">Tất cả khách đã lưu</div>
          </div>
          <div className="pc-customers-stat">
            <div className="pc-customers-stat-label">Khách đang nợ</div>
            <div className="pc-customers-stat-value pc-customers-red">{pcDebtCount}</div>
            <div className="pc-customers-stat-sub">Cần thu hồi công nợ</div>
          </div>
          <div className="pc-customers-stat">
            <div className="pc-customers-stat-label">Khách mới tháng này</div>
            <div className="pc-customers-stat-value">{pcNewThisMonth}</div>
            <div className="pc-customers-stat-sub">Tháng {pcNow.getMonth() + 1}/{pcNow.getFullYear()}</div>
          </div>
        </div>

        <div className="pc-customers-layout">
          <section className="pc-customers-table-card" aria-label="Danh sách khách hàng">
            <table className="pc-customers-table">
              <thead>
                <tr>
                  <th>Khách hàng</th>
                  <th>SDT</th>
                  <th>Ngày sinh</th>
                  <th>Địa chỉ</th>
                  <th className="pc-customers-num">Công nợ</th>
                  <th className="pc-customers-num">Điểm tích lũy</th>
                  <th>Mua gần nhất</th>
                  <th>Thao tác</th>
                </tr>
              </thead>
              <tbody>
                {pcFiltered.map((c) => {
                  const lastOrder = selected && c.id === selected.id ? selected.recent_orders?.[0] : undefined;
                  return (
                    <tr key={c.id} className={selected?.id === c.id ? 'selected' : ''} onClick={() => void openDetail(c.id)}>
                      <td>
                        <div className="pc-customers-cust">
                          <span className="pc-customers-avatar">{c.name.charAt(0).toUpperCase()}</span>
                          <span className="pc-customers-cust-text">
                            <b title={c.name}>{c.name}</b>
                            <span className={`pc-customers-tag tier-${c.tier ?? 'member'}`}>{pcTierLabel(c.tier)}</span>
                            {c.reward_available && <span className="pc-customers-tag reward">Có thưởng</span>}
                          </span>
                        </div>
                      </td>
                      <td className="pc-customers-nowrap">{c.phone || '—'}</td>
                      <td className="pc-customers-nowrap">{pcBirthdayLabel(c.birthday)}</td>
                      <td className="pc-customers-addr" title={c.address ?? ''}>{c.address || '—'}</td>
                      <td className={`pc-customers-num${c.debt > 0 ? ' pc-customers-red' : ''}`}>{formatVND(c.debt)}</td>
                      <td className="pc-customers-num">{(c.points ?? 0).toLocaleString('vi-VN')}</td>
                      <td className="pc-customers-nowrap">{lastOrder ? formatDateTime(lastOrder.created_at) : '—'}</td>
                      <td>
                        <button type="button" className="btn btn-outline pc-customers-btn-sm" onClick={(e) => { e.stopPropagation(); void openDetail(c.id); }}>
                          <LineIcon name="eye" size={16} /> Xem
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {pcFiltered.length === 0 && !busy && (
              <div className="pc-customers-empty">
                <p>Chưa có khách hàng nào phù hợp.</p>
                <p>Thêm khách để tích tem và theo dõi công nợ.</p>
              </div>
            )}
            {busy && <div className="pc-customers-empty"><p>Đang tìm...</p></div>}
            <div className="pc-customers-pager">
              <span>Hiển thị {pcFiltered.length} / {visible.length} khách</span>
              <span>{selected ? `Đang xem: ${selected.name}` : 'Chưa chọn khách hàng'}</span>
            </div>
          </section>

          <aside className="pc-customers-panel" aria-label="Chi tiết khách hàng">
            {selected ? (
              <>
                <div className="pc-customers-detail-head">
                  <div className="pc-customers-detail-title">
                    <span className="pc-customers-avatar lg">{selected.name.charAt(0).toUpperCase()}</span>
                    <span className="pc-customers-detail-name">
                      <b title={selected.name}>{selected.name}</b>
                      <span className={`pc-customers-tag tier-${selected.tier ?? 'member'}`}>{pcTierLabel(selected.tier)}</span>
                    </span>
                  </div>
                  <button type="button" className="pc-customers-close" aria-label="Đóng chi tiết" onClick={() => setSelected(null)}>
                    <LineIcon name="x" size={18} />
                  </button>
                </div>

                <div className="pc-customers-info-grid">
                  <div><div className="pc-customers-lbl">Họ tên</div><div className="pc-customers-val" title={selected.name}>{selected.name}</div></div>
                  <div><div className="pc-customers-lbl">Hạng</div><div className="pc-customers-val">{pcTierLabel(selected.tier)}</div></div>
                  <div><div className="pc-customers-lbl">Ngày sinh</div><div className="pc-customers-val">{pcBirthdayLabel(selected.birthday)}</div></div>
                  <div><div className="pc-customers-lbl">Số điện thoại</div><div className="pc-customers-val pc-customers-nowrap">{selected.phone}</div></div>
                  <div className="pc-customers-full"><div className="pc-customers-lbl">Địa chỉ</div><div className="pc-customers-val">{selected.address || '—'}</div></div>
                  {selected.note && <div className="pc-customers-full"><div className="pc-customers-lbl">Ghi chú</div><div className="pc-customers-val">{selected.note}</div></div>}
                  {warehouses.length > 1 && selected.warehouse_id && (
                    <div className="pc-customers-full"><div className="pc-customers-lbl">Kho của khách</div><div className="pc-customers-val">{warehouses.find((w) => w.id === selected.warehouse_id)?.name ?? ''}</div></div>
                  )}
                </div>

                <div className="pc-customers-highlights">
                  <div className="pc-customers-hl"><div className="pc-customers-lbl">Tổng mua</div><div className="pc-customers-hl-val">{formatVND(selected.total_spent ?? 0)}</div></div>
                  <div className="pc-customers-hl"><div className="pc-customers-lbl">Công nợ</div><div className="pc-customers-hl-val pc-customers-red">{formatVND(selected.debt)}</div></div>
                  <div className="pc-customers-hl"><div className="pc-customers-lbl">Điểm</div><div className="pc-customers-hl-val">{(selected.points ?? 0).toLocaleString('vi-VN')}</div></div>
                </div>

                <PcRewardBlock
                  customer={selected}
                  stampsTarget={stampsTarget}
                  onChanged={(c) => { setSelected(c); void search(q); }}
                />

                <div className="pc-customers-actions">
                  <button type="button" className="btn btn-outline pc-customers-btn-block" onClick={() => setFormOpen(selected)}>
                    <LineIcon name="edit" size={18} /> Sửa
                  </button>
                  <button type="button" className="btn pc-customers-btn-block" onClick={() => pcScrollTo('pc-customers-debt')}>
                    <LineIcon name="wallet" size={18} /> Thu nợ
                  </button>
                </div>

                <div className="pc-customers-block">
                  <div className="pc-customers-block-title">Lịch sử mua hàng</div>
                  {(selected.recent_orders ?? []).length === 0 && <p className="pc-customers-hint">Chưa có đơn nào</p>}
                  {(selected.recent_orders ?? []).map((o) => (
                    <div key={o.id} className="pc-customers-hist">
                      <div className="pc-customers-hist-main">
                        <b>{o.code}</b>
                        <span className="pc-customers-hist-sub" title={(o.items ?? []).map((i) => i.product_name).join(', ')}>
                          {formatDateTime(o.created_at)}{(o.items ?? []).length > 0 ? ` - ${(o.items ?? []).map((i) => i.product_name).join(', ')}` : ''}
                        </span>
                      </div>
                      <span className="pc-customers-hist-amount pc-customers-nowrap">{formatVND(o.total)}</span>
                    </div>
                  ))}
                </div>

                <div className="pc-customers-debt">
                  <div className="pc-customers-block-title">Công nợ - Thu nợ theo quỹ</div>
                  <DebtCard
                    customer={selected}
                    onChanged={async () => { if (selected) await pcRefreshSelected(selected.id); }}
                  />
                </div>
              </>
            ) : (
              <div className="pc-customers-placeholder">
                <LineIcon name="users" size={40} />
                <p><b>Chọn một khách hàng</b></p>
                <p>Bấm một dòng ở bảng bên trái để xem chi tiết, công nợ, điểm và lịch sử mua hàng ở đây.</p>
              </div>
            )}

            <div className="pc-customers-birthday">
              <div className="pc-customers-block-title">Sinh nhật &amp; Zalo</div>
              <p className="pc-customers-hint">Sinh nhật trong 30 ngày tới, kèm mẫu tin nhắn và nút mở chat Zalo.</p>
              <BirthdayZaloTab list={visible} shopName={shopName} />
            </div>
          </aside>
        </div>

        {formOpen && (
          <CustomerForm
            customer={formOpen === 'new' ? null : formOpen}
            warehouses={warehouses}
            onClose={() => setFormOpen(null)}
            onSaved={() => void search(q)}
          />
        )}
      </div>
    );
  }

  return (
    <div className="page">
      <PageHead
        title="Khách hàng"
        right={
          <button className="btn btn-add-customer" onClick={() => setFormOpen('new')}>
            <span aria-hidden>＋</span> Thêm
          </button>
        }
      />

      <div className="row" style={{ gap: 8, marginBottom: 12 }}>
        <button type="button" className={`sb-chip${custTab === 'list' ? ' selected' : ''}`} onClick={() => setCustTab('list')}>
          👥 Danh sách
        </button>
        <button type="button" className={`sb-chip${custTab === 'birthday' ? ' selected' : ''}`} onClick={() => setCustTab('birthday')}>
          🎂 Sinh nhật & Zalo
        </button>
      </div>

      {custTab === 'birthday' ? (
        <BirthdayZaloTab list={visible} shopName={shopName} />
      ) : (
      <>
      <div className="sb-search" style={{ marginBottom: 12 }}>
        <span className="sico"><TIcon emoji="🔍" size={18} /></span>
        <input
          placeholder="Tìm tên, số điện thoại…"
          value={q}
          onChange={(e) => {
            setQ(e.target.value);
            void search(e.target.value);
          }}
          aria-label="Tìm khách hàng"
        />
      </div>

      <button className="sb-menu-row" onClick={() => navigate('/debt')} style={{ marginBottom: 12, borderRadius: 14, background: 'var(--surface)', boxShadow: 'var(--shadow)' }}>
        <span className="sb-ico-box" style={{ background: '#F3E8FF' }}>📒</span>
        <span>Sổ nợ</span>
        <span className="chev">›</span>
      </button>

      {warehouses.length > 1 && (
        <div className="row" style={{ gap: 8, marginBottom: 12, flexWrap: 'wrap' }}>
          <button className={`sb-chip${whFilter === 'all' ? ' selected' : ''}`} onClick={() => setWhFilter('all')}>
            Mọi kho
          </button>
          {warehouses.map((w) => (
            <button key={w.id} className={`sb-chip${whFilter === w.id ? ' selected' : ''}`} onClick={() => setWhFilter(w.id)}>
              {w.name}
            </button>
          ))}
        </div>
      )}

      <div className="sb-section" style={{ padding: '4px 16px' }}>
        {visible.map((c) => (
          <button key={c.id} className="sb-row" onClick={() => openDetail(c.id)}>
            <span className="avatar">{c.name.charAt(0).toUpperCase()}</span>
            <span className="rbody">
              <span className="rtitle">
                {c.name}
                {c.reward_available ? ' 🎁' : ''}
                {c.tier && c.tier !== 'member' && <span className="small"> {TIER_LABEL[c.tier]}</span>}
              </span>
              <span className="rsub">
                {c.phone}
                {warehouses.length > 1 && c.warehouse_id
                  ? ` · ${warehouses.find((w) => w.id === c.warehouse_id)?.name ?? ''}`
                  : ''}
              </span>
            </span>
            <span style={{ textAlign: 'right', flexShrink: 0 }}>
              <span className="small muted" style={{ display: 'block' }}>
                🎟️ {c.stamps}/{stampsTarget} · ⭐ {c.points ?? 0}đ
              </span>
              {c.debt > 0 && (
                <span className="ramount text-orange" style={{ display: 'block', marginTop: 2 }}>
                  {formatVND(c.debt)}
                </span>
              )}
            </span>
            <span className="chev muted" style={{ fontSize: 22 }}>›</span>
          </button>
        ))}
        {visible.length === 0 && !busy && (
          <div className="sb-empty">
            <div className="eico">👥</div>
            <p>
              Chưa có khách hàng nào.
              <br />
              Thêm khách để tích tem và theo dõi công nợ.
            </p>
          </div>
        )}
      </div>

      <button className="fab" onClick={() => setFormOpen('new')} aria-label="Thêm khách hàng mới">
        +
      </button>

      </>
      )}

      {selected && (
        <CustomerDetail
          customer={selected}
          stampsTarget={stampsTarget}
          onClose={() => setSelected(null)}
          onEdit={() => setFormOpen(selected)}
          onChanged={(c) => {
            setSelected(c);
            void search(q);
          }}
        />
      )}
      {formOpen && (
        <CustomerForm
          customer={formOpen === 'new' ? null : formOpen}
          warehouses={warehouses}
          onClose={() => setFormOpen(null)}
          onSaved={() => void search(q)}
        />
      )}
    </div>
  );
}

function CustomerDetail({ customer, stampsTarget, onClose, onEdit, onChanged }: {
  customer: Customer;
  stampsTarget: number;
  onClose: () => void;
  onEdit: () => void;
  onChanged: (c: Customer) => void;
}) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);

  const redeem = async () => {
    const lastOrder = customer.recent_orders?.[0];
    if (!lastOrder) {
      toast.show('Khách chưa có đơn nào để đổi thưởng');
      return;
    }
    if (!window.confirm(`Đổi thưởng cho ${customer.name}? (mua ${stampsTarget} tặng 1)`)) return;
    setBusy(true);
    try {
      await redeemReward(customer.id);
      toast.show('🎁 Đã đổi thưởng thành công!');
      const c = await getCustomer(customer.id);
      if (c) onChanged(c);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Đổi thưởng thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet title={customer.name} onClose={onClose}>
      <div className="sb-section">
        <div className="row" style={{ marginBottom: 8 }}>
          <h3 className="sb-section-title grow" style={{ margin: 0 }}>Thông tin</h3>
          <button className="btn btn-ghost btn-sm" style={{ minHeight: 44, padding: '6px 12px' }} onClick={onEdit}>
            Sửa
          </button>
        </div>
        <div className="row small" style={{ marginBottom: 6 }}>
          <span className="muted grow">Số điện thoại</span>
          <b>{customer.phone}</b>
        </div>
        {customer.birthday && (
          <div className="row small" style={{ marginBottom: 6 }}>
            <span className="muted grow">Ngày sinh</span>
            <b>{customer.birthday}</b>
          </div>
        )}
        {customer.address && (
          <div className="row small" style={{ marginBottom: 6 }}>
            <span className="muted grow">Địa chỉ</span>
            <b>{customer.address}</b>
          </div>
        )}
        {customer.note && <div className="small muted" style={{ marginTop: 6 }}>{customer.note}</div>}
      </div>

      <div className="sb-section">
        <h3 className="sb-section-title">⭐ Tích điểm & hạng</h3>
        <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <div style={{ fontSize: 22, fontWeight: 800 }}>{(customer.points ?? 0).toLocaleString('vi-VN')} <span className="small muted">điểm</span></div>
            <div className="small muted">Đã chi tiêu: {formatVND(customer.total_spent ?? 0)}</div>
          </div>
          <div className="sb-chip selected" style={{ fontSize: 15 }}>{TIER_LABEL[customer.tier ?? 'member']}</div>
        </div>
      </div>

      <div className="sb-section">
        <h3 className="sb-section-title">
          Tích tem <span className="muted">({customer.stamps}/{stampsTarget})</span>
        </h3>
        <div className="stamps">
          {Array.from({ length: stampsTarget }).map((_, i) => (
            <span key={i} className={`stamp${i < customer.stamps ? ' on' : ''}`}>{i < customer.stamps ? '☕' : '·'}</span>
          ))}
        </div>
        {customer.reward_available ? (
          <button className="btn btn-green btn-block" style={{ minHeight: 48, marginTop: 8 }} disabled={busy} onClick={redeem}>
            🎁 Đổi thưởng (mua {stampsTarget} tặng 1)
          </button>
        ) : (
          <p className="small muted" style={{ margin: 0 }}>
            Còn {stampsTarget - customer.stamps} tem nữa để nhận 1 ly miễn phí.
          </p>
        )}
      </div>

      <DebtCard
        customer={customer}
        onChanged={async () => {
          const c = await getCustomer(customer.id);
          if (c) onChanged(c);
        }}
      />

      <div className="sb-section" style={{ padding: '8px 16px' }}>
        <h3 className="sb-section-title" style={{ margin: '6px 0 4px' }}>Đơn gần nhất</h3>
        {(customer.recent_orders ?? []).map((o) => (
          <div key={o.id} className="sb-row" style={{ cursor: 'default' }}>
            <span className="rbody">
              <span className="rtitle">{o.code}</span>
              <span className="rsub">{formatDateTime(o.created_at)}</span>
            </span>
            <span className="ramount">{formatVND(o.total)}</span>
          </div>
        ))}
        {(customer.recent_orders ?? []).length === 0 && (
          <p className="muted small" style={{ margin: '8px 0' }}>Chưa có đơn nào</p>
        )}
      </div>
    </Sheet>
  );
}

function DebtCard({ customer, onChanged }: { customer: Customer; onChanged: () => Promise<void> }) {
  const toast = useToast();
  const [logs, setLogs] = useState<DebtLog[]>([]);
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const [funds, setFunds] = useState<Fund[]>([]);
  const [fundId, setFundId] = useState('');

  useEffect(() => {
    listDebtLogs(customer.id).then(setLogs).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [customer.id, customer.debt]);

  useEffect(() => {
    getFunds()
      .then((fs) => {
        const act = fs.filter((f) => f.active);
        setFunds(act);
        setFundId((cur) => cur || act.find((f) => f.kind === 'cash')?.id || act[0]?.id || '');
      })
      .catch(() => {});
  }, []);

  const submit = async (isPayment: boolean) => {
    const v = parseInt(amount.replace(/\D/g, ''), 10);
    if (!v || v <= 0) {
      toast.show('Nhập số tiền hợp lệ');
      return;
    }
    setBusy(true);
    try {
      if (isPayment) {
        // Thu nợ QUA collectCustomerDebt: trừ nợ + ghi khoản thu vào Sổ quỹ
        // trong CÙNG 1 transaction (giống màn Sổ nợ). Bản cũ thu bằng
        // adjustDebt nên tiền thu ở màn này không bao giờ vào Sổ quỹ.
        await collectCustomerDebt(customer.id, v, {
          note: note.trim() || `Thu nợ — ${customer.name}`,
          fundId: fundId || null,
          method: funds.find((f) => f.id === fundId)?.kind === 'transfer' ? 'transfer' : 'cash',
          warehouseId: customer.warehouse_id ?? null,
        });
      } else {
        await adjustDebt(customer.id, v, note.trim() || null);
      }
      toast.show(isPayment ? `Đã thu ${formatVND(v)}` : `Đã ghi nợ ${formatVND(v)}`);
      setAmount('');
      setNote('');
      await onChanged();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Cập nhật công nợ thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="sb-section">
      <div className="row" style={{ marginBottom: 12 }}>
        <h3 className="sb-section-title grow" style={{ margin: 0 }}>Công nợ</h3>
        <b className="money text-orange" style={{ fontSize: 20 }}>
          {formatVND(customer.debt)}
        </b>
      </div>
      <div className="sb-float">
        <input
          inputMode="numeric"
          placeholder=" "
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
        <label>Số tiền</label>
      </div>
      <div className="sb-float">
        <input
          placeholder=" "
          value={note}
          onChange={(e) => setNote(e.target.value)}
        />
        <label>Ghi chú (không bắt buộc)</label>
      </div>
      {funds.length > 0 && (
        <div style={{ marginBottom: 12 }}>
          <div className="small muted" style={{ marginBottom: 4 }}>Thu nợ vào quỹ</div>
          <select
            value={fundId}
            onChange={(e) => setFundId(e.target.value)}
            style={{ width: '100%', minHeight: 44, borderRadius: 8, padding: '0 10px' }}
          >
            {funds.map((f) => (
              <option key={f.id} value={f.id}>{f.name}</option>
            ))}
          </select>
        </div>
      )}
      <div className="row" style={{ gap: 12, marginBottom: 4 }}>
        <button className="btn btn btn-block" style={{ minHeight: 48 }} disabled={busy} onClick={() => submit(false)}>
          Ghi nợ
        </button>
        <button className="btn btn-block" style={{ minHeight: 48 }} disabled={busy || customer.debt <= 0} onClick={() => submit(true)}>
          Thu nợ
        </button>
      </div>
      {logs.length > 0 && (
        <div style={{ marginTop: 4 }}>
          {logs.map((l) => (
            <div key={l.id} className="sb-row" style={{ cursor: 'default' }}>
              <span className="rbody">
                <span className="rsub" style={{ marginTop: 0 }}>{formatDateTime(l.created_at)}</span>
                {l.note && <span className="rtitle" style={{ fontSize: 14, fontWeight: 500 }}>{l.note}</span>}
              </span>
              <span style={{ textAlign: 'right', flexShrink: 0 }}>
                <b className={l.amount > 0 ? 'text-red' : 'text-green'}>
                  {l.amount > 0 ? '+' : '−'}{formatVND(Math.abs(l.amount))}
                </b>
                <span className="small muted" style={{ display: 'block' }}>Còn {formatVND(l.balance_after)}</span>
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function CustomerForm({ customer, warehouses, onClose, onSaved }: {
  customer: Customer | null;
  warehouses: Warehouse[];
  onClose: () => void;
  onSaved: () => void;
}) {
  const toast = useToast();
  const [name, setName] = useState(customer?.name ?? '');
  const [phone, setPhone] = useState(customer?.phone ?? '');
  const [birthday, setBirthday] = useState(customer?.birthday ?? '');
  const [address, setAddress] = useState(customer?.address ?? '');
  const [note, setNote] = useState(customer?.note ?? '');
  const [whId, setWhId] = useState(customer?.warehouse_id ?? '');
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) {
      toast.show('Nhập tên và SĐT');
      return;
    }
    setBusy(true);
    try {
      const body = { name: name.trim(), phone: phone.trim(), birthday: birthday || null, address: address.trim() || null, note: note.trim() || null, warehouse_id: whId || null };
      if (customer) await updateCustomer(customer.id, body);
      else await createCustomer(body);
      toast.show(customer ? 'Đã cập nhật' : 'Đã thêm khách hàng');
      onSaved();
      onClose();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet title={customer ? 'Sửa khách hàng' : 'Thêm khách hàng'} onClose={onClose}>
      <form onSubmit={submit}>
        <div className="sb-float">
          <input placeholder=" " value={name} onChange={(e) => setName(e.target.value)} />
          <label>Tên <span className="req">*</span></label>
        </div>
        <div className="sb-float">
          <input placeholder=" " inputMode="tel" value={phone} onChange={(e) => setPhone(e.target.value)} />
          <label>SĐT <span className="req">*</span></label>
        </div>
        <div className="sb-float">
          <input placeholder=" " type="date" value={birthday} onChange={(e) => setBirthday(e.target.value)} />
          <label>Ngày sinh</label>
        </div>
        <div className="sb-float">
          <input placeholder=" " value={address} onChange={(e) => setAddress(e.target.value)} />
          <label>Địa chỉ</label>
        </div>
        <div className="sb-float">
          <textarea placeholder=" " value={note} onChange={(e) => setNote(e.target.value)} />
          <label>Ghi chú</label>
        </div>
        {warehouses.length > 1 && (
          <div className="sb-float">
            <select value={whId} onChange={(e) => setWhId(e.target.value)} aria-label="Kho của khách">
              <option value="">Mọi kho</option>
              {warehouses.map((w) => (
                <option key={w.id} value={w.id}>{w.name}</option>
              ))}
            </select>
            <label>Kho của khách</label>
          </div>
        )}
        <button type="submit" className="btn btn-block btn-lg" style={{ minHeight: 52 }} disabled={busy}>
          {busy ? 'Đang lưu…' : 'Lưu'}
        </button>
      </form>
    </Sheet>
  );
}
