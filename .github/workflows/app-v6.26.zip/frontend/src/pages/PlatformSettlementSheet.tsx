// Ghi nhận tiền đơn sàn đã về tài khoản (v6.25, giữ nguyên ở v6.26).
// Form "Nhập đơn sàn" riêng đã bỏ ở v6.26 — đơn sàn bán chung ở màn Bán hàng
// (POS.tsx / CheckoutModal), nên file này chỉ còn sheet "Đã về tiền".
// Chỉ chủ quán bấm được (rules Firestore chỉ cho chủ quán sửa đơn ngoài
// status/note/customer_id; trang Đơn hàng cũng chặn nhân viên).
// Mô hình quỹ GỘP: thu = tổng đơn, chi phí sàn, chi thuế sàn — số dư quỹ
// tăng đúng bằng tiền thực về tài khoản.
import { useState } from 'react';
import { DbError, markPlatformOrderReceived } from '../lib/db';
import { formatVND } from '../lib/format';
import { useToast } from '../components/Toast';
import { Sheet } from '../components/Sheet';
import type { Order } from '../lib/types';
import { PLATFORM_STATUS_LABEL } from '../lib/types';

/** Form ghi nhận tiền đơn sàn đã về — chỉ chủ quán (rules chỉ cho chủ quán sửa đơn). */
export function PlatformSettlementSheet({
  order,
  onClose,
  onDone,
}: {
  order: Order;
  onClose: () => void;
  onDone: (order: Order) => void;
}) {
  const toast = useToast();
  const [feeText, setFeeText] = useState(String(order.platform_fee ?? 0));
  const [taxVatText, setTaxVatText] = useState(String(order.platform_tax_vat ?? 0));
  const [taxPitText, setTaxPitText] = useState(String(order.platform_tax_pit ?? 0));
  const [actualText, setActualText] = useState(String(order.platform_net_expected ?? 0));
  const [busy, setBusy] = useState(false);

  const fee = Math.max(0, Math.round(Number(feeText) || 0));
  const taxVat = Math.max(0, Math.round(Number(taxVatText) || 0));
  const taxPit = Math.max(0, Math.round(Number(taxPitText) || 0));
  const tax = taxVat + taxPit;
  const actual = Math.max(0, Math.round(Number(actualText) || 0));
  const expectedFromFeeTax = order.total - fee - tax;
  const diff = actual - expectedFromFeeTax;
  const platformName = order.source === 'grabfood' ? 'GrabFood' : order.source === 'shopeefood' ? 'ShopeeFood' : '';

  const submit = async () => {
    if (actual <= 0) {
      toast.show('Nhập tiền thực về tài khoản.');
      return;
    }
    if (actual > order.total) {
      toast.show('Tiền thực về không được lớn hơn tổng đơn.');
      return;
    }
    if (fee + tax >= order.total) {
      toast.show('Phí sàn + thuế không được lớn hơn hoặc bằng tổng đơn.');
      return;
    }
    setBusy(true);
    try {
      const updated = await markPlatformOrderReceived(order.id, {
        actualAmount: actual,
        fee,
        taxVat,
        taxPit,
      });
      toast.show(`Đã ghi nhận tiền về đơn ${order.code}: ${formatVND(actual)}.`);
      onDone(updated);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Ghi nhận tiền về thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet title={`Đã về tiền — đơn ${order.code}`} onClose={onClose}>
      <div style={{ display: 'grid', gap: 10 }}>
        <p className="small" style={{ margin: 0 }}>
          {platformName} {order.platform_order_code ? `· Mã sàn ${order.platform_order_code}` : ''} · Tổng đơn{' '}
          <b>{formatVND(order.total)}</b>
        </p>
        <div className="field">
          <label>Chiết khấu sàn thực tế (đ) — sửa theo sao kê sàn nếu khác số dự kiến</label>
          <input className="input" type="number" min={0} step={1} value={feeText} onChange={(e) => setFeeText(e.target.value)} />
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
          <div className="field">
            <label>Thuế GTGT thực tế (đ)</label>
            <input className="input" type="number" min={0} step={1} value={taxVatText} onChange={(e) => setTaxVatText(e.target.value)} />
          </div>
          <div className="field">
            <label>Thuế TNCN thực tế (đ)</label>
            <input className="input" type="number" min={0} step={1} value={taxPitText} onChange={(e) => setTaxPitText(e.target.value)} />
          </div>
        </div>
        <div className="field">
          <label>Tiền thực về tài khoản (đ) — nhập theo sao kê ngân hàng / GrabMerchant</label>
          <input className="input" type="number" min={0} step={1} value={actualText} onChange={(e) => setActualText(e.target.value)} />
        </div>
        <div className="card" style={{ margin: 0 }}>
          <div className="row" style={{ justifyContent: 'space-between' }}>
            <span className="muted">Tổng đơn − phí − thuế</span>
            <b>{formatVND(expectedFromFeeTax)}</b>
          </div>
          <div className="row" style={{ justifyContent: 'space-between' }}>
            <span className="muted">Tiền thực về nhập vào</span>
            <b>{formatVND(actual)}</b>
          </div>
          {diff !== 0 && (
            <p className="small" style={{ margin: '6px 0 0', color: '#B45309' }}>
              Chênh {formatVND(Math.abs(diff))} so với tổng đơn − phí − thuế. Kiểm tra lại phí/thuế theo sao kê
              sàn trước khi lưu — tiền thực về và phí/thuế phải khớp nhau thì sổ quỹ mới đối chiếu đúng.
            </p>
          )}
          <p className="small muted" style={{ margin: '6px 0 0' }}>
            Sau khi lưu: quỹ Chuyển khoản ghi thu {formatVND(order.total)} (tổng đơn), chi phí sàn{' '}
            {formatVND(fee)}, chi thuế sàn {formatVND(tax)} — số dư quỹ tăng đúng {formatVND(expectedFromFeeTax)}.
            Trạng thái đơn chuyển thành “{PLATFORM_STATUS_LABEL['da-ve']}”.
          </p>
        </div>
        <button className="btn btn-block" style={{ minHeight: 48 }} disabled={busy} onClick={() => void submit()}>
          {busy ? 'Đang lưu…' : 'Xác nhận đã về tiền'}
        </button>
      </div>
    </Sheet>
  );
}
