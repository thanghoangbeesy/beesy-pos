// Sổ nợ — thao tác nhanh kiểu "Tôi đã đưa / Tôi đã nhận".
// Dùng dữ liệu công nợ sẵn có (Customer.debt + adjustDebt trong lib/db.ts).
import { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { DbError, adjustDebt, collectCustomerDebt, getAllowedWarehouses, getFunds, listDebtLogs, listSuppliers, searchCustomers, toLocalDateTimeInput } from '../lib/db';
import { formatDMY, formatVND, unsignVietnamese } from '../lib/format';
import { Sheet } from '../components/Sheet';
import { TIcon } from '../components/TIcon';
import { PageHead } from '../components/PageHead';
import { useToast } from '../components/Toast';
import { useAuth } from '../lib/auth';
import { LineIcon } from '../components/LineIcon';
import type { Customer, DebtLog, Fund, Supplier, Warehouse } from '../lib/types';
import './pc-debt.css';

/** Hook phat hien man hinh PC (>= 1024px), theo mau pages/Reports.tsx. */
function useIsPC(): boolean {
  const [isPC, setIsPC] = useState(() => typeof window !== 'undefined' && window.innerWidth >= 1024);
  useEffect(() => {
    const onResize = () => setIsPC(window.innerWidth >= 1024);
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);
  return isPC;
}

/** Nhan hang thanh vien that (khong dung emoji cua TIER_LABEL trong JSX PC). */
function tierLabel(tier: Customer['tier'] | undefined): string {
  if (tier === 'gold') return 'Vàng';
  if (tier === 'silver') return 'Bạc';
  return 'Thành viên';
}

export function DebtBook() {
  const navigate = useNavigate();
  const toast = useToast();
  const { can } = useAuth();
  const canDebt = can('debt');
  const isPC = useIsPC();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [list, setList] = useState<Customer[]>([]);
  // Cong no phai tra NCC (v5.7): tab "phai tra" trong bao cao cong no
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [tab, setTab] = useState<'receivable' | 'payable'>('receivable');
  const [q, setQ] = useState('');
  const [busy, setBusy] = useState(true);
  const [sheet, setSheet] = useState<'give' | 'receive' | null>(null);
  // Khách chọn sẵn cho sheet Thu/Ghi nợ khi bấm từ panel PC (mobile không
  // đặt nên luôn null → hành vi mobile y nguyên).
  const [sheetCustomer, setSheetCustomer] = useState<Customer | null>(null);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [whFilter, setWhFilter] = useState('all');

  const load = useCallback(async () => {
    setBusy(true);
    try {
      const [all, allowed, sups] = await Promise.all([
        searchCustomers(''),
        getAllowedWarehouses(),
        listSuppliers().catch(() => [] as Supplier[]),
      ]);
      const ws = allowed.warehouses;
      setList(all.filter((c) => c.debt > 0));
      setSuppliers(sups.filter((s) => s.debt > 0).sort((a, b) => b.debt - a.debt));
      setWarehouses(ws);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tải được sổ nợ');
    } finally {
      setBusy(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const needle = unsignVietnamese(q.trim()).toLowerCase();
  const whList = whFilter === 'all' ? list : list.filter((c) => !c.warehouse_id || c.warehouse_id === whFilter);
  const filtered = needle
    ? whList.filter((c) => unsignVietnamese(`${c.name} ${c.phone}`).toLowerCase().includes(needle))
    : whList;
  const total = whList.reduce((s, c) => s + c.debt, 0);
  const supFiltered = needle
    ? suppliers.filter((s) => unsignVietnamese(`${s.name} ${s.phone}`).toLowerCase().includes(needle))
    : suppliers;
  const totalPayable = suppliers.reduce((s, x) => s + x.debt, 0);

  // ---- Nhanh PC (chi them, khong dung toi JSX mobile phia duoi) ----
  // Sap xep ban PC theo cong no giam dan nhu demo; ban mobile giu nguyen thu tu cu.
  const pcCustomers = [...filtered].sort((a, b) => b.debt - a.debt);
  const pcSuppliers = [...supFiltered].sort((a, b) => b.debt - a.debt);
  const pcRows = tab === 'receivable' ? pcCustomers : pcSuppliers;
  const pcSelectedCustomer = tab === 'receivable'
    ? (pcCustomers.find((c) => c.id === selectedId) ?? pcCustomers[0] ?? null)
    : null;
  const pcSelectedSupplier = tab === 'payable'
    ? (pcSuppliers.find((s) => s.id === selectedId) ?? pcSuppliers[0] ?? null)
    : null;
  const warehouseName = (id: string | null) =>
    warehouses.find((w) => w.id === id)?.name ?? '';

  if (isPC) {
    return (
      <div className="pc-debt-page">
        <div className="pc-debt-head">
          <div className="pc-debt-head-text">
            <h1>Sổ nợ</h1>
            <p>Theo dõi tiền khách nợ quán và tiền quán nợ nhà cung cấp, thu nợ và ghi nợ mới ngay tại quầy.</p>
          </div>
          <button className="btn btn-outline pc-debt-refresh" type="button" onClick={() => void load()} disabled={busy}>
            <LineIcon name="refresh" size={18} />
            <span>{busy ? 'Đang tải...' : 'Tải lại'}</span>
          </button>
        </div>

        <div className="pc-debt-stats">
          <div className="pc-debt-stat">
            <div className="pc-debt-stat-label">Tổng phải thu</div>
            <div className="pc-debt-stat-value pc-debt-red">{formatVND(total)}</div>
            <div className="pc-debt-stat-sub">Tiền khách đang nợ quán</div>
          </div>
          <div className="pc-debt-stat">
            <div className="pc-debt-stat-label">Tổng phải trả</div>
            <div className="pc-debt-stat-value pc-debt-red">{formatVND(totalPayable)}</div>
            <div className="pc-debt-stat-sub">Tiền quán nợ nhà cung cấp</div>
          </div>
          <div className="pc-debt-stat">
            <div className="pc-debt-stat-label">Chênh lệch</div>
            <div className="pc-debt-stat-value" style={{ color: total - totalPayable >= 0 ? 'var(--green)' : 'var(--red)' }}>
              {formatVND(total - totalPayable)}
            </div>
            <div className="pc-debt-stat-sub">Phải thu trừ phải trả</div>
          </div>
          <div className="pc-debt-stat">
            <div className="pc-debt-stat-label">Số khách đang nợ</div>
            <div className="pc-debt-stat-value">{whList.length} khach</div>
            <div className="pc-debt-stat-sub">Chỉ tính khách còn nợ trên 0đ</div>
          </div>
        </div>

        <div className="pc-debt-tabs" role="tablist">
          <button
            type="button"
            className={`pc-debt-tab${tab === 'receivable' ? ' pc-debt-tab-active' : ''}`}
            onClick={() => setTab('receivable')}
          >
            Phải thu ({list.length})
          </button>
          <button
            type="button"
            className={`pc-debt-tab${tab === 'payable' ? ' pc-debt-tab-active' : ''}`}
            onClick={() => setTab('payable')}
          >
            Phải trả ({suppliers.length})
          </button>
        </div>

        <div className="pc-debt-toolbar">
          <label className="pc-debt-search">
            <LineIcon name="search" size={18} />
            <input
              placeholder="Tìm khách theo tên hoặc SĐT..."
              value={q}
              onChange={(e) => setQ(e.target.value)}
              aria-label="Tìm khách theo tên hoặc SĐT"
            />
          </label>
          {tab === 'receivable' && warehouses.length > 1 && (
            <div className="pc-debt-wh">
              <button type="button" className={`pc-debt-chip${whFilter === 'all' ? ' pc-debt-chip-active' : ''}`} onClick={() => setWhFilter('all')}>
                Mọi kho
              </button>
              {warehouses.map((w) => (
                <button key={w.id} type="button" className={`pc-debt-chip${whFilter === w.id ? ' pc-debt-chip-active' : ''}`} onClick={() => setWhFilter(w.id)} title={w.name}>
                  {w.name}
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="pc-debt-layout">
          <section className="pc-debt-card pc-debt-table-card">
            <div className="pc-debt-card-head">
              <h3>{tab === 'receivable' ? 'Khách đang nợ' : 'Nhà cung cấp đang chờ thanh toán'}</h3>
              <span className="muted small">{pcRows.length} {tab === 'receivable' ? 'khach' : 'nhà cung cấp'} - sắp xếp theo công nợ giảm dần</span>
            </div>
            {busy ? (
              <p className="muted pc-debt-empty">Đang tải...</p>
            ) : pcRows.length === 0 ? (
              <p className="muted pc-debt-empty">
                {tab === 'receivable' ? 'Chưa có khoản nợ nào.' : 'Không nợ nhà cung cấp nào.'}
              </p>
            ) : (
              <div className="pc-debt-table-wrap">
                <table className="pc-debt-table">
                  <thead>
                    <tr>
                      <th>{tab === 'receivable' ? 'Khách hàng' : 'Nhà cung cấp'}</th>
                      <th>SDT</th>
                      <th className="pc-debt-r">Công nợ</th>
                      <th>Ghi chú</th>
                      <th>Thao tác</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pcRows.map((row) => {
                      const isSelected = tab === 'receivable'
                        ? pcSelectedCustomer?.id === row.id
                        : pcSelectedSupplier?.id === row.id;
                      const note = (row as Customer).note ?? (row as Supplier).note ?? '';
                      return (
                        <tr
                          key={row.id}
                          className={isSelected ? 'pc-debt-row-selected' : ''}
                          onClick={() => setSelectedId(row.id)}
                        >
                          <td>
                            <span className="pc-debt-cust">
                              <span className="pc-debt-avatar">{row.name.charAt(0).toUpperCase()}</span>
                              <span className="pc-debt-cust-text">
                                <b title={row.name}>{row.name}</b>
                                {tab === 'receivable' && (
                                  <span className="pc-debt-tag">{tierLabel((row as Customer).tier)}</span>
                                )}
                              </span>
                            </span>
                          </td>
                          <td className="pc-debt-nowrap">{row.phone || 'Chưa có SĐT'}</td>
                          <td className="pc-debt-r pc-debt-money pc-debt-red">{formatVND(row.debt)}</td>
                          <td className="pc-debt-note" title={note || undefined}>{note || '—'}</td>
                          <td>
                            <button
                              type="button"
                              className="pc-debt-view"
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedId(row.id);
                              }}
                            >
                              <LineIcon name="eye" size={18} />
                              <span>Xem chi tiết</span>
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
            <div className="pc-debt-pager">
              <span>Hiển thị {pcRows.length} trên {pcRows.length} {tab === 'receivable' ? 'khách đang nợ' : 'nhà cung cấp'}</span>
            </div>
          </section>

          <aside className="pc-debt-card pc-debt-detail">
            {tab === 'receivable' ? (
              pcSelectedCustomer ? (
                <>
                  <div className="pc-debt-detail-head">
                    <span className="pc-debt-avatar pc-debt-avatar-lg">{pcSelectedCustomer.name.charAt(0).toUpperCase()}</span>
                    <div className="pc-debt-detail-head-text">
                      <b title={pcSelectedCustomer.name}>{pcSelectedCustomer.name}</b>
                      <div>
                        <span className="pc-debt-tag">{tierLabel(pcSelectedCustomer.tier)}</span>
                        <span className="muted small"> Đang chọn</span>
                      </div>
                    </div>
                  </div>
                  <div className="pc-debt-contact">
                    <div className="pc-debt-rowline"><span className="muted">SDT</span><span className="pc-debt-nowrap">{pcSelectedCustomer.phone || 'Chưa có SĐT'}</span></div>
                    {pcSelectedCustomer.address && (
                      <div className="pc-debt-rowline"><span className="muted">Địa chỉ</span><span title={pcSelectedCustomer.address}>{pcSelectedCustomer.address}</span></div>
                    )}
                    {pcSelectedCustomer.warehouse_id && warehouseName(pcSelectedCustomer.warehouse_id) && (
                      <div className="pc-debt-rowline"><span className="muted">Kho</span><span>{warehouseName(pcSelectedCustomer.warehouse_id)}</span></div>
                    )}
                    <div className="pc-debt-rowline"><span className="muted">Điểm tích lũy</span><span>{pcSelectedCustomer.points} điểm</span></div>
                    {pcSelectedCustomer.note && (
                      <div className="pc-debt-rowline"><span className="muted">Ghi chú</span><span title={pcSelectedCustomer.note}>{pcSelectedCustomer.note}</span></div>
                    )}
                  </div>
                  <div className="pc-debt-detail-total">
                    <div className="pc-debt-detail-total-label">Tổng công nợ</div>
                    <div className="pc-debt-detail-total-value">{formatVND(pcSelectedCustomer.debt)}</div>
                    <div className="muted small">Khách còn nợ quán</div>
                  </div>
                  <h3 className="pc-debt-detail-title">Lịch sử công nợ</h3>
                  <PcDebtHistory customerId={pcSelectedCustomer.id} />
                  <div className="pc-debt-detail-actions">
                    <button
                      type="button"
                      className="btn btn-block"
                      onClick={() => (canDebt ? (setSheetCustomer(pcSelectedCustomer), setSheet('receive')) : toast.show('Chỉ Thu ngân trở lên mới được thu nợ'))}
                    >
                      <LineIcon name="wallet" size={18} />
                      <span>Thu nợ</span>
                    </button>
                    <button
                      type="button"
                      className="btn btn-outline btn-block"
                      onClick={() => (canDebt ? (setSheetCustomer(pcSelectedCustomer), setSheet('give')) : toast.show('Chỉ Thu ngân trở lên mới được ghi nợ'))}
                    >
                      <LineIcon name="plus" size={18} />
                      <span>Ghi nợ moi</span>
                    </button>
                    <button type="button" className="btn btn-ghost btn-block" onClick={() => navigate('/customers')}>
                      <LineIcon name="users" size={18} />
                      <span>Xem chi tiết day du</span>
                    </button>
                  </div>
                  <p className="muted small pc-debt-detail-note">Thu nợ sẽ trừ công nợ và ghi vào Sổ quỹ. Ghi nợ mới chỉ tăng công nợ, chưa thu tiền. Sheet mở ra với khách đang chọn sẵn (bấm Đổi để chọn khách khác).</p>
                </>
              ) : (
                <p className="muted pc-debt-empty">Chưa có khách nợ nào để hiển thị.</p>
              )
            ) : (
              pcSelectedSupplier ? (
                <>
                  <div className="pc-debt-detail-head">
                    <span className="pc-debt-avatar pc-debt-avatar-lg">{pcSelectedSupplier.name.charAt(0).toUpperCase()}</span>
                    <div className="pc-debt-detail-head-text">
                      <b title={pcSelectedSupplier.name}>{pcSelectedSupplier.name}</b>
                      <div><span className="muted small">Đang chọn</span></div>
                    </div>
                  </div>
                  <div className="pc-debt-contact">
                    <div className="pc-debt-rowline"><span className="muted">SDT</span><span className="pc-debt-nowrap">{pcSelectedSupplier.phone || 'Chưa có SĐT'}</span></div>
                    {pcSelectedSupplier.address && (
                      <div className="pc-debt-rowline"><span className="muted">Địa chỉ</span><span title={pcSelectedSupplier.address}>{pcSelectedSupplier.address}</span></div>
                    )}
                    {pcSelectedSupplier.note && (
                      <div className="pc-debt-rowline"><span className="muted">Ghi chú</span><span title={pcSelectedSupplier.note}>{pcSelectedSupplier.note}</span></div>
                    )}
                  </div>
                  <div className="pc-debt-detail-total">
                    <div className="pc-debt-detail-total-label">Tổng công nợ phải trả</div>
                    <div className="pc-debt-detail-total-value">{formatVND(pcSelectedSupplier.debt)}</div>
                    <div className="muted small">Quan con no nhà cung cấp</div>
                  </div>
                  <div className="pc-debt-detail-actions">
                    <button type="button" className="btn btn-block" onClick={() => navigate('/nhap-hang')}>
                      <LineIcon name="truck" size={18} />
                      <span>Sang trang Nhập hàng</span>
                    </button>
                  </div>
                  <p className="muted small pc-debt-detail-note">Bam vao nhà cung cấp de sang trang Nhap hang - tra no tai do se ghi vao So quy (dung co che nhu ban mobile).</p>
                </>
              ) : (
                <p className="muted pc-debt-empty">Không nợ nhà cung cấp nào.</p>
              )
            )}
          </aside>
        </div>

        {sheet && (
          <DebtSheet
            mode={sheet}
            initialCustomer={sheetCustomer}
            onClose={() => { setSheet(null); setSheetCustomer(null); }}
            onDone={() => {
              setSheet(null);
              setSheetCustomer(null);
              void load();
            }}
          />
        )}
      </div>
    );
  }

  return (
    <div className="page with-dual-actions">
      <PageHead title="Công nợ" back />

      <div className="sb-search" style={{ marginBottom: 12 }}>
        <span className="sico"><TIcon emoji="🔍" size={18} /></span>
        <input
          placeholder="Tìm tên, số điện thoại…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          aria-label="Tìm khách nợ"
        />
      </div>

      {tab === 'receivable' && warehouses.length > 1 && (
        <div className="row" style={{ gap: 8, marginBottom: 12, flexWrap: 'wrap' }}>
          <button className={`sb-chip${whFilter === 'all' ? ' selected' : ''}`} onClick={() => setWhFilter('all')}>
            Mọi kho
          </button>
          {warehouses.map((w) => (
            <button key={w.id} className={`sb-chip${whFilter === w.id ? ' selected' : ''}`} onClick={() => setWhFilter(w.id)}>
              {w.name}
            </button>
          ))}
        </div>
      )}

      {/* Tong hop cong no 2 chieu (v5.7): phai thu khach + phai tra NCC */}
      <div className="sb-section" style={{ marginBottom: 12 }}>
        <div className="row" style={{ justifyContent: 'space-around', textAlign: 'center' }}>
          <div>
            <div className="small muted">Phải thu (khách nợ)</div>
            <div className="money text-orange" style={{ fontSize: 19, fontWeight: 700 }}>{formatVND(total)}</div>
          </div>
          <div>
            <div className="small muted">Phải trả (nợ NCC)</div>
            <div className="money" style={{ fontSize: 19, fontWeight: 700, color: 'var(--red)' }}>{formatVND(totalPayable)}</div>
          </div>
          <div>
            <div className="small muted">Chênh lệch</div>
            <div className="money" style={{ fontSize: 19, fontWeight: 700, color: total - totalPayable >= 0 ? 'var(--green)' : 'var(--red)' }}>
              {formatVND(total - totalPayable)}
            </div>
          </div>
        </div>
      </div>

      <div className="row" style={{ gap: 8, marginBottom: 12 }}>
        <button
          className={`sb-chip${tab === 'receivable' ? ' selected' : ''}`}
          onClick={() => setTab('receivable')}
        >
          Khách nợ quán ({list.length})
        </button>
        <button
          className={`sb-chip${tab === 'payable' ? ' selected' : ''}`}
          onClick={() => setTab('payable')}
        >
          Quán nợ NCC ({suppliers.length})
        </button>
      </div>

      {tab === 'receivable' ? (
      <>
      <div className="sb-section" style={{ marginBottom: 12, textAlign: 'center' }}>
        <div className="small muted">Tổng công nợ cần thu</div>
        <div className="money text-orange" style={{ fontSize: 32, margin: '4px 0' }}>
          {formatVND(total)}
        </div>
        <div className="small muted">{list.length} khách đang nợ</div>
      </div>

      <div className="sb-section" style={{ padding: '4px 16px' }}>
        {busy ? (
          <p className="muted" style={{ textAlign: 'center' }}>
            Đang tải…
          </p>
        ) : filtered.length === 0 ? (
          <div className="sb-empty">
            <div className="eico"><TIcon emoji="📒" size={28} /></div>
            <p>
              Chưa có khoản nợ nào.
              <br />
              Ghi chép rõ ràng, thu hồi dễ dàng.
            </p>
          </div>
        ) : (
          filtered.map((c) => (
            <button key={c.id} className="sb-row" onClick={() => navigate('/customers')}>
              <span className="avatar">{c.name.charAt(0).toUpperCase()}</span>
              <span className="rbody">
                <span className="rtitle">{c.name}</span>
                <span className="rsub">{c.phone}</span>
              </span>
              <span className="ramount text-orange">{formatVND(c.debt)}</span>
              <span className="chev muted" style={{ fontSize: 22 }}>›</span>
            </button>
          ))
        )}
      </div>
      </>
      ) : (
      <>
      <div className="sb-section" style={{ marginBottom: 12, textAlign: 'center' }}>
        <div className="small muted">Tổng công nợ phải trả NCC</div>
        <div className="money" style={{ fontSize: 32, margin: '4px 0', color: 'var(--red)' }}>
          {formatVND(totalPayable)}
        </div>
        <div className="small muted">{suppliers.length} nhà cung cấp đang chờ thanh toán</div>
      </div>

      <div className="sb-section" style={{ padding: '4px 16px' }}>
        {busy ? (
          <p className="muted" style={{ textAlign: 'center' }}>
            Đang tải…
          </p>
        ) : supFiltered.length === 0 ? (
          <div className="sb-empty">
            <div className="eico"><TIcon emoji="🏭" size={28} /></div>
            <p>
              Không nợ nhà cung cấp nào.
              <br />
              Thanh toán sòng phẳng, nhập hàng dễ dàng.
            </p>
          </div>
        ) : (
          supFiltered.map((s) => (
            <button key={s.id} className="sb-row" onClick={() => navigate('/nhap-hang')}>
              <span className="avatar">{s.name.charAt(0).toUpperCase()}</span>
              <span className="rbody">
                <span className="rtitle">{s.name}</span>
                <span className="rsub">{s.phone || 'Chưa có SĐT'}</span>
              </span>
              <span className="ramount" style={{ color: 'var(--red)' }}>{formatVND(s.debt)}</span>
              <span className="chev muted" style={{ fontSize: 22 }}>›</span>
            </button>
          ))
        )}
      </div>
      <p className="small muted" style={{ textAlign: 'center', marginTop: 8 }}>
        Bấm vào nhà cung cấp để sang trang Nhập hàng — trả nợ tại đó sẽ ghi vào Sổ quỹ.
      </p>
      </>
      )}

      {tab === 'receivable' && (
      <div className="sb-dual-actions">
        <div className="inner">
          <button
            className="btn btn btn-block btn-lg"
            onClick={() => (canDebt ? setSheet('give') : toast.show('Chỉ Thu ngân trở lên mới được ghi nợ'))}
          >
            Tôi đã đưa
          </button>
          <button
            className="btn btn-block btn-lg"
            onClick={() => (canDebt ? setSheet('receive') : toast.show('Chỉ Thu ngân trở lên mới được thu nợ'))}
          >
            Tôi đã nhận
          </button>
        </div>
      </div>
      )}

      {sheet && (
        <DebtSheet
          mode={sheet}
          initialCustomer={sheetCustomer}
          onClose={() => { setSheet(null); setSheetCustomer(null); }}
          onDone={() => {
            setSheet(null);
            setSheetCustomer(null);
            void load();
          }}
        />
      )}
    </div>
  );
}

/** Lịch sử công nợ that cua khach dang chon (chi dung o panel PC, dung loader listDebtLogs san co nhu trang Khách hàng). */
function PcDebtHistory({ customerId }: { customerId: string }) {
  const [logs, setLogs] = useState<DebtLog[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    let alive = true;
    setLoading(true);
    listDebtLogs(customerId)
      .then((r) => { if (alive) setLogs(r); })
      .catch(() => { if (alive) setLogs([]); })
      .finally(() => { if (alive) setLoading(false); });
    return () => { alive = false; };
  }, [customerId]);
  if (loading) return <p className="muted small">Đang tải lịch sử...</p>;
  if (logs.length === 0) return <p className="muted small">Chưa có lịch sử công nợ ghi nhận.</p>;
  return (
    <div className="pc-debt-history">
      {logs.map((l) => (
        <div key={l.id} className="pc-debt-rowline">
          <div className="pc-debt-history-text">
            <b title={l.note ?? undefined}>{l.note || (l.amount > 0 ? 'Ghi nợ' : 'Thu nợ')}</b>
            <div className="muted small">{formatDMY(l.created_at.slice(0, 10))}</div>
          </div>
          <span className={l.amount > 0 ? 'pc-debt-plus' : 'pc-debt-minus'}>
            {l.amount > 0 ? '+' : ''}{formatVND(l.amount)}
          </span>
        </div>
      ))}
    </div>
  );
}

function DebtSheet({
  mode,
  initialCustomer,
  onClose,
  onDone,
}: {
  mode: 'give' | 'receive';
  /** Khách chọn sẵn (panel PC truyền vào); không truyền thì mở ra ở ô tìm như cũ. */
  initialCustomer?: Customer | null;
  onClose: () => void;
  onDone: () => void;
}) {
  const toast = useToast();
  const [q, setQ] = useState('');
  const [results, setResults] = useState<Customer[]>([]);
  const [searched, setSearched] = useState(false);
  const [selected, setSelected] = useState<Customer | null>(initialCustomer ?? null);
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [funds, setFunds] = useState<Fund[]>([]);
  const [fundId, setFundId] = useState('cash');
  const [occurredAt, setOccurredAt] = useState(() => toLocalDateTimeInput());
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    // Thu nợ = tiền về quỹ → cần chọn quỹ nhận (chỉ ở chế độ "Tôi đã nhận")
    if (mode !== 'receive') return;
    getFunds()
      .then((fl) => {
        const act = fl.filter((f) => f.active);
        setFunds(act);
        if (!act.some((f) => f.id === fundId) && act[0]) setFundId(act[0].id);
      })
      .catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode]);

  const doSearch = async () => {
    setBusy(true);
    try {
      const r = await searchCustomers(q.trim());
      setResults(r);
      setSearched(true);
      if (r.length === 0) toast.show('Không tìm thấy khách hàng');
    } catch {
      toast.show('Không tìm được, kiểm tra mạng');
    } finally {
      setBusy(false);
    }
  };

  const submit = async () => {
    if (!selected) {
      toast.show('Hãy chọn khách hàng trước');
      return;
    }
    const v = parseInt(amount.replace(/\D/g, ''), 10);
    if (!v || v <= 0) {
      toast.show('Nhập số tiền hợp lệ');
      return;
    }
    setBusy(true);
    try {
      const finalNote = note.trim() || (mode === 'receive' ? `Thu nợ — ${selected.name}` : null);
      if (mode === 'receive') {
        // Thu nợ: trừ công nợ + ghi quỹ trong 1 transaction (không bao giờ lệch nhau)
        await collectCustomerDebt(selected.id, v, {
          note: finalNote,
          fundId,
          method: funds.find((f) => f.id === fundId)?.kind === 'transfer' ? 'transfer' : 'cash',
          warehouseId: selected.warehouse_id ?? null,
          occurredAt: occurredAt ? new Date(occurredAt).toISOString() : null,
        });
      } else {
        // Ghi nợ thêm: chỉ tăng công nợ (chưa thu tiền nên không ghi quỹ)
        await adjustDebt(selected.id, v, finalNote);
      }
      toast.show(
        mode === 'give'
          ? `Đã ghi nợ ${formatVND(v)} cho ${selected.name}`
          : `Đã thu ${formatVND(v)} của ${selected.name}`,
      );
      onDone();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet
      title={mode === 'give' ? 'Tôi đã đưa (ghi nợ)' : 'Tôi đã nhận (thu nợ)'}
      onClose={onClose}
      footer={
        <button
          className={`btn btn-block btn-lg${mode === 'give' ? ' btn' : ''}`}
          disabled={busy}
          onClick={submit}
        >
          {busy ? 'Đang lưu…' : 'Xác nhận'}
        </button>
      }
    >
      {!selected ? (
        <>
          <div className="row" style={{ marginBottom: 12 }}>
            <div className="sb-search grow">
              <span className="sico"><TIcon emoji="🔍" size={18} /></span>
              <input
                placeholder="Nhập tên hoặc SĐT…"
                value={q}
                onChange={(e) => setQ(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && doSearch()}
              />
            </div>
            <button className="btn" style={{ minHeight: 44 }} onClick={doSearch} disabled={busy}>
              Tìm
            </button>
          </div>
          {results.map((c) => (
            <button key={c.id} className="sb-row" onClick={() => setSelected(c)}>
              <span className="avatar">{c.name.charAt(0).toUpperCase()}</span>
              <span className="rbody">
                <span className="rtitle">{c.name}</span>
                <span className="rsub">{c.phone}</span>
              </span>
              <span className={`ramount ${c.debt > 0 ? 'text-orange' : ''}`}>
                {c.debt > 0 ? formatVND(c.debt) : <span className="muted">—</span>}
              </span>
            </button>
          ))}
          {searched && results.length === 0 && (
            <p className="muted small" style={{ textAlign: 'center' }}>
              Không tìm thấy khách hàng
            </p>
          )}
        </>
      ) : (
        <>
          <button className="sb-row" onClick={() => setSelected(null)} aria-label="Đổi khách hàng">
            <span className="avatar">{selected.name.charAt(0).toUpperCase()}</span>
            <span className="rbody">
              <span className="rtitle">{selected.name}</span>
              <span className="rsub">
                {selected.phone} · đang nợ {formatVND(selected.debt)}
              </span>
            </span>
            <span className="text-green" style={{ fontWeight: 600 }}>
              Đổi ›
            </span>
          </button>
          <div className="field" style={{ marginTop: 12 }}>
            <label>Số tiền</label>
            <input
              className="sb-money-input"
              inputMode="numeric"
              placeholder="0"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              autoFocus
            />
          </div>
          <div className="field">
            <label>Ghi chú (không bắt buộc)</label>
            <input
              className="input"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="VD: tiền nước tuần này…"
            />
          </div>
          <div className="field">
            <label>🕐 Thời gian</label>
            <input
              type="datetime-local"
              className="input"
              value={occurredAt}
              onChange={(e) => setOccurredAt(e.target.value)}
            />
          </div>
          {mode === 'receive' && funds.length > 1 && (
            <div className="field">
              <label>Tiền vào quỹ</label>
              <div className="row" style={{ flexWrap: 'wrap', gap: 8 }}>
                {funds.map((f) => (
                  <button
                    key={f.id}
                    type="button"
                    className={`sb-chip${fundId === f.id ? ' selected' : ''}`}
                    onClick={() => setFundId(f.id)}
                  >
                    {f.name}
                  </button>
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </Sheet>
  );
}
