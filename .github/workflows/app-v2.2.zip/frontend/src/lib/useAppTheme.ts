import { useEffect, useState } from 'react';
import { getTheme, type AppTheme } from './theme';

// Hook đọc theme hiện tại, tự cập nhật khi đổi trong Cài đặt
export function useAppTheme(): AppTheme {
  const [theme, setThemeState] = useState<AppTheme>(getTheme);
  useEffect(() => {
    const onChange = (e: Event) => {
      setThemeState((e as CustomEvent<AppTheme>).detail ?? getTheme());
    };
    window.addEventListener('beesy-theme-change', onChange);
    return () => window.removeEventListener('beesy-theme-change', onChange);
  }, []);
  return theme;
}
