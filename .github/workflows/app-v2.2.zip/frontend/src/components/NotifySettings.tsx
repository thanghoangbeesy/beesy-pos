import { useEffect, useState } from 'react';
import { DbError, getSettings, setSetting } from '../lib/db';
import { useToast } from '../components/Toast';

interface NotifyPrefs {
  low_stock: boolean;
  daily_report: boolean;
  daily_report_time: string; // HH:mm
  online_order: boolean;
}

const DEFAULTS: NotifyPrefs = {
  low_stock: true,
  daily_report: false,
  daily_report_time: '22:00',
  online_order: true,
};

function parsePrefs(raw: Record<string, string>): NotifyPrefs {
  try {
    const j = JSON.parse(raw.notify_prefs ?? '{}');
    return { ...DEFAULTS, ...j };
  } catch {
    return DEFAULTS;
  }
}

/** Cài đặt thông báo: hàng sắp hết, báo cáo cuối ngày, đơn online. */
export function NotifySettings() {
  const toast = useToast();
  const [prefs, setPrefs] = useState<NotifyPrefs>(DEFAULTS);
  const [busy, setBusy] = useState(false);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    getSettings()
      .then((s) => {
        setPrefs(parsePrefs(s));
        setLoaded(true);
      })
      .catch(() => setLoaded(true));
  }, []);

  const save = async (next: NotifyPrefs) => {
    setPrefs(next);
    setBusy(true);
    try {
      await setSetting('notify_prefs', JSON.stringify(next));
      toast.show('Đã lưu cài đặt thông báo ✅');
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  const toggle = (key: keyof NotifyPrefs) => {
    if (typeof prefs[key] !== 'boolean') return;
    void save({ ...prefs, [key]: !prefs[key] });
  };

  if (!loaded) return <p className="muted">Đang tải…</p>;

  return (
    <div style={{ padding: '16px 4px 12px' }}>
      <p className="small muted" style={{ marginBottom: 12 }}>
        Thông báo hiện khi mở app. Đơn online đã có âm báo + đẩy riêng ở trang Đơn online.
      </p>

      <div className="row" style={{ marginBottom: 16 }}>
        <span className="grow" style={{ fontWeight: 600, fontSize: 15 }}>
          ⚠️ Báo hàng sắp hết
          <span className="small muted" style={{ display: 'block', fontWeight: 400 }}>
            Hiện cảnh báo khi mở app nếu có nguyên liệu dưới ngưỡng
          </span>
        </span>
        <label className="switch" aria-label="Báo hàng sắp hết">
          <input type="checkbox" checked={prefs.low_stock} disabled={busy} onChange={() => toggle('low_stock')} />
          <span className="track" />
        </label>
      </div>

      <div className="row" style={{ marginBottom: 8 }}>
        <span className="grow" style={{ fontWeight: 600, fontSize: 15 }}>
          🌙 Báo cáo doanh thu cuối ngày
          <span className="small muted" style={{ display: 'block', fontWeight: 400 }}>
            Nhắc xem báo cáo vào giờ đã chọn (khi đang mở app)
          </span>
        </span>
        <label className="switch" aria-label="Báo cáo cuối ngày">
          <input type="checkbox" checked={prefs.daily_report} disabled={busy} onChange={() => toggle('daily_report')} />
          <span className="track" />
        </label>
      </div>
      {prefs.daily_report && (
        <div className="field" style={{ marginBottom: 16 }}>
          <label>Giờ nhắc</label>
          <input
            className="input"
            type="time"
            value={prefs.daily_report_time}
            disabled={busy}
            onChange={(e) => void save({ ...prefs, daily_report_time: e.target.value })}
          />
        </div>
      )}

      <div className="row" style={{ marginBottom: 8 }}>
        <span className="grow" style={{ fontWeight: 600, fontSize: 15 }}>
          🌐 Thông báo đơn online
          <span className="small muted" style={{ display: 'block', fontWeight: 400 }}>
            Âm báo + thông báo đẩy khi có đơn mới (cài chi tiết ở trang Đơn online)
          </span>
        </span>
        <label className="switch" aria-label="Thông báo đơn online">
          <input type="checkbox" checked={prefs.online_order} disabled={busy} onChange={() => toggle('online_order')} />
          <span className="track" />
        </label>
      </div>
    </div>
  );
}
