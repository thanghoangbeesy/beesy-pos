import { useState } from 'react';
import { getTheme, setTheme, type AppTheme } from '../lib/theme';

// Nút chuyển đổi giao diện v1/v2 trong Cài đặt
export default function ThemeSwitch() {
  const [theme, setThemeState] = useState<AppTheme>(getTheme());
  const pick = (t: AppTheme) => {
    setThemeState(t);
    setTheme(t);
  };
  return (
    <div className="sb-seg" role="group" aria-label="Chọn giao diện">
      <button type="button" className={theme === 'v1' ? 'on' : ''} onClick={() => pick('v1')}>
        🌿 v1 — Xanh lá
      </button>
      <button type="button" className={theme === 'v2' ? 'on' : ''} onClick={() => pick('v2')}>
        ✨ v2 — Kasa POS
      </button>
    </div>
  );
}
