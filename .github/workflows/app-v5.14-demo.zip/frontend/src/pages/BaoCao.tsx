import { useCallback, useEffect, useMemo, useState } from 'react';
import { DbError, downloadFile, exportOrdersCsv, getAllowedWarehouses, getRangeReport, listCashbookEntries } from '../lib/db';
import {
  addDaysVN,
  formatVND,
  startOfMonthVN,
  startOfWeekVN,
  todayVN,
} from '../lib/format';
import { useToast } from '../components/Toast';
import { useAuth } from '../lib/auth';
import { TIcon } from '../components/TIcon';
import type { CashbookEntry, DailyReport, Warehouse } from '../lib/types';

type PresetKey = 'today' | 'yesterday' | 'thisWeek' | 'lastWeek' | 'thisMonth' | 'lastMonth' | 'custom';
type TabKey = 'products' | 'hours' | 'promo' | 'cashflow' | 'profit';

const PRESETS: { key: PresetKey; label: string }[] = [
  { key: 'today', label: 'Hôm nay' },
  { key: 'yesterday', label: 'Hôm qua' },
  { key: 'thisWeek', label: 'Tuần này' },
  { key: 'lastWeek', label: 'Tuần trước' },
  { key: 'thisMonth', label: 'Tháng này' },
  { key: 'lastMonth', label: 'Tháng trước' },
  { key: 'custom', label: 'Tùy chọn' },
];

function presetRange(key: PresetKey, cs: string, ce: string): [string, string] {
  const t = todayVN();
  switch (key) {
    case 'today': return [t, t];
    case 'yesterday': { const y = addDaysVN(t, -1); return [y, y]; }
    case 'thisWeek': return [startOfWeekVN(t), t];
    case 'lastWeek': {
      const m = startOfWeekVN(t);
      const ml = addDaysVN(m, -7);
      return [ml, addDaysVN(ml, 6)];
    }
    case 'thisMonth': return [startOfMonthVN(t), t];
    case 'lastMonth': {
      const f = startOfMonthVN(t);
      const l = addDaysVN(f, -1);
      return [startOfMonthVN(l), l];
    }
    case 'custom': return [cs, ce];
  }
}

const TABS: { key: TabKey; label: string; icon: string }[] = [
  { key: 'products', label: 'Món bán', icon: '🧾' },
  { key: 'hours', label: 'Theo giờ', icon: '🕐' },
  { key: 'promo', label: 'Khuyến mại', icon: '🎁' },
  { key: 'cashflow', label: 'Dòng tiền', icon: '💸' },
  { key: 'profit', label: 'Lợi nhuận', icon: '📈' },
];

export function BaoCao() {
  const toast = useToast();
  const { can } = useAuth();
  const [tab, setTab] = useState<TabKey>('products');
  const [preset, setPreset] = useState<PresetKey>('today');
  const [customStart, setCustomStart] = useState(todayVN());
  const [customEnd, setCustomEnd] = useState(todayVN());
  const [report, setReport] = useState<DailyReport | null>(null);
  const [cashflow, setCashflow] = useState<CashbookEntry[]>([]);
  const [busy, setBusy] = useState(false);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [isOwner, setIsOwner] = useState(false);
  const [whFilter, setWhFilter] = useState('all');
  const [sortKey, setSortKey] = useState<'qty' | 'revenue' | 'profit'>('revenue');
  const [sortDir, setSortDir] = useState<'desc' | 'asc'>('desc');
  const [exportBusy, setExportBusy] = useState(false);

  const scopeIds = whFilter === 'all' ? (isOwner ? undefined : warehouses.map((w) => w.id)) : [whFilter];

  const load = useCallback(async (key: PresetKey, cs: string, ce: string, ids?: string[]) => {
    const [s, e] = presetRange(key, cs, ce);
    if (!s || !e || s > e) { toast.show('Khoảng ngày không hợp lệ'); return; }
    setBusy(true);
    try {
      const [data, entries] = await Promise.all([
        getRangeReport(s, e, ids),
        listCashbookEntries(1000),
      ]);
      setReport(data);
      // Lọc khoản quỹ trong kỳ
      setCashflow(entries.filter((en) => {
        const d = (en.created_at || '').slice(0, 10);
        return d >= s && d <= e;
      }));
    } catch (err) {
      toast.show(err instanceof DbError ? err.message : 'Không tải được báo cáo');
    } finally {
      setBusy(false);
    }
  }, [toast]);

  useEffect(() => {
    getAllowedWarehouses()
      .then(({ warehouses: ws, isOwner: ow }) => {
        setWarehouses(ws);
        setIsOwner(ow);
        const ids = ow ? undefined : ws.map((w) => w.id);
        void load('today', todayVN(), todayVN(), ids);
      })
      .catch(() => { void load('today', todayVN(), todayVN()); });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const pickPreset = (key: PresetKey) => {
    setPreset(key);
    void load(key, customStart, customEnd, scopeIds);
  };

  const changeWh = (id: string) => {
    setWhFilter(id);
    const ids = id === 'all' ? (isOwner ? undefined : warehouses.map((w) => w.id)) : [id];
    void load(preset, customStart, customEnd, ids);
  };

  const sortedProducts = useMemo(() => {
    const arr = [...(report?.top_products ?? [])];
    arr.sort((a, b) => {
      const d = a[sortKey] - b[sortKey];
      return sortDir === 'desc' ? -d : d;
    });
    return arr;
  }, [report, sortKey, sortDir]);

  const maxHour = Math.max(1, ...(report?.by_hour.map((h) => h.revenue) ?? [1]));
  const bestHour = useMemo(() => {
    if (!report) return null;
    return [...report.by_hour].sort((a, b) => b.revenue - a.revenue)[0];
  }, [report]);

  // Dòng tiền: tổng thu/chi
  const cashStats = useMemo(() => {
    let thu = 0, chi = 0;
    const byCat: Record<string, { name: string; thu: number; chi: number }> = {};
    for (const en of cashflow) {
      const amt = en.amount || 0;
      if (en.type === 'thu') thu += amt;
      else chi += amt;
      const cat = en.category || 'Khác';
      const slot = byCat[cat] ?? { name: cat, thu: 0, chi: 0 };
      if (en.type === 'thu') slot.thu += amt;
      else slot.chi += amt;
      byCat[cat] = slot;
    }
    return { thu, chi, net: thu - chi, byCat: Object.values(byCat).sort((a, b) => (b.thu + b.chi) - (a.thu + a.chi)) };
  }, [cashflow]);

  const doExport = async () => {
    setExportBusy(true);
    try {
      const [s, e] = presetRange(preset, customStart, customEnd);
      const csv = await exportOrdersCsv(s, e, scopeIds);
      const tabName = TABS.find((t) => t.key === tab)?.label ?? 'bao-cao';
      downloadFile(`beesy-${tabName}_${s}_${e}.csv`, csv, 'text/csv');
      toast.show('Đã xuất file Excel');
    } catch (err) {
      toast.show(err instanceof DbError ? err.message : 'Xuất file thất bại');
    } finally {
      setExportBusy(false);
    }
  };

  if (!can('reports')) {
    return <div className="page"><div className="card">🔒 Chỉ Quản lý trở lên mới được xem báo cáo.</div></div>;
  }

  const rangeLabel = (() => {
    const [s, e] = presetRange(preset, customStart, customEnd);
    return s === e ? s : `${s} → ${e}`;
  })();

  return (
    <div className="page bc-page">
      <div className="bc-header">
        <h1>Báo cáo chi tiết</h1>
        <select value={preset} onChange={(e) => pickPreset(e.target.value as PresetKey)} className="input" aria-label="Chọn kỳ">
          {PRESETS.map((p) => <option key={p.key} value={p.key}>{p.label}</option>)}
        </select>
      </div>

      {preset === 'custom' && (
        <div className="row" style={{ gap: 8, marginBottom: 12, alignItems: 'center' }}>
          <input type="date" className="input" value={customStart} max={todayVN()} onChange={(e) => setCustomStart(e.target.value)} />
          <span>→</span>
          <input type="date" className="input" value={customEnd} max={todayVN()} onChange={(e) => setCustomEnd(e.target.value)} />
          <button className="btn btn-sm" onClick={() => pickPreset('custom')}>Xem</button>
        </div>
      )}

      {warehouses.length > 1 && (
        <div className="row" style={{ gap: 8, marginBottom: 12, flexWrap: 'wrap' }}>
          <button className={`sb-chip${whFilter === 'all' ? ' selected' : ''}`} onClick={() => changeWh('all')}>Mọi kho</button>
          {warehouses.map((w) => (
            <button key={w.id} className={`sb-chip${whFilter === w.id ? ' selected' : ''}`} onClick={() => changeWh(w.id)}>{w.name}</button>
          ))}
        </div>
      )}

      {/* Tabs — 5 tab, chữ hiện đầy đủ */}
      <div className="bc-tabs bc-tabs-5">
        {TABS.map((t) => (
          <button key={t.key} className={`bc-tab${tab === t.key ? ' active' : ''}`} onClick={() => setTab(t.key)}>
            <TIcon emoji={t.icon} size={20} />
            <span>{t.label}</span>
          </button>
        ))}
      </div>

      {busy && !report ? (
        <p className="muted">Đang tải…</p>
      ) : !report ? (
        <p className="muted">Không có dữ liệu</p>
      ) : (
        <>
          <div className="bc-summary">
            <div><span>Doanh thu</span><b>{formatVND(report.revenue)}</b></div>
            <div><span>Giá vốn</span><b>{formatVND(report.cost)}</b></div>
            <div><span>Lợi nhuận</span><b className="text-green">{formatVND(report.profit)}</b></div>
            <div><span>Đơn bán</span><b>{report.order_count}</b></div>
            <div><span>Đơn hủy</span><b>{report.cancelled_count}</b></div>
            <div><span>TB/đơn</span><b>{formatVND(Math.round(report.avg_order))}</b></div>
          </div>

          {/* Nút xuất file trong từng tab */}
          <div className="row" style={{ justifyContent: 'flex-end', marginBottom: 10 }}>
            <button className="btn btn-outline btn-sm" disabled={exportBusy} onClick={doExport}>
              {exportBusy ? 'Đang xuất…' : <><TIcon emoji="⬇" size={13} /> Xuất {TABS.find((t) => t.key === tab)?.label}</>}
            </button>
          </div>
          <p className="small muted" style={{ margin: '-4px 0 10px', textAlign: 'right' }}>Kỳ: {rangeLabel}</p>

          {tab === 'products' && (
            <div className="card">
              <div className="row" style={{ gap: 8, marginBottom: 10, flexWrap: 'wrap' }}>
                {([['qty', 'Số lượng'], ['revenue', 'Doanh thu'], ['profit', 'Lợi nhuận']] as const).map(([k, label]) => (
                  <button key={k} className={`sb-chip${sortKey === k ? ' selected' : ''}`} onClick={() => setSortKey(k)}>{label}</button>
                ))}
                <button className="sb-chip" onClick={() => setSortDir((d) => d === 'desc' ? 'asc' : 'desc')}>
                  {sortDir === 'desc' ? '↓ Giảm dần' : '↑ Tăng dần'}
                </button>
              </div>
              <div className="bc-table-wrap">
                <table className="pc-table">
                  <thead>
                    <tr><th>#</th><th>Món</th><th className="r">SL</th><th className="r">Doanh thu</th><th className="r">Giá vốn</th><th className="r">Lợi nhuận</th></tr>
                  </thead>
                  <tbody>
                    {sortedProducts.map((p, i) => (
                      <tr key={p.product_id}>
                        <td>{i + 1}</td>
                        <td><b>{p.name}</b></td>
                        <td className="r">{p.qty}</td>
                        <td className="r">{formatVND(p.revenue)}</td>
                        <td className="r">{formatVND(p.cost)}</td>
                        <td className="r" style={{ color: '#16A34A', fontWeight: 600 }}>{formatVND(p.profit)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {sortedProducts.length === 0 && <p className="muted small">Chưa có dữ liệu</p>}
            </div>
          )}

          {tab === 'hours' && (
            <div className="card">
              <h3 style={{ margin: '0 0 12px' }}>Doanh thu theo giờ</h3>
              {bestHour && bestHour.revenue > 0 && (
                <p className="small" style={{ marginBottom: 12 }}>
                  Giờ bán tốt nhất: <b>{bestHour.hour}h</b> — {formatVND(bestHour.revenue)} ({bestHour.count} đơn)
                </p>
              )}
              <div className="hour-chart">
                {report.by_hour.map((h) => (
                  <div className="hour-bar" key={h.hour} title={`${h.hour}h: ${formatVND(h.revenue)} (${h.count} đơn)`}>
                    <div className="bar" style={{ height: `${Math.round((h.revenue / maxHour) * 120)}px` }} />
                    <div className="h">{h.hour}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {tab === 'promo' && (
            <div className="card">
              <h3 style={{ margin: '0 0 12px' }}>Khuyến mại</h3>
              <div className="bc-summary" style={{ marginBottom: 0 }}>
                <div><span>Đơn KM</span><b>{report.promo_count}</b></div>
                <div><span>Tiền giảm</span><b>{formatVND(report.promo_discount)}</b></div>
                <div><span>Tỉ lệ</span><b>{report.order_count > 0 ? Math.round((report.promo_count / report.order_count) * 100) : 0}%</b></div>
              </div>
            </div>
          )}

          {tab === 'cashflow' && (
            <div className="card">
              <h3 style={{ margin: '0 0 12px' }}>Dòng tiền</h3>
              <div className="bc-summary" style={{ marginBottom: 12 }}>
                <div><span>Tổng thu</span><b className="text-green">{formatVND(cashStats.thu)}</b></div>
                <div><span>Tổng chi</span><b style={{ color: '#DC2626' }}>{formatVND(cashStats.chi)}</b></div>
                <div><span>Chênh lệch</span><b>{formatVND(cashStats.net)}</b></div>
              </div>
              <h4 style={{ margin: '0 0 8px', fontSize: 14 }}>Theo danh mục</h4>
              {cashStats.byCat.length === 0 ? (
                <p className="muted small">Chưa có dữ liệu</p>
              ) : (
                cashStats.byCat.map((c) => (
                  <div className="ov-row" key={c.name}>
                    <div className="ov-row-body">
                      <span className="ov-row-title">{c.name}</span>
                      <span className="ov-row-sub">Thu {formatVND(c.thu)} · Chi {formatVND(c.chi)}</span>
                    </div>
                    <span className="ov-row-amount">{formatVND(c.thu - c.chi)}</span>
                  </div>
                ))
              )}
            </div>
          )}

          {tab === 'profit' && (
            <div className="card">
              <h3 style={{ margin: '0 0 12px' }}>Lợi nhuận</h3>
              <div className="bc-summary" style={{ marginBottom: 12 }}>
                <div><span>Doanh thu</span><b>{formatVND(report.revenue)}</b></div>
                <div><span>Giá vốn</span><b>{formatVND(report.cost)}</b></div>
                <div><span>Chi phí</span><b>{formatVND(report.expenses)}</b></div>
                <div><span>Lợi nhuận ròng</span><b className="text-green">{formatVND(report.profit)}</b></div>
                <div><span>Biên LN</span><b>{report.revenue > 0 ? ((report.profit / report.revenue) * 100).toFixed(1) : 0}%</b></div>
                <div><span>Giảm giá KM</span><b>{formatVND(report.promo_discount)}</b></div>
                <div><span>Số món</span><b>{report.top_products.length}</b></div>
              </div>
              <h4 style={{ margin: '0 0 8px', fontSize: 14 }}>Top món lợi nhuận cao</h4>
              {[...report.top_products].sort((a, b) => b.profit - a.profit).slice(0, 10).map((p, i) => (
                <div className="ov-row" key={p.product_id}>
                  <span className="ov-rank">{i + 1}</span>
                  <div className="ov-row-body">
                    <span className="ov-row-title">{p.name}</span>
                    <span className="ov-row-sub">{p.qty} món · vốn {formatVND(p.cost)}</span>
                  </div>
                  <span className="ov-row-amount" style={{ color: '#16A34A' }}>{formatVND(p.profit)}</span>
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
