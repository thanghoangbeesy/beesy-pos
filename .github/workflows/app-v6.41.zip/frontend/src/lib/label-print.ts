// Tem món theo đúng mẫu B đã chốt ở space Tem Món (mẫu B · Gọn 50x30mm):
//   Beesy Coffee & Tea            #A102
//   --------------------------------
//   Trà Đào Cam Sả                 (tên món đậm to nhất)
//   L · Đường 50% · Ít đá         (giá trị thông số in đậm, nhãn "Đường" chữ thường)
//   + Trân châu trắng, Thạch đào  (topping, tiền tố "+ ")
//   Ít ngọt thôi, cho nhiều đào   (ghi chú, in nghiêng, KHÔNG tiền tố "Ghi chú:")
//   Khách: Chị Lan · 14:21 · Mang đi  ("Khách: tên" in đậm, giờ + nguồn chữ thường)
// File này giữ mô hình tem chung (LabelView) để cả 2 đường in dùng:
// in hệ thống render HTML (giữ nguyên dấu), in Bluetooth render ESC/POS
// (không dấu, xem lib/printer.ts). In qua hệ thống dùng chung cơ chế
// #print-root với BillPrint: tem ghi vào #label-print-area, body thêm class
// 'print-labels' để CSS @media print chỉ hiện tem (ẩn bill) trong lúc in,
// gỡ class sau khi in xong.

import type { LabelPaperSize, Order, OrderItem } from './types';
import { ORDER_SOURCE_LABEL } from './types';

function esc(s: string): string {
  return s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c] ?? c));
}

/** Số ly trong đơn = số tem cần in (mỗi ly 1 tem). */
export function cupCount(order: Order): number {
  return order.items.reduce((a, it) => a + Math.max(0, Math.floor(it.qty)), 0);
}

/** Giờ tạo đơn dạng HH:mm (giờ địa phương của thiết bị). */
export function orderTimeHHmm(order: Order): string {
  const d = new Date(order.created_at);
  if (Number.isNaN(d.getTime())) return '';
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}

/** Tên nguồn đơn hiển thị trên tem: tên chụp lúc tạo đơn, nếu không có thì
 * tra bảng tên nguồn, cuối cùng là mã nguồn. */
export function orderSourceLabel(order: Order): string {
  return order.source_label || ORDER_SOURCE_LABEL[order.source] || order.source || '';
}

/** 1 thông số trên tem: label '' = chỉ hiện giá trị in đậm (Size, Đá);
 * label 'Đường' = hiện "Đường <giá trị in đậm>". */
export interface LabelSpec {
  label: string;
  value: string;
}

/** Nội dung 1 tem (1 ly) theo mẫu B — thuần dữ liệu, 2 đường in tự render. */
export interface LabelView {
  shop: string;
  code: string; // mã đơn, KHÔNG kèm '#'; lúc render mới thêm '#'
  drink: string;
  specs: LabelSpec[];
  toppings: string[];
  note: string | null;
  customer: string | null;
  time: string; // HH:mm
  source: string;
}

/** Xếp nhóm lựa chọn (modifier) về đúng vị trí trên tem mẫu B, theo tên nhóm
 * trong menu quán (seed: Size / Độ ngọt / Đá / Topping). Nhóm lạ (quán thêm
 * sau này) vẫn hiện ở dòng thông số dưới dạng giá trị in đậm để không mất
 * thông tin. Thuần logic, không chạm DOM nên test được. */
export function labelViewForOrder(
  order: Order,
  item: OrderItem,
  shopName: string,
  customerName: string | null,
): LabelView {
  const norm = (s: string) =>
    (s || '')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/đ/g, 'd')
      .replace(/Đ/g, 'D')
      .toLowerCase()
      .trim();
  const specs: LabelSpec[] = [];
  const toppings: string[] = [];
  const seenKnown = new Set<string>();
  for (const m of item.modifiers || []) {
    const opt = (m.option || '').trim();
    if (!opt) continue;
    const g = norm(m.group || '');
    const tokens = g.split(/\s+/);
    const has = (...ws: string[]) => ws.some((w) => tokens.includes(w));
    if ((has('size', 'co', 'ly') || g === 'size') && !seenKnown.has('size')) {
      // Size mẫu B chỉ lấy phần đầu ("L · 700ml" -> "L"); "Ly Lớn" giữ nguyên.
      specs.push({ label: '', value: opt.split('·')[0].trim() || opt });
      seenKnown.add('size');
    } else if ((has('ngot', 'duong') || g.includes('ngot') || g.includes('duong')) && !seenKnown.has('sugar')) {
      specs.push({ label: 'Đường', value: opt });
      seenKnown.add('sugar');
    } else if ((has('da') || g === 'da') && !seenKnown.has('ice')) {
      specs.push({ label: '', value: opt });
      seenKnown.add('ice');
    } else if (has('topping', 'them') || g.includes('topping')) {
      toppings.push(opt);
    } else if (seenKnown.has('size') && has('size', 'co', 'ly')) {
      specs.push({ label: '', value: opt });
    } else if (seenKnown.has('sugar') && (has('ngot', 'duong') || g.includes('ngot'))) {
      specs.push({ label: 'Đường', value: opt });
    } else if (seenKnown.has('ice') && has('da')) {
      specs.push({ label: '', value: opt });
    } else {
      // Nhóm lạ: vẫn hiện giá trị in đậm ở dòng thông số.
      specs.push({ label: '', value: opt });
    }
  }
  return {
    shop: shopName,
    code: order.code,
    drink: item.product_name,
    specs,
    toppings,
    note: item.note && item.note.trim() ? item.note.trim() : null,
    customer: customerName && customerName.trim() ? customerName.trim() : null,
    time: orderTimeHHmm(order),
    source: orderSourceLabel(order),
  };
}

/** HTML 1 tem theo mẫu B (dùng class .label-* mà CSS in đã định nghĩa
 * theo đúng cỡ chữ mm của space). */
export function labelHtmlForView(v: LabelView): string {
  const specsHtml =
    v.specs.length > 0
      ? `<div class="label-mod">${v.specs
          .map((s) => (s.label ? `${esc(s.label)} <b>${esc(s.value)}</b>` : `<b>${esc(s.value)}</b>`))
          .join(' · ')}</div>`
      : '';
  const topsHtml =
    v.toppings.length > 0 ? `<div class="label-mod">+ ${esc(v.toppings.join(', '))}</div>` : '';
  const noteHtml = v.note ? `<div class="label-note">${esc(v.note)}</div>` : '';
  const footParts: string[] = [];
  if (v.customer) footParts.push(`<span class="label-cust">Khách: ${esc(v.customer)}</span>`);
  if (v.time) footParts.push(esc(v.time));
  if (v.source) footParts.push(esc(v.source));
  const footHtml = footParts.length > 0 ? `<div class="label-foot">${footParts.join(' · ')}</div>` : '';
  return (
    `<div class="label-page">` +
    `<div class="label-head"><span class="label-shop">${esc(v.shop)}</span><span class="label-code">#${esc(v.code)}</span></div>` +
    `<hr class="label-hr"/>` +
    `<div class="label-name">${esc(v.drink)}</div>` +
    specsHtml +
    topsHtml +
    noteHtml +
    footHtml +
    `</div>`
  );
}

/** HTML cho toàn bộ tem của 1 đơn — mỗi ly 1 trang tem theo mẫu B.
 * Thuần logic, không chạm DOM nên test được. */
export function buildLabelHtml(
  order: Order,
  shopName = 'Beesy Coffee & Tea',
  customerName: string | null = null,
): string {
  const pages: string[] = [];
  for (const it of order.items) {
    const qty = Math.max(0, Math.floor(it.qty));
    for (let cup = 0; cup < qty; cup++) {
      pages.push(labelHtmlForView(labelViewForOrder(order, it, shopName, customerName)));
    }
  }
  return `<div id="label-print-area">${pages.join('')}</div>`;
}

/** Ghi tem vào #print-root rồi mở hộp thoại in của hệ thống để chọn máy in
 * WiFi/LAN. Khổ tem lấy theo cài đặt (mặc định 50x30mm) — CSS đổi khổ qua
 * class label-<khổ> trên body. Không xóa HTML bill trong #print-root
 * (chỉ thêm khu vực tem), để in bill qua hệ thống vẫn dùng được sau đó. */
export function printLabelsViaSystem(
  order: Order,
  size: LabelPaperSize = '50x30',
  shopName = 'Beesy Coffee & Tea',
  customerName: string | null = null,
): void {
  if (cupCount(order) === 0) return;
  let root = document.getElementById('print-root');
  if (!root) {
    root = document.createElement('div');
    root.id = 'print-root';
    document.body.appendChild(root);
  }
  const old = document.getElementById('label-print-area');
  if (old) old.remove();
  root.insertAdjacentHTML('beforeend', buildLabelHtml(order, shopName, customerName));
  document.body.classList.add('print-labels');
  const sizeClass = size === '50x30' ? null : `label-${size}`;
  if (sizeClass) document.body.classList.add(sizeClass);
  const done = () => {
    document.body.classList.remove('print-labels');
    if (sizeClass) document.body.classList.remove(sizeClass);
    window.removeEventListener('afterprint', done);
  };
  window.addEventListener('afterprint', done);
  // Dự phòng: một số trình duyệt không bắn afterprint khi hủy hộp thoại.
  window.setTimeout(done, 10000);
  window.print();
}
