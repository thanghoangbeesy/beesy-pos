// In hóa đơn qua máy in nhiệt Bluetooth (XPrinter và các máy chuẩn ESC/POS).
// Dùng Web Bluetooth — cần HTTPS (web.app OK) + thao tác của người dùng (bấm nút).
// Tiếng Việt: máy in nhiệt thường không có codepage tiếng Việt nên bill in
// không dấu (hàm unsigned() ở dưới chỉ bỏ dấu, giữ nguyên dấu câu).
// Đây là chuẩn chung của bill nhiệt VN.

import type { LabelPaperSize, Order } from './types';
import { LABEL_PAPER_SIZES } from './types';
import { labelViewForOrder } from './label-print';

const ESC = 0x1b;
const GS = 0x1d;

export interface ReceiptData {
  shopName: string;
  orderCode: string;
  createdAt: string; // ISO
  cashierName: string;
  customerName?: string | null;
  warehouseName?: string | null;
  items: { name: string; qty: number; unitPrice: number; lineTotal: number; note?: string }[];
  subtotal: number;
  discount: number;
  discountLabel?: string | null;
  total: number;
  paymentMethodName: string;
  amountReceived?: number | null;
  changeAmount?: number | null;
}

type WebBluetooth = {
  requestDevice: (opts: Record<string, unknown>) => Promise<BluetoothDeviceLike>;
};
type BluetoothDeviceLike = {
  name?: string;
  gatt?: {
    connect: () => Promise<BluetoothServerLike>;
  };
};
type BluetoothServerLike = {
  getPrimaryServices: () => Promise<BluetoothServiceLike[]>;
};
type BluetoothServiceLike = {
  getCharacteristics: () => Promise<BluetoothCharLike[]>;
};
type BluetoothCharLike = {
  properties: { write?: boolean; writeWithoutResponse?: boolean };
  writeValueWithResponse?: (v: BufferSource) => Promise<void>;
  writeValueWithoutResponse?: (v: BufferSource) => Promise<void>;
};

let deviceName: string | null = null;
let writeChar: BluetoothCharLike | null = null;

/** Trình duyệt có hỗ trợ Web Bluetooth không? */
export function isBluetoothSupported(): boolean {
  return typeof navigator !== 'undefined' && !!(navigator as unknown as { bluetooth?: unknown }).bluetooth;
}

function getBT(): WebBluetooth {
  const bt = (navigator as unknown as { bluetooth?: WebBluetooth }).bluetooth;
  if (!bt) throw new Error('Trình duyệt không hỗ trợ Bluetooth. Dùng Chrome trên Android/PC.');
  return bt;
}

// Các service BLE phổ biến của máy in nhiệt (XPrinter dùng 0xFFE0/0xFFE1 kiểu HM-10,
// một số dùng 0xFF00 hoặc Microchip 49535343-...).
const PRINTER_SERVICES = [
  0xffe0,
  0xff00,
  '49535343-fe7d-4ae6-8fa9-370793520401',
  '0000ff00-0000-1000-8000-00805f9b34fb',
];

async function requestPrinter(): Promise<{ char: BluetoothCharLike; name: string }> {
  const bt = getBT();
  const device = await bt.requestDevice({
    acceptAllDevices: true,
    optionalServices: PRINTER_SERVICES as unknown as string[],
  });
  const server = await device.gatt?.connect();
  if (!server) throw new Error('Không kết nối được tới máy in.');
  const services = await server.getPrimaryServices();
  for (const svc of services) {
    const chars = await svc.getCharacteristics();
    const writable = chars.find((c) => c.properties.writeWithoutResponse || c.properties.write);
    if (writable) return { char: writable, name: device.name ?? 'Máy in' };
  }
  throw new Error('Thiết bị này không có cổng ghi ESC/POS. Kiểm tra lại máy in.');
}

/** Kết nối máy in bill (hiện popup chọn thiết bị của trình duyệt). */
export async function connectPrinter(): Promise<string> {
  const found = await requestPrinter();
  writeChar = found.char;
  deviceName = found.name;
  return deviceName;
}

export function getPrinterName(): string | null {
  return deviceName;
}

export function isPrinterConnected(): boolean {
  return !!writeChar;
}

export function disconnectPrinter(): void {
  writeChar = null;
  deviceName = null;
}

// ---------- Máy in tem riêng (v6.37) ----------
// Quán dùng 2 máy Bluetooth: máy in bill 80mm + máy in tem 50mm. Giữ 2 kết
// nối riêng để in bill không bị gửi nhầm sang máy in tem và ngược lại.
let labelDeviceName: string | null = null;
let labelWriteChar: BluetoothCharLike | null = null;

/** Máy in tem 50mm đã kết nối chưa? */
export function isLabelPrinterConnected(): boolean {
  return !!labelWriteChar;
}

export function getLabelPrinterName(): string | null {
  return labelDeviceName;
}

export function disconnectLabelPrinter(): void {
  labelWriteChar = null;
  labelDeviceName = null;
}

/** Kết nối máy in tem 50mm (hiện popup chọn thiết bị — chọn đúng máy in tem). */
export async function connectLabelPrinter(): Promise<string> {
  const found = await requestPrinter();
  labelWriteChar = found.char;
  labelDeviceName = found.name;
  return labelDeviceName;
}

// ---------- Dựng lệnh ESC/POS ----------

/** Bỏ dấu tiếng Việt nhưng GIỮ nguyên ký tự ASCII in được (:, /, &, -, ...).
 * Khác unsignVietnamese ở format.ts (lọc cả dấu câu): dùng riêng cho máy in
 * nhiệt để dòng kẻ ngang, ngày giờ, dấu phẩy giữa các lựa chọn in đúng.
 * Trước đây ascii() dùng unsignVietnamese nên bill in ra mất hẳn dòng kẻ
 * ngang (32 dấu gạch thành dòng trắng) và mất dấu hai chấm/gạch chéo. */
function unsigned(s: string): string {
  return s
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd')
    .replace(/Đ/g, 'D')
    .replace(/[^\x20-\x7E\n]/g, '')
    .toUpperCase();
}

function ascii(s: string): number[] {
  // Bill không dấu để tương thích mọi máy in nhiệt
  return [...unsigned(s)].map((c) => c.charCodeAt(0));
}

function line(s = ''): number[] {
  return [...ascii(s), 0x0a];
}

function money(n: number): string {
  return Math.round(n).toLocaleString('vi-VN') + 'd';
}

function center(s: string): number[] {
  return [ESC, 0x61, 0x01, ...line(s), ESC, 0x61, 0x00];
}

function big(s: string): number[] {
  return [GS, 0x21, 0x11, ...center(s), GS, 0x21, 0x00];
}

function twoCol(left: string, right: string, width = 32): number[] {
  const l = unsigned(left);
  const r = unsigned(right);
  // Khổ hẹp (58mm = 22 cột): dòng nào dài quá thì tách thành 2 dòng thay vì tràn giấy.
  if (l.length + r.length + 1 > width) return [...line(l), ...line(r)];
  const spaces = Math.max(1, width - l.length - r.length);
  return line(l + ' '.repeat(spaces) + r);
}

export function buildReceipt(data: ReceiptData, cols = 32): Uint8Array {
  const b: number[] = [];
  const div = '-'.repeat(cols);
  b.push(ESC, 0x40); // init
  b.push(...big(data.shopName.toUpperCase()));
  b.push(...center('CAM ON QUY KHACH'));
  b.push(...line(div));
  b.push(...twoCol('Ma don:', data.orderCode, cols));
  const d = new Date(data.createdAt);
  const dt = `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  b.push(...twoCol('Thoi gian:', dt, cols));
  if (data.cashierName) b.push(...twoCol('Thu ngan:', data.cashierName, cols));
  if (data.customerName) b.push(...twoCol('Khach:', data.customerName, cols));
  if (data.warehouseName) b.push(...twoCol('Kho:', data.warehouseName, cols));
  b.push(...line(div));
  for (const it of data.items) {
    b.push(...line(it.name));
    b.push(...twoCol(`  ${it.qty} x ${money(it.unitPrice)}`, money(it.lineTotal), cols));
    if (it.note) b.push(...line(`  (${it.note})`));
  }
  b.push(...line(div));
  b.push(...twoCol('Tam tinh:', money(data.subtotal), cols));
  if (data.discount > 0) {
    b.push(...twoCol(`Giam gia${data.discountLabel ? ` (${data.discountLabel})` : ''}:`, '-' + money(data.discount), cols));
  }
  b.push(ESC, 0x45, 0x01, ...ascii('TONG CONG: ' + money(data.total)), ESC, 0x45, 0x00, 0x0a);
  b.push(...twoCol('Thanh toan:', data.paymentMethodName, cols));
  if (data.amountReceived != null) {
    b.push(...twoCol('Khach dua:', money(data.amountReceived), cols));
    b.push(...twoCol('Thoi lai:', money(data.changeAmount ?? 0), cols));
  }
  b.push(...line(div));
  b.push(...center('Hen gap lai!'));
  b.push(0x0a, 0x0a, 0x0a);
  b.push(GS, 0x56, 0x00); // cắt giấy
  return new Uint8Array(b);
}

async function writeChunksTo(char: BluetoothCharLike | null, data: Uint8Array): Promise<void> {
  if (!char) throw new Error('Chưa kết nối máy in.');
  const CHUNK = 100;
  for (let i = 0; i < data.length; i += CHUNK) {
    const chunk = data.slice(i, i + CHUNK);
    if (char.properties.writeWithoutResponse && char.writeValueWithoutResponse) {
      await char.writeValueWithoutResponse(chunk);
    } else if (char.writeValueWithResponse) {
      await char.writeValueWithResponse(chunk);
    } else {
      throw new Error('Máy in không hỗ trợ ghi dữ liệu.');
    }
    await new Promise((r) => setTimeout(r, 30));
  }
}

async function writeChunks(data: Uint8Array): Promise<void> {
  await writeChunksTo(writeChar, data);
}

/** In hóa đơn — tự throw lỗi tiếng Việt thân thiện khi thất bại.
 * cols: số cột chữ thường theo khổ giấy (80mm = 32, 58mm = 22). */
export async function printReceipt(data: ReceiptData, cols = 32): Promise<void> {
  try {
    await writeChunks(buildReceipt(data, cols));
  } catch (e) {
    writeChar = null;
    deviceName = null;
    throw new Error(
      e instanceof Error && e.message.startsWith('Chưa kết nối')
        ? 'Chưa kết nối máy in. Bấm "Kết nối máy in" trước.'
        : 'In thất bại — kiểm tra máy in đã bật và ở gần điện thoại.',
    );
  }
}

// ---------- In tem món, mẫu B đã chốt ở space Tem Món (v6.41) ----------
// Cấu trúc giống hệt tem in qua hệ thống (xem lib/label-print.ts), chỉ khác:
// - Không dấu tiếng Việt (giống bill nhiệt).
// - Dấu "·" của maket không có trong bảng mã ASCII của máy nhiệt nên dùng " | ".
// - Tên món chữ to nhưng căn TRÁI (không căn giữa như v6.37).
// - Header tên quán + mã đơn: vừa 1 dòng thì in chung, không vừa thì tách
//   2 dòng (tên quán căn giữa, mã đơn căn phải).
// - Tem Bluetooth đầy đủ dài khoảng 40mm (font A cao ~4,2mm/dòng) nên với
//   giấy 50x30mm có thể lệch dần — nên dùng khổ 50x40mm cho máy in tem nhiệt.

export interface LabelData {
  order: Order;
  shopName: string;
  customerName?: string | null;
}

/** Ngắt chữ không dấu thành các dòng vừa khổ, ngắt theo từ (từ dài hơn
 * khổ thì cắt cứng). Dùng chung cho tên món (chữ to) và các dòng thường. */
function wrapUnsigned(s: string, width: number): string[] {
  const clean = unsigned(s).trim();
  if (!clean) return [];
  const words = clean.split(/\s+/);
  const lines: string[] = [];
  let cur = '';
  for (const w of words) {
    if (w.length > width) {
      if (cur) {
        lines.push(cur);
        cur = '';
      }
      for (let i = 0; i < w.length; i += width) lines.push(w.slice(i, i + width));
      continue;
    }
    if (!cur) cur = w;
    else if (cur.length + 1 + w.length <= width) cur += ' ' + w;
    else {
      lines.push(cur);
      cur = w;
    }
  }
  if (cur) lines.push(cur);
  return lines;
}

/** Chữ đậm (ESC E) — dùng cho dòng lựa chọn trên tem (mẫu B: thông số in đậm). */
function bold(s: string): number[] {
  return [ESC, 0x45, 0x01, ...line(s), ESC, 0x45, 0x00];
}

/** Chữ nghiêng (ESC 4 bật / ESC 5 tắt) — dùng cho dòng ghi chú trên tem
 * (mẫu B: ghi chú in nghiêng). Máy nào không hỗ trợ thì bỏ qua lệnh, vẫn
 * in chữ thường, không lỗi. */
function italic(s: string): number[] {
  return [ESC, 0x34, ...line(s), ESC, 0x35];
}

/** Chữ to gấp đôi nhưng căn TRÁI (mẫu B: tên món căn trái, không căn giữa). */
function bigLeft(s: string): number[] {
  return [GS, 0x21, 0x11, ...line(s), GS, 0x21, 0x00];
}

interface StyledSeg {
  text: string;
  bold?: boolean;
  italic?: boolean;
}

/** Dựng 1 dòng có đoạn đậm/nghiêng xen kẽ (dòng thông số và dòng chân tem
 * mẫu B), tự ngắt theo từ vừa khổ. Mỗi đầu dòng đều tắt đậm/nghiêng rồi
 * mới bật lại theo đoạn, nên trạng thái máy in từ dòng trước không làm
 * lệch dòng sau. Trả về bytes + số dòng đã dựng (để tính số dòng đẩy giấy). */
function emitStyledLine(
  segs: StyledSeg[],
  cols: number,
): { bytes: number[]; lines: number } {
  const words: { text: string; bold: boolean; italic: boolean }[] = [];
  for (const s of segs) {
    for (const w of unsigned(s.text).split(/\s+/)) {
      if (!w) continue;
      words.push({ text: w, bold: !!s.bold, italic: !!s.italic });
    }
  }
  if (words.length === 0) return { bytes: [], lines: 0 };
  const lines: (typeof words)[] = [];
  let cur: typeof words = [];
  let curLen = 0;
  for (const w of words) {
    const add = cur.length === 0 ? w.text.length : 1 + w.text.length;
    if (cur.length > 0 && curLen + add > cols) {
      lines.push(cur);
      cur = [];
      curLen = 0;
    }
    if (cur.length > 0) curLen += 1;
    cur.push(w);
    curLen += w.text.length;
  }
  if (cur.length > 0) lines.push(cur);
  const out: number[] = [];
  for (const ln of lines) {
    out.push(ESC, 0x45, 0x00, ESC, 0x35); // tắt đậm + tắt nghiêng ở đầu dòng
    let b = false;
    let it = false;
    for (let i = 0; i < ln.length; i++) {
      const w = ln[i];
      if (w.bold !== b) {
        out.push(ESC, 0x45, w.bold ? 0x01 : 0x00);
        b = w.bold;
      }
      if (w.italic !== it) {
        out.push(ESC, w.italic ? 0x34 : 0x35);
        it = w.italic;
      }
      if (i > 0) out.push(0x20);
      out.push(...ascii(w.text));
    }
    out.push(0x0a);
  }
  return { bytes: out, lines: lines.length };
}

/** Dựng lệnh ESC/POS cho toàn bộ tem của 1 đơn — mỗi ly 1 tem (qty ly
 * thì in qty tem). Khổ tem lấy theo cài đặt (mặc định 50x30mm).
 * Mỗi tem đẩy giấy tổng cộng đủ số dòng của khổ tem (1 dòng ≈ 4,2mm) để
 * tem sau không bị chồng lên tem trước. KHÔNG gửi lệnh cắt giấy: giấy tem
 * bế sẵn không cắt bằng dao máy in. Thuần logic, không chạm Bluetooth nên test được. */
export function buildLabels(data: LabelData, size: LabelPaperSize = '50x30'): Uint8Array {
  const spec = LABEL_PAPER_SIZES[size] ?? LABEL_PAPER_SIZES['50x30'];
  const bigCols = Math.floor(spec.cols / 2);
  const b: number[] = [];
  b.push(ESC, 0x40); // init
  for (const it of data.order.items) {
    const qty = Math.max(0, Math.floor(it.qty));
    for (let cup = 0; cup < qty; cup++) {
      const view = labelViewForOrder(data.order, it, data.shopName, data.customerName ?? null);
      // Đếm đơn vị dòng đã đẩy (dòng chữ to tính gấp đôi) để bù số dòng
      // trắng cho đủ khổ tem.
      let units = 0;
      // Header: tên quán + mã đơn (vừa 1 dòng thì in chung, không thì tách 2 dòng).
      const head = unsigned(view.shop);
      const code = `#${view.code}`;
      if (head.length + 1 + code.length <= spec.cols) {
        b.push(...bold(head + ' '.repeat(spec.cols - head.length - code.length) + code));
        units += 1;
      } else {
        b.push(ESC, 0x45, 0x01, ...center(head.slice(0, spec.cols)), ESC, 0x45, 0x00);
        units += 1;
        const pad = Math.max(0, spec.cols - code.length);
        b.push(ESC, 0x45, 0x01, ...line(' '.repeat(pad) + code), ESC, 0x45, 0x00);
        units += 1;
      }
      // Đường kẻ ngang phân cách header với tên món.
      b.push(...line('-'.repeat(spec.cols)));
      units += 1;
      // Tên món: chữ to, căn trái.
      for (const ln of wrapUnsigned(view.drink, bigCols)) {
        b.push(...bigLeft(ln));
        units += 2;
      }
      // Dòng thông số: giá trị in đậm, nhãn "Đường" chữ thường, nối bằng " | ".
      if (view.specs.length > 0) {
        const segs: StyledSeg[] = [];
        view.specs.forEach((s, i) => {
          if (i > 0) segs.push({ text: '|' });
          if (s.label) segs.push({ text: s.label });
          segs.push({ text: s.value, bold: true });
        });
        const r = emitStyledLine(segs, spec.cols);
        b.push(...r.bytes);
        units += r.lines;
      }
      // Dòng topping: tiền tố "+ ", các topping nối bằng ", ".
      if (view.toppings.length > 0) {
        for (const ln of wrapUnsigned(`+ ${view.toppings.join(', ')}`, spec.cols)) {
          b.push(...line(ln));
          units += 1;
        }
      }
      // Ghi chú: in nghiêng, không tiền tố "Ghi chú:".
      if (view.note) {
        for (const ln of wrapUnsigned(view.note, spec.cols)) {
          b.push(...italic(ln));
          units += 1;
        }
      }
      // Chân tem: "Khách: tên" in đậm · giờ · nguồn.
      const footSegs: StyledSeg[] = [];
      if (view.customer) footSegs.push({ text: `Khách: ${view.customer}`, bold: true });
      if (view.time) {
        if (footSegs.length > 0) footSegs.push({ text: '|' });
        footSegs.push({ text: view.time });
      }
      if (view.source) {
        if (footSegs.length > 0) footSegs.push({ text: '|' });
        footSegs.push({ text: view.source });
      }
      if (footSegs.length > 0) {
        const r = emitStyledLine(footSegs, spec.cols);
        b.push(...r.bytes);
        units += r.lines;
      }
      const feed = Math.max(1, spec.advanceLines - units);
      for (let i = 0; i < feed; i++) b.push(0x0a);
    }
  }
  return new Uint8Array(b);
}

/** In tem qua máy in tem Bluetooth — tự throw lỗi tiếng Việt thân thiện. */
export async function printLabels(data: LabelData, size: LabelPaperSize = '50x30'): Promise<void> {
  try {
    await writeChunksTo(labelWriteChar, buildLabels(data, size));
  } catch (e) {
    labelWriteChar = null;
    labelDeviceName = null;
    throw new Error(
      e instanceof Error && e.message.startsWith('Chưa kết nối')
        ? 'Chưa kết nối máy in tem. Bấm "In tem" rồi chọn máy in tem 50mm.'
        : 'In tem thất bại — kiểm tra máy in tem đã bật và ở gần điện thoại.',
    );
  }
}
