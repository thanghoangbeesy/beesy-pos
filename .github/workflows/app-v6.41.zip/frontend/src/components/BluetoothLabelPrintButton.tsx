import { useState } from 'react';
import { useToast } from './Toast';
import { LineIcon } from './LineIcon';
import type { Order } from '../lib/types';
import {
  connectLabelPrinter,
  isBluetoothSupported,
  isLabelPrinterConnected,
  printLabels,
} from '../lib/printer';
import { printLabelsViaSystem } from '../lib/label-print';
import { getPrintSettings } from '../lib/db';

/** Nút in tem món — in theo Cài đặt → In ấn (mặc định máy in tem Bluetooth
 * riêng 50mm; nếu cài đặt là Hệ thống thì in qua hộp thoại in của thiết bị,
 * tem giữ nguyên dấu tiếng Việt). Mỗi ly 1 tem. Máy in tem giữ kết nối riêng
 * với máy in bill nên in bill không bị gửi nhầm sang máy in tem. */
export function BluetoothLabelPrintButton({
  order,
  small = false,
  shopName = 'Beesy Coffee & Tea',
  customerName = null,
}: {
  order: Order;
  small?: boolean;
  shopName?: string;
  customerName?: string | null;
}) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const supported = isBluetoothSupported();
  const cupCount = order.items.reduce((a, it) => a + Math.max(0, Math.floor(it.qty)), 0);

  const doPrint = async () => {
    const ps = await getPrintSettings();
    if (ps.label_route === 'system') {
      if (cupCount === 0) {
        toast.show('Đơn không có món nên không có tem để in.');
        return;
      }
      printLabelsViaSystem(order, ps.label_size, shopName, customerName);
      toast.show('Chọn máy in WiFi/LAN trong hộp thoại in.');
      return;
    }
    if (!supported) {
      toast.show('Trình duyệt không hỗ trợ Bluetooth. Dùng Chrome trên Android/PC để in tem.');
      return;
    }
    if (cupCount === 0) {
      toast.show('Đơn không có món nên không có tem để in.');
      return;
    }
    setBusy(true);
    try {
      if (!isLabelPrinterConnected()) {
        const name = await connectLabelPrinter();
        toast.show(`Đã kết nối ${name}`);
      }
      await printLabels({
        order,
        shopName,
        customerName,
      }, ps.label_size);
      toast.show(`Đã gửi lệnh in ${cupCount} tem`);
    } catch (e) {
      toast.show(e instanceof Error ? e.message : 'In tem thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <button
      className={`btn btn-outline ${small ? 'btn-sm' : 'btn-lg'}`}
      style={{ width: '100%', ...(small ? { padding: '8px 4px', fontSize: 13 } : {}) }}
      disabled={busy}
      onClick={doPrint}
    >
      {busy ? 'Đang in…' : (
        <>
          <LineIcon name="tag" size={16} /> In tem
        </>
      )}
    </button>
  );
}
