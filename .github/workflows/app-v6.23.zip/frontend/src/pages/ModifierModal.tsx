import { useMemo, useState } from 'react';
import { Sheet } from '../components/Sheet';
import { TIcon } from '../components/TIcon';
import { formatVND } from '../lib/format';
import type { ModifierGroup, ModifierOption, Product, SelectedModifier } from '../lib/types';

// Bottom-sheet chọn modifier: single = lưới chọn 1, multi = chọn nhiều + giá, ghi chú, tổng live
export function ModifierModal({
  product,
  groups,
  initial,
  allowCustomPrice,
  onAdd,
  onClose,
}: {
  product: Product;
  groups: ModifierGroup[];
  /** Sửa dòng đã có: nạp sẵn topping/ghi chú/số lượng/giá cũ. */
  initial?: {
    modifiers: SelectedModifier[];
    note: string;
    qty: number;
    unitPrice?: number;
  } | null;
  /** Chỉ POS mới được nhập tay giá (trang khách đặt hàng không hiện ô giá). */
  allowCustomPrice?: boolean;
  onAdd: (mods: SelectedModifier[], note: string, qty: number, unitPrice?: number) => void;
  onClose: () => void;
}) {
  const active = useMemo(
    () =>
      [...groups]
        .filter((g) => g.active)
        .sort((a, b) => a.sort_order - b.sort_order)
        .map((g) => ({ ...g, options: g.options.filter((o) => o.active).sort((a, b) => a.sort_order - b.sort_order) }))
        .filter((g) => g.options.length > 0),
    [groups],
  );

  // Mặc định: nhóm single bắt buộc → chọn option đầu tiên (giảm tap).
  // Sửa dòng: nạp lại topping đã chọn (option không còn trong nhóm thì bỏ qua).
  const [sel, setSel] = useState<Record<string, string[]>>(() => {
    const init: Record<string, string[]> = {};
    const initialIds = new Set((initial?.modifiers ?? []).map((m) => m.option_id));
    for (const g of active) {
      if (g.selection_type === 'single') {
        const picked = g.options.find((o) => initialIds.has(o.id));
        init[g.id] = picked ? [picked.id] : (g.required && g.options[0] ? [g.options[0].id] : []);
      } else {
        init[g.id] = g.options.filter((o) => initialIds.has(o.id)).map((o) => o.id);
      }
    }
    return init;
  });
  const [note, setNote] = useState(initial?.note ?? '');
  // Số lượng nhập tay: chuỗi để gõ dở không bị ép về 1 (rỗng → tính là 1 khi chốt)
  const [qtyStr, setQtyStr] = useState(String(initial?.qty ?? 1));
  const qty = Math.max(1, parseInt(qtyStr.replace(/\D/g, ''), 10) || 1);
  // Giá bán nhập tay (chỉ POS): rỗng → giá menu; 0 = tặng
  const [priceStr, setPriceStr] = useState(
    initial?.unitPrice !== undefined && initial?.unitPrice !== null
      ? String(initial.unitPrice)
      : String(product.base_price),
  );
  const customPrice = priceStr.trim() === '' ? product.base_price : Math.max(0, parseInt(priceStr.replace(/\D/g, ''), 10) || 0);

  const optById = useMemo(() => {
    const m = new Map<string, { opt: ModifierOption; group: ModifierGroup }>();
    for (const g of active) for (const o of g.options) m.set(o.id, { opt: o, group: g });
    return m;
  }, [active]);

  const toggle = (group: ModifierGroup, optionId: string) => {
    setSel((prev) => {
      const cur = prev[group.id] ?? [];
      if (group.selection_type === 'single') return { ...prev, [group.id]: [optionId] };
      return {
        ...prev,
        [group.id]: cur.includes(optionId) ? cur.filter((id) => id !== optionId) : [...cur, optionId],
      };
    });
  };

  const selected: SelectedModifier[] = useMemo(
    () =>
      Object.values(sel)
        .flat()
        .map((id) => optById.get(id))
        .filter((x): x is { opt: ModifierOption; group: ModifierGroup } => !!x)
        .map(({ opt, group }) => ({
          option_id: opt.id,
          group: group.name,
          option: opt.name,
          price_delta: opt.price_delta,
        })),
    [sel, optById],
  );

  const unitTotal = (allowCustomPrice ? customPrice : product.base_price) + selected.reduce((s, m) => s + m.price_delta, 0);
  const missingRequired = active.some((g) => g.required && (sel[g.id] ?? []).length === 0);

  const submit = () => {
    if (missingRequired) return;
    onAdd(selected, note.trim(), qty, allowCustomPrice ? customPrice : undefined);
  };

  return (
    <Sheet
      title={`${product.name} — ${formatVND(product.base_price)}`}
      onClose={onClose}
      footer={
        <div>
          <div className="row" style={{ marginBottom: 10 }}>
            <div className="qty-ctl">
              <button className="qty-btn" onClick={() => setQtyStr(String(Math.max(1, qty - 1)))} aria-label="Giảm số lượng">−</button>
              <input
                className="input"
                style={{ width: 64, textAlign: 'center', padding: '6px 4px' }}
                inputMode="numeric"
                aria-label="Số lượng"
                value={qtyStr}
                onChange={(e) => setQtyStr(e.target.value.replace(/\D/g, ''))}
              />
              <button className="qty-btn" onClick={() => setQtyStr(String(qty + 1))} aria-label="Tăng số lượng">+</button>
            </div>
            <span className="grow" />
            <span className="money" style={{ fontSize: 22 }}>
              {formatVND(unitTotal * qty)}
            </span>
          </div>
          <button className="btn btn-green btn-block btn-lg" disabled={missingRequired} onClick={submit}>
            <TIcon emoji={initial ? '💾' : '➕'} size={16} /> {initial ? 'Lưu thay đổi' : 'Thêm vào giỏ'}
          </button>
          {missingRequired && <div className="small text-red" style={{ marginTop: 6, textAlign: 'center' }}>Vui lòng chọn đủ các mục bắt buộc (*)</div>}
        </div>
      }
    >
      {allowCustomPrice && (
        <div className="field">
          <label htmlFor="mod-price">💰 Giá bán (nhập tay, topping vẫn cộng thêm)</label>
          <input
            id="mod-price"
            className="input"
            inputMode="numeric"
            placeholder={String(product.base_price)}
            value={priceStr}
            onChange={(e) => setPriceStr(e.target.value.replace(/\D/g, ''))}
          />
        </div>
      )}
      {active.map((g) => (
        <div className="mod-group" key={g.id}>
          <h4>
            {g.name}
            {g.required && <span className="req">* bắt buộc</span>}
            {g.selection_type === 'multi' && <span className="req muted">· chọn nhiều</span>}
          </h4>
          <div className="opt-grid">
            {g.options.map((o) => {
              const on = (sel[g.id] ?? []).includes(o.id);
              return (
                <button key={o.id} className={`opt-btn${on ? ' selected' : ''}`} onClick={() => toggle(g, o.id)}>
                  {on ? '✅ ' : ''}{o.name}
                  <span className="delta">{o.price_delta > 0 ? `+${formatVND(o.price_delta)}` : o.price_delta < 0 ? formatVND(o.price_delta) : 'miễn phí'}</span>
                </button>
              );
            })}
          </div>
        </div>
      ))}
      <div className="field">
        <label htmlFor="mod-note">📝 Ghi chú cho pha chế</label>
        <input
          id="mod-note"
          className="input"
          placeholder="VD: ít đá, mang đi xa…"
          value={note}
          onChange={(e) => setNote(e.target.value)}
        />
      </div>
    </Sheet>
  );
}
