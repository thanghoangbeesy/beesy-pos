import { useEffect, useState } from 'react';
import type { FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { initializeApp, getApps } from 'firebase/app';
import { createUserWithEmailAndPassword, getAuth, signOut } from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import {
  DbError,
  type VoucherInput,
  createPaymentMethod,
  deletePaymentMethod,
  downloadFile,
  ensureWarehousesSeeded,
  exportAllJson,
  exportTableCsv,
  getDefaultWarehouseId,
  getSettings,
  isSystemPaymentMethod,
  listPaymentMethods,
  listProducts,
  listUsers,
  listWarehouses,
  paymentKindLabel,
  setDefaultWarehouse,
  setSetting,
  updatePaymentMethod,
  getPromotions,
  getOrCreateTenantId,
  logAudit,
  savePromotions,
  listVouchers,
  saveVoucher,
  deleteVoucher,
  listCombos,
  saveCombo,
  deleteCombo,
  toggleCombo,
  updateUserRole,
  updateUserWarehouses,
} from '../lib/db';
import type { Combo, ComboItem, PaymentMethodDef, PaymentMethodKind, Promotion, RoleKey, User, Voucher, Warehouse } from '../lib/types';
import { ROLE_LABELS, STAFF_ROLES } from '../lib/permissions';
import { db, firebaseConfig } from '../lib/firebase';
import {
  backupToDrive,
  cacheDriveClientId,
  downloadBackupFile,
  DRIVE_CLIENT_ID_SETTING_KEY,
  getDriveClientIdSync,
  isDriveConfigured,
  listBackupFiles,
  restoreFromData,
  setDriveClientId,
  type DriveFileInfo,
} from '../lib/drive';
import { resolveVietQRBin } from '../lib/vietqr';
import { todayVN } from '../lib/format';
import { Sheet } from '../components/Sheet';
import { useToast } from '../components/Toast';
import { NotifySettings } from '../components/NotifySettings';
import { useAuth } from '../lib/auth';
import { isSuperAdmin } from './ShopSetupChecklist';
import { MenuIcon } from '../components/MenuIcon';
import { TIcon } from '../components/TIcon';
import { applyBrandColor, compressLogoToDataUrl, isValidHexColor, loadBrand } from '../lib/brand';
import { PLAN_LABEL, activateLicense, canUsePro, generateLicenseKey, getLicense, parseLicenseKey, type License, type LicensePlan } from '../lib/license';

const FIELDS = [
  { key: 'shop_name', label: 'Tên quán', placeholder: 'Beesy Coffee & Tea' },
  { key: 'shop_phone', label: 'Số điện thoại quán', placeholder: 'VD: 0901234567' },
  { key: 'shop_address', label: 'Địa chỉ quán', placeholder: 'VD: 123 Đường ABC, Quận XYZ' },
];

const LOYALTY_FIELDS = [
  { key: 'stamps_target', label: 'Số tem để đổi thưởng', placeholder: 'VD: 9', hint: 'Khách mua đủ số tem này được tặng 1 món.' },
  { key: 'loyalty_points_rate', label: 'Số tiền (đ) = 1 điểm', placeholder: 'VD: 10000', hint: 'VD: 10000 = mua 10k được 1 điểm.' },
  { key: 'loyalty_silver_at', label: 'Tổng chi để lên hạng Bạc (đ)', placeholder: 'VD: 1000000', hint: '' },
  { key: 'loyalty_gold_at', label: 'Tổng chi để lên hạng Vàng (đ)', placeholder: 'VD: 5000000', hint: '' },
  { key: 'loyalty_silver_discount', label: 'Giảm giá hạng Bạc (%)', placeholder: 'VD: 3', hint: 'Tự áp ở màn thanh toán.' },
  { key: 'loyalty_gold_discount', label: 'Giảm giá hạng Vàng (%)', placeholder: 'VD: 5', hint: 'Tự áp ở màn thanh toán.' },
];

const CSV_TABLES = [
  { key: 'orders' as const, label: 'Đơn hàng' },
  { key: 'products' as const, label: 'Sản phẩm' },
  { key: 'customers' as const, label: 'Khách hàng' },
  { key: 'categories' as const, label: 'Danh mục' },
  { key: 'payment_methods' as const, label: 'Thanh toán' },
];

const CONFIRM_WORD = 'KHOI PHUC';

type SectionKey = 'shop' | 'staff' | 'payment' | 'backup' | 'warehouse' | 'promo' | 'license' | 'loyalty' | 'notify';

function formatSize(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 KB';
  if (bytes >= 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${Math.max(1, Math.round(bytes / 1024))} KB`;
}

function formatDriveTime(iso: string): string {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleString('vi-VN', {
      timeZone: 'Asia/Ho_Chi_Minh',
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return iso;
  }
}

function OnlineOrderLinkCard() {
  const [copied, setCopied] = useState(false);
  const url = `${window.location.origin}/dat-hang`;
  const qr = `https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encodeURIComponent(url)}`;
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      /* bỏ qua */
    }
  };
  return (
    <div className="row" style={{ gap: 12, alignItems: 'center', flexWrap: 'wrap' }}>
      <img src={qr} alt="QR đặt hàng" width={110} height={110} style={{ borderRadius: 8 }} />
      <div style={{ flex: 1, minWidth: 180 }}>
        <div className="small" style={{ wordBreak: 'break-all', marginBottom: 8 }}>{url}</div>
        <button className="btn btn-outline" style={{ minHeight: 40 }} onClick={() => void copy()}>
          {copied ? 'Đã sao chép ✓' : <><TIcon emoji="📋" size={15} /> Sao chép link</>}
        </button>
      </div>
    </div>
  );
}

export function Settings() {
  const [brandLogo, setBrandLogo] = useState('');
  const [brandColor, setBrandColor] = useState('#00B14F');
  const [brandSaving, setBrandSaving] = useState(false);
  const [license, setLicense] = useState<License | null>(null);
  const [licenseKey, setLicenseKey] = useState('');
  const [licenseBusy, setLicenseBusy] = useState(false);
  const [genPlan, setGenPlan] = useState<LicensePlan>('pro');
  const [genExpiry, setGenExpiry] = useState('');
  const [genKey, setGenKey] = useState('');
  const [tenantId, setTenantId] = useState('');
  const [loyaltyVals, setLoyaltyVals] = useState<Record<string, string>>({});
  const [loyaltySaving, setLoyaltySaving] = useState(false);

  const [voucherPro, setVoucherPro] = useState<boolean | null>(null);
  const [goodsCosts, setGoodsCosts] = useState(false);
  const [goodsCostsSaving, setGoodsCostsSaving] = useState(false);
  const toast = useToast();
  const { isOwner, logout, user: me } = useAuth();
  const navigate = useNavigate();
  const [values, setValues] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [backing, setBacking] = useState(false);
  const [openSection, setOpenSection] = useState<SectionKey | null>('shop');

  // Google Drive backup
  const [driveBusy, setDriveBusy] = useState(false);  const [driveReady, setDriveReady] = useState(isDriveConfigured());
  const [clientIdInput, setClientIdInput] = useState('');
  const [showClientIdForm, setShowClientIdForm] = useState(false);
  const [savingClientId, setSavingClientId] = useState(false);
  const [filesOpen, setFilesOpen] = useState(false);
  const [filesLoading, setFilesLoading] = useState(false);
  const [backupFiles, setBackupFiles] = useState<DriveFileInfo[]>([]);
  const [confirmTarget, setConfirmTarget] = useState<DriveFileInfo | null>(null);

  const [confirmText, setConfirmText] = useState('');
  const [jsonRestore, setJsonRestore] = useState<{ name: string; data: Record<string, unknown[]> } | null>(null);
  const [jsonConfirmText, setJsonConfirmText] = useState('');

  useEffect(() => {
    getSettings()
      .then((s) => { setValues(s); setGoodsCosts(s['include_goods_costs'] === '1'); })
      .catch(() => toast.show('Không tải được cài đặt'))
      .finally(() => setLoading(false));
    // Client ID Drive: ưu tiên bản lưu ở Firestore (đồng bộ mọi thiết bị),
    // rồi đến bản lưu cục bộ / biến build-time.
    getDoc(doc(db, 'settings', DRIVE_CLIENT_ID_SETTING_KEY))
      .then((s) => {
        const id = String(s.data()?.value ?? '').trim();
        if (id) {
          if (id !== getDriveClientIdSync()) cacheDriveClientId(id);
          setClientIdInput(id);
          setDriveReady(true);
          return;
        }
        const local = getDriveClientIdSync();
        if (local) {
          setClientIdInput(local);
          setDriveReady(true);
        }
      })
      .catch(() => {
        const local = getDriveClientIdSync();
        if (local) {
          setClientIdInput(local);
          setDriveReady(true);
        }
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const toggle = (key: SectionKey) => setOpenSection((cur) => (cur === key ? null : key));

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const save = async (e: FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      for (const f of FIELDS) {
        await setSetting(f.key, values[f.key] ?? '');
      }
      toast.show('✅ Đã lưu cài đặt');
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Lưu thất bại');
    } finally {
      setSaving(false);
    }
  };

  const backupJson = async () => {
    setBacking(true);
    try {
      const d = todayVN().replace(/-/g, '');
      const data = await exportAllJson();
      downloadFile(`beesy-backup-${d}.json`, JSON.stringify(data, null, 2), 'application/json');
      toast.show('Đã tải file sao lưu JSON');
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Sao lưu thất bại');
    } finally {
      setBacking(false);
    }
  };

  const pickJsonFile = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json,application/json';
    input.onchange = async () => {
      const file = input.files?.[0];
      if (!file) return;
      try {
        const text = await file.text();
        const data = JSON.parse(text) as unknown;
        if (!data || typeof data !== 'object' || Array.isArray(data)) {
          throw new Error('File không đúng định dạng sao lưu.');
        }
        const rec = data as Record<string, unknown>;
        const hasData = Object.values(rec).some((v) => Array.isArray(v) && v.length > 0);
        if (!hasData) throw new Error('File sao lưu không có dữ liệu nào.');
        setJsonRestore({ name: file.name, data: rec as Record<string, unknown[]> });
        setJsonConfirmText('');
      } catch (ex) {
        toast.show(ex instanceof Error ? ex.message : 'Đọc file thất bại');
      }
    };
    input.click();
  };

  const doJsonRestore = async () => {
    if (!jsonRestore || jsonConfirmText !== CONFIRM_WORD) return;
    setBacking(true);
    try {
      const r = await restoreFromData(jsonRestore.data);
      toast.show(`Đã khôi phục ${r.docs} bản ghi (${r.collections} bảng) từ ${jsonRestore.name}`);
      setJsonRestore(null);
      setJsonConfirmText('');
    } catch (ex) {
      toast.show(ex instanceof Error ? ex.message : 'Khôi phục thất bại');
    } finally {
      setBacking(false);
    }
  };

  const backupCsv = async (table: (typeof CSV_TABLES)[number]['key']) => {
    setBacking(true);
    try {
      const d = todayVN().replace(/-/g, '');
      const csv = await exportTableCsv(table);
      downloadFile(`beesy-${table}-${d}.csv`, csv, 'text/csv');
      toast.show(`Đã tải CSV bảng ${table}`);
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Sao lưu thất bại');
    } finally {
      setBacking(false);
    }
  };

  // ------------------------------------------------------- Drive backup ---
  const saveClientId = async () => {
    const id = clientIdInput.trim();
    if (!id.endsWith('.apps.googleusercontent.com') || id.length < 20) {
      toast.show('Client ID chưa đúng định dạng (phải kết thúc bằng .apps.googleusercontent.com)');
      return;
    }
    setSavingClientId(true);
    try {
      await setSetting(DRIVE_CLIENT_ID_SETTING_KEY, id);
      setDriveClientId(id);
      setDriveReady(true);
      setShowClientIdForm(false);
      toast.show('✅ Đã lưu Google Client ID — bấm "Sao lưu lên Google Drive" để dùng ngay');
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Lưu Client ID thất bại');
    } finally {
      setSavingClientId(false);
    }
  };

  const driveBackup = async () => {
    setDriveBusy(true);
    try {
      const r = await backupToDrive();
      toast.show(`Đã sao lưu ${r.fileName} (${formatSize(r.size)}) lên Google Drive`);
    } catch (ex) {
      toast.show(ex instanceof Error ? ex.message : 'Sao lưu lên Drive thất bại');
    } finally {
      setDriveBusy(false);
    }
  };

  const loadBackupFiles = async () => {
    setFilesLoading(true);
    try {
      setBackupFiles(await listBackupFiles());
    } catch (ex) {
      toast.show(ex instanceof Error ? ex.message : 'Không tải được danh sách file sao lưu');
      setBackupFiles([]);
    } finally {
      setFilesLoading(false);
    }
  };

  const openRestore = () => {
    setConfirmTarget(null);
    setConfirmText('');
    setFilesOpen(true);
    void loadBackupFiles();
  };

  const [staffName, setStaffName] = useState('');
  const [staffEmail, setStaffEmail] = useState('');
  const [staffPass, setStaffPass] = useState('');
  const [staffRole, setStaffRole] = useState<RoleKey>('seller');
  const [staffBusy, setStaffBusy] = useState(false);
  const [staffListBusy, setStaffListBusy] = useState(false);

  // Khuyến mãi (giờ vàng)
  const [promos, setPromos] = useState<Promotion[]>([]);
  const [promoBusy, setPromoBusy] = useState(false);
  const [promoForm, setPromoForm] = useState<Promotion | 'new' | null>(null);
  const [vouchers, setVouchers] = useState<Voucher[]>([]);
  const [voucherBusy, setVoucherBusy] = useState(false);
  const [voucherForm, setVoucherForm] = useState<Voucher | 'new' | null>(null);
  const [promoTab, setPromoTab] = useState<'time' | 'voucher' | 'combo'>('time');
  const [combos, setCombos] = useState<Combo[]>([]);
  const [comboBusy, setComboBusy] = useState(false);
  const [comboForm, setComboForm] = useState<Combo | 'new' | null>(null);
  // Nhật ký thao tác

  // Multi-kho: kho mặc định + gán kho cho nhân viên
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [defaultWid, setDefaultWid] = useState('');
  const [whBusy, setWhBusy] = useState(false);
  const [whSaving, setWhSaving] = useState(false);

  const loadStaffWarehouse = async (forStaff: boolean) => {
    if (forStaff) setStaffListBusy(true); else setWhBusy(true);
    try {
      let ws = await listWarehouses(false);
      if (ws.length === 0) ws = await ensureWarehousesSeeded();
      const [us, def] = await Promise.all([listUsers(), getDefaultWarehouseId()]);
      setWarehouses(ws);
      setUsers(us);
      setDefaultWid(def ?? '');
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tải được cài đặt kho');
    } finally {
      if (forStaff) setStaffListBusy(false); else setWhBusy(false);
    }
  };

  useEffect(() => {
    if (openSection === 'shop') {
      loadBrand().then((b) => {
        setBrandLogo(b.logo);
        setBrandColor(b.color);
      }).catch(() => {});
    }
    if (openSection === 'license') {
      getLicense().then(setLicense).catch(() => {});
      getOrCreateTenantId().then(setTenantId).catch(() => {});
    }
    if (openSection === 'loyalty') {
      getSettings().then((st) => {
        const v: Record<string, string> = {};
        for (const f of LOYALTY_FIELDS) v[f.key] = st[f.key] ?? '';
        setLoyaltyVals(v);
      }).catch(() => {});
    }
    if (openSection === 'warehouse') void loadStaffWarehouse(false);
    else if (openSection === 'staff') void loadStaffWarehouse(true);
    else if (openSection === 'promo') {
      void loadPromos();
      canUsePro().then((v) => {
        setVoucherPro(v);
        if (v) {
          void loadVouchers();
          void loadCombos();
        }
      }).catch(() => setVoucherPro(true));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [openSection]);

  const loadPromos = async () => {
    setPromoBusy(true);
    try {
      setPromos(await getPromotions());
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tải được khuyến mãi');
    } finally {
      setPromoBusy(false);
    }
  };

  const loadVouchers = async () => {
    setVoucherBusy(true);
    try {
      setVouchers(await listVouchers());
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tải được voucher');
    } finally {
      setVoucherBusy(false);
    }
  };

  const saveVoucherForm = async (v: VoucherInput) => {
    try {
      const saved = await saveVoucher(v, voucherForm && voucherForm !== 'new' ? voucherForm.id : undefined);
      setVouchers((prev) => {
        const next = prev.filter((x) => x.id !== saved.id);
        return [saved, ...next];
      });
      setVoucherForm(null);
      toast.show('Đã lưu voucher');
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu voucher thất bại');
    }
  };

  const removeVoucher = async (id: string) => {
    if (!window.confirm('Xóa voucher này?')) return;
    try {
      await deleteVoucher(id);
      setVouchers((prev) => prev.filter((x) => x.id !== id));
      toast.show('Đã xóa voucher');
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Xóa voucher thất bại');
    }
  };

  const toggleVoucher = async (v: Voucher) => {
    try {
      const saved = await saveVoucher(
        {
          code: v.code, name: v.name, type: v.type, value: v.value,
          max_discount: v.max_discount, min_order: v.min_order, usage_limit: v.usage_limit,
          start_date: v.start_date, end_date: v.end_date, active: !v.active,
        },
        v.id,
      );
      setVouchers((prev) => prev.map((x) => (x.id === saved.id ? saved : x)));
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Đổi trạng thái thất bại');
    }
  };

  const loadCombos = async () => {
    setComboBusy(true);
    try {
      setCombos(await listCombos());
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tải được combo');
    } finally {
      setComboBusy(false);
    }
  };

  const saveComboForm = async (c: { id?: string; name: string; price: number; items: ComboItem[] }) => {
    try {
      const saved = await saveCombo(c);
      setCombos((prev) => {
        const next = prev.filter((x) => x.id !== saved.id);
        return [...next, saved].sort((a, b) => a.sort_order - b.sort_order);
      });
      setComboForm(null);
      toast.show('Đã lưu combo');
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu combo thất bại');
    }
  };

  const removeCombo = async (id: string) => {
    if (!window.confirm('Xóa combo này?')) return;
    try {
      await deleteCombo(id);
      setCombos((prev) => prev.filter((x) => x.id !== id));
      toast.show('Đã xóa combo');
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Xóa combo thất bại');
    }
  };

  const savePromoForm = async (p: Promotion) => {
    try {
      const next = promoForm === 'new' ? [...promos, p] : promos.map((x) => (x.id === p.id ? p : x));
      await savePromotions(next);
      setPromos(next);
      setPromoForm(null);
      toast.show('Đã lưu khuyến mãi');
      logAudit('promo.save', `Lưu khuyến mãi "${p.name}"`, { type: 'promotion', id: p.id });
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    }
  };

  const deletePromo = async (id: string) => {
    if (!window.confirm('Xóa khuyến mãi này?')) return;
    try {
      const next = promos.filter((x) => x.id !== id);
      await savePromotions(next);
      setPromos(next);
      toast.show('Đã xóa khuyến mãi');
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Xóa thất bại');
    }
  };

  const togglePromo = async (p: Promotion) => {
    try {
      const next = promos.map((x) => (x.id === p.id ? { ...x, active: !x.active } : x));
      await savePromotions(next);
      setPromos(next);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    }
  };

  const saveDefaultWarehouse = async () => {
    if (!defaultWid) {
      toast.show('Chọn kho mặc định');
      return;
    }
    setWhSaving(true);
    try {
      await setDefaultWarehouse(defaultWid);
      toast.show('Đã đặt kho bán hàng mặc định');
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    } finally {
      setWhSaving(false);
    }
  };

  const changeUserRole = async (u: User, role: RoleKey) => {
    if (role === u.role) return;
    try {
      await updateUserRole(u.id, role);
      setUsers((us) => us.map((x) => (x.id === u.id ? { ...x, role } : x)));
      toast.show(`Đã đổi ${u.full_name || u.email} thành ${ROLE_LABELS[role]}`);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Đổi vai trò thất bại');
    }
  };

  const toggleUserWarehouse = async (u: User, wid: string) => {
    const has = (u.warehouse_ids ?? []).includes(wid);
    const next = has
      ? (u.warehouse_ids ?? []).filter((x) => x !== wid)
      : [...(u.warehouse_ids ?? []), wid];
    try {
      await updateUserWarehouses(u.id, next);
      setUsers((us) => us.map((x) => (x.id === u.id ? { ...x, warehouse_ids: next } : x)));
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Cập nhật thất bại');
    }
  };

  // Chủ quán thêm tài khoản nhân viên ngay trong app (dùng Firebase app phụ để
  // không bị đăng xuất khỏi phiên chủ quán hiện tại).
  const addStaff = async (e: FormEvent) => {
    e.preventDefault();
    if (!staffName.trim() || !staffEmail.trim() || staffPass.length < 6) {
      toast.show('Nhập tên, email và mật khẩu (≥ 6 ký tự) cho nhân viên');
      return;
    }
    setStaffBusy(true);
    try {
      const secondary =
        getApps().find((a) => a.name === 'beesy-secondary') ??
        initializeApp(firebaseConfig, 'beesy-secondary');
      const secondaryAuth = getAuth(secondary);
      const cred = await createUserWithEmailAndPassword(secondaryAuth, staffEmail.trim(), staffPass);
      await signOut(secondaryAuth);
      await setDoc(doc(db, 'users', cred.user.uid), {
        id: cred.user.uid,
        email: staffEmail.trim(),
        full_name: staffName.trim(),
        role: staffRole,
        warehouse_ids: [],
      });
      toast.show(`Đã thêm ${ROLE_LABELS[staffRole]} ${staffName.trim()} (${staffEmail.trim()})`);
      setStaffName('');
      setStaffEmail('');
      setStaffPass('');
      setStaffRole('seller');
      void loadStaffWarehouse(true);
    } catch (ex) {
      const code = (ex as { code?: string })?.code ?? '';
      toast.show(
        code === 'auth/email-already-in-use'
          ? 'Email này đã được đăng ký.'
          : ex instanceof DbError
            ? ex.message
            : 'Thêm nhân viên thất bại. Kiểm tra mạng rồi thử lại.',
      );
    } finally {
      setStaffBusy(false);
    }
  };

  const doRestore = async () => {
    if (!confirmTarget || confirmText !== CONFIRM_WORD) return;
    setDriveBusy(true);
    try {
      const data = await downloadBackupFile(confirmTarget.id);
      const r = await restoreFromData(data);
      toast.show(`Đã khôi phục ${r.docs} bản ghi (${r.collections} bảng) từ ${confirmTarget.name}`);
      setFilesOpen(false);
      setConfirmTarget(null);
      setConfirmText('');
    } catch (ex) {
      toast.show(ex instanceof Error ? ex.message : 'Khôi phục thất bại');
    } finally {
      setDriveBusy(false);
    }
  };

  if (!isOwner) {
    return (
      <div className="page">
        <div className="card sb-empty">
          <div className="eico"><TIcon emoji="🔒" size={28} /></div>
          <p style={{ fontWeight: 600, color: 'var(--ink)', marginBottom: 16 }}>
            Chỉ chủ quán mới được xem cài đặt.
          </p>
          <button
            className="btn btn-block"
            style={{}}
            onClick={handleLogout}
          >
            Đăng xuất
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="page">
      <div className="pg-home" style={{ paddingBottom: 12 }}>
        <div className="pg-shop-sub" style={{ color: 'rgba(255,255,255,.9)' }}>Chủ cửa hàng · <span className="sb-status-pill" style={{ marginLeft: 4 }}>Đã thiết lập</span></div>
      </div>

      <div className="sb-section" style={{ padding: '4px 16px' }}>
        <button className="sb-menu-row" onClick={() => toggle('shop')}>
          <MenuIcon name="gear" fallback="🏪" />
          Thông tin quán
          <span className="chev">›</span>
        </button>
        {openSection === 'shop' && (
          <div style={{ padding: '16px 4px 12px' }}>
            {loading ? (
              <div className="muted">Đang tải…</div>
            ) : (
              <form onSubmit={save}>
                {FIELDS.map((f) => (
                  <div className="sb-float" key={f.key}>
                    <label htmlFor={`set-${f.key}`}>{f.label}</label>
                    <input
                      id={`set-${f.key}`}
                      placeholder={f.placeholder}
                      value={values[f.key] ?? ''}
                      onChange={(e) => setValues((v) => ({ ...v, [f.key]: e.target.value }))}
                    />
                  </div>
                ))}
                <button type="submit" className="btn btn-block" disabled={saving}>
                  {saving ? 'Đang lưu…' : 'Lưu cài đặt'}
                </button>
              </form>
            )}
            <div className="card" style={{ marginTop: 12 }}>
              <div className="sb-menu-row" style={{ marginBottom: 10 }}>
                <span className="sb-menu-ico"><MenuIcon name="clipboard" fallback="📊" /></span>
                <span style={{ fontWeight: 700 }}>Báo cáo</span>
              </div>
              <label className="row" style={{ gap: 8, alignItems: 'center' }}>
                <input
                  type="checkbox"
                  checked={goodsCosts}
                  disabled={goodsCostsSaving}
                  onChange={async (e) => {
                    const v = e.target.checked;
                    setGoodsCosts(v);
                    setGoodsCostsSaving(true);
                    try {
                      await setSetting('include_goods_costs', v ? '1' : '0');
                      toast.show('Đã lưu cài đặt');
                    } catch (ex) {
                      setGoodsCosts(!v);
                      toast.show(ex instanceof DbError ? ex.message : 'Lưu thất bại');
                    } finally {
                      setGoodsCostsSaving(false);
                    }
                  }}
                />
                <span>Tính chi phí nhập hàng + nguyên liệu vào chi phí tổng</span>
              </label>
              <p className="small muted" style={{ marginTop: 8 }}>
                Bật thì Chi phí trong báo cáo = Vận hành + Nhập hàng + Nguyên liệu, Lợi nhuận = Doanh thu − Chi phí tổng. Tắt thì giữ cách tính cũ (Chi phí = vận hành, Lợi nhuận đã trừ giá vốn riêng).
              </p>
            </div>
            <div className="card" style={{ marginTop: 12 }}>
              <div className="sb-menu-row" style={{ marginBottom: 10 }}>
                <span className="sb-menu-ico"><MenuIcon name="store" fallback="🏪" /></span>
                <span style={{ fontWeight: 700 }}>Thương hiệu</span>
              </div>
              <div className="row" style={{ gap: 12, alignItems: 'flex-start', marginBottom: 10 }}>
                <div
                  style={{
                    width: 64, height: 64, borderRadius: 16, background: 'var(--brand-light)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28, overflow: 'hidden', flexShrink: 0,
                  }}
                >
                  {brandLogo.startsWith('data:image') ? (
                    <img src={brandLogo} alt="logo" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  ) : (
                    <MenuIcon name="store" fallback="🏪" />
                  )}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div className="field" style={{ marginBottom: 10 }}>
                    <label>Tải logo lên</label>
                    <div className="row" style={{ gap: 8 }}>
                      <label className="btn btn-outline btn-upload" style={{ minHeight: 44, cursor: 'pointer', flex: 1 }}>
                        <TIcon emoji="📤" size={16} /><span>Chọn ảnh</span>
                        <input
                          type="file"
                          accept="image/*"
                          style={{ display: 'none' }}
                          onChange={(e) => {
                            const f = e.target.files?.[0];
                            if (!f) return;
                            compressLogoToDataUrl(f)
                              .then(setBrandLogo)
                              .catch(() => toast.show('Không đọc được ảnh'));
                            e.target.value = '';
                          }}
                        />
                      </label>
                      {brandLogo && (
                        <button type="button" className="btn btn-outline" style={{ minHeight: 44, padding: '0 14px' }} onClick={() => setBrandLogo('')}>
                          Xóa
                        </button>
                      )}
                    </div>
                  </div>
                  <div className="field" style={{ margin: 0 }}>
                    <label>Màu thương hiệu</label>
                    <div className="row" style={{ gap: 8, alignItems: 'center' }}>
                      <input
                        type="color"
                        value={isValidHexColor(brandColor) ? brandColor : '#00B14F'}
                        onChange={(e) => setBrandColor(e.target.value)}
                        style={{ width: 48, height: 44, padding: 4, border: '1px solid var(--line)', borderRadius: 8 }}
                      />
                      <input
                        className="input"
                        style={{ width: 110 }}
                        value={brandColor}
                        onChange={(e) => setBrandColor(e.target.value)}
                        placeholder="#00B14F"
                        maxLength={7}
                      />
                    </div>
                  </div>
                </div>
              </div>
              <button
                className="btn btn-block"
                disabled={brandSaving}
                onClick={() => {
                  setBrandSaving(true);
                  Promise.all([
                    setSetting('brand_logo', brandLogo.slice(0, 200000)),
                    setSetting('brand_color', isValidHexColor(brandColor) ? brandColor : '#00B14F'),
                  ])
                    .then(() => {
                      applyBrandColor(isValidHexColor(brandColor) ? brandColor : '#00B14F');
                      toast.show('Đã lưu thương hiệu');
                    })
                    .catch((e) => toast.show(e instanceof DbError ? e.message : 'Lưu thất bại'))
                    .finally(() => setBrandSaving(false));
                }}
              >
                {brandSaving ? 'Đang lưu…' : 'Lưu thương hiệu'}
              </button>
              <p className="small muted" style={{ marginBottom: 0 }}>
                Logo và màu áp dụng ngay cho app bán hàng và trang đặt online.
              </p>
            </div>
            <div className="card" style={{ marginTop: 12 }}>
              <div style={{ fontWeight: 700, marginBottom: 6 }}><TIcon emoji="🌐" size={16} /> Link đặt hàng online</div>
              <p className="small muted" style={{ marginTop: 0 }}>
                Khách quét QR hoặc mở link để tự đặt món mang về. Đơn chờ duyệt ở màn Pha chế.
              </p>
              <OnlineOrderLinkCard />
            </div>
          </div>
        )}

        <button className="sb-menu-row" onClick={() => toggle('staff')}>
          <MenuIcon name="users" fallback="👥" />
          Nhân viên
          <span className="chev">›</span>
        </button>
        {openSection === 'staff' && (
          <div style={{ padding: '16px 4px 12px' }}>
            <form onSubmit={addStaff}>
              <div className="sb-float">
                <label htmlFor="st-name">Tên nhân viên</label>
                <input
                  id="st-name"
                  value={staffName}
                  onChange={(e) => setStaffName(e.target.value)}
                  placeholder="VD: Lan"
                />
              </div>
              <div className="sb-float">
                <label htmlFor="st-email">Email đăng nhập</label>
                <input
                  id="st-email"
                  autoComplete="off"
                  value={staffEmail}
                  onChange={(e) => setStaffEmail(e.target.value)}
                  placeholder="VD: lan@beesy.local"
                />
              </div>
              <div className="sb-float">
                <label htmlFor="st-pass">Mật khẩu (≥ 6 ký tự)</label>
                <input
                  id="st-pass"
                  type="password"
                  autoComplete="new-password"
                  value={staffPass}
                  onChange={(e) => setStaffPass(e.target.value)}
                  placeholder="••••••"
                />
              </div>
              <div className="field">
                <label>Nhóm nhân viên</label>
                <select
                  className="input"
                  value={staffRole}
                  onChange={(e) => setStaffRole(e.target.value as RoleKey)}
                >
                  {STAFF_ROLES.map((r) => (
                    <option key={r} value={r}>
                      {ROLE_LABELS[r]}
                      {r === 'manager'
                        ? ' — quản lý menu, kho, quỹ, báo cáo'
                        : r === 'cashier'
                          ? ' — bán hàng, thu nợ'
                          : ' — bán hàng'}
                    </option>
                  ))}
                </select>
              </div>
              <button type="submit" className="btn btn-block" disabled={staffBusy}>
                {staffBusy ? 'Đang thêm…' : 'Thêm nhân viên'}
              </button>
              <p className="small muted" style={{ marginBottom: 0, marginTop: 10 }}>
                Nhân viên dùng email/mật khẩu này để đăng nhập. Xóa tài khoản: Firebase
                console → Authentication / Firestore.
              </p>
            </form>

            <div style={{ fontWeight: 700, fontSize: 15, margin: '20px 0 8px' }}>
              Danh sách nhân viên
            </div>
            {staffListBusy ? (
              <div className="muted">Đang tải…</div>
            ) : users.filter((u) => u.role !== 'owner').length === 0 ? (
              <p className="small muted">Chưa có tài khoản nhân viên nào.</p>
            ) : (
              users
                .filter((u) => u.role !== 'owner')
                .map((u) => (
                  <div className="sb-section" key={u.id} style={{ marginBottom: 10 }}>
                    <div style={{ fontWeight: 600, fontSize: 15 }}>
                      {u.full_name || u.email}
                      <span className="small muted"> · {u.email}</span>
                    </div>
                    <div className="field" style={{ marginTop: 8, marginBottom: 8 }}>
                      <label>Nhóm</label>
                      <select
                        className="input"
                        value={u.role}
                        onChange={(e) => void changeUserRole(u, e.target.value as RoleKey)}
                      >
                        {STAFF_ROLES.map((r) => (
                          <option key={r} value={r}>
                            {ROLE_LABELS[r]}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="small muted" style={{ marginBottom: 6, fontWeight: 600 }}>
                      Kho được dùng
                    </div>
                    <div className="row" style={{ flexWrap: 'wrap', gap: 8 }}>
                      {warehouses.filter((w) => w.active).length === 0 ? (
                        <span className="small muted">Chưa có kho nào.</span>
                      ) : (
                        warehouses
                          .filter((w) => w.active)
                          .map((w) => {
                            const checked = (u.warehouse_ids ?? []).includes(w.id);
                            return (
                              <label
                                key={w.id}
                                className={`sb-chip${checked ? ' selected' : ''}`}
                                style={{ minHeight: 36, padding: '4px 12px', fontSize: 13, cursor: 'pointer' }}
                              >
                                <input
                                  type="checkbox"
                                  checked={checked}
                                  onChange={() => void toggleUserWarehouse(u, w.id)}
                                  style={{ marginRight: 6 }}
                                />
                                {w.name}
                              </label>
                            );
                          })
                      )}
                    </div>
                  </div>
                ))
            )}
          </div>
        )}

        <button className="sb-menu-row" onClick={() => toggle('warehouse')}>
          <MenuIcon name="archive" fallback="🗃️" />
          Kho hàng
          <span className="chev">›</span>
        </button>
        {openSection === 'warehouse' && (
          <div style={{ padding: '16px 4px 12px' }}>
            {whBusy ? (
              <div className="muted">Đang tải…</div>
            ) : (
              <>
                <div className="field">
                  <label>Kho bán hàng mặc định (POS trừ tồn ở kho này)</label>
                  <select
                    className="input"
                    value={defaultWid}
                    onChange={(e) => setDefaultWid(e.target.value)}
                  >
                    <option value="">— Chọn kho —</option>
                    {warehouses
                      .filter((w) => w.active)
                      .map((w) => (
                        <option key={w.id} value={w.id}>
                          {w.name}
                        </option>
                      ))}
                  </select>
                </div>
                <button type="button" className="btn btn-block" disabled={whSaving} onClick={saveDefaultWarehouse}>
                  {whSaving ? 'Đang lưu…' : 'Lưu kho mặc định'}
                </button>

                <div style={{ fontWeight: 700, fontSize: 15, margin: '18px 0 8px' }}>
                  Phân quyền nhân viên
                </div>
                <p className="small muted" style={{ marginTop: 0 }}>
                  Đổi nhóm vai trò và gán kho cho từng nhân viên ở mục{' '}
                  <b>Nhân viên</b> bên trên. Quản lý dùng được mọi kho; Thu ngân/Bán hàng chỉ
                  dùng các kho được gán.
                </p>
                <button
                  type="button"
                  className="btn btn-outline btn-block"
                  style={{ marginTop: 6 }}
                  onClick={() => navigate('/inventory')}
                >
                  Quản lý kho ở màn Tồn kho →
                </button>
              </>
            )}
          </div>
        )}

        <button className="sb-menu-row" onClick={() => toggle('promo')}>
          <MenuIcon name="gift" fallback="🎁" />
          Khuyến mãi
          <span className="chev">›</span>
        </button>
        {openSection === 'promo' && (
          <div style={{ padding: '16px 4px 12px' }}>
            <div className="row" style={{ gap: 8, marginBottom: 12 }}>
              <button type="button" className={`sb-chip${promoTab === 'time' ? ' selected' : ''}`} onClick={() => setPromoTab('time')}>
                <TIcon emoji="🎁" size={15} /> Giờ vàng
              </button>
              <button type="button" className={`sb-chip${promoTab === 'voucher' ? ' selected' : ''}`} onClick={() => setPromoTab('voucher')}>
                <TIcon emoji="🎟️" size={15} /> Voucher
              </button>
              <button type="button" className={`sb-chip${promoTab === 'combo' ? ' selected' : ''}`} onClick={() => setPromoTab('combo')}>
                <TIcon emoji="🍱" size={15} /> Combo
              </button>
            </div>
            {promoTab === 'time' && (
            <>
            {promoBusy ? (
              <div className="muted">Đang tải…</div>
            ) : (
              <>
                <p className="small muted" style={{ marginTop: 0 }}>
                  Khuyến mãi đang trong khung giờ sẽ <b>tự áp dụng</b> ở màn thanh toán. Nhân viên
                  vẫn có thể sửa tay mức giảm cho từng đơn.
                </p>
                {promos.length === 0 ? (
                  <p className="small muted">Chưa có khuyến mãi nào.</p>
                ) : (
                  promos.map((p) => (
                    <div className="sb-section" key={p.id} style={{ marginBottom: 10, opacity: p.active ? 1 : 0.6 }}>
                      <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center' }}>
                        <div style={{ fontWeight: 600 }}>
                          {p.name}{' '}
                          <span className="small" style={{ color: 'var(--green)' }}>
                            {p.type === 'percent' ? `-${p.value}%` : `-${p.value.toLocaleString('vi-VN')}đ`}
                          </span>
                        </div>
                        <label className="switch" style={{ flexShrink: 0 }}>
                          <input type="checkbox" checked={p.active} onChange={() => void togglePromo(p)} />
                          <span className="track" />
                        </label>
                      </div>
                      <div className="small muted" style={{ margin: '4px 0 8px' }}>
                        ⏰ {p.start} – {p.end} hằng ngày
                      </div>
                      <div className="row" style={{ gap: 8 }}>
                        <button className="btn btn-outline" style={{ minHeight: 40 }} onClick={() => setPromoForm(p)}>
                          Sửa
                        </button>
                        <button
                          className="btn btn-outline"
                          style={{ minHeight: 40 }}
                          onClick={() => void deletePromo(p.id)}
                        >
                          Xóa
                        </button>
                      </div>
                    </div>
                  ))
                )}
                <button className="btn btn-block" onClick={() => setPromoForm('new')}>
                  ＋ Thêm khuyến mãi
                </button>
              </>
            )}
            {promoForm && (
              <PromoForm
                initial={promoForm === 'new' ? null : promoForm}
                onClose={() => setPromoForm(null)}
                onSave={(p) => void savePromoForm(p)}
              />
            )}
            </>
            )}
            {promoTab === 'voucher' && (
            <>
            {voucherPro === false ? (
              <div className="card" style={{ textAlign: 'center', padding: '32px 16px' }}>
                <div style={{ fontSize: 44 }}><TIcon emoji="🔒" size={44} /></div>
                <h3>Tính năng Pro</h3>
                <p className="muted">Voucher thuộc gói Nâng cao (Pro).<br />Mở mục <b>Giấy phép sử dụng</b> để kích hoạt.</p>
              </div>
            ) : (
            <>
            <p className="small muted" style={{ marginTop: 0 }}>
              Khách đọc mã ở quầy, nhân viên nhập mã ở màn thanh toán để trừ tiền.
              Lượt dùng được trừ tự động, chống dùng lố.
            </p>
            {voucherBusy ? (
              <div className="muted">Đang tải…</div>
            ) : (
              <>
                {vouchers.length === 0 ? (
                  <p className="small muted">Chưa có voucher nào.</p>
                ) : (
                  vouchers.map((v) => (
                    <div className="sb-section" key={v.id} style={{ marginBottom: 10, opacity: v.active ? 1 : 0.6 }}>
                      <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center' }}>
                        <div style={{ fontWeight: 700, letterSpacing: 1 }}>{v.code}</div>
                        <label className="switch" style={{ flexShrink: 0 }}>
                          <input type="checkbox" checked={v.active} onChange={() => void toggleVoucher(v)} />
                          <span className="track" />
                        </label>
                      </div>
                      <div style={{ fontWeight: 600, marginTop: 2 }}>
                        {v.name}{' '}
                        <span className="small" style={{ color: 'var(--green)' }}>
                          {v.type === 'percent' ? `-${v.value}%` : `-${v.value.toLocaleString('vi-VN')}đ`}
                          {v.type === 'percent' && v.max_discount != null ? ` (tối đa ${v.max_discount.toLocaleString('vi-VN')}đ)` : ''}
                        </span>
                      </div>
                      <div className="small muted" style={{ margin: '4px 0 8px' }}>
                        {v.min_order > 0 ? `Đơn tối thiểu ${v.min_order.toLocaleString('vi-VN')}đ · ` : ''}
                        Đã dùng {v.used_count}{v.usage_limit != null ? `/${v.usage_limit}` : ''} lượt
                        {v.start_date || v.end_date ? ` · ${v.start_date ?? '…'} → ${v.end_date ?? '…'}` : ''}
                      </div>
                      <div className="row" style={{ gap: 8 }}>
                        <button className="btn btn-outline" style={{ minHeight: 40 }} onClick={() => setVoucherForm(v)}>
                          Sửa
                        </button>
                        <button
                          className="btn btn-outline"
                          style={{ minHeight: 40 }}
                          onClick={() => void removeVoucher(v.id)}
                        >
                          Xóa
                        </button>
                      </div>
                    </div>
                  ))
                )}
                <button className="btn btn-block" onClick={() => setVoucherForm('new')}>
                  ＋ Thêm voucher
                </button>
              </>
            )}
            {voucherForm && (
              <VoucherForm
                initial={voucherForm === 'new' ? null : voucherForm}
                onClose={() => setVoucherForm(null)}
                onSave={(v) => void saveVoucherForm(v)}
              />
            )}
            </>
            )}
            </>
            )}
            {promoTab === 'combo' && (
              <ComboTab
                combos={combos}
                busy={comboBusy}
                proOk={voucherPro}
                onAdd={() => setComboForm('new')}
                onEdit={(c) => setComboForm(c)}
                onDelete={(id) => void removeCombo(id)}
                onToggle={(id) => void toggleCombo(id).then(() => void loadCombos())}
              />
            )}
            {comboForm && (
              <ComboForm
                initial={comboForm === 'new' ? null : comboForm}
                onClose={() => setComboForm(null)}
                onSave={(c) => void saveComboForm(c)}
              />
            )}
          </div>
        )}

        <button className="sb-menu-row" onClick={() => toggle('loyalty')}>
          <MenuIcon name="star" fallback="⭐" />
          Tích điểm & Tích tem
          <span className="chev">›</span>
        </button>
        {openSection === 'loyalty' && (
          <div style={{ padding: '16px 4px 12px' }}>
            <p className="small muted" style={{ marginTop: 0 }}>
              Cấu hình chương trình khách hàng thân thiết: tích tem đổi thưởng, tích điểm lên hạng.
            </p>
            <div className="sb-section" style={{ marginBottom: 12 }}>
              <h3 className="sb-section-title">🎟️ Tích tem</h3>
              {LOYALTY_FIELDS.slice(0, 1).map((f) => (
                <div className="field" key={f.key}>
                  <label>{f.label}</label>
                  <input
                    className="input"
                    inputMode="numeric"
                    placeholder={f.placeholder}
                    value={loyaltyVals[f.key] ?? ''}
                    onChange={(e) => setLoyaltyVals((v) => ({ ...v, [f.key]: e.target.value }))}
                  />
                  {f.hint && <p className="small muted" style={{ margin: '4px 0 0' }}>{f.hint}</p>}
                </div>
              ))}
            </div>
            <div className="sb-section" style={{ marginBottom: 12 }}>
              <h3 className="sb-section-title">⭐ Tích điểm & Hạng</h3>
              {LOYALTY_FIELDS.slice(1).map((f) => (
                <div className="field" key={f.key}>
                  <label>{f.label}</label>
                  <input
                    className="input"
                    inputMode="numeric"
                    placeholder={f.placeholder}
                    value={loyaltyVals[f.key] ?? ''}
                    onChange={(e) => setLoyaltyVals((v) => ({ ...v, [f.key]: e.target.value }))}
                  />
                  {f.hint && <p className="small muted" style={{ margin: '4px 0 0' }}>{f.hint}</p>}
                </div>
              ))}
            </div>
            <button
              className="btn btn-block"
              disabled={loyaltySaving}
              onClick={() => {
                setLoyaltySaving(true);
                Promise.all(LOYALTY_FIELDS.map((f) => setSetting(f.key, (loyaltyVals[f.key] ?? '').trim())))
                  .then(() => toast.show('Đã lưu cấu hình ✅'))
                  .catch((e) => toast.show(e instanceof DbError ? e.message : 'Lưu thất bại'))
                  .finally(() => setLoyaltySaving(false));
              }}
            >
              {loyaltySaving ? 'Đang lưu…' : 'Lưu cấu hình'}
            </button>
          </div>
        )}

        <button className="sb-menu-row" onClick={() => toggle('license')}>
          <MenuIcon name="key" fallback="🔑" />
          Giấy phép sử dụng
          <span className="chev">›</span>
        </button>
        {openSection === 'license' && (
          <div style={{ padding: '16px 4px 12px' }}>
            {!license ? (
              <p className="muted">Đang tải…</p>
            ) : (
              <>
                <div className="card" style={{ marginBottom: 12 }}>
                  <div className="small muted">Mã quán (định danh bản deploy này)</div>
                  <div style={{ fontWeight: 800, letterSpacing: 1, fontSize: 16 }}>{tenantId || '…'}</div>
                </div>
                <div className="card" style={{ marginBottom: 12, background: license.valid ? 'var(--green-bg)' : 'var(--red-bg)' }}>
                  <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center' }}>
                    <div style={{ fontWeight: 800, fontSize: 17 }}>Gói {PLAN_LABEL[license.plan]}</div>
                    <span className={`sb-chip${license.valid ? ' selected' : ''}`}>
                      {license.valid ? `Còn ${license.daysLeft} ngày` : 'Hết hạn'}
                    </span>
                  </div>
                  <p className="small muted" style={{ margin: '6px 0 0' }}>
                    Hạn dùng: {license.expires || '—'}
                    <br />
                    Gói Pro mở: đặt hàng online, nhập hàng/NCC, voucher, đa kho.
                  </p>
                </div>
                <div className="field">
                  <label>Nhập mã bản quyền để kích hoạt/gia hạn</label>
                  <input
                    className="input"
                    value={licenseKey}
                    onChange={(e) => setLicenseKey(e.target.value.toUpperCase())}
                    placeholder="BEESY-PRO-20261231-XXXXXXX"
                    style={{ textTransform: 'uppercase', letterSpacing: 1 }}
                  />
                </div>
                <button
                  className="btn btn-block"
                  disabled={licenseBusy || !parseLicenseKey(licenseKey)}
                  onClick={() => {
                    setLicenseBusy(true);
                    activateLicense(licenseKey)
                      .then((l) => {
                        setLicense(l);
                        setLicenseKey('');
                        toast.show('Kích hoạt thành công ✅');
                      })
                      .catch(() => toast.show('Mã không hợp lệ'))
                      .finally(() => setLicenseBusy(false));
                  }}
                >
                  {licenseBusy ? 'Đang kích hoạt…' : 'Kích hoạt'}
                </button>
                <div className="card" style={{ marginTop: 12 }}>
                  <div style={{ fontWeight: 700, marginBottom: 6 }}>🛠️ Tạo mã cho khách (chủ Beesy)</div>
                  <div className="row" style={{ gap: 8 }}>
                    <div className="field" style={{ flex: 1, margin: 0 }}>
                      <label>Gói</label>
                      <select className="input" value={genPlan} onChange={(e) => setGenPlan(e.target.value as LicensePlan)}>
                        <option value="trial">Dùng thử</option>
                        <option value="basic">Cơ bản</option>
                        <option value="pro">Nâng cao (Pro)</option>
                      </select>
                    </div>
                    <div className="field" style={{ flex: 1, margin: 0 }}>
                      <label>Hết hạn</label>
                      <input className="input" type="date" value={genExpiry} onChange={(e) => setGenExpiry(e.target.value)} />
                    </div>
                  </div>
                  <button
                    className="btn btn-outline btn-block"
                    style={{ marginTop: 8 }}
                    disabled={!genExpiry}
                    onClick={() => setGenKey(generateLicenseKey(genPlan, genExpiry))}
                  >
                    Tạo mã
                  </button>
                  {genKey && (
                    <div className="row" style={{ gap: 8, marginTop: 8, alignItems: 'center' }}>
                      <code className="small" style={{ flex: 1, wordBreak: 'break-all' }}>{genKey}</code>
                      <button
                        type="button"
                        className="sb-chip"
                        onClick={() => {
                          navigator.clipboard.writeText(genKey).then(() => toast.show('Đã chép mã')).catch(() => {});
                        }}
                      >
                        📋 Chép
                      </button>
                    </div>
                  )}
                </div>
              </>
            )}
          </div>
        )}


        <button className="sb-menu-row" onClick={() => toggle('payment')}>
          <MenuIcon name="card" fallback="💳" />
          Phương thức thanh toán
          <span className="chev">›</span>
        </button>
        {openSection === 'payment' && (
          <div style={{ padding: '8px 4px 12px' }}>
            <PaymentMethodsManager />
          </div>
        )}

        <button className="sb-menu-row" onClick={() => toggle('notify')}>
          <MenuIcon name="bell" fallback="🔔" />
          Thông báo
          <span className="chev">›</span>
        </button>
        {openSection === 'notify' && (
          <div className="sb-section" style={{ padding: '4px 16px' }}>
            <NotifySettings />
          </div>
        )}
        <button className="sb-menu-row" onClick={() => toggle('backup')}>
          <MenuIcon name="cloud" fallback="☁️" />
          Sao lưu &amp; khôi phục
          <span className="chev">›</span>
        </button>
        {openSection === 'backup' && (
          <div style={{ padding: '16px 4px 12px' }}>
            {driveReady && (
              <>
                <button
                  className="btn btn-block"
                  style={{ marginBottom: 8 }}
                  disabled={driveBusy}
                  onClick={driveBackup}
                >
                  {driveBusy ? 'Đang xử lý…' : 'Sao lưu lên Google Drive'}
                </button>
                <button
                  className="btn btn-outline btn-block"
                  style={{ marginBottom: 12 }}
                  disabled={driveBusy}
                  onClick={openRestore}
                >
                  Khôi phục từ Google Drive
                </button>
                <p className="small muted">
                  Sao lưu &amp; khôi phục hoàn toàn trên trình duyệt (không tốn Cloud Functions).
                  Lần đầu dùng, Google sẽ hỏi cho phép truy cập Drive.
                </p>
                {!showClientIdForm && (
                  <button
                    className="btn btn-outline btn-block"
                    style={{ marginBottom: 4 }}
                    onClick={() => setShowClientIdForm(true)}
                  >
                    🔑 Đổi Google Client ID
                  </button>
                )}
              </>
            )}
            {(!driveReady || showClientIdForm) && (
              <div className="field" style={{ marginTop: driveReady ? 12 : 0 }}>
                <label>Google Client ID</label>
                <input
                  className="input"
                  value={clientIdInput}
                  onChange={(e) => setClientIdInput(e.target.value)}
                  placeholder="xxx.apps.googleusercontent.com"
                  autoComplete="off"
                  autoCapitalize="off"
                  spellCheck={false}
                />
                <p className="small muted" style={{ margin: '6px 0 8px' }}>
                  Lấy Client ID: Google Cloud Console → bật <b>Google Drive API</b> → tạo{' '}
                  <b>OAuth Client ID</b> (loại Web) → thêm địa chỉ web của quán vào{' '}
                  <b>Authorized JavaScript origins</b>. Chi tiết xem README mục “Bật Google Drive backup”.
                </p>
                <button
                  className="btn btn-block"
                  disabled={savingClientId || !clientIdInput.trim()}
                  onClick={saveClientId}
                >
                  {savingClientId ? 'Đang lưu…' : '💾 Lưu Client ID'}
                </button>
              </div>
            )}
            <div className="row" style={{ margin: '16px 0 8px' }}>
              <b className="grow">Sao lưu thủ công</b>
            </div>
            <button className="btn btn-outline btn-block" style={{ marginBottom: 8 }} disabled={backing} onClick={backupJson}>
              Tải toàn bộ dữ liệu (JSON)
            </button>
            <button className="btn btn-outline btn-block" style={{ marginBottom: 8 }} disabled={backing} onClick={pickJsonFile}>
              Khôi phục từ file JSON
            </button>
            {jsonRestore && (
              <div
                className="card"
                style={{ marginBottom: 8, border: '2px solid var(--red)', background: 'var(--red-bg)' }}
              >
                <b style={{ color: 'var(--red)' }}>NGUY HIỂM — xác nhận khôi phục</b>
                <p className="small">
                  Dữ liệu trong file <b>{jsonRestore.name}</b> sẽ được ghi đè lên các bản ghi
                  tương ứng hiện tại. Lưu ý: dữ liệu MỚI phát sinh sau ngày sao lưu (đơn,
                  khách, khoản quỹ…) <b>không bị xóa</b> — sau khôi phục dữ liệu là bản trộn
                  cũ + mới, hãy kiểm tra kỹ. Bộ đếm mã chứng từ giữ số lớn hơn nên không
                  trùng mã. File của quán khác sẽ bị chặn. Không thể hoàn tác!
                </p>
                <p className="small">
                  Để xác nhận, gõ đúng chữ <b>{CONFIRM_WORD}</b> vào ô bên dưới:
                </p>
                <input
                  className="input"
                  value={jsonConfirmText}
                  onChange={(e) => setJsonConfirmText(e.target.value)}
                  placeholder={CONFIRM_WORD}
                  style={{ marginBottom: 10 }}
                />
                <div className="row">
                  <button
                    className="btn"
                    style={{}}
                    disabled={backing || jsonConfirmText !== CONFIRM_WORD}
                    onClick={doJsonRestore}
                  >
                    {backing ? 'Đang khôi phục…' : 'Xác nhận khôi phục'}
                  </button>
                  <button
                    type="button"
                    className="btn btn-ghost"
                    disabled={backing}
                    onClick={() => setJsonRestore(null)}
                  >
                    Hủy
                  </button>
                </div>
              </div>
            )}
            <p className="small muted">Tải từng bảng dạng CSV (tiếng Việt, có header):</p>
            <div className="opt-grid">
              {CSV_TABLES.map((t) => (
                <button key={t.key} className="btn btn-outline" disabled={backing} onClick={() => backupCsv(t.key)}>
                  {t.label}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="sb-section" style={{ padding: '4px 16px' }}>
        {isSuperAdmin(me?.email) && (
          <>
            <button className="sb-menu-row" onClick={() => navigate('/shops')}>
              <MenuIcon name="store" fallback="🏪" />
              Quản lý các quán
              <span className="chev">›</span>
            </button>
            <button className="sb-menu-row" onClick={() => navigate('/setup-shop')}>
              <MenuIcon name="clipboard" fallback="📋" />
              Checklist setup quán mới
              <span className="chev">›</span>
            </button>
          </>
        )}
        <button className="sb-menu-row danger" onClick={handleLogout}>
          <span className="sb-ico-box" style={{ background: '#FDECEC' }}>🚪</span>
          Đăng xuất
          <span className="chev">›</span>
        </button>
      </div>

      {filesOpen && (
        <Sheet title="Khôi phục từ Google Drive" onClose={() => setFilesOpen(false)}>
          {filesLoading ? (
            <div className="muted">Đang tải danh sách file…</div>
          ) : backupFiles.length === 0 ? (
            <div className="muted">Chưa có file sao lưu nào trong thư mục “Beesy POS Backup”.</div>
          ) : (
            backupFiles.map((f) => (
              <div className="sb-row" key={f.id}>
                <span className="rbody">
                  <span className="rtitle">{f.name}</span>
                  <span className="rsub">
                    {formatDriveTime(f.createdTime)} · {formatSize(Number(f.size) || 0)}
                  </span>
                </span>
                <button
                  className="btn btn-outline btn-sm"
                  disabled={driveBusy}
                  onClick={() => {
                    setConfirmTarget(f);
                    setConfirmText('');
                  }}
                >
                  Khôi phục
                </button>
              </div>
            ))
          )}

          {confirmTarget && (
            <div
              className="card"
              style={{ marginTop: 12, border: '2px solid var(--red)', background: 'var(--red-bg)' }}
            >
              <b style={{ color: 'var(--red)' }}>NGUY HIỂM — xác nhận khôi phục</b>
              <p className="small">
                Dữ liệu trong file <b>{confirmTarget.name}</b> sẽ được ghi đè lên các bản ghi
                tương ứng hiện tại. Lưu ý: dữ liệu MỚI phát sinh sau ngày sao lưu (đơn hàng,
                menu, khách hàng, sổ quỹ…) <b>không bị xóa</b> — sau khôi phục dữ liệu là bản
                trộn cũ + mới, hãy kiểm tra kỹ. Bộ đếm mã chứng từ giữ số lớn hơn nên không
                trùng mã. File của quán khác sẽ bị chặn. Không thể hoàn tác!
              </p>
              <p className="small">
                Để xác nhận, gõ đúng chữ <b>{CONFIRM_WORD}</b> vào ô bên dưới:
              </p>
              <input
                className="input"
                value={confirmText}
                onChange={(e) => setConfirmText(e.target.value)}
                placeholder={CONFIRM_WORD}
                style={{ marginBottom: 10 }}
              />
              <div className="row">
                <button
                  className="btn"
                  style={{}}
                  disabled={driveBusy || confirmText !== CONFIRM_WORD}
                  onClick={doRestore}
                >
                  {driveBusy ? 'Đang khôi phục…' : 'Xác nhận khôi phục'}
                </button>
                <button
                  type="button"
                  className="btn btn-ghost"
                  disabled={driveBusy}
                  onClick={() => setConfirmTarget(null)}
                >
                  Hủy
                </button>
              </div>
            </div>
          )}
        </Sheet>
      )}
    </div>
  );
}

// ------------------------------------------------- quản lý phương thức thanh toán ---
function PaymentMethodsManager() {
  const toast = useToast();
  const [methods, setMethods] = useState<PaymentMethodDef[]>([]);
  const [loading, setLoading] = useState(true);
  const [formOpen, setFormOpen] = useState<PaymentMethodDef | 'new' | null>(null);

  const reload = async () => {
    setLoading(true);
    try {
      setMethods(await listPaymentMethods(false));
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tải được phương thức thanh toán');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void reload();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const toggleHide = async (m: PaymentMethodDef, where: 'pos' | 'reports') => {
    try {
      await updatePaymentMethod(m.id, where === 'pos' ? { hide_pos: !m.hide_pos } : { hide_reports: !m.hide_reports });
      await reload();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Cập nhật thất bại');
    }
  };

  const unhide = async (m: PaymentMethodDef) => {
    try {
      await updatePaymentMethod(m.id, { active: true, hide_pos: false, hide_reports: false });
      await reload();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Cập nhật thất bại');
    }
  };

  const remove = async (m: PaymentMethodDef) => {
    if (!window.confirm(`Xóa phương thức “${m.name}”? Đơn hàng cũ không bị ảnh hưởng.`)) return;
    try {
      await deletePaymentMethod(m.id);
      toast.show('Đã xóa phương thức');
      await reload();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Xóa thất bại');
    }
  };

  return (
    <div>
      <div className="row" style={{ marginBottom: 4 }}>
        <b className="grow">Danh sách phương thức</b>
        <button className="btn btn-sm" onClick={() => setFormOpen('new')}>
          Thêm
        </button>
      </div>
      {loading ? (
        <div className="muted">Đang tải…</div>
      ) : methods.length === 0 ? (
        <div className="sb-empty">Chưa có phương thức nào</div>
      ) : (
        <div style={{ marginBottom: 8 }}>
          {methods.map((m) => (
            <div className="sb-row" key={m.id} style={!m.active || (m.hide_pos && m.hide_reports) ? { opacity: 0.5 } : undefined}>
              <span
                className="sb-ico-box"
                style={{ width: 44, height: 44, borderRadius: 12, background: 'var(--gray-bg)' }}
              >
                {m.icon}
              </span>
              <span className="rbody">
                <span className="rtitle">{m.name}</span>
                <span className="rsub">
                  {paymentKindLabel(m.kind)}
                  {m.kind === 'transfer' && m.bank_account ? ` · ${m.bank_account}` : ''}
                  {!m.active ? ' · Đang ẩn' : ''}
                  {m.active && m.hide_pos ? ' · Ẩn ở POS' : ''}
                  {m.active && m.hide_reports ? ' · Ẩn ở Sổ quỹ/Báo cáo' : ''}
                </span>
              </span>
              {!m.active ? (
                <button className="btn btn-ghost btn-sm" onClick={() => unhide(m)}>
                  Hiện
                </button>
              ) : (
                <>
                  <button className="btn btn-ghost btn-sm" onClick={() => toggleHide(m, 'pos')}>
                    {m.hide_pos ? 'Hiện ở POS' : 'Ẩn ở POS'}
                  </button>
                  <button className="btn btn-ghost btn-sm" onClick={() => toggleHide(m, 'reports')}>
                    {m.hide_reports ? 'Hiện ở B.cáo' : 'Ẩn ở B.cáo'}
                  </button>
                </>
              )}
              <button className="btn btn-ghost btn-sm" onClick={() => setFormOpen(m)}>
                Sửa
              </button>
              {!isSystemPaymentMethod(m.id) && (
                <button
                  className="btn btn-ghost btn-sm"
                  onClick={() => remove(m)}
                >
                  Xóa
                </button>
              )}
            </div>
          ))}
        </div>
      )}
      <p className="small muted" style={{ marginBottom: 0 }}>
        Phương thức mặc định (Tiền mặt / Chuyển khoản / Ghi nợ) chỉ Ẩn được, không xóa.
        Ẩn ở POS: không hiện trên bảng thanh toán khi bán hàng.
        Ẩn ở B.cáo: không hiện trong Sổ quỹ, Chốt két và báo cáo (số liệu cũ vẫn giữ nguyên).
        Thông tin ngân hàng của từng phương thức chuyển khoản dùng để sinh mã VietQR khi thanh toán.
      </p>
      {formOpen && (
        <PaymentMethodForm
          method={formOpen === 'new' ? null : formOpen}
          onClose={() => setFormOpen(null)}
          onSaved={() => void reload()}
        />
      )}
    </div>
  );
}

function PaymentMethodForm({ method, onClose, onSaved }: {
  method: PaymentMethodDef | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const toast = useToast();
  const [name, setName] = useState(method?.name ?? '');
  const [kind, setKind] = useState<PaymentMethodKind>(method?.kind ?? 'cash');
  const [icon, setIcon] = useState(method?.icon ?? '💵');
  const [bin, setBin] = useState(method?.bank_bin ?? '');
  const [account, setAccount] = useState(method?.bank_account ?? '');
  const [accountName, setAccountName] = useState(method?.bank_account_name ?? '');
  const [hidePos, setHidePos] = useState(method?.hide_pos ?? false);
  const [hideReports, setHideReports] = useState(method?.hide_reports ?? false);
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      toast.show('Nhập tên phương thức');
      return;
    }
    if (kind === 'transfer' && (!bin.trim() || !account.trim())) {
      toast.show('Chuyển khoản cần nhập mã BIN và số tài khoản để sinh VietQR');
      return;
    }
    setBusy(true);
    try {
      // Chuan hoa BIN khi luu: nhap "Momo"/"VCB" tu doi sang BIN so (971025...)
      // de QR tu sinh dung chuan - dich vu vietqr.io tu hieu ten, app thi khong.
      const resolvedBin = kind === 'transfer' ? resolveVietQRBin(bin) : null;
      const body = {
        name: name.trim(),
        kind,
        icon: icon.trim() || '💳',
        bank_bin: kind === 'transfer' ? (resolvedBin ?? bin.trim()) : null,
        bank_account: kind === 'transfer' ? account.trim() : null,
        bank_account_name: kind === 'transfer' ? accountName.trim() : null,
      };
      if (method) await updatePaymentMethod(method.id, { ...body, hide_pos: hidePos, hide_reports: hideReports });
      else await createPaymentMethod(body);
      toast.show(method ? 'Đã cập nhật' : 'Đã thêm phương thức');
      onSaved();
      onClose();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet title={method ? 'Sửa phương thức' : 'Thêm phương thức'} onClose={onClose}>
      <form onSubmit={submit}>
        <div className="sb-float">
          <label>Tên phương thức <span className="req">*</span></label>
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="VD: Momo, VNPay, Chuyển khoản VCB…" />
        </div>
        <div className="sb-float">
          <label>Loại</label>
          <select value={kind} onChange={(e) => setKind(e.target.value as PaymentMethodKind)}>
            <option value="cash">Tiền mặt (nhập tiền khách đưa, tính thối lại)</option>
            <option value="transfer">Chuyển khoản (hiện mã VietQR)</option>
            <option value="debt">Ghi nợ (cộng vào công nợ khách)</option>
          </select>
        </div>
        <div className="sb-float">
          <label>Biểu tượng</label>
          <input value={icon} onChange={(e) => setIcon(e.target.value)} placeholder="VD: 💵" maxLength={4} />
        </div>
        {kind === 'transfer' && (
          <>
            <div className="sb-float">
              <label>Mã BIN ngân hàng <span className="req">*</span></label>
              <input value={bin} onChange={(e) => setBin(e.target.value)} placeholder="VD: 970422 (MB)" />
            </div>
            <div className="sb-float">
              <label>Số tài khoản <span className="req">*</span></label>
              <input value={account} onChange={(e) => setAccount(e.target.value)} placeholder="VD: 0901234567" />
            </div>
            <div className="sb-float">
              <label>Tên chủ tài khoản</label>
              <input value={accountName} onChange={(e) => setAccountName(e.target.value)} placeholder="VD: BEESY COFFEE" />
            </div>
          </>
        )}
        {method && (
          <>
            <label className="row" style={{ gap: 8, alignItems: 'center', marginBottom: 12 }}>
              <input type="checkbox" checked={hidePos} onChange={(e) => setHidePos(e.target.checked)} />
              <span>Ẩn khỏi bảng thanh toán trong POS</span>
            </label>
            <label className="row" style={{ gap: 8, alignItems: 'center', marginBottom: 12 }}>
              <input type="checkbox" checked={hideReports} onChange={(e) => setHideReports(e.target.checked)} />
              <span>Ẩn khỏi Sổ quỹ, Báo cáo và Chốt két</span>
            </label>
          </>
        )}
        <button type="submit" className="btn btn-block btn-lg" disabled={busy}>
          {busy ? 'Đang lưu…' : 'Lưu'}
        </button>
      </form>
    </Sheet>
  );
}

/** Form thêm/sửa khuyến mãi giờ vàng. */
function ComboTab({
  combos,
  busy,
  proOk,
  onAdd,
  onEdit,
  onDelete,
  onToggle,
}: {
  combos: Combo[];
  busy: boolean;
  proOk: boolean | null;
  onAdd: () => void;
  onEdit: (c: Combo) => void;
  onDelete: (id: string) => void;
  onToggle: (id: string) => void;
}) {
  if (proOk === false) {
    return (
      <div className="card" style={{ textAlign: 'center', padding: '32px 16px' }}>
        <div style={{ fontSize: 44 }}>🔒</div>
        <h3>Tính năng Pro</h3>
        <p className="muted">Combo thuộc gói Nâng cao (Pro).<br />Mở mục <b>Giấy phép sử dụng</b> để kích hoạt.</p>
      </div>
    );
  }
  return (
    <>
      <p className="small muted" style={{ marginTop: 0 }}>
        Gói nhiều món thành 1 combo giá ưu đãi. Khách chọn combo ở POS như 1 món, kho trừ theo định lượng từng món.
      </p>
      {busy ? (
        <div className="muted">Đang tải…</div>
      ) : combos.length === 0 ? (
        <p className="small muted">Chưa có combo nào.</p>
      ) : (
        combos.map((c) => (
          <div className="sb-section" key={c.id} style={{ marginBottom: 10, opacity: c.active ? 1 : 0.6 }}>
            <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ fontWeight: 700 }}>
                🍱 {c.name}{' '}
                <span className="small" style={{ color: 'var(--green)' }}>
                  {c.price.toLocaleString('vi-VN')}đ
                </span>
              </div>
              <label className="switch" style={{ flexShrink: 0 }}>
                <input type="checkbox" checked={c.active} onChange={() => onToggle(c.id)} />
                <span className="track" />
              </label>
            </div>
            <div className="small muted" style={{ margin: '4px 0 8px' }}>
              {c.items.map((it) => `${it.qty}× ${it.product_name}`).join(' + ')}
            </div>
            <div className="row" style={{ gap: 8 }}>
              <button className="btn btn-outline" style={{ minHeight: 40 }} onClick={() => onEdit(c)}>
                Sửa
              </button>
              <button className="btn btn-outline" style={{ minHeight: 40 }} onClick={() => onDelete(c.id)}>
                Xóa
              </button>
            </div>
          </div>
        ))
      )}
      <button className="btn btn-block" onClick={onAdd}>
        ＋ Thêm combo
      </button>
    </>
  );
}

function ComboForm({
  initial,
  onClose,
  onSave,
}: {
  initial: Combo | null;
  onClose: () => void;
  onSave: (c: { id?: string; name: string; price: number; items: ComboItem[] }) => void;
}) {
  const [name, setName] = useState(initial?.name ?? '');
  const [price, setPrice] = useState(initial ? String(initial.price) : '');
  const [items, setItems] = useState<{ product_id: string; qty: string }[]>(
    initial ? initial.items.map((it) => ({ product_id: it.product_id, qty: String(it.qty) })) : [{ product_id: '', qty: '1' }],
  );
  const [products, setProducts] = useState<{ id: string; name: string; base_price: number }[]>([]);

  useEffect(() => {
    listProducts().then((ps) => setProducts(ps.filter((p) => p.active))).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const setItem = (i: number, patch: Partial<(typeof items)[number]>) =>
    setItems((prev) => prev.map((it, j) => (j === i ? { ...it, ...patch } : it)));

  const submit = () => {
    const p = Math.max(0, parseInt(price.replace(/\D/g, ''), 10) || 0);
    if (!name.trim() || p <= 0) return;
    const clean = items
      .filter((it) => it.product_id)
      .map((it) => {
        const prod = products.find((x) => x.id === it.product_id);
        return {
          product_id: it.product_id,
          product_name: prod?.name ?? '',
          qty: Math.max(1, parseInt(it.qty, 10) || 1),
        };
      });
    if (clean.length === 0) return;
    onSave({ id: initial?.id, name: name.trim(), price: p, items: clean });
  };

  const normalTotal = items.reduce((s, it) => {
    const prod = products.find((x) => x.id === it.product_id);
    return s + (prod?.base_price ?? 0) * Math.max(1, parseInt(it.qty, 10) || 1);
  }, 0);

  return (
    <Sheet title={initial ? 'Sửa combo' : 'Thêm combo'} onClose={onClose}>
      <div className="field">
        <label>Tên combo</label>
        <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="VD: Combo 2 người" />
      </div>
      <div className="field">
        <label>Giá combo (đ)</label>
        <input className="input" inputMode="numeric" value={price} onChange={(e) => setPrice(e.target.value)} placeholder="VD: 99000" />
        {normalTotal > 0 && (
          <p className="small muted" style={{ margin: '4px 0 0' }}>
            Giá lẻ tổng: {normalTotal.toLocaleString('vi-VN')}đ
          </p>
        )}
      </div>
      {items.map((it, i) => (
        <div key={i} className="row" style={{ gap: 8, marginBottom: 8 }}>
          <select
            className="input"
            style={{ flex: 3 }}
            value={it.product_id}
            onChange={(e) => setItem(i, { product_id: e.target.value })}
          >
            <option value="">— Chọn món —</option>
            {products.map((prod) => (
              <option key={prod.id} value={prod.id}>
                {prod.name} ({prod.base_price.toLocaleString('vi-VN')}đ)
              </option>
            ))}
          </select>
          <input
            className="input"
            style={{ flex: 1 }}
            inputMode="numeric"
            value={it.qty}
            onChange={(e) => setItem(i, { qty: e.target.value.replace(/\D/g, '') })}
            placeholder="SL"
          />
          <button
            type="button"
            className="btn btn-outline"
            style={{ minHeight: 44 }}
            onClick={() => setItems((prev) => prev.filter((_, j) => j !== i))}
            disabled={items.length === 1}
          >
            ✕
          </button>
        </div>
      ))}
      <button className="btn btn-outline btn-block" style={{ marginBottom: 12 }} onClick={() => setItems((prev) => [...prev, { product_id: '', qty: '1' }])}>
        ＋ Thêm món
      </button>
      <button className="btn btn-block btn-lg" onClick={submit}>
        {initial ? 'Lưu' : 'Tạo combo'}
      </button>
    </Sheet>
  );
}

function VoucherForm({
  initial,
  onClose,
  onSave,
}: {
  initial: Voucher | null;
  onClose: () => void;
  onSave: (v: VoucherInput) => void;
}) {
  const [code, setCode] = useState(initial?.code ?? '');
  const [name, setName] = useState(initial?.name ?? '');
  const [type, setType] = useState<'percent' | 'amount'>(initial?.type ?? 'percent');
  const [value, setValue] = useState(initial ? String(initial.value) : '');
  const [maxDiscount, setMaxDiscount] = useState(initial?.max_discount != null ? String(initial.max_discount) : '');
  const [minOrder, setMinOrder] = useState(initial ? String(initial.min_order) : '');
  const [usageLimit, setUsageLimit] = useState(initial?.usage_limit != null ? String(initial.usage_limit) : '');
  const [startDate, setStartDate] = useState(initial?.start_date ?? '');
  const [endDate, setEndDate] = useState(initial?.end_date ?? '');

  const submit = () => {
    const c = code.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
    const v = Math.max(0, parseInt(value.replace(/\D/g, ''), 10) || 0);
    if (!c || v <= 0) return;
    onSave({
      code: c,
      name: name.trim() || c,
      type,
      value: type === 'percent' ? Math.min(100, v) : v,
      max_discount: maxDiscount.trim() ? Math.max(0, parseInt(maxDiscount.replace(/\D/g, ''), 10) || 0) : null,
      min_order: Math.max(0, parseInt(minOrder.replace(/\D/g, ''), 10) || 0),
      usage_limit: usageLimit.trim() ? Math.max(0, parseInt(usageLimit.replace(/\D/g, ''), 10) || 0) : null,
      start_date: startDate || null,
      end_date: endDate || null,
      active: initial?.active ?? true,
    });
  };

  return (
    <Sheet title={initial ? `Sửa voucher ${initial.code}` : 'Thêm voucher'} onClose={onClose}>
      <div className="field">
        <label>Mã voucher (chữ + số, VD: BEESY20)</label>
        <input
          className="input"
          value={code}
          onChange={(e) => setCode(e.target.value.toUpperCase())}
          placeholder="BEESY20"
          maxLength={20}
          disabled={!!initial}
          style={{ textTransform: 'uppercase', letterSpacing: 1, fontWeight: 700 }}
        />
      </div>
      <div className="field">
        <label>Tên voucher</label>
        <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="VD: Giảm 20% khai trương" />
      </div>
      <div className="field">
        <label>Kiểu giảm</label>
        <div className="row" style={{ gap: 8 }}>
          <button type="button" className={`sb-chip${type === 'percent' ? ' selected' : ''}`} onClick={() => setType('percent')}>
            Giảm %
          </button>
          <button type="button" className={`sb-chip${type === 'amount' ? ' selected' : ''}`} onClick={() => setType('amount')}>
            Giảm tiền
          </button>
          <input
            className="input"
            style={{ width: 110 }}
            inputMode="numeric"
            placeholder="0"
            value={value}
            onChange={(e) => setValue(e.target.value)}
          />
        </div>
      </div>
      {type === 'percent' && (
        <div className="field">
          <label>Trần giảm tối đa (đ, để trống = không trần)</label>
          <input className="input" inputMode="numeric" placeholder="VD: 50000" value={maxDiscount} onChange={(e) => setMaxDiscount(e.target.value)} />
        </div>
      )}
      <div className="field">
        <label>Đơn tối thiểu (đ, để trống = không yêu cầu)</label>
        <input className="input" inputMode="numeric" placeholder="VD: 100000" value={minOrder} onChange={(e) => setMinOrder(e.target.value)} />
      </div>
      <div className="field">
        <label>Giới hạn lượt dùng (để trống = không giới hạn)</label>
        <input className="input" inputMode="numeric" placeholder="VD: 100" value={usageLimit} onChange={(e) => setUsageLimit(e.target.value)} />
      </div>
      <div className="row" style={{ gap: 8 }}>
        <div className="field" style={{ flex: 1 }}>
          <label>Từ ngày</label>
          <input className="input" type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
        </div>
        <div className="field" style={{ flex: 1 }}>
          <label>Đến ngày</label>
          <input className="input" type="date" value={endDate} min={startDate} onChange={(e) => setEndDate(e.target.value)} />
        </div>
      </div>
      <button className="btn btn-block btn-lg" onClick={submit}>
        {initial ? 'Lưu' : 'Tạo voucher'}
      </button>
    </Sheet>
  );
}

function PromoForm({
  initial,
  onClose,
  onSave,
}: {
  initial: Promotion | null;
  onClose: () => void;
  onSave: (p: Promotion) => void;
}) {
  const [name, setName] = useState(initial?.name ?? '');
  const [type, setType] = useState<'percent' | 'amount'>(initial?.type ?? 'percent');
  const [value, setValue] = useState(initial ? String(initial.value) : '');
  const [start, setStart] = useState(initial?.start ?? '14:00');
  const [end, setEnd] = useState(initial?.end ?? '17:00');

  const submit = () => {
    const v = Math.max(0, parseInt(value.replace(/\D/g, ''), 10) || 0);
    if (!name.trim()) return;
    if (v <= 0) return;
    onSave({
      id: initial?.id ?? `promo_${Date.now()}`,
      name: name.trim().slice(0, 100),
      type,
      value: type === 'percent' ? Math.min(100, v) : v,
      start,
      end,
      active: initial?.active ?? true,
    });
  };

  return (
    <Sheet title={initial ? 'Sửa khuyến mãi' : 'Thêm khuyến mãi'} onClose={onClose}>
      <div className="field">
        <label>Tên khuyến mãi</label>
        <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="VD: Giờ vàng chiều" />
      </div>
      <div className="field">
        <label>Kiểu giảm</label>
        <div className="row" style={{ gap: 8 }}>
          <button
            type="button"
            className={`sb-chip${type === 'percent' ? ' selected' : ''}`}
            style={{ minHeight: 40, padding: '4px 16px' }}
            onClick={() => setType('percent')}
          >
            Giảm %
          </button>
          <button
            type="button"
            className={`sb-chip${type === 'amount' ? ' selected' : ''}`}
            style={{ minHeight: 40, padding: '4px 16px' }}
            onClick={() => setType('amount')}
          >
            Giảm tiền
          </button>
          <input
            className="input grow"
            inputMode="numeric"
            placeholder={type === 'percent' ? '% (VD: 10)' : 'Số tiền (VD: 5000)'}
            value={value}
            onChange={(e) => setValue(e.target.value)}
          />
        </div>
      </div>
      <div className="row" style={{ gap: 8 }}>
        <div className="field grow">
          <label>Từ giờ</label>
          <input type="time" className="input" value={start} onChange={(e) => setStart(e.target.value)} />
        </div>
        <div className="field grow">
          <label>Đến giờ</label>
          <input type="time" className="input" value={end} onChange={(e) => setEnd(e.target.value)} />
        </div>
      </div>
      <button className="btn btn-block btn-lg" onClick={submit}>
        Lưu khuyến mãi
      </button>
    </Sheet>
  );
}
