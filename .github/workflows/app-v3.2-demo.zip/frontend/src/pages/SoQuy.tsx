// Sổ quỹ — sổ tiền của quán.
// Gồm khoản THỦ CÔNG (nhập tay) và khoản TỰ ĐỘNG:
//  - đơn đã thu tiền (tiền mặt/chuyển khoản) → "Doanh thu bán hàng" (ghi trong transaction tạo đơn)
//  - thu nợ ở Sổ nợ → "Thu nợ — tên khách"
// Đơn ghi nợ lúc bán chưa thu tiền nên không ghi vào quỹ.
// Đơn cũ trước tính năng tự động không backfill.
import { useNavigate } from 'react-router-dom';
import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  DbError,
  type FundIssue,
  LOCKED_THU_CATS,
  addCashbookEntry,
  deleteCashbookEntry,
  deleteTransferPair,
  updateCashbookEntry,
  getFundCategories,
  getFunds,
  getFundSumsBefore,
  listCashbookEntries,
  getAllowedWarehouses,
  normalizeFundId,
  repairFundIssues,
  saveFundOpening,
  scanFundIssues,
  setFundCategories,
  toLocalDateTimeInput,
  transferFunds,
  exportCashbookCsv,
  downloadFile,
} from '../lib/db';
import { formatDMY, formatTime, formatVND, todayVN, unsignVietnamese, addDaysVN, startOfMonthVN, startOfWeekVN } from '../lib/format';
import { Sheet } from '../components/Sheet';
import { PageHead } from '../components/PageHead';
import { useToast } from '../components/Toast';
import { useAuth } from '../lib/auth';
import type { CashbookEntry, CashbookType, Fund, FundCategories, Warehouse } from '../lib/types';

type FilterKey = 'today' | 'yesterday' | 'week' | 'lastweek' | 'month' | 'lastmonth' | 'custom';
const FILTERS: { key: FilterKey; label: string }[] = [
  { key: 'today', label: 'Hôm nay' },
  { key: 'yesterday', label: 'Hôm qua' },
  { key: 'week', label: 'Tuần này' },
  { key: 'lastweek', label: 'Tuần trước' },
  { key: 'month', label: 'Tháng này' },
  { key: 'lastmonth', label: 'Tháng trước' },
  { key: 'custom', label: 'Tùy chọn' },
];

/** YYYY-MM-DD theo giờ VN từ chuỗi ISO. */
function vnDateKey(iso: string): string {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Ho_Chi_Minh',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date(iso));
}

/** Nhãn ngày kiểu "Thứ Bảy, 10/10" theo giờ VN. */
function vnDayLabel(iso: string): string {
  return new Date(iso).toLocaleDateString('vi-VN', {
    weekday: 'long',
    day: '2-digit',
    month: '2-digit',
    timeZone: 'Asia/Ho_Chi_Minh',
  });
}

export function SoQuy() {
  const toast = useToast();
  const navigate = useNavigate();
  const { can, isOwner } = useAuth();
  const canSettings = can('cashbook.settings');
  const [entries, setEntries] = useState<CashbookEntry[]>([]);
  const [funds, setFunds] = useState<Fund[]>([]);
  const [cats, setCats] = useState<FundCategories>({ thu: ['Bán hàng', 'Thu nợ', 'Khác'], chi: ['Nguyên liệu', 'Mặt bằng', 'Lương', 'Khác'] });
  const [filter, setFilter] = useState<FilterKey>('month');
  const [customFrom, setCustomFrom] = useState(() => todayVN());
  const [customTo, setCustomTo] = useState(() => todayVN());
  const [fundFilter, setFundFilter] = useState<string>('all'); // 'all' hoặc fund.id
  const [typeFilter, setTypeFilter] = useState<'all' | 'thu' | 'chi'>('all'); // lọc thu/chi
  const [catFilter, setCatFilter] = useState<string[]>([]); // [] = mọi hạng mục, ngược lại lọc theo danh sách đã chọn
  const [catOpen, setCatOpen] = useState(false); // mở/đóng dropdown chọn hạng mục
  const [q, setQ] = useState('');
  const [busy, setBusy] = useState(true);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [whFilter, setWhFilter] = useState('all'); // 'all' hoặc warehouse.id
  const [sheet, setSheet] = useState<CashbookType | null>(null);
  const [fundSheet, setFundSheet] = useState<Fund | null>(null); // sửa số dư đầu kỳ của quỹ
  const [transferOpen, setTransferOpen] = useState(false); // sheet chuyển quỹ
  const [catSheet, setCatSheet] = useState(false);
  // Tổng thu/chi TRƯỚC rangeFrom của từng quỹ (dùng aggregate, không giới hạn 500)
  const [openingSums, setOpeningSums] = useState<Map<string, { thu: number; chi: number }>>(new Map());
  const [openingBusy, setOpeningBusy] = useState(false);
  const [detailEntry, setDetailEntry] = useState<CashbookEntry | null>(null); // modal chi tiết khoản
  const [editEntry, setEditEntry] = useState<CashbookEntry | null>(null); // sheet sửa khoản
  const [scanOpen, setScanOpen] = useState(false); // modal rà soát & sửa dữ liệu quỹ
  const [exportBusy, setExportBusy] = useState(false);

  const doExport = async () => {
    setExportBusy(true);
    try {
      const csv = await exportCashbookCsv(rangeFrom, rangeTo, fundFilter, scopeIds, typeFilter, catFilter);
      downloadFile(`beesy-so-quy_${rangeFrom}_${rangeTo}.csv`, csv, 'text/csv;charset=utf-8');
      toast.show('Đã xuất file Excel');
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Xuất file thất bại');
    } finally {
      setExportBusy(false);
    }
  };

  const load = useCallback(async () => {
    setBusy(true);
    try {
      const [list, fl, c, allowed] = await Promise.all([
        listCashbookEntries(500),
        getFunds(),
        getFundCategories(),
        getAllowedWarehouses(),
      ]);
      const ws = allowed.warehouses;
      setEntries(list);
      setFunds(fl);
      setCats(c);
      setWarehouses(ws);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tải được sổ quỹ');
    } finally {
      setBusy(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const t = todayVN();
  const needle = unsignVietnamese(q.trim()).toLowerCase();
  const fundIds = useMemo(() => new Set(funds.map((f) => f.id)), [funds]);
  const activeFunds = useMemo(() => funds.filter((f) => f.active), [funds]);

  // Chuẩn hóa fund_id khoản cũ: 'bank' (bản trước) → id phương thức; id lạ → 'cash'
  const normalized = useMemo(
    () => entries.map((e) => ({ ...e, fund_id: normalizeFundId(e.fund_id, fundIds) })),
    [entries, fundIds],
  );

  // Phạm vi kho được xem: 'all' = mọi kho ĐÃ GÁN (không phải mọi kho hệ thống)
  const scopeIds = useMemo(
    () => (whFilter === 'all' ? warehouses.map((w) => w.id) : [whFilter]),
    [whFilter, warehouses],
  );
  const inScope = useMemo(
    () => (e: { warehouse_id?: string | null }) =>
      scopeIds.length === 0 || !e.warehouse_id || scopeIds.includes(e.warehouse_id),
    [scopeIds],
  );

  // Khoảng ngày theo bộ lọc (YYYY-MM-DD)
  const [rangeFrom, rangeTo] = useMemo(() => {
    switch (filter) {
      case 'today':
        return [t, t];
      case 'yesterday': {
        const y = addDaysVN(t, -1);
        return [y, y];
      }
      case 'week':
        return [startOfWeekVN(t), t];
      case 'lastweek': {
        const mondayThis = startOfWeekVN(t);
        const mondayLast = addDaysVN(mondayThis, -7);
        return [mondayLast, addDaysVN(mondayLast, 6)];
      }
      case 'month':
        return [startOfMonthVN(t), t];
      case 'lastmonth': {
        const firstThis = startOfMonthVN(t);
        const lastPrev = addDaysVN(firstThis, -1);
        return [startOfMonthVN(lastPrev), lastPrev];
      }
      case 'custom':
        return [customFrom <= customTo ? customFrom : customTo, customFrom <= customTo ? customTo : customFrom];
    }
  }, [filter, t, customFrom, customTo]);

  // Tải tổng thu/chi TRƯỚC rangeFrom cho từng quỹ (aggregate — chính xác dù có hàng chục nghìn khoản)
  const [openingError, setOpeningError] = useState(false);
  useEffect(() => {
    let cancelled = false;
    const cutoffIso = new Date(`${rangeFrom}T00:00:00+07:00`).toISOString();
    setOpeningBusy(true);
    setOpeningError(false);
    Promise.all(
      activeFunds.map(async (f) => {
        try {
          const s = await getFundSumsBefore(cutoffIso, f.id, scopeIds);
          return [f.id, s] as const;
        } catch {
          return [f.id, null] as const; // lỗi (VD: index chưa build xong) → fallback bên dưới
        }
      }),
    )
      .then((rs) => {
        if (cancelled) return;
        const m = new Map<string, { thu: number; chi: number }>();
        let failed = false;
        for (const [id, s] of rs) {
          if (s) m.set(id, s);
          else failed = true;
        }
        setOpeningSums(m);
        setOpeningError(failed);
      })
      .finally(() => {
        if (!cancelled) setOpeningBusy(false);
      });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rangeFrom, activeFunds, scopeIds.join(',')]);

  // Danh sách hạng mục để lọc: từ cài đặt + các hạng mục thực tế có trong dữ liệu
  const allCats = useMemo(() => {
    const s = new Set<string>();
    for (const c of cats.thu) s.add(c);
    for (const c of cats.chi) s.add(c);
    for (const e of normalized) if (e.category) s.add(e.category);
    return [...s].sort((a, b) => a.localeCompare(b, 'vi'));
  }, [cats, normalized]);

  const filtered = useMemo(
    () =>
      normalized.filter((e) => {
        if (fundFilter !== 'all' && e.fund_id !== fundFilter) return false;
        if (typeFilter !== 'all' && e.type !== typeFilter) return false;
        if (catFilter.length > 0 && !catFilter.includes(e.category)) return false;
        if (!inScope(e)) return false;
        const k = vnDateKey(e.created_at);
        if (k < rangeFrom || k > rangeTo) return false;
        if (needle) {
          const hay = unsignVietnamese(
            `${e.category} ${e.note ?? ''} ${e.amount} ${formatTime(e.created_at)}`,
          ).toLowerCase();
          if (!hay.includes(needle)) return false;
        }
        return true;
      }),
    [normalized, fundFilter, typeFilter, catFilter, rangeFrom, rangeTo, needle, inScope],
  );

  // Số dư từng quỹ = số dư đầu kỳ + Σ thu − Σ chi của quỹ đó
  // (tính trên 500 khoản mới nhất — đủ cho quán nhỏ)
  const whEntries = useMemo(() => normalized.filter(inScope), [normalized, inScope]);
  // Số dư đầu kỳ hiển thị = tổng số dư đầu kỳ các kho trong phạm vi
  const openingDisplay = (f: Fund) =>
    scopeIds.length === 0
      ? f.opening_balance
      : scopeIds.reduce((sum, wid) => sum + (f.opening_by_warehouse?.[wid]?.opening_balance ?? 0), 0);
  // Đầu kỳ / Cuối kỳ theo khoảng ngày đang lọc (không bị ảnh hưởng bởi ô tìm kiếm):
  // Đầu kỳ = số dư đầu kỳ cài đặt + Σ thu/chi TRƯỚC rangeFrom (dùng aggregate — chính xác
  //   dù có hàng chục nghìn khoản; nếu aggregate lỗi thì fallback cộng từ 500 khoản đã tải)
  // Cuối kỳ = Đầu kỳ + Σ thu/chi trong [rangeFrom, rangeTo]
  // Chuyển quỹ nội bộ (ref_type='transfer') KHÔNG tính vào Tổng thu/chi chung khi xem "Tất cả quỹ"
  //   (tiền chỉ chạy nội bộ, không phải thu/chi thực) — nhưng vẫn tính vào từng quỹ.
  const periodStats = useMemo(() => {
    let opening = 0;
    let thu = 0;
    let chi = 0;
    const perFund = new Map<string, { opening: number; closing: number }>();
    const fundsInScope =
      fundFilter === 'all' ? activeFunds : activeFunds.filter((f) => f.id === fundFilter);
    const activeIds = new Set(activeFunds.map((f) => f.id));
    // Quỹ nào đã có số liệu aggregate → không cộng fallback từ 500 khoản đã tải
    const aggOk = new Set<string>();
    for (const f of fundsInScope) {
      const o = openingDisplay(f);
      const s = openingSums.get(f.id);
      const before = s ? s.thu - s.chi : 0;
      if (s) aggOk.add(f.id);
      opening += o + before;
      perFund.set(f.id, { opening: o + before, closing: o + before });
    }
    for (const e of whEntries) {
      if (fundFilter !== 'all' && e.fund_id !== fundFilter) continue;
      // BUG 5: bỏ qua khoản của quỹ đã ẩn khỏi tổng chung cho nhất quán với hiển thị
      if (!activeIds.has(e.fund_id)) continue;
      const k = vnDateKey(e.created_at);
      const net = e.type === 'thu' ? e.amount : -e.amount;
      const pf = perFund.get(e.fund_id);
      const isTransfer = e.ref_type === 'transfer';
      if (k < rangeFrom) {
        // Chỉ cộng fallback khi aggregate lỗi (không có số liệu cho quỹ này)
        if (pf && !aggOk.has(e.fund_id)) {
          opening += net;
          pf.opening += net;
          pf.closing += net;
        }
      } else if (k <= rangeTo) {
        // BUG 2: chuyển quỹ nội bộ không tính vào Tổng thu/chi khi xem tất cả quỹ
        if (!(isTransfer && fundFilter === 'all')) {
          if (e.type === 'thu') thu += e.amount;
          else chi += e.amount;
        }
        if (pf) pf.closing += net;
      }
    }
    return { opening, thu, chi, closing: opening + thu - chi, perFund };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeFunds, fundFilter, whEntries, rangeFrom, rangeTo, openingSums]);

  const delEntry = async (e: CashbookEntry) => {
    const isTransfer = e.ref_type === 'transfer' && !!e.ref_id;
    // Khoản tự động (từ đơn / thu nợ KH / trả nợ NCC) không xóa lẻ —
    // phải xử lý nghiệp vụ gốc để công nợ và sổ quỹ không lệch nhau
    if (e.ref_type === 'order' || e.ref_type === 'debt_pay' || e.ref_type === 'supplier_pay') {
      toast.show('Khoản tự động không xóa lẻ được. Hãy xử lý ở nghiệp vụ gốc (đơn hàng / sổ nợ / NCC).');
      return;
    }
    try {
      if (isTransfer) {
        // BUG 4: khoản chuyển quỹ là 1 cặp — CHỈ cho xóa cả cặp, không cho xóa lẻ 1 vế
        // (xóa lẻ sẽ tạo tiền từ không khí hoặc làm mất tiền)
        if (window.confirm(`Xóa cả cặp chuyển quỹ ${formatVND(e.amount)} (1 khoản chi + 1 khoản thu)?`)) {
          await deleteTransferPair(e.id);
          toast.show('Đã xóa cặp chuyển quỹ');
          void load();
        }
        return;
      }
      if (!window.confirm(`Xóa khoản ${e.type === 'thu' ? 'thu' : 'chi'} ${formatVND(e.amount)}${e.note ? ` — ${e.note}` : ''}?`))
        return;
      await deleteCashbookEntry(e.id);
      toast.show('Đã xóa khoản');
      void load();
    } catch (err) {
      toast.show(err instanceof DbError ? err.message : 'Xóa thất bại');
    }
  };

  const groups = useMemo(() => {
    const m = new Map<string, CashbookEntry[]>();
    for (const e of filtered) {
      const k = vnDateKey(e.created_at);
      if (!m.has(k)) m.set(k, []);
      m.get(k)!.push(e);
    }
    return [...m.entries()].sort((a, b) => (a[0] < b[0] ? 1 : -1));
  }, [filtered]);

  return (
    <div className="page with-dual-actions">
      <PageHead title="Sổ quỹ" back />

      <div className="sb-search" style={{ marginBottom: 12 }}>
        <span className="sico">🔍</span>
        <input
          placeholder="Tìm ghi chú, số tiền…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          aria-label="Tìm khoản thu chi"
        />
      </div>

      <div className="row" style={{ gap: 8, marginBottom: 12, flexWrap: 'wrap' }}>
        {/* Tab tách riêng Thu / Chi */}
        <div className="seg" role="tablist" aria-label="Lọc thu chi" style={{ flex: '1 1 auto' }}>
          {(
            [
              ['all', 'Tất cả'],
              ['thu', '↓ Thu'],
              ['chi', '↑ Chi'],
            ] as const
          ).map(([v, label]) => (
            <button
              key={v}
              type="button"
              role="tab"
              aria-selected={typeFilter === v}
              className={`seg-btn${typeFilter === v ? ' active' : ''}`}
              onClick={() => setTypeFilter(v)}
            >
              {label}
            </button>
          ))}
        </div>
        <div style={{ position: 'relative', flex: '1 1 130px', minWidth: 0 }}>
          <button
            type="button"
            className="input"
            style={{ width: '100%', textAlign: 'left', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}
            onClick={() => setCatOpen((v) => !v)}
            aria-label="Lọc theo hạng mục"
            aria-expanded={catOpen}
          >
            {catFilter.length === 0 ? 'Mọi hạng mục' : `${catFilter.length} hạng mục`}
          </button>
          {catOpen && (
            <div
              className="card"
              style={{
                position: 'absolute', top: '100%', left: 0, right: 0, zIndex: 50,
                marginTop: 4, padding: 8, maxHeight: 240, overflowY: 'auto',
              }}
            >
              <label className="row" style={{ gap: 8, padding: '6px 4px', cursor: 'pointer' }}>
                <input
                  type="checkbox"
                  checked={catFilter.length === 0}
                  onChange={() => setCatFilter([])}
                />
                <span style={{ fontWeight: 600 }}>Mọi hạng mục</span>
              </label>
              {allCats.map((c) => (
                <label key={c} className="row" style={{ gap: 8, padding: '6px 4px', cursor: 'pointer' }}>
                  <input
                    type="checkbox"
                    checked={catFilter.includes(c)}
                    onChange={() => {
                      setCatFilter((prev) =>
                        prev.includes(c) ? prev.filter((x) => x !== c) : [...prev, c],
                      );
                    }}
                  />
                  <span>{c}</span>
                </label>
              ))}
            </div>
          )}
        </div>
        <select
          className="input"
          style={{ flex: '1 1 130px', minWidth: 0 }}
          value={filter}
          onChange={(e) => setFilter(e.target.value as FilterKey)}
          aria-label="Lọc theo thời gian"
        >
          {FILTERS.map((f) => (
            <option key={f.key} value={f.key}>
              {f.label}
            </option>
          ))}
        </select>
        {activeFunds.length > 1 && (
          <select
            className="input"
            style={{ flex: '1 1 130px', minWidth: 0 }}
            value={fundFilter}
            onChange={(e) => setFundFilter(e.target.value)}
            aria-label="Lọc theo quỹ"
          >
            <option value="all">Tất cả quỹ</option>
            {activeFunds.map((f) => (
              <option key={f.id} value={f.id}>
                {f.name}
              </option>
            ))}
          </select>
        )}
        {warehouses.length > 1 && (
          <select
            className="input"
            style={{ flex: '1 1 130px', minWidth: 0 }}
            value={whFilter}
            onChange={(e) => setWhFilter(e.target.value)}
            aria-label="Lọc theo kho"
          >
            <option value="all">Mọi kho</option>
            {warehouses.map((w) => (
              <option key={w.id} value={w.id}>
                {w.name}
              </option>
            ))}
          </select>
        )}
        {canSettings && (
          <button className="btn" style={{ flex: '0 0 auto' }} onClick={() => setTransferOpen(true)} aria-label="Chuyển tiền giữa các quỹ">
            🔄 Chuyển quỹ
          </button>
        )}
        {canSettings && (
          <button className="btn" style={{ flex: '0 0 auto' }} onClick={() => setCatSheet(true)} aria-label="Quản lý danh mục thu chi">
            ⚙ Danh mục
          </button>
        )}
        {isOwner && (
          <button className="btn" style={{ flex: '0 0 auto' }} onClick={() => setScanOpen(true)} aria-label="Rà soát và sửa dữ liệu quỹ">
            🔧 Rà soát
          </button>
        )}
        <button className="btn" style={{ flex: '0 0 auto' }} disabled={exportBusy} onClick={() => void doExport()} aria-label="Xuất sổ quỹ ra Excel">
          {exportBusy ? 'Đang xuất…' : '⬇ Excel'}
        </button>
      </div>
      {filter === 'custom' && (
        <div className="row" style={{ gap: 8, marginBottom: 12, alignItems: 'center', flexWrap: 'wrap' }}>
          <span className="small muted">Từ ngày</span>
          <input
            type="date"
            className="input"
            style={{ width: 'auto' }}
            value={customFrom}
            max={customTo}
            onChange={(e) => e.target.value && setCustomFrom(e.target.value)}
            aria-label="Từ ngày"
          />
          <span className="small muted">đến</span>
          <input
            type="date"
            className="input"
            style={{ width: 'auto' }}
            value={customTo}
            min={customFrom}
            onChange={(e) => e.target.value && setCustomTo(e.target.value)}
            aria-label="Đến ngày"
          />
        </div>
      )}

      {/* Số dư quỹ */}
      <div className="sb-section" style={{ marginBottom: 12 }}>
        <div style={{ textAlign: 'center' }}>
          <div className="small muted">
            {fundFilter === 'all'
              ? 'Sổ quỹ'
              : (activeFunds.find((f) => f.id === fundFilter)?.name ?? 'Quỹ')}
            {' · '}
            {formatDMY(rangeFrom)} → {formatDMY(rangeTo)}
            {openingBusy && <span> · đang tính…</span>}
            {openingError && (
              <div className="small" style={{ color: '#b45309', marginTop: 4 }}>
                ⚠️ Không tính được số dư đầu kỳ chính xác (đang dùng số tạm từ 500 khoản mới nhất).
                Thử tải lại trang sau vài phút.
              </div>
            )}
          </div>
          <div className="row" style={{ gap: 12, marginTop: 8 }}>
            <div className="grow">
              <div className="small muted">Đầu kỳ</div>
              <div className="money" style={{ fontSize: 24, margin: '4px 0' }}>
                {formatVND(periodStats.opening)}
              </div>
            </div>
            <div className="grow">
              <div className="small muted">Cuối kỳ</div>
              <div className="money text-green" style={{ fontSize: 24, margin: '4px 0' }}>
                {formatVND(periodStats.closing)}
              </div>
            </div>
          </div>
        </div>
        <div style={{ marginTop: 4 }}>
          {activeFunds.map((f) => (
            <div
              key={f.id}
              className="row"
              style={{
                justifyContent: 'space-between',
                alignItems: 'center',
                padding: '10px 0',
                borderTop: '1px solid var(--line)',
              }}
            >
              <div>
                <div style={{ fontWeight: 600 }}>{f.name}</div>
                <div className="small" style={{ marginTop: 2 }}>
                  Đầu kỳ:{' '}
                  <b className="money">{formatVND(periodStats.perFund.get(f.id)?.opening ?? 0)}</b>
                  {' → '}
                  Cuối kỳ:{' '}
                  <b className="money">{formatVND(periodStats.perFund.get(f.id)?.closing ?? 0)}</b>
                </div>
                <button
                  type="button"
                  className="small muted"
                  style={{
                    background: 'none',
                    border: 'none',
                    padding: '4px 0',
                    minHeight: 28,
                  }}
                  onClick={() => {
                    if (!canSettings) {
                      toast.show('Chỉ chủ quán mới được sửa số dư ban đầu');
                      return;
                    }
                    setFundSheet(f);
                  }}
                >
                  Số dư ban đầu: {formatVND(openingDisplay(f))}
                  {canSettings ? ' · Sửa ›' : ''}
                </button>
              </div>
            </div>
          ))}
        </div>
        <p className="small muted" style={{ textAlign: 'center', marginTop: 8 }}>
          Mỗi phương thức thanh toán (trừ Ghi nợ) là một quỹ — thêm/sửa phương thức ở Cài đặt.
        </p>
      </div>

      <div className="sb-section" style={{ marginBottom: 12 }}>
        <div className="row" style={{ justifyContent: 'space-between', marginBottom: 10 }}>
          <span className="muted">Chênh lệch (kỳ lọc)</span>
          <b className="money" style={{ fontSize: 22 }}>
            {formatVND(periodStats.thu - periodStats.chi)}
          </b>
        </div>
        <div className="row" style={{ gap: 12 }}>
          <div className="card pastel-green grow" style={{ boxShadow: 'none' }}>
            <div className="small muted">Tổng thu</div>
            <div className="money text-green" style={{ fontSize: 20 }}>
              {formatVND(periodStats.thu)}
            </div>
          </div>
          <div className="card pastel-yellow grow" style={{ boxShadow: 'none' }}>
            <div className="small muted">Tổng chi</div>
            <div className="money text-orange" style={{ fontSize: 20 }}>
              {formatVND(periodStats.chi)}
            </div>
          </div>
        </div>
      </div>

      {busy ? (
        <div className="sb-section muted" style={{ textAlign: 'center' }}>
          Đang tải…
        </div>
      ) : groups.length === 0 ? (
        <div className="sb-section">
          <div className="sb-empty">
            <div className="eico">💸</div>
            <p>
              Chưa có khoản thu chi nào.
              <br />
              Đơn đã thu tiền và thu nợ sẽ tự ghi vào đây.
            </p>
          </div>
        </div>
      ) : (
        groups.map(([day, list]) => (
          <div className="sb-day-group" key={day}>
            <div className="sb-day-label">{vnDayLabel(list[0].created_at)}</div>
            <div className="sb-section" style={{ padding: '4px 16px' }}>
              {list.map((e) => {
                // Bấm vào dòng → mở chi tiết khoản
                const isTransferRow = e.ref_type === 'transfer';
                const inner = (
                  <>
                    <span
                      className="avatar"
                      style={
                        isTransferRow
                          ? { background: 'var(--brand-bg, #e8f5e9)', color: 'var(--brand-dark)' }
                          : e.type === 'thu'
                            ? { background: 'var(--green-bg)', color: 'var(--brand-dark)' }
                            : { background: 'var(--orange-bg)', color: 'var(--orange)' }
                      }
                    >
                      {isTransferRow ? '🔄' : e.type === 'thu' ? '↓' : '↑'}
                    </span>
                    <span className="rbody">
                      <span className="rtitle">
                        {e.note || e.category}
                        {e.ref_type !== 'manual' && (
                          <span className="sb-status-pill" style={{ marginLeft: 6, fontSize: 11 }}>
                            Tự động
                          </span>
                        )}
                      </span>
                      <span className="rsub">
                        {e.code ? `${e.code} · ` : e.ref_type === 'order' && e.ref_code ? `Đơn ${e.ref_code} · ` : ''}
                        {fundFilter === 'all' && activeFunds.length > 1
                          ? `${funds.find((f) => f.id === e.fund_id)?.name ?? ''} · `
                          : ''}
                        {whFilter === 'all' && warehouses.length > 1 && e.warehouse_id
                          ? `${warehouses.find((w) => w.id === e.warehouse_id)?.name ?? ''} · `
                          : ''}
                        {e.note ? `${e.category} · ` : ''}
                        {formatTime(e.created_at)}
                      </span>
                    </span>
                    <span className={`ramount ${e.type === 'thu' ? 'text-green' : 'text-orange'}`}>
                      {e.type === 'thu' ? '+' : '−'}
                      {formatVND(e.amount)}
                    </span>
                    <span className="chev muted" style={{ fontSize: 22 }}>
                      ›
                    </span>
                  </>
                );
                const delBtn = canSettings ? (
                  <button
                    type="button"
                    className="sb-row-del"
                    aria-label="Xóa khoản này"
                    onClick={(ev) => {
                      ev.stopPropagation();
                      void delEntry(e);
                    }}
                  >
                    ×
                  </button>
                ) : null;
                const rowPad = canSettings ? { paddingRight: 42 } : undefined;
                return (
                  <div key={e.id} style={{ position: 'relative' }}>
                    <button
                      className="sb-row"
                      style={{
                        ...rowPad,
                        width: '100%',
                        textAlign: 'left',
                        ...(isTransferRow ? { background: 'var(--brand-bg, #f1f8f1)' } : undefined),
                      }}
                      onClick={() => setDetailEntry(e)}
                    >
                      {inner}
                    </button>
                    {delBtn}
                  </div>
                );
              })}
            </div>
          </div>
        ))
      )}

      <div className="sb-dual-actions">
        <div className="inner" style={{ justifyContent: 'flex-end' }}>
          <button className="btn btn-sm" onClick={() => setSheet('chi')}>
            − Tạo chi
          </button>
          <button className="btn btn-sm" onClick={() => setSheet('thu')}>
            + Tạo thu
          </button>
        </div>
      </div>

      {sheet && (
        <FundEntrySheet
          type={sheet}
          cats={sheet === 'thu' ? cats.thu : cats.chi}
          funds={activeFunds}
          warehouses={warehouses}
          defaultFundId={fundFilter !== 'all' ? fundFilter : undefined}
          defaultWarehouseId={whFilter}
          canManageCats={canSettings}
          onManageCats={() => {
            setSheet(null);
            setCatSheet(true);
          }}
          onClose={() => setSheet(null)}
          onDone={() => {
            setSheet(null);
            void load();
          }}
        />
      )}

      {catSheet && (
        <FundCategorySheet
          cats={cats}
          onClose={() => setCatSheet(false)}
          onDone={(c) => {
            setCats(c);
            setCatSheet(false);
          }}
        />
      )}

      {fundSheet && (
        <FundSheet
          fund={fundSheet}
          warehouses={warehouses}
          defaultWarehouseId={whFilter}
          onClose={() => setFundSheet(null)}
          onDone={(fl) => {
            setFunds(fl);
            setFundSheet(null);
          }}
        />
      )}

      {transferOpen && (
        <TransferSheet
          funds={activeFunds}
          warehouses={warehouses}
          defaultWarehouseId={whFilter}
          onClose={() => setTransferOpen(false)}
          onDone={() => {
            setTransferOpen(false);
            void load();
          }}
        />
      )}

      {detailEntry && (
        <EntryDetailSheet
          entry={detailEntry}
          funds={funds}
          warehouses={warehouses}
          canEdit={canSettings}
          onClose={() => setDetailEntry(null)}
          onEdit={() => {
            setEditEntry(detailEntry);
            setDetailEntry(null);
          }}
          onDelete={async () => {
            await delEntry(detailEntry);
            setDetailEntry(null);
          }}
          onOpenOrder={() => {
            const rid = detailEntry.ref_id;
            setDetailEntry(null);
            navigate(`/orders?open=${rid}`);
          }}
          onOpenDoc={(refType, refId) => {
            setDetailEntry(null);
            if (refType === 'purchase' || refType === 'stock_export') {
              navigate(`/nhap-hang?open=${refId}`);
            } else if (refType === 'production') {
              navigate(`/inventory?tab=production`);
            }
          }}
        />
      )}

      {editEntry && (
        <EntryEditSheet
          entry={editEntry}
          cats={editEntry.type === 'thu' ? cats.thu : cats.chi}
          funds={activeFunds}
          onClose={() => setEditEntry(null)}
          onDone={() => {
            setEditEntry(null);
            void load();
          }}
        />
      )}
      {scanOpen && (
        <FundScanSheet
          onClose={() => setScanOpen(false)}
          onDone={() => {
            setScanOpen(false);
            void load();
          }}
        />
      )}
    </div>
  );
}

function FundSheet({
  fund,
  warehouses,
  defaultWarehouseId,
  onClose,
  onDone,
}: {
  fund: Fund;
  warehouses: Warehouse[];
  defaultWarehouseId?: string;
  onClose: () => void;
  onDone: (fl: Fund[]) => void;
}) {
  const toast = useToast();
  const [whId, setWhId] = useState(
    defaultWarehouseId && defaultWarehouseId !== 'all'
      ? defaultWarehouseId
      : Object.keys(fund.opening_by_warehouse)[0] ?? warehouses.find((w) => w.is_default)?.id ?? warehouses[0]?.id ?? '',
  );
  const opening = whId ? fund.opening_by_warehouse?.[whId] : undefined;
  const [balance, setBalance] = useState(String(opening?.opening_balance ?? fund.opening_balance));
  const [date, setDate] = useState(opening?.opening_date ?? fund.opening_date);
  const [busy, setBusy] = useState(false);

  const pickWarehouse = (id: string) => {
    setWhId(id);
    const o = fund.opening_by_warehouse?.[id];
    setBalance(String(o?.opening_balance ?? 0));
    setDate(o?.opening_date ?? todayVN());
  };

  const submit = async () => {
    const v = parseInt(balance.replace(/\D/g, ''), 10);
    if (!Number.isFinite(v) || v < 0) {
      toast.show('Nhập số dư hợp lệ');
      return;
    }
    setBusy(true);
    try {
      const fl = await saveFundOpening(fund.id, v, date, whId);
      toast.show(`Đã cập nhật số dư đầu kỳ quỹ ${fund.name}`);
      onDone(fl);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet
      title={`Số dư đầu kỳ — ${fund.name}`}
      onClose={onClose}

      footer={
        <button className="btn btn-block btn-lg" disabled={busy} onClick={submit}>
          {busy ? 'Đang lưu…' : 'Lưu'}
        </button>
      }
    >
      {warehouses.length > 1 && (
        <div className="field">
          <label>Kho</label>
          <div className="row" style={{ flexWrap: 'wrap', gap: 8 }}>
            {warehouses.map((w) => (
              <button
                key={w.id}
                type="button"
                className={`sb-chip${whId === w.id ? ' selected' : ''}`}
                onClick={() => pickWarehouse(w.id)}
              >
                {w.name}
              </button>
            ))}
          </div>
        </div>
      )}
      <div className="field">
        <label>Số dư đầu kỳ{warehouses.length > 1 && whId ? ` — ${warehouses.find((w) => w.id === whId)?.name ?? ''}` : ''}</label>
        <input
          className="sb-money-input"
          inputMode="numeric"
          value={balance}
          onChange={(e) => setBalance(e.target.value)}
          placeholder="0"
        />
      </div>
      <div className="field">
        <label>Tính từ ngày</label>
        <input
          type="date"
          className="input"
          value={date}
          max={todayVN()}
          onChange={(e) => setDate(e.target.value)}
        />
      </div>
      <p className="small muted">
        Số dư quỹ = số dư đầu kỳ + tổng thu − tổng chi của quỹ đó. Đơn {fund.name} tự động ghi
        vào quỹ này.
      </p>
    </Sheet>
  );
}

function FundEntrySheet({
  type,
  cats,
  funds,
  warehouses,
  defaultFundId,
  defaultWarehouseId,
  canManageCats,
  onManageCats,
  onClose,
  onDone,
}: {
  type: CashbookType;
  cats: string[];
  funds: Fund[];
  warehouses: Warehouse[];
  defaultFundId?: string;
  defaultWarehouseId?: string;
  canManageCats: boolean;
  onManageCats: () => void;
  onClose: () => void;
  onDone: () => void;
}) {
  const toast = useToast();
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [category, setCategory] = useState(cats[0] ?? 'Khác');
  const [fundId, setFundId] = useState(
    funds.some((f) => f.id === defaultFundId) ? (defaultFundId as string) : (funds[0]?.id ?? 'cash'),
  );
  const [whId, setWhId] = useState(
    defaultWarehouseId && defaultWarehouseId !== 'all'
      ? defaultWarehouseId
      : warehouses.find((w) => w.is_default)?.id ?? warehouses[0]?.id ?? '',
  );
  const [occurredAt, setOccurredAt] = useState(() => toLocalDateTimeInput());
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    const v = parseInt(amount.replace(/\D/g, ''), 10);
    if (!v || v <= 0) {
      toast.show('Nhập số tiền hợp lệ');
      return;
    }
    setBusy(true);
    try {
      await addCashbookEntry(type, v, note.trim() || null, category, {
        fundId,
        method: funds.find((f) => f.id === fundId)?.kind === 'transfer' ? 'transfer' : 'cash',
        warehouseId: whId || null,
        occurredAt: occurredAt ? new Date(occurredAt).toISOString() : null,
      });
      toast.show(
        type === 'thu' ? `Đã ghi khoản thu ${formatVND(v)}` : `Đã ghi khoản chi ${formatVND(v)}`,
      );
      onDone();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet
      title={type === 'thu' ? 'Khoản thu' : 'Khoản chi'}
      onClose={onClose}
      footer={
        <button
          className={`btn btn-block btn-lg${type === 'chi' ? ' btn' : ''}`}
          disabled={busy}
          onClick={submit}
        >
          {busy ? 'Đang lưu…' : 'Lưu'}
        </button>
      }
    >
      <div className="field">
        <label>Số tiền</label>
        <input
          className="sb-money-input"
          inputMode="numeric"
          placeholder="0"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          autoFocus
        />
      </div>
      <div className="field">
        <label>Quỹ</label>
        <div className="row" style={{ flexWrap: 'wrap', gap: 8 }}>
          {funds.map((f) => (
            <button
              key={f.id}
              type="button"
              className={`sb-chip${fundId === f.id ? ' selected' : ''}`}
              onClick={() => setFundId(f.id)}
            >
              {f.name}
            </button>
          ))}
        </div>
      </div>
      <div className="field">
        <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center' }}>
          <label style={{ margin: 0 }}>Danh mục</label>
          {canManageCats && (
            <button
              type="button"
              className="small"
              style={{ color: 'var(--brand-dark)', fontWeight: 600, background: 'none', border: 'none', padding: 4, minHeight: 32 }}
              onClick={onManageCats}
            >
              Quản lý ›
            </button>
          )}
        </div>
        <div className="row" style={{ flexWrap: 'wrap', gap: 8 }}>
          {cats.map((c) => (
            <button
              key={c}
              type="button"
              className={`sb-chip${category === c ? ' selected' : ''}`}
              onClick={() => setCategory(c)}
            >
              {c}
            </button>
          ))}
        </div>
      </div>
      <div className="field">
        <label>🕐 Thời gian</label>
        <input
          type="datetime-local"
          className="input"
          value={occurredAt}
          onChange={(e) => setOccurredAt(e.target.value)}
        />
      </div>
      {warehouses.length > 1 && (
        <div className="field">
          <label>Kho</label>
          <div className="row" style={{ flexWrap: 'wrap', gap: 8 }}>
            {warehouses.map((w) => (
              <button
                key={w.id}
                type="button"
                className={`sb-chip${whId === w.id ? ' selected' : ''}`}
                onClick={() => setWhId(w.id)}
              >
                {w.name}
              </button>
            ))}
          </div>
        </div>
      )}
      <div className="field">
        <label>Ghi chú (không bắt buộc)</label>
        <input
          className="input"
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="VD: nhập sữa tươi…"
        />
      </div>
    </Sheet>
  );
}

/** Sheet chuyển tiền từ quỹ này sang quỹ khác — chỉ chủ quán. */
function TransferSheet({
  funds,
  warehouses,
  defaultWarehouseId,
  onClose,
  onDone,
}: {
  funds: Fund[];
  warehouses: Warehouse[];
  defaultWarehouseId?: string;
  onClose: () => void;
  onDone: () => void;
}) {
  const toast = useToast();
  const [fromId, setFromId] = useState(funds[0]?.id ?? '');
  const [toId, setToId] = useState(funds[1]?.id ?? funds[0]?.id ?? '');
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [date, setDate] = useState(() => todayVN());
  const [whId, setWhId] = useState(
    defaultWarehouseId && defaultWarehouseId !== 'all'
      ? defaultWarehouseId
      : warehouses.find((w) => w.is_default)?.id ?? warehouses[0]?.id ?? '',
  );
  const [busy, setBusy] = useState(false);

  const toOptions = funds.filter((f) => f.id !== fromId);
  // Nếu quỹ đích đang chọn trùng quỹ nguồn (do đổi nguồn), tự chuyển sang quỹ khác
  useEffect(() => {
    if (toId === fromId) {
      setToId(toOptions[0]?.id ?? '');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fromId]);

  const submit = async () => {
    const v = parseInt(amount.replace(/\D/g, ''), 10);
    if (!fromId || !toId) {
      toast.show('Vui lòng chọn quỹ nguồn và quỹ đích');
      return;
    }
    if (fromId === toId) {
      toast.show('Quỹ nguồn và quỹ đích phải khác nhau');
      return;
    }
    if (!v || v <= 0) {
      toast.show('Nhập số tiền hợp lệ');
      return;
    }
    if (!date) {
      toast.show('Vui lòng chọn ngày');
      return;
    }
    setBusy(true);
    try {
      await transferFunds({
        fromFundId: fromId,
        toFundId: toId,
        amount: v,
        note: note.trim() || null,
        businessDate: date,
        warehouseId: whId || null,
      });
      const fromName = funds.find((f) => f.id === fromId)?.name ?? '';
      const toName = funds.find((f) => f.id === toId)?.name ?? '';
      toast.show(`Đã chuyển ${formatVND(v)}: ${fromName} → ${toName}`);
      onDone();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Chuyển quỹ thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet
      title="🔄 Chuyển quỹ"
      onClose={onClose}
      footer={
        <button className="btn btn-block btn-lg" disabled={busy} onClick={submit}>
          {busy ? 'Đang chuyển…' : 'Xác nhận chuyển'}
        </button>
      }
    >
      <div className="field">
        <label>Từ quỹ</label>
        <select className="input" value={fromId} onChange={(e) => setFromId(e.target.value)}>
          {funds.map((f) => (
            <option key={f.id} value={f.id}>
              {f.name}
            </option>
          ))}
        </select>
      </div>
      <div className="field">
        <label>Đến quỹ</label>
        <select className="input" value={toId} onChange={(e) => setToId(e.target.value)}>
          {toOptions.map((f) => (
            <option key={f.id} value={f.id}>
              {f.name}
            </option>
          ))}
        </select>
      </div>
      <div className="field">
        <label>Số tiền</label>
        <input
          className="input"
          inputMode="numeric"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          placeholder="VD: 1000000"
        />
      </div>
      <div className="row" style={{ gap: 8 }}>
        <div className="field" style={{ flex: 1 }}>
          <label>Ngày</label>
          <input
            type="date"
            className="input"
            value={date}
            onChange={(e) => setDate(e.target.value)}
          />
        </div>
        {warehouses.length > 1 && (
          <div className="field" style={{ flex: 1 }}>
            <label>Kho</label>
            <select className="input" value={whId} onChange={(e) => setWhId(e.target.value)}>
              {warehouses.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.name}
                </option>
              ))}
            </select>
          </div>
        )}
      </div>
      <div className="field">
        <label>Ghi chú (không bắt buộc)</label>
        <input
          className="input"
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="VD: nộp tiền mặt vào ngân hàng…"
        />
      </div>
      <p className="small muted" style={{ marginTop: 4 }}>
        Hệ thống sẽ tạo 2 khoản: 1 khoản chi từ quỹ nguồn và 1 khoản thu vào quỹ đích.
      </p>
    </Sheet>
  );
}

function FundCategorySheet({
  cats,
  onClose,
  onDone,
}: {
  cats: FundCategories;
  onClose: () => void;
  onDone: (c: FundCategories) => void;
}) {
  const toast = useToast();
  const [thu, setThu] = useState<string[]>(cats.thu);
  const [chi, setChi] = useState<string[]>(cats.chi);
  const [newThu, setNewThu] = useState('');
  const [newChi, setNewChi] = useState('');
  const [editing, setEditing] = useState<{ list: 'thu' | 'chi'; idx: number } | null>(null);
  const [editVal, setEditVal] = useState('');
  const [confirmDel, setConfirmDel] = useState<{ list: 'thu' | 'chi'; idx: number } | null>(null);
  const [busy, setBusy] = useState(false);

  const isLocked = (list: 'thu' | 'chi', name: string) =>
    list === 'thu' && LOCKED_THU_CATS.includes(name);
  const getList = (list: 'thu' | 'chi') => (list === 'thu' ? thu : chi);
  const setList = (list: 'thu' | 'chi', v: string[]) =>
    list === 'thu' ? setThu(v) : setChi(v);

  const addItem = (list: 'thu' | 'chi') => {
    const raw = (list === 'thu' ? newThu : newChi).trim().slice(0, 30);
    if (!raw) {
      toast.show('Nhập tên danh mục');
      return;
    }
    const cur = getList(list);
    if (cur.some((c) => c.toLowerCase() === raw.toLowerCase())) {
      toast.show('Danh mục này đã có');
      return;
    }
    if (cur.length >= 30) {
      toast.show('Tối đa 30 danh mục');
      return;
    }
    setList(list, [...cur, raw]);
    if (list === 'thu') setNewThu('');
    else setNewChi('');
  };

  const saveEdit = () => {
    if (!editing) return;
    const raw = editVal.trim().slice(0, 30);
    if (!raw) {
      toast.show('Tên danh mục không được trống');
      return;
    }
    const cur = getList(editing.list);
    if (cur.some((c, i) => i !== editing.idx && c.toLowerCase() === raw.toLowerCase())) {
      toast.show('Danh mục này đã có');
      return;
    }
    const next = [...cur];
    next[editing.idx] = raw;
    setList(editing.list, next);
    setEditing(null);
  };

  const delItem = (list: 'thu' | 'chi', idx: number) => {
    const cur = getList(list);
    if (cur.length <= 1) {
      toast.show('Phải giữ lại ít nhất 1 danh mục');
      return;
    }
    setList(
      list,
      cur.filter((_, i) => i !== idx),
    );
    setConfirmDel(null);
  };

  const save = async () => {
    setBusy(true);
    try {
      const c = await setFundCategories({ thu, chi });
      toast.show('Đã lưu danh mục');
      onDone(c);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  const renderSection = (list: 'thu' | 'chi', title: string) => {
    const cur = getList(list);
    const newVal = list === 'thu' ? newThu : newChi;
    const setNewVal = list === 'thu' ? setNewThu : setNewChi;
    return (
      <div style={{ marginBottom: 20 }}>
        <div style={{ fontWeight: 700, marginBottom: 8 }}>{title}</div>
        {cur.map((c, idx) => {
          const locked = isLocked(list, c);
          const isEditing = editing?.list === list && editing?.idx === idx;
          const isConfirm = confirmDel?.list === list && confirmDel?.idx === idx;
          return (
            <div
              key={`${c}-${idx}`}
              className="row"
              style={{
                justifyContent: 'space-between',
                alignItems: 'center',
                padding: '8px 0',
                borderBottom: '1px solid var(--line)',
              }}
            >
              {isEditing ? (
                <>
                  <input
                    className="input"
                    style={{ flex: 1, marginRight: 8 }}
                    value={editVal}
                    maxLength={30}
                    onChange={(e) => setEditVal(e.target.value)}
                    autoFocus
                  />
                  <div className="row" style={{ gap: 8 }}>
                    <button type="button" className="sb-chip selected" onClick={saveEdit}>
                      Lưu
                    </button>
                    <button type="button" className="sb-chip" onClick={() => setEditing(null)}>
                      Hủy
                    </button>
                  </div>
                </>
              ) : (
                <>
                  <div style={{ fontWeight: 600 }}>
                    {c}
                    {locked && (
                      <span className="sb-status-pill" style={{ marginLeft: 6, fontSize: 11 }}>
                        Mặc định
                      </span>
                    )}
                  </div>
                  {!locked && (
                    <div className="row" style={{ gap: 8 }}>
                      {isConfirm ? (
                        <>
                          <button
                            type="button"
                            className="sb-chip selected"
                            onClick={() => delItem(list, idx)}
                          >
                            Chắc chắn xóa
                          </button>
                          <button
                            type="button"
                            className="sb-chip"
                            onClick={() => setConfirmDel(null)}
                          >
                            Hủy
                          </button>
                        </>
                      ) : (
                        <>
                          <button
                            type="button"
                            className="sb-chip"
                            onClick={() => {
                              setEditing({ list, idx });
                              setEditVal(c);
                              setConfirmDel(null);
                            }}
                          >
                            Sửa
                          </button>
                          <button
                            type="button"
                            className="sb-chip"
                            onClick={() => {
                              setConfirmDel({ list, idx });
                              setEditing(null);
                            }}
                          >
                            Xóa
                          </button>
                        </>
                      )}
                    </div>
                  )}
                </>
              )}
            </div>
          );
        })}
        <div className="row" style={{ gap: 8, marginTop: 10 }}>
          <input
            className="input"
            style={{ flex: 1 }}
            value={newVal}
            maxLength={30}
            onChange={(e) => setNewVal(e.target.value)}
            placeholder="Tên danh mục mới…"
            onKeyDown={(e) => {
              if (e.key === 'Enter') addItem(list);
            }}
          />
          <button type="button" className="sb-chip selected" onClick={() => addItem(list)}>
            + Thêm
          </button>
        </div>
      </div>
    );
  };

  return (
    <Sheet
      title="Danh mục thu chi"
      onClose={onClose}
      footer={
        <button className="btn btn-block btn-lg" disabled={busy} onClick={save}>
          {busy ? 'Đang lưu…' : 'Lưu'}
        </button>
      }
    >
      {renderSection('thu', 'Danh mục khoản thu')}
      {renderSection('chi', 'Danh mục khoản chi')}
      <p className="small muted">
        "Bán hàng" và "Thu nợ" là danh mục mặc định của khoản tự động nên không thể sửa/xóa.
        Xóa danh mục không ảnh hưởng các khoản đã ghi trước đó.
      </p>
    </Sheet>
  );
}

/** Modal chi tiết một khoản thu/chi. */
function EntryDetailSheet({
  entry,
  funds,
  warehouses,
  canEdit,
  onClose,
  onEdit,
  onDelete,
  onOpenOrder,
  onOpenDoc,
}: {
  entry: CashbookEntry;
  funds: Fund[];
  warehouses: Warehouse[];
  canEdit: boolean;
  onClose: () => void;
  onEdit: () => void;
  onDelete: () => void;
  onOpenOrder: () => void;
  onOpenDoc: (refType: string, refId: string) => void;
}) {
  const isTransfer = entry.ref_type === 'transfer';
  const isAuto = entry.ref_type === 'order' || entry.ref_type === 'debt_pay' || entry.ref_type === 'supplier_pay';
  const fundName = funds.find((f) => f.id === entry.fund_id)?.name ?? entry.fund_id;
  const whName = entry.warehouse_id ? (warehouses.find((w) => w.id === entry.warehouse_id)?.name ?? '') : '';
  const sourceLabel =
    entry.ref_type === 'manual'
      ? '✍️ Nhập tay'
      : entry.ref_type === 'order'
        ? `🧾 Từ đơn ${entry.ref_code ?? ''}`
        : entry.ref_type === 'debt_pay'
          ? '💳 Thu nợ khách hàng'
          : entry.ref_type === 'supplier_pay'
            ? '🏭 Trả nợ NCC'
            : entry.ref_type === 'transfer'
              ? '🔄 Chuyển quỹ'
              : entry.ref_type === 'purchase'
                ? `📦 Phiếu nhập ${entry.ref_code ?? ''}`
                : entry.ref_type === 'stock_export'
                  ? `📤 Phiếu xuất ${entry.ref_code ?? ''}`
                  : entry.ref_type === 'production'
                    ? `🧪 Phiếu SX ${entry.ref_code ?? ''}`
                    : entry.ref_type;
  return (
    <Sheet
      title={`${entry.type === 'thu' ? 'Khoản thu' : 'Khoản chi'} ${formatVND(entry.amount)}`}
      onClose={onClose}
      footer={
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: `repeat(${[canEdit && !isAuto, canEdit, true].filter(Boolean).length}, 1fr)`,
            gap: 8,
          }}
        >          {canEdit && !isAuto && (
            <button type="button" className="btn btn-lg" style={{ width: '100%' }} onClick={onEdit}>
              ✏️ Sửa
            </button>
          )}
          {canEdit && (
            <button
              type="button"
              className="btn btn-lg"
              style={{ width: '100%', background: 'var(--red-bg, #fdecea)', color: 'var(--red, #d32f2f)' }}
              onClick={onDelete}
            >
              🗑️ Xóa
            </button>
          )}
          <button type="button" className="btn btn-lg btn-ghost" style={{ width: '100%' }} onClick={onClose}>
            Đóng
          </button>
        </div>
      }
    >
      <div className="sb-kv">
        <div className="kv-row">
          <span className="k">Loại</span>
          <span className={`v ${entry.type === 'thu' ? 'text-green' : 'text-orange'}`} style={{ fontWeight: 700 }}>
            {entry.type === 'thu' ? '↓ Thu' : '↑ Chi'}
          </span>
        </div>
        <div className="kv-row">
          <span className="k">Số tiền</span>
          <span className="v" style={{ fontWeight: 700, fontSize: 18 }}>
            {formatVND(entry.amount)}
          </span>
        </div>
        <div className="kv-row">
          <span className="k">Danh mục</span>
          <span className="v">{entry.category}</span>
        </div>
        <div className="kv-row">
          <span className="k">Quỹ</span>
          <span className="v">{fundName}</span>
        </div>
        {whName && (
          <div className="kv-row">
            <span className="k">Kho</span>
            <span className="v">{whName}</span>
          </div>
        )}
        <div className="kv-row">
          <span className="k">Thời gian</span>
          <span className="v">
            {formatDMY(vnDateKey(entry.created_at))} {formatTime(entry.created_at)}
          </span>
        </div>
        <div className="kv-row">
          <span className="k">Nguồn</span>
          <span className="v">{sourceLabel}</span>
        </div>
        {entry.note && (
          <div className="kv-row">
            <span className="k">Ghi chú</span>
            <span className="v">{entry.note}</span>
          </div>
        )}
        {isTransfer && (
          <p className="small muted" style={{ marginTop: 8 }}>
            🔄 Khoản chuyển quỹ gồm 1 khoản chi + 1 khoản thu liên kết. Sửa số tiền sẽ cập nhật cả 2 bên.
          </p>
        )}
        {isAuto && (
          <p className="small muted" style={{ marginTop: 8 }}>
            Khoản tự động từ hệ thống — không sửa trực tiếp được. Hãy sửa đơn gốc.
          </p>
        )}
      </div>
      {entry.ref_type === 'order' && entry.ref_id && (
        <button type="button" className="btn btn-block" style={{ marginTop: 12 }} onClick={onOpenOrder}>
          Mở đơn {entry.ref_code ?? ''} ›
        </button>
      )}
      {entry.ref_type === 'purchase' && entry.ref_id && (
        <button
          type="button"
          className="btn btn-block"
          style={{ marginTop: 12 }}
          onClick={() => onOpenDoc('purchase', entry.ref_id!)}
        >
          📦 Mở phiếu nhập {entry.ref_code ?? ''} ›
        </button>
      )}
      {entry.ref_type === 'stock_export' && entry.ref_id && (
        <button
          type="button"
          className="btn btn-block"
          style={{ marginTop: 12 }}
          onClick={() => onOpenDoc('stock_export', entry.ref_id!)}
        >
          📤 Mở phiếu xuất {entry.ref_code ?? ''} ›
        </button>
      )}
      {entry.ref_type === 'production' && entry.ref_id && (
        <button
          type="button"
          className="btn btn-block"
          style={{ marginTop: 12 }}
          onClick={() => onOpenDoc('production', entry.ref_id!)}
        >
          🧪 Mở phiếu SX {entry.ref_code ?? ''} ›
        </button>
      )}
    </Sheet>
  );
}

/** Sheet sửa khoản thu/chi (chỉ khoản tay + chuyển quỹ). */
function EntryEditSheet({
  entry,
  cats,
  funds,
  onClose,
  onDone,
}: {
  entry: CashbookEntry;
  cats: string[];
  funds: Fund[];
  onClose: () => void;
  onDone: () => void;
}) {
  const toast = useToast();
  const [amount, setAmount] = useState(String(entry.amount));
  const [note, setNote] = useState(entry.note ?? '');
  const [category, setCategory] = useState(entry.category);
  const [fundId, setFundId] = useState(entry.fund_id);
  const [date, setDate] = useState(vnDateKey(entry.created_at));
  const [busy, setBusy] = useState(false);
  const isTransfer = entry.ref_type === 'transfer';

  const submit = async () => {
    const v = parseInt(amount.replace(/\D/g, ''), 10);
    if (!v || v <= 0) {
      toast.show('Nhập số tiền hợp lệ');
      return;
    }
    if (!date) {
      toast.show('Vui lòng chọn ngày');
      return;
    }
    setBusy(true);
    try {
      await updateCashbookEntry(entry.id, {
        amount: v,
        note: note.trim() || null,
        category,
        fund_id: fundId,
        businessDate: date,
      });
      toast.show(
        isTransfer ? `Đã cập nhật cặp chuyển quỹ ${formatVND(v)}` : 'Đã lưu thay đổi',
      );
      onDone();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet
      title={`✏️ Sửa khoản ${entry.type === 'thu' ? 'thu' : 'chi'}`}
      onClose={onClose}
      footer={
        <div className="row" style={{ gap: 8 }}>
          <button className="btn btn-block btn-lg" disabled={busy} onClick={submit}>
            {busy ? 'Đang lưu…' : '💾 Lưu'}
          </button>
          <button type="button" className="btn btn-block btn-lg btn-ghost" onClick={onClose}>
            Hủy
          </button>
        </div>
      }
    >
      <div className="field">
        <label>Số tiền</label>
        <input
          className="sb-money-input"
          inputMode="numeric"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          placeholder="0"
          autoFocus
        />
      </div>
      {isTransfer && (
        <p className="small muted">🔄 Sửa số tiền sẽ cập nhật cả 2 khoản trong cặp chuyển quỹ.</p>
      )}
      <div className="field">
        <label>Quỹ</label>
        <div className="row" style={{ flexWrap: 'wrap', gap: 8 }}>
          {funds.map((f) => (
            <button
              key={f.id}
              type="button"
              className={`sb-chip${fundId === f.id ? ' selected' : ''}`}
              onClick={() => setFundId(f.id)}
            >
              {f.name}
            </button>
          ))}
        </div>
      </div>
      <div className="field">
        <label>Danh mục</label>
        <div className="row" style={{ flexWrap: 'wrap', gap: 8 }}>
          {cats.map((c) => (
            <button
              key={c}
              type="button"
              className={`sb-chip${category === c ? ' selected' : ''}`}
              onClick={() => setCategory(c)}
            >
              {c}
            </button>
          ))}
        </div>
      </div>
      <div className="field">
        <label>Ngày</label>
        <input
          type="date"
          className="input"
          value={date}
          max={todayVN()}
          onChange={(e) => setDate(e.target.value)}
        />
      </div>
      <div className="field">
        <label>Ghi chú</label>
        <input
          className="input"
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="Ghi chú…"
        />
      </div>
    </Sheet>
  );
}

/* ============================================================================
 * Modal rà soát & sửa dữ liệu quỹ từ đầu (chỉ chủ quán)
 * ========================================================================== */
function FundScanSheet({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const [issues, setIssues] = useState<FundIssue[] | null>(null);
  const [fixing, setFixing] = useState(false);
  const [result, setResult] = useState<{ fixed: number; errors: string[] } | null>(null);

  const doScan = async () => {
    setBusy(true);
    setIssues(null);
    setResult(null);
    try {
      const rs = await scanFundIssues();
      setIssues(rs);
      if (rs.length === 0) toast.show('Dữ liệu quỹ khớp hoàn toàn ✅');
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Rà soát thất bại');
    } finally {
      setBusy(false);
    }
  };

  const doFix = async () => {
    if (!issues || issues.length === 0) return;
    if (!window.confirm(`Sửa ${issues.length} lỗi đã phát hiện? Thao tác này ghi nhật ký đầy đủ.`)) return;
    setFixing(true);
    try {
      const rs = await repairFundIssues(issues);
      setResult(rs);
      setIssues(null);
      toast.show(`Đã sửa ${rs.fixed}/${issues.length} lỗi${rs.errors.length > 0 ? `, ${rs.errors.length} lỗi thất bại` : ''}`);
      if (rs.errors.length === 0) onDone();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Sửa thất bại');
    } finally {
      setFixing(false);
    }
  };

  const kindLabel = (k: FundIssue['kind']): string => {
    switch (k) {
      case 'orphan_order_entry': return '🗑️ Khoản mồ côi';
      case 'cancelled_order_entry': return '🚫 Khoản đơn đã hủy';
      case 'date_mismatch': return '📅 Sai ngày';
      case 'amount_mismatch': return '💰 Sai số tiền';
      case 'missing_entry': return '❌ Thiếu khoản';
      case 'orphan_transfer': return '🔄 Chuyển quỹ lẻ';
      case 'timestamp_date': return '🕐 Chuẩn hóa ngày';
      case 'duplicate_entry': return '👯 Khoản trùng';
    }
  };

  return (
    <Sheet title="🔧 Rà soát & tính lại quỹ từ đầu" onClose={onClose}>
      <p className="small muted" style={{ marginBottom: 12 }}>
        Quét toàn bộ đơn hàng và khoản quỹ, đối chiếu từng khoản với chứng từ gốc.
        Đơn đã xóa/hủy (kể cả đơn test) sẽ không được tính. Xem kỹ danh sách trước khi bấm sửa.
      </p>
      {!issues && !result && (
        <>
          <button className="btn primary" style={{ width: '100%' }} disabled={busy} onClick={() => void doScan()}>
            {busy ? 'Đang quét…' : '🔍 Bắt đầu rà soát'}
          </button>
          <ContinuityCheck />
        </>
      )}
      {issues && issues.length > 0 && (
        <>
          <div className="small" style={{ marginBottom: 8 }}>
            Phát hiện <b>{issues.length}</b> vấn đề:
          </div>
          <div style={{ maxHeight: 320, overflowY: 'auto', marginBottom: 12 }}>
            {issues.map((it, i) => (
              <div key={i} className="card" style={{ padding: 10, marginBottom: 8 }}>
                <div className="small" style={{ fontWeight: 600 }}>{kindLabel(it.kind)}</div>
                <div className="small muted">{it.description}</div>
                {it.amount > 0 && (
                  <div className="small">Số tiền: {formatVND(it.amount)}{it.expectedAmount != null && ` → ${formatVND(it.expectedAmount)}`}</div>
                )}
                {it.entryDate && (
                  <div className="small">Ngày: {it.entryDate}{it.expectedDate && ` → ${it.expectedDate}`}</div>
                )}
              </div>
            ))}
          </div>
          <button className="btn primary" style={{ width: '100%' }} disabled={fixing} onClick={() => void doFix()}>
            {fixing ? 'Đang sửa…' : `✅ Sửa tất cả ${issues.length} lỗi`}
          </button>
          <button className="btn" style={{ width: '100%', marginTop: 8 }} onClick={() => void doScan()}>
            🔍 Quét lại
          </button>
        </>
      )}
      {issues && issues.length === 0 && (
        <div className="card" style={{ padding: 16, textAlign: 'center' }}>
          <div style={{ fontSize: 32 }}>✅</div>
          <div>Dữ liệu quỹ khớp hoàn toàn với chứng từ gốc.</div>
          <button className="btn" style={{ marginTop: 12 }} onClick={onClose}>Đóng</button>
        </div>
      )}
      {result && (
        <div className="card" style={{ padding: 12, marginTop: 12 }}>
          <div className="small">Đã sửa: <b>{result.fixed}</b></div>
          {result.errors.length > 0 && (
            <div className="small" style={{ color: '#b91c1c', marginTop: 8 }}>
              Thất bại ({result.errors.length}):
              {result.errors.map((e, i) => <div key={i}>• {e}</div>)}
            </div>
          )}
          <button className="btn primary" style={{ width: '100%', marginTop: 12 }} onClick={() => void doScan()}>
            🔍 Quét lại để kiểm tra
          </button>
        </div>
      )}
      <RenumberSection />
    </Sheet>
  );
}

function ContinuityCheck() {
  const [busy, setBusy] = useState(false);
  const [results, setResults] = useState<Array<{ fundName: string; date: string; closeD: number; openD1: number; diff: number }> | null>(null);
  const doCheck = async () => {
    setBusy(true);
    setResults(null);
    try {
      const { checkBalanceContinuity } = await import('../lib/db');
      const r = await checkBalanceContinuity(7);
      setResults(r);
    } catch (e) {
      alert('Lỗi: ' + (e instanceof Error ? e.message : String(e)));
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="card" style={{ padding: 12, marginTop: 12 }}>
      <div className="small" style={{ fontWeight: 700, marginBottom: 4 }}>🔗 Kiểm tra liên tục số dư</div>
      <p className="small muted" style={{ marginBottom: 8 }}>
        Đối chiếu cuối kỳ hôm trước với đầu kỳ hôm sau (7 ngày gần nhất). Chỗ nào lệch sẽ hiện ra.
      </p>
      <button className="btn" style={{ width: '100%' }} disabled={busy} onClick={() => void doCheck()}>
        {busy ? 'Đang kiểm tra…' : '🔗 Kiểm tra liên tục'}
      </button>
      {results && (
        <div className="small" style={{ marginTop: 8 }}>
          {results.length === 0 ? (
            <div style={{ color: 'green' }}>✅ Mọi ngày đều liên tục, không lệch.</div>
          ) : (
            results.map((r, i) => (
              <div key={i} style={{ marginBottom: 6, padding: 8, background: '#fef2f2', borderRadius: 8 }}>
                <b>{r.fundName}</b> ngày {r.date}: cuối kỳ {r.closeD.toLocaleString('vi-VN')}đ ≠ đầu kỳ hôm sau {r.openD1.toLocaleString('vi-VN')}đ (lệch {r.diff.toLocaleString('vi-VN')}đ)
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}

function RenumberSection() {
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<string | null>(null);
  const doRenumber = async () => {
    if (!window.confirm('Đánh lại TOÀN BỘ mã chứng từ theo thứ tự thời gian tạo?\n\n• Đơn bán: A001, A002...\n• Phiếu nhập: PN001...\n• Phiếu xuất: XK001...\n• Phiếu SX: SX001...\n\nNên làm lúc quán vắng khách. Bấm OK để bắt đầu.')) return;
    setBusy(true);
    setDone(null);
    try {
      const { renumberAllDocuments } = await import('../lib/db');
      const r = await renumberAllDocuments();
      if (r.errors.length > 0) {
        setDone('Lỗi: ' + r.errors.join('; '));
      } else {
        setDone(`Xong! Đơn: ${r.orders}, Nhập: ${r.purchase_orders}, Xuất: ${r.stock_exports}, SX: ${r.production_orders}. Tải lại trang để thấy số mới.`);
      }
    } catch (e) {
      setDone('Thất bại: ' + (e instanceof Error ? e.message : String(e)));
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="card" style={{ padding: 12, marginTop: 16 }}>
      <div className="small" style={{ fontWeight: 700, marginBottom: 4 }}>🔢 Đánh lại số chứng từ</div>
      <p className="small muted" style={{ marginBottom: 8 }}>
        Sắp xếp toàn bộ đơn/phiếu theo thời gian tạo và đánh số liên tục từ 001. Chỉ cần làm 1 lần.
      </p>
      <button className="btn primary" style={{ width: '100%' }} disabled={busy} onClick={() => void doRenumber()}>
        {busy ? '⏳ Đang đánh lại số, vui lòng đợi...' : '🔢 Đánh lại số toàn bộ'}
      </button>
      {done && <div className="small" style={{ marginTop: 8 }}>{done}</div>}
    </div>
  );
}
