// Quản lý giao diện v1/v2/v3 của app.
// v1: theme xanh lá Sổ Bán Hàng (mặc định cũ)
// v2: theme Kasa POS — nền #F2F4F7, primary #4D81F1, font Plus Jakarta Sans
// v3: DEMO — biến thể v2 gọn hơn (icon nhỏ, dòng thấp, hiện nhiều thông tin)
export type AppTheme = 'v1' | 'v2' | 'v3';

const KEY = 'beesy-theme';

export function getTheme(): AppTheme {
  try {
    const t = localStorage.getItem(KEY);
    return t === 'v1' || t === 'v3' ? t : 'v2';
  } catch {
    return 'v2';
  }
}

export function setTheme(t: AppTheme): void {
  try {
    localStorage.setItem(KEY, t);
  } catch {
    /* bỏ qua */
  }
  document.documentElement.setAttribute('data-theme', t);
  // Đổi màu thanh trạng thái trình duyệt theo theme
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', t === 'v2' || t === 'v3' ? '#4D81F1' : '#00B14F');
  // Báo cho các component đang mở để render lại layout
  window.dispatchEvent(new CustomEvent<AppTheme>('beesy-theme-change', { detail: t }));
}

// Gọi sớm khi app khởi động (index.html đã set sẵn để tránh nháy)
export function initTheme(): void {
  setTheme(getTheme());
}
