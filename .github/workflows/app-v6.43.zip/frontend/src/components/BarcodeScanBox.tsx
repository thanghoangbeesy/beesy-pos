import { useEffect, useRef, useState } from 'react';
import { LineIcon } from './LineIcon';
import { BarcodeScanner } from './BarcodeScanner';

// PC = màn hình rộng (>= 1024px): ẩn nút camera, chỉ dùng súng quét.
function useIsPC(): boolean {
  const [isPC, setIsPC] = useState(() => typeof window !== 'undefined' && window.innerWidth >= 1024);
  useEffect(() => {
    const onResize = () => setIsPC(window.innerWidth >= 1024);
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);
  return isPC;
}

// O nhap ma vach dung chung cho ban hang va nhap/xuat kho:
// - Go tay ma vach roi Enter.
// - May quet USB (súng bắn mã vạch): may go ma nhu ban phim roi tu Enter —
//   chi can de con tro o o nay la quet duoc, khong can cai dat gi them.
// - Nut camera: chi hien tren dien thoai/may tinh bang (v6.35: tren PC web
//   khong dung camera, chi dung sung quet).
// Quet xong thi xoa o va giu focus de quet lien tiep mon tiep theo.
export function BarcodeScanBox({
  placeholder,
  onCode,
  autoFocus,
  inputRef: inputRefProp,
}: {
  placeholder?: string;
  onCode: (code: string) => void;
  autoFocus?: boolean;
  // v6.42: cha truyền ref vào để tự focus lại ô quét sau khi đóng modal
  // (bắn liên tục trên PC) — không truyền thì dùng ref nội bộ như trước.
  inputRef?: React.RefObject<HTMLInputElement | null>;
}) {
  const [value, setValue] = useState('');
  const [showScanner, setShowScanner] = useState(false);
  const fallbackRef = useRef<HTMLInputElement>(null);
  const inputRef = inputRefProp ?? fallbackRef;
  // v6.35: trên PC web không bắn mã bằng camera mà bằng súng quét — ẩn nút camera.
  const isPC = useIsPC();

  const submit = () => {
    const code = value.trim();
    if (!code) return;
    setValue('');
    onCode(code);
    inputRef.current?.focus();
  };

  return (
    <div className="barcode-box">
      <div className="sb-search grow">
        <span className="sico" aria-hidden>
          <LineIcon name="barcode" size={18} />
        </span>
        <input
          ref={inputRef}
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              e.preventDefault();
              submit();
            }
          }}
          placeholder={placeholder ?? 'Quét hoặc nhập mã vạch…'}
          aria-label="Mã vạch"
          autoFocus={autoFocus}
          autoComplete="off"
          autoCapitalize="off"
          autoCorrect="off"
          spellCheck={false}
        />
      </div>
      {!isPC && (
        <button
          type="button"
          className="btn btn-outline"
          style={{ minHeight: 48, minWidth: 48, padding: '0 12px' }}
          onClick={() => setShowScanner(true)}
          aria-label="Quét mã vạch bằng camera"
          title="Quét mã vạch bằng camera"
        >
          <LineIcon name="camera" size={20} />
        </button>
      )}
      {showScanner && (
        <BarcodeScanner
          onScan={(code) => {
            setShowScanner(false);
            onCode(code);
          }}
          onClose={() => setShowScanner(false)}
        />
      )}
    </div>
  );
}
