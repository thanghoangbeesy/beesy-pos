// Lớp dữ liệu Firestore cho Beesy POS (gói miễn phí Spark — không dùng Cloud Functions).
// Mọi tính toán giá/tích tem thực hiện client-side, mirror logic backend self-hosted
// (backend/src/routes/orders.js + lib/pricing.js), với validation thêm ở firestore.rules.
import {
  collection,
  deleteDoc,
  deleteField,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  writeBatch,
  query,
  where,
  orderBy,
  limit,
  runTransaction,
  increment,
  onSnapshot,
  serverTimestamp,
  startAfter,
  documentId,
  Timestamp,
  FirestoreError,
  type DocumentSnapshot,
  type QueryDocumentSnapshot,
  type QuerySnapshot,
  type Transaction,
} from 'firebase/firestore';
import { auth, db } from './firebase';
import { addDaysVN, todayVN, unsignVietnamese, uuid } from './format';
import { normalizeRole } from './permissions';
import { round2, wacAdd, wacRemove } from './wac';
import type {
  CashbookEntry,
  CashbookType,
  Category,
  Customer,
  DailyReport,
  DebtLog,
  DraftOrder,
  DraftOrderItem,
  FundRefType,
  FundCategories,
  FundSettings,
  Fund,
  Ingredient,
  IngredientWithStock,
  StockLog,
  RecipeItem,
  ModifierGroup,
  ModifierOption,
  Order,
  OrderItem,
  OrderStatus,
  PaymentMethod,
  PaymentMethodDef,
  PaymentMethodKind,
  Product,
  SelectedModifier,
  User,
  Warehouse,
  RoleKey,
  Promotion,
  Voucher,
  OnlineOrder,
  OnlineOrderItem,
  Supplier,
  PurchaseOrder,
  PurchaseOrderItem,
  StockExport,
  StockExportItem,
  StockExportReason,
  Combo,
  ComboItem,
  DayClose,
  AuditLog,
  StockReason,
  StockReasonsSettings,
  StockExportBehavior,
  ProductionOrder,
} from './types';
import { discountAmountFor, orderPaymentSplits } from './types';

// ---------------------------------------------------------------- DbError ---
export class DbError extends Error {
  code: string;
  constructor(code: string, message: string) {
    super(message);
    this.name = 'DbError';
    this.code = code;
  }
}

/**
 * Lấy số thứ tự toàn cục tiếp theo cho mã chứng từ (đảm bảo duy nhất, không tái sử dụng số đã xóa).
 * - counterKey: key trong collection 'counters' (VD: 'order_seq', 'po_seq')
 * - codePrefix: tiền tố mã (VD: 'A', 'PN', 'SX', 'XK')
 * - collection: collection cần quét để tìm số lớn nhất khi khởi tạo
 * Phải gọi NGOÀI transaction (vì cần query).
 */
export async function nextGlobalSeq(
  counterKey: string,
  codePrefix: string,
  collectionName: string,
): Promise<number> {
  try {
    const seqSnap = await getDoc(doc(db, 'counters', counterKey));
    if (seqSnap.exists()) {
      return Number((seqSnap.data() as Record<string, unknown>).last ?? 0) + 1;
    }
    // Lần đầu: tìm số lớn nhất đã dùng
    let max = 0;
    const snap = await getDocs(query(collection(db, collectionName), orderBy('created_at', 'desc'), limit(500)));
    const re = new RegExp(`^${codePrefix}(\\d+)$`);
    for (const d of snap.docs) {
      const c = String((d.data() as Record<string, unknown>).code ?? '');
      const m = c.match(re);
      if (m) max = Math.max(max, parseInt(m[1], 10));
    }
    return max + 1;
  } catch {
    return 1;
  }
}

const FIRESTORE_CODE_MAP: Record<string, string> = {
  'deadline-exceeded': 'unavailable',
  unavailable: 'unavailable',
  'permission-denied': 'permission-denied',
  'not-found': 'not-found',
  'invalid-argument': 'invalid-argument',
};

export function toDbError(e: unknown): DbError {
  if (e instanceof DbError) return e;
  if (e instanceof FirestoreError) {
    const code = FIRESTORE_CODE_MAP[e.code] ?? 'unknown';
    const message =
      code === 'unavailable'
        ? 'Mất kết nối mạng. Vui lòng kiểm tra internet rồi thử lại.'
        : code === 'permission-denied'
          ? 'Bạn không có quyền thực hiện thao tác này.'
          : e.message;
    return new DbError(code, message);
  }
  return new DbError('unknown', e instanceof Error ? e.message : 'Lỗi không xác định.');
}

// ------------------------------------------------------------- converters ---
function tsToIso(v: unknown): string {
  if (v instanceof Timestamp) return v.toDate().toISOString();
  if (typeof v === 'string' && v) return v;
  return new Date().toISOString();
}

/** YYYY-MM-DD theo giờ Việt Nam của 1 mốc thời gian (Timestamp hoặc chuỗi ISO).
 *  Mọi báo cáo phải xếp ngày khoản quỹ bằng hàm này — trước v5.2 một số hàm cắt
 *  chuỗi ISO UTC nên khoản ghi 00:00-06:59 giờ VN bị tính sang ngày hôm trước. */
function vnDateKeyOf(v: unknown): string {
  const iso = tsToIso(v);
  try {
    return new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Ho_Chi_Minh',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    }).format(new Date(iso));
  } catch {
    return iso.slice(0, 10);
  }
}

/** Giờ (0-23) theo Asia/Ho_Chi_Minh của 1 mốc thời gian (Timestamp hoặc ISO).
 *  Dùng Intl như vnDateKeyOf, không dùng getHours() của máy vì múi giờ máy
 *  có thể khác giờ VN. */
function vnHourOf(v: unknown): number {
  const iso = tsToIso(v);
  try {
    return Number(new Intl.DateTimeFormat('en-GB', {
      timeZone: 'Asia/Ho_Chi_Minh',
      hour: 'numeric',
      hourCycle: 'h23',
    }).format(new Date(iso)));
  } catch {
    return new Date(iso).getUTCHours();
  }
}
/** Khoản 'chi' này có phải CHI PHÍ VẬN HÀNH để trừ vào lợi nhuận ròng không?
 *  Loại ra: chuyển quỹ nội bộ (tiền chỉ chạy giữa các quỹ), nhập hàng và trả nợ
 *  NCC (tiền mua nguyên liệu đã tính trong giá vốn món qua định lượng — tính nữa
 *  là trừ 2 lần). Dữ liệu cũ thiếu ref_type thì nhận diện thêm qua tên danh mục. */
function isOperatingExpense(data: Record<string, unknown>): boolean {
  if (data.type !== 'chi') return false;
  const rt = typeof data.ref_type === 'string' ? data.ref_type : '';
  // debt_refund (sua 25/10/2026): phieu chi hoan tien thu no khi xoa/huy
  // don ghi no — la tra lai tien khach, KHONG phai chi phi van hanh, nen
  // khong duoc tru vao loi nhuan (tru nua la tru 2 lan: doanh thu cua don
  // da bi xoa khoi bao cao khi don mat).
  if (rt === 'transfer' || rt === 'purchase' || rt === 'supplier_pay' || rt === 'debt_refund') return false;
  const cat = typeof data.category === 'string' ? data.category : '';
  if (cat === 'Chuyển quỹ' || cat === 'Nhập hàng' || cat === 'Trả nợ NCC') return false;
  return true;
}

/** Quy tắc kho DUY NHẤT phía báo cáo (khớp orderInScope): khi có phạm vi kho,
 *  khoản/đơn không thuộc kho nào (null) bị loại; không có phạm vi thì lấy tất cả. */
function cashbookInScope(wid: string | null, warehouseIds?: string[] | null): boolean {
  if (!warehouseIds || warehouseIds.length === 0) return true;
  return !!wid && warehouseIds.includes(wid);
}

/** Tải TOÀN BỘ đơn trong [start, end] theo business_date (phân trang — không cắt
 *  ngầm ở 2000 đơn như trước, tránh mất đơn ở các ngày cũ trong kỳ khi dữ liệu lớn). */
async function fetchOrdersInRange(start: string, end: string): Promise<Order[]> {
  const out: Order[] = [];
  let last: unknown = null;
  for (let page = 0; page < 100; page++) {
    const q =
      last == null
        ? query(
            collection(db, 'orders'),
            where('business_date', '>=', start),
            where('business_date', '<=', end),
            orderBy('business_date', 'desc'),
            limit(1000),
          )
        : query(
            collection(db, 'orders'),
            where('business_date', '>=', start),
            where('business_date', '<=', end),
            orderBy('business_date', 'desc'),
            limit(1000),
            startAfter(last as never),
          );
    const snap = await getDocs(q);
    if (snap.docs.length === 0) break;
    for (const d of snap.docs) {
      const o = orderFromDoc(d);
      if (o) out.push(o);
    }
    last = snap.docs[snap.docs.length - 1];
    if (snap.docs.length < 1000) break;
  }
  return out;
}

/** Loại bỏ đệ quy mọi field undefined (Firestore không chấp nhận undefined). */
function stripUndefined<T>(v: T): T {
  if (Array.isArray(v)) return v.map(stripUndefined) as unknown as T;
  if (v !== null && typeof v === 'object') {
    const out: Record<string, unknown> = {};
    for (const [k, val] of Object.entries(v as Record<string, unknown>)) {
      if (val === undefined) continue;
      out[k] = stripUndefined(val);
    }
    return out as T;
  }
  return v;
}

function activeOf(d: Record<string, unknown>): boolean {
  return d.active !== false;
}

function toCategory(id: string, d: Record<string, unknown>): Category {
  return {
    id,
    name: String(d.name ?? ''),
    sort_order: Number(d.sort_order ?? 0),
    active: activeOf(d),
  };
}

function toProduct(id: string, d: Record<string, unknown>): Product {
  const recipeRaw = Array.isArray(d.recipe) ? d.recipe : [];
  const recipe: RecipeItem[] = [];
  for (const r of recipeRaw) {
    const o = r as Record<string, unknown>;
    const q = Number(o.qty ?? 0);
    if (typeof o.ingredient_id === 'string' && o.ingredient_id && q > 0) {
      recipe.push({ ingredient_id: o.ingredient_id, qty: q });
    }
  }
  return {
    id,
    name: String(d.name ?? ''),
    category_id: (d.category_id as string | null) ?? null,
    base_price: Number(d.base_price ?? 0),
    cost_price: Math.max(0, Math.round(Number(d.cost_price ?? 0)) || 0),
    unit: String(d.unit ?? '').trim().slice(0, 20),
    recipe,
    variant_recipes: (() => {
      const vr = d.variant_recipes as Record<string, unknown> | undefined;
      if (!vr || typeof vr !== 'object') return undefined;
      const out: Record<string, RecipeItem[]> = {};
      for (const [k, v] of Object.entries(vr)) {
        const r = sanitizeRecipe(v);
        if (r.length > 0) out[k] = r;
      }
      return Object.keys(out).length > 0 ? out : undefined;
    })(),
    image_url: (d.image_url as string | null) ?? null,
    active: activeOf(d),
    sort_order: Number(d.sort_order ?? 0),
    warehouse_ids: Array.isArray(d.warehouse_ids)
      ? (d.warehouse_ids as unknown[]).filter((x): x is string => typeof x === 'string' && !!x)
      : [],
    track_stock: d.track_stock === true,
    stock_ingredient_id: (d.stock_ingredient_id as string | null) ?? null,
  };
}

function toModifierOption(id: string, d: Record<string, unknown>): ModifierOption {
  return {
    id,
    group_id: String(d.group_id ?? ''),
    name: String(d.name ?? ''),
    price_delta: Number(d.price_delta ?? 0),
    sort_order: Number(d.sort_order ?? 0),
    active: activeOf(d),
  };
}

function toModifierGroup(
  id: string,
  d: Record<string, unknown>,
  options: ModifierOption[],
): ModifierGroup {
  return {
    id,
    name: String(d.name ?? ''),
    selection_type: d.selection_type === 'multi' ? 'multi' : 'single',
    required: d.required === true,
    sort_order: Number(d.sort_order ?? 0),
    active: activeOf(d),
    options,
  };
}

function toCustomer(id: string, d: Record<string, unknown>): Customer {
  return {
    id,
    name: String(d.name ?? ''),
    phone: String(d.phone ?? ''),
    birthday: (d.birthday as string | null) ?? null,
    address: (d.address as string | null) ?? null,
    stamps: Number(d.stamps ?? 0),
    reward_available: d.reward_available === true,
    points: Math.max(0, Number(d.points ?? 0)),
    total_spent: Math.max(0, Number(d.total_spent ?? 0)),
    tier: d.tier === 'gold' ? 'gold' : d.tier === 'silver' ? 'silver' : 'member',
    debt: Number(d.debt ?? 0),
    zalo_user_id: (d.zalo_user_id as string | null) ?? null,
    note: (d.note as string | null) ?? null,
    warehouse_id: typeof d.warehouse_id === 'string' && d.warehouse_id ? d.warehouse_id : null,
    created_at: tsToIso(d.created_at),
  };
}

function toPaymentMethod(id: string, d: Record<string, unknown>): PaymentMethodDef {
  const kind = d.kind as string;
  return {
    id,
    name: String(d.name ?? ''),
    kind: kind === 'transfer' || kind === 'debt' ? kind : 'cash',
    icon: String(d.icon ?? ''),
    bank_bin: (d.bank_bin as string | null) ?? null,
    bank_account: (d.bank_account as string | null) ?? null,
    bank_account_name: (d.bank_account_name as string | null) ?? null,
    active: activeOf(d),
    sort_order: Number(d.sort_order ?? 0),
  };
}

function toDebtLog(id: string, d: Record<string, unknown>): DebtLog {
  return {
    id,
    amount: Number(d.amount ?? 0),
    balance_after: Number(d.balance_after ?? 0),
    note: (d.note as string | null) ?? null,
    order_code: (d.order_code as string | null) ?? null,
    order_id: (d.order_id as string | null) ?? null,
    created_by: (d.created_by as string | null) ?? null,
    created_at: tsToIso(d.created_at),
  };
}

// Convert 1 document orders → Order (dùng chung cho db.ts và realtime.ts)
export function orderFromDoc(
  snap: DocumentSnapshot | QueryDocumentSnapshot,
): Order | null {
  if (!snap.exists()) return null;
  const d = snap.data() as Record<string, unknown>;
  const rawItems = Array.isArray(d.items) ? d.items : [];
  const items: OrderItem[] = rawItems.map((it: Record<string, unknown>, i: number) => ({
    id: String(it.id ?? `${snap.id}-item-${i}`),
    order_id: String(it.order_id ?? snap.id),
    product_id: String(it.product_id ?? ''),
    product_name: String(it.product_name ?? ''),
    qty: Number(it.qty ?? 0),
    unit_price: Number(it.unit_price ?? 0),
    cost_price: Math.max(0, Math.round(Number(it.cost_price ?? 0)) || 0),
    recipe: sanitizeRecipe(it.recipe),
    modifiers: (Array.isArray(it.modifiers) ? it.modifiers : []).map(
      (m: Record<string, unknown>): SelectedModifier => ({
        option_id: String(m.option_id ?? ''),
        group: String(m.group ?? ''),
        option: String(m.option ?? ''),
        price_delta: Number(m.price_delta ?? 0),
      }),
    ),
    line_total: Number(it.line_total ?? 0),
    discount: Number(it.discount ?? 0),
    discount_type: (it.discount_type as 'percent' | 'amount' | null) ?? null,
    discount_value: it.discount_value == null ? null : Number(it.discount_value),
    ...(typeof it.note === 'string' && it.note ? { note: it.note } : {}),
    ...(it.is_combo === true ? { is_combo: true } : {}),
    ...(Array.isArray(it.combo_items) ? { combo_items: it.combo_items.map(String) } : {}),
  }));
  return {
    id: snap.id,
    client_uuid: String(d.client_uuid ?? snap.id),
    code: String(d.code ?? ''),
    business_date: String(d.business_date ?? ''),
    customer_id: (d.customer_id as string | null) ?? null,
    status: d.status as OrderStatus,
    payment_method: String(d.payment_method ?? ''),
    payment_method_name: (d.payment_method_name as string | null) ?? null,
    warehouse_id: (d.warehouse_id as string | null) ?? null,
    warehouse_name: (d.warehouse_name as string | null) ?? null,
    subtotal: Number(d.subtotal ?? 0),
    discount: Number(d.discount ?? 0),
    discount_type: (d.discount_type as 'percent' | 'amount' | null) ?? null,
    discount_value: d.discount_value == null ? null : Number(d.discount_value),
    discount_label: (d.discount_label as string | null) ?? null,
    shipping_fee: Math.max(0, Number(d.shipping_fee ?? 0)),
    total: Number(d.total ?? 0),
    amount_received: d.amount_received == null ? null : Number(d.amount_received),
    change_amount: d.change_amount == null ? null : Number(d.change_amount),
    note: (d.note as string | null) ?? null,
    source: d.source === 'online' ? 'online' : 'pos',
    online_name: (d.online_name as string | null) ?? null,
    online_phone: (d.online_phone as string | null) ?? null,
    voucher_code: (d.voucher_code as string | null) ?? null,
    points_earned: Math.max(0, Number(d.points_earned ?? 0)),
    reward_triggered: d.reward_triggered === true,
    created_by: (d.created_by as string | null) ?? null,
    created_at: tsToIso(d.created_at),
    items,
    ...(Array.isArray(d.payments) && d.payments.length > 0
      ? {
          payments: (d.payments as Array<Record<string, unknown>>)
            .map((sp) => ({
              method_id: String(sp.method_id ?? ''),
              method_name: String(sp.method_name ?? sp.method_id ?? ''),
              kind:
                sp.kind === 'transfer' ? ('transfer' as const)
                : sp.kind === 'debt' ? ('debt' as const)
                : ('cash' as const),
              amount: Math.max(0, Math.round(Number(sp.amount ?? 0))),
            }))
            .filter((sp) => sp.method_id && sp.amount > 0),
        }
      : {}),
  };
}

// Giờ VN (0-23) từ chuỗi ISO — mirror backend lib/dates.js#vnHour
function vnHour(iso: string): number {
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Asia/Ho_Chi_Minh',
    hour: 'numeric',
    hourCycle: 'h23',
  }).formatToParts(new Date(iso));
  return Number(parts.find((p) => p.type === 'hour')?.value ?? 0);
}

// ------------------------------------------------------------- categories ---
export async function listCategories(): Promise<Category[]> {
  try {
    const snap = await getDocs(query(collection(db, 'categories'), orderBy('sort_order', 'asc')));
    return snap.docs.map((d) => toCategory(d.id, d.data()));
  } catch (e) {
    throw toDbError(e);
  }
}

export async function createCategory(name: string): Promise<Category> {
  const trimmed = String(name ?? '').trim();
  if (!trimmed) throw new DbError('invalid-argument', 'Vui lòng nhập tên danh mục.');
  try {
    const existing = await listCategories();
    const maxSort = existing.reduce((m, c) => Math.max(m, c.sort_order), 0);
    const id = uuid();
    const data = { id, name: trimmed, sort_order: maxSort + 1, active: true };
    await setDoc(doc(db, 'categories', id), data);
    return toCategory(id, data);
  } catch (e) {
    throw toDbError(e);
  }
}

export async function updateCategory(
  id: string,
  patch: { name?: string; active?: boolean; sort_order?: number },
): Promise<void> {
  const data: Record<string, unknown> = {};
  if (patch.name !== undefined) {
    const trimmed = String(patch.name).trim();
    if (!trimmed) throw new DbError('invalid-argument', 'Tên danh mục không được để trống.');
    data.name = trimmed;
  }
  if (patch.active !== undefined) data.active = patch.active;
  if (patch.sort_order !== undefined) data.sort_order = patch.sort_order;
  if (Object.keys(data).length === 0) return;
  try {
    await updateDoc(doc(db, 'categories', id), data);
  } catch (e) {
    throw toDbError(e);
  }
}

// Xóa danh mục. Các món đang thuộc danh mục này được chuyển sang "chưa phân loại"
// (giữ lại món để vẫn bán được). Trả về số món đã chuyển.
export async function deleteCategory(id: string): Promise<{ moved: number }> {
  try {
    const products = await listProducts();
    const affected = products.filter((p) => p.category_id === id);
    const batch = writeBatch(db);
    for (const p of affected) {
      batch.update(doc(db, 'products', p.id), { category_id: null });
    }
    batch.delete(doc(db, 'categories', id));
    await batch.commit();
    return { moved: affected.length };
  } catch (e) {
    throw toDbError(e);
  }
}

// -------------------------------------------------------------- products ---
export async function listProducts(): Promise<Product[]> {
  try {
    const snap = await getDocs(query(collection(db, 'products'), orderBy('sort_order', 'asc')));
    return snap.docs.map((d) => toProduct(d.id, d.data()));
  } catch (e) {
    throw toDbError(e);
  }
}

export async function createProduct(d: {
  name: string;
  base_price: number;
  category_id: string | null;
  cost_price?: number;
  unit?: string;
  recipe?: RecipeItem[];
  warehouse_ids?: string[];
}): Promise<Product> {
  const name = String(d.name ?? '').trim();
  if (!name) throw new DbError('invalid-argument', 'Vui lòng nhập tên món.');
  const price = Math.round(Number(d.base_price));
  if (!Number.isFinite(price) || price <= 0) {
    throw new DbError('invalid-argument', 'Giá bán phải là số dương.');
  }
  const cost = Math.max(0, Math.round(Number(d.cost_price ?? 0)) || 0);
  const unit = String(d.unit ?? '').trim().slice(0, 20);
  const recipe = sanitizeRecipe(d.recipe);
  try {
    if (d.category_id) {
      const cat = await getDoc(doc(db, 'categories', d.category_id));
      if (!cat.exists()) throw new DbError('invalid-argument', 'Danh mục không tồn tại.');
    }
    const existing = await listProducts();
    const maxSort = existing.reduce((m, p) => Math.max(m, p.sort_order), 0);
    const id = uuid();
    const data = {
      id,
      name,
      category_id: d.category_id ?? null,
      base_price: price,
      cost_price: cost,
      unit,
      recipe,
      image_url: null,
      active: true,
      sort_order: maxSort + 1,
      warehouse_ids: Array.isArray(d.warehouse_ids)
        ? [...new Set(d.warehouse_ids.filter((x) => typeof x === 'string' && x))].slice(0, 50)
        : [],
    };
    await setDoc(doc(db, 'products', id), data);
    clearCatalogCache();
    return toProduct(id, data);
  } catch (e) {
    throw toDbError(e);
  }
}

/** Chuẩn hóa định lượng: bỏ dòng rỗng, gộp trùng nguyên liệu. */
function sanitizeRecipe(input: unknown): RecipeItem[] {
  if (!Array.isArray(input)) return [];
  const map = new Map<string, number>();
  for (const r of input) {
    const o = r as Record<string, unknown>;
    const q = Number(o.qty ?? 0);
    if (typeof o.ingredient_id === 'string' && o.ingredient_id && q > 0 && Number.isFinite(q)) {
      map.set(o.ingredient_id, (map.get(o.ingredient_id) ?? 0) + q);
    }
  }
  return [...map.entries()].map(([ingredient_id, qty]) => ({ ingredient_id, qty }));
}

export async function updateProduct(
  id: string,
  patch: Partial<Pick<Product, 'name' | 'base_price' | 'cost_price' | 'unit' | 'recipe' | 'variant_recipes' | 'category_id' | 'active' | 'sort_order' | 'image_url' | 'warehouse_ids'>>,
): Promise<void> {
  const data: Record<string, unknown> = {};
  if (patch.name !== undefined) {
    const trimmed = String(patch.name).trim();
    if (!trimmed) throw new DbError('invalid-argument', 'Tên món không được để trống.');
    data.name = trimmed;
  }
  if (patch.base_price !== undefined) {
    const price = Math.round(Number(patch.base_price));
    if (!Number.isFinite(price) || price <= 0) {
      throw new DbError('invalid-argument', 'Giá bán phải là số dương.');
    }
    data.base_price = price;
  }
  if (patch.cost_price !== undefined) {
    const cost = Math.round(Number(patch.cost_price));
    if (!Number.isFinite(cost) || cost < 0) {
      throw new DbError('invalid-argument', 'Giá vốn không hợp lệ.');
    }
    data.cost_price = cost;
  }
  if (patch.unit !== undefined) {
    data.unit = String(patch.unit ?? '').trim().slice(0, 20);
  }
  if (patch.recipe !== undefined) {
    data.recipe = sanitizeRecipe(patch.recipe);
  }
  if (patch.variant_recipes !== undefined) {
    const vr = patch.variant_recipes as Record<string, unknown>;
    const out: Record<string, RecipeItem[]> = {};
    if (vr && typeof vr === 'object') {
      for (const [k, v] of Object.entries(vr)) {
        const r = sanitizeRecipe(v);
        if (r.length > 0) out[k] = r;
      }
    }
    data.variant_recipes = out;
  }
  if (patch.category_id !== undefined) {
    if (patch.category_id) {
      try {
        const cat = await getDoc(doc(db, 'categories', patch.category_id));
        if (!cat.exists()) throw new DbError('invalid-argument', 'Danh mục không tồn tại.');
      } catch (e) {
        throw toDbError(e);
      }
    }
    data.category_id = patch.category_id;
  }
  if (patch.active !== undefined) data.active = patch.active;
  if (patch.sort_order !== undefined) data.sort_order = patch.sort_order;
  if (patch.image_url !== undefined) data.image_url = patch.image_url;
  if (patch.warehouse_ids !== undefined) {
    data.warehouse_ids = Array.isArray(patch.warehouse_ids)
      ? [...new Set(patch.warehouse_ids.filter((x) => typeof x === 'string' && x))].slice(0, 50)
      : [];
  }
  if (Object.keys(data).length === 0) return;
  try {
    const before = await getDoc(doc(db, 'products', id));
    const beforeName = before.exists() ? String((before.data() as Record<string, unknown>).name ?? id) : id;
    const beforePrice = before.exists() ? Number((before.data() as Record<string, unknown>).base_price ?? 0) : 0;
    await updateDoc(doc(db, 'products', id), data);
    clearCatalogCache();
    if (data.base_price !== undefined && Number(data.base_price) !== beforePrice) {
      logAudit('product.price', `Đổi giá "${beforeName}": ${beforePrice.toLocaleString('vi-VN')}đ → ${Number(data.base_price).toLocaleString('vi-VN')}đ`, { type: 'product', id });
    } else {
      logAudit('product.update', `Sửa món "${beforeName}"`, { type: 'product', id });
    }
  } catch (e) {
    throw toDbError(e);
  }
}

// Xóa hẳn một món khỏi menu. Đơn hàng cũ không bị ảnh hưởng vì đã lưu tên/giá riêng.
export async function deleteProduct(id: string): Promise<void> {
  let pname = id;
  try {
    const snap = await getDoc(doc(db, 'products', id));
    if (snap.exists()) pname = String((snap.data() as Record<string, unknown>).name ?? id);
  } catch { /* bỏ qua */ }
  try {
    await deleteDoc(doc(db, 'products', id));
    clearCatalogCache();
    logAudit('product.delete', `Xóa món "${pname}"`, { type: 'product', id });
  } catch (e) {
    throw toDbError(e);
  }
}

// Thêm nhiều món cùng lúc (từ màn hình "Thêm hàng loạt").
// Mỗi phần tử: { name, base_price, category_id }. Bỏ qua các dòng lỗi, trả về số món đã thêm.
export async function createProductsBulk(
  items: { name: string; base_price: number; category_id: string | null }[],
): Promise<{ added: number }> {
  const valid = items.filter(
    (it) =>
      String(it.name ?? '').trim() &&
      Number.isFinite(Math.round(Number(it.base_price))) &&
      Math.round(Number(it.base_price)) > 0,
  );
  if (valid.length === 0) throw new DbError('invalid-argument', 'Không có món hợp lệ để thêm.');
  try {
    const existing = await listProducts();
    let sort = existing.reduce((m, p) => Math.max(m, p.sort_order), 0);
    const batch = writeBatch(db);
    for (const it of valid) {
      const id = uuid();
      sort += 1;
      batch.set(doc(db, 'products', id), {
        id,
        name: String(it.name).trim(),
        category_id: it.category_id ?? null,
        base_price: Math.round(Number(it.base_price)),
        image_url: null,
        active: true,
        sort_order: sort,
      });
    }
    await batch.commit();
    return { added: valid.length };
  } catch (e) {
    throw toDbError(e);
  }
}

// -------------------------------------------------------- modifier groups ---
export async function listModifierGroups(): Promise<ModifierGroup[]> {
  try {
    const [gSnap, oSnap] = await Promise.all([
      getDocs(query(collection(db, 'modifierGroups'), orderBy('sort_order', 'asc'))),
      getDocs(query(collection(db, 'modifierOptions'), orderBy('sort_order', 'asc'))),
    ]);
    const byGroup = new Map<string, ModifierOption[]>();
    for (const d of oSnap.docs) {
      const opt = toModifierOption(d.id, d.data());
      const arr = byGroup.get(opt.group_id) ?? [];
      arr.push(opt);
      byGroup.set(opt.group_id, arr);
    }
    return gSnap.docs.map((d) => toModifierGroup(d.id, d.data(), byGroup.get(d.id) ?? []));
  } catch (e) {
    throw toDbError(e);
  }
}

export async function createModifierOption(
  groupId: string,
  d: { name: string; price_delta: number },
): Promise<ModifierOption> {
  const name = String(d.name ?? '').trim();
  if (!name) throw new DbError('invalid-argument', 'Vui lòng nhập tên tùy chọn.');
  const delta = Math.round(Number(d.price_delta));
  if (!Number.isFinite(delta) || delta < 0) {
    throw new DbError('invalid-argument', 'Phụ thu phải là số không âm.');
  }
  try {
    const groupSnap = await getDoc(doc(db, 'modifierGroups', groupId));
    if (!groupSnap.exists()) throw new DbError('not-found', 'Nhóm tùy chọn không tồn tại.');
    const oSnap = await getDocs(
      query(collection(db, 'modifierOptions'), where('group_id', '==', groupId)),
    );
    const maxSort = oSnap.docs.reduce(
      (m, x) => Math.max(m, Number(x.data().sort_order ?? 0)),
      0,
    );
    const id = uuid();
    const data = {
      id,
      group_id: groupId,
      name,
      price_delta: delta,
      sort_order: maxSort + 1,
      active: true,
    };
    await setDoc(doc(db, 'modifierOptions', id), data);
    return toModifierOption(id, data);
  } catch (e) {
    throw toDbError(e);
  }
}

export async function updateModifierOption(
  id: string,
  patch: { name?: string; price_delta?: number; active?: boolean },
): Promise<void> {
  const data: Record<string, unknown> = {};
  if (patch.name !== undefined) {
    const trimmed = String(patch.name).trim();
    if (!trimmed) throw new DbError('invalid-argument', 'Tên tùy chọn không được để trống.');
    data.name = trimmed;
  }
  if (patch.price_delta !== undefined) {
    const delta = Math.round(Number(patch.price_delta));
    if (!Number.isFinite(delta) || delta < 0) {
      throw new DbError('invalid-argument', 'Phụ thu phải là số không âm.');
    }
    data.price_delta = delta;
  }
  if (patch.active !== undefined) data.active = patch.active;
  if (Object.keys(data).length === 0) return;
  try {
    await updateDoc(doc(db, 'modifierOptions', id), data);
  } catch (e) {
    throw toDbError(e);
  }
}

// Xóa hẳn một lựa chọn (VD: topping). Đơn hàng cũ không bị ảnh hưởng vì đã lưu tên/giá riêng.
export async function deleteModifierOption(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'modifierOptions', id));
  } catch (e) {
    throw toDbError(e);
  }
}

// -------------------------------------------------------- payment methods ---
const SYSTEM_METHOD_IDS = ['cash', 'transfer', 'debt'];

const KIND_LABEL: Record<PaymentMethodKind, string> = {
  cash: 'Tiền mặt',
  transfer: 'Chuyển khoản',
  debt: 'Ghi nợ',
};

export function paymentKindLabel(kind: PaymentMethodKind): string {
  return KIND_LABEL[kind] ?? kind;
}

// Tạo 3 phương thức mặc định nếu collection còn trống.
// Đồng thời chuyển cấu hình ngân hàng cũ (settings bank_*) sang phương thức chuyển khoản.
export async function ensurePaymentMethodsSeeded(): Promise<void> {
  try {
    const snap = await getDocs(query(collection(db, 'payment_methods'), limit(1)));
    if (!snap.empty) return;
    const settings = await getSettings();
    const batch = writeBatch(db);
    const defaults: Array<Omit<PaymentMethodDef, 'active'>> = [
      {
        id: 'cash', name: 'Tiền mặt', kind: 'cash', icon: '💵',
        bank_bin: null, bank_account: null, bank_account_name: null, sort_order: 1,
      },
      {
        id: 'transfer', name: 'Chuyển khoản', kind: 'transfer', icon: '📱',
        bank_bin: settings.bank_bin || null,
        bank_account: settings.bank_account || null,
        bank_account_name: settings.bank_account_name || null,
        sort_order: 2,
      },
      {
        id: 'debt', name: 'Ghi nợ', kind: 'debt', icon: '📒',
        bank_bin: null, bank_account: null, bank_account_name: null, sort_order: 3,
      },
    ];
    for (const m of defaults) {
      batch.set(doc(db, 'payment_methods', m.id), { ...m, active: true });
    }
    await batch.commit();
  } catch (e) {
    throw toDbError(e);
  }
}

let pmCache: { at: number; all: PaymentMethodDef[] } | null = null;
export function clearPaymentMethodsCache(): void {
  pmCache = null;
}
export async function listPaymentMethods(activeOnly = true): Promise<PaymentMethodDef[]> {
  try {
    // Cache 10 phút — phương thức thanh toán ít khi đổi
    if (!pmCache || Date.now() - pmCache.at > 10 * 60 * 1000) {
      await ensurePaymentMethodsSeeded();
      const snap = await getDocs(collection(db, 'payment_methods'));
      const all = snap.docs.map((d) => toPaymentMethod(d.id, d.data()));
      all.sort((a, b) => a.sort_order - b.sort_order || a.name.localeCompare(b.name, 'vi'));
      pmCache = { at: Date.now(), all };
    }
    return activeOnly ? pmCache.all.filter((m) => m.active) : pmCache.all;
  } catch (e) {
    throw toDbError(e);
  }
}

/**
 * Đọc phương thức thanh toán cho trang công khai (/dat-hang).
 * KHÔNG gọi ensurePaymentMethodsSeeded: khách vãng lai không có quyền ghi
 * (rules chỉ cho chủ quán ghi payment_methods), nên seed sẽ lỗi permission-denied
 * và làm sập cả trang menu. Collection này đã được seed từ lần chủ quán mở app.
 */
export async function listPaymentMethodsPublic(): Promise<PaymentMethodDef[]> {
  try {
    const snap = await getDocs(collection(db, 'payment_methods'));
    const all = snap.docs.map((d) => toPaymentMethod(d.id, d.data()));
    const filtered = all.filter((m) => m.active);
    filtered.sort((a, b) => a.sort_order - b.sort_order || a.name.localeCompare(b.name, 'vi'));
    return filtered;
  } catch (e) {
    throw toDbError(e);
  }
}

export async function createPaymentMethod(d: {
  name: string;
  kind: PaymentMethodKind;
  icon?: string;
  bank_bin?: string | null;
  bank_account?: string | null;
  bank_account_name?: string | null;
}): Promise<PaymentMethodDef> {
  const name = String(d.name ?? '').trim();
  if (!name) throw new DbError('invalid-argument', 'Vui lòng nhập tên phương thức.');
  if (d.kind !== 'cash' && d.kind !== 'transfer' && d.kind !== 'debt') {
    throw new DbError('invalid-argument', 'Loại phương thức không hợp lệ.');
  }
  try {
    const snap = await getDocs(collection(db, 'payment_methods'));
    const sort_order = snap.docs.reduce((mx, x) => Math.max(mx, Number(x.data().sort_order ?? 0)), 0) + 1;
    const id = uuid();
    const data = {
      id,
      name,
      kind: d.kind,
      icon: String(d.icon ?? '').trim() || '💳',
      bank_bin: d.bank_bin?.trim() || null,
      bank_account: d.bank_account?.trim() || null,
      bank_account_name: d.bank_account_name?.trim() || null,
      active: true,
      sort_order,
    };
    await setDoc(doc(db, 'payment_methods', id), data);
    clearPaymentMethodsCache();
    return { ...data };
  } catch (e) {
    throw toDbError(e);
  }
}

export async function updatePaymentMethod(
  id: string,
  patch: Partial<Pick<PaymentMethodDef, 'name' | 'kind' | 'icon' | 'bank_bin' | 'bank_account' | 'bank_account_name' | 'active' | 'sort_order'>>,
): Promise<void> {
  const data: Record<string, unknown> = {};
  if (patch.name !== undefined) {
    const name = String(patch.name).trim();
    if (!name) throw new DbError('invalid-argument', 'Tên phương thức không được để trống.');
    data.name = name;
  }
  if (patch.kind !== undefined) {
    if (patch.kind !== 'cash' && patch.kind !== 'transfer' && patch.kind !== 'debt') {
      throw new DbError('invalid-argument', 'Loại phương thức không hợp lệ.');
    }
    data.kind = patch.kind;
  }
  if (patch.icon !== undefined) data.icon = String(patch.icon).trim() || '💳';
  if (patch.bank_bin !== undefined) data.bank_bin = patch.bank_bin?.trim() || null;
  if (patch.bank_account !== undefined) data.bank_account = patch.bank_account?.trim() || null;
  if (patch.bank_account_name !== undefined) data.bank_account_name = patch.bank_account_name?.trim() || null;
  if (patch.active !== undefined) data.active = patch.active === true;
  if (patch.sort_order !== undefined) data.sort_order = Number(patch.sort_order) || 0;
  if (Object.keys(data).length === 0) return;
  try {
    await updateDoc(doc(db, 'payment_methods', id), data);
    clearPaymentMethodsCache();
  } catch (e) {
    throw toDbError(e);
  }
}

// Phương thức hệ thống (cash/transfer/debt) chỉ được ẩn, không được xóa hẳn.
export async function deletePaymentMethod(id: string): Promise<void> {
  if (SYSTEM_METHOD_IDS.includes(id)) {
    throw new DbError('invalid-argument', 'Phương thức mặc định chỉ có thể Ẩn, không xóa được.');
  }
  try {
    await deleteDoc(doc(db, 'payment_methods', id));
    clearPaymentMethodsCache();
  } catch (e) {
    throw toDbError(e);
  }
}

export function isSystemPaymentMethod(id: string): boolean {
  return SYSTEM_METHOD_IDS.includes(id);
}

// ------------------------------------------------------------------ orders ---
export interface CreateOrderItemInput {
  productId: string;
  qty: number;
  modifierOptionIds?: string[];
  note?: string;
  comboId?: string | null;
  // Giảm giá riêng cho món này (v5.7): áp trên tổng dòng trước giảm giá toàn đơn
  discountType?: 'percent' | 'amount' | null;
  discountValue?: number | null;
}

export function validYMD(v: unknown): v is string {
  return typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v);
}

/** Parse chuỗi datetime (từ input datetime-local) → Date, hoặc null nếu không hợp lệ. */
export function parseISODateTime(v: unknown): Date | null {
  if (typeof v !== 'string' || !v.trim()) return null;
  const d = new Date(v.trim());
  return Number.isNaN(d.getTime()) ? null : d;
}

/** Chuỗi datetime-local (YYYY-MM-DDTHH:mm) cho input, giờ địa phương. */
export function toLocalDateTimeInput(d: Date = new Date()): string {
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
}

// ---- Thời gian nghiệp vụ của phiếu (v6.3) ----
// Vấn đề cũ: phiếu nhập/xuất chỉ lưu business_date YYYY-MM-DD, khoản quỹ gắn
// theo dùng parseISODateTime("YYYY-MM-DD") = 00:00 UTC = 07:00 giờ VN, nên mọi
// khoản quỹ của phiếu nhập/xuất đều mặc định 07:00 sáng dù phiếu lập giờ khác.
// Từ v6.3: phiếu nhập/xuất mang thêm thời gian thật (field tùy chọn
// business_datetime, ISO). datetime-local trong form được hiểu là giờ VN
// (Asia/Ho_Chi_Minh), không phụ thuộc múi giờ của máy đang mở app.

/** Đổi ISO datetime -> chuỗi datetime-local theo giờ VN (để nạp vào form sửa). */
export function isoToVNDateTimeInput(iso: string | null | undefined): string | null {
  if (typeof iso !== 'string' || !iso.trim()) return null;
  const d = new Date(iso.trim());
  if (Number.isNaN(d.getTime())) return null;
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Ho_Chi_Minh',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(d);
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? '';
  return `${get('year')}-${get('month')}-${get('day')}T${get('hour')}:${get('minute')}`;
}

/**
 * Parse chuỗi datetime-local (YYYY-MM-DDTHH:mm, hiểu là giờ VN) hoặc ISO có
 * múi giờ -> ISO string (UTC). Trả null nếu không hợp lệ.
 */
export function parseVNDateTimeInput(v: string | null | undefined): string | null {
  if (typeof v !== 'string' || !v.trim()) return null;
  const s = v.trim();
  const m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2}))?$/.exec(s);
  if (m) {
    const d = new Date(`${m[1]}-${m[2]}-${m[3]}T${m[4]}:${m[5]}:${m[6] ?? '00'}+07:00`);
    return Number.isNaN(d.getTime()) ? null : d.toISOString();
  }
  const d = new Date(s);
  return Number.isNaN(d.getTime()) ? null : d.toISOString();
}

/** Phần ngày YYYY-MM-DD của một chuỗi datetime-local/ISO (để suy business_date). */
export function datePartOfDateTimeInput(v: string | null | undefined): string | null {
  if (typeof v !== 'string' || !v.trim()) return null;
  const m = /^(\d{4}-\d{2}-\d{2})/.exec(v.trim());
  return m ? m[1] : null;
}

/**
 * Giải quyết thời gian của một phiếu từ input form.
 * - Có businessDateTime hợp lệ -> businessDate = phần ngày của nó, timeIso = giờ đó.
 * - Chỉ có businessDate -> businessDate đó, timeIso = null (người gọi tự quyết:
 *   tạo mới dùng giờ hiện tại, sửa mà không chạm giờ thì giữ nguyên giờ cũ).
 */
export function resolveSlipDateTime(input: {
  businessDate?: string | null;
  businessDateTime?: string | null;
}): { businessDate: string; timeIso: string | null } {
  const timeIso = parseVNDateTimeInput(input.businessDateTime);
  if (timeIso) {
    const datePart = datePartOfDateTimeInput(input.businessDateTime);
    return { businessDate: datePart && validYMD(datePart) ? datePart : todayVN(), timeIso };
  }
  return { businessDate: validYMD(input.businessDate) ? (input.businessDate as string) : todayVN(), timeIso: null };
}

export interface CreateOrderInput {
  clientUuid: string;
  customerId: string | null;
  items: CreateOrderItemInput[];
  paymentMethod: PaymentMethod;
  /** Thanh toán hỗn hợp: nhiều phần [{methodId, amount}]; tổng phải bằng tổng đơn (±1đ). */
  payments?: Array<{ methodId: string; amount: number }>;
  amountReceived?: number | null;
  note?: string | null;
  warehouseId?: string | null; // kho trừ tồn khi bán (multi-kho); null = kho mặc định
  discountType?: 'percent' | 'amount' | null;
  discountValue?: number | null;
  discountLabel?: string | null;
  shippingFee?: number | null; // phí ship cộng vào tổng đơn (v5.15)
  voucherCode?: string | null; // mã voucher (ưu tiên hơn giảm giá tay)
  businessDate?: string | null; // YYYY-MM-DD — ngày lập hóa đơn (mặc định: hôm nay)
  createdAt?: string | null; // ISO datetime — thời gian lập hóa đơn (mặc định: bây giờ)
  source?: 'pos' | 'online'; // mặc định 'pos'
  onlineName?: string | null;
  onlinePhone?: string | null;
}

/**
 * Tính tiền giảm giá từ subtotal. Trả về số tiền giảm (>= 0, không vượt subtotal).
 */
export function calcDiscount(
  subtotal: number,
  type: 'percent' | 'amount' | null | undefined,
  value: number | null | undefined,
): number {
  return discountAmountFor(subtotal, type, value);
}

/**
 * Chọn kho để trừ tồn khi bán: ưu tiên kho POS đang chọn, kiểm tra quyền,
 * rớt về kho mặc định. Chủ quán chưa có kho nào → tự tạo kho mặc định.
 */
async function resolveSaleWarehouse(
  requestedId: string | null,
): Promise<{ warehouseId: string; warehouseName: string }> {
  const me = await getMyProfile();
  const privileged = me.role === 'owner'; // CHỈ chủ quán thấy mọi kho
  let ws = await listWarehouses();
  if (privileged && ws.length === 0) ws = await ensureWarehousesSeeded();
  const allowed = privileged ? ws : ws.filter((w) => me.warehouse_ids.includes(w.id));
  if (allowed.length === 0) {
    throw new DbError(
      'permission-denied',
      'Tài khoản chưa được gán kho nào. Nhờ chủ quán vào Cài đặt → Nhân viên để gán kho.',
    );
  }
  const pick =
    (requestedId ? allowed.find((w) => w.id === requestedId) : undefined) ??
    allowed.find((w) => w.is_default) ??
    allowed[0];
  return { warehouseId: pick.id, warehouseName: pick.name };
}

interface CatalogMaps {
  products: Map<string, Record<string, unknown>>;
  groups: Map<string, Record<string, unknown>>;
  options: Map<string, Record<string, unknown>>;
  combos: Map<string, Record<string, unknown>>;
}

let catalogCache: { at: number; maps: CatalogMaps } | null = null;
export function clearCatalogCache(): void {
  catalogCache = null;
}
async function loadCatalog(): Promise<CatalogMaps> {
  // Cache 10 phút — menu ít khi đổi trong ca bán
  if (catalogCache && Date.now() - catalogCache.at < 10 * 60 * 1000) {
    return catalogCache.maps;
  }
  const [pSnap, gSnap, oSnap, cSnap] = await Promise.all([
    getDocs(collection(db, 'products')),
    getDocs(collection(db, 'modifierGroups')),
    getDocs(collection(db, 'modifierOptions')),
    getDocs(collection(db, 'combos')),
  ]);
  const maps: CatalogMaps = {
    products: new Map(pSnap.docs.map((d) => [d.id, d.data()])),
    groups: new Map(gSnap.docs.map((d) => [d.id, d.data()])),
    options: new Map(oSnap.docs.map((d) => [d.id, d.data()])),
    combos: new Map(cSnap.docs.map((d) => [d.id, d.data()])),
  };
  catalogCache = { at: Date.now(), maps };
  return maps;
}

// Tính giá client-side — mirror backend lib/pricing.js#calculateOrderPricing.
// Snapshot mỗi dòng gồm option_id (theo schema orders.items của bản Firebase).
function priceOrderLines(items: CreateOrderItemInput[], catalog: CatalogMaps) {
  const lines = items.map((item, idx) => {
    const n = idx + 1;
    // Combo: giá cố định, trừ tồn theo định lượng gộp của các món thành phần
    const comboId = typeof item.comboId === 'string' && item.comboId ? item.comboId : null;
    if (comboId) {
      const combo = catalog.combos.get(comboId) as (Record<string, unknown> & { id?: string }) | undefined;
      if (!combo) throw new DbError('invalid-argument', `Món thứ ${n}: combo không tồn tại.`);
      if (combo.active === false) {
        throw new DbError('invalid-argument', `Món thứ ${n}: combo "${String(combo.name)}" hiện không bán.`);
      }
      const qty = Number(item.qty);
      if (!Number.isInteger(qty) || qty < 1 || qty > 99) {
        throw new DbError('invalid-argument', `Món thứ ${n}: số lượng phải là số nguyên từ 1 đến 99.`);
      }
      const compItems = Array.isArray(combo.items) ? combo.items as Record<string, unknown>[] : [];
      if (compItems.length === 0) throw new DbError('invalid-argument', `Món thứ ${n}: combo chưa có món nào.`);
      // Gộp định lượng nguyên liệu của các món thành phần
      const merged = new Map<string, { ingredient_id: string; qty: number }>();
      const compNames: string[] = [];
      let comboCost = 0;
      for (const ci of compItems) {
        const pid = String(ci.product_id ?? '');
        const cqty = Math.max(1, Number(ci.qty ?? 1));
        const prod = catalog.products.get(pid);
        if (!prod) throw new DbError('invalid-argument', `Món thứ ${n}: món trong combo không tồn tại.`);
        compNames.push(`${cqty}× ${String(prod.name ?? ci.product_name ?? '')}`);
        // Snapshot giá vốn combo = tổng giá vốn các món thành phần (trước v5.2
        // để 0 cố định nên báo cáo tính giá vốn combo bằng 0, lãi combo bị phồng)
        comboCost += Math.max(0, Math.round(Number(prod.cost_price) || 0)) * cqty;
        for (const r of sanitizeRecipe(prod.recipe)) {
          const ex = merged.get(r.ingredient_id);
          if (ex) ex.qty += r.qty * cqty;
          else merged.set(r.ingredient_id, { ingredient_id: r.ingredient_id, qty: r.qty * cqty });
        }
      }
      const unit_price = Math.max(0, Math.round(Number(combo.price) || 0));
      const gross = unit_price * qty;
      const lineDiscount = calcDiscount(gross, item.discountType, item.discountValue);
      return {
        id: uuid(),
        product_id: String(combo.id ?? comboId),
        product_name: String(combo.name),
        is_combo: true,
        combo_items: compNames,
        qty,
        unit_price,
        cost_price: comboCost,
        recipe: [...merged.values()],
        modifiers: [],
        discount: lineDiscount,
        discount_type: lineDiscount > 0 ? (item.discountType ?? null) : null,
        discount_value: lineDiscount > 0 ? Math.round(Number(item.discountValue) || 0) : null,
        line_total: gross - lineDiscount,
        note: typeof item.note === 'string' && item.note ? item.note.slice(0, 500) : undefined,
      };
    }
    const product = catalog.products.get(item.productId);
    if (!product) throw new DbError('invalid-argument', `Món thứ ${n}: sản phẩm không tồn tại.`);
    if (product.active === false) {
      throw new DbError('invalid-argument', `Món thứ ${n}: "${String(product.name)}" hiện không bán.`);
    }
    const qty = Number(item.qty);
    if (!Number.isInteger(qty) || qty < 1 || qty > 99) {
      throw new DbError('invalid-argument', `Món thứ ${n}: số lượng phải là số nguyên từ 1 đến 99.`);
    }
    const optionIds = Array.isArray(item.modifierOptionIds) ? item.modifierOptionIds : [];
    const byGroup = new Map<string, { group: Record<string, unknown>; opts: Record<string, unknown>[] }>();
    for (const optId of optionIds) {
      const opt = catalog.options.get(optId) as (Record<string, unknown> & { id?: string }) | undefined;
      if (!opt) throw new DbError('invalid-argument', `Món thứ ${n}: tùy chọn không tồn tại.`);
      if (opt.active === false) {
        throw new DbError('invalid-argument', `Món thứ ${n}: tùy chọn "${String(opt.name)}" đã ngừng dùng.`);
      }
      const group = catalog.groups.get(String(opt.group_id));
      if (!group) throw new DbError('invalid-argument', `Món thứ ${n}: nhóm tùy chọn không tồn tại.`);
      if (group.active === false) {
        throw new DbError('invalid-argument', `Món thứ ${n}: nhóm "${String(group.name)}" đã ngừng dùng.`);
      }
      const gid = String(opt.group_id);
      const entry = byGroup.get(gid) ?? { group, opts: [] };
      entry.opts.push({ ...opt, id: optId });
      byGroup.set(gid, entry);
    }
    const modifiers: SelectedModifier[] = [];
    for (const { group, opts } of byGroup.values()) {
      if (group.selection_type === 'single' && opts.length > 1) {
        throw new DbError(
          'invalid-argument',
          `Món thứ ${n}: nhóm "${String(group.name)}" chỉ được chọn 1 tùy chọn.`,
        );
      }
      for (const opt of opts) {
        modifiers.push({
          option_id: String(opt.id ?? ''),
          group: String(group.name),
          option: String(opt.name),
          price_delta: Number(opt.price_delta) || 0,
        });
      }
    }
    // Nhóm bắt buộc (VD: Size) phải được chọn — riêng group Size phải chọn đúng 1 option
    for (const [gid, group] of catalog.groups) {
      if (group.required === true && group.active !== false && !byGroup.has(gid)) {
        throw new DbError('invalid-argument', `Món thứ ${n}: Vui lòng chọn ${String(group.name)}.`);
      }
    }
    const unit_price =
      Number(product.base_price) + modifiers.reduce((s, m) => s + m.price_delta, 0);
    const gross = unit_price * qty;
    // Giam gia rieng cua mon (v5.7): tinh tren tong dong, truoc giam gia toan don
    const lineDiscount = calcDiscount(gross, item.discountType, item.discountValue);
    const line_total = gross - lineDiscount;
    // Định lượng theo biến thể (Pro) — ngữ nghĩa từ v5.5:
    // - Nhóm chính (nhóm bắt buộc + chọn 1, VD Size): nếu option có định lượng
    //   riêng thì THAY THẾ định lượng gốc của món.
    // - Mọi option còn lại (topping thêm...): định lượng riêng CỘNG THÊM vào
    //   định lượng gốc (hoặc vào định lượng đã thay thế của nhóm chính).
    // Bản cũ: chỉ cần 1 option bất kỳ có định lượng riêng là mất toàn bộ định
    // lượng gốc; nhiều nhóm có định lượng riêng thì cộng dồn trùng lặp.
    const variantRecipes = product.variant_recipes as Record<string, unknown> | undefined;
    let lineRecipe: RecipeItem[];
    if (variantRecipes && typeof variantRecipes === 'object') {
      let primaryGroupId: string | null = null;
      for (const [gid, entry] of byGroup) {
        if (entry.group.required === true && entry.group.selection_type === 'single') {
          primaryGroupId = gid;
          break;
        }
      }
      let base: RecipeItem[] = sanitizeRecipe(product.recipe);
      if (primaryGroupId) {
        for (const o of byGroup.get(primaryGroupId)?.opts ?? []) {
          const vr = variantRecipes[String(o.id ?? '')];
          if (Array.isArray(vr)) base = sanitizeRecipe(vr);
        }
      }
      const merged = new Map<string, number>();
      for (const r of base) merged.set(r.ingredient_id, (merged.get(r.ingredient_id) ?? 0) + r.qty);
      for (const [gid, entry] of byGroup) {
        if (gid === primaryGroupId) continue;
        for (const o of entry.opts) {
          const vr = variantRecipes[String(o.id ?? '')];
          if (Array.isArray(vr)) {
            for (const r of sanitizeRecipe(vr)) {
              merged.set(r.ingredient_id, (merged.get(r.ingredient_id) ?? 0) + r.qty);
            }
          }
        }
      }
      lineRecipe = [...merged.entries()].map(([ingredient_id, qty]) => ({ ingredient_id, qty }));
    } else {
      lineRecipe = sanitizeRecipe(product.recipe);
    }
    return {
      id: uuid(),
      product_id: String(product.id ?? item.productId),
      product_name: String(product.name),
      qty,
      unit_price,
      cost_price: Math.max(0, Math.round(Number(product.cost_price) || 0)),
      recipe: lineRecipe,
      modifiers,
      discount: lineDiscount,
      discount_type: lineDiscount > 0 ? (item.discountType ?? null) : null,
      discount_value: lineDiscount > 0 ? Math.round(Number(item.discountValue) || 0) : null,
      line_total,
      note: typeof item.note === 'string' && item.note ? item.note.slice(0, 500) : undefined,
    };
  });
  const subtotal = lines.reduce((s, l) => s + l.line_total, 0);
  return { lines, subtotal, discount: 0, total: subtotal };
}

// Kiểm tra tiền mặt — mirror backend lib/pricing.js#calculateChange
function checkCash(kind: PaymentMethodKind, total: number, amountReceived?: number | null) {
  if (kind === 'cash') {
    const got = Number(amountReceived);
    if (!Number.isInteger(got) || got <= 0) {
      throw new DbError('invalid-argument', 'Tiền mặt: vui lòng nhập số tiền khách đưa.');
    }
    if (got < total) {
      throw new DbError(
        'invalid-argument',
        `Tiền khách đưa (${got}) nhỏ hơn tổng tiền (${total}).`,
      );
    }
    return { amount_received: got, change_amount: got - total };
  }
  return { amount_received: null, change_amount: null };
}

/** Cấu hình tích điểm & hạng thành viên (settings). */
export interface LoyaltyConfig {
  points_rate: number; // đ / 1 điểm
  silver_at: number; // tổng chi để lên Bạc
  gold_at: number; // tổng chi để lên Vàng
  silver_discount: number; // % giảm hạng Bạc
  gold_discount: number; // % giảm hạng Vàng
}

export async function getLoyaltyConfig(): Promise<LoyaltyConfig> {
  try {
    const [r, s, g, sd, gd] = await Promise.all([
      getDoc(doc(db, 'settings', 'loyalty_points_rate')),
      getDoc(doc(db, 'settings', 'loyalty_silver_at')),
      getDoc(doc(db, 'settings', 'loyalty_gold_at')),
      getDoc(doc(db, 'settings', 'loyalty_silver_discount')),
      getDoc(doc(db, 'settings', 'loyalty_gold_discount')),
    ]);
    const num = (snap: unknown, def: number) => {
      const v = Number((snap as { exists: () => boolean; data: () => Record<string, unknown> }).exists() ? ((snap as { data: () => Record<string, unknown> }).data().value ?? def) : def);
      return Number.isFinite(v) && v >= 0 ? Math.round(v) : def;
    };
    return {
      points_rate: Math.max(1000, num(r, 10000)),
      silver_at: num(s, 1000000),
      gold_at: Math.max(num(s, 1000000), num(g, 5000000)),
      silver_discount: Math.min(100, num(sd, 3)),
      gold_discount: Math.min(100, num(gd, 5)),
    };
  } catch {
    return { points_rate: 10000, silver_at: 1000000, gold_at: 5000000, silver_discount: 3, gold_discount: 5 };
  }
}

export type MemberTier = 'member' | 'silver' | 'gold';

export function tierFor(totalSpent: number, cfg: LoyaltyConfig): MemberTier {
  if (totalSpent >= cfg.gold_at) return 'gold';
  if (totalSpent >= cfg.silver_at) return 'silver';
  return 'member';
}

export function tierDiscount(tier: MemberTier, cfg: LoyaltyConfig): number {
  return tier === 'gold' ? cfg.gold_discount : tier === 'silver' ? cfg.silver_discount : 0;
}

export const TIER_LABEL: Record<MemberTier, string> = {
  member: 'Thành viên',
  silver: '🥈 Bạc',
  gold: '🥇 Vàng',
};

export async function createOrder(input: CreateOrderInput): Promise<Order> {
  const clientUuid = String(input.clientUuid ?? '').trim();
  if (!clientUuid) throw new DbError('invalid-argument', 'Thiếu clientUuid (mã chống trùng đơn).');
  if (clientUuid.length > 100) throw new DbError('invalid-argument', 'clientUuid quá dài.');
  if (!Array.isArray(input.items) || input.items.length === 0) {
    throw new DbError('invalid-argument', 'Đơn hàng phải có ít nhất một món.');
  }
  if (input.items.length > 50) {
    throw new DbError('invalid-argument', 'Đơn hàng vượt quá 50 dòng món.');
  }
  const methodId = String(input.paymentMethod ?? '').trim();
  if (!methodId) throw new DbError('invalid-argument', 'Thiếu phương thức thanh toán.');
  const isOnline = input.source === 'online';
  const onlineName = typeof input.onlineName === 'string' ? input.onlineName.trim().slice(0, 50) : '';
  const onlinePhone = typeof input.onlinePhone === 'string' ? input.onlinePhone.trim().slice(0, 20) : '';

  try {
    // 1. Idempotent: đơn đã tồn tại → trả về luôn
    const orderRef = doc(db, 'orders', clientUuid);
    const existing = await getDoc(orderRef);
    if (existing.exists()) {
      const o = orderFromDoc(existing);
      if (o) return o;
    }

    // 2. Tính giá client-side từ catalog (không tin giá client gửi) + kiểm tra phương thức
    const [catalog, methods] = await Promise.all([loadCatalog(), listPaymentMethods(true)]);
    const method = methods.find((m) => m.id === methodId);
    if (!method) throw new DbError('invalid-argument', 'Phương thức thanh toán không hợp lệ hoặc đã bị ẩn.');
    const kind = method.kind;
    const pricing = priceOrderLines(input.items, catalog);
    const businessDate0 = validYMD(input.businessDate) ? (input.businessDate as string) : todayVN();
    // Voucher (nếu có) được ưu tiên hơn giảm giá tay; kiểm tra lại trong transaction + trừ lượt dùng.
    let voucher: Voucher | null = null;
    let voucherRef: ReturnType<typeof doc> | null = null;
    const vCode = typeof input.voucherCode === 'string' ? input.voucherCode.trim().toLowerCase() : '';
    if (vCode) {
      voucherRef = doc(db, 'vouchers', vCode);
      voucher = voucherFromDoc(await getDoc(voucherRef));
      if (!voucher) throw new DbError('invalid-argument', 'Mã voucher không tồn tại.');
      const vErr = validateVoucher(voucher, pricing.subtotal, businessDate0);
      if (vErr) throw new DbError('invalid-argument', vErr);
    }
    const discountAmount = voucher
      ? calcVoucherDiscount(pricing.subtotal, voucher)
      : isOnline
        ? 0
        : calcDiscount(pricing.subtotal, input.discountType, input.discountValue);
    // Phí ship (v5.15): cộng vào tổng sau giảm giá; trần 10 triệu chặn gõ nhầm.
    const shippingFee = Math.max(0, Math.min(10_000_000, Math.round(Number(input.shippingFee) || 0)));
    const finalTotal = pricing.subtotal - discountAmount + shippingFee;
    const discountLabel = voucher
      ? `Voucher ${voucher.code}`
      : isOnline
        ? null
        : typeof input.discountLabel === 'string' && input.discountLabel.trim()
          ? input.discountLabel.trim().slice(0, 100)
          : null;
    // Thanh toán hỗn hợp: resolve từng phần [{methodId, amount}]
    const splitMode = Array.isArray(input.payments) && input.payments.length > 0;
    const splits: Array<{ def: PaymentMethodDef; amount: number }> = [];
    let debtTotal = 0;
    if (splitMode) {
      if ((input.payments as Array<{ methodId: string; amount: number }>).length > 10) {
        throw new DbError('invalid-argument', 'Tối đa 10 phần thanh toán trên 1 đơn.');
      }
      let sum = 0;
      for (const sp of input.payments as Array<{ methodId: string; amount: number }>) {
        const amt = Math.round(Number(sp.amount) || 0);
        if (amt <= 0) throw new DbError('invalid-argument', 'Số tiền mỗi phần thanh toán phải lớn hơn 0.');
        const def = methods.find((m) => m.id === String(sp.methodId ?? ''));
        if (!def) throw new DbError('invalid-argument', 'Phương thức thanh toán không hợp lệ hoặc đã bị ẩn.');
        splits.push({ def, amount: amt });
        sum += amt;
      }
      if (Math.abs(sum - finalTotal) > 1) {
        throw new DbError(
          'invalid-argument',
          `Tổng các phần thanh toán (${sum}đ) phải bằng tổng đơn (${finalTotal}đ).`,
        );
      }
      debtTotal = splits.filter((x) => x.def.kind === 'debt').reduce((a, x) => a + x.amount, 0);
    } else {
      splits.push({ def: method, amount: finalTotal });
      debtTotal = kind === 'debt' ? finalTotal : 0;
    }
    const cash = splitMode
      ? { amount_received: null as number | null, change_amount: null as number | null }
      : checkCash(kind, finalTotal, input.amountReceived);
    const business_date = businessDate0;
    const customCreated = parseISODateTime(input.createdAt); // null = dùng giờ server
    const createdBy = auth.currentUser?.uid ?? null;
    const note = typeof input.note === 'string' && input.note ? input.note.slice(0, 1000) : null;
    const customerId = input.customerId ?? null;
    const loyaltyCfgPre = customerId ? await getLoyaltyConfig().catch(() => null) : null;
    const pointsEarned = loyaltyCfgPre ? Math.floor(finalTotal / loyaltyCfgPre.points_rate) : 0;
    if (debtTotal > 0 && !customerId) {
      throw new DbError('invalid-argument', 'Ghi nợ cần chọn khách hàng cho đơn này.');
    }

    // Kho bán: trừ tồn ở kho POS đang chọn (kiểm tra quyền, rớt về kho mặc định)
    const { warehouseId, warehouseName } = await resolveSaleWarehouse(
      typeof input.warehouseId === 'string' ? input.warehouseId : null,
    );

    // Tính số thứ tự toàn cục cho mã đơn (làm trước transaction vì cần query)
    const globalSeqStart = await nextGlobalSeq('order_seq', 'A', 'orders');

    // 3. Transaction: mã đơn đánh số liên tục + ghi đơn + tích tem + cộng công nợ + trừ kho
    // NGUYÊN TẮC Firestore: mọi tx.get() phải xong trước mọi tx.set()/update()/delete().
    await runTransaction(db, async (tx) => {
      // ---- PHASE 1: đọc ----
      // Đua idempotency trong transaction: đơn đã có → bỏ qua ghi
      const oSnap = await tx.get(orderRef);
      if (oSnap.exists()) return;

      // Mã đơn đánh số liên tục toàn hệ thống (không reset theo ngày để tránh trùng mã)
      const counterRef = doc(db, 'counters', 'order_seq');
      const cSnap = await tx.get(counterRef);
      // Dùng max(gía trị trong tx, giá trị tính trước) để tránh đua
      const txNext = cSnap.exists() ? Number((cSnap.data() as Record<string, unknown>).last ?? 0) + 1 : 1;
      const next = Math.max(txNext, globalSeqStart);
      const code = 'A' + String(next).padStart(3, '0');
      // Ghi counter ở PHASE 2 (sau mọi lệnh đọc) — không ghi ở đây để tránh lỗi transaction.

      let stampUpdate: { stamps: number; reward_available?: boolean } | null = null;
      let rewardTriggered = false;
      let debtAfter = -1;
      let loyaltyCfg: LoyaltyConfig | null = null;
      let custSnapForLoyalty: Awaited<ReturnType<typeof tx.get>> | null = null;
      if (customerId) loyaltyCfg = loyaltyCfgPre;
      if (customerId) {
        const custRef = doc(db, 'customers', customerId);
        const custSnap = await tx.get(custRef);
        if (!custSnap.exists()) throw new DbError('invalid-argument', 'Khách hàng không tồn tại.');
        custSnapForLoyalty = custSnap;
        const setSnap = await tx.get(doc(db, 'settings', 'stamps_target'));
        const target = Number(setSnap.exists() ? (setSnap.data() as Record<string, unknown>).value : 9) || 9;
        const stamps = Number((custSnap.data() as Record<string, unknown>).stamps ?? 0) + 1;
        rewardTriggered = stamps >= target;
        stampUpdate = rewardTriggered ? { stamps: 0, reward_available: true } : { stamps };
        if (debtTotal > 0) debtAfter = Number((custSnap.data() as Record<string, unknown>).debt ?? 0) + debtTotal;
      }

      // Voucher: đọc lại trong transaction để trừ lượt dùng an toàn
      let voucherSnap: Awaited<ReturnType<typeof tx.get>> | null = null;
      if (voucherRef) voucherSnap = await tx.get(voucherRef);

      // Tồn kho: đọc trước toàn bộ mức tồn tại kho bán
      const needs = calcNeeds(pricing.lines);
      const stockState = new Map<string, StockState>();
      if (needs.size > 0) {
        const ids = [...needs.keys()];
        const [lSnaps, iSnaps] = await Promise.all([
          Promise.all(ids.map((ingId) => tx.get(doc(db, 'stock_levels', stockLevelId(warehouseId, ingId))))),
          Promise.all(ids.map((ingId) => tx.get(doc(db, 'ingredients', ingId)))),
        ]);
        ids.forEach((ingId, i) => {
          const lSnap = lSnaps[i];
          const iSnap = iSnaps[i];
          if (!iSnap.exists()) return; // nguyên liệu đã bị xóa → bỏ qua
          const lData = (lSnap.exists() ? lSnap.data() : {}) as Record<string, unknown>;
          stockState.set(ingId, {
            stock: Number(lData.stock ?? 0),
            name:
              String(lData.ingredient_name ?? '') ||
              String((iSnap.data() as Record<string, unknown>).name ?? ''),
          });
        });
      }

      // ---- PHASE 2: ghi ----
      if (cSnap.exists()) tx.update(counterRef, { last: next });
      else tx.set(counterRef, { last: next });

      tx.set(orderRef, {
        id: clientUuid,
        client_uuid: clientUuid,
        code,
        business_date,
        customer_id: customerId,
        status: 'new',
        payment_method: splits[0].def.id,
        payment_method_name: splits[0].def.name,
        ...(splitMode
          ? {
              payments: splits.map((sp) => ({
                method_id: sp.def.id,
                method_name: sp.def.name,
                kind: sp.def.kind,
                amount: sp.amount,
              })),
            }
          : {}),
        warehouse_id: warehouseId,
        warehouse_name: warehouseName,
        subtotal: pricing.subtotal,
        discount: discountAmount,
        discount_type: input.discountType ?? null,
        discount_value: input.discountType ? Math.round(Number(input.discountValue) || 0) : null,
        discount_label: discountLabel,
        shipping_fee: shippingFee,
        total: finalTotal,
        amount_received: cash.amount_received,
        change_amount: cash.change_amount,
        note,
        voucher_code: voucher ? voucher.code : null,
        points_earned: pointsEarned,
        source: isOnline ? 'online' : 'pos',
        online_name: isOnline ? onlineName : null,
        online_phone: isOnline ? onlinePhone : null,
        reward_triggered: rewardTriggered,
        created_by: createdBy,
        created_at: customCreated ? customCreated.toISOString() : new Date().toISOString(),
        items: pricing.lines.map((l) => ({
          id: l.id,
          order_id: clientUuid,
          product_id: l.product_id,
          product_name: l.product_name,
          qty: l.qty,
          unit_price: l.unit_price,
          cost_price: l.cost_price,
          recipe: l.recipe,
          modifiers: l.modifiers,
          line_total: l.line_total,
          ...(l.note ? { note: l.note } : {}),
        })),
      });

      // Trừ tồn kho nguyên liệu theo định lượng món tại kho bán
      // (cho phép tồn âm → cảnh báo ở màn Tồn kho)
      writeStockMoves(tx, {
        warehouseId,
        warehouseName,
        needs,
        state: stockState,
        sign: -1,
        note: `Bán đơn ${code}`,
        ref_type: 'order',
        ref_id: clientUuid,
        createdBy,
      });

      if (customerId) {
        const custUpdate: Record<string, unknown> = {};
        if (stampUpdate) Object.assign(custUpdate, stampUpdate);
        if (debtAfter >= 0) {
          custUpdate.debt = debtAfter;
          const logRef = doc(collection(db, 'customers', customerId, 'debt_logs'));
          tx.set(logRef, {
            id: logRef.id,
            amount: debtTotal,
            balance_after: debtAfter,
            note: `Ghi nợ đơn ${code}`,
            order_code: code,
            order_id: clientUuid,
            created_by: createdBy,
            created_at: customCreated ? customCreated.toISOString() : new Date().toISOString(),
          });
        }
        // Tích điểm & hạng thành viên
        if (loyaltyCfg && custSnapForLoyalty && custSnapForLoyalty.exists()) {
          const cd = custSnapForLoyalty.data() as Record<string, unknown>;
          const newSpent = Math.max(0, Number(cd.total_spent ?? 0)) + finalTotal;
          custUpdate.points = Math.max(0, Number(cd.points ?? 0)) + pointsEarned;
          custUpdate.total_spent = newSpent;
          custUpdate.tier = tierFor(newSpent, loyaltyCfg);
        }
        if (Object.keys(custUpdate).length > 0) {
          tx.update(doc(db, 'customers', customerId), custUpdate);
        }
      }

      // Voucher: kiểm tra lại + trừ lượt dùng (atomic)
      if (voucherRef && voucherSnap && voucher) {
        const vd = voucherSnap.data() as Record<string, unknown>;
        if (!voucherSnap.exists()) throw new DbError('invalid-argument', 'Voucher không còn tồn tại.');
        if (vd.active === false) throw new DbError('invalid-argument', 'Voucher đã bị tắt.');
        const used = Number(vd.used_count ?? 0);
        const lim = vd.usage_limit == null ? null : Number(vd.usage_limit);
        if (lim != null && used >= lim) throw new DbError('invalid-argument', 'Voucher đã hết lượt sử dụng.');
        tx.update(voucherRef, { used_count: increment(1) });
      }

      // Sổ quỹ: mỗi phần đã thu (tiền mặt/chuyển khoản) → 1 khoản thu "Doanh thu bán hàng" riêng.
      // Phần ghi nợ chưa thu tiền nên KHÔNG ghi. Id doc fund cố định theo đơn để idempotent.
      // Đơn cũ trước tính năng này không backfill.
      splits
        .filter((sp) => sp.def.kind === 'cash' || sp.def.kind === 'transfer')
        .forEach((sp, i) => {
          const fundRef = doc(db, 'cashbook_entries', splitMode ? `fund_${clientUuid}_${i}` : `fund_${clientUuid}`);
          tx.set(fundRef, {
            id: fundRef.id,
            type: 'thu',
            amount: sp.amount,
            note: splitMode ? `Doanh thu bán hàng (${sp.def.name})` : 'Doanh thu bán hàng',
            category: 'Bán hàng',
            fund_id: sp.def.id, // mỗi phương thức thanh toán (trừ ghi nợ) là một quỹ
            ref_type: 'order',
            ref_id: clientUuid,
            ref_code: code,
            method: sp.def.kind,
            warehouse_id: warehouseId,
            created_by: createdBy,
            created_at: customCreated ? customCreated.toISOString() : new Date().toISOString(),
          });
        });
    });

    // 4. Đọc lại → Timestamp → ISO string
    const after = await getDoc(orderRef);
    const order = orderFromDoc(after);
    if (!order) throw new DbError('unknown', 'Không đọc được đơn vừa tạo.');
    return order;
  } catch (e) {
    throw toDbError(e);
  }
}

export async function getOrder(id: string): Promise<Order | null> {
  try {
    return orderFromDoc(await getDoc(doc(db, 'orders', id)));
  } catch (e) {
    throw toDbError(e);
  }
}

export async function listOrdersByDate(date: string, limitN?: number, warehouseIds?: string[] | null): Promise<Order[]> {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    throw new DbError('invalid-argument', 'Tham số date phải có dạng YYYY-MM-DD.');
  }
  const n = Math.min(Math.max(limitN ?? 100, 1), 500);
  try {
    const snap = await getDocs(
      query(
        collection(db, 'orders'),
        where('business_date', '==', date),
        orderBy('created_at', 'desc'),
        limit(n),
      ),
    );
    return snap.docs
      .map((d) => orderFromDoc(d))
      .filter((o): o is Order => o !== null)
      .filter((o) => orderInScope(o, warehouseIds));
  } catch (e) {
    throw toDbError(e);
  }
}

// new → preparing → ready → done; bất kỳ trạng thái nào (trừ done/cancelled) → cancelled
const ORDER_FLOW: Record<OrderStatus, OrderStatus[]> = {
  new: ['preparing'],
  preparing: ['ready'],
  ready: ['done'],
  done: [],
  cancelled: [],
};

/** Quy + kho cua khoan "Thu no" gan nhat cua khach — de phieu chi hoan
 *  tien (khi xoa/huy don ghi no) tru dung quy da nhan tien. Query chi dung
 *  1 dieu kien ref_id (khong orderBy) de khong can composite index moi,
 *  loc ref_type va chon moi nhat o client. Query loi -> null (mac dinh
 *  quy tien mat). Sua 25/10/2026. */
async function getLatestDebtPaySource(
  customerId: string,
): Promise<{ fundId: string; warehouseId: string | null } | null> {
  try {
    const snap = await getDocs(
      query(collection(db, 'cashbook_entries'), where('ref_id', '==', customerId), limit(50)),
    );
    let best: { created: string; fundId: string; warehouseId: string | null } | null = null;
    for (const d of snap.docs) {
      const data = d.data() as Record<string, unknown>;
      if (data.ref_type !== 'debt_pay') continue;
      const created = tsToIso(data.created_at);
      const fundId = typeof data.fund_id === 'string' && data.fund_id ? data.fund_id : 'cash';
      const warehouseId = typeof data.warehouse_id === 'string' && data.warehouse_id ? data.warehouse_id : null;
      if (!best || created >= best.created) best = { created, fundId, warehouseId };
    }
    return best ? { fundId: best.fundId, warehouseId: best.warehouseId } : null;
  } catch {
    return null;
  }
}

/**
 * Phat lai tien thu no theo tung don (FIFO) tu debt_logs cua khach.
 * Quy tac: tien thu no duoc tinh cho don no CU NHAT truoc.
 * - Log "Ghi nợ đơn X": tang outstanding[X].
 * - Log "Hoàn nợ do ... đơn X": giam outstanding[X], KHONG tinh la tien da tra.
 * - Log thu no (amount am, khong phai hoan no): phan bo theo FIFO cho cac
 *   don con outstanding theo thu tu don tao truoc, ghi paid[X].
 * - Log dieu chinh no khong gan don (amount duong): bucket chung, chi giam
 *   khi phan bo thua sau cac don (khong anh huong paid cua don).
 * - Log phai thu phieu xuat ("Phải thu phiếu xuất..." / "Thu phải thu..."):
 *   bo qua o day vi phai thu xuat duoc theo doi rieng tren phieu, khong
 *   phai tien tra cho don ban hang.
 * Log moi co order_code/order_id thi dung field do; log cu thi tach ma don
 * tu note ("Ghi nợ đơn X", "Hoàn nợ do hủy/xóa/sửa đơn X").
 * Tra ve { paid, found }: found = false khi khong co log ghi no nao cho don
 * nay (du lieu thieu) -> caller fallback ve cong thuc cu, khong hoan sai so.
 */
export interface DebtLogRaw {
  amount: number;
  note: string | null;
  order_code?: string | null;
  order_id?: string | null;
  created_at: string;
}

function debtLogOrderKey(log: DebtLogRaw): string | null {
  if (log.order_code) return log.order_code;
  if (log.order_id) return log.order_id;
  const note = log.note ?? '';
  const m1 = note.match(/^Ghi nợ đơn\s+(\S+)/);
  if (m1) return m1[1];
  const m2 = note.match(/Hoàn nợ do \S+ đơn\s+(\S+)/);
  if (m2) return m2[1];
  return null;
}

export function allocateOrderDebtPaid(
  logs: DebtLogRaw[],
  orderCode: string,
  orderId: string,
): { paid: number; found: boolean } {
  const ordered = [...logs].sort((a, b) => (a.created_at < b.created_at ? -1 : a.created_at > b.created_at ? 1 : 0));
  const outstanding = new Map<string, number>();
  const paid = new Map<string, number>();
  const seen = new Set<string>();
  let commonOutstanding = 0;
  for (const log of ordered) {
    const note = log.note ?? '';
    // Phai thu phieu xuat theo doi rieng, khong lan vao no don ban hang.
    if (note.startsWith('Phải thu phiếu xuất') || note.startsWith('Thu phải thu')) continue;
    const amt = Number(log.amount ?? 0);
    if (note.startsWith('Ghi nợ đơn')) {
      const key = debtLogOrderKey(log);
      if (!key) continue;
      seen.add(key);
      outstanding.set(key, (outstanding.get(key) ?? 0) + amt);
    } else if (note.includes('Hoàn nợ')) {
      const key = debtLogOrderKey(log);
      if (!key) continue;
      seen.add(key);
      outstanding.set(key, Math.max(0, (outstanding.get(key) ?? 0) + amt));
    } else if (amt < 0) {
      // Tien thu: phan bo FIFO cho cac don con outstanding, theo thu tu
      // don xuat hien lan dau trong log (don tao truoc duoc tra truoc).
      let pay = -amt;
      for (const key of [...outstanding.keys()]) {
        if (pay <= 0) break;
        const avail = outstanding.get(key) ?? 0;
        if (avail <= 0) continue;
        const take = Math.min(pay, avail);
        outstanding.set(key, avail - take);
        paid.set(key, (paid.get(key) ?? 0) + take);
        pay -= take;
      }
      if (pay > 0) commonOutstanding = Math.max(0, commonOutstanding - pay);
    } else if (amt > 0) {
      commonOutstanding += amt;
    }
  }
  const targetKey = orderCode || orderId;
  const byCode = paid.get(orderCode) ?? 0;
  const byId = orderId && orderId !== orderCode ? (paid.get(orderId) ?? 0) : 0;
  return { paid: byCode + byId, found: seen.has(targetKey) || seen.has(orderCode) || (orderId !== '' && seen.has(orderId)) };
}

/** Tai toan bo debt_logs cua khach theo thu tu thoi gian tang dan (phan trang). */
async function fetchDebtLogsAsc(customerId: string): Promise<DebtLogRaw[]> {
  const out: DebtLogRaw[] = [];
  let last: unknown = null;
  for (let page = 0; page < 20; page++) {
    const q =
      last == null
        ? query(collection(db, 'customers', customerId, 'debt_logs'), orderBy('created_at', 'asc'), limit(500))
        : query(
            collection(db, 'customers', customerId, 'debt_logs'),
            orderBy('created_at', 'asc'),
            limit(500),
            startAfter(last as never),
          );
    const snap = await getDocs(q);
    if (snap.docs.length === 0) break;
    for (const d of snap.docs) {
      const data = d.data() as Record<string, unknown>;
      out.push({
        amount: Number(data.amount ?? 0),
        note: (data.note as string | null) ?? null,
        order_code: (data.order_code as string | null) ?? null,
        order_id: (data.order_id as string | null) ?? null,
        created_at: tsToIso(data.created_at),
      });
    }
    last = snap.docs[snap.docs.length - 1];
    if (snap.docs.length < 500) break;
  }
  return out;
}

export async function updateOrderStatus(id: string, status: OrderStatus): Promise<Order> {
  const valid: OrderStatus[] = ['new', 'preparing', 'ready', 'done', 'cancelled'];
  if (!valid.includes(status)) {
    throw new DbError('invalid-argument', `Trạng thái "${status}" không hợp lệ.`);
  }
  try {
    const ref = doc(db, 'orders', id);
    const snap = await getDoc(ref);
    const current = orderFromDoc(snap);
    if (!current) throw new DbError('not-found', 'Đơn hàng không tồn tại.');
    const from = current.status;
    if (from !== status) {
      const forwardOk = (ORDER_FLOW[from] ?? []).includes(status);
      const cancelOk = status === 'cancelled' && from !== 'done' && from !== 'cancelled';
      if (!forwardOk && !cancelOk) {
        throw new DbError(
          'invalid-argument',
          `Không thể chuyển đơn từ trạng thái "${from}" sang "${status}".`,
        );
      }
      if (status === 'cancelled') {
        // Hủy đơn → hoàn tác TOÀN BỘ như xóa đơn (chỉ khác: giữ lại đơn ở trạng
        // thái cancelled thay vì xóa hẳn): hoàn tồn kho, XÓA khoản quỹ của đơn,
        // hoàn công nợ / tem / điểm / hạng cho khách.
        // Trước v5.2 nhánh này chỉ hoàn tồn kho, nên khoản thu "Doanh thu bán
        // hàng" vẫn nằm trong Sổ Quỹ và nợ của khách vẫn còn dù báo cáo đã loại
        // đơn hủy khỏi doanh thu — hai phía lệch nhau đúng bằng giá trị đơn hủy.
        const fallbackWid = await getDefaultWarehouseId();
        // Query khoản quỹ của đơn TRƯỚC transaction (tx.get không hỗ trợ Query)
        let fundRefs: Array<ReturnType<typeof doc>> = [];
        try {
          const orphanSnap = await getDocs(
            query(collection(db, 'cashbook_entries'), where('ref_id', '==', id), limit(50)),
          );
          fundRefs = orphanSnap.docs
            .filter((d) => (d.data() as Record<string, unknown>).ref_type === 'order')
            .map((d) => d.ref);
        } catch {
          /* query thất bại thì fallback xóa fund_<id> trong tx */
        }
        // SUA 25/10/2026: quy/kho cua khoan thu no gan nhat de lam phieu
        // chi hoan tien (neu don ghi no da thu mot phan).
        const refundSource = current.customer_id
          ? await getLatestDebtPaySource(current.customer_id)
          : null;
        // Phat lai FIFO tien thu no theo tung don (neu query loi thi fallback
        // ve cong thuc cu trong transaction, khong chan huy don).
        let debtAllocation: { paid: number; found: boolean } | null = null;
        if (current.customer_id) {
          try {
            const logs = await fetchDebtLogsAsc(current.customer_id);
            debtAllocation = allocateOrderDebtPaid(logs, current.code, current.id);
          } catch {
            debtAllocation = null;
          }
        }
        let cancelledCode = current.code;
        await runTransaction(db, async (tx) => {
          // PHASE 1: đọc
          const s = await tx.get(ref);
          const o = orderFromDoc(s);
          if (!o) throw new DbError('not-found', 'Không tìm thấy đơn hàng.');
          if (o.status === 'cancelled') return;
          cancelledCode = o.code;

          // Hoàn công nợ nếu đơn ghi nợ (toàn phần hoặc 1 phần của thanh toán hỗn hợp)
          const orderSplits = orderPaymentSplits(o);
          let orderDebtTotal = 0;
          if (o.payments && o.payments.length > 0) {
            orderDebtTotal = orderSplits.filter((sp) => sp.kind === 'debt').reduce((a, sp) => a + sp.amount, 0);
          } else {
            const methodSnap = await tx.get(doc(db, 'payment_methods', o.payment_method));
            const kind = methodSnap.exists() ? String((methodSnap.data() as Record<string, unknown>).kind ?? '') : '';
            if (kind === 'debt') orderDebtTotal = o.total;
          }
          let custRef: ReturnType<typeof doc> | null = null;
          let cSnap: Awaited<ReturnType<typeof tx.get>> | null = null;
          let stampTarget = 9;
          let cancelLoyaltyCfg: LoyaltyConfig | null = null;
          if (o.customer_id) {
            custRef = doc(db, 'customers', o.customer_id);
            cSnap = await tx.get(custRef);
            const setSnap = await tx.get(doc(db, 'settings', 'stamps_target'));
            stampTarget =
              Number((setSnap.exists() ? (setSnap.data() as Record<string, unknown>).value : 9) ?? 9) || 9;
            cancelLoyaltyCfg = await getLoyaltyConfig().catch(() => null);
          }
          const isDebtOrder = orderDebtTotal > 0 && o.customer_id;

          // Lượt voucher của đơn — đọc ở pha đọc để hoàn lượt khi hủy (trước đây
          // hủy/xóa đơn không hoàn lượt, voucher hết hạn mức sớm hơn thực tế).
          const vCode = String(o.voucher_code ?? '').trim().toLowerCase();
          const vRef = vCode ? doc(db, 'vouchers', vCode) : null;
          const vSnap = vRef ? await tx.get(vRef) : null;

          // Tồn kho cần hoàn (đọc trước) — về đúng kho của đơn
          const restoreWid = o.warehouse_id ?? fallbackWid;
          const { needs, state } = restoreWid
            ? await readStockState(tx, o, restoreWid)
            : { needs: new Map<string, number>(), state: new Map<string, StockState>() };

          // PHASE 2: ghi
          if (custRef && cSnap && cSnap.exists()) {
            const cData = cSnap.data() as Record<string, unknown>;
            const custUpdate: Record<string, unknown> = {};
            if (isDebtOrder) {
              const curDebt = Number(cData.debt ?? 0);
              // HOAN TIEN THEO TUNG DON (FIFO): tien thu tinh cho don no cu
              // nhat truoc. Vi du don A 100 + don B 100, da thu 40 -> 40
              // tinh cho A. Huy A: hoan no 60 + phieu chi hoan 40, con no
              // B 100. Huy B truoc: hoan no 100, hoan tien 0 (40 da tinh
              // cho A). Neu khong phat lai duoc (khong co log ghi no cho
              // don nay) thi fallback ve cong thuc cu, khong hoan sai so.
              let reverse: number;
              let refundAmount: number;
              if (debtAllocation && debtAllocation.found) {
                const paidDon = Math.min(Math.max(debtAllocation.paid, 0), orderDebtTotal);
                const outstandingDon = Math.max(0, orderDebtTotal - paidDon);
                reverse = Math.min(outstandingDon, Math.max(curDebt, 0));
                refundAmount = paidDon;
              } else {
                reverse = Math.min(orderDebtTotal, Math.max(curDebt, 0));
                refundAmount = Math.max(0, orderDebtTotal - curDebt);
              }
              if (reverse > 0) {
                const next = curDebt - reverse;
                custUpdate.debt = next;
                const logRef = doc(collection(db, 'customers', o.customer_id as string, 'debt_logs'));
                tx.set(logRef, {
                  id: logRef.id,
                  amount: -reverse,
                  balance_after: next,
                  note: `Hoàn nợ do hủy đơn ${o.code}`,
                  order_code: o.code,
                  order_id: o.id,
                  created_by: auth.currentUser?.uid ?? null,
                  created_at: serverTimestamp(),
                });
              }
              if (refundAmount > 0) {
                const fundRef = doc(collection(db, 'cashbook_entries'));
                tx.set(fundRef, {
                  id: fundRef.id,
                  type: 'chi',
                  amount: refundAmount,
                  note: `Hoàn tiền thu nợ do hủy đơn ${o.code} — trả lại tiền khách đã trả cho đơn này`,
                  category: 'Hoàn tiền nợ',
                  fund_id: refundSource?.fundId ?? 'cash',
                  ref_type: 'debt_refund',
                  ref_id: o.customer_id,
                  method: null,
                  created_by: auth.currentUser?.uid ?? null,
                  warehouse_id: refundSource?.warehouseId ?? null,
                  created_at: new Date().toISOString(),
                });
              }
            }
            // Hoàn tem tích điểm — cùng quy tắc với xóa đơn
            const curStamps = Number(cData.stamps ?? 0);
            const hasReward = cData.reward_available === true;
            const triggered = o.reward_triggered || (curStamps === 0 && hasReward);
            if (triggered && hasReward) {
              custUpdate.stamps = Math.max(0, stampTarget - 1);
              custUpdate.reward_available = false;
            } else if (!triggered) {
              custUpdate.stamps = Math.max(0, curStamps - 1);
            }
            // Hoàn điểm tích & tổng chi (tính lại hạng)
            if (cancelLoyaltyCfg) {
              const newSpent = Math.max(0, Number(cData.total_spent ?? 0) - o.total);
              custUpdate.points = Math.max(0, Number(cData.points ?? 0) - o.points_earned);
              custUpdate.total_spent = newSpent;
              custUpdate.tier = tierFor(newSpent, cancelLoyaltyCfg);
            }
            if (Object.keys(custUpdate).length > 0) tx.update(custRef, custUpdate);
          }

          // Hoàn lượt voucher đã trừ lúc tạo đơn
          if (vRef && vSnap && vSnap.exists()) {
            const usedNow = Number((vSnap.data() as Record<string, unknown>).used_count ?? 0);
            if (usedNow > 0) tx.update(vRef, { used_count: usedNow - 1 });
          }

          // Xóa khoản quỹ tự động của đơn (gồm cả split entries của thanh toán hỗn hợp)
          for (const r of fundRefs) tx.delete(r);
          tx.delete(doc(db, 'cashbook_entries', `fund_${o.id}`));

          tx.update(ref, { status });
          if (restoreWid) {
            writeStockMoves(tx, {
              warehouseId: restoreWid,
              warehouseName: o.warehouse_name ?? current?.warehouse_name ?? null,
              needs,
              state,
              sign: 1,
              note: `Hủy đơn ${o.code}`,
              ref_type: 'order',
              ref_id: o.id,
              createdBy: auth.currentUser?.uid ?? null,
            });
          }
        });
        logAudit('order.cancel', `Hủy đơn ${cancelledCode}`, { type: 'order', id });
      } else {
        await updateDoc(ref, { status });
      }
    }
    const after = orderFromDoc(await getDoc(ref));
    if (!after) throw new DbError('not-found', 'Đơn hàng không tồn tại.');
    return after;
  } catch (e) {
    throw toDbError(e);
  }
}

// --------------------------------------------------------------- đơn hàng ---
export interface ListOrdersOpts {
  from: string; // YYYY-MM-DD
  to: string; // YYYY-MM-DD
  limitN?: number;
  warehouseIds?: string[] | null; // giới hạn đơn theo kho được phép xem
}

/** Liệt kê đơn theo khoảng ngày (mới nhất trước). Lọc theo mã đơn/khách làm ở client.
 *  v5.19: KHÔNG còn cắt ngầm 300 đơn mới nhất — khi không truyền limitN, hàm
 *  phân trang tải HẾT đơn trong khoảng (trước đây quán vượt 300 đơn là các đơn
 *  cũ nhất biến mất khỏi trang Đơn hàng dù dữ liệu còn nguyên — sự cố 24/10). */
export async function listOrders(opts: ListOrdersOpts): Promise<Order[]> {
  const { from, to } = opts;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(from) || !/^\d{4}-\d{2}-\d{2}$/.test(to)) {
    throw new DbError('invalid-argument', 'Khoảng ngày không hợp lệ.');
  }
  try {
    const docs: QueryDocumentSnapshot[] = [];
    if (opts.limitN != null) {
      const n = Math.min(Math.max(opts.limitN, 1), 1000);
      const snap = await getDocs(
        query(
          collection(db, 'orders'),
          where('business_date', '>=', from),
          where('business_date', '<=', to),
          orderBy('business_date', 'desc'),
          limit(n),
        ),
      );
      docs.push(...snap.docs);
    } else {
      const PAGE = 500;
      let last: unknown = null;
      for (let page = 0; page < 40; page++) {
        const qq =
          last == null
            ? query(
                collection(db, 'orders'),
                where('business_date', '>=', from),
                where('business_date', '<=', to),
                orderBy('business_date', 'desc'),
                limit(PAGE),
              )
            : query(
                collection(db, 'orders'),
                where('business_date', '>=', from),
                where('business_date', '<=', to),
                orderBy('business_date', 'desc'),
                limit(PAGE),
                startAfter(last as never),
              );
        const snap = await getDocs(qq);
        if (snap.docs.length === 0) break;
        docs.push(...snap.docs);
        last = snap.docs[snap.docs.length - 1];
        if (snap.docs.length < PAGE) break;
      }
    }
    const list = docs
      .map((d) => orderFromDoc(d))
      .filter((o): o is Order => o !== null)
      .filter((o) => orderInScope(o, opts.warehouseIds));
    list.sort((a, b) => (a.created_at < b.created_at ? 1 : -1));
    return list;
  } catch (e) {
    throw toDbError(e);
  }
}

/**
 * Sửa đơn đã bán — CHỈ cho sửa ghi chú + khách hàng (không sửa món/giá để báo cáo không sai).
 * Rules phía server cũng chỉ cho phép 3 field: status, note, customer_id.
 */
export async function updateOrderMeta(
  id: string,
  patch: { note?: string | null; customerId?: string | null },
): Promise<Order> {
  // Đổi khách trên đơn ĐÃ gắn khách bị chặn: nợ/tem/điểm/tổng chi của đơn đang
  // nằm ở khách cũ, gán thẳng khách mới làm sai cả hai phía (và lần hủy/xóa
  // sau này sẽ hoàn nhầm người). Muốn đổi khách: hủy đơn và tạo lại.
  if (patch.customerId !== undefined) {
    const cur0 = await getOrder(id);
    if (!cur0) throw new DbError('not-found', 'Đơn hàng không tồn tại.');
    const newCid = patch.customerId ? String(patch.customerId) : null;
    if (newCid !== cur0.customer_id && cur0.customer_id) {
      throw new DbError(
        'invalid-argument',
        'Đơn này đã gắn khách và đã tích tem/điểm (có thể cả ghi nợ) cho khách đó — không đổi khách trực tiếp được. Hãy hủy đơn và tạo lại nếu cần đổi khách.',
      );
    }
  }
  const data: Record<string, unknown> = {};
  if (patch.note !== undefined) {
    const n = typeof patch.note === 'string' ? patch.note.trim() : '';
    data.note = n ? n.slice(0, 1000) : null;
  }
  if (patch.customerId !== undefined) {
    const cid = patch.customerId ? String(patch.customerId) : null;
    if (cid) {
      const cSnap = await getDoc(doc(db, 'customers', cid));
      if (!cSnap.exists()) throw new DbError('not-found', 'Khách hàng không tồn tại.');
    }
    data.customer_id = cid;
  }
  if (Object.keys(data).length === 0) {
    const cur = await getOrder(id);
    if (!cur) throw new DbError('not-found', 'Đơn hàng không tồn tại.');
    return cur;
  }
  try {
    await updateDoc(doc(db, 'orders', id), data);
    const after = await getOrder(id);
    if (!after) throw new DbError('not-found', 'Đơn hàng không tồn tại.');
    logAudit('order.edit', `Sửa đơn ${after.code} (${Object.keys(data).join(', ')})`, { type: 'order', id });
    return after;
  } catch (e) {
    throw toDbError(e);
  }
}

/**
 * Xóa đơn đã bán — chỉ chủ quán (rules + UI đều chặn nhân viên).
 * - Đơn ghi nợ → hoàn công nợ tương ứng (ghi log "Hoàn nợ do xóa đơn A001").
 * - Xóa luôn khoản quỹ tự động của đơn (cashbook_entries/fund_<orderId>).
 * - Tem tích điểm KHÔNG hoàn (không có đường hoàn sạch khi đã đổi thưởng/reset tem).
 */
export async function deleteOrder(id: string): Promise<void> {
  // Đơn cũ chưa có kho → hoàn về kho mặc định hiện tại (đọc trước transaction)
  const fallbackWid = await getDefaultWarehouseId();
  // Query các khoản quỹ liên quan TRƯỚC transaction (tx.get không hỗ trợ Query) —
  // gồm fund_<id> và split entries fund_<id>_0/1 của thanh toán hỗn hợp
  let fundRefs: Array<ReturnType<typeof doc>> = [];
  try {
    const orphanSnap = await getDocs(
      query(collection(db, 'cashbook_entries'), where('ref_id', '==', id), limit(50)),
    );
    fundRefs = orphanSnap.docs
      .filter((d) => (d.data() as Record<string, unknown>).ref_type === 'order')
      .map((d) => d.ref);
  } catch {
    /* query thất bại thì fallback xóa fund_<id> trong tx */
  }
  // SUA 25/10/2026: quy/kho cua khoan thu no gan nhat de lam phieu chi
  // hoan tien (can biet khach truoc transaction vi query khong chay
  // trong tx; doc truoc chi de xac dinh quy, khong anh huong logic tx).
  let refundSource: { fundId: string; warehouseId: string | null } | null = null;
  let debtAllocation: { paid: number; found: boolean } | null = null;
  try {
    const preSnap = await getDoc(doc(db, 'orders', id));
    const preCustomerId = preSnap.exists()
      ? ((preSnap.data() as Record<string, unknown>).customer_id as string | null)
      : null;
    if (preCustomerId) {
      refundSource = await getLatestDebtPaySource(preCustomerId);
      try {
        const logs = await fetchDebtLogsAsc(preCustomerId);
        const preCode = String((preSnap.data() as Record<string, unknown>).code ?? '');
        debtAllocation = allocateOrderDebtPaid(logs, preCode, id);
      } catch {
        debtAllocation = null;
      }
    }
  } catch {
    /* khong xac dinh duoc quy -> mac dinh tien mat trong tx */
  }
  let deletedCode = id;
  try {
    await runTransaction(db, async (tx) => {
      // ---- PHASE 1: đọc ----
      const orderRef = doc(db, 'orders', id);
      const oSnap = await tx.get(orderRef);
      const order = oSnap.exists() ? orderFromDoc(oSnap) : null;
      if (!order) throw new DbError('not-found', 'Đơn hàng không tồn tại.');
      deletedCode = order.code;

      // Hoàn công nợ nếu đơn ghi nợ (toàn phần hoặc 1 phần của thanh toán hỗn hợp)
      const orderSplits = orderPaymentSplits(order);
      let orderDebtTotal = 0;
      if (order.payments && order.payments.length > 0) {
        orderDebtTotal = orderSplits.filter((sp) => sp.kind === 'debt').reduce((a, sp) => a + sp.amount, 0);
      } else {
        const methodSnap = await tx.get(doc(db, 'payment_methods', order.payment_method));
        const kind = methodSnap.exists() ? String((methodSnap.data() as Record<string, unknown>).kind ?? '') : '';
        if (kind === 'debt') orderDebtTotal = order.total;
      }
      let custRef: ReturnType<typeof doc> | null = null;
      let cSnap: Awaited<ReturnType<typeof tx.get>> | null = null;
      let stampTarget = 9;
      let delLoyaltyCfg: LoyaltyConfig | null = null;
      if (order.customer_id) {
        custRef = doc(db, 'customers', order.customer_id);
        cSnap = await tx.get(custRef);
        const setSnap = await tx.get(doc(db, 'settings', 'stamps_target'));
        stampTarget =
          Number((setSnap.exists() ? (setSnap.data() as Record<string, unknown>).value : 9) ?? 9) || 9;
        delLoyaltyCfg = await getLoyaltyConfig().catch(() => null);
      }
      const isDebtOrder = orderDebtTotal > 0 && order.customer_id;

      // Tồn kho cần hoàn (đọc trước)
      const restoreWid = order.warehouse_id ?? fallbackWid;
      const { needs, state } = restoreWid
        ? await readStockState(tx, order, restoreWid)
        : { needs: new Map<string, number>(), state: new Map<string, StockState>() };

      // Lượt voucher của đơn — đọc ở pha đọc để hoàn lượt khi xóa
      const vCode = String(order.voucher_code ?? '').trim().toLowerCase();
      const vRef = vCode ? doc(db, 'vouchers', vCode) : null;
      const vSnap = vRef ? await tx.get(vRef) : null;

      // ---- PHASE 2: ghi ----
      if (order.status === 'cancelled') {
        // Đơn ĐÃ hủy: lúc hủy đã hoàn tác toàn bộ (kho, quỹ, nợ, tem, điểm,
        // voucher). Xóa tiếp mà hoàn tác lần nữa sẽ cộng kho thừa, trừ tem/nợ
        // oan. Chỉ xóa document đơn + khoản quỹ còn sót nếu có.
        for (const r of fundRefs) tx.delete(r);
        tx.delete(doc(db, 'cashbook_entries', `fund_${order.id}`));
        tx.delete(orderRef);
        return;
      }
      if (custRef && cSnap && cSnap.exists()) {
        const cData = cSnap.data() as Record<string, unknown>;
        const custUpdate: Record<string, unknown> = {};
        // Hoàn công nợ nếu đơn ghi nợ — theo tung don (FIFO, giong nhanh huy)
        if (isDebtOrder) {
          const curDebt = Number(cData.debt ?? 0);
          let reverse: number;
          let refundAmount: number;
          if (debtAllocation && debtAllocation.found) {
            const paidDon = Math.min(Math.max(debtAllocation.paid, 0), orderDebtTotal);
            const outstandingDon = Math.max(0, orderDebtTotal - paidDon);
            reverse = Math.min(outstandingDon, Math.max(curDebt, 0));
            refundAmount = paidDon;
          } else {
            reverse = Math.min(orderDebtTotal, Math.max(curDebt, 0));
            refundAmount = Math.max(0, orderDebtTotal - curDebt);
          }
          if (reverse > 0) {
            const next = curDebt - reverse;
            custUpdate.debt = next;
            const logRef = doc(collection(db, 'customers', order.customer_id as string, 'debt_logs'));
            tx.set(logRef, {
              id: logRef.id,
              amount: -reverse,
              balance_after: next,
              note: `Hoàn nợ do xóa đơn ${order.code}`,
              order_code: order.code,
              order_id: order.id,
              created_by: auth.currentUser?.uid ?? null,
              created_at: serverTimestamp(),
            });
          }
          // Don da huy roi thi nhanh early-return o tren da tra ve truoc,
          // nen khong hoan tien lan hai.
          if (refundAmount > 0) {
            const fundRef = doc(collection(db, 'cashbook_entries'));
            tx.set(fundRef, {
              id: fundRef.id,
              type: 'chi',
              amount: refundAmount,
              note: `Hoàn tiền thu nợ do xóa đơn ${order.code} — trả lại tiền khách đã trả cho đơn này`,
              category: 'Hoàn tiền nợ',
              fund_id: refundSource?.fundId ?? 'cash',
              ref_type: 'debt_refund',
              ref_id: order.customer_id,
              method: null,
              created_by: auth.currentUser?.uid ?? null,
              warehouse_id: refundSource?.warehouseId ?? null,
              created_at: new Date().toISOString(),
            });
          }
        }
        // Hoàn tem tích điểm: đơn đã cộng 1 tem → xóa đơn trừ lại.
        // - Đơn kích hoạt thưởng và khách chưa đổi → thu hồi: tem về mốc-1, tắt thưởng.
        // - Đơn kích hoạt thưởng nhưng khách đã đổi → giữ nguyên (tem đã đổi thành quà).
        // - Còn lại → trừ 1 tem (không âm).
        const curStamps = Number(cData.stamps ?? 0);
        const hasReward = cData.reward_available === true;
        // Đơn mới có cờ reward_triggered chính xác; đơn cũ suy luận: đang 0 tem + có thưởng chưa đổi
        // thì đơn này (hoặc đơn gần nhất) đã kích hoạt thưởng.
        const triggered = order.reward_triggered || (curStamps === 0 && hasReward);
        if (triggered && hasReward) {
          custUpdate.stamps = Math.max(0, stampTarget - 1);
          custUpdate.reward_available = false;
        } else if (!triggered) {
          custUpdate.stamps = Math.max(0, curStamps - 1);
        }
        // Hoàn điểm tích & tổng chi (tính lại hạng)
        if (delLoyaltyCfg) {
          const newSpent = Math.max(0, Number(cData.total_spent ?? 0) - order.total);
          custUpdate.points = Math.max(0, Number(cData.points ?? 0) - order.points_earned);
          custUpdate.total_spent = newSpent;
          custUpdate.tier = tierFor(newSpent, delLoyaltyCfg);
        }
        if (Object.keys(custUpdate).length > 0) tx.update(custRef, custUpdate);
      }

      // Hoàn lượt voucher đã trừ lúc tạo đơn
      if (vRef && vSnap && vSnap.exists()) {
        const usedNow = Number((vSnap.data() as Record<string, unknown>).used_count ?? 0);
        if (usedNow > 0) tx.update(vRef, { used_count: usedNow - 1 });
      }

      // Xóa khoản quỹ tự động của đơn (nếu có) — gồm cả split entries fund_<id>_0/1
      // của thanh toán hỗn hợp (đã query trước transaction; fallback fund_<id>)
      for (const r of fundRefs) tx.delete(r);
      tx.delete(doc(db, 'cashbook_entries', `fund_${order.id}`));

      // Hoàn lại tồn kho đã trừ lúc bán, về đúng kho của đơn
      if (restoreWid) {
        writeStockMoves(tx, {
          warehouseId: restoreWid,
          warehouseName: order.warehouse_name,
          needs,
          state,
          sign: 1,
          note: `Xóa đơn ${order.code}`,
          ref_type: 'order',
          ref_id: order.id,
          createdBy: auth.currentUser?.uid ?? null,
        });
      }

      tx.delete(orderRef);
    });
    logAudit('order.delete', `Xóa đơn ${deletedCode}`, { type: 'order', id });
    // (Các khoản quỹ của đơn đã được xóa trong transaction ở trên,
    //  gồm cả split entries của thanh toán hỗn hợp.)
  } catch (e) {
    throw toDbError(e);
  }
}


// ================= SỬA TOÀN BỘ ĐƠN HÀNG =================
/**
 * Sửa toàn bộ đơn hàng đã bán: món, số lượng, giảm giá, voucher, phương thức
 * thanh toán, khách hàng, ghi chú (chỉ chủ quán — UI chặn, rules kiểm tra lại).
 * Không cho sửa đơn đã hủy.
 *
 * Trong 1 transaction:
 * - Hoàn tác cái cũ: cộng lại tồn đã trừ, xóa khoản quỹ fund_<id>, hoàn công nợ
 *   (nếu đơn cũ ghi nợ), hoàn tem/điểm/hạng, hoàn lượt dùng voucher cũ.
 * - Áp cái mới: tính giá lại từ catalog, trừ tồn mới, ghi khoản quỹ mới, cộng
 *   công nợ (nếu thanh toán mới là ghi nợ), cộng tem/điểm/hạng, trừ lượt voucher mới.
 * - Giữ nguyên: id, code, business_date, status, created_by, created_at, source.
 */
export interface UpdateOrderFullInput {
  items: CreateOrderItemInput[];
  paymentMethod: string;
  customerId: string | null;
  note?: string | null;
  discountType?: 'percent' | 'amount' | null;
  discountValue?: number | null;
  shippingFee?: number | null; // phí ship cộng vào tổng đơn (v5.15)
  voucherCode?: string | null;
  warehouseId?: string | null;
  amountReceived?: number | null;
  /** v6.3: chuỗi datetime-local (giờ VN) mới của đơn; null = không đổi giờ. */
  businessDateTime?: string | null;
}

export async function updateOrderFull(id: string, input: UpdateOrderFullInput): Promise<Order> {
  const items = input.items ?? [];
  if (!Array.isArray(items) || items.length === 0) {
    throw new DbError('invalid-argument', 'Đơn hàng phải có ít nhất một món.');
  }
  if (items.length > 50) throw new DbError('invalid-argument', 'Đơn hàng vượt quá 50 dòng món.');
  const methodId = String(input.paymentMethod ?? '').trim();
  if (!methodId) throw new DbError('invalid-argument', 'Thiếu phương thức thanh toán.');
  const customerId = input.customerId ?? null;
  const vCodeNew = typeof input.voucherCode === 'string' ? input.voucherCode.trim().toLowerCase() : '';

  try {
    // ---- Tính giá mới ngoài transaction (dùng cache) ----
    const [catalog, methods] = await Promise.all([loadCatalog(), listPaymentMethods(true)]);
    const method = methods.find((m) => m.id === methodId);
    if (!method) throw new DbError('invalid-argument', 'Phương thức thanh toán không hợp lệ hoặc đã bị ẩn.');
    const newKind = method.kind;
    const pricing = priceOrderLines(items, catalog);
    let voucherNew: Voucher | null = null;
    if (vCodeNew) {
      voucherNew = await getVoucherByCode(vCodeNew);
      if (!voucherNew) throw new DbError('invalid-argument', 'Mã voucher không tồn tại.');
      const vErr = validateVoucher(voucherNew, pricing.subtotal, todayVN());
      if (vErr) throw new DbError('invalid-argument', vErr);
    }
    const discountAmount = voucherNew
      ? calcVoucherDiscount(pricing.subtotal, voucherNew)
      : calcDiscount(pricing.subtotal, input.discountType, input.discountValue);
    // Phí ship (v5.15): giữ/sửa theo form sửa đơn gửi lên.
    const shippingFee = Math.max(0, Math.min(10_000_000, Math.round(Number(input.shippingFee) || 0)));
    const finalTotal = pricing.subtotal - discountAmount + shippingFee;
    const cash = checkCash(newKind, finalTotal, input.amountReceived);
    if (newKind === 'debt' && !customerId) {
      throw new DbError('invalid-argument', 'Ghi nợ cần chọn khách hàng cho đơn này.');
    }
    // Nạp cấu hình tích điểm KHÔNG điều kiện: kể cả khi sửa đơn thành khách lẻ
    // (bỏ khách) vẫn phải hoàn điểm/tổng chi cho khách cũ — bản cũ chỉ nạp khi
    // còn khách mới nên bỏ khách là điểm của khách cũ kẹt vĩnh viễn.
    const loyaltyCfgPre = await getLoyaltyConfig().catch(() => null);
    const pointsEarnedNew = customerId && loyaltyCfgPre ? Math.floor(finalTotal / loyaltyCfgPre.points_rate) : 0;
    const { warehouseId: newWid, warehouseName: newWName } = await resolveSaleWarehouse(
      typeof input.warehouseId === 'string' ? input.warehouseId : null,
    );
    const fallbackWid = await getDefaultWarehouseId();
    const note = typeof input.note === 'string' && input.note ? input.note.slice(0, 1000) : null;
    const discountLabel = voucherNew ? `Voucher ${voucherNew.code}` : null;
    const discType = voucherNew ? null : (input.discountType ?? null);
    const discValue = voucherNew || !input.discountType ? null : Math.round(Number(input.discountValue) || 0);
    // v6.3: giờ mới chỉ khi form sửa gửi businessDateTime; null = giữ nguyên
    // ngày + giờ gốc của đơn (không chạm business_date/created_at/khoản quỹ).
    const newOrderTimeIso = parseVNDateTimeInput(input.businessDateTime);
    const newOrderBusinessDate = newOrderTimeIso
      ? (datePartOfDateTimeInput(input.businessDateTime) ?? null)
      : null;

    // Khoản quỹ mồ côi đời cũ (ref_id trùng nhưng id doc không phải fund_<id>) → xóa trong tx
    let legacyFundRefs: Array<ReturnType<typeof doc>> = [];
    try {
      const orphans = await getDocs(
        query(collection(db, 'cashbook_entries'), where('ref_id', '==', id), limit(20)),
      );
      legacyFundRefs = orphans.docs
        .filter(
          (d) =>
            d.id !== `fund_${id}` && (d.data() as Record<string, unknown>).ref_type === 'order',
        )
        .map((d) => d.ref);
    } catch {
      /* bỏ qua */
    }

    let rewardTriggeredNew = false;

    await runTransaction(db, async (tx) => {
      // ---- PHASE 1: đọc ----
      const orderRef = doc(db, 'orders', id);
      const oSnap = await tx.get(orderRef);
      const order = oSnap.exists() ? orderFromDoc(oSnap) : null;
      if (!order) throw new DbError('not-found', 'Đơn hàng không tồn tại.');
      if (order.status === 'cancelled') throw new DbError('invalid-argument', 'Không thể sửa đơn đã hủy.');

      const oldMethodSnap = await tx.get(doc(db, 'payment_methods', order.payment_method));
      const oldKind = oldMethodSnap.exists()
        ? String((oldMethodSnap.data() as Record<string, unknown>).kind ?? '')
        : '';
      // Nợ của đơn cũ tính từ các phần thanh toán (đơn hỗn hợp có thể chỉ nợ
      // MỘT PHẦN) — bản cũ chỉ nhìn phương thức chính: chính là tiền mặt mà có
      // phần ghi nợ thì không hoàn nợ; chính là ghi nợ mà nợ một phần thì hoàn
      // theo cả tổng đơn, trừ oan vào nợ khác của khách.
      const oldDebtTotal = order.payments && order.payments.length > 0
        ? orderPaymentSplits(order).filter((sp) => sp.kind === 'debt').reduce((a, sp) => a + sp.amount, 0)
        : oldKind === 'debt' ? order.total : 0;
      const oldCustId = order.customer_id;
      const custIds = [...new Set([oldCustId, customerId].filter((x): x is string => !!x))];
      const cSnaps = new Map<string, Awaited<ReturnType<typeof tx.get>>>();
      for (const cid of custIds) cSnaps.set(cid, await tx.get(doc(db, 'customers', cid)));
      if (customerId && !cSnaps.get(customerId)?.exists()) {
        throw new DbError('not-found', 'Khách hàng không tồn tại.');
      }
      const setSnap = await tx.get(doc(db, 'settings', 'stamps_target'));
      const stampTarget =
        Number((setSnap.exists() ? (setSnap.data() as Record<string, unknown>).value : 9) ?? 9) || 9;
      const loyaltyCfg = loyaltyCfgPre;

      // Tồn kho cũ cần hoàn (về đúng kho của đơn)
      const restoreWid = order.warehouse_id ?? fallbackWid;
      const oldStock = restoreWid
        ? await readStockState(tx, order, restoreWid)
        : { needs: new Map<string, number>(), state: new Map<string, StockState>() };

      // Tồn kho mới cần trừ — đọc mức tồn tại kho mới
      const newNeeds = calcNeeds(pricing.lines);
      const newState = new Map<string, StockState>();
      if (newNeeds.size > 0) {
        const ids = [...newNeeds.keys()];
        const [lSnaps, iSnaps] = await Promise.all([
          Promise.all(ids.map((ingId) => tx.get(doc(db, 'stock_levels', stockLevelId(newWid, ingId))))),
          Promise.all(ids.map((ingId) => tx.get(doc(db, 'ingredients', ingId)))),
        ]);
        ids.forEach((ingId, i) => {
          const lSnap = lSnaps[i];
          const iSnap = iSnaps[i];
          if (!iSnap.exists()) return; // nguyên liệu đã bị xóa → bỏ qua
          const lData = (lSnap.exists() ? lSnap.data() : {}) as Record<string, unknown>;
          newState.set(ingId, {
            stock: Number(lData.stock ?? 0),
            name:
              String(lData.ingredient_name ?? '') ||
              String((iSnap.data() as Record<string, unknown>).name ?? ''),
          });
        });
      }

      // Gộp hoàn tác + trừ mới thành delta ròng theo (kho, nguyên liệu)
      // → tránh ghi đè khi 2 lần tx.set cùng doc stock_levels trong 1 transaction.
      interface NetMove {
        warehouseId: string;
        warehouseName: string | null;
        ingredientId: string;
        name: string;
        delta: number;
      }
      const net = new Map<string, NetMove>();
      const addMove = (
        wid: string,
        wname: string | null,
        iid: string,
        name: string,
        delta: number,
      ) => {
        const k = `${wid}_${iid}`;
        const ex = net.get(k);
        if (ex) ex.delta += delta;
        else net.set(k, { warehouseId: wid, warehouseName: wname, ingredientId: iid, name, delta });
      };
      if (restoreWid) {
        for (const [iid, qty] of oldStock.needs) {
          const st = oldStock.state.get(iid);
          if (!st) continue;
          addMove(restoreWid, order.warehouse_name, iid, st.name, qty); // hoàn tác: cộng lại
        }
      }
      for (const [iid, qty] of newNeeds) {
        const st = newState.get(iid);
        if (!st) continue;
        addMove(newWid, newWName, iid, st.name, -qty); // áp mới: trừ tồn
      }
      const moves = [...net.values()].filter((m) => m.delta !== 0);
      const curSnaps = await Promise.all(
        moves.map((m) => tx.get(doc(db, 'stock_levels', stockLevelId(m.warehouseId, m.ingredientId)))),
      );

      // Voucher cũ/mới (doc id = mã chữ thường)
      const vCodeOld = String(order.voucher_code ?? '').trim().toLowerCase();
      const oldVRef = vCodeOld ? doc(db, 'vouchers', vCodeOld) : null;
      const newVRef = vCodeNew ? doc(db, 'vouchers', vCodeNew) : null;
      const oldVSnap = oldVRef ? await tx.get(oldVRef) : null;
      const newVSnap =
        newVRef && (!oldVRef || newVRef.path !== oldVRef.path) ? await tx.get(newVRef) : oldVSnap;
      if (newVRef && newVSnap) {
        if (!newVSnap.exists()) throw new DbError('invalid-argument', 'Voucher không còn tồn tại.');
        const vd = newVSnap.data() as Record<string, unknown>;
        if (vd.active === false) throw new DbError('invalid-argument', 'Voucher đã bị tắt.');
        // Trừ lượt hoàn tác của chính đơn này khi giữ nguyên voucher
        const used = Number(vd.used_count ?? 0) - (vCodeOld === vCodeNew && vCodeNew ? 1 : 0);
        const lim = vd.usage_limit == null ? null : Number(vd.usage_limit);
        if (lim != null && used >= lim) throw new DbError('invalid-argument', 'Voucher đã hết lượt sử dụng.');
      }

      // Sổ quỹ cũ: đọc ở pha đọc (Firestore yêu cầu mọi tx.get() xong trước mọi tx.set/update/delete)
      const oldFundRef = doc(db, 'cashbook_entries', `fund_${id}`);
      const oldFundSnap = await tx.get(oldFundRef);
      const oldFundCreatedAt = oldFundSnap.exists()
        ? (oldFundSnap.data() as Record<string, unknown>).created_at
        : null;

      // ---- PHASE 2: ghi ----
      const createdBy = auth.currentUser?.uid ?? null;
      interface DebtLogPlan {
        custId: string;
        amount: number;
        balance_after: number;
        note: string;
        order_code?: string;
        order_id?: string;
      }
      const debtLogs: DebtLogPlan[] = [];

      // 2a. Khách hàng: hoàn tác cũ rồi áp mới (dùng bản sao số liệu để tính nối tiếp)
      interface CustWork {
        debt: number;
        stamps: number;
        reward_available: boolean;
        points: number;
        total_spent: number;
        tier: MemberTier;
      }
      const workOf = (cData: Record<string, unknown>): CustWork => ({
        debt: Number(cData.debt ?? 0),
        stamps: Number(cData.stamps ?? 0),
        reward_available: cData.reward_available === true,
        points: Number(cData.points ?? 0),
        total_spent: Number(cData.total_spent ?? 0),
        tier: (cData.tier as MemberTier) ?? 'member',
      });
      const reverseInto = (w: CustWork, custId: string) => {
        if (oldDebtTotal > 0) {
          const reverse = Math.min(oldDebtTotal, Math.max(w.debt, 0));
          if (reverse > 0) {
            w.debt -= reverse;
            debtLogs.push({
              custId,
              amount: -reverse,
              balance_after: w.debt,
              note: `Hoàn nợ do sửa đơn ${order.code}`,
              order_code: order.code,
              order_id: order.id,
            });
          }
        }
        const triggered = order.reward_triggered || (w.stamps === 0 && w.reward_available);
        if (triggered && w.reward_available) {
          w.stamps = Math.max(0, stampTarget - 1);
          w.reward_available = false;
        } else if (!triggered) {
          w.stamps = Math.max(0, w.stamps - 1);
        }
        if (loyaltyCfg) {
          w.points = Math.max(0, w.points - order.points_earned);
          w.total_spent = Math.max(0, w.total_spent - order.total);
          w.tier = tierFor(w.total_spent, loyaltyCfg);
        }
      };
      const applyInto = (w: CustWork, custId: string) => {
        w.stamps += 1;
        const trig = w.stamps >= stampTarget;
        if (trig) {
          w.stamps = 0;
          w.reward_available = true;
          rewardTriggeredNew = true;
        }
        if (newKind === 'debt') {
          w.debt += finalTotal;
          debtLogs.push({
            custId,
            amount: finalTotal,
            balance_after: w.debt,
            note: `Ghi nợ đơn ${order.code} (sửa)`,
            order_code: order.code,
            order_id: order.id,
          });
        }
        if (loyaltyCfg) {
          w.points += pointsEarnedNew;
          w.total_spent += finalTotal;
          w.tier = tierFor(w.total_spent, loyaltyCfg);
        }
      };

      const custUpdates = new Map<string, CustWork>();
      if (oldCustId && cSnaps.get(oldCustId)?.exists()) {
        const w = workOf(cSnaps.get(oldCustId)!.data() as Record<string, unknown>);
        reverseInto(w, oldCustId);
        custUpdates.set(oldCustId, w);
      }
      if (customerId) {
        let w: CustWork;
        if (customerId === oldCustId && custUpdates.has(customerId)) {
          w = custUpdates.get(customerId)!; // nối tiếp sau hoàn tác
        } else {
          const snap = cSnaps.get(customerId);
          if (!snap || !snap.exists()) throw new DbError('not-found', 'Khách hàng không tồn tại.');
          w = workOf(snap.data() as Record<string, unknown>);
        }
        applyInto(w, customerId);
        custUpdates.set(customerId, w);
      }
      for (const [cid, w] of custUpdates) {
        tx.update(doc(db, 'customers', cid), {
          debt: w.debt,
          stamps: w.stamps,
          reward_available: w.reward_available,
          points: w.points,
          total_spent: w.total_spent,
          tier: w.tier,
        });
      }
      for (const dl of debtLogs) {
        const logRef = doc(collection(db, 'customers', dl.custId, 'debt_logs'));
        tx.set(logRef, {
          id: logRef.id,
          amount: dl.amount,
          balance_after: dl.balance_after,
          note: dl.note,
          order_code: dl.order_code ?? null,
          order_id: dl.order_id ?? null,
          created_by: createdBy,
          created_at: serverTimestamp(),
        });
      }

      // 2b. Voucher: hoàn lượt cũ, trừ lượt mới (giữ nguyên mã → ròng bằng 0)
      if (oldVRef && oldVSnap && oldVSnap.exists()) {
        tx.update(oldVRef, { used_count: increment(-1) });
      }
      if (newVRef && newVSnap && newVSnap.exists()) {
        tx.update(newVRef, { used_count: increment(1) });
      }

      // 2c. Sổ quỹ: xóa khoản cũ (+ mồ côi đời cũ), ghi khoản mới
      // BUG 6: GIỮ NGUYÊN ngày gốc của khoản quỹ cũ — không dùng serverTimestamp()
      // (sửa đơn cũ mà ghi ngày hôm nay sẽ làm tiền "nhảy" sang ngày hiện tại)
      for (const r of legacyFundRefs) tx.delete(r);
      tx.delete(oldFundRef);
      if (newKind === 'cash' || newKind === 'transfer') {
        const fundRef = doc(db, 'cashbook_entries', `fund_${id}`);
        tx.set(fundRef, {
          id: fundRef.id,
          type: 'thu',
          amount: finalTotal,
          note: 'Doanh thu bán hàng',
          category: 'Bán hàng',
          fund_id: method.id,
          ref_type: 'order',
          ref_id: id,
          ref_code: order.code,
          method: newKind,
          warehouse_id: newWid,
          created_by: createdBy,
          // v6.3: sửa giờ thì khoản quỹ doanh thu đổi theo đúng giờ mới (Sổ quỹ
          // hiển thị theo created_at); không sửa giờ thì giữ nguyên giờ gốc.
          created_at: newOrderTimeIso ?? tsToIso(oldFundCreatedAt ?? order.created_at),
        });
      }

      // 2d. Tồn kho: ghi delta ròng
      moves.forEach((m, i) => {
        const snap = curSnaps[i];
        const cur = snap.exists() ? Number((snap.data() as Record<string, unknown>).stock ?? 0) : 0;
        const balance_after = cur + m.delta;
        tx.set(
          doc(db, 'stock_levels', stockLevelId(m.warehouseId, m.ingredientId)),
          {
            warehouse_id: m.warehouseId,
            ingredient_id: m.ingredientId,
            ingredient_name: m.name,
            stock: balance_after,
          },
          { merge: true },
        );
        const logRef = doc(collection(db, 'stock_logs'));
        tx.set(logRef, {
          id: logRef.id,
          warehouse_id: m.warehouseId,
          warehouse_name: m.warehouseName,
          ingredient_id: m.ingredientId,
          ingredient_name: m.name,
          change: m.delta,
          balance_after,
          note: `Sửa đơn ${order.code}`,
          ref_type: 'order',
          ref_id: id,
          created_by: createdBy,
          created_at: serverTimestamp(),
        });
      });

      // 2e. Cập nhật document đơn (giữ id/code/trạng thái/người tạo/kênh;
      // v6.3: chỉ đổi ngày + giờ tạo khi form sửa gửi giờ mới, còn lại giữ nguyên)
      // Xóa mảng payments cũ: form sửa chỉ hỗ trợ 1 phương thức, giữ mảng cũ là
      // báo cáo/bill vẫn phân bổ theo phần thanh toán cũ lệch với tổng mới.
      tx.update(orderRef, {
        payments: deleteField(),
        ...(newOrderTimeIso && newOrderBusinessDate ? { business_date: newOrderBusinessDate, created_at: newOrderTimeIso } : {}),
        customer_id: customerId,
        payment_method: method.id,
        payment_method_name: method.name,
        warehouse_id: newWid,
        warehouse_name: newWName,
        subtotal: pricing.subtotal,
        discount: discountAmount,
        discount_type: discType,
        discount_value: discValue,
        discount_label: discountLabel,
        shipping_fee: shippingFee,
        total: finalTotal,
        amount_received: cash.amount_received,
        change_amount: cash.change_amount,
        note,
        voucher_code: voucherNew ? voucherNew.code : null,
        points_earned: pointsEarnedNew,
        reward_triggered: rewardTriggeredNew,
        items: pricing.lines.map((l) => ({
          id: l.id,
          order_id: id,
          product_id: l.product_id,
          product_name: l.product_name,
          qty: l.qty,
          unit_price: l.unit_price,
          cost_price: l.cost_price,
          recipe: l.recipe,
          modifiers: l.modifiers,
          line_total: l.line_total,
          ...(l.note ? { note: l.note } : {}),
        })),
      });
    });

    const after = await getDoc(doc(db, 'orders', id));
    const updated = orderFromDoc(after);
    if (!updated) throw new DbError('unknown', 'Không đọc được đơn sau khi sửa.');
    logAudit('order.update_full', `Sửa toàn bộ đơn ${updated.code}`, { type: 'order', id });
    return updated;
  } catch (e) {
    throw toDbError(e);
  }
}

// ------------------------------------------------------------- warehouses ---
// Multi-kho: mỗi nguyên liệu có tồn kho RIÊNG theo từng kho (collection stock_levels).
// - warehouses: danh sách kho (chỉ chủ quán quản lý).
// - stock_levels/{warehouseId_ingredientId}: tồn của 1 nguyên liệu tại 1 kho.
//   Nhân viên được đọc/ghi tồn ở các kho mình được gán (users/{uid}.warehouse_ids).
// - Bán hàng trừ kho đang chọn ở POS; hủy/xóa đơn hoàn về đúng kho của đơn đó.

function toWarehouse(id: string, d: Record<string, unknown>): Warehouse {
  return {
    id,
    name: String(d.name ?? 'Kho'),
    note: (d.note as string | null) ?? null,
    is_default: d.is_default === true,
    active: activeOf(d),
    sort_order: Number(d.sort_order ?? 0),
    created_at: tsToIso(d.created_at),
  };
}

/** Id cố định của doc tồn kho: `${warehouseId}_${ingredientId}` — tiện đọc trong transaction. */
export function stockLevelId(warehouseId: string, ingredientId: string): string {
  return `${warehouseId}_${ingredientId}`;
}

/** Danh sách kho (mặc định chỉ kho đang dùng). */
let warehousesCache: { at: number; all: Warehouse[] } | null = null;
export function clearWarehousesCache(): void {
  warehousesCache = null;
}
export async function listWarehouses(activeOnly = true): Promise<Warehouse[]> {
  try {
    // Cache 10 phút — danh sách kho ít khi đổi
    if (!warehousesCache || Date.now() - warehousesCache.at > 10 * 60 * 1000) {
      const snap = await getDocs(
        query(collection(db, 'warehouses'), orderBy('sort_order', 'asc'), limit(100)),
      );
      const all = snap.docs.map((d) => toWarehouse(d.id, d.data() as Record<string, unknown>));
      warehousesCache = { at: Date.now(), all };
    }
    return activeOnly ? warehousesCache.all.filter((w) => w.active) : warehousesCache.all;
  } catch (e) {
    throw toDbError(e);
  }
}

/** Tạo kho mới — chỉ chủ quán (rules). */
export async function createWarehouse(name: string, note?: string | null): Promise<Warehouse> {
  const n = String(name ?? '').trim().slice(0, 60);
  if (!n) throw new DbError('invalid-argument', 'Vui lòng nhập tên kho.');
  try {
    const existing = await listWarehouses(false);
    const maxSort = existing.reduce((m, w) => Math.max(m, w.sort_order), 0);
    const id = uuid();
    const data = {
      id,
      name: n,
      note: typeof note === 'string' && note.trim() ? note.trim().slice(0, 500) : null,
      is_default: existing.length === 0, // kho đầu tiên làm mặc định
      active: true,
      sort_order: maxSort + 1,
      created_at: serverTimestamp(),
    };
    await setDoc(doc(db, 'warehouses', id), data);
    return toWarehouse(id, { ...data, created_at: new Date().toISOString() });
  } catch (e) {
    throw toDbError(e);
  }
}

/** Sửa kho (tên, ghi chú, ẩn/hiện) — chỉ chủ quán (rules). */
export async function updateWarehouse(
  id: string,
  patch: Partial<Pick<Warehouse, 'name' | 'note' | 'active'>>,
): Promise<void> {
  const data: Record<string, unknown> = {};
  if (patch.name !== undefined) {
    const n = String(patch.name ?? '').trim().slice(0, 60);
    if (!n) throw new DbError('invalid-argument', 'Tên kho không được để trống.');
    data.name = n;
  }
  if (patch.note !== undefined) {
    data.note = typeof patch.note === 'string' && patch.note.trim() ? patch.note.trim().slice(0, 500) : null;
  }
  if (patch.active !== undefined) data.active = patch.active;
  if (Object.keys(data).length === 0) return;
  try {
    await updateDoc(doc(db, 'warehouses', id), data);
  } catch (e) {
    throw toDbError(e);
  }
}

/** Đặt kho bán hàng mặc định (trừ kho này khi bán ở POS) — chỉ chủ quán. */
export async function setDefaultWarehouse(id: string): Promise<void> {
  try {
    const ws = await listWarehouses(false);
    const target = ws.find((w) => w.id === id && w.active);
    if (!target) throw new DbError('invalid-argument', 'Kho không tồn tại hoặc đang ẩn.');
    const batch = writeBatch(db);
    for (const w of ws) {
      if ((w.is_default && w.id !== id) || (!w.is_default && w.id === id)) {
        batch.update(doc(db, 'warehouses', w.id), { is_default: w.id === id });
      }
    }
    await batch.commit();
    await setSetting('default_warehouse', id);
  } catch (e) {
    throw toDbError(e);
  }
}

/** Kho mặc định để trừ tồn khi bán: settings → cờ is_default → kho đầu tiên. */
export async function getDefaultWarehouseId(): Promise<string | null> {
  try {
    const [s, ws] = await Promise.all([getSettings(), listWarehouses(false)]);
    const active = ws.filter((w) => w.active);
    const fromSettings = (s.default_warehouse || '').trim();
    if (fromSettings && active.some((w) => w.id === fromSettings)) return fromSettings;
    return active.find((w) => w.is_default)?.id ?? active[0]?.id ?? null;
  } catch {
    return null;
  }
}

/**
 * Khởi tạo kho lần đầu — chỉ chủ quán gọi.
 * Tạo "Kho quầy" làm mặc định và chuyển tồn kho chung cũ của từng
 * nguyên liệu vào kho này (giữ nguyên số liệu, không mất dữ liệu).
 */
export async function ensureWarehousesSeeded(): Promise<Warehouse[]> {
  try {
    const existing = await listWarehouses(false);
    if (existing.length > 0) return existing;
    const ings = await listIngredients(false);
    const wid = uuid();
    const writes: Array<{ ref: ReturnType<typeof doc>; data: Record<string, unknown> }> = [
      {
        ref: doc(db, 'warehouses', wid),
        data: {
          id: wid,
          name: 'Kho quầy',
          note: 'Kho mặc định',
          is_default: true,
          active: true,
          sort_order: 1,
          created_at: serverTimestamp(),
        },
      },
    ];
    for (const ing of ings) {
      writes.push({
        ref: doc(db, 'stock_levels', stockLevelId(wid, ing.id)),
        data: {
          warehouse_id: wid,
          ingredient_id: ing.id,
          ingredient_name: ing.name,
          stock: ing.stock,
        },
      });
    }
    for (let i = 0; i < writes.length; i += 400) {
      const batch = writeBatch(db);
      for (const w of writes.slice(i, i + 400)) batch.set(w.ref, w.data);
      await batch.commit();
    }
    await setSetting('default_warehouse', wid);
    return listWarehouses(false);
  } catch (e) {
    throw toDbError(e);
  }
}

// ------------------------------------------------------- phân quyền kho ---
export interface MyProfile {
  role: RoleKey;
  warehouse_ids: string[];
}

/** Hồ sơ quyền của tài khoản đang đăng nhập (vai trò + các kho được gán). */
let myProfileCache: { uid: string; profile: MyProfile } | null = null;
export function clearMyProfileCache(): void {
  myProfileCache = null;
}
export async function getMyProfile(): Promise<MyProfile> {
  const uid = auth.currentUser?.uid;
  if (!uid) throw new DbError('unauthenticated', 'Chưa đăng nhập.');
  // Cache theo session — role/kho được gán ít khi đổi trong phiên làm việc
  if (myProfileCache && myProfileCache.uid === uid) {
    return myProfileCache.profile;
  }
  try {
    const snap = await getDoc(doc(db, 'users', uid));
    const d = (snap.data() ?? {}) as Record<string, unknown>;
    const profile: MyProfile = {
      role: normalizeRole(d.role),
      warehouse_ids: Array.isArray(d.warehouse_ids) ? d.warehouse_ids.map((x) => String(x)) : [],
    };
    myProfileCache = { uid, profile };
    return profile;
  } catch (e) {
    throw toDbError(e);
  }
}

function toUser(id: string, d: Record<string, unknown>): User {
  return {
    id,
    email: String(d.email ?? ''),
    full_name: String(d.full_name ?? ''),
    role: normalizeRole(d.role),
    warehouse_ids: Array.isArray(d.warehouse_ids) ? d.warehouse_ids.map((x) => String(x)) : [],
  };
}

/** Danh sách tài khoản — chỉ chủ quán (rules). */
export async function listUsers(): Promise<User[]> {
  try {
    const snap = await getDocs(query(collection(db, 'users'), limit(200)));
    const all = snap.docs.map((d) => toUser(d.id, d.data() as Record<string, unknown>));
    all.sort((a, b) => a.full_name.localeCompare(b.full_name, 'vi'));
    return all;
  } catch (e) {
    throw toDbError(e);
  }
}

/** Đổi vai trò nhân viên (Quản lý/Thu ngân/Bán hàng) — chỉ chủ quán (rules). */
export async function updateUserRole(uid: string, role: RoleKey): Promise<void> {
  const r = normalizeRole(role);
  if (r === 'owner') throw new DbError('invalid-argument', 'Không thể gán vai trò chủ quán ở đây.');
  try {
    await updateDoc(doc(db, 'users', uid), { role: r });
    logAudit('staff.role', `Đổi vai trò nhân viên ${uid} → ${r}`, { type: 'user', id: uid });
  } catch (e) {
    throw toDbError(e);
  }
}

/** Gán các kho cho tài khoản nhân viên — chỉ chủ quán (rules). */
export async function updateUserWarehouses(uid: string, warehouseIds: string[]): Promise<void> {
  try {
    const ws = await listWarehouses(false);
    const valid = new Set(ws.map((w) => w.id));
    const clean = [...new Set(warehouseIds.map(String))].filter((id) => valid.has(id));
    await updateDoc(doc(db, 'users', uid), { warehouse_ids: clean });
    logAudit('staff.warehouse', `Gán kho cho nhân viên ${uid}: ${clean.length} kho`, { type: 'user', id: uid });
  } catch (e) {
    throw toDbError(e);
  }
}

// ------------------------------------------------------------- ingredients ---
function toIngredient(id: string, d: Record<string, unknown>): Ingredient {
  return {
    id,
    name: String(d.name ?? ''),
    unit: String(d.unit ?? '').trim().slice(0, 20),
    stock: Number(d.stock ?? 0), // tồn chung cũ — chỉ dùng khi migrate sang multi-kho
    min_stock: Math.max(0, Number(d.min_stock ?? 0) || 0),
    alert_enabled: d.alert_enabled !== false,
    cost_per_unit: Math.max(0, Math.round(Number(d.cost_per_unit ?? 0)) || 0),
    active: activeOf(d),
    sort_order: Number(d.sort_order ?? 0),
    is_product_stock: d.is_product_stock === true,
    product_id: (d.product_id as string | null) ?? null,
    production_recipe: Array.isArray(d.production_recipe)
      ? (d.production_recipe as Array<Record<string, unknown>>)
          .map((r) => ({
            ingredient_id: String(r.ingredient_id ?? ''),
            qty: Number(r.qty ?? 0),
          }))
          .filter((r) => r.ingredient_id && Number.isFinite(r.qty) && r.qty > 0)
      : undefined,
    production_batch_qty:
      d.production_batch_qty != null && Number(d.production_batch_qty) > 0
        ? Number(d.production_batch_qty)
        : undefined,
  };
}

function toStockLog(id: string, d: Record<string, unknown>): StockLog {
  const rt = d.ref_type;
  return {
    id,
    warehouse_id: (d.warehouse_id as string | null) ?? null,
    warehouse_name: (d.warehouse_name as string | null) ?? null,
    ingredient_id: String(d.ingredient_id ?? ''),
    ingredient_name: String(d.ingredient_name ?? ''),
    change: Number(d.change ?? 0),
    balance_after: Number(d.balance_after ?? 0),
    unit_cost: d.unit_cost == null ? null : Number(d.unit_cost),
    total_cost: d.total_cost == null ? null : Number(d.total_cost),
    note: (d.note as string | null) ?? null,
    ref_type: (rt as StockLog['ref_type']) ?? 'manual',
    ref_id: (d.ref_id as string | null) ?? null,
    created_by: (d.created_by as string | null) ?? null,
    created_at: tsToIso(d.created_at),
  };
}

/** Danh mục nguyên liệu (thông tin chung, không gồm tồn kho từng kho). */
export async function listIngredients(activeOnly = false): Promise<Ingredient[]> {
  try {
    const snap = await getDocs(
      query(collection(db, 'ingredients'), orderBy('sort_order', 'asc'), limit(500)),
    );
    const all = snap.docs.map((d) => toIngredient(d.id, d.data() as Record<string, unknown>));
    return activeOnly ? all.filter((i) => i.active) : all;
  } catch (e) {
    throw toDbError(e);
  }
}

/** Nguyên liệu kèm tồn kho tại 1 kho cụ thể (dùng cho màn Tồn kho). */
export async function listWarehouseStock(warehouseId: string): Promise<IngredientWithStock[]> {
  try {
    const [ings, snap] = await Promise.all([
      listIngredients(false),
      getDocs(
        query(collection(db, 'stock_levels'), where('warehouse_id', '==', warehouseId), limit(1000)),
      ),
    ]);
    const lv = new Map<string, number>();
    for (const d of snap.docs) {
      const data = d.data() as Record<string, unknown>;
      lv.set(String(data.ingredient_id ?? ''), Number(data.stock ?? 0));
    }
    return ings.map((i) => ({ ...i, stock: lv.get(i.id) ?? 0 }));
  } catch (e) {
    throw toDbError(e);
  }
}

/** Thêm nguyên liệu — chỉ chủ quán (rules). Tồn đầu ghi vào kho chỉ định. */
export async function createIngredient(
  d: {
    name: string;
    unit: string;
    stock?: number;
    min_stock?: number;
    cost_per_unit?: number;
    alert_enabled?: boolean;
  },
  warehouseId?: string | null,
): Promise<Ingredient> {
  const name = String(d.name ?? '').trim().slice(0, 60);
  if (!name) throw new DbError('invalid-argument', 'Vui lòng nhập tên nguyên liệu.');
  const unit = String(d.unit ?? '').trim().slice(0, 20) || 'đơn vị';
  const stock = Number(d.stock ?? 0);
  if (!Number.isFinite(stock)) throw new DbError('invalid-argument', 'Tồn kho không hợp lệ.');
  try {
    const existing = await listIngredients();
    const maxSort = existing.reduce((m, i) => Math.max(m, i.sort_order), 0);
    const id = uuid();
    const data = {
      id,
      name,
      unit,
      stock: 0, // tồn chung cũ không dùng nữa — tồn thật nằm ở stock_levels
      min_stock: Math.max(0, Number(d.min_stock ?? 0) || 0),
      alert_enabled: d.alert_enabled !== false,
      cost_per_unit: Math.max(0, Math.round(Number(d.cost_per_unit ?? 0)) || 0),
      active: true,
      sort_order: maxSort + 1,
      created_at: serverTimestamp(),
    };
    const wid = warehouseId ?? (await getDefaultWarehouseId());
    const batch = writeBatch(db);
    batch.set(doc(db, 'ingredients', id), data);
    if (wid && stock !== 0) {
      const wSnap = await getDoc(doc(db, 'warehouses', wid));
      const wName = wSnap.exists() ? String((wSnap.data() as Record<string, unknown>).name ?? '') : '';
      batch.set(doc(db, 'stock_levels', stockLevelId(wid, id)), {
        warehouse_id: wid,
        ingredient_id: id,
        ingredient_name: name,
        stock,
      });
      const logRef = doc(collection(db, 'stock_logs'));
      batch.set(logRef, {
        id: logRef.id,
        warehouse_id: wid,
        warehouse_name: wName || null,
        ingredient_id: id,
        ingredient_name: name,
        change: stock,
        balance_after: stock,
        note: 'Tồn đầu kỳ',
        ref_type: 'manual',
        ref_id: null,
        created_by: auth.currentUser?.uid ?? null,
        created_at: serverTimestamp(),
      });
    }
    await batch.commit();
    return toIngredient(id, { ...data, stock });
  } catch (e) {
    throw toDbError(e);
  }
}

/** Sửa nguyên liệu — chỉ chủ quán (rules). Đổi tên thì đồng bộ tên ở các kho. */
export async function updateIngredient(
  id: string,
  patch: Partial<Pick<Ingredient, 'name' | 'unit' | 'min_stock' | 'cost_per_unit' | 'active' | 'sort_order' | 'alert_enabled'>>,
): Promise<void> {
  const data: Record<string, unknown> = {};
  if (patch.name !== undefined) {
    const name = String(patch.name ?? '').trim().slice(0, 60);
    if (!name) throw new DbError('invalid-argument', 'Tên nguyên liệu không được để trống.');
    data.name = name;
  }
  if (patch.unit !== undefined) {
    data.unit = String(patch.unit ?? '').trim().slice(0, 20) || 'đơn vị';
  }
  if (patch.min_stock !== undefined) {
    const v = Number(patch.min_stock);
    if (!Number.isFinite(v) || v < 0) throw new DbError('invalid-argument', 'Ngưỡng cảnh báo không hợp lệ.');
    data.min_stock = v;
  }
  if (patch.cost_per_unit !== undefined) {
    const v = Math.round(Number(patch.cost_per_unit));
    if (!Number.isFinite(v) || v < 0) throw new DbError('invalid-argument', 'Giá vốn không hợp lệ.');
    data.cost_per_unit = v;
  }
  if (patch.active !== undefined) data.active = patch.active;
  if (patch.alert_enabled !== undefined) data.alert_enabled = patch.alert_enabled === true;
  if (patch.sort_order !== undefined) data.sort_order = patch.sort_order;
  if (Object.keys(data).length === 0) return;
  try {
    await updateDoc(doc(db, 'ingredients', id), data);
    if (typeof data.name === 'string') {
      // Đồng bộ tên nguyên liệu ở các doc tồn kho (best-effort)
      const snap = await getDocs(
        query(collection(db, 'stock_levels'), where('ingredient_id', '==', id), limit(50)),
      );
      if (!snap.empty) {
        const batch = writeBatch(db);
        for (const d of snap.docs) batch.update(d.ref, { ingredient_name: data.name });
        await batch.commit();
      }
    }
  } catch (e) {
    throw toDbError(e);
  }
}

/**
 * Nhập/xuất kho thủ công tại 1 kho (change > 0: nhập; < 0: xuất/điều chỉnh giảm).
 * Ghi log kèm tồn sau điều chỉnh. Cho phép tồn âm (sẽ cảnh báo đỏ ở màn Tồn kho).
 * Trả về tồn sau điều chỉnh.
 */
export async function adjustStock(
  warehouseId: string,
  ingredientId: string,
  change: number,
  note?: string | null,
  unitCost?: number | null, // giá nhập / đơn vị (đ) — chỉ dùng khi nhập (change > 0)
): Promise<number> {
  const delta = Number(change);
  if (!Number.isFinite(delta) || delta === 0) {
    throw new DbError('invalid-argument', 'Số lượng điều chỉnh phải khác 0.');
  }
  if (!warehouseId) throw new DbError('invalid-argument', 'Thiếu kho.');
  const cost = unitCost != null && Number.isFinite(Number(unitCost)) && Number(unitCost) > 0 ? Math.round(Number(unitCost)) : null;
  try {
    let balanceAfter = 0;
    await runTransaction(db, async (tx) => {
      // Đọc trước — ghi sau (Firestore bắt buộc thứ tự này trong transaction)
      const wRef = doc(db, 'warehouses', warehouseId);
      const iRef = doc(db, 'ingredients', ingredientId);
      const lRef = doc(db, 'stock_levels', stockLevelId(warehouseId, ingredientId));
      const [wSnap, iSnap, lSnap] = await Promise.all([tx.get(wRef), tx.get(iRef), tx.get(lRef)]);
      if (!wSnap.exists() || (wSnap.data() as Record<string, unknown>).active === false) {
        throw new DbError('invalid-argument', 'Kho không tồn tại hoặc đang ẩn.');
      }
      if (!iSnap.exists()) throw new DbError('not-found', 'Không tìm thấy nguyên liệu.');
      const ingName = String((iSnap.data() as Record<string, unknown>).name ?? '');
      const wName = String((wSnap.data() as Record<string, unknown>).name ?? '');
      const cur = lSnap.exists() ? Number((lSnap.data() as Record<string, unknown>).stock ?? 0) : 0;
      balanceAfter = cur + delta;

      // Giá vốn bình quân: chỉ cập nhật khi NHẬP có nhập giá
      let avgCost = lSnap.exists() ? Number((lSnap.data() as Record<string, unknown>).avg_cost ?? 0) : 0;
      if (delta > 0 && cost != null) {
        const totalQty = cur + delta;
        avgCost = totalQty > 0 ? Math.round((cur * avgCost + delta * cost) / totalQty) : cost;
      }

      tx.set(
        lRef,
        {
          warehouse_id: warehouseId,
          ingredient_id: ingredientId,
          ingredient_name: ingName,
          stock: balanceAfter,
          avg_cost: avgCost,
          updated_at: serverTimestamp(),
        },
        { merge: true },
      );
      const logRef = doc(collection(db, 'stock_logs'));
      tx.set(logRef, {
        id: logRef.id,
        warehouse_id: warehouseId,
        warehouse_name: wName || null,
        ingredient_id: ingredientId,
        ingredient_name: ingName,
        change: delta,
        balance_after: balanceAfter,
        note: typeof note === 'string' && note.trim() ? note.trim().slice(0, 500) : null,
        unit_cost: cost,
        total_cost: cost != null && delta > 0 ? cost * delta : null,
        ref_type: 'manual',
        ref_id: null,
        created_by: auth.currentUser?.uid ?? null,
        created_at: serverTimestamp(),
      });
    });
    return balanceAfter;
  } catch (e) {
    throw toDbError(e);
  }
}

/**
 * Chuyển kho: giảm tồn ở kho nguồn, tăng ở kho đích, ghi log cả 2 đầu.
 * Người gọi phải có quyền cả 2 kho (rules kiểm tra).
 */
export async function transferStock(
  fromWarehouseId: string,
  toWarehouseId: string,
  ingredientId: string,
  qty: number,
  note?: string | null,
): Promise<void> {
  const q = Number(qty);
  if (!Number.isFinite(q) || q <= 0) throw new DbError('invalid-argument', 'Số lượng chuyển phải lớn hơn 0.');
  if (!fromWarehouseId || !toWarehouseId) throw new DbError('invalid-argument', 'Thiếu kho nguồn/kho đích.');
  if (fromWarehouseId === toWarehouseId) throw new DbError('invalid-argument', 'Kho nguồn và kho đích trùng nhau.');
  try {
    await runTransaction(db, async (tx) => {
      const fromWRef = doc(db, 'warehouses', fromWarehouseId);
      const toWRef = doc(db, 'warehouses', toWarehouseId);
      const iRef = doc(db, 'ingredients', ingredientId);
      const fromLRef = doc(db, 'stock_levels', stockLevelId(fromWarehouseId, ingredientId));
      const toLRef = doc(db, 'stock_levels', stockLevelId(toWarehouseId, ingredientId));
      const [fromWSnap, toWSnap, iSnap, fromLSnap, toLSnap] = await Promise.all([
        tx.get(fromWRef),
        tx.get(toWRef),
        tx.get(iRef),
        tx.get(fromLRef),
        tx.get(toLRef),
      ]);
      if (!fromWSnap.exists() || !toWSnap.exists()) throw new DbError('invalid-argument', 'Kho không tồn tại.');
      if (!iSnap.exists()) throw new DbError('not-found', 'Không tìm thấy nguyên liệu.');
      const ingName = String((iSnap.data() as Record<string, unknown>).name ?? '');
      const fromWName = String((fromWSnap.data() as Record<string, unknown>).name ?? '');
      const toWName = String((toWSnap.data() as Record<string, unknown>).name ?? '');
      const fromCur = fromLSnap.exists() ? Number((fromLSnap.data() as Record<string, unknown>).stock ?? 0) : 0;
      const toCur = toLSnap.exists() ? Number((toLSnap.data() as Record<string, unknown>).stock ?? 0) : 0;
      // SUA 25/10/2026 (chan ton am): kho nguon khong du thi dung lai, khong
      // cho ton am roi moi bao cao sau.
      if (fromCur < q) {
        throw new DbError(
          'invalid-argument',
          `Kho ${fromWName || 'nguồn'} chỉ còn ${fromCur} ${ingName}, không đủ để chuyển ${q}.`,
        );
      }
      const fromAfter = fromCur - q;
      const toAfter = toCur + q;
      const createdBy = auth.currentUser?.uid ?? null;
      const cleanNote = typeof note === 'string' && note.trim() ? note.trim().slice(0, 500) : null;

      tx.set(fromLRef, { warehouse_id: fromWarehouseId, ingredient_id: ingredientId, ingredient_name: ingName, stock: fromAfter }, { merge: true });
      tx.set(toLRef, { warehouse_id: toWarehouseId, ingredient_id: ingredientId, ingredient_name: ingName, stock: toAfter }, { merge: true });
      const outRef = doc(collection(db, 'stock_logs'));
      tx.set(outRef, {
        id: outRef.id,
        warehouse_id: fromWarehouseId,
        warehouse_name: fromWName || null,
        ingredient_id: ingredientId,
        ingredient_name: ingName,
        change: -q,
        balance_after: fromAfter,
        note: `Chuyển sang ${toWName}${cleanNote ? ` · ${cleanNote}` : ''}`,
        ref_type: 'transfer',
        ref_id: null,
        created_by: createdBy,
        created_at: serverTimestamp(),
      });
      const inRef = doc(collection(db, 'stock_logs'));
      tx.set(inRef, {
        id: inRef.id,
        warehouse_id: toWarehouseId,
        warehouse_name: toWName || null,
        ingredient_id: ingredientId,
        ingredient_name: ingName,
        change: q,
        balance_after: toAfter,
        note: `Nhận từ ${fromWName}${cleanNote ? ` · ${cleanNote}` : ''}`,
        ref_type: 'transfer',
        ref_id: null,
        created_by: createdBy,
        created_at: serverTimestamp(),
      });
    });
  } catch (e) {
    throw toDbError(e);
  }
}

/**
 * Lịch sử nhập/xuất kho của 1 kho, mới nhất trước.
 * Luôn lọc theo warehouse_id trong query để khớp với rule phân quyền theo kho.
 */
/**
 * Bật/tắt theo dõi tồn kho cho món (hàng nhập về bán trực tiếp).
 * Khi bật: tự tạo nguyên liệu kho liên kết (is_product_stock), món bán sẽ trừ tồn trực tiếp.
 * Khi tắt: giữ nguyên liệu và số tồn cũ, chỉ tắt cờ theo dõi.
 */
export async function setProductStockTracking(productId: string, enabled: boolean): Promise<void> {
  try {
    const pRef = doc(db, 'products', productId);
    const pSnap = await getDoc(pRef);
    if (!pSnap.exists()) throw new DbError('not-found', 'Không tìm thấy món.');
    const p = toProduct(productId, pSnap.data() as Record<string, unknown>);

    if (enabled) {
      if (p.track_stock && p.stock_ingredient_id) return;
      const ingRef = doc(collection(db, 'ingredients'));
      const batch = writeBatch(db);
      batch.set(ingRef, {
        id: ingRef.id,
        name: p.name,
        unit: p.unit || 'cái',
        min_stock: 0,
        cost_per_unit: p.cost_price || 0,
        active: true,
        sort_order: 0,
        is_product_stock: true,
        product_id: productId,
        created_at: serverTimestamp(),
      });
      batch.update(pRef, {
        track_stock: true,
        stock_ingredient_id: ingRef.id,
        recipe: [{ ingredient_id: ingRef.id, qty: 1 }],
      });
      await batch.commit();
      logAudit('product.stock_tracking', `Bật theo dõi tồn kho cho món ${p.name}`, {
        type: 'product',
        id: productId,
      });
    } else {
      await updateDoc(pRef, { track_stock: false });
      logAudit('product.stock_tracking', `Tắt theo dõi tồn kho cho món ${p.name}`, {
        type: 'product',
        id: productId,
      });
    }
  } catch (e) {
    throw toDbError(e);
  }
}

/**
 * Kiểm kho: điều chỉnh hàng loạt về số lượng thực tế.
 * Mỗi dòng lệch tạo 1 log với ref_type='check'. Chạy trong 1 transaction.
 */
export async function applyStockCheck(
  warehouseId: string,
  adjustments: { ingredientId: string; actualQty: number }[],
  note?: string | null,
): Promise<{ adjusted: number }> {
  const items = (adjustments ?? [])
    .map((a) => ({ ingredientId: String(a.ingredientId ?? ''), actualQty: Number(a.actualQty ?? 0) }))
    .filter((a) => a.ingredientId && Number.isFinite(a.actualQty) && a.actualQty >= 0);
  if (items.length === 0) throw new DbError('invalid-argument', 'Chưa có số liệu kiểm kho.');
  if (!warehouseId) throw new DbError('invalid-argument', 'Thiếu kho.');
  try {
    let adjusted = 0;
    await runTransaction(db, async (tx) => {
      const wSnap = await tx.get(doc(db, 'warehouses', warehouseId));
      if (!wSnap.exists()) throw new DbError('invalid-argument', 'Kho không tồn tại.');
      const wName = String((wSnap.data() as Record<string, unknown>).name ?? '');
      const createdBy = auth.currentUser?.uid ?? null;
      const checkNote = typeof note === 'string' && note.trim() ? note.trim().slice(0, 500) : null;
      // PHASE 1: đọc TẤT CẢ tồn trước. Firestore cấm đọc sau khi đã ghi trong
      // cùng transaction — bản cũ đọc/ghi xen kẽ từng dòng nên kiểm kho có từ
      // 2 dòng lệch trở lên là transaction bị hủy, không cân bằng được dòng nào.
      interface CheckRow {
        ingredientId: string;
        name: string;
        diff: number;
        balanceAfter: number;
      }
      const rows: CheckRow[] = [];
      for (const a of items) {
        const iRef = doc(db, 'ingredients', a.ingredientId);
        const lRef = doc(db, 'stock_levels', stockLevelId(warehouseId, a.ingredientId));
        const [iSnap, lSnap] = await Promise.all([tx.get(iRef), tx.get(lRef)]);
        if (!iSnap.exists()) continue;
        const iname = String((iSnap.data() as Record<string, unknown>).name ?? '');
        const cur = lSnap.exists() ? Number((lSnap.data() as Record<string, unknown>).stock ?? 0) : 0;
        const diff = Math.round((a.actualQty - cur) * 100) / 100;
        if (diff === 0) continue;
        rows.push({ ingredientId: a.ingredientId, name: iname, diff, balanceAfter: cur + diff });
      }
      // PHASE 2: ghi toàn bộ (tồn + log) sau khi đã đọc xong.
      for (const r of rows) {
        tx.set(
          doc(db, 'stock_levels', stockLevelId(warehouseId, r.ingredientId)),
          {
            warehouse_id: warehouseId,
            ingredient_id: r.ingredientId,
            ingredient_name: r.name,
            stock: r.balanceAfter,
            updated_at: serverTimestamp(),
          },
          { merge: true },
        );
        const logRef = doc(collection(db, 'stock_logs'));
        tx.set(logRef, {
          id: logRef.id,
          warehouse_id: warehouseId,
          warehouse_name: wName || null,
          ingredient_id: r.ingredientId,
          ingredient_name: r.name,
          change: r.diff,
          balance_after: r.balanceAfter,
          note: `Kiểm kho${checkNote ? ` — ${checkNote}` : ''}`,
          unit_cost: null,
          total_cost: null,
          ref_type: 'check',
          ref_id: null,
          created_by: createdBy,
          created_at: serverTimestamp(),
        });
        adjusted++;
      }
    });
    if (adjusted === 0) throw new DbError('invalid-argument', 'Không có chênh lệch nào cần cân bằng.');
    logAudit('stock.check', `Kiểm kho — cân bằng ${adjusted} nguyên liệu`, { type: 'stock_check', id: warehouseId });
    return { adjusted };
  } catch (e) {
    throw toDbError(e);
  }
}

export async function listStockLogs(warehouseId: string, limitN = 100): Promise<StockLog[]> {
  try {
    const snap = await getDocs(
      query(
        collection(db, 'stock_logs'),
        where('warehouse_id', '==', warehouseId),
        orderBy('created_at', 'desc'),
        limit(Math.min(Math.max(limitN, 1), 500)),
      ),
    );
    return snap.docs.map((d) => toStockLog(d.id, d.data() as Record<string, unknown>));
  } catch (e) {
    throw toDbError(e);
  }
}

/** Tải TOÀN BỘ log tồn kho của 1 kho (phân trang, không cắt ở 500 như
 *  listStockLogs) — Sổ kho kỳ quá khứ cần đủ log trong kỳ VÀ sau kỳ để
 *  tính ngược tồn cuối kỳ; cắt 500 rồi mới lọc kỳ sẽ làm mất log cũ.
 *  Tran 100 trang x 500 = 50.000 log, du cho quan 1 kho. */
export async function listAllStockLogs(warehouseId: string): Promise<StockLog[]> {
  try {
    const out: StockLog[] = [];
    let last: unknown = null;
    for (let page = 0; page < 100; page++) {
      const q =
        last == null
          ? query(
              collection(db, 'stock_logs'),
              where('warehouse_id', '==', warehouseId),
              orderBy('created_at', 'desc'),
              limit(500),
            )
          : query(
              collection(db, 'stock_logs'),
              where('warehouse_id', '==', warehouseId),
              orderBy('created_at', 'desc'),
              limit(500),
              startAfter(last as never),
            );
      const snap = await getDocs(q);
      if (snap.docs.length === 0) break;
      for (const d of snap.docs) out.push(toStockLog(d.id, d.data() as Record<string, unknown>));
      last = snap.docs[snap.docs.length - 1];
      if (snap.docs.length < 500) break;
    }
    return out;
  } catch (e) {
    throw toDbError(e);
  }
}

/**
 * Xóa nguyên liệu — chỉ khi không còn món nào dùng trong định lượng.
 * Xóa luôn các doc tồn kho của nguyên liệu này ở mọi kho.
 */
export async function deleteIngredient(id: string): Promise<void> {
  try {
    const prods = await listProducts();
    const usedBy = prods
      .filter((p) => p.recipe.some((r) => r.ingredient_id === id))
      .map((p) => p.name);
    if (usedBy.length > 0) {
      throw new DbError(
        'invalid-argument',
        `Nguyên liệu đang dùng trong định lượng: ${usedBy.slice(0, 3).join(', ')}${usedBy.length > 3 ? '…' : ''}. Hãy xóa khỏi định lượng các món trước.`,
      );
    }
    const ings = await listIngredients();
    const usedBySemi = ings
      .filter((i) => (i.production_recipe ?? []).some((r) => r.ingredient_id === id))
      .map((i) => i.name);
    if (usedBySemi.length > 0) {
      throw new DbError(
        'invalid-argument',
        `Nguyên liệu đang dùng trong công thức sản xuất: ${usedBySemi.slice(0, 3).join(', ')}${usedBySemi.length > 3 ? '…' : ''}. Hãy xóa khỏi công thức trước.`,
      );
    }
    const batch = writeBatch(db);
    batch.delete(doc(db, 'ingredients', id));
    const lvSnap = await getDocs(
      query(collection(db, 'stock_levels'), where('ingredient_id', '==', id), limit(50)),
    );
    for (const d of lvSnap.docs) batch.delete(d.ref);
    await batch.commit();
  } catch (e) {
    throw toDbError(e);
  }
}

// ------------------------------------------------- sản xuất bán thành phẩm ---
function productionOrderFromDoc(
  snap: QueryDocumentSnapshot | DocumentSnapshot,
): ProductionOrder | null {
  if (!snap.exists()) return null;
  const d = snap.data() as Record<string, unknown>;
  return {
    id: snap.id,
    code: String(d.code ?? ''),
    product_id: String(d.product_id ?? ''),
    product_name: String(d.product_name ?? ''),
    product_unit: String(d.product_unit ?? ''),
    qty_produced: Number(d.qty_produced ?? 0),
    ingredients_used: Array.isArray(d.ingredients_used)
      ? (d.ingredients_used as Array<Record<string, unknown>>).map((it) => ({
          ingredient_id: String(it.ingredient_id ?? ''),
          ingredient_name: String(it.ingredient_name ?? ''),
          unit: String(it.unit ?? ''),
          qty: Number(it.qty ?? 0),
        }))
      : [],
    warehouse_id: String(d.warehouse_id ?? ''),
    warehouse_name: String(d.warehouse_name ?? ''),
    batch_cost: d.batch_cost != null ? Number(d.batch_cost) : undefined,
    new_cost_per_unit: d.new_cost_per_unit != null ? Number(d.new_cost_per_unit) : undefined,
    note: (d.note as string | null) ?? null,
    business_date: String(d.business_date ?? ''),
    created_by: (d.created_by as string | null) ?? null,
    created_at: tsToIso(d.created_at),
  };
}

/**
 * Lưu công thức sản xuất bán thành phẩm: định lượng nguyên liệu thô
 * cho 1 đơn vị thành phẩm (tính theo đơn vị của chính nó).
 * VD: 1ml kem muối cần 0.8ml kem béo + 0.05g muối hồng.
 * Chỉ chủ quán (rules).
 */
export async function updateIngredientProductionRecipe(
  ingredientId: string,
  recipe: Array<{ ingredient_id: string; qty: number }>,
  batchQty?: number | null,
): Promise<void> {
  const clean = (recipe ?? [])
    .map((r) => ({
      ingredient_id: String(r.ingredient_id ?? ''),
      qty: Number(r.qty ?? 0),
    }))
    .filter((r) => r.ingredient_id && Number.isFinite(r.qty) && r.qty > 0);
  // Không cho tự tham chiếu chính mình
  if (clean.some((r) => r.ingredient_id === ingredientId)) {
    throw new DbError('invalid-argument', 'Công thức không được chứa chính nguyên liệu này.');
  }
  // Không trùng nguyên liệu thô
  const seen = new Set<string>();
  for (const r of clean) {
    if (seen.has(r.ingredient_id)) throw new DbError('invalid-argument', 'Công thức bị trùng nguyên liệu thô.');
    seen.add(r.ingredient_id);
  }
  try {
    const batch = batchQty != null && Number(batchQty) > 0 ? Number(batchQty) : null;
    await updateDoc(doc(db, 'ingredients', ingredientId), {
      production_recipe: clean.length > 0 ? clean : deleteField(),
      production_batch_qty: batch ?? deleteField(),
    });
    logAudit('production.recipe', `Cập nhật công thức SX cho nguyên liệu ${ingredientId} (${clean.length} NL)`, {
      type: 'ingredient',
      id: ingredientId,
    });
  } catch (e) {
    throw toDbError(e);
  }
}

export interface ProduceSemiFinishedInput {
  ingredientId: string;
  qty: number; // số lượng thành phẩm cần tạo (theo đơn vị của nó)
  warehouseId: string;
  note?: string | null;
  businessDate?: string | null; // YYYY-MM-DD
}

/**
 * Sản xuất bán thành phẩm: trừ tồn nguyên liệu thô theo công thức,
 * cộng tồn thành phẩm. Ghi phiếu sản xuất (mã SX001 theo ngày).
 * Chỉ quản lý trở lên (rules + UI).
 */
export async function produceSemiFinished(input: ProduceSemiFinishedInput): Promise<ProductionOrder> {
  const ingredientId = String(input.ingredientId ?? '');
  const qty = Number(input.qty ?? 0);
  const warehouseId = String(input.warehouseId ?? '');
  if (!ingredientId) throw new DbError('invalid-argument', 'Thiếu bán thành phẩm.');
  if (!Number.isFinite(qty) || qty <= 0) throw new DbError('invalid-argument', 'Số lượng sản xuất phải lớn hơn 0.');
  if (!warehouseId) throw new DbError('invalid-argument', 'Thiếu kho sản xuất.');
  const businessDate = validYMD(input.businessDate) ? (input.businessDate as string) : todayVN();
  const note = typeof input.note === 'string' ? input.note.trim().slice(0, 500) : '';
  // Số thứ tự toàn cục cho mã phiếu SX (gọi ngoài transaction)
  const sxSeqStart = await nextGlobalSeq('prod_seq', 'SX', 'production_orders');
  // Giá vốn toàn cục hiện tại của bán thành phẩm (đọc TRƯỚC transaction vì
  // tx.get không nhận Query): tổng hợp từ stock_levels của MỌI kho. Bản cũ lấy
  // tồn riêng kho sản xuất nhân giá toàn cục rồi ghi đè giá toàn cục, nên sản
  // xuất ở kho A làm thay đổi giá vốn phần tồn đang nằm ở kho B.
  const preIngSnap = await getDoc(doc(db, 'ingredients', ingredientId));
  const semiOldCost = preIngSnap.exists()
    ? Math.max(0, Number((preIngSnap.data() as Record<string, unknown>).cost_per_unit ?? 0) || 0)
    : 0;
  const preLvlSnap = await getDocs(
    query(collection(db, 'stock_levels'), where('ingredient_id', '==', ingredientId)),
  );
  let gStock = 0;
  let gValue = 0;
  preLvlSnap.forEach((d) => {
    const dd = d.data() as Record<string, unknown>;
    const s = Number(dd.stock ?? 0);
    const a = Number(dd.avg_cost ?? 0);
    gStock += s;
    gValue += s * (a > 0 ? a : semiOldCost);
  });
  const gAvg = gStock > 0 ? gValue / gStock : semiOldCost;
  try {
    let saved: ProductionOrder | undefined;
    await runTransaction(db, async (tx) => {
      // ---- PHASE 1: đọc ----
      const ingSnap = await tx.get(doc(db, 'ingredients', ingredientId));
      if (!ingSnap.exists()) throw new DbError('not-found', 'Không tìm thấy bán thành phẩm.');
      const ing = toIngredient(ingSnap.id, ingSnap.data() as Record<string, unknown>);
      const recipe = ing.production_recipe ?? [];
      if (recipe.length === 0) {
        throw new DbError('invalid-argument', `“${ing.name}” chưa có công thức sản xuất. Hãy nhập công thức trước.`);
      }
      // Công thức tính theo mẻ: 1 mẻ làm ra batchQty đơn vị thành phẩm
      const batchQty = ing.production_batch_qty && ing.production_batch_qty > 0 ? ing.production_batch_qty : 1;
      const wSnap = await tx.get(doc(db, 'warehouses', warehouseId));
      if (!wSnap.exists()) throw new DbError('invalid-argument', 'Kho sản xuất không tồn tại.');
      const warehouseName = String((wSnap.data() as Record<string, unknown>).name ?? 'Kho');

      // Mã phiếu SX đánh số liên tục toàn hệ thống (không reset theo ngày)
      const counterRef = doc(db, 'counters', 'prod_seq');
      const cSnap = await tx.get(counterRef);
      const txNext = cSnap.exists() ? Number((cSnap.data() as Record<string, unknown>).last ?? 0) + 1 : 1;
      const next = Math.max(txNext, sxSeqStart);
      const code = 'SX' + String(next).padStart(3, '0');
      // (ghi counter ở PHASE 2 — transaction yêu cầu đọc xong hết mới được ghi)

      // Nguyên liệu thô cần dùng + tồn hiện tại
      const needs = new Map<string, number>();
      const state = new Map<string, { stock: number; name: string; unit: string; cost: number }>();
      const usedItems: ProductionOrder['ingredients_used'] = [];
      for (const r of recipe) {
        const needQty = (r.qty * qty) / batchQty;
        const iRef = doc(db, 'ingredients', r.ingredient_id);
        const lRef = doc(db, 'stock_levels', stockLevelId(warehouseId, r.ingredient_id));
        const [iSnap, lSnap] = await Promise.all([tx.get(iRef), tx.get(lRef)]);
        if (!iSnap.exists()) throw new DbError('invalid-argument', 'Nguyên liệu thô trong công thức không còn tồn tại.');
        const iData = iSnap.data() as Record<string, unknown>;
        const iName = String(iData.name ?? '');
        const iUnit = String(iData.unit ?? '');
        // Giá vốn nguyên liệu thô: ưu tiên giá bình quân tại kho này (do phiếu
        // nhập cập nhật), chưa có thì dùng giá nhập tay cost_per_unit.
        const lvlAvg = lSnap.exists() ? Number((lSnap.data() as Record<string, unknown>).avg_cost ?? 0) : 0;
        const iCost = lvlAvg > 0 ? lvlAvg : Math.max(0, Number(iData.cost_per_unit ?? 0) || 0);
        const curStock = lSnap.exists() ? Number((lSnap.data() as Record<string, unknown>).stock ?? 0) : 0;
        if (curStock < needQty) {
          throw new DbError(
            'invalid-argument',
            `Không đủ “${iName}”: cần ${needQty} ${iUnit}, kho chỉ còn ${curStock} ${iUnit}.`,
          );
        }
        needs.set(r.ingredient_id, (needs.get(r.ingredient_id) ?? 0) + needQty);
        if (!state.has(r.ingredient_id)) state.set(r.ingredient_id, { stock: curStock, name: iName, unit: iUnit, cost: iCost });
        usedItems.push({ ingredient_id: r.ingredient_id, ingredient_name: iName, unit: iUnit, qty: needQty });
      }
      // Tồn hiện tại của bán thành phẩm
      const pLevelRef = doc(db, 'stock_levels', stockLevelId(warehouseId, ingredientId));
      const pLevelSnap = await tx.get(pLevelRef);
      const pStock = pLevelSnap.exists() ? Number((pLevelSnap.data() as Record<string, unknown>).stock ?? 0) : 0;
      const pAvgLevel = pLevelSnap.exists() ? Number((pLevelSnap.data() as Record<string, unknown>).avg_cost ?? 0) : 0;
      const createdBy = auth.currentUser?.uid ?? null;

      // ---- PHASE 2: ghi ----
      if (cSnap.exists()) tx.update(counterRef, { last: next });
      else tx.set(counterRef, { last: next });

      // Id phiếu biết trước để gán ref_id cho các log
      const poRefEarly = doc(collection(db, 'production_orders'));

      // Trừ nguyên liệu thô
      for (const [rawId, needQty] of needs) {
        const st = state.get(rawId);
        if (!st) continue;
        const balanceAfter = st.stock - needQty;
        tx.set(
          doc(db, 'stock_levels', stockLevelId(warehouseId, rawId)),
          {
            warehouse_id: warehouseId,
            ingredient_id: rawId,
            ingredient_name: st.name,
            stock: balanceAfter,
          },
          { merge: true },
        );
        const logRef = doc(collection(db, 'stock_logs'));
        tx.set(logRef, {
          id: logRef.id,
          warehouse_id: warehouseId,
          warehouse_name: warehouseName,
          ingredient_id: rawId,
          ingredient_name: st.name,
          change: -needQty,
          balance_after: balanceAfter,
          note: `SX ${code}: sản xuất ${qty} ${ing.unit} ${ing.name}`,
          ref_type: 'production',
          ref_id: poRefEarly.id,
          created_by: createdBy,
          created_at: serverTimestamp(),
        });
      }
      // Tính giá vốn bình quân gia quyền cho bán thành phẩm
      // Tổng giá vốn nguyên liệu thô của mẻ này
      let batchRawCost = 0;
      for (const [rawId, needQty] of needs) {
        const st = state.get(rawId);
        if (st) batchRawCost += needQty * st.cost;
      }
      const oldCost = semiOldCost;
      const newCostPerUnit = gStock + qty > 0
        ? round2((gStock * gAvg + batchRawCost) / (gStock + qty))
        : round2(batchRawCost / Math.max(1, qty));
      // Cập nhật giá vốn vào nguyên liệu bán thành phẩm
      tx.update(doc(db, 'ingredients', ingredientId), { cost_per_unit: newCostPerUnit });
      // Giá vốn bình quân riêng tại kho sản xuất (ghi kèm khi cộng tồn ở dưới).
      // Giữ 2 số thập phân: đơn vị ml/g mà làm tròn số nguyên thì mỗi mẻ lệch vài trăm đồng.
      const newLevelAvg = pStock + qty > 0
        ? round2((pStock * (pAvgLevel > 0 ? pAvgLevel : oldCost) + batchRawCost) / (pStock + qty))
        : newCostPerUnit;

      // Cộng bán thành phẩm
      const pBalanceAfter = pStock + qty;
      tx.set(
        pLevelRef,
        {
          warehouse_id: warehouseId,
          ingredient_id: ingredientId,
          ingredient_name: ing.name,
          stock: pBalanceAfter,
          avg_cost: newLevelAvg,
        },
        { merge: true },
      );
      const pLogRef = doc(collection(db, 'stock_logs'));
      tx.set(pLogRef, {
        id: pLogRef.id,
        warehouse_id: warehouseId,
        warehouse_name: warehouseName,
        ingredient_id: ingredientId,
        ingredient_name: ing.name,
        change: qty,
        balance_after: pBalanceAfter,
        note: `SX ${code}: sản xuất ${qty} ${ing.unit}`,
        ref_type: 'production',
        ref_id: poRefEarly.id,
        created_by: createdBy,
        created_at: serverTimestamp(),
      });

      // Phiếu sản xuất
      const poRef = poRefEarly;
      const poData = {
        id: poRef.id,
        code,
        product_id: ingredientId,
        product_name: ing.name,
        product_unit: ing.unit,
        qty_produced: qty,
        ingredients_used: usedItems,
        batch_cost: round2(batchRawCost),
        new_cost_per_unit: newCostPerUnit,
        warehouse_id: warehouseId,
        warehouse_name: warehouseName,
        note: note || null,
        business_date: businessDate,
        created_by: createdBy,
        created_at: serverTimestamp(),
      };
      tx.set(poRef, poData);
      saved = {
        ...poData,
        note: poData.note,
        created_by: poData.created_by,
        created_at: new Date().toISOString(),
      };
    });
    if (!saved) throw new DbError('unknown', 'Sản xuất thất bại.');
    logAudit('production.create', `SX ${saved.code}: ${saved.qty_produced} ${saved.product_unit} ${saved.product_name}`, {
      type: 'production_order',
      id: saved.id,
    });
    return saved;
  } catch (e) {
    throw toDbError(e);
  }
}

/** Danh sách phiếu sản xuất — mới nhất trước. */
export async function listProductionOrders(limitN = 100): Promise<ProductionOrder[]> {
  const n = Math.min(Math.max(limitN, 1), 500);
  try {
    const snap = await getDocs(
      query(collection(db, 'production_orders'), orderBy('created_at', 'desc'), limit(n)),
    );
    return snap.docs.map(productionOrderFromDoc).filter((p): p is ProductionOrder => !!p);
  } catch (e) {
    throw toDbError(e);
  }
}

/**
 * Xóa phiếu sản xuất: cộng lại nguyên liệu thô đã trừ, trừ đi bán thành phẩm
 * đã cộng. Chỉ chủ quán.
 */
export async function deleteProductionOrder(id: string): Promise<void> {
  // Đọc trước transaction (tx.get không nhận Query): giá vốn mẻ SX + tổng hợp
  // giá vốn toàn cục của bán thành phẩm để hoàn tác đúng khi xóa phiếu.
  const prePoSnap = await getDoc(doc(db, 'production_orders', id));
  const prePo = prePoSnap.exists() ? productionOrderFromDoc(prePoSnap) : null;
  let batchCost = prePo?.batch_cost != null ? Number(prePo.batch_cost) : 0;
  if (prePo && prePo.batch_cost == null) {
    // Phiếu cũ chưa lưu batch_cost: ước lại từ định lượng x giá nhập tay hiện tại
    for (const it of prePo.ingredients_used) {
      const iSnap = await getDoc(doc(db, 'ingredients', it.ingredient_id));
      const c = iSnap.exists()
        ? Math.max(0, Number((iSnap.data() as Record<string, unknown>).cost_per_unit ?? 0) || 0)
        : 0;
      batchCost += it.qty * c;
    }
  }
  const pIngSnapPre = prePo ? await getDoc(doc(db, 'ingredients', prePo.product_id)) : null;
  const pIngCost = pIngSnapPre?.exists()
    ? Math.max(0, Number((pIngSnapPre.data() as Record<string, unknown>).cost_per_unit ?? 0) || 0)
    : 0;
  let gStock = 0;
  let gValue = 0;
  if (prePo) {
    const allLvl = await getDocs(
      query(collection(db, 'stock_levels'), where('ingredient_id', '==', prePo.product_id)),
    );
    allLvl.forEach((d) => {
      const dd = d.data() as Record<string, unknown>;
      const s = Number(dd.stock ?? 0);
      const a = Number(dd.avg_cost ?? 0);
      gStock += s;
      gValue += s * (a > 0 ? a : pIngCost);
    });
  }
  const gAvg = gStock > 0 ? gValue / gStock : pIngCost;
  try {
    await runTransaction(db, async (tx) => {
      const poRef = doc(db, 'production_orders', id);
      const poSnap = await tx.get(poRef);
      const po = poSnap.exists() ? productionOrderFromDoc(poSnap) : null;
      if (!po) throw new DbError('not-found', 'Không tìm thấy phiếu sản xuất.');
      const createdBy = auth.currentUser?.uid ?? null;

      // ---- PHASE 1: đọc tồn hiện tại (mọi tx.get phải xong trước mọi tx.set/update/delete) ----
      // Tồn nguyên liệu thô (mỗi nguyên liệu đọc 1 lần) + tồn bán thành phẩm
      const curStock = new Map<string, number>();
      for (const it of po.ingredients_used) {
        if (curStock.has(it.ingredient_id)) continue;
        const lr = doc(db, 'stock_levels', stockLevelId(po.warehouse_id, it.ingredient_id));
        const ls = await tx.get(lr);
        curStock.set(
          it.ingredient_id,
          ls.exists() ? Number((ls.data() as Record<string, unknown>).stock ?? 0) : 0,
        );
      }
      const pRef = doc(db, 'stock_levels', stockLevelId(po.warehouse_id, po.product_id));
      const pSnap = await tx.get(pRef);
      const pCur = pSnap.exists() ? Number((pSnap.data() as Record<string, unknown>).stock ?? 0) : 0;
      const pAvgCur = pSnap.exists() ? Number((pSnap.data() as Record<string, unknown>).avg_cost ?? 0) : 0;
      const pIngRef = doc(db, 'ingredients', po.product_id);
      // SUA 25/10/2026 (chan ton BTP am): da ban het ban thanh pham roi thi
      // khong duoc xoa phieu san xuat (xoa se tru am), phai xu ly don ban truoc.
      if (pCur < po.qty_produced) {
        throw new DbError(
          'invalid-argument',
          `Không xóa được phiếu ${po.code}: ${po.product_name} chỉ còn ${pCur}, không đủ để trừ lại ${po.qty_produced} đã sản xuất (phần đã bán phải xử lý trước).`,
        );
      }

      // ---- PHASE 2: ghi ----
      // Hoàn nguyên liệu thô (cộng lại)
      const running = new Map<string, number>();
      for (const it of po.ingredients_used) {
        const lRef = doc(db, 'stock_levels', stockLevelId(po.warehouse_id, it.ingredient_id));
        const balanceAfter = (running.get(it.ingredient_id) ?? curStock.get(it.ingredient_id) ?? 0) + it.qty;
        running.set(it.ingredient_id, balanceAfter);
        tx.set(
          lRef,
          {
            warehouse_id: po.warehouse_id,
            ingredient_id: it.ingredient_id,
            ingredient_name: it.ingredient_name,
            stock: balanceAfter,
          },
          { merge: true },
        );
        const logRef = doc(collection(db, 'stock_logs'));
        tx.set(logRef, {
          id: logRef.id,
          warehouse_id: po.warehouse_id,
          warehouse_name: po.warehouse_name,
          ingredient_id: it.ingredient_id,
          ingredient_name: it.ingredient_name,
          change: it.qty,
          balance_after: balanceAfter,
          note: `Xóa phiếu SX ${po.code} (hoàn nguyên liệu)`,
          ref_type: 'production',
          ref_id: po.id,
          created_by: createdBy,
          created_at: serverTimestamp(),
        });
      }
      // Trừ bán thành phẩm đã cộng + gỡ lớp giá vốn của mẻ này (bản cũ chỉ hoàn
      // số lượng, giá vốn sau sản xuất giữ nguyên kể cả khi đã xóa phiếu).
      const pAfter = pCur - po.qty_produced;
      tx.set(
        pRef,
        {
          warehouse_id: po.warehouse_id,
          ingredient_id: po.product_id,
          ingredient_name: po.product_name,
          stock: pAfter,
          avg_cost: wacRemove(pCur, pAvgCur > 0 ? pAvgCur : pIngCost, po.qty_produced, batchCost),
        },
        { merge: true },
      );
      if (batchCost > 0 && pIngSnapPre?.exists()) {
        tx.update(pIngRef, {
          cost_per_unit: wacRemove(gStock, gAvg, po.qty_produced, batchCost),
        });
      }
      const pLogRef = doc(collection(db, 'stock_logs'));
      tx.set(pLogRef, {
        id: pLogRef.id,
        warehouse_id: po.warehouse_id,
        warehouse_name: po.warehouse_name,
        ingredient_id: po.product_id,
        ingredient_name: po.product_name,
        change: -po.qty_produced,
        balance_after: pAfter,
        note: `Xóa phiếu SX ${po.code} (hoàn thành phẩm)`,
        ref_type: 'production',
        ref_id: po.id,
        created_by: createdBy,
        created_at: serverTimestamp(),
      });

      tx.delete(poRef);
    });
    logAudit('production.delete', `Xóa phiếu sản xuất ${id}`, { type: 'production_order', id });
  } catch (e) {
    throw toDbError(e);
  }
}

// ------------------------------------------------- stock helpers (transaction) ---
// Các helper này dùng CHUNG cho tạo đơn / hủy đơn / xóa đơn.
// NGUYÊN TẮC: mọi tx.get() phải xong trước mọi tx.set()/update()/delete().

/** Tổng nguyên liệu cần trừ/cộng từ các dòng đơn (dương = số lượng cần). */
function calcNeeds(lines: Array<{ qty: number; recipe?: RecipeItem[] }>): Map<string, number> {
  const needs = new Map<string, number>();
  for (const l of lines) {
    for (const r of l.recipe ?? []) {
      const q = Number(r.qty ?? 0) * l.qty;
      if (r.ingredient_id && q > 0 && Number.isFinite(q)) {
        needs.set(r.ingredient_id, (needs.get(r.ingredient_id) ?? 0) + q);
      }
    }
  }
  return needs;
}

interface StockState {
  stock: number;
  name: string;
}

/**
 * Đọc tồn hiện tại + tên nguyên liệu tại 1 kho (PHASE ĐỌC trong transaction).
 * Đơn cũ không có snapshot recipe thì đọc định lượng hiện tại của món.
 */
async function readStockState(
  tx: Transaction,
  order: Order,
  warehouseId: string,
): Promise<{ needs: Map<string, number>; state: Map<string, StockState> }> {
  const needs = calcNeeds(order.items);
  // Đơn cũ chưa có snapshot định lượng → dùng định lượng hiện tại của món
  const noSnapshot = order.items.filter((it) => !(it.recipe && it.recipe.length > 0));
  if (noSnapshot.length > 0) {
    const prodIds = [...new Set(noSnapshot.map((it) => it.product_id).filter(Boolean))];
    const pSnaps = await Promise.all(prodIds.map((pid) => tx.get(doc(db, 'products', pid))));
    for (const pSnap of pSnaps) {
      if (!pSnap.exists()) continue;
      const p = toProduct(pSnap.id, pSnap.data() as Record<string, unknown>);
      for (const it of noSnapshot.filter((m) => m.product_id === p.id)) {
        for (const r of p.recipe) {
          const q = Number(r.qty ?? 0) * it.qty;
          if (r.ingredient_id && q > 0 && Number.isFinite(q)) {
            needs.set(r.ingredient_id, (needs.get(r.ingredient_id) ?? 0) + q);
          }
        }
      }
    }
  }
  const state = new Map<string, StockState>();
  if (needs.size > 0) {
    const ids = [...needs.keys()];
    const [lSnaps, iSnaps] = await Promise.all([
      Promise.all(ids.map((ingId) => tx.get(doc(db, 'stock_levels', stockLevelId(warehouseId, ingId))))),
      Promise.all(ids.map((ingId) => tx.get(doc(db, 'ingredients', ingId)))),
    ]);
    ids.forEach((ingId, i) => {
      const lSnap = lSnaps[i];
      const iSnap = iSnaps[i];
      if (!iSnap.exists()) return; // nguyên liệu đã bị xóa → bỏ qua
      const lData = (lSnap.exists() ? lSnap.data() : {}) as Record<string, unknown>;
      state.set(ingId, {
        stock: Number(lData.stock ?? 0),
        name:
          String(lData.ingredient_name ?? '') ||
          String((iSnap.data() as Record<string, unknown>).name ?? ''),
      });
    });
  }
  return { needs, state };
}

export type StockRefType = 'order' | 'transfer' | 'manual' | 'purchase' | 'stock_export' | 'check' | 'production';

/**
 * Ghi biến động tồn kho (PHASE GHI trong transaction — không đọc gì thêm).
 * delta > 0: cộng tồn (hoàn kho / nhập); delta < 0: trừ tồn (bán / xuất).
 */
function writeStockMoves(
  tx: Transaction,
  args: {
    warehouseId: string;
    warehouseName: string | null;
    needs: Map<string, number>;
    state: Map<string, StockState>;
    sign: 1 | -1; // 1 = cộng tồn, -1 = trừ tồn
    note: string;
    ref_type: StockRefType;
    ref_id: string | null;
    createdBy: string | null;
    // Giá vốn bình quân MỚI cho từng nguyên liệu (chỉ phiếu nhập/SX truyền vào);
    // không truyền -> giữ nguyên avg_cost đang có trong stock_levels.
    avgCostUpdates?: Map<string, number>;
  },
): void {
  const { warehouseId, warehouseName, needs, state, sign, note, ref_type, ref_id, createdBy } = args;
  for (const [ingId, qty] of needs) {
    const st = state.get(ingId);
    if (!st) continue;
    const balance_after = st.stock + sign * qty;
    const newAvg = args.avgCostUpdates?.get(ingId);
    tx.set(
      doc(db, 'stock_levels', stockLevelId(warehouseId, ingId)),
      {
        warehouse_id: warehouseId,
        ingredient_id: ingId,
        ingredient_name: st.name,
        stock: balance_after,
        ...(newAvg != null ? { avg_cost: newAvg, updated_at: serverTimestamp() } : {}),
      },
      { merge: true },
    );
    const logRef = doc(collection(db, 'stock_logs'));
    tx.set(logRef, {
      id: logRef.id,
      warehouse_id: warehouseId,
      warehouse_name: warehouseName,
      ingredient_id: ingId,
      ingredient_name: st.name,
      change: sign * qty,
      balance_after,
      note,
      ref_type,
      ref_id,
      created_by: createdBy,
      created_at: serverTimestamp(),
    });
  }
}
// --------------------------------------------------------------- customers ---
export async function searchCustomers(q: string): Promise<Customer[]> {
  try {
    const snap = await getDocs(collection(db, 'customers'));
    const all = snap.docs.map((d) => toCustomer(d.id, d.data()));
    const needle = unsignVietnamese(String(q ?? '')).toLowerCase();
    const filtered = needle
      ? all.filter((c) => {
          const hay = unsignVietnamese(`${c.name} ${c.phone}`).toLowerCase();
          return hay.includes(needle);
        })
      : all;
    filtered.sort((a, b) => a.name.localeCompare(b.name, 'vi'));
    return filtered;
  } catch (e) {
    throw toDbError(e);
  }
}

export async function getCustomer(
  id: string,
): Promise<(Customer & { recent_orders: Order[] }) | null> {
  try {
    const snap = await getDoc(doc(db, 'customers', id));
    if (!snap.exists()) return null;
    const customer = toCustomer(snap.id, snap.data());
    const oSnap = await getDocs(
      query(
        collection(db, 'orders'),
        where('customer_id', '==', id),
        orderBy('created_at', 'desc'),
        limit(20),
      ),
    );
    const recent_orders = oSnap.docs
      .map((d) => orderFromDoc(d))
      .filter((o): o is Order => o !== null);
    return { ...customer, recent_orders };
  } catch (e) {
    throw toDbError(e);
  }
}

export async function createCustomer(d: {
  name: string;
  phone: string;
  birthday?: string | null;
  address?: string | null;
  note?: string | null;
  warehouse_id?: string | null;
}): Promise<Customer> {
  const name = String(d.name ?? '').trim();
  const phone = String(d.phone ?? '').trim();
  if (!name) throw new DbError('invalid-argument', 'Vui lòng nhập tên khách hàng.');
  if (!phone) throw new DbError('invalid-argument', 'Vui lòng nhập số điện thoại.');
  try {
    const dup = await getDocs(query(collection(db, 'customers'), where('phone', '==', phone), limit(1)));
    if (!dup.empty) {
      throw new DbError('invalid-argument', `Số điện thoại ${phone} đã được đăng ký cho khách khác.`);
    }
    const id = uuid();
    const data = {
      id,
      name,
      phone,
      birthday: d.birthday ?? null,
      address: typeof d.address === 'string' && d.address ? d.address.slice(0, 500) : null,
      stamps: 0,
      reward_available: false,
      debt: 0,
      note: typeof d.note === 'string' && d.note ? d.note.slice(0, 1000) : null,
      warehouse_id: typeof d.warehouse_id === 'string' && d.warehouse_id ? d.warehouse_id : null,
      created_at: serverTimestamp(),
    };
    await setDoc(doc(db, 'customers', id), data);
    const snap = await getDoc(doc(db, 'customers', id));
    const c = snap.exists() ? toCustomer(snap.id, snap.data()) : null;
    if (!c) throw new DbError('unknown', 'Không đọc được khách hàng vừa tạo.');
    return c;
  } catch (e) {
    throw toDbError(e);
  }
}

export async function updateCustomer(
  id: string,
  patch: Partial<Pick<Customer, 'name' | 'phone' | 'birthday' | 'address' | 'note' | 'warehouse_id' | 'zalo_user_id'>>,
): Promise<void> {
  const data: Record<string, unknown> = {};
  if (patch.name !== undefined) {
    const trimmed = String(patch.name).trim();
    if (!trimmed) throw new DbError('invalid-argument', 'Tên khách hàng không được để trống.');
    data.name = trimmed;
  }
  if (patch.phone !== undefined) {
    const trimmed = String(patch.phone).trim();
    if (!trimmed) throw new DbError('invalid-argument', 'Số điện thoại không được để trống.');
    data.phone = trimmed;
  }
  if (patch.birthday !== undefined) data.birthday = patch.birthday;
  if (patch.address !== undefined) data.address = patch.address;
  if (patch.note !== undefined) data.note = patch.note;
  if (patch.warehouse_id !== undefined)
    data.warehouse_id = patch.warehouse_id ? String(patch.warehouse_id) : null;
  if (patch.zalo_user_id !== undefined)
    data.zalo_user_id = patch.zalo_user_id ? String(patch.zalo_user_id).trim() : null;
  if (Object.keys(data).length === 0) return;
  try {
    if (data.phone !== undefined) {
      const dup = await getDocs(
        query(collection(db, 'customers'), where('phone', '==', data.phone), limit(2)),
      );
      if (dup.docs.some((x) => x.id !== id)) {
        throw new DbError(
          'invalid-argument',
          `Số điện thoại ${data.phone} đã được đăng ký cho khách khác.`,
        );
      }
    }
    await updateDoc(doc(db, 'customers', id), data);
  } catch (e) {
    throw toDbError(e);
  }
}

// --------------------------------------------------------------- công nợ ---
// Điều chỉnh công nợ khách hàng: amount > 0 = ghi nợ thêm, amount < 0 = thu nợ.
// Ghi lịch sử vào subcollection debt_logs để đối chiếu.
export async function adjustDebt(
  customerId: string,
  amount: number,
  note?: string | null,
): Promise<number> {
  const delta = Number(amount);
  if (!Number.isFinite(delta) || delta === 0) {
    throw new DbError('invalid-argument', 'Số tiền điều chỉnh công nợ không hợp lệ.');
  }
  try {
    const balanceAfter = await runTransaction(db, async (tx) => {
      const ref = doc(db, 'customers', customerId);
      const snap = await tx.get(ref);
      if (!snap.exists()) throw new DbError('not-found', 'Khách hàng không tồn tại.');
      const cur = Number(snap.data().debt ?? 0);
      const next = cur + delta;
      if (next < 0) throw new DbError('invalid-argument', `Số tiền thu (${formatVNDLocal(-delta)}) lớn hơn công nợ hiện tại (${formatVNDLocal(cur)}).`);
      tx.update(ref, { debt: next });
      const logRef = doc(collection(db, 'customers', customerId, 'debt_logs'));
      tx.set(logRef, {
        id: logRef.id,
        amount: delta,
        balance_after: next,
        note: typeof note === 'string' && note ? note.slice(0, 500) : null,
        created_by: auth.currentUser?.uid ?? null,
        created_at: serverTimestamp(),
      });
      return next;
    });
    return balanceAfter;
  } catch (e) {
    throw toDbError(e);
  }
}

function formatVNDLocal(n: number): string {
  return new Intl.NumberFormat('vi-VN').format(Math.round(n)) + 'đ';
}

/**
 * Thu nợ khách hàng: trừ công nợ + ghi khoản thu vào sổ quỹ TRONG 1 TRANSACTION.
 * Fix VẤN ĐỀ 3: trước đây là 2 call rời (adjustDebt rồi addCashbookEntry) —
 * nếu call 2 fail thì nợ đã trừ nhưng quỹ không ghi; double-tap thì trừ 2 lần.
 */
export async function collectCustomerDebt(
  customerId: string,
  amount: number,
  opts: {
    note?: string | null;
    fundId?: string | null;
    method?: 'cash' | 'transfer' | null;
    warehouseId?: string | null;
    occurredAt?: string | null;
  } = {},
): Promise<number> {
  const v = Math.round(Number(amount));
  if (!Number.isFinite(v) || v <= 0) throw new DbError('invalid-argument', 'Số tiền thu không hợp lệ.');
  try {
    const balanceAfter = await runTransaction(db, async (tx) => {
      const ref = doc(db, 'customers', customerId);
      const snap = await tx.get(ref);
      if (!snap.exists()) throw new DbError('not-found', 'Khách hàng không tồn tại.');
      const cData = snap.data() as Record<string, unknown>;
      const cur = Number(cData.debt ?? 0);
      if (v > cur) {
        throw new DbError('invalid-argument', `Số tiền thu (${formatVNDLocal(v)}) lớn hơn công nợ hiện tại (${formatVNDLocal(cur)}).`);
      }
      const next = cur - v;
      tx.update(ref, { debt: next });
      const customerName = String(cData.name ?? '');
      const finalNote =
        typeof opts.note === 'string' && opts.note.trim()
          ? opts.note.trim().slice(0, 500)
          : `Thu nợ — ${customerName}`;
      // Nhật ký công nợ
      const logRef = doc(collection(db, 'customers', customerId, 'debt_logs'));
      tx.set(logRef, {
        id: logRef.id,
        amount: -v,
        balance_after: next,
        note: finalNote,
        created_by: auth.currentUser?.uid ?? null,
        created_at: serverTimestamp(),
      });
      // Khoản thu vào sổ quỹ (cùng transaction → không bao giờ lệch)
      const fundRef = doc(collection(db, 'cashbook_entries'));
      tx.set(fundRef, {
        id: fundRef.id,
        type: 'thu',
        amount: v,
        note: finalNote,
        category: 'Thu nợ',
        fund_id: typeof opts.fundId === 'string' && opts.fundId.trim() ? opts.fundId.trim() : 'cash',
        ref_type: 'debt_pay',
        ref_id: customerId,
        method: opts.method ?? null,
        created_by: auth.currentUser?.uid ?? null,
        warehouse_id: typeof opts.warehouseId === 'string' && opts.warehouseId ? opts.warehouseId : null,
        created_at: parseISODateTime(opts.occurredAt)?.toISOString() ?? new Date().toISOString(),
      });
      return next;
    });
    logAudit('debt.collect', `Thu nợ ${formatVNDLocal(v)}`, { type: 'customer', id: customerId });
    return balanceAfter;
  } catch (e) {
    throw toDbError(e);
  }
}

export async function listDebtLogs(customerId: string, limitN = 20): Promise<DebtLog[]> {
  try {
    const snap = await getDocs(
      query(
        collection(db, 'customers', customerId, 'debt_logs'),
        orderBy('created_at', 'desc'),
        limit(limitN),
      ),
    );
    return snap.docs.map((d) => toDebtLog(d.id, d.data()));
  } catch (e) {
    throw toDbError(e);
  }
}

// ------------------------------------------------------------ sổ thu chi ---
// Thu/chi THỦ CÔNG của quán (nhập hàng, mặt bằng, lương...).
// LƯU Ý: đơn bán KHÔNG tự log vào đây — chỉ ghi tay qua màn hình Thu chi.
function toCashbookEntry(id: string, d: Record<string, unknown>): CashbookEntry {
  const rt = d.ref_type;
  return {
    id,
    type: d.type === 'chi' ? 'chi' : 'thu',
    amount: Number(d.amount ?? 0),
    code: (d.code as string | null) ?? null,
    note: (d.note as string | null) ?? null,
    category: String(d.category ?? 'Khác'),
    fund_id: String(d.fund_id ?? 'cash'),
    ref_type: rt === 'order' || rt === 'debt_pay' || rt === 'debt_refund' || rt === 'supplier_pay' || rt === 'transfer' ? (rt as FundRefType) : 'manual',
    ref_id: (d.ref_id as string | null) ?? null,
    ref_code: (d.ref_code as string | null) ?? null,
    method: d.method === 'cash' || d.method === 'transfer' ? d.method : null,
    created_by: (d.created_by as string | null) ?? null,
    warehouse_id: typeof d.warehouse_id === 'string' && d.warehouse_id ? d.warehouse_id : null,
    created_at: tsToIso(d.created_at),
  };
}

export interface AddCashbookOpts {
  refType?: FundRefType;
  refId?: string | null;
  method?: 'cash' | 'transfer' | null;
  fundId?: string | null; // quỹ nhận khoản này, mặc định 'cash'
  warehouseId?: string | null; // kho phát sinh khoản này (sổ quỹ độc lập theo kho)
  occurredAt?: string | null; // ISO datetime — thời gian phát sinh (mặc định: bây giờ)
}

export async function addCashbookEntry(
  type: CashbookType,
  amount: number,
  note?: string | null,
  category?: string | null,
  opts?: AddCashbookOpts,
): Promise<CashbookEntry> {
  const v = Math.round(Number(amount));
  if (!Number.isFinite(v) || v <= 0) {
    throw new DbError('invalid-argument', 'Số tiền phải lớn hơn 0.');
  }
  const id = uuid();
  // Số phiếu: thu thủ công PT001..., chi thủ công PC001... (tự động có ref_code riêng)
  const refType = opts?.refType ?? 'manual';
  // SUA 25/10/2026 (chong trung ma PT/PC): cap ma + ghi phieu phai o trong
  // CUNG transaction theo mau A/PN/SX/XK — truoc day lay so ngoai transaction
  // roi ghi counter bang setDoc thuong, loi bi nuot bang catch {} nen 2 may
  // cung doc last=50 se cung ra PT051. Gio: doc lai counter trong transaction,
  // next = max(txNext, seqStart), ghi counter o phase 2; transaction loi thi
  // khong co phieu nao duoc tao va loi KHONG bi nuot.
  const counterKey = type === 'thu' ? 'pt_seq' : 'pc_seq';
  const codePrefix = type === 'thu' ? 'PT' : 'PC';
  const seqStart =
    refType === 'manual'
      ? await nextGlobalSeq(counterKey, codePrefix, 'cashbook_entries')
      : null;
  const data = {
    id,
    type,
    amount: v,
    code: null as string | null,
    note: typeof note === 'string' && note.trim() ? note.trim().slice(0, 500) : null,
    category: typeof category === 'string' && category.trim() ? category.trim().slice(0, 50) : 'Khác',
    fund_id:
      typeof opts?.fundId === 'string' && opts.fundId.trim() ? opts.fundId.trim().slice(0, 60) : 'cash',
    ref_type: refType,
    ref_id: opts?.refId ?? null,
    method: opts?.method ?? null,
    created_by: auth.currentUser?.uid ?? null,
    warehouse_id:
      typeof opts?.warehouseId === 'string' && opts.warehouseId ? opts.warehouseId : null,
    created_at: parseISODateTime(opts?.occurredAt)?.toISOString() ?? new Date().toISOString(),
  };
  try {
    if (refType === 'manual' && seqStart !== null) {
      await runTransaction(db, async (tx) => {
        // PHASE 1: doc counter (Firestore transaction tu retry khi tranh chap,
        // nen may thu hai se doc lai last moi va nhan so tiep theo, khong trung).
        const counterRef = doc(db, 'counters', counterKey);
        const cSnap = await tx.get(counterRef);
        const txNext = cSnap.exists() ? Number((cSnap.data() as Record<string, unknown>).last ?? 0) + 1 : 1;
        const next = Math.max(txNext, seqStart);
        const slipCode = codePrefix + String(next).padStart(3, '0');
        // PHASE 2: ghi counter + ghi phieu trong cung transaction.
        if (cSnap.exists()) tx.update(counterRef, { last: next });
        else tx.set(counterRef, { last: next });
        tx.set(doc(db, 'cashbook_entries', id), { ...data, code: slipCode });
      });
    } else {
      await setDoc(doc(db, 'cashbook_entries', id), data);
    }
    const snap = await getDoc(doc(db, 'cashbook_entries', id));
    const e = snap.exists() ? toCashbookEntry(snap.id, snap.data() as Record<string, unknown>) : null;
    if (!e) throw new DbError('unknown', 'Không đọc được khoản vừa tạo.');
    return e;
  } catch (e) {
    throw toDbError(e);
  }
}

/** Xóa một khoản trong cặp chuyển quỹ (ref_type='transfer'): xóa cả 2 khoản đối ứng. */
export async function deleteTransferPair(id: string): Promise<void> {
  try {
    const snap = await getDoc(doc(db, 'cashbook_entries', id));
    const e = snap.exists() ? toCashbookEntry(snap.id, snap.data() as Record<string, unknown>) : null;
    if (!e) throw new DbError('not-found', 'Không tìm thấy khoản chuyển quỹ.');
    if (e.ref_type !== 'transfer' || !e.ref_id) {
      // Không phải khoản chuyển quỹ → xóa đơn lẻ như bình thường
      await deleteCashbookEntry(id);
      return;
    }
    const batch = writeBatch(db);
    batch.delete(doc(db, 'cashbook_entries', id));
    // Khoản đối ứng có ref_id trỏ về id này (lọc đơn để không cần composite index)
    const pairSnap = await getDocs(query(collection(db, 'cashbook_entries'), where('ref_id', '==', id), limit(5)));
    for (const d of pairSnap.docs) {
      if ((d.data() as Record<string, unknown>).ref_type === 'transfer') batch.delete(d.ref);
    }
    await batch.commit();
    logAudit('fund.transfer_delete', `Xóa cặp chuyển quỹ ${formatVNDLocal(e.amount)}`, {
      type: 'cashbook_entry',
      id,
    });
  } catch (e) {
    throw toDbError(e);
  }
}

/**
 * Chuyển tiền từ quỹ này sang quỹ khác — chỉ chủ quán (check ở UI, rules enforce).
 * Tạo 2 khoản cashbook_entries trong 1 batch:
 * - 1 khoản CHI từ quỹ nguồn (category 'Chuyển quỹ')
 * - 1 khoản THU vào quỹ đích (category 'Chuyển quỹ')
 * Cả 2 dùng ref_type='transfer', ref_id trỏ chéo nhau để truy vết cặp.
 */
export async function transferFunds(input: {
  fromFundId: string;
  toFundId: string;
  amount: number;
  note?: string | null;
  businessDate?: string | null;
  /** v6.3: chuỗi datetime-local (giờ VN); có thì thắng businessDate, không có thì giờ hiện tại. */
  businessDateTime?: string | null;
  warehouseId?: string | null;
}): Promise<{ outId: string; inId: string }> {
  const fromFundId = String(input.fromFundId ?? '').trim();
  const toFundId = String(input.toFundId ?? '').trim();
  const amount = Math.round(Number(input.amount));
  if (!fromFundId || !toFundId) throw new DbError('invalid-argument', 'Vui lòng chọn quỹ nguồn và quỹ đích.');
  if (fromFundId === toFundId) throw new DbError('invalid-argument', 'Quỹ nguồn và quỹ đích phải khác nhau.');
  if (!Number.isFinite(amount) || amount <= 0) throw new DbError('invalid-argument', 'Số tiền phải lớn hơn 0.');
  const businessDate = validYMD(input.businessDate) ? (input.businessDate as string) : todayVN();
  const note = typeof input.note === 'string' ? input.note.trim().slice(0, 500) : '';
  const warehouseId = typeof input.warehouseId === 'string' && input.warehouseId ? input.warehouseId : null;
  try {
    // Validate cả 2 quỹ tồn tại (đồng bộ từ phương thức thanh toán)
    const funds = await getFunds();
    const fromFund = funds.find((f) => f.id === fromFundId);
    const toFund = funds.find((f) => f.id === toFundId);
    if (!fromFund) throw new DbError('not-found', 'Quỹ nguồn không tồn tại.');
    if (!toFund) throw new DbError('not-found', 'Quỹ đích không tồn tại.');

    const outId = uuid();
    const inId = uuid();
    const createdBy = auth.currentUser?.uid ?? null;
    // v6.3: chuyển quỹ tạo mới dùng đúng giờ đã chọn (giờ VN), không còn
    // mặc định 00:00 UTC = 07:00 giờ VN khi chỉ chọn ngày.
    const createdAt =
      parseVNDateTimeInput(input.businessDateTime) ??
      parseISODateTime(businessDate)?.toISOString() ??
      new Date().toISOString();
    const outNote = `Chuyển sang ${toFund.name}${note ? ` — ${note}` : ''}`;
    const inNote = `Nhận từ ${fromFund.name}${note ? ` — ${note}` : ''}`;
    const batch = writeBatch(db);
    batch.set(doc(db, 'cashbook_entries', outId), {
      id: outId,
      type: 'chi',
      amount,
      note: outNote,
      category: 'Chuyển quỹ',
      fund_id: fromFundId,
      ref_type: 'transfer',
      ref_id: inId,
      ref_code: null,
      method: null,
      created_by: createdBy,
      warehouse_id: warehouseId,
      created_at: createdAt,
    });
    batch.set(doc(db, 'cashbook_entries', inId), {
      id: inId,
      type: 'thu',
      amount,
      note: inNote,
      category: 'Chuyển quỹ',
      fund_id: toFundId,
      ref_type: 'transfer',
      ref_id: outId,
      ref_code: null,
      method: null,
      created_by: createdBy,
      warehouse_id: warehouseId,
      created_at: createdAt,
    });
    await batch.commit();
    logAudit('fund.transfer', `Chuyển quỹ ${formatVNDLocal(amount)}: ${fromFund.name} → ${toFund.name}`, {
      type: 'cashbook_entry',
      id: outId,
    });
    return { outId, inId };
  } catch (e) {
    throw toDbError(e);
  }
}

/**
 * Sửa khoản thu/chi trong Sổ quỹ — chỉ chủ quán (check ở UI, rules enforce).
 * - CHỈ cho sửa khoản nhập tay (ref_type='manual') và chuyển quỹ (ref_type='transfer').
 * - CHẶN sửa khoản tự động từ đơn bán (ref_type='order') và thu nợ (ref_type='debt_pay').
 * - Khoản chuyển quỹ: sửa amount → cập nhật CẢ 2 khoản trong cặp (giữ bằng nhau);
 *   sửa note/category/fund → chỉ sửa khoản được chọn.
 */
export async function updateCashbookEntry(
  id: string,
  patch: {
    amount?: number;
    note?: string | null;
    category?: string;
    fund_id?: string;
    businessDate?: string; // YYYY-MM-DD → cập nhật created_at
    /** v6.3: chuỗi datetime-local (giờ VN); có thì thắng businessDate. */
    businessDateTime?: string | null;
  },
): Promise<void> {
  const eid = String(id ?? '').trim();
  if (!eid) throw new DbError('invalid-argument', 'Thiếu id khoản thu/chi.');
  try {
    const snap = await getDoc(doc(db, 'cashbook_entries', eid));
    const e = snap.exists() ? toCashbookEntry(snap.id, snap.data() as Record<string, unknown>) : null;
    if (!e) throw new DbError('not-found', 'Không tìm thấy khoản thu/chi.');
    if (e.ref_type === 'order' || e.ref_type === 'debt_pay') {
      throw new DbError(
        'invalid-argument',
        'Khoản tự động không sửa trực tiếp được. Hãy sửa đơn gốc.',
      );
    }
    if (e.ref_type !== 'manual' && e.ref_type !== 'transfer') {
      throw new DbError('invalid-argument', 'Khoản này không sửa được.');
    }
    const isTransferPair = e.ref_type === 'transfer' && !!e.ref_id;

    const data: Record<string, unknown> = {};
    let newAmount: number | null = null;
    let newDate: string | null = null;
    if (patch.amount !== undefined) {
      const v = Math.round(Number(patch.amount));
      if (!Number.isFinite(v) || v <= 0) throw new DbError('invalid-argument', 'Số tiền phải lớn hơn 0.');
      newAmount = v;
      data.amount = v;
    }
    if (patch.note !== undefined) {
      data.note = typeof patch.note === 'string' && patch.note.trim() ? patch.note.trim().slice(0, 500) : null;
    }
    if (patch.category !== undefined) {
      const c = String(patch.category ?? '').trim().slice(0, 50);
      if (!c) throw new DbError('invalid-argument', 'Vui lòng chọn danh mục.');
      data.category = c;
    }
    if (patch.fund_id !== undefined) {
      const fid = String(patch.fund_id ?? '').trim();
      if (!fid) throw new DbError('invalid-argument', 'Vui lòng chọn quỹ.');
      // BUG 3: khoản chuyển quỹ là 1 cặp liên kết — không cho đổi quỹ 1 vế
      // (đổi sẽ làm lệch cặp vĩnh viễn). Muốn đổi quỹ thì xóa cặp cũ, tạo chuyển mới.
      if (isTransferPair && fid !== e.fund_id) {
        throw new DbError(
          'invalid-argument',
          'Không đổi được quỹ của khoản chuyển quỹ. Hãy xóa cặp chuyển này và tạo chuyển mới.',
        );
      }
      const funds = await getFunds();
      if (!funds.some((f) => f.id === fid)) throw new DbError('not-found', 'Quỹ không tồn tại.');
      data.fund_id = fid;
    }
    if (patch.businessDate !== undefined) {
      if (!validYMD(patch.businessDate)) throw new DbError('invalid-argument', 'Ngày không hợp lệ.');
      const d = parseISODateTime(patch.businessDate);
      if (d) {
        const iso = d.toISOString();
        data.created_at = iso;
        newDate = iso;
      }
    }
    // v6.3: sửa giờ (datetime-local, giờ VN) thắng ngày — khoản quỹ đổi theo
    // đúng ngày + giờ + phút đã chọn, cả khoản đối ứng trong cặp chuyển quỹ.
    if (patch.businessDateTime) {
      const iso = parseVNDateTimeInput(patch.businessDateTime);
      if (!iso) throw new DbError('invalid-argument', 'Giờ không hợp lệ.');
      data.created_at = iso;
      newDate = iso;
    }
    if (Object.keys(data).length === 0) return;

    const batch = writeBatch(db);
    batch.update(doc(db, 'cashbook_entries', eid), data);

    // Khoản chuyển quỹ: đồng bộ số tiền + ngày cho khoản đối ứng trong cặp
    if (isTransferPair && (newAmount !== null || newDate !== null)) {
      const pairSnap = await getDocs(
        query(collection(db, 'cashbook_entries'), where('ref_id', '==', eid), limit(5)),
      );
      for (const d of pairSnap.docs) {
        if ((d.data() as Record<string, unknown>).ref_type === 'transfer') {
          const syncData: Record<string, unknown> = {};
          if (newAmount !== null) syncData.amount = newAmount;
          if (newDate !== null) syncData.created_at = newDate;
          if (Object.keys(syncData).length > 0) batch.update(d.ref, syncData);
        }
      }
    }
    await batch.commit();
    logAudit(
      'cashbook.update',
      `Sửa khoản ${e.type === 'chi' ? 'chi' : 'thu'} ${formatVNDLocal(e.amount)}${isTransferPair ? ' (chuyển quỹ)' : ''}`,
      { type: 'cashbook_entry', id: eid },
    );
  } catch (e) {
    throw toDbError(e);
  }
}

/** Xóa một khoản thu/chi — chỉ chủ quán (rules enforce). Ghi nhật ký. */
export async function deleteCashbookEntry(id: string): Promise<void> {
  try {
    const snap = await getDoc(doc(db, 'cashbook_entries', id));
    const e = snap.exists() ? toCashbookEntry(snap.id, snap.data() as Record<string, unknown>) : null;
    await deleteDoc(doc(db, 'cashbook_entries', id));
    logAudit(
      'cashbook.delete',
      `Xóa khoản ${e?.type === 'chi' ? 'chi' : 'thu'} ${formatVNDLocal(e?.amount ?? 0)}${e?.note ? ` — ${e.note}` : ''}`,
      { type: 'cashbook_entry', id },
    );
  } catch (e) {
    throw toDbError(e);
  }
}

export async function listCashbookEntries(limitN = 500): Promise<CashbookEntry[]> {
  try {
    const snap = await getDocs(
      query(collection(db, 'cashbook_entries'), orderBy('created_at', 'desc'), limit(limitN)),
    );
    return snap.docs.map((d) => toCashbookEntry(d.id, d.data() as Record<string, unknown>));
  } catch (e) {
    throw toDbError(e);
  }
}

/** Tải TOÀN BỘ khoản quỹ (phân trang) — Sổ Quỹ và tab Dòng tiền dùng bản này để
 *  tổng thu/chi và số dư không bị thiếu khi tổng số khoản vượt 500/1000 như trước. */
export async function listAllCashbookEntries(): Promise<CashbookEntry[]> {
  try {
    const out: CashbookEntry[] = [];
    let last: unknown = null;
    for (let page = 0; page < 100; page++) {
      const q =
        last == null
          ? query(collection(db, 'cashbook_entries'), orderBy('created_at', 'desc'), limit(500))
          : query(
              collection(db, 'cashbook_entries'),
              orderBy('created_at', 'desc'),
              limit(500),
              startAfter(last as never),
            );
      const snap = await getDocs(q);
      if (snap.docs.length === 0) break;
      for (const d of snap.docs) {
        out.push(toCashbookEntry(d.id, d.data() as Record<string, unknown>));
      }
      last = snap.docs[snap.docs.length - 1];
      if (snap.docs.length < 500) break;
    }
    return out;
  } catch (e) {
    throw toDbError(e);
  }
}

/**
 * Tổng thu/chi của 1 quỹ TRƯỚC mốc cutoff (chuỗi ISO, so sánh theo giờ VN).
 * Dùng aggregate SUM nên không bị giới hạn 500 khoản như listCashbookEntries
 * → số dư Đầu kỳ luôn đúng dù quán có hàng chục nghìn khoản.
 * Mỗi aggregate chỉ tính 1 lượt đọc, rẻ hơn nhiều so với tải toàn bộ entries.
 *
 * LƯU Ý: created_at trong Firestore đang lẫn 2 kiểu (Timestamp và chuỗi ISO)
 * do các bản cũ ghi khác nhau. Firestore so sánh khác kiểu theo thứ tự loại
 * (timestamp < string) nên phải query cả 2 kiểu rồi cộng lại.
 */
/**
 * Ngày bắt đầu tính số dư của quỹ trong phạm vi kho đang xem ('' = chưa đặt → không lọc).
 * - Không lọc kho: dùng opening_date chung.
 * - 1 kho: dùng opening_date của kho đó (trống thì dùng chung).
 * - Nhiều kho: dùng ngày sớm nhất (an toàn: không giấu khoản của kho có ngày sớm nhất).
 */
export function fundFromDate(fund: Fund, warehouseIds: string[]): string {
  const dates: string[] = [];
  if (warehouseIds.length === 0) {
    if (fund.opening_date) dates.push(fund.opening_date);
  } else {
    for (const wid of warehouseIds) {
      const d = fund.opening_by_warehouse?.[wid]?.opening_date ?? fund.opening_date;
      if (d) dates.push(d);
    }
  }
  if (dates.length === 0) return '';
  return dates.sort()[0];
}

export async function getFundSumsBefore(
  cutoffIso: string,
  fundId: string,
  warehouseIds: string[],
  fromIso?: string,
): Promise<{ thu: number; chi: number }> {
  // Tính tổng bằng cách tải trực tiếp (không dùng aggregate để tránh lỗi index).
  // So sánh bằng chuỗi ISO sau khi chuẩn hóa Timestamp → string.
  try {
    let thu = 0;
    let chi = 0;
    let last: unknown = null;
    const validWarehouse = (wid: string | null): boolean => {
      if (warehouseIds.length === 0) return true;
      if (!wid) return true; // khoản cũ chưa có warehouse_id → tính vào
      return warehouseIds.includes(wid);
    };
    for (let page = 0; page < 200; page++) {
      const q =
        last == null
          ? query(
              collection(db, 'cashbook_entries'),
              where('fund_id', '==', fundId),
              orderBy('__name__'),
              limit(500),
            )
          : query(
              collection(db, 'cashbook_entries'),
              where('fund_id', '==', fundId),
              orderBy('__name__'),
              limit(500),
              startAfter(last as never),
            );
      const snap = await getDocs(q);
      if (snap.docs.length === 0) break;
      for (const d of snap.docs) {
        const data = d.data() as Record<string, unknown>;
        const iso = tsToIso(data.created_at);
        if (iso >= cutoffIso) continue; // chỉ tính khoản trước kỳ
        if (fromIso && iso < fromIso) continue; // chỉ tính khoản từ ngày đầu kỳ trở đi
        const wid = typeof data.warehouse_id === 'string' ? data.warehouse_id : null;
        if (!validWarehouse(wid)) continue;
        const amt = Number(data.amount ?? 0);
        if (data.type === 'thu') thu += amt;
        else chi += amt;
      }
      last = snap.docs[snap.docs.length - 1];
      if (snap.docs.length < 500) break;
    }
    return { thu, chi };
  } catch (e) {
    throw toDbError(e);
  }
}

export interface FundBalance {
  fund: Fund;
  opening: number; // số dư đầu kỳ trong phạm vi kho
  fromDate: string; // '' = không lọc
  balance: number; // số dư trên phần mềm tính đến cuối ngày asOf
}

/** Số dư trên phần mềm của từng quỹ đang hoạt động, tính đến cuối ngày asOf (mặc định hôm nay). */
export async function getFundCurrentBalances(
  warehouseIds: string[],
  asOfYMD?: string,
): Promise<FundBalance[]> {
  const funds = await getFunds();
  const asOf = asOfYMD ?? todayVN();
  const cutoffIso = new Date(`${addDays(asOf, 1)}T00:00:00+07:00`).toISOString();
  const out: FundBalance[] = [];
  for (const f of funds.filter((x) => x.active)) {
    const opening =
      warehouseIds.length === 0
        ? f.opening_balance
        : warehouseIds.reduce((s, wid) => s + (f.opening_by_warehouse?.[wid]?.opening_balance ?? 0), 0);
    const fromDate = fundFromDate(f, warehouseIds);
    const fromIso = fromDate ? new Date(`${fromDate}T00:00:00+07:00`).toISOString() : undefined;
    const sums = await getFundSumsBefore(cutoffIso, f.id, warehouseIds, fromIso);
    out.push({ fund: f, opening, fromDate, balance: opening + sums.thu - sums.chi });
  }
  return out;
}

// ------------------------------------------------------- hóa đơn tạm ---
function toDraftOrder(id: string, d: Record<string, unknown>): DraftOrder | null {
  const items = Array.isArray(d.items) ? d.items : [];
  if (items.length === 0) return null;
  return {
    id,
    items: items as DraftOrderItem[],
    customer_id: typeof d.customer_id === 'string' ? d.customer_id : null,
    customer_name: typeof d.customer_name === 'string' ? d.customer_name : null,
    created_by: typeof d.created_by === 'string' ? d.created_by : null,
    created_at: tsToIso(d.created_at),
  };
}

/** Lưu tạm giỏ hàng thành hóa đơn tạm. */
export async function saveDraftOrder(input: {
  items: DraftOrderItem[];
  customer_id: string | null;
  customer_name: string | null;
}): Promise<DraftOrder> {
  const items = input.items.filter((i) => i.qty > 0 && i.product);
  if (items.length === 0) throw new DbError('invalid-argument', 'Giỏ hàng đang trống.');
  if (items.length > 50) throw new DbError('invalid-argument', 'Hóa đơn tạm tối đa 50 dòng.');
  const id = uuid();
  try {
    await setDoc(doc(db, 'draft_orders', id), {
      id,
      items: items.map((i) => stripUndefined({
        product: { ...i.product },
        qty: i.qty,
        modifiers: i.modifiers ?? [],
        note: i.note ?? '',
      })),
      customer_id: input.customer_id,
      customer_name: input.customer_name,
      created_by: auth.currentUser?.uid ?? null,
      created_at: serverTimestamp(),
    });
    const snap = await getDoc(doc(db, 'draft_orders', id));
    const draft = snap.exists() ? toDraftOrder(snap.id, snap.data() as Record<string, unknown>) : null;
    if (!draft) throw new DbError('unknown', 'Không đọc được hóa đơn tạm vừa lưu.');
    return draft;
  } catch (e) {
    throw toDbError(e);
  }
}

/** Danh sách hóa đơn tạm, mới nhất trước. */
export async function listDraftOrders(): Promise<DraftOrder[]> {
  try {
    const snap = await getDocs(
      query(collection(db, 'draft_orders'), orderBy('created_at', 'desc'), limit(50)),
    );
    const out: DraftOrder[] = [];
    for (const d of snap.docs) {
      const draft = toDraftOrder(d.id, d.data() as Record<string, unknown>);
      if (draft) out.push(draft);
    }
    return out;
  } catch (e) {
    throw toDbError(e);
  }
}

/** Xóa hóa đơn tạm (sau khi mở lại hoặc hủy). */
export async function deleteDraftOrder(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'draft_orders', id));
  } catch (e) {
    throw toDbError(e);
  }
}

// ------------------------------------------------------------- sổ quỹ ---
const DEFAULT_FUND: FundSettings = {
  fund_name: 'Tiền mặt tại quầy',
  opening_balance: 0,
  opening_date: todayVN(),
};

/** Đọc cài đặt quỹ ở settings/fund (chưa có → dùng mặc định). */
export async function getFundSettings(): Promise<FundSettings> {
  try {
    const snap = await getDoc(doc(db, 'settings', 'fund'));
    if (!snap.exists()) return { ...DEFAULT_FUND };
    const d = snap.data();
    return {
      fund_name: typeof d.fund_name === 'string' && d.fund_name ? d.fund_name : DEFAULT_FUND.fund_name,
      opening_balance: Number.isFinite(Number(d.opening_balance)) ? Math.round(Number(d.opening_balance)) : 0,
      opening_date: /^\d{4}-\d{2}-\d{2}$/.test(String(d.opening_date)) ? String(d.opening_date) : todayVN(),
    };
  } catch (e) {
    throw toDbError(e);
  }
}

/** Lưu cài đặt quỹ — chỉ chủ quán (rules settings/{key} chỉ cho owner ghi). */
export async function setFundSettings(patch: Partial<FundSettings>): Promise<FundSettings> {
  const data: Record<string, unknown> = {};
  if (patch.fund_name !== undefined) {
    const n = String(patch.fund_name ?? '').trim().slice(0, 100);
    if (!n) throw new DbError('invalid-argument', 'Tên quỹ không được để trống.');
    data.fund_name = n;
  }
  if (patch.opening_balance !== undefined) {
    const v = Math.round(Number(patch.opening_balance));
    if (!Number.isFinite(v)) throw new DbError('invalid-argument', 'Số dư đầu kỳ không hợp lệ.');
    data.opening_balance = v;
  }
  if (patch.opening_date !== undefined) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(patch.opening_date))) {
      throw new DbError('invalid-argument', 'Ngày không hợp lệ.');
    }
    data.opening_date = String(patch.opening_date);
  }
  if (Object.keys(data).length === 0) return getFundSettings();
  try {
    await setDoc(doc(db, 'settings', 'fund'), data, { merge: true });
    return getFundSettings();
  } catch (e) {
    throw toDbError(e);
  }
}

// ------------------------------------------------- danh mục thu/chi ---
// Danh mục hệ thống của khoản TỰ ĐỘNG — luôn tồn tại, không cho xóa/sửa.
export const LOCKED_THU_CATS = ['Bán hàng', 'Thu nợ'];
const DEFAULT_FUND_CATEGORIES: FundCategories = {
  thu: ['Bán hàng', 'Thu nợ', 'Khác'],
  chi: ['Nguyên liệu', 'Mặt bằng', 'Lương', 'Khác'],
};

/** Chuẩn hóa danh sách danh mục: trim, ≤30 ký tự, không trùng, giữ locked lên đầu. */
function sanitizeCatList(input: unknown, locked: string[]): string[] {
  const arr = Array.isArray(input) ? input : [];
  const seen = new Set<string>();
  const out: string[] = [];
  for (const s of [...locked, ...arr]) {
    const t = String(s ?? '').trim().slice(0, 30);
    if (!t || seen.has(t.toLowerCase())) continue;
    seen.add(t.toLowerCase());
    out.push(t);
  }
  return out.slice(0, 30);
}

/** Đọc danh mục thu/chi ở settings/fund_categories (chưa có → dùng mặc định). */
export async function getFundCategories(): Promise<FundCategories> {
  try {
    const snap = await getDoc(doc(db, 'settings', 'fund_categories'));
    if (!snap.exists()) {
      return { thu: [...DEFAULT_FUND_CATEGORIES.thu], chi: [...DEFAULT_FUND_CATEGORIES.chi] };
    }
    const d = snap.data();
    const thu = sanitizeCatList(d.thu, LOCKED_THU_CATS);
    const chi = sanitizeCatList(d.chi, []);
    return { thu, chi: chi.length > 0 ? chi : ['Khác'] };
  } catch (e) {
    throw toDbError(e);
  }
}

/** Lưu danh mục thu/chi — chỉ chủ quán (rules settings/{key} chỉ cho owner ghi). */
export async function setFundCategories(cats: FundCategories): Promise<FundCategories> {
  const clean: FundCategories = {
    thu: sanitizeCatList(cats.thu, LOCKED_THU_CATS),
    chi: sanitizeCatList(cats.chi, []),
  };
  if (clean.chi.length === 0) clean.chi.push('Khác');
  try {
    await setDoc(
      doc(db, 'settings', 'fund_categories'),
      { ...clean, updated_at: serverTimestamp() },
      { merge: true },
    );
    return clean;
  } catch (e) {
    throw toDbError(e);
  }
}

// ------------------------------------------------------------- quỹ ---
// Mỗi phương thức thanh toán (trừ Ghi nợ) là một quỹ.
// Danh sách quỹ đồng bộ từ payment_methods: thêm/sửa/ẩn phương thức ở Cài đặt
// thì quỹ tự theo. Số dư đầu kỳ của từng quỹ lưu ở settings/funds.

/** Đọc số dư đầu kỳ đã lưu ở settings/funds (key theo id phương thức). */
export interface FundOpening {
  opening_balance: number;
  opening_date: string; // YYYY-MM-DD; '' = chưa đặt ngày (không lọc giao dịch)
}

async function getFundOpenings(): Promise<Record<string, FundOpening & { by_warehouse: Record<string, FundOpening> }>> {
  const parseOpening = (o: Record<string, unknown>): FundOpening => ({
    opening_balance: Math.round(Number(o.opening_balance ?? 0)) || 0,
    opening_date:
      typeof o.opening_date === 'string' && validYMD(o.opening_date) ? o.opening_date : '',
  });
  try {
    const snap = await getDoc(doc(db, 'settings', 'funds'));
    if (!snap.exists()) return {};
    const arr = (snap.data() as Record<string, unknown>).funds;
    const out: Record<string, FundOpening & { by_warehouse: Record<string, FundOpening> }> = {};
    if (Array.isArray(arr)) {
      for (const r of arr) {
        const o = r as Record<string, unknown>;
        const id = String(o.id ?? '');
        if (!id) continue;
        const legacy = parseOpening(o);
        const by_warehouse: Record<string, FundOpening> = {};
        const raw = o.by_warehouse as Record<string, unknown> | undefined;
        if (raw && typeof raw === 'object') {
          for (const [wid, v] of Object.entries(raw)) {
            if (v && typeof v === 'object') by_warehouse[wid] = parseOpening(v as Record<string, unknown>);
          }
        }
        out[id] = { ...legacy, by_warehouse };
      }
    }
    return out;
  } catch {
    return {};
  }
}

/**
 * Danh sách quỹ = các phương thức thanh toán (trừ Ghi nợ).
 * Tên + trạng thái theo phương thức; số dư đầu kỳ sửa riêng ở Sổ quỹ.
 */
export async function getFunds(): Promise<Fund[]> {
  try {
    const [methods, openings, warehouses] = await Promise.all([
      listPaymentMethods(false),
      getFundOpenings(),
      listWarehouses(),
    ]);
    // Dữ liệu cũ (chỉ có opening_balance chung) → gán vào kho mặc định để không mất số liệu.
    const defaultWid = warehouses.find((w) => w.is_default)?.id ?? warehouses[0]?.id ?? '';
    const list: Fund[] = methods
      .filter((m) => m.kind !== 'debt')
      .map((m) => {
        const o = openings[m.id];
        const by_warehouse: Record<string, FundOpening> = { ...(o?.by_warehouse ?? {}) };
        if (Object.keys(by_warehouse).length === 0 && defaultWid) {
          by_warehouse[defaultWid] = {
            opening_balance: o?.opening_balance ?? 0,
            opening_date: o?.opening_date ?? '',
          };
        }
        return {
          id: m.id,
          payment_method_id: m.id,
          kind: m.kind as 'cash' | 'transfer',
          name: m.name,
          opening_balance: o?.opening_balance ?? 0,
          opening_date: o?.opening_date ?? '',
          opening_by_warehouse: by_warehouse,
          active: m.active,
          sort_order: m.sort_order,
        };
      });
    list.sort((a, b) => a.sort_order - b.sort_order || a.name.localeCompare(b.name, 'vi'));
    return list;
  } catch (e) {
    throw toDbError(e);
  }
}

/** Cập nhật số dư đầu kỳ của một quỹ tại một kho — chỉ chủ quán (rules settings/{key} chỉ cho owner ghi). */
export async function saveFundOpening(
  id: string,
  opening_balance: number,
  opening_date: string,
  warehouseId?: string | null,
): Promise<Fund[]> {
  const v = Math.round(Number(opening_balance));
  if (!Number.isFinite(v) || v < 0) {
    throw new DbError('invalid-argument', 'Số dư đầu kỳ không hợp lệ.');
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(opening_date))) {
    throw new DbError('invalid-argument', 'Ngày không hợp lệ.');
  }
  try {
    const funds = await getFunds();
    const fund = funds.find((f) => f.id === id);
    if (!fund) throw new DbError('not-found', 'Không tìm thấy quỹ.');
    const wid =
      typeof warehouseId === 'string' && warehouseId
        ? warehouseId
        : Object.keys(fund.opening_by_warehouse)[0] ?? '';
    if (!wid) throw new DbError('invalid-argument', 'Chưa có kho để lưu số dư đầu kỳ.');
    await setDoc(
      doc(db, 'settings', 'funds'),
      {
        funds: funds.map((f) =>
          f.id === id
            ? {
                id: f.id,
                name: f.name,
                opening_balance: v,
                opening_date,
                by_warehouse: {
                  ...f.opening_by_warehouse,
                  [wid]: { opening_balance: v, opening_date },
                },
              }
            : {
                id: f.id,
                name: f.name,
                opening_balance: f.opening_balance,
                opening_date: f.opening_date,
                by_warehouse: f.opening_by_warehouse,
              },
        ),
        updated_at: serverTimestamp(),
      },
      { merge: true },
    );
    return getFunds();
  } catch (e) {
    throw toDbError(e);
  }
}

/**
 * Chuẩn hóa fund_id của khoản cũ:
 * - 'bank' là id quỹ chuyển khoản của bản trước → nay là id phương thức ('transfer')
 * - id lạ (phương thức đã xóa) → 'cash'
 */
export function normalizeFundId(fundId: string, validIds: Set<string>): string {
  if (fundId === 'bank') return 'transfer';
  return validIds.has(fundId) ? fundId : 'cash';
}

/** Số dư từng quỹ = số dư đầu kỳ + Σ thu − Σ chi của quỹ đó. */
export function fundBalance(fund: Fund, entries: CashbookEntry[], warehouseIds?: string[] | null): number {
  let b: number;
  if (warehouseIds && warehouseIds.length > 0) {
    // Số dư đầu kỳ = tổng số dư đầu kỳ của các kho trong phạm vi
    b = warehouseIds.reduce(
      (sum, wid) => sum + (fund.opening_by_warehouse?.[wid]?.opening_balance ?? 0),
      0,
    );
  } else {
    b = fund.opening_balance; // legacy: toàn quán
  }
  for (const e of entries) {
    if (e.fund_id !== fund.id) continue;
    b += e.type === 'thu' ? e.amount : -e.amount;
  }
  return b;
}

/** Khoản thu/chi có thuộc kho đang xem không — dữ liệu cũ (warehouse_id null) hiện ở mọi kho. */
export function entryInWarehouse(e: { warehouse_id?: string | null }, warehouseId: string | null): boolean {
  if (!warehouseId || warehouseId === 'all') return true;
  return !e.warehouse_id || e.warehouse_id === warehouseId;
}

// Đổi thưởng mua-N-tặng-1: chỉ reset cờ reward_available (đơn thưởng do POS tạo riêng)
export async function redeemReward(customerId: string): Promise<void> {
  try {
    const ref = doc(db, 'customers', customerId);
    const snap = await getDoc(ref);
    if (!snap.exists()) throw new DbError('not-found', 'Khách hàng không tồn tại.');
    if (snap.data().reward_available !== true) {
      throw new DbError('invalid-argument', 'Khách hàng chưa có lượt đổi thưởng nào.');
    }
    await updateDoc(ref, { reward_available: false });
  } catch (e) {
    throw toDbError(e);
  }
}

// ---------------------------------------------------------------- settings ---
// ================= NHÀ CUNG CẤP & PHIẾU NHẬP HÀNG =================

function supplierFromDoc(snap: QueryDocumentSnapshot | DocumentSnapshot): Supplier | null {
  if (!snap.exists()) return null;
  const d = snap.data() as Record<string, unknown>;
  return {
    id: snap.id,
    name: String(d.name ?? ''),
    phone: String(d.phone ?? ''),
    address: (d.address as string | null) ?? null,
    note: (d.note as string | null) ?? null,
    debt: Math.max(0, Number(d.debt ?? 0)),
    active: d.active !== false,
    created_at: tsToIso(d.created_at),
  };
}

export async function listSuppliers(): Promise<Supplier[]> {
  try {
    const snap = await getDocs(query(collection(db, 'suppliers'), orderBy('name', 'asc'), limit(200)));
    return snap.docs.map(supplierFromDoc).filter((s): s is Supplier => !!s);
  } catch (e) {
    throw toDbError(e);
  }
}

export async function saveSupplier(input: {
  id?: string;
  name: string;
  phone?: string;
  address?: string | null;
  note?: string | null;
  active?: boolean;
}): Promise<Supplier> {
  const name = input.name.trim();
  if (!name) throw new DbError('invalid-argument', 'Thiếu tên nhà cung cấp.');
  try {
    const ref = input.id ? doc(db, 'suppliers', input.id) : doc(collection(db, 'suppliers'));
    const ex = input.id ? await getDoc(ref) : null;
    await setDoc(
      ref,
      {
        id: ref.id,
        name: name.slice(0, 100),
        phone: (input.phone ?? '').trim().slice(0, 20),
        address: input.address?.trim()?.slice(0, 200) || null,
        note: input.note?.trim()?.slice(0, 500) || null,
        debt: ex?.exists() ? Number((ex.data() as Record<string, unknown>).debt ?? 0) : 0,
        active: input.active !== false,
        created_at: ex?.exists() ? ex.data()?.created_at ?? serverTimestamp() : serverTimestamp(),
      },
      { merge: true },
    );
    logAudit('supplier.save', `${input.id ? 'Sửa' : 'Thêm'} NCC "${name}"`, { type: 'supplier', id: ref.id });
    const v = supplierFromDoc(await getDoc(ref));
    if (!v) throw new DbError('unknown', 'Không đọc được NCC vừa lưu.');
    return v;
  } catch (e) {
    throw toDbError(e);
  }
}

export async function deleteSupplier(id: string): Promise<void> {
  try {
    const snap = await getDoc(doc(db, 'suppliers', id));
    const s = snap.exists() ? supplierFromDoc(snap) : null;
    if (s && s.debt > 0) throw new DbError('invalid-argument', 'NCC còn công nợ, không thể xóa.');
    await deleteDoc(doc(db, 'suppliers', id));
    logAudit('supplier.delete', `Xóa NCC "${s?.name ?? id}"`, { type: 'supplier', id });
  } catch (e) {
    throw toDbError(e);
  }
}

function purchaseOrderFromDoc(snap: QueryDocumentSnapshot | DocumentSnapshot): PurchaseOrder | null {
  if (!snap.exists()) return null;
  const d = snap.data() as Record<string, unknown>;
  return {
    id: snap.id,
    code: String(d.code ?? ''),
    supplier_id: (d.supplier_id as string | null) ?? null,
    supplier_name: String(d.supplier_name ?? ''),
    warehouse_id: String(d.warehouse_id ?? ''),
    warehouse_name: String(d.warehouse_name ?? ''),
    items: (Array.isArray(d.items) ? d.items : []).map((it: Record<string, unknown>) => ({
      ingredient_id: String(it.ingredient_id ?? ''),
      ingredient_name: String(it.ingredient_name ?? ''),
      unit: String(it.unit ?? ''),
      qty: Number(it.qty ?? 0),
      unit_cost: Number(it.unit_cost ?? 0),
      line_total: Number(it.line_total ?? 0),
    })),
    subtotal: Number(d.subtotal ?? 0),
    paid_amount: Number(d.paid_amount ?? 0),
    debt_amount: Number(d.debt_amount ?? 0),
    reason_id: (d.reason_id as string | null) ?? null,
    attachments: Array.isArray(d.attachments) ? (d.attachments as string[]).slice(0, 3) : [],
    fund_id: (d.fund_id as string | null) ?? null,
    note: (d.note as string | null) ?? null,
    business_date: String(d.business_date ?? ''),
    business_datetime: (d.business_datetime as string | null) ?? null,
    created_by: (d.created_by as string | null) ?? null,
    created_at: tsToIso(d.created_at),
  };
}

export async function listPurchaseOrders(limitN = 100): Promise<PurchaseOrder[]> {
  try {
    const snap = await getDocs(
      query(collection(db, 'purchase_orders'), orderBy('created_at', 'desc'), limit(Math.min(limitN, 200))),
    );
    return snap.docs.map(purchaseOrderFromDoc).filter((p): p is PurchaseOrder => !!p);
  } catch (e) {
    throw toDbError(e);
  }
}

export interface CreatePOItemInput {
  ingredientId: string;
  qty: number;
  unitCost: number;
}

export interface CreatePOInput {
  supplierId?: string | null;
  warehouseId: string;
  items: CreatePOItemInput[];
  paidAmount?: number | null;
  fundId?: string | null;
  note?: string | null;
  businessDate?: string | null;
  /** v6.3: chuỗi datetime-local (giờ VN) của phiếu; null = không chạm giờ khi sửa. */
  businessDateTime?: string | null;
  reasonId?: string | null;
  attachments?: string[];
}

/**
 * Tạo phiếu nhập: cộng tồn kho từng nguyên liệu + ghi công nợ NCC + ghi chi vào sổ quỹ
 * (nếu trả ngay). Tất cả trong 1 transaction.
 */
export async function createPurchaseOrder(input: CreatePOInput): Promise<PurchaseOrder> {
  const items = (input.items ?? [])
    .map((it) => ({
      ingredientId: String(it.ingredientId ?? ''),
      qty: Number(it.qty ?? 0),
      unitCost: Math.max(0, Math.round(Number(it.unitCost ?? 0))),
    }))
    .filter((it) => it.ingredientId && it.qty > 0);
  if (items.length === 0) throw new DbError('invalid-argument', 'Phiếu nhập phải có ít nhất một nguyên liệu.');
  if (!input.warehouseId) throw new DbError('invalid-argument', 'Thiếu kho nhập.');
  const paidAmount = Math.max(0, Math.round(Number(input.paidAmount) || 0));
  // v6.3: giờ nghiệp vụ của phiếu = giờ người dùng chọn (datetime-local, giờ VN);
  // không có giờ thì dùng giờ hiện tại, KHÔNG dùng 00:00 UTC (= 07:00 VN) nữa.
  const slipDt = resolveSlipDateTime({ businessDate: input.businessDate, businessDateTime: input.businessDateTime });
  const businessDate = slipDt.businessDate;
  const slipTimeIso = slipDt.timeIso ?? new Date().toISOString();
  // Số thứ tự toàn cục cho mã phiếu PN (gọi ngoài transaction)
  const poSeqStart = await nextGlobalSeq('po_seq', 'PN', 'purchase_orders');
  try {
    let saved: PurchaseOrder | undefined;
    await runTransaction(db, async (tx) => {
      // ---- PHASE 1: đọc ----
      const wSnap = await tx.get(doc(db, 'warehouses', input.warehouseId));
      if (!wSnap.exists()) throw new DbError('invalid-argument', 'Kho nhập không tồn tại.');
      const warehouseName = String((wSnap.data() as Record<string, unknown>).name ?? 'Kho');
      let supplier: Supplier | null = null;
      let supRef: ReturnType<typeof doc> | null = null;
      if (input.supplierId) {
        supRef = doc(db, 'suppliers', input.supplierId);
        const sSnap = await tx.get(supRef);
        if (!sSnap.exists()) throw new DbError('invalid-argument', 'Nhà cung cấp không tồn tại.');
        supplier = supplierFromDoc(sSnap);
      }
      // Mã phiếu PN đánh số liên tục toàn hệ thống (không reset theo ngày)
      const counterRef = doc(db, 'counters', 'po_seq');
      const cSnap = await tx.get(counterRef);
      const txNext = cSnap.exists() ? Number((cSnap.data() as Record<string, unknown>).last ?? 0) + 1 : 1;
      const next = Math.max(txNext, poSeqStart);
      const code = 'PN' + String(next).padStart(3, '0');
      // Ghi counter ở PHASE 2 (sau mọi lệnh đọc) — không ghi ở đây để tránh lỗi transaction.
      // Nguyên liệu + tồn hiện tại
      const needs = new Map<string, number>();
      const state = new Map<string, { stock: number; name: string; avg: number }>();
      const poItems: PurchaseOrderItem[] = [];
      for (const it of items) {
        const iRef = doc(db, 'ingredients', it.ingredientId);
        const lRef = doc(db, 'stock_levels', stockLevelId(input.warehouseId, it.ingredientId));
        const [iSnap, lSnap] = await Promise.all([tx.get(iRef), tx.get(lRef)]);
        if (!iSnap.exists()) throw new DbError('invalid-argument', 'Nguyên liệu không tồn tại.');
        const ing = iSnap.data() as Record<string, unknown>;
        const iname = String(ing.name ?? '');
        needs.set(it.ingredientId, (needs.get(it.ingredientId) ?? 0) + it.qty);
        if (!state.has(it.ingredientId)) {
          const lData = lSnap.exists() ? (lSnap.data() as Record<string, unknown>) : null;
          state.set(it.ingredientId, {
            stock: lData ? Number(lData.stock ?? 0) : 0,
            name: iname,
            avg: lData ? Number(lData.avg_cost ?? 0) : 0,
          });
        }
        poItems.push({
          ingredient_id: it.ingredientId,
          ingredient_name: iname,
          unit: String(ing.unit ?? ''),
          qty: it.qty,
          unit_cost: it.unitCost,
          line_total: Math.round(it.qty * it.unitCost),
        });
      }
      const subtotal = poItems.reduce((s, it) => s + it.line_total, 0);
      const debtAmount = Math.max(0, subtotal - paidAmount);
      const createdBy = auth.currentUser?.uid ?? null;
      // SUA 25/10/2026: (1) tra ngay vuot tong thi chan, khong de quy chi
      // doi len; (2) mua le (khong NCC) ma tra thieu thi chan vi khoan no
      // se khong co noi de tra sau — phai chon NCC (quyet dinh 25/10/2026).
      if (paidAmount > subtotal) {
        throw new DbError(
          'invalid-argument',
          `Trả ngay ${paidAmount.toLocaleString('vi-VN')}đ vượt tổng phiếu ${subtotal.toLocaleString('vi-VN')}đ. Vui lòng nhập số trả ngay không quá tổng phiếu.`,
        );
      }
      if (!supplier && debtAmount > 0) {
        throw new DbError(
          'invalid-argument',
          `Mua lẻ trả thiếu ${debtAmount.toLocaleString('vi-VN')}đ mà không chọn nhà cung cấp thì khoản nợ không có nơi để trả. Vui lòng chọn nhà cung cấp hoặc trả đủ tổng phiếu.`,
        );
      }

      // ---- PHASE 2: ghi ----
      if (cSnap.exists()) tx.update(counterRef, { last: next });
      else tx.set(counterRef, { last: next });
      const poRef = doc(collection(db, 'purchase_orders'));
      tx.set(poRef, {
        id: poRef.id,
        code,
        supplier_id: supplier?.id ?? null,
        supplier_name: supplier?.name ?? 'Mua lẻ',
        warehouse_id: input.warehouseId,
        warehouse_name: warehouseName,
        items: poItems,
        subtotal,
        paid_amount: paidAmount,
        debt_amount: debtAmount,
        fund_id: paidAmount > 0 ? (input.fundId ?? null) : null,
        note: typeof input.note === 'string' && input.note ? input.note.slice(0, 500) : null,
        reason_id: input.reasonId ?? null,
        attachments: (input.attachments ?? []).slice(0, 3),
        business_date: businessDate,
        business_datetime: slipTimeIso,
        created_by: createdBy,
        created_at: serverTimestamp(),
      });
      // Cộng tồn kho + cập nhật giá vốn bình quân gia quyền theo phiếu nhập này
      // (trước v5.5 phiếu nhập không đụng vào avg_cost nên giá vốn báo cáo đứng
      // yên ở mức nhập tay ban đầu, lợi nhuận sai dần theo từng đợt nhập).
      const receiptQty = new Map<string, number>();
      const receiptValue = new Map<string, number>();
      const lastUnitCost = new Map<string, number>();
      for (const p of poItems) {
        receiptQty.set(p.ingredient_id, (receiptQty.get(p.ingredient_id) ?? 0) + p.qty);
        receiptValue.set(p.ingredient_id, (receiptValue.get(p.ingredient_id) ?? 0) + p.line_total);
        lastUnitCost.set(p.ingredient_id, p.unit_cost);
      }
      const avgUpdates = new Map<string, number>();
      for (const [ingId, st] of state) {
        avgUpdates.set(ingId, wacAdd(st.stock, st.avg, receiptQty.get(ingId) ?? 0, receiptValue.get(ingId) ?? 0));
      }
      writeStockMoves(tx, {
        warehouseId: input.warehouseId,
        warehouseName,
        needs,
        state,
        sign: 1,
        note: `Nhập hàng ${code}`,
        ref_type: 'purchase',
        ref_id: poRef.id,
        createdBy,
        avgCostUpdates: avgUpdates,
      });
      // Giá nhập gần nhất -> cost_per_unit (form nhập lần sau gợi ý đúng giá mới)
      for (const [ingId, uc] of lastUnitCost) {
        tx.update(doc(db, 'ingredients', ingId), { cost_per_unit: uc });
      }
      // Công nợ NCC
      if (supRef && supplier && debtAmount > 0) {
        tx.update(supRef, { debt: Number(supplier.debt ?? 0) + debtAmount });
      }
      // Chi tiền trả ngay → sổ quỹ
      if (paidAmount > 0) {
        const fundRef = doc(collection(db, 'cashbook_entries'));
        // v6.3: khoản quỹ copy ĐÚNG giờ của phiếu (ngày + giờ + phút), không
        // còn parse ngày YYYY-MM-DD ra 00:00 UTC = 07:00 giờ VN như trước.
        const poEntryIso = slipTimeIso;
        tx.set(fundRef, {
          id: fundRef.id,
          type: 'chi',
          amount: paidAmount,
          note: `Nhập hàng ${code}${supplier ? ` — ${supplier.name}` : ''}`,
          category: 'Nhập hàng',
          fund_id: input.fundId ?? null,
          warehouse_id: input.warehouseId,
          ref_type: 'purchase',
          ref_id: poRef.id,
          // v2.9.19: khoản quỹ phiếu nhập cũng phải lưu ISO string (không dùng
          // serverTimestamp) để "Rà soát quỹ" không cờ chuẩn hóa ngày nữa
          occurred_at: poEntryIso,
          created_by: createdBy,
          created_at: poEntryIso,
        });
      }
      saved = {
        id: poRef.id,
        code,
        supplier_id: supplier?.id ?? null,
        supplier_name: supplier?.name ?? 'Mua lẻ',
        warehouse_id: input.warehouseId,
        warehouse_name: warehouseName,
        items: poItems,
        subtotal,
        paid_amount: paidAmount,
        debt_amount: debtAmount,
        fund_id: paidAmount > 0 ? (input.fundId ?? null) : null,
        note: typeof input.note === 'string' && input.note ? input.note.slice(0, 500) : null,
        business_date: businessDate,
        business_datetime: slipTimeIso,
        created_by: createdBy,
        created_at: new Date().toISOString(),
      };
    });
    if (!saved) throw new DbError('unknown', 'Không tạo được phiếu nhập.');
    logAudit('purchase.create', `Nhập hàng ${saved.code} — ${saved.subtotal.toLocaleString('vi-VN')}đ`, {
      type: 'purchase_order',
      id: saved.id,
    });
    return saved;
  } catch (e) {
    throw toDbError(e);
  }
}

/**
 * Sửa phiếu nhập: hoàn tác toàn bộ ảnh hưởng cũ (tồn kho, khoản chi, công nợ NCC)
 * rồi áp dụng lại theo dữ liệu mới. Giữ nguyên mã phiếu, ngày tạo, người tạo.
 * Tất cả trong 1 transaction. Chỉ chủ quán.
 */
export async function updatePurchaseOrder(id: string, input: CreatePOInput): Promise<PurchaseOrder> {
  const items = (input.items ?? [])
    .map((it) => ({
      ingredientId: String(it.ingredientId ?? ''),
      qty: Number(it.qty ?? 0),
      unitCost: Math.max(0, Math.round(Number(it.unitCost ?? 0))),
    }))
    .filter((it) => it.ingredientId && it.qty > 0);
  if (items.length === 0) throw new DbError('invalid-argument', 'Phiếu nhập phải có ít nhất một nguyên liệu.');
  if (!input.warehouseId) throw new DbError('invalid-argument', 'Thiếu kho nhập.');
  const paidAmount = Math.max(0, Math.round(Number(input.paidAmount) || 0));
  const businessDate = validYMD(input.businessDate) ? (input.businessDate as string) : todayVN();
  // v6.3: giờ mới chỉ khi người dùng sửa trường giờ (form gửi businessDateTime);
  // null = không chạm giờ -> khoản quỹ cũ giữ nguyên giờ, không suy diễn giờ mới.
  const newTimeIso = parseVNDateTimeInput(input.businessDateTime);
  try {
    // Khoản chi cũ liên quan (đọc trước transaction, xóa trong transaction)
    const cbSnap = await getDocs(
      query(collection(db, 'cashbook_entries'), where('ref_id', '==', id), limit(20)),
    );
    const oldCbRefs = cbSnap.docs
      .filter((d) => (d.data() as Record<string, unknown>).ref_type === 'purchase')
      .map((d) => d.ref);
    const oldFundCreatedAt = cbSnap.docs
      .filter((d) => (d.data() as Record<string, unknown>).ref_type === 'purchase')
      .map((d) => tsToIso((d.data() as Record<string, unknown>).created_at))
      .find((v) => !!v) ?? null;
    let saved: PurchaseOrder | undefined;
    await runTransaction(db, async (tx) => {
      // ---- PHASE 1: đọc ----
      const poRef = doc(db, 'purchase_orders', id);
      const poSnap = await tx.get(poRef);
      if (!poSnap.exists()) throw new DbError('not-found', 'Không tìm thấy phiếu nhập.');
      const old = purchaseOrderFromDoc(poSnap);
      if (!old) throw new DbError('not-found', 'Không tìm thấy phiếu nhập.');
      const wSnap = await tx.get(doc(db, 'warehouses', input.warehouseId));
      if (!wSnap.exists()) throw new DbError('invalid-argument', 'Kho nhập không tồn tại.');
      const warehouseName = String((wSnap.data() as Record<string, unknown>).name ?? 'Kho');
      // NCC cũ + mới (có thể trùng)
      const supIds = new Set<string>();
      if (old.supplier_id) supIds.add(old.supplier_id);
      if (input.supplierId) supIds.add(input.supplierId);
      const supSnaps = new Map<string, DocumentSnapshot>();
      for (const sid of supIds) {
        const sSnap: DocumentSnapshot = await tx.get(doc(db, 'suppliers', sid));
        if (sid === input.supplierId && !sSnap.exists()) throw new DbError('invalid-argument', 'Nhà cung cấp không tồn tại.');
        supSnaps.set(sid, sSnap);
      }
      const supplier = input.supplierId ? supplierFromDoc(supSnaps.get(input.supplierId) as DocumentSnapshot) : null;
      // Tồn kho hoàn tác (kho cũ)
      const revertNeeds = new Map<string, number>();
      const revertState = new Map<string, { stock: number; name: string; avg: number }>();
      for (const it of old.items) {
        const lSnap = await tx.get(doc(db, 'stock_levels', stockLevelId(old.warehouse_id, it.ingredient_id)));
        const lData = lSnap.exists() ? (lSnap.data() as Record<string, unknown>) : null;
        const cur = lData ? Number(lData.stock ?? 0) : 0;
        revertNeeds.set(it.ingredient_id, (revertNeeds.get(it.ingredient_id) ?? 0) + it.qty);
        if (!revertState.has(it.ingredient_id)) {
          revertState.set(it.ingredient_id, { stock: cur, name: it.ingredient_name, avg: lData ? Number(lData.avg_cost ?? 0) : 0 });
        }
      }
      // Tồn kho áp mới (kho mới) + dựng items
      const applyNeeds = new Map<string, number>();
      const applyState = new Map<string, { stock: number; name: string; avg: number }>();
      const poItems: PurchaseOrderItem[] = [];
      const poSameWarehouse = old.warehouse_id === input.warehouseId;
      for (const it of items) {
        const iRef = doc(db, 'ingredients', it.ingredientId);
        const lRef = doc(db, 'stock_levels', stockLevelId(input.warehouseId, it.ingredientId));
        const [iSnap, lSnap] = await Promise.all([tx.get(iRef), tx.get(lRef)]);
        if (!iSnap.exists()) throw new DbError('invalid-argument', 'Nguyên liệu không tồn tại.');
        const ing = iSnap.data() as Record<string, unknown>;
        const lData = lSnap.exists() ? (lSnap.data() as Record<string, unknown>) : null;
        const cur = lData ? Number(lData.stock ?? 0) : 0;
        applyNeeds.set(it.ingredientId, (applyNeeds.get(it.ingredientId) ?? 0) + it.qty);
        if (!applyState.has(it.ingredientId)) {
          // Cùng kho: số dư đã bị trừ đi lượng hoàn tác ở bước trước → nối chuỗi
          const reverted = poSameWarehouse ? (revertNeeds.get(it.ingredientId) ?? 0) : 0;
          applyState.set(it.ingredientId, {
            stock: cur - reverted,
            name: String(ing.name ?? ''),
            avg: lData ? Number(lData.avg_cost ?? 0) : 0,
          });
        }
        poItems.push({
          ingredient_id: it.ingredientId,
          ingredient_name: String(ing.name ?? ''),
          unit: String(ing.unit ?? ''),
          qty: it.qty,
          unit_cost: it.unitCost,
          line_total: Math.round(it.qty * it.unitCost),
        });
      }
      const subtotal = poItems.reduce((st, it) => st + it.line_total, 0);
      const debtAmount = Math.max(0, subtotal - paidAmount);
      const createdBy = auth.currentUser?.uid ?? null;

      // SUA 25/10/2026 (chan ton am khi sua phieu nhap): kiem tra ton cuoi
      // sau hoan tac (cung kho thi cong them so ap moi, vi ton cuoi =
      // ton hien tai - hoan tac + ap moi; khac kho thi chi xet kho cu).
      // Kiem tra rieng buoc hoan tac se chan ca truong hop sua hop le
      // (vd ton 0, sua tu 100 len 150 thi ton cuoi 50 van du) nen phai
      // kiem tra tren ton cuoi, khong phai chi tren buoc tru.
      for (const [ingId, rq] of revertNeeds) {
        const st = revertState.get(ingId);
        if (!st) continue;
        const aq = poSameWarehouse ? (applyNeeds.get(ingId) ?? 0) : 0;
        if (st.stock - rq + aq < 0) {
          throw new DbError(
            'invalid-argument',
            `Không sửa được phiếu ${old.code}: ${st.name} chỉ còn ${st.stock}, không đủ để trừ lại ${rq} đã nhập${aq > 0 ? ` (dù cộng thêm ${aq} mới vẫn thiếu)` : ''} (phần đã bán/xuất phải xử lý trước).`,
          );
        }
      }

      // SUA 25/10/2026 (giong tao phieu): chan tra ngay vuot tong va chan
      // mua le tra thieu khong co NCC — phai kiem tra o ca sua phieu vi sua
      // tong tien/so tra deu co the tao ra 2 truong hop nay sau khi tao.
      if (paidAmount > subtotal) {
        throw new DbError(
          'invalid-argument',
          `Trả ngay ${paidAmount.toLocaleString('vi-VN')}đ vượt tổng phiếu ${subtotal.toLocaleString('vi-VN')}đ. Vui lòng nhập số trả ngay không quá tổng phiếu.`,
        );
      }
      if (!supplier && debtAmount > 0) {
        throw new DbError(
          'invalid-argument',
          `Mua lẻ trả thiếu ${debtAmount.toLocaleString('vi-VN')}đ mà không chọn nhà cung cấp thì khoản nợ không có nơi để trả. Vui lòng chọn nhà cung cấp hoặc trả đủ tổng phiếu.`,
        );
      }

      // ---- PHASE 2: ghi ----
      // Giá vốn bình quân: gỡ lớp nhập cũ ở kho cũ, cộng lớp nhập mới ở kho mới.
      // Cùng kho thì nối chuỗi: giá sau hoàn tác là nền cho bước áp mới.
      const oldReceiptValue = new Map<string, number>();
      for (const it of old.items) {
        oldReceiptValue.set(it.ingredient_id, (oldReceiptValue.get(it.ingredient_id) ?? 0) + it.line_total);
      }
      const revertAvg = new Map<string, number>();
      for (const [ingId, st] of revertState) {
        revertAvg.set(ingId, wacRemove(st.stock, st.avg, revertNeeds.get(ingId) ?? 0, oldReceiptValue.get(ingId) ?? 0));
      }
      const newReceiptValue = new Map<string, number>();
      const lastUnitCost = new Map<string, number>();
      for (const p of poItems) {
        newReceiptValue.set(p.ingredient_id, (newReceiptValue.get(p.ingredient_id) ?? 0) + p.line_total);
        lastUnitCost.set(p.ingredient_id, p.unit_cost);
      }
      const applyAvg = new Map<string, number>();
      for (const [ingId, st] of applyState) {
        const baseAvg = poSameWarehouse && revertAvg.has(ingId) ? (revertAvg.get(ingId) as number) : st.avg;
        applyAvg.set(ingId, wacAdd(st.stock, baseAvg, applyNeeds.get(ingId) ?? 0, newReceiptValue.get(ingId) ?? 0));
      }
      // 1. Hoàn tác tồn kho cũ (trừ lại số đã cộng)
      writeStockMoves(tx, {
        warehouseId: old.warehouse_id,
        warehouseName: old.warehouse_name,
        needs: revertNeeds,
        state: revertState,
        sign: -1,
        note: `Sửa phiếu nhập ${old.code} (hoàn tác)`,
        ref_type: 'purchase',
        ref_id: null,
        createdBy,
        avgCostUpdates: revertAvg,
      });
      // 2. Xóa khoản chi cũ liên quan
      for (const r of oldCbRefs) tx.delete(r);
      // 3. Công nợ NCC: hoàn cũ rồi áp mới
      const finalDebt = new Map<string, number>();
      if (old.supplier_id && old.debt_amount > 0) {
        const oldSnap = supSnaps.get(old.supplier_id);
        if (oldSnap?.exists()) {
          const curDebt = Number((oldSnap.data() as Record<string, unknown>).debt ?? 0);
          finalDebt.set(old.supplier_id, Math.max(0, curDebt - old.debt_amount));
        }
      }
      if (supplier && debtAmount > 0) {
        const base = finalDebt.has(supplier.id)
          ? (finalDebt.get(supplier.id) as number)
          : Number(((supSnaps.get(supplier.id)?.data() ?? {}) as Record<string, unknown>).debt ?? 0);
        finalDebt.set(supplier.id, base + debtAmount);
      }
      for (const [sid, debt] of finalDebt) {
        tx.update(doc(db, 'suppliers', sid), { debt });
      }
      // 4. Cập nhật phiếu (giữ code, created_at, created_by)
      const note = typeof input.note === 'string' && input.note ? input.note.slice(0, 500) : null;
      const attachments = (input.attachments ?? []).slice(0, 3);
      tx.update(poRef, {
        supplier_id: supplier?.id ?? null,
        supplier_name: supplier?.name ?? 'Mua lẻ',
        warehouse_id: input.warehouseId,
        warehouse_name: warehouseName,
        items: poItems,
        subtotal,
        paid_amount: paidAmount,
        debt_amount: debtAmount,
        fund_id: paidAmount > 0 ? (input.fundId ?? null) : null,
        note,
        reason_id: input.reasonId ?? null,
        attachments,
        business_date: businessDate,
        // v6.3: chỉ ghi business_datetime khi người dùng sửa giờ; phiếu cũ
        // không có field này thì vẫn không có, giờ quỹ giữ nguyên (xem dưới).
        ...(newTimeIso ? { business_datetime: newTimeIso } : {}),
      });
      // 5. Áp tồn kho mới
      writeStockMoves(tx, {
        warehouseId: input.warehouseId,
        warehouseName,
        needs: applyNeeds,
        state: applyState,
        sign: 1,
        note: `Sửa phiếu nhập ${old.code}`,
        ref_type: 'purchase',
        ref_id: id,
        createdBy,
        avgCostUpdates: applyAvg,
      });
      // Giá nhập gần nhất -> cost_per_unit (gợi ý cho lần nhập sau)
      for (const [ingId, uc] of lastUnitCost) {
        tx.update(doc(db, 'ingredients', ingId), { cost_per_unit: uc });
      }
      // 6. Khoản chi mới (nếu trả ngay) — v6.3: sửa giờ thì khoản quỹ đổi
      // theo đúng giờ mới (cả occurred_at lẫn created_at, vì Sổ quỹ hiển thị
      // theo created_at); không sửa giờ thì giữ nguyên giờ khoản quỹ cũ.
      if (paidAmount > 0) {
        const fundRef = doc(collection(db, 'cashbook_entries'));
        tx.set(fundRef, {
          id: fundRef.id,
          type: 'chi',
          amount: paidAmount,
          note: `Nhập hàng ${old.code}${supplier ? ` — ${supplier.name}` : ''}`,
          category: 'Nhập hàng',
          fund_id: input.fundId ?? null,
          warehouse_id: input.warehouseId,
          ref_type: 'purchase',
          ref_id: id,
          occurred_at: newTimeIso ?? new Date().toISOString(),
          created_by: createdBy,
          created_at: newTimeIso ?? oldFundCreatedAt ?? old.created_at ?? new Date().toISOString(),
        });
      }
      saved = {
        id,
        code: old.code,
        supplier_id: supplier?.id ?? null,
        supplier_name: supplier?.name ?? 'Mua lẻ',
        warehouse_id: input.warehouseId,
        warehouse_name: warehouseName,
        items: poItems,
        subtotal,
        paid_amount: paidAmount,
        debt_amount: debtAmount,
        fund_id: paidAmount > 0 ? (input.fundId ?? null) : null,
        note,
        reason_id: input.reasonId ?? null,
        attachments,
        business_date: businessDate,
        business_datetime: newTimeIso ?? old.business_datetime ?? null,
        created_by: old.created_by,
        created_at: old.created_at,
      };
    });
    if (!saved) throw new DbError('unknown', 'Không sửa được phiếu nhập.');
    logAudit('purchase.update', `Sửa phiếu nhập ${saved.code} — ${saved.subtotal.toLocaleString('vi-VN')}đ`, {
      type: 'purchase_order',
      id: saved.id,
    });
    clearCatalogCache();
    return saved;
  } catch (e) {
    throw toDbError(e);
  }
}

function stockExportFromDoc(snap: QueryDocumentSnapshot | DocumentSnapshot): StockExport | null {
  if (!snap.exists()) return null;
  const d = snap.data() as Record<string, unknown>;
  const exSubtotal = Number(d.subtotal ?? 0);
  const exReceived = Number(d.received_amount ?? 0);
  const exBehavior = (d.behavior as StockExportBehavior) ?? 'none';
  return {
    id: String(d.id ?? snap.id),
    code: String(d.code ?? ''),
    reason: (d.reason as StockExportReason) ?? 'khac',
    behavior: exBehavior,
    attachments: Array.isArray(d.attachments) ? (d.attachments as string[]).slice(0, 3) : [],
    supplier_id: (d.supplier_id as string | null) ?? null,
    supplier_name: (d.supplier_name as string | null) ?? null,
    customer_id: (d.customer_id as string | null) ?? null,
    customer_name: (d.customer_name as string | null) ?? null,
    debt_booked_amount: Number(d.debt_booked_amount ?? 0),
    warehouse_id: String(d.warehouse_id ?? ''),
    warehouse_name: String(d.warehouse_name ?? ''),
    items: Array.isArray(d.items) ? (d.items as StockExportItem[]) : [],
    subtotal: exSubtotal,
    received_amount: exReceived,
    // Phieu cu chua co field nay thi suy ra tu tong - da thu (chi khi ban),
    // de phan thieu cu cung hien len chu khong bien mat.
    receivable_amount:
      d.receivable_amount != null
        ? Number(d.receivable_amount)
        : exBehavior === 'sale'
          ? Math.max(0, exSubtotal - exReceived)
          : 0,
    fund_id: (d.fund_id as string | null) ?? null,
    note: (d.note as string | null) ?? null,
    business_date: String(d.business_date ?? ''),
    business_datetime: (d.business_datetime as string | null) ?? null,
    created_by: (d.created_by as string | null) ?? null,
    created_at: tsToIso(d.created_at),
  };
}

export async function listStockExports(limitN = 100): Promise<StockExport[]> {
  try {
    const snap = await getDocs(
      query(collection(db, 'stock_exports'), orderBy('created_at', 'desc'), limit(Math.min(limitN, 200))),
    );
    return snap.docs.map(stockExportFromDoc).filter((p): p is StockExport => !!p);
  } catch (e) {
    throw toDbError(e);
  }
}

/** Danh sach phieu xuat ban con phai thu (receivable_amount > 0) de doi
 *  chieu. Phieu cu chua co field thi fromDoc suy ra tu subtotal -
 *  received_amount nen van hien. Thu phai thu bang nut "Thu phải thu" o
 *  chi tiet phieu (collectExportReceivable) hoac sua phieu tang so da thu. */
export async function listExportReceivables(): Promise<StockExport[]> {
  try {
    const out: StockExport[] = [];
    let last: unknown = null;
    for (let page = 0; page < 20; page++) {
      const q =
        last == null
          ? query(collection(db, 'stock_exports'), orderBy('created_at', 'desc'), limit(200))
          : query(
              collection(db, 'stock_exports'),
              orderBy('created_at', 'desc'),
              limit(200),
              startAfter(last as never),
            );
      const snap = await getDocs(q);
      if (snap.docs.length === 0) break;
      for (const d of snap.docs) {
        const ex = stockExportFromDoc(d);
        if (ex && ex.receivable_amount > 0) out.push(ex);
      }
      last = snap.docs[snap.docs.length - 1];
      if (snap.docs.length < 200) break;
    }
    return out;
  } catch (e) {
    throw toDbError(e);
  }
}

export interface CreateStockExportItemInput {
  ingredientId: string;
  qty: number;
  unitPrice: number;
}

export interface CreateStockExportInput {
  reason: StockExportReason;
  behavior?: StockExportBehavior;
  supplierId?: string | null;
  customerId?: string | null; // chi co y nghia khi behavior = sale; ban le de null
  warehouseId: string;
  items: CreateStockExportItemInput[];
  receivedAmount?: number | null;
  fundId?: string | null;
  note?: string | null;
  businessDate?: string | null;
  /** v6.3: chuỗi datetime-local (giờ VN) của phiếu; null = không chạm giờ khi sửa. */
  businessDateTime?: string | null;
  attachments?: string[];
}

export const STOCK_EXPORT_REASONS: { key: StockExportReason; label: string }[] = [
  { key: 'ban', label: 'Bán nguyên liệu' },
  { key: 'tra_ncc', label: 'Trả hàng NCC' },
  { key: 'huy', label: 'Hủy hàng hỏng' },
  { key: 'khac', label: 'Khác' },
];

/**
 * Tạo phiếu xuất: trừ tồn kho + ghi thu vào sổ quỹ (nếu bán có thu tiền)
 * + trừ công nợ NCC (nếu trả hàng). Tất cả trong 1 transaction.
 */
export async function createStockExport(input: CreateStockExportInput): Promise<StockExport> {
  const items = (input.items ?? [])
    .map((it) => ({
      ingredientId: String(it.ingredientId ?? ''),
      qty: Number(it.qty ?? 0),
      unitPrice: Math.max(0, Math.round(Number(it.unitPrice ?? 0))),
    }))
    .filter((it) => it.ingredientId && it.qty > 0);
  if (items.length === 0) throw new DbError('invalid-argument', 'Phiếu xuất phải có ít nhất một nguyên liệu.');
  if (!input.warehouseId) throw new DbError('invalid-argument', 'Thiếu kho xuất.');
  const receivedAmount = Math.max(0, Math.round(Number(input.receivedAmount) || 0));
  // v6.3: giờ nghiệp vụ = giờ người dùng chọn (giờ VN); không có giờ thì giờ hiện tại.
  const slipDt = resolveSlipDateTime({ businessDate: input.businessDate, businessDateTime: input.businessDateTime });
  const businessDate = slipDt.businessDate;
  const slipTimeIso = slipDt.timeIso ?? new Date().toISOString();
  const reason: StockExportReason = input.reason ?? 'khac';
  const behavior: StockExportBehavior = input.behavior ?? 'none';
  // Số thứ tự toàn cục cho mã phiếu XK (gọi ngoài transaction)
  const xkSeqStart = await nextGlobalSeq('xk_seq', 'XK', 'stock_exports');
  try {
    let saved: StockExport | undefined;
    await runTransaction(db, async (tx) => {
      // ---- PHASE 1: đọc ----
      const wSnap = await tx.get(doc(db, 'warehouses', input.warehouseId));
      if (!wSnap.exists()) throw new DbError('invalid-argument', 'Kho xuất không tồn tại.');
      const warehouseName = String((wSnap.data() as Record<string, unknown>).name ?? 'Kho');
      let supplier: Supplier | null = null;
      let supRef: ReturnType<typeof doc> | null = null;
      if (input.supplierId) {
        supRef = doc(db, 'suppliers', input.supplierId);
        const sSnap = await tx.get(supRef);
        if (!sSnap.exists()) throw new DbError('invalid-argument', 'Nhà cung cấp không tồn tại.');
        supplier = supplierFromDoc(sSnap);
      }
      // Khach mua phieu xuat ban (chi khi ban; ban le thi null). Doc ten + no
      // hien tai de ghi no phai thu vao he thong no khach hang o phase 2.
      let custRef: ReturnType<typeof doc> | null = null;
      let custName: string | null = null;
      let custDebt = 0;
      if (behavior === 'sale' && input.customerId) {
        custRef = doc(db, 'customers', input.customerId);
        const cSnap = await tx.get(custRef);
        if (!cSnap.exists()) throw new DbError('invalid-argument', 'Khách hàng không tồn tại.');
        custName = String((cSnap.data() as Record<string, unknown>).name ?? '');
        custDebt = Number((cSnap.data() as Record<string, unknown>).debt ?? 0);
      }
      // Mã phiếu XK đánh số liên tục toàn hệ thống (không reset theo ngày)
      const counterRef = doc(db, 'counters', 'xk_seq');
      const cSnap = await tx.get(counterRef);
      const txNext = cSnap.exists() ? Number((cSnap.data() as Record<string, unknown>).last ?? 0) + 1 : 1;
      const next = Math.max(txNext, xkSeqStart);
      const code = 'XK' + String(next).padStart(3, '0');
      // Ghi counter ở PHASE 2 (sau mọi lệnh đọc) — không ghi ở đây để tránh lỗi transaction.
      // Nguyên liệu + kiểm tra tồn
      const needs = new Map<string, number>();
      const state = new Map<string, { stock: number; name: string }>();
      const exItems: StockExportItem[] = [];
      for (const it of items) {
        const iRef = doc(db, 'ingredients', it.ingredientId);
        const lRef = doc(db, 'stock_levels', stockLevelId(input.warehouseId, it.ingredientId));
        const [iSnap, lSnap] = await Promise.all([tx.get(iRef), tx.get(lRef)]);
        if (!iSnap.exists()) throw new DbError('invalid-argument', 'Nguyên liệu không tồn tại.');
        const ing = iSnap.data() as Record<string, unknown>;
        const iname = String(ing.name ?? '');
        const curStock = lSnap.exists() ? Number((lSnap.data() as Record<string, unknown>).stock ?? 0) : 0;
        const alreadyNeed = needs.get(it.ingredientId) ?? 0;
        if (curStock < alreadyNeed + it.qty) {
          throw new DbError('invalid-argument', `${iname}: tồn kho không đủ (còn ${curStock}).`);
        }
        needs.set(it.ingredientId, alreadyNeed + it.qty);
        if (!state.has(it.ingredientId)) {
          state.set(it.ingredientId, { stock: curStock, name: iname });
        }
        exItems.push({
          ingredient_id: it.ingredientId,
          ingredient_name: iname,
          unit: String(ing.unit ?? ''),
          qty: it.qty,
          unit_price: it.unitPrice,
          line_total: Math.round(it.qty * it.unitPrice),
        });
      }
      const subtotal = exItems.reduce((s, it) => s + it.line_total, 0);
      const createdBy = auth.currentUser?.uid ?? null;
      // Phai thu xuat ban: chi khi ban ma thu thieu thi phan thieu thanh
      // phai thu, luu ngay tren phieu de doi chieu duoc. Neu co khach hang
      // thi phan nay dong thoi ghi vao no khach hang o phase 2 (de dot sau
      // co nut "Thu phai thu" rieng va hien trong So no / the khach).
      const receivableAmount = behavior === 'sale' ? Math.max(0, subtotal - receivedAmount) : 0;
      const debtBookedAmount = behavior === 'sale' && custRef ? receivableAmount : 0;
      // SUA 25/10/2026: tra hang vuot no thi CHAN thay vi cat tran max(0,...)
      // (cat tran lam mat phan vuot, sau do xoa phieu lai cong du nen no
      // phong len cao hon so goc). Giong paySupplierDebt von chan san.
      if (behavior === 'return_supplier' && supplier && subtotal > Number(supplier.debt ?? 0)) {
        throw new DbError(
          'invalid-argument',
          `Trả hàng ${subtotal.toLocaleString('vi-VN')}đ vượt số nợ của ${supplier.name} (${Number(supplier.debt ?? 0).toLocaleString('vi-VN')}đ). Vui lòng giảm số lượng trả hàng hoặc trả nợ trước.`,
        );
      }

      // ---- PHASE 2: ghi ----
      if (cSnap.exists()) tx.update(counterRef, { last: next });
      else tx.set(counterRef, { last: next });
      const exRef = doc(collection(db, 'stock_exports'));
      tx.set(exRef, {
        id: exRef.id,
        code,
        reason,
          behavior,
        supplier_id: supplier?.id ?? null,
        supplier_name: supplier?.name ?? null,
        customer_id: behavior === 'sale' && custRef ? (input.customerId ?? null) : null,
        customer_name: behavior === 'sale' ? custName : null,
        debt_booked_amount: debtBookedAmount,
        warehouse_id: input.warehouseId,
        warehouse_name: warehouseName,
        items: exItems,
        subtotal,
        received_amount: receivedAmount,
        receivable_amount: receivableAmount,
        fund_id: receivedAmount > 0 ? (input.fundId ?? null) : null,
        note: typeof input.note === 'string' && input.note ? input.note.slice(0, 500) : null,
        attachments: (input.attachments ?? []).slice(0, 3),
          business_date: businessDate,
        business_datetime: slipTimeIso,
        created_by: createdBy,
        created_at: serverTimestamp(),
      });
      // Trừ tồn kho
      const reasonLabel = STOCK_EXPORT_REASONS.find((r) => r.key === reason)?.label ?? 'Xuất kho';
      writeStockMoves(tx, {
        warehouseId: input.warehouseId,
        warehouseName,
        needs,
        state,
        sign: -1,
        note: `${reasonLabel} ${code}`,
        ref_type: 'stock_export',
        ref_id: exRef.id,
        createdBy,
      });
      // Bán có thu tiền → phiếu thu vào sổ quỹ
      if (behavior === 'sale' && receivedAmount > 0) {
        const fundRef = doc(collection(db, 'cashbook_entries'));
        tx.set(fundRef, {
          id: fundRef.id,
          type: 'thu',
          amount: receivedAmount,
          note: `Xuất bán ${code}`,
          category: 'Xuất bán',
          fund_id: input.fundId ?? null,
          warehouse_id: input.warehouseId,
          ref_type: 'stock_export',
          ref_id: exRef.id,
          // v6.3: khoản quỹ copy ĐÚNG giờ của phiếu (trước đây luôn lấy giờ tạo,
          // nên phiếu xuất lùi ngày vẫn ghi quỹ vào ngày hôm nay).
          occurred_at: slipTimeIso,
          created_by: createdBy,
          created_at: slipTimeIso,
        });
      }
      // Bán thu thiếu có khách → ghi phai thu vào nợ khách hàng (cùng tx).
      if (debtBookedAmount > 0 && custRef) {
        const newCustDebt = custDebt + debtBookedAmount;
        tx.update(custRef, { debt: newCustDebt });
        const logRef = doc(collection(db, 'customers', input.customerId as string, 'debt_logs'));
        tx.set(logRef, {
          id: logRef.id,
          amount: debtBookedAmount,
          balance_after: newCustDebt,
          note: `Phải thu phiếu xuất ${code}`,
          created_by: createdBy,
          created_at: new Date().toISOString(),
        });
      }
      // Trả hàng NCC → trừ công nợ
      if (behavior === 'return_supplier' && supRef && supplier && subtotal > 0) {
        const newDebt = Math.max(0, Number(supplier.debt ?? 0) - subtotal);
        tx.update(supRef, { debt: newDebt });
      }
      saved = {
        id: exRef.id,
        code,
        reason,
        behavior,
        supplier_id: supplier?.id ?? null,
        supplier_name: supplier?.name ?? null,
        customer_id: behavior === 'sale' && custRef ? (input.customerId ?? null) : null,
        customer_name: behavior === 'sale' ? custName : null,
        debt_booked_amount: debtBookedAmount,
        warehouse_id: input.warehouseId,
        warehouse_name: warehouseName,
        items: exItems,
        subtotal,
        received_amount: receivedAmount,
        receivable_amount: receivableAmount,
        fund_id: receivedAmount > 0 ? (input.fundId ?? null) : null,
        note: typeof input.note === 'string' && input.note ? input.note.slice(0, 500) : null,
        business_date: businessDate,
        business_datetime: slipTimeIso,
        created_by: createdBy,
        created_at: new Date().toISOString(),
      };
    });
    if (!saved) throw new DbError('unknown', 'Không tạo được phiếu xuất.');
    logAudit('stock_export.create', `Xuất kho ${saved.code} — ${saved.subtotal.toLocaleString('vi-VN')}đ`, {
      type: 'stock_export',
      id: saved.id,
    });
    return saved;
  } catch (e) {
    throw toDbError(e);
  }
}


/**
 * Sửa phiếu xuất: hoàn tác ảnh hưởng cũ (tồn kho, khoản thu, công nợ NCC)
 * rồi áp dụng lại theo dữ liệu mới. Giữ nguyên mã phiếu, ngày tạo, người tạo.
 * Tất cả trong 1 transaction. Chỉ chủ quán.
 */
export async function updateStockExport(id: string, input: CreateStockExportInput): Promise<StockExport> {
  const items = (input.items ?? [])
    .map((it) => ({
      ingredientId: String(it.ingredientId ?? ''),
      qty: Number(it.qty ?? 0),
      unitPrice: Math.max(0, Math.round(Number(it.unitPrice ?? 0))),
    }))
    .filter((it) => it.ingredientId && it.qty > 0);
  if (items.length === 0) throw new DbError('invalid-argument', 'Phiếu xuất phải có ít nhất một nguyên liệu.');
  if (!input.warehouseId) throw new DbError('invalid-argument', 'Thiếu kho xuất.');
  const receivedAmount = Math.max(0, Math.round(Number(input.receivedAmount) || 0));
  const businessDate = validYMD(input.businessDate) ? (input.businessDate as string) : todayVN();
  // v6.3: giờ mới chỉ khi người dùng sửa trường giờ; null = giữ nguyên giờ quỹ cũ.
  const newTimeIso = parseVNDateTimeInput(input.businessDateTime);
  const reason: StockExportReason = input.reason ?? 'khac';
  const behavior: StockExportBehavior = input.behavior ?? 'none';
  try {
    // Khoản thu cũ liên quan (đọc trước transaction, xóa trong transaction)
    const cbSnap = await getDocs(
      query(collection(db, 'cashbook_entries'), where('ref_id', '==', id), limit(20)),
    );
    const oldCbRefs = cbSnap.docs
      .filter((d) => (d.data() as Record<string, unknown>).ref_type === 'stock_export')
      .map((d) => d.ref);
    const oldFundCreatedAt = cbSnap.docs
      .filter((d) => (d.data() as Record<string, unknown>).ref_type === 'stock_export')
      .map((d) => tsToIso((d.data() as Record<string, unknown>).created_at))
      .find((v) => !!v) ?? null;
    let saved: StockExport | undefined;
    await runTransaction(db, async (tx) => {
      // ---- PHASE 1: đọc ----
      const exRef = doc(db, 'stock_exports', id);
      const exSnap = await tx.get(exRef);
      if (!exSnap.exists()) throw new DbError('not-found', 'Không tìm thấy phiếu xuất.');
      const old = stockExportFromDoc(exSnap);
      if (!old) throw new DbError('not-found', 'Không tìm thấy phiếu xuất.');
      const wSnap = await tx.get(doc(db, 'warehouses', input.warehouseId));
      if (!wSnap.exists()) throw new DbError('invalid-argument', 'Kho xuất không tồn tại.');
      const warehouseName = String((wSnap.data() as Record<string, unknown>).name ?? 'Kho');
      const oldIsReturn = (old.behavior ?? 'none') === 'return_supplier';
      const newIsReturn = behavior === 'return_supplier';
      const supIds = new Set<string>();
      if (oldIsReturn && old.supplier_id) supIds.add(old.supplier_id);
      if (newIsReturn && input.supplierId) supIds.add(input.supplierId);
      const supSnaps = new Map<string, DocumentSnapshot>();
      for (const sid of supIds) {
        const sSnap: DocumentSnapshot = await tx.get(doc(db, 'suppliers', sid));
        if (newIsReturn && sid === input.supplierId && !sSnap.exists()) {
          throw new DbError('invalid-argument', 'Nhà cung cấp không tồn tại.');
        }
        supSnaps.set(sid, sSnap);
      }
      const supplier = newIsReturn && input.supplierId
        ? supplierFromDoc(supSnaps.get(input.supplierId) as DocumentSnapshot)
        : null;
      // Khach hang cua phieu xuat ban: giu khach cu neu caller khong gui
      // customerId (undefined), chi xoa khi gui null mot cach ro rang.
      const newCustomerId =
        behavior === 'sale' ? (input.customerId !== undefined ? input.customerId : (old.customer_id ?? null)) : null;
      let oldCustRef: ReturnType<typeof doc> | null = null;
      let oldCustDebt = 0;
      if (old.debt_booked_amount > 0 && old.customer_id) {
        oldCustRef = doc(db, 'customers', old.customer_id);
        const ocSnap = await tx.get(oldCustRef);
        if (ocSnap.exists()) oldCustDebt = Number((ocSnap.data() as Record<string, unknown>).debt ?? 0);
        else oldCustRef = null; // khach cu da bi xoa: bo qua buoc hoan no
      }
      let newCustRef: ReturnType<typeof doc> | null = null;
      let newCustName: string | null = null;
      let newCustDebt = 0;
      if (behavior === 'sale' && newCustomerId) {
        newCustRef = doc(db, 'customers', newCustomerId);
        const ncSnap = await tx.get(newCustRef);
        if (!ncSnap.exists()) throw new DbError('invalid-argument', 'Khách hàng không tồn tại.');
        newCustName = String((ncSnap.data() as Record<string, unknown>).name ?? '');
        newCustDebt = Number((ncSnap.data() as Record<string, unknown>).debt ?? 0);
      }
      // Tồn kho hoàn tác (kho cũ): cộng lại số đã trừ
      const revertNeeds = new Map<string, number>();
      const revertState = new Map<string, { stock: number; name: string }>();
      for (const it of old.items) {
        const lSnap = await tx.get(doc(db, 'stock_levels', stockLevelId(old.warehouse_id, it.ingredient_id)));
        const cur = lSnap.exists() ? Number((lSnap.data() as Record<string, unknown>).stock ?? 0) : 0;
        revertNeeds.set(it.ingredient_id, (revertNeeds.get(it.ingredient_id) ?? 0) + it.qty);
        if (!revertState.has(it.ingredient_id)) revertState.set(it.ingredient_id, { stock: cur, name: it.ingredient_name });
      }
      // Tồn kho áp mới (kho mới) + dựng items, kiểm tra đủ tồn
      const applyNeeds = new Map<string, number>();
      const applyState = new Map<string, { stock: number; name: string }>();
      const exItems: StockExportItem[] = [];
      const sameWarehouse = old.warehouse_id === input.warehouseId;
      for (const it of items) {
        const iRef = doc(db, 'ingredients', it.ingredientId);
        const lRef = doc(db, 'stock_levels', stockLevelId(input.warehouseId, it.ingredientId));
        const [iSnap, lSnap] = await Promise.all([tx.get(iRef), tx.get(lRef)]);
        if (!iSnap.exists()) throw new DbError('invalid-argument', 'Nguyên liệu không tồn tại.');
        const ing = iSnap.data() as Record<string, unknown>;
        const iname = String(ing.name ?? '');
        const cur = lSnap.exists() ? Number((lSnap.data() as Record<string, unknown>).stock ?? 0) : 0;
        const alreadyNeed = applyNeeds.get(it.ingredientId) ?? 0;
        // Số hoàn tác về kho mới (nếu cùng kho) được tính vào tồn khả dụng
        const available = cur + (sameWarehouse ? (revertNeeds.get(it.ingredientId) ?? 0) : 0);
        if (available < alreadyNeed + it.qty) {
          throw new DbError('invalid-argument', `${iname}: tồn kho không đủ (còn ${available}).`);
        }
        applyNeeds.set(it.ingredientId, alreadyNeed + it.qty);
        if (!applyState.has(it.ingredientId)) {
          // Cùng kho: số dư đã được cộng lại lượng hoàn tác ở bước trước → nối chuỗi
          applyState.set(it.ingredientId, { stock: cur + (sameWarehouse ? (revertNeeds.get(it.ingredientId) ?? 0) : 0), name: iname });
        }
        exItems.push({
          ingredient_id: it.ingredientId,
          ingredient_name: iname,
          unit: String(ing.unit ?? ''),
          qty: it.qty,
          unit_price: it.unitPrice,
          line_total: Math.round(it.qty * it.unitPrice),
        });
      }
      const subtotal = exItems.reduce((st, it) => st + it.line_total, 0);
      const createdBy = auth.currentUser?.uid ?? null;
      // SUA 25/10/2026 (phai thu xuat ban): tinh lai theo so moi; doi hanh
      // vi khoi ban hoac tra du thi phai thu ve 0.
      const receivableAmount = behavior === 'sale' ? Math.max(0, subtotal - receivedAmount) : 0;

      // ---- PHASE 2: ghi ----
      // 1. Hoàn tác tồn kho cũ (cộng lại số đã trừ)
      writeStockMoves(tx, {
        warehouseId: old.warehouse_id,
        warehouseName: old.warehouse_name,
        needs: revertNeeds,
        state: revertState,
        sign: 1,
        note: `Sửa phiếu xuất ${old.code} (hoàn tác)`,
        ref_type: 'stock_export',
        ref_id: null,
        createdBy,
      });
      // 2. Xóa khoản thu cũ liên quan
      for (const r of oldCbRefs) tx.delete(r);
      // 3. Công nợ NCC: hoàn cũ (cộng lại số đã trừ) rồi áp mới (trừ)
      const finalDebt = new Map<string, number>();
      if (oldIsReturn && old.supplier_id && old.subtotal > 0) {
        const oldSnap = supSnaps.get(old.supplier_id);
        if (oldSnap?.exists()) {
          const curDebt = Number((oldSnap.data() as Record<string, unknown>).debt ?? 0);
          finalDebt.set(old.supplier_id, curDebt + old.subtotal);
        }
      }
      if (newIsReturn && supplier && subtotal > 0) {
        // Kha dung = no hien tai + phan no cu da hoan tac (neu cung NCC thi
        // finalDebt da cong san so cu; neu doi NCC thi chi la no hien tai).
        const base = finalDebt.has(supplier.id)
          ? (finalDebt.get(supplier.id) as number)
          : Number(((supSnaps.get(supplier.id)?.data() ?? {}) as Record<string, unknown>).debt ?? 0);
        // SUA 25/10/2026: chan tra vuot kha dung thay vi cat tran ve 0.
        if (subtotal > base) {
          throw new DbError(
            'invalid-argument',
            `Trả hàng ${subtotal.toLocaleString('vi-VN')}đ vượt số nợ khả dụng của ${supplier.name} (${base.toLocaleString('vi-VN')}đ, đã gồm phần nợ cũ hoàn tác). Vui lòng giảm số lượng trả hàng.`,
          );
        }
        finalDebt.set(supplier.id, base - subtotal);
      }
      for (const [sid, debt] of finalDebt) {
        tx.update(doc(db, 'suppliers', sid), { debt });
      }
      // 3b. Cong no khach hang phieu xuat ban: hoan phan da ghi cho khach
      // cu (neu co), roi ghi phan phai thu moi cho khach moi. Cung khach
      // thi tinh noi tiep tren cung so du de khong lech. Phieu cu chua
      // tung ghi no (debt_booked_amount = 0) thi khong hoan gi ca.
      const newDebtBookedAmount = behavior === 'sale' && newCustRef ? receivableAmount : 0;
      const custWork = new Map<string, { ref: ReturnType<typeof doc>; debt: number }>();
      if (oldCustRef && old.debt_booked_amount > 0 && old.customer_id) {
        const rev = Math.min(old.debt_booked_amount, Math.max(oldCustDebt, 0));
        const next = Math.max(0, oldCustDebt - rev);
        custWork.set(old.customer_id, { ref: oldCustRef, debt: next });
        if (rev > 0) {
          const logRef = doc(collection(db, 'customers', old.customer_id, 'debt_logs'));
          tx.set(logRef, {
            id: logRef.id,
            amount: -rev,
            balance_after: next,
            note: `Hoàn nợ do sửa phiếu xuất ${old.code}`,
            created_by: createdBy,
            created_at: new Date().toISOString(),
          });
        }
      }
      if (newCustRef && newDebtBookedAmount > 0 && newCustomerId) {
        const base = custWork.has(newCustomerId)
          ? (custWork.get(newCustomerId) as { ref: ReturnType<typeof doc>; debt: number }).debt
          : newCustDebt;
        const next = base + newDebtBookedAmount;
        custWork.set(newCustomerId, { ref: newCustRef, debt: next });
        const logRef = doc(collection(db, 'customers', newCustomerId, 'debt_logs'));
        tx.set(logRef, {
          id: logRef.id,
          amount: newDebtBookedAmount,
          balance_after: next,
          note: `Phải thu phiếu xuất ${old.code}`,
          created_by: createdBy,
          created_at: new Date().toISOString(),
        });
      }
      for (const [, w] of custWork) tx.update(w.ref, { debt: w.debt });
      // 4. Cập nhật phiếu (giữ code, created_at, created_by)
      const note = typeof input.note === 'string' && input.note ? input.note.slice(0, 500) : null;
      const attachments = (input.attachments ?? []).slice(0, 3);
      tx.update(exRef, {
        reason,
        behavior,
        supplier_id: supplier?.id ?? null,
        supplier_name: supplier?.name ?? null,
        customer_id: behavior === 'sale' ? newCustomerId : null,
        customer_name: behavior === 'sale' ? (newCustomerId ? newCustName : null) : null,
        debt_booked_amount: newDebtBookedAmount,
        warehouse_id: input.warehouseId,
        warehouse_name: warehouseName,
        items: exItems,
        subtotal,
        received_amount: receivedAmount,
        receivable_amount: receivableAmount,
        fund_id: receivedAmount > 0 ? (input.fundId ?? null) : null,
        note,
        attachments,
        business_date: businessDate,
        // v6.3: chỉ ghi business_datetime khi người dùng sửa giờ.
        ...(newTimeIso ? { business_datetime: newTimeIso } : {}),
      });
      // 5. Áp tồn kho mới (trừ)
      writeStockMoves(tx, {
        warehouseId: input.warehouseId,
        warehouseName,
        needs: applyNeeds,
        state: applyState,
        sign: -1,
        note: `Sửa phiếu xuất ${old.code}`,
        ref_type: 'stock_export',
        ref_id: id,
        createdBy,
      });
      // 6. Bán có thu tiền → phiếu thu mới vào sổ quỹ (v6.3: sửa giờ thì quỹ
      // đổi theo đúng giờ mới; không sửa giờ thì giữ nguyên giờ quỹ cũ).
      if (behavior === 'sale' && receivedAmount > 0) {
        const fundRef = doc(collection(db, 'cashbook_entries'));
        tx.set(fundRef, {
          id: fundRef.id,
          type: 'thu',
          amount: receivedAmount,
          note: `Xuất bán ${old.code}`,
          category: 'Xuất bán',
          fund_id: input.fundId ?? null,
          warehouse_id: input.warehouseId,
          ref_type: 'stock_export',
          ref_id: id,
          occurred_at: newTimeIso ?? new Date().toISOString(),
          created_by: createdBy,
          created_at: newTimeIso ?? oldFundCreatedAt ?? old.created_at ?? new Date().toISOString(),
        });
      }
      saved = {
        id,
        code: old.code,
        reason,
        behavior,
        supplier_id: supplier?.id ?? null,
        supplier_name: supplier?.name ?? null,
        customer_id: behavior === 'sale' ? newCustomerId : null,
        customer_name: behavior === 'sale' ? (newCustomerId ? newCustName : null) : null,
        debt_booked_amount: newDebtBookedAmount,
        warehouse_id: input.warehouseId,
        warehouse_name: warehouseName,
        items: exItems,
        subtotal,
        received_amount: receivedAmount,
        receivable_amount: receivableAmount,
        attachments,
        fund_id: receivedAmount > 0 ? (input.fundId ?? null) : null,
        note,
        business_date: businessDate,
        business_datetime: newTimeIso ?? old.business_datetime ?? null,
        created_by: old.created_by,
        created_at: old.created_at,
      };
    });
    if (!saved) throw new DbError('unknown', 'Không sửa được phiếu xuất.');
    logAudit('stock_export.update', `Sửa phiếu xuất ${saved.code} — ${saved.subtotal.toLocaleString('vi-VN')}đ`, {
      type: 'stock_export',
      id: saved.id,
    });
    clearCatalogCache();
    return saved;
  } catch (e) {
    throw toDbError(e);
  }
}

/**
 * Xóa phiếu nhập: hoàn tồn kho (trừ lại), xóa khoản chi liên quan,
 * hoàn công nợ NCC. Chỉ chủ quán.
 */
export async function deletePurchaseOrder(id: string): Promise<void> {
  try {
    // Khoản chi liên quan (đọc trước transaction — query collection không chạy trong tx)
    const cbSnap = await getDocs(
      query(collection(db, 'cashbook_entries'), where('ref_id', '==', id), limit(20)),
    );
    const oldCbRefs = cbSnap.docs
      .filter((d) => (d.data() as Record<string, unknown>).ref_type === 'purchase')
      .map((d) => d.ref);
    await runTransaction(db, async (tx) => {
      // ---- PHASE 1: đọc ----
      const poRef = doc(db, 'purchase_orders', id);
      const poSnap = await tx.get(poRef);
      if (!poSnap.exists()) throw new DbError('not-found', 'Không tìm thấy phiếu nhập.');
      const po = purchaseOrderFromDoc(poSnap);
      if (!po) throw new DbError('not-found', 'Không tìm thấy phiếu nhập.');
      // Tồn kho (hoàn lại = trừ tồn)
      const needs = new Map<string, number>();
      const state = new Map<string, { stock: number; name: string; avg: number }>();
      for (const it of po.items) {
        const lRef = doc(db, 'stock_levels', stockLevelId(po.warehouse_id, it.ingredient_id));
        const lSnap = await tx.get(lRef);
        const lData = lSnap.exists() ? (lSnap.data() as Record<string, unknown>) : null;
        const cur = lData ? Number(lData.stock ?? 0) : 0;
        needs.set(it.ingredient_id, (needs.get(it.ingredient_id) ?? 0) + it.qty);
        if (!state.has(it.ingredient_id)) {
          state.set(it.ingredient_id, { stock: cur, name: it.ingredient_name, avg: lData ? Number(lData.avg_cost ?? 0) : 0 });
        }
      }
      // SUA 25/10/2026 (chan ton am khi xoa phieu nhap): ton hien tai phai du
      // de tru lai toan bo so da nhap, neu khong phieu khong duoc xoa.
      for (const [ingId, qty] of needs) {
        const st = state.get(ingId);
        if (st && st.stock < qty) {
          throw new DbError(
            'invalid-argument',
            `Không xóa được phiếu ${po.code}: ${st.name} chỉ còn ${st.stock}, không đủ để trừ lại ${qty} đã nhập (phần đã bán/xuất phải xử lý trước).`,
          );
        }
      }
      // Công nợ NCC (đọc trước khi ghi — Firestore cấm đọc sau ghi trong transaction)
      let supRef: ReturnType<typeof doc> | null = null;
      let curDebt = 0;
      if (po.supplier_id && po.debt_amount > 0) {
        const ref = doc(db, 'suppliers', po.supplier_id);
        const sSnap = await tx.get(ref);
        if (sSnap.exists()) {
          supRef = ref;
          curDebt = Number((sSnap.data() as Record<string, unknown>).debt ?? 0);
        }
      }
      // ---- PHASE 2: ghi ----
      // Gỡ lớp nhập của phiếu này khỏi giá vốn bình quân (xóa phiếu = như chưa nhập)
      const poReceiptValue = new Map<string, number>();
      for (const it of po.items) {
        poReceiptValue.set(it.ingredient_id, (poReceiptValue.get(it.ingredient_id) ?? 0) + it.line_total);
      }
      const delAvgUpdates = new Map<string, number>();
      for (const [ingId, st] of state) {
        delAvgUpdates.set(ingId, wacRemove(st.stock, st.avg, needs.get(ingId) ?? 0, poReceiptValue.get(ingId) ?? 0));
      }
      writeStockMoves(tx, {
        warehouseId: po.warehouse_id,
        warehouseName: po.warehouse_name,
        needs,
        state,
        sign: -1,
        note: `Xóa phiếu nhập ${po.code}`,
        ref_type: 'purchase',
        ref_id: null,
        createdBy: auth.currentUser?.uid ?? null,
        avgCostUpdates: delAvgUpdates,
      });
      // Xóa khoản chi liên quan
      for (const r of oldCbRefs) tx.delete(r);
      // Hoàn công nợ NCC
      if (supRef) tx.update(supRef, { debt: Math.max(0, curDebt - po.debt_amount) });
      tx.delete(poRef);
    });
    logAudit('purchase.delete', `Xóa phiếu nhập ${id}`, { type: 'purchase_order', id });
  } catch (e) {
    throw toDbError(e);
  }
}

/**
 * Xóa phiếu xuất: hoàn tồn kho (cộng lại), xóa khoản thu liên quan,
 * hoàn công nợ NCC (nếu trả hàng). Chỉ chủ quán.
 */
export async function deleteStockExport(id: string): Promise<void> {
  try {
    // Khoản thu liên quan (đọc trước transaction — query collection không chạy trong tx)
    const cbSnap = await getDocs(
      query(collection(db, 'cashbook_entries'), where('ref_id', '==', id), limit(20)),
    );
    const oldCbRefs = cbSnap.docs
      .filter((d) => (d.data() as Record<string, unknown>).ref_type === 'stock_export')
      .map((d) => d.ref);
    await runTransaction(db, async (tx) => {
      // ---- PHASE 1: đọc ----
      const exRef = doc(db, 'stock_exports', id);
      const exSnap = await tx.get(exRef);
      if (!exSnap.exists()) throw new DbError('not-found', 'Không tìm thấy phiếu xuất.');
      const ex = stockExportFromDoc(exSnap);
      if (!ex) throw new DbError('not-found', 'Không tìm thấy phiếu xuất.');
      // Tồn kho (hoàn lại = cộng tồn)
      const needs = new Map<string, number>();
      const state = new Map<string, { stock: number; name: string }>();
      for (const it of ex.items) {
        const lRef = doc(db, 'stock_levels', stockLevelId(ex.warehouse_id, it.ingredient_id));
        const lSnap = await tx.get(lRef);
        const cur = lSnap.exists() ? Number((lSnap.data() as Record<string, unknown>).stock ?? 0) : 0;
        needs.set(it.ingredient_id, (needs.get(it.ingredient_id) ?? 0) + it.qty);
        if (!state.has(it.ingredient_id)) state.set(it.ingredient_id, { stock: cur, name: it.ingredient_name });
      }
      // Hoàn công nợ NCC (trả hàng đã trừ nợ → cộng lại): đọc trước khi ghi
      let supRef: ReturnType<typeof doc> | null = null;
      let curDebt = 0;
      const isReturn = (ex.behavior ?? 'none') === 'return_supplier';
      if (isReturn && ex.supplier_id && ex.subtotal > 0) {
        const ref = doc(db, 'suppliers', ex.supplier_id);
        const sSnap = await tx.get(ref);
        if (sSnap.exists()) {
          supRef = ref;
          curDebt = Number((sSnap.data() as Record<string, unknown>).debt ?? 0);
        }
      }
      // Hoàn nợ khách hàng của phiếu xuất bán (chỉ phần đã ghi, kẹp về 0).
      // Phiếu cũ chưa từng ghi nợ (debt_booked_amount = 0) thì không hoàn gì.
      let custRefDel: ReturnType<typeof doc> | null = null;
      let custDebtDel = 0;
      if ((ex.behavior ?? 'none') === 'sale' && ex.debt_booked_amount > 0 && ex.customer_id) {
        const ref = doc(db, 'customers', ex.customer_id);
        const sSnap = await tx.get(ref);
        if (sSnap.exists()) {
          custRefDel = ref;
          custDebtDel = Number((sSnap.data() as Record<string, unknown>).debt ?? 0);
        }
      }
      // ---- PHASE 2: ghi ----
      writeStockMoves(tx, {
        warehouseId: ex.warehouse_id,
        warehouseName: ex.warehouse_name,
        needs,
        state,
        sign: 1,
        note: `Xóa phiếu xuất ${ex.code}`,
        ref_type: 'stock_export',
        ref_id: null,
        createdBy: auth.currentUser?.uid ?? null,
      });
      // Xóa khoản thu liên quan
      for (const r of oldCbRefs) tx.delete(r);
      // Hoàn công nợ NCC
      if (supRef) tx.update(supRef, { debt: curDebt + ex.subtotal });
      // Hoàn nợ khách hàng của phiếu xuất bán
      if (custRefDel && ex.customer_id) {
        const rev = Math.min(ex.debt_booked_amount, Math.max(custDebtDel, 0));
        const next = Math.max(0, custDebtDel - rev);
        tx.update(custRefDel, { debt: next });
        if (rev > 0) {
          const logRef = doc(collection(db, 'customers', ex.customer_id, 'debt_logs'));
          tx.set(logRef, {
            id: logRef.id,
            amount: -rev,
            balance_after: next,
            note: `Hoàn nợ do xóa phiếu xuất ${ex.code}`,
            created_by: auth.currentUser?.uid ?? null,
            created_at: new Date().toISOString(),
          });
        }
      }
      tx.delete(exRef);
    });
    logAudit('stock_export.delete', `Xóa phiếu xuất ${id}`, { type: 'stock_export', id });
  } catch (e) {
    throw toDbError(e);
  }
}

/**
 * Thu phải thu phiếu xuất bán: tăng đã thu, giảm phải thu, ghi khoản thu
 * vào sổ quỹ và (nếu phần phải thu này đã ghi vào nợ khách hàng) giảm nợ
 * khách tương ứng — tất cả trong 1 transaction.
 * Quy tắc phiếu cũ: phiếu tạo trước bản gắn khách (không có bản ghi nợ
 * khách tương ứng, debt_booked_amount = 0) thì chỉ thu theo phiếu, không
 * trừ nợ khách âm thầm, dù phiếu có customer_id.
 */
export async function collectExportReceivable(
  exportId: string,
  amount: number,
  fundId: string | null,
): Promise<StockExport> {
  const v = Math.max(0, Math.round(Number(amount) || 0));
  if (v <= 0) throw new DbError('invalid-argument', 'Số tiền thu phải lớn hơn 0.');
  try {
    let saved: StockExport | undefined;
    await runTransaction(db, async (tx) => {
      const exRef = doc(db, 'stock_exports', exportId);
      const exSnap = await tx.get(exRef);
      if (!exSnap.exists()) throw new DbError('not-found', 'Không tìm thấy phiếu xuất.');
      const ex = stockExportFromDoc(exSnap);
      if (!ex) throw new DbError('not-found', 'Không tìm thấy phiếu xuất.');
      if ((ex.behavior ?? 'none') !== 'sale') throw new DbError('invalid-argument', 'Phiếu này không phải phiếu xuất bán nên không có phải thu.');
      const receivable = ex.receivable_amount > 0 ? ex.receivable_amount : Math.max(0, ex.subtotal - ex.received_amount);
      if (v > receivable) {
        throw new DbError('invalid-argument', `Số tiền thu (${v.toLocaleString('vi-VN')}đ) lớn hơn phải thu còn lại (${receivable.toLocaleString('vi-VN')}đ).`);
      }
      const createdBy = auth.currentUser?.uid ?? null;
      // Giảm nợ khách: chỉ phần đã ghi (debt_booked_amount), kẹp về 0.
      let custRef: ReturnType<typeof doc> | null = null;
      let custDebt = 0;
      let debtReduce = 0;
      if (ex.customer_id && ex.debt_booked_amount > 0) {
        custRef = doc(db, 'customers', ex.customer_id);
        const cSnap = await tx.get(custRef);
        if (cSnap.exists()) {
          custDebt = Number((cSnap.data() as Record<string, unknown>).debt ?? 0);
          debtReduce = Math.min(v, Math.max(custDebt, 0));
        } else {
          custRef = null;
        }
      }
      const newReceived = ex.received_amount + v;
      const newReceivable = Math.max(0, receivable - v);
      const newBooked = Math.max(0, ex.debt_booked_amount - v);
      tx.update(exRef, {
        received_amount: newReceived,
        receivable_amount: newReceivable,
        debt_booked_amount: newBooked,
        fund_id: fundId ?? ex.fund_id ?? null,
      });
      if (custRef && debtReduce > 0 && ex.customer_id) {
        const next = Math.max(0, custDebt - debtReduce);
        tx.update(custRef, { debt: next });
        const logRef = doc(collection(db, 'customers', ex.customer_id, 'debt_logs'));
        tx.set(logRef, {
          id: logRef.id,
          amount: -debtReduce,
          balance_after: next,
          note: `Thu phải thu ${ex.code}`,
          created_by: createdBy,
          created_at: new Date().toISOString(),
        });
      }
      const fundRef = doc(collection(db, 'cashbook_entries'));
      tx.set(fundRef, {
        id: fundRef.id,
        type: 'thu',
        amount: v,
        note: `Thu phải thu phiếu ${ex.code}`,
        category: 'Xuất bán',
        fund_id: fundId ?? null,
        warehouse_id: ex.warehouse_id,
        ref_type: 'stock_export',
        ref_id: ex.id,
        occurred_at: new Date().toISOString(),
        created_by: createdBy,
        created_at: new Date().toISOString(),
      });
      saved = { ...ex, received_amount: newReceived, receivable_amount: newReceivable, debt_booked_amount: newBooked, fund_id: fundId ?? ex.fund_id ?? null };
    });
    if (!saved) throw new DbError('unknown', 'Không thu được phải thu.');
    logAudit('stock_export.collect', `Thu phải thu ${saved.code} — ${v.toLocaleString('vi-VN')}đ`, { type: 'stock_export', id: saved.id });
    return saved;
  } catch (e) {
    throw toDbError(e);
  }
}

/** Trả nợ nhà cung cấp: trừ công nợ + ghi chi vào sổ quỹ. */
export async function paySupplierDebt(
  supplierId: string,
  amount: number,
  fundId: string | null,
  warehouseId: string,
  note?: string | null,
): Promise<void> {
  const amt = Math.max(0, Math.round(Number(amount) || 0));
  if (amt <= 0) throw new DbError('invalid-argument', 'Số tiền trả phải lớn hơn 0.');
  try {
    await runTransaction(db, async (tx) => {
      const supRef = doc(db, 'suppliers', supplierId);
      const sSnap = await tx.get(supRef);
      if (!sSnap.exists()) throw new DbError('not-found', 'Nhà cung cấp không tồn tại.');
      const curDebt = Number((sSnap.data() as Record<string, unknown>).debt ?? 0);
      if (amt > curDebt) throw new DbError('invalid-argument', `Nợ NCC chỉ còn ${curDebt.toLocaleString('vi-VN')}đ.`);
      tx.update(supRef, { debt: curDebt - amt });
      const fundRef = doc(collection(db, 'cashbook_entries'));
      tx.set(fundRef, {
        id: fundRef.id,
        type: 'chi',
        amount: amt,
        note: `Trả nợ NCC — ${String((sSnap.data() as Record<string, unknown>).name ?? '')}${note ? ` — ${note}` : ''}`,
        category: 'Trả nợ NCC',
        fund_id: fundId,
        warehouse_id: warehouseId,
        ref_type: 'supplier_pay',
        ref_id: supplierId,
        occurred_at: new Date().toISOString(),
        created_by: auth.currentUser?.uid ?? null,
        created_at: new Date().toISOString(),
      });
    });
    logAudit('supplier.pay', `Trả nợ NCC ${amt.toLocaleString('vi-VN')}đ`, { type: 'supplier', id: supplierId });
  } catch (e) {
    throw toDbError(e);
  }
}

/** Nguyên liệu sắp hết (tồn <= ngưỡng) tại các kho được phép — để gợi ý nhập hàng. */
export async function listLowStock(warehouseIds?: string[] | null): Promise<
  { ingredient_id: string; name: string; unit: string; warehouse_id: string; warehouse_name: string; stock: number; min_stock: number }[]
> {
  try {
    const [ings, ws] = await Promise.all([
      getDocs(query(collection(db, 'ingredients'), where('active', '==', true), limit(500))),
      listWarehouses(false),
    ]);
    const inScope = ws.filter(
      (w) => w.active && (!warehouseIds || warehouseIds.length === 0 || warehouseIds.includes(w.id)),
    );
    const ingList = ings.docs.map((d) => ({
      id: d.id,
      name: String((d.data() as Record<string, unknown>).name ?? ''),
      unit: String((d.data() as Record<string, unknown>).unit ?? ''),
      min_stock: Number((d.data() as Record<string, unknown>).min_stock ?? 0),
      // Nguyen lieu tat canh bao (alert_enabled === false) thi khong canh bao
      // nua - khong phai hang nao cung can canh bao (Hoang yeu cau v5.14).
      alert_enabled: (d.data() as Record<string, unknown>).alert_enabled !== false,
    }));
    const out: { ingredient_id: string; name: string; unit: string; warehouse_id: string; warehouse_name: string; stock: number; min_stock: number }[] = [];
    for (const w of inScope) {
      const snaps = await Promise.all(
        ingList.map((ing) => getDoc(doc(db, 'stock_levels', stockLevelId(w.id, ing.id)))),
      );
      snaps.forEach((snap, i) => {
        const stock = snap.exists() ? Number((snap.data() as Record<string, unknown>).stock ?? 0) : 0;
        const ing = ingList[i];
        if (!ing.alert_enabled) return;
        if (stock <= ing.min_stock) {
          out.push({
            ingredient_id: ing.id,
            name: ing.name,
            unit: ing.unit,
            warehouse_id: w.id,
            warehouse_name: w.name,
            stock,
            min_stock: ing.min_stock,
          });
        }
      });
    }
    return out.sort((a, b) => a.stock - b.stock);
  } catch (e) {
    throw toDbError(e);
  }
}

/** Mã định danh quán (multi-tenant: mỗi bản deploy 1 mã). Tự tạo lần đầu. */
export async function getOrCreateTenantId(): Promise<string> {
  try {
    const snap = await getDoc(doc(db, 'settings', 'tenant_id'));
    const cur = snap.exists() ? String((snap.data() as Record<string, unknown>).value ?? '') : '';
    if (/^BEESY-[0-9A-Z]{6}$/.test(cur)) return cur;
    const id = 'BEESY-' + Array.from({ length: 6 }, () => 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'[Math.floor(Math.random() * 32)]).join('');
    await setDoc(doc(db, 'settings', 'tenant_id'), { key: 'tenant_id', value: id }, { merge: true });
    return id;
  } catch {
    return 'BEESY-UNKNOWN';
  }
}

// ================= COMBO =================

function comboFromDoc(snap: QueryDocumentSnapshot | DocumentSnapshot): Combo | null {
  if (!snap.exists()) return null;
  const d = snap.data() as Record<string, unknown>;
  return {
    id: snap.id,
    name: String(d.name ?? ''),
    price: Math.max(0, Math.round(Number(d.price ?? 0))),
    items: (Array.isArray(d.items) ? d.items : []).map((it: Record<string, unknown>) => ({
      product_id: String(it.product_id ?? ''),
      product_name: String(it.product_name ?? ''),
      qty: Math.max(1, Number(it.qty ?? 1)),
    })),
    active: d.active !== false,
    sort_order: Number(d.sort_order ?? 0),
    created_at: tsToIso(d.created_at),
  };
}

export async function listCombos(activeOnly = false): Promise<Combo[]> {
  try {
    const q = activeOnly
      ? query(collection(db, 'combos'), where('active', '==', true), orderBy('sort_order', 'asc'), limit(100))
      : query(collection(db, 'combos'), orderBy('sort_order', 'asc'), limit(100));
    const snap = await getDocs(q);
    return snap.docs.map(comboFromDoc).filter((c): c is Combo => !!c);
  } catch (e) {
    throw toDbError(e);
  }
}

export async function saveCombo(input: {
  id?: string;
  name: string;
  price: number;
  items: ComboItem[];
  sort_order?: number;
}): Promise<Combo> {
  const name = input.name.trim().slice(0, 100);
  if (!name) throw new DbError('invalid-argument', 'Thiếu tên combo.');
  const price = Math.max(0, Math.round(Number(input.price) || 0));
  if (price <= 0) throw new DbError('invalid-argument', 'Giá combo phải lớn hơn 0.');
  const items = (input.items ?? [])
    .filter((it) => it.product_id)
    .map((it) => ({
      product_id: String(it.product_id),
      product_name: String(it.product_name ?? '').slice(0, 100),
      qty: Math.max(1, Math.round(Number(it.qty) || 1)),
    }));
  if (items.length === 0) throw new DbError('invalid-argument', 'Combo phải có ít nhất một món.');
  try {
    const ref = input.id ? doc(db, 'combos', input.id) : doc(collection(db, 'combos'));
    const ex = input.id ? await getDoc(ref) : null;
    await setDoc(
      ref,
      {
        id: ref.id,
        name,
        price,
        items,
        active: ex?.exists() ? (ex.data() as Record<string, unknown>).active !== false : true,
        sort_order: Number(input.sort_order ?? (ex?.exists() ? Number((ex.data() as Record<string, unknown>).sort_order ?? 0) : 0)),
        created_at: ex?.exists() ? ex.data()?.created_at ?? serverTimestamp() : serverTimestamp(),
      },
      { merge: true },
    );
    logAudit('combo.save', `${input.id ? 'Sửa' : 'Thêm'} combo "${name}"`, { type: 'combo', id: ref.id });
    const c = comboFromDoc(await getDoc(ref));
    if (!c) throw new DbError('unknown', 'Không đọc được combo vừa lưu.');
    return c;
  } catch (e) {
    throw toDbError(e);
  }
}

export async function toggleCombo(id: string): Promise<void> {
  try {
    const ref = doc(db, 'combos', id);
    const snap = await getDoc(ref);
    if (!snap.exists()) throw new DbError('not-found', 'Combo không tồn tại.');
    await updateDoc(ref, { active: !((snap.data() as Record<string, unknown>).active !== false) });
  } catch (e) {
    throw toDbError(e);
  }
}

export async function deleteCombo(id: string): Promise<void> {
  try {
    const snap = await getDoc(doc(db, 'combos', id));
    const name = snap.exists() ? String((snap.data() as Record<string, unknown>).name ?? id) : id;
    await deleteDoc(doc(db, 'combos', id));
    logAudit('combo.delete', `Xóa combo "${name}"`, { type: 'combo', id });
  } catch (e) {
    throw toDbError(e);
  }
}

/** Cài đặt công khai cho trang đặt hàng (không cần đăng nhập). */
export async function getPublicSettings(): Promise<{ shop_name: string; brand: string }> {
  try {
    const [sn, br] = await Promise.all([
      getDoc(doc(db, 'settings', 'shop_name')),
      getDoc(doc(db, 'settings', 'brand')),
    ]);
    return {
      shop_name: sn.exists() ? String((sn.data() as Record<string, unknown>).value ?? '') : '',
      brand: br.exists() ? String((br.data() as Record<string, unknown>).value ?? '') : '',
    };
  } catch {
    return { shop_name: '', brand: '' };
  }
}

// ================= ĐƠN ĐẶT ONLINE =================

function onlineOrderFromDoc(snap: QueryDocumentSnapshot | DocumentSnapshot): OnlineOrder | null {
  if (!snap.exists()) return null;
  const d = snap.data() as Record<string, unknown>;
  const items = (Array.isArray(d.items) ? d.items : []).map((it: Record<string, unknown>) => ({
    product_id: String(it.product_id ?? ''),
    product_name: String(it.product_name ?? ''),
    qty: Math.max(1, Number(it.qty ?? 1)),
    unit_price: Math.max(0, Number(it.unit_price ?? 0)),
    modifier_option_ids: Array.isArray(it.modifier_option_ids) ? it.modifier_option_ids.map(String) : [],
    modifiers: Array.isArray(it.modifiers)
      ? it.modifiers.map((m: Record<string, unknown>) => ({
          group: String(m.group ?? ''),
          option: String(m.option ?? ''),
          price_delta: Number(m.price_delta ?? 0),
        }))
      : [],
    line_total: Math.max(0, Number(it.line_total ?? 0)),
    ...(typeof it.note === 'string' && it.note ? { note: it.note.slice(0, 200) } : {}),
  }));
  const pk = d.payment_kind === 'transfer' ? 'transfer' : 'cash';
  const st = d.status === 'confirmed' ? 'confirmed' : d.status === 'cancelled' ? 'cancelled' : 'pending';
  return {
    id: snap.id,
    items,
    customer_name: String(d.customer_name ?? ''),
    customer_phone: String(d.customer_phone ?? ''),
    note: (d.note as string | null) ?? null,
    payment_method_id: String(d.payment_method_id ?? 'cash'),
    payment_kind: pk,
    voucher_code: (d.voucher_code as string | null) ?? null,
    subtotal: Number(d.subtotal ?? 0),
    discount: Number(d.discount ?? 0),
    total: Number(d.total ?? 0),
    status: st,
    confirmed_order_id: (d.confirmed_order_id as string | null) ?? null,
    created_at: tsToIso(d.created_at),
  };
}

export interface PlaceOnlineOrderInput {
  items: CreateOrderItemInput[];
  customerName: string;
  customerPhone: string;
  note?: string | null;
  paymentMethodId: string;
  voucherCode?: string | null;
}

/**
 * Khách vãng lai đặt hàng (không cần đăng nhập). Giá tính lại từ catalog phía server,
 * không tin giá client gửi. Đơn vào online_orders chờ nhân viên duyệt 1 chạm.
 */
export async function placeOnlineOrder(input: PlaceOnlineOrderInput): Promise<{ id: string; total: number }> {
  const name = input.customerName.trim().slice(0, 50);
  const phone = input.customerPhone.trim().slice(0, 20);
  if (!name) throw new DbError('invalid-argument', 'Vui lòng nhập tên người nhận.');
  if (!/^[0-9+\s]{8,20}$/.test(phone)) throw new DbError('invalid-argument', 'Số điện thoại chưa đúng.');
  if (!Array.isArray(input.items) || input.items.length === 0 || input.items.length > 20) {
    throw new DbError('invalid-argument', 'Giỏ hàng chưa có món.');
  }
  try {
    const [catalog, methods] = await Promise.all([loadCatalog(), listPaymentMethodsPublic()]);
    const method = methods.find((m) => m.id === input.paymentMethodId && m.kind !== 'debt');
    if (!method) throw new DbError('invalid-argument', 'Phương thức thanh toán không hợp lệ.');
    const pricing = priceOrderLines(input.items, catalog);
    // Voucher (nếu có)
    let voucher: Voucher | null = null;
    const vCode = typeof input.voucherCode === 'string' ? input.voucherCode.trim().toLowerCase() : '';
    if (vCode) {
      voucher = voucherFromDoc(await getDoc(doc(db, 'vouchers', vCode)));
      if (!voucher) throw new DbError('invalid-argument', 'Mã voucher không tồn tại.');
      const vErr = validateVoucher(voucher, pricing.subtotal, todayVN());
      if (vErr) throw new DbError('invalid-argument', vErr);
    }
    const discount = voucher ? calcVoucherDiscount(pricing.subtotal, voucher) : 0;
    const total = pricing.subtotal - discount;
    if (total <= 0) throw new DbError('invalid-argument', 'Tổng tiền đơn hàng không hợp lệ.');
    const id = uuid();
    const items: OnlineOrderItem[] = pricing.lines.map((l, i) => ({
      product_id: l.product_id,
      product_name: l.product_name,
      qty: input.items[i].qty,
      unit_price: l.unit_price,
      modifier_option_ids: input.items[i].modifierOptionIds ?? [],
      modifiers: l.modifiers,
      line_total: l.line_total,
      ...(l.note ? { note: l.note } : {}),
    }));
    await setDoc(doc(db, 'online_orders', id), {
      id,
      items,
      customer_name: name,
      customer_phone: phone,
      note: typeof input.note === 'string' && input.note ? input.note.slice(0, 500) : null,
      payment_method_id: method.id,
      payment_kind: method.kind,
      voucher_code: voucher ? voucher.code : null,
      subtotal: pricing.subtotal,
      discount,
      total,
      status: 'pending',
      confirmed_order_id: null,
      created_at: serverTimestamp(),
    });
    return { id, total };
  } catch (e) {
    throw toDbError(e);
  }
}

export async function getOnlineOrder(id: string): Promise<OnlineOrder | null> {
  try {
    return onlineOrderFromDoc(await getDoc(doc(db, 'online_orders', id)));
  } catch (e) {
    throw toDbError(e);
  }
}

/** Đơn online chờ duyệt — realtime cho KDS/nhân viên. */
export function subscribePendingOnlineOrders(
  cb: (items: OnlineOrder[]) => void,
  onError?: (e: unknown) => void,
): () => void {
  const q = query(collection(db, 'online_orders'), where('status', '==', 'pending'), orderBy('created_at', 'desc'), limit(50));
  return onSnapshot(
    q,
    (snap) => {
      cb(snap.docs.map(onlineOrderFromDoc).filter((o): o is OnlineOrder => !!o));
    },
    (e) => {
      cb([]);
      onError?.(e);
    },
  );
}

/**
 * Duyệt đơn online (nhân viên): tạo đơn thật qua createOrder (tính lại giá, trừ kho,
 * trừ lượt voucher) rồi đánh dấu confirmed. Chỉ chủ/quản lý/thu ngân.
 */
export async function confirmOnlineOrder(id: string): Promise<Order> {
  try {
    const oo = onlineOrderFromDoc(await getDoc(doc(db, 'online_orders', id)));
    if (!oo) throw new DbError('not-found', 'Đơn online không tồn tại.');
    if (oo.status === 'confirmed' && oo.confirmed_order_id) {
      // Đã duyệt rồi (bấm 2 lần / 2 người cùng duyệt): trả về đúng đơn đã tạo.
      const existing = await getOrder(oo.confirmed_order_id);
      if (existing) return existing;
    }
    if (oo.status !== 'pending') throw new DbError('invalid-argument', 'Đơn này đã được xử lý.');
    // clientUuid = chính id của đơn online: createOrder chống trùng theo
    // clientUuid nên duyệt lại bao nhiêu lần cũng chỉ ra MỘT đơn thật.
    // Kho bán cố định = kho mặc định của quán (bản cũ lấy theo kho của người
    // duyệt — người được gán nhiều kho là đơn trừ nhầm kho).
    const onlineWid = await getDefaultWarehouseId();
    const order = await createOrder({
      clientUuid: id,
      customerId: null,
      warehouseId: onlineWid,
      items: oo.items.map((it) => ({
        productId: it.product_id,
        qty: it.qty,
        modifierOptionIds: it.modifier_option_ids,
        note: it.note,
      })),
      paymentMethod: oo.payment_method_id,
      note: oo.note ? `[Online] ${oo.note}` : '[Online]',
      source: 'online',
      onlineName: oo.customer_name,
      onlinePhone: oo.customer_phone,
      voucherCode: oo.voucher_code,
    });
    // Ghi confirmed bằng transaction có điều kiện: nếu người khác đã duyệt
    // thành một đơn khác thì báo lỗi thay vì ghi đè.
    await runTransaction(db, async (tx) => {
      const ref = doc(db, 'online_orders', id);
      const s = await tx.get(ref);
      if (!s.exists()) throw new DbError('not-found', 'Đơn online không tồn tại.');
      const cur = s.data() as Record<string, unknown>;
      if (cur.status === 'confirmed') {
        if (cur.confirmed_order_id === order.id) return;
        throw new DbError('invalid-argument', 'Đơn này đã được duyệt thành một đơn khác.');
      }
      tx.update(ref, { status: 'confirmed', confirmed_order_id: order.id });
    });
    logAudit('order.online', `Duyệt đơn online ${oo.customer_name} → ${order.code}`, { type: 'online_order', id });
    return order;
  } catch (e) {
    throw toDbError(e);
  }
}

export async function cancelOnlineOrder(id: string): Promise<void> {
  try {
    const oo = onlineOrderFromDoc(await getDoc(doc(db, 'online_orders', id)));
    if (!oo) throw new DbError('not-found', 'Đơn online không tồn tại.');
    if (oo.status !== 'pending') throw new DbError('invalid-argument', 'Đơn này đã được xử lý.');
    await updateDoc(doc(db, 'online_orders', id), { status: 'cancelled' });
    logAudit('order.online', `Từ chối đơn online của ${oo.customer_name}`, { type: 'online_order', id });
  } catch (e) {
    throw toDbError(e);
  }
}

/** Lý do nhập/xuất kho tùy chỉnh (settings/stock_reasons). */
const DEFAULT_IMPORT_REASONS: StockReason[] = [
  { id: 'ncc', label: 'Nhập hàng NCC', builtin: true },
  { id: 'dieu_chinh', label: 'Nhập điều chỉnh', builtin: true },
  { id: 'tra_hang', label: 'Khách trả hàng', builtin: true },
];
const DEFAULT_EXPORT_REASONS: StockReason[] = [
  { id: 'ban', label: 'Bán nguyên liệu', behavior: 'sale', builtin: true },
  { id: 'tra_ncc', label: 'Trả hàng NCC', behavior: 'return_supplier', builtin: true },
  { id: 'huy', label: 'Hủy hàng hỏng', behavior: 'none', builtin: true },
  { id: 'khac', label: 'Khác', behavior: 'none', builtin: true },
];

export async function getStockReasons(): Promise<StockReasonsSettings> {
  try {
    const snap = await getDoc(doc(db, 'settings', 'stock_reasons'));
    if (snap.exists()) {
      const d = snap.data() as Record<string, unknown>;
      const imp = Array.isArray(d.import_reasons) ? d.import_reasons : [];
      const exp = Array.isArray(d.export_reasons) ? d.export_reasons : [];
      return {
        import_reasons: imp.length > 0 ? (imp as StockReason[]) : DEFAULT_IMPORT_REASONS,
        export_reasons: exp.length > 0 ? (exp as StockReason[]) : DEFAULT_EXPORT_REASONS,
      };
    }
    return { import_reasons: DEFAULT_IMPORT_REASONS, export_reasons: DEFAULT_EXPORT_REASONS };
  } catch {
    return { import_reasons: DEFAULT_IMPORT_REASONS, export_reasons: DEFAULT_EXPORT_REASONS };
  }
}

export async function saveStockReasons(r: StockReasonsSettings): Promise<void> {
  try {
    await setDoc(
      doc(db, 'settings', 'stock_reasons'),
      {
        import_reasons: r.import_reasons.map((x) => ({ id: x.id, label: x.label, builtin: !!x.builtin })),
        export_reasons: r.export_reasons.map((x) => ({
          id: x.id,
          label: x.label,
          behavior: x.behavior ?? 'none',
          builtin: !!x.builtin,
        })),
        updated_at: serverTimestamp(),
      },
      { merge: true },
    );
    logAudit('settings.stock_reasons', 'Cập nhật lý do nhập/xuất kho');
  } catch (e) {
    throw toDbError(e);
  }
}

/** Tìm behavior của lý do xuất (mặc định 'none' nếu không rõ). */
export function exportReasonBehavior(reasons: StockReason[], reasonId: string): StockExportBehavior {
  return reasons.find((r) => r.id === reasonId)?.behavior ?? 'none';
}

export async function getSettings(): Promise<Record<string, string>> {
  try {
    const snap = await getDocs(collection(db, 'settings'));
    const out: Record<string, string> = {};
    for (const d of snap.docs) out[d.id] = String(d.data().value ?? '');
    return out;
  } catch (e) {
    throw toDbError(e);
  }
}

export async function setSetting(key: string, value: string): Promise<void> {
  if (!String(key ?? '').trim()) throw new DbError('invalid-argument', 'Thiếu key cài đặt.');
  try {
    await setDoc(doc(db, 'settings', key), { key, value: String(value ?? '') }, { merge: true });
  } catch (e) {
    throw toDbError(e);
  }
}

// ----------------------------------------------------------------- reports ---
// Mirror backend GET /api/v1/reports/daily — aggregate client-side.
// Đơn cancelled không tính vào doanh thu.

/** Giá vốn hiện tại của món — dùng cho đơn cũ chưa có snapshot cost_price. */
let costMapCache: { at: number; map: Map<string, number> } | null = null;
let costMapInflight: Promise<Map<string, number>> | null = null;
async function loadCostMap(): Promise<Map<string, number>> {
  // Cache 5 phút — giá vốn ít khi đổi, tránh đọc 2000 docs mỗi lần mở báo cáo
  if (costMapCache && Date.now() - costMapCache.at < 5 * 60 * 1000) {
    return costMapCache.map;
  }
  // Chia sẻ promise đang bay — các getRangeReport gọi song song không đọc products trùng lặp
  if (!costMapInflight) {
    costMapInflight = (async () => {
      try {
        const pSnap = await getDocs(query(collection(db, 'products'), limit(2000)));
        const m = new Map<string, number>();
        for (const d of pSnap.docs) {
          m.set(d.id, toProduct(d.id, d.data() as Record<string, unknown>).cost_price);
        }
        // Combo không nằm trong products: giá vốn combo = tổng (giá vốn món thành
        // phần x số lượng) — để đơn combo cũ có snapshot cost_price = 0 vẫn tính
        // được giá vốn xấp xỉ thay vì bị coi là 0 đồng.
        try {
          const cSnap = await getDocs(query(collection(db, 'combos'), limit(100)));
          for (const d of cSnap.docs) {
            const cdata = d.data() as Record<string, unknown>;
            const cItems = Array.isArray(cdata.items) ? (cdata.items as Record<string, unknown>[]) : [];
            let cc = 0;
            for (const ci of cItems) {
              const pid = String(ci.product_id ?? '');
              const cq = Math.max(1, Number(ci.qty ?? 1));
              cc += (m.get(pid) ?? 0) * cq;
            }
            if (cc > 0) m.set(d.id, cc);
          }
        } catch { /* đọc combo lỗi thì bỏ qua, không chặn báo cáo */ }
        costMapCache = { at: Date.now(), map: m };
        return m;
      } catch {
        return costMapCache?.map ?? new Map();
      } finally {
        costMapInflight = null;
      }
    })();
  }
  return costMapInflight;
}

function buildDailyReport(orders: Order[], date: string, costNow: Map<string, number>, expenses = 0): DailyReport {
  const itemCost = (it: { product_id: string; cost_price: number }) =>
    it.cost_price > 0 ? it.cost_price : (costNow.get(it.product_id) ?? 0);

  // Cach B (chot 25/10/2026): phi ship chi la thu ho roi tra cho don vi van
  // chuyen, KHONG tinh vao doanh thu va KHONG tinh vao loi nhuan. Doanh thu o
  // day chi la tien hang (tong don tru phi ship). So quy van thu du tong gom
  // ship, nen tien thu thuc te = revenue + shipping_total. by_payment giu
  // nguyen la tien thu theo phuong thuc (gom ship) vi Chot ket dung no de doi
  // chieu tien mat trong ket; chi revenue/by_hour moi loai ship.
  const shipping_total = orders.reduce((s, o) => s + Math.max(0, o.shipping_fee ?? 0), 0);
  const revenue = orders.reduce((s, o) => s + o.total - Math.max(0, o.shipping_fee ?? 0), 0);
  const by_payment: DailyReport['by_payment'] = {};
  for (const o of orders) {
    // Đơn hỗn hợp: cộng dồn DOANH THU theo từng phần thanh toán, nhưng COUNT chỉ
    // đếm 1 lượt cho phần chính (khớp payment_method của đơn) — trước đây đếm mỗi
    // phần 1 lượt nên tổng số lượt theo phương thức lớn hơn tổng số đơn.
    const splits = orderPaymentSplits(o);
    if (splits.length > 1) {
      let counted = false;
      for (const sp of splits) {
        const key = sp.method_id || 'unknown';
        const slot = by_payment[key] ?? { name: sp.method_name || key, count: 0, revenue: 0 };
        if (!counted && sp.method_id === o.payment_method) {
          slot.count += 1;
          counted = true;
        }
        slot.revenue += sp.amount;
        if (sp.method_name) slot.name = sp.method_name;
        by_payment[key] = slot;
      }
      if (!counted) {
        // Không phần nào khớp payment_method (dữ liệu lạ) → đếm vào phần đầu tiên
        const first = splits[0];
        const key = first.method_id || 'unknown';
        if (by_payment[key]) by_payment[key].count += 1;
      }
    } else {
      const key = o.payment_method || 'unknown';
      const slot = by_payment[key] ?? { name: o.payment_method_name || key, count: 0, revenue: 0 };
      slot.count += 1;
      slot.revenue += o.total;
      if (o.payment_method_name) slot.name = o.payment_method_name;
      by_payment[key] = slot;
    }
  }

  const topMap = new Map<
    string,
    { product_id: string; name: string; qty: number; revenue: number; cost: number; profit: number }
  >();
  let profit = 0;
  let cost = 0;
  let promo_count = 0;
  let promo_discount = 0;
  for (const o of orders) {
    // Đơn khuyến mại: có giảm giá hoặc voucher
    const discount = o.discount ?? 0;
    if (discount > 0 || !!o.voucher_code) {
      promo_count += 1;
      promo_discount += discount;
    }
    // Phân bổ giảm giá theo tỉ lệ từng dòng để lợi nhuận = doanh thu thực - giá vốn
    const subtotal = o.items.reduce((s, it) => s + it.line_total, 0);
    for (const it of o.items) {
      const lineCost = itemCost(it) * it.qty;
      const share = subtotal > 0 ? (it.line_total / subtotal) * discount : 0;
      const lineRevenue = it.line_total - share;
      const lineProfit = lineRevenue - lineCost;
      profit += lineProfit;
      cost += lineCost;
      const cur = topMap.get(it.product_id) ?? {
        product_id: it.product_id,
        name: it.product_name,
        qty: 0,
        revenue: 0,
        cost: 0,
        profit: 0,
      };
      cur.qty += it.qty;
      cur.revenue += lineRevenue;
      cur.cost += lineCost;
      cur.profit += lineProfit;
      topMap.set(it.product_id, cur);
    }
  }
  // Trả TOÀN BỘ món (sắp xếp mặc định theo số lượng); màn Báo cáo sẽ sắp xếp lại
  // theo tiêu chí (số lượng/doanh thu/lợi nhuận) rồi mới cắt top 10 — để top
  // doanh thu/lợi nhuận chính xác kể cả khi món nằm ngoài top 10 số lượng.
  const top_products = [...topMap.values()].sort((a, b) => b.qty - a.qty || b.revenue - a.revenue);

  const by_hour = Array.from({ length: 24 }, (_, hour) => ({ hour, count: 0, revenue: 0 }));
  for (const o of orders) {
    const h = vnHour(o.created_at);
    if (h >= 0 && h < 24) {
      by_hour[h].count += 1;
      by_hour[h].revenue += o.total - Math.max(0, o.shipping_fee ?? 0);
    }
  }

  const order_count = orders.length;
  // Lợi nhuận ròng = doanh thu − giá vốn − toàn bộ chi phí (từ sổ quỹ)
  const netProfit = profit - expenses;
  return {
    date,
    revenue,
    shipping_total,
    profit: netProfit,
    cost,
    expenses,
    order_count,
    cancelled_count: 0, // được tính ở caller (đơn hủy bị lọc riêng)
    promo_count,
    promo_discount,
    avg_order: order_count > 0 ? revenue / order_count : 0,
    by_payment,
    top_products,
    by_hour,
  };
}

export async function getDailyReport(date: string): Promise<DailyReport> {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    throw new DbError('invalid-argument', 'Tham số date phải có dạng YYYY-MM-DD.');
  }
  try {
    const [allOrders, costNow, expenses] = await Promise.all([
      fetchOrdersInRange(date, date),
      loadCostMap(),
      getExpensesTotal(date, date),
    ]);
    const cancelled_count = allOrders.filter((o) => o.status === 'cancelled').length;
    const orders = allOrders.filter((o) => o.status !== 'cancelled');
    const report = buildDailyReport(orders, date, costNow, expenses);
    report.cancelled_count = cancelled_count;
    return report;
  } catch (e) {
    throw toDbError(e);
  }
}

// Báo cáo theo khoảng ngày (dùng cho các mốc lọc: hôm qua, tuần này/tháng này...).
// Truy vấn range trên business_date + orderBy cùng field nên không cần composite index mới.
/**
 * Kho mà người dùng hiện tại được phép XEM DỮ LIỆU (Sổ quỹ, Báo cáo, Chốt ngày).
 * Chủ quán = mọi kho; nhân viên = chỉ các kho đã gán.
 */
export async function getAllowedWarehouses(): Promise<{ warehouses: Warehouse[]; isOwner: boolean }> {
  const me = await getMyProfile();
  const privileged = me.role === 'owner';
  let ws = await listWarehouses();
  if (privileged && ws.length === 0) ws = await ensureWarehousesSeeded();
  const allowed = privileged ? ws : ws.filter((w) => me.warehouse_ids.includes(w.id));
  return { warehouses: allowed, isOwner: privileged };
}

/** Lọc đơn theo kho được phép xem — đơn không rõ kho (null) thì loại khỏi phạm vi giới hạn. */
function orderInScope(o: { warehouse_id?: string | null }, warehouseIds?: string[] | null): boolean {
  if (!warehouseIds || warehouseIds.length === 0) return true;
  return !!o.warehouse_id && warehouseIds.includes(o.warehouse_id);
}

/** Doanh thu + lợi nhuận từng ngày trong khoảng — 1 truy vấn duy nhất, gom nhóm client-side.
 *  Dùng cho biểu đồ so sánh tuần để tránh N truy vấn đơn lẻ (tiết kiệm lượt đọc). */
export interface DayRevenue { date: string; revenue: number; profit: number }
export async function getDailyBreakdown(start: string, end: string, warehouseIds?: string[] | null): Promise<DayRevenue[]> {
  const valid = /^\d{4}-\d{2}-\d{2}$/;
  if (!valid.test(start) || !valid.test(end) || start > end) {
    throw new DbError('invalid-argument', 'Khoảng ngày không hợp lệ.');
  }
  try {
    const dayCount = Math.max(1, Math.round((new Date(end).getTime() - new Date(start).getTime()) / 86400000) + 1);
    const [allOrders, costNow] = await Promise.all([
      fetchOrdersInRange(start, end),
      loadCostMap(),
    ]);
    const itemCost = (it: { product_id: string; cost_price: number }) =>
      it.cost_price > 0 ? it.cost_price : (costNow.get(it.product_id) ?? 0);
    // Khởi tạo slot cho MỌI ngày trong kỳ: ngày không có đơn vẫn phải bị trừ chi
    // phí (lợi nhuận âm) — trước đây chi phí của ngày không có đơn bị bỏ qua hẳn.
    const byDay = new Map<string, { revenue: number; profit: number }>();
    for (let i = 0; i < dayCount; i++) {
      byDay.set(addDaysVN(start, i), { revenue: 0, profit: 0 });
    }
    for (const o of allOrders) {
      if (o.status === 'cancelled' || !orderInScope(o, warehouseIds)) continue;
      const slot = byDay.get(o.business_date);
      if (!slot) continue;
      // Cach B: doanh thu theo ngay cung loai phi ship (thu ho, khong phai doanh thu).
      slot.revenue += o.total - Math.max(0, o.shipping_fee ?? 0);
      const subtotal = o.items.reduce((s, it) => s + it.line_total, 0);
      const discount = o.discount ?? 0;
      for (const it of o.items) {
        const share = subtotal > 0 ? (it.line_total / subtotal) * discount : 0;
        slot.profit += (it.line_total - share) - itemCost(it) * it.qty;
      }
    }
    // Trừ chi phí vận hành từng ngày — CÙNG quy tắc với getExpensesTotal: loại
    // chuyển quỹ/nhập hàng/trả nợ NCC, xếp ngày theo giờ VN, lọc kho, phân trang
    // toàn bộ (trước đây giới hạn 2000 khoản và xếp ngày theo UTC).
    let last: unknown = null;
    for (let page = 0; page < 200; page++) {
      const q =
        last == null
          ? query(
              collection(db, 'cashbook_entries'),
              where('type', '==', 'chi'),
              orderBy('__name__'),
              limit(500),
            )
          : query(
              collection(db, 'cashbook_entries'),
              where('type', '==', 'chi'),
              orderBy('__name__'),
              limit(500),
              startAfter(last as never),
            );
      const expSnap = await getDocs(q);
      if (expSnap.docs.length === 0) break;
      for (const d of expSnap.docs) {
        const data = d.data() as Record<string, unknown>;
        if (!isOperatingExpense(data)) continue;
        const wid = typeof data.warehouse_id === 'string' ? data.warehouse_id : null;
        if (!cashbookInScope(wid, warehouseIds)) continue;
        const slot = byDay.get(vnDateKeyOf(data.created_at));
        if (slot) slot.profit -= Number(data.amount ?? 0);
      }
      last = expSnap.docs[expSnap.docs.length - 1];
      if (expSnap.docs.length < 500) break;
    }
    const out: DayRevenue[] = [];
    for (let i = 0; i < dayCount; i++) {
      const date = addDaysVN(start, i);
      const v = byDay.get(date);
      out.push({ date, revenue: v?.revenue ?? 0, profit: v?.profit ?? 0 });
    }
    return out;
  } catch (e) {
    throw toDbError(e);
  }
}

/** 1 cặp cột giờ: doanh thu + lợi nhuận + chi phí vận hành của kỳ này và
 *  kỳ trước trong cùng giờ. Chi phí tách riêng (không gộp vào lợi nhuận)
 *  để biểu đồ có chế độ "Chi phí" riêng. */
export interface HourComparison {
  hour: number;
  curRevenue: number;
  curProfit: number;
  curExpense: number;
  prevRevenue: number;
  prevProfit: number;
  prevExpense: number;
}

/**
 * Gom đơn + chi phí vận hành theo GIỜ VN — hàm thuần (không chạm Firestore)
 * để test logic được mà không cần dữ liệu thật.
 * Quy tắc tiền giống hệt getDailyBreakdown (cách B: doanh thu loại phí ship
 * thu hộ; lợi nhuận món = line_total - phần giảm giá chia theo tỉ lệ -
 * cost_price/costNow; trừ chi phí vận hành isOperatingExpense, lọc kho).
 * Ngày + giờ của đơn lấy từ created_at theo giờ VN; ngày + giờ của khoản chi
 * lấy từ created_at theo giờ VN (giống getDailyBreakdown xếp ngày khoản chi
 * theo created_at). Đơn/khoản chi có ngày VN khác cả 2 ngày so sánh thì bỏ
 * qua — đó là giới hạn đã biết khi đơn bị sửa business_date khác ngày tạo
 * (xem BUILD-LOG v6.4): tổng 24 giờ khi đó có thể lệch tổng ngày của
 * getDailyBreakdown đúng bằng phần đơn bị sửa ngày đó.
 */
export function aggregateHourly(
  orders: Order[],
  expenses: Record<string, unknown>[],
  curDay: string,
  prevDay: string,
  costNow: Map<string, number>,
  warehouseIds?: string[] | null,
): HourComparison[] {
  const slots = new Map<string, { revenue: number; profit: number; expense: number }>();
  const slotOf = (day: string, hour: number) => {
    const key = `${day}|${hour}`;
    let s = slots.get(key);
    if (!s) { s = { revenue: 0, profit: 0, expense: 0 }; slots.set(key, s); }
    return s;
  };
  const itemCost = (it: { product_id: string; cost_price: number }) =>
    it.cost_price > 0 ? it.cost_price : (costNow.get(it.product_id) ?? 0);
  for (const o of orders) {
    if (o.status === 'cancelled' || !orderInScope(o, warehouseIds)) continue;
    const day = vnDateKeyOf(o.created_at);
    if (day !== curDay && day !== prevDay) continue;
    const slot = slotOf(day, vnHourOf(o.created_at));
    slot.revenue += o.total - Math.max(0, o.shipping_fee ?? 0);
    const subtotal = o.items.reduce((s, it) => s + it.line_total, 0);
    const discount = o.discount ?? 0;
    for (const it of o.items) {
      const share = subtotal > 0 ? (it.line_total / subtotal) * discount : 0;
      slot.profit += (it.line_total - share) - itemCost(it) * it.qty;
    }
  }
  for (const data of expenses) {
    if (!isOperatingExpense(data)) continue;
    const wid = typeof data.warehouse_id === 'string' ? data.warehouse_id : null;
    if (!cashbookInScope(wid, warehouseIds)) continue;
    const day = vnDateKeyOf(data.created_at);
    if (day !== curDay && day !== prevDay) continue;
    const slot = slotOf(day, vnHourOf(data.created_at));
    slot.profit -= Number(data.amount ?? 0);
    slot.expense += Number(data.amount ?? 0);
  }
  const out: HourComparison[] = [];
  for (let h = 0; h < 24; h++) {
    const cur = slots.get(`${curDay}|${h}`) ?? { revenue: 0, profit: 0, expense: 0 };
    const prev = slots.get(`${prevDay}|${h}`) ?? { revenue: 0, profit: 0, expense: 0 };
    out.push({ hour: h, curRevenue: cur.revenue, curProfit: cur.profit, curExpense: cur.expense, prevRevenue: prev.revenue, prevProfit: prev.profit, prevExpense: prev.expense });
  }
  return out;
}

/**
 * Doanh thu + lợi nhuận theo giờ của 2 ngày (ngày này so với ngày liền trước)
 * — dùng cho biểu đồ Tổng quan khi chọn kỳ 1 ngày. Đơn lấy qua
 * fetchOrdersInRange theo business_date trong [prevDay, curDay] (phân trang
 * toàn bộ, không cắt ngầm); chi phí vận hành phân trang toàn bộ như
 * getDailyBreakdown. Giờ tương lai trong ngày hôm nay tự nhiên = 0.
 */
export async function getHourlyBreakdown(
  curDay: string,
  prevDay: string,
  warehouseIds?: string[] | null,
): Promise<HourComparison[]> {
  const valid = /^\d{4}-\d{2}-\d{2}$/;
  if (!valid.test(curDay) || !valid.test(prevDay) || prevDay > curDay) {
    throw new DbError('invalid-argument', 'Khoảng ngày không hợp lệ.');
  }
  try {
    const [allOrders, costNow] = await Promise.all([
      fetchOrdersInRange(prevDay, curDay),
      loadCostMap(),
    ]);
    const expenses: Record<string, unknown>[] = [];
    let last: unknown = null;
    for (let page = 0; page < 200; page++) {
      const q =
        last == null
          ? query(
              collection(db, 'cashbook_entries'),
              where('type', '==', 'chi'),
              orderBy('__name__'),
              limit(500),
            )
          : query(
              collection(db, 'cashbook_entries'),
              where('type', '==', 'chi'),
              orderBy('__name__'),
              limit(500),
              startAfter(last as never),
            );
      const expSnap = await getDocs(q);
      if (expSnap.docs.length === 0) break;
      for (const d of expSnap.docs) expenses.push(d.data() as Record<string, unknown>);
      last = expSnap.docs[expSnap.docs.length - 1];
      if (expSnap.docs.length < 500) break;
    }
    return aggregateHourly(allOrders, expenses, curDay, prevDay, costNow, warehouseIds);
  } catch (e) {
    throw toDbError(e);
  }
}

/** Chi phí vận hành từng ngày trong khoảng — tách riêng khỏi getDailyBreakdown
 *  để biểu đồ có chế độ "Chi phí" riêng. Cùng quy tắc: isOperatingExpense
 *  (loại chuyển quỹ/nhập hàng/trả nợ NCC), lọc kho cashbookInScope, xếp ngày
 *  theo giờ VN của created_at (vnDateKeyOf). KHÔNG phải giá vốn, KHÔNG phải
 *  tổng tiền nhập hàng. Tổng các ngày = getExpensesTotal cùng khoảng. */
export interface DayExpense { date: string; expense: number }
export async function getDailyExpenses(
  start: string,
  end: string,
  warehouseIds?: string[] | null,
): Promise<DayExpense[]> {
  const valid = /^\d{4}-\d{2}-\d{2}$/;
  if (!valid.test(start) || !valid.test(end) || start > end) {
    throw new DbError('invalid-argument', 'Khoảng ngày không hợp lệ.');
  }
  try {
    const dayCount = Math.max(1, Math.round((new Date(end).getTime() - new Date(start).getTime()) / 86400000) + 1);
    const byDay = new Map<string, number>();
    for (let i = 0; i < dayCount; i++) byDay.set(addDaysVN(start, i), 0);
    let last: unknown = null;
    for (let page = 0; page < 200; page++) {
      const q =
        last == null
          ? query(
              collection(db, 'cashbook_entries'),
              where('type', '==', 'chi'),
              orderBy('__name__'),
              limit(500),
            )
          : query(
              collection(db, 'cashbook_entries'),
              where('type', '==', 'chi'),
              orderBy('__name__'),
              limit(500),
              startAfter(last as never),
            );
      const expSnap = await getDocs(q);
      if (expSnap.docs.length === 0) break;
      for (const d of expSnap.docs) {
        const data = d.data() as Record<string, unknown>;
        if (!isOperatingExpense(data)) continue;
        const wid = typeof data.warehouse_id === 'string' ? data.warehouse_id : null;
        if (!cashbookInScope(wid, warehouseIds)) continue;
        const day = vnDateKeyOf(data.created_at);
        if (byDay.has(day)) byDay.set(day, (byDay.get(day) ?? 0) + Number(data.amount ?? 0));
      }
      last = expSnap.docs[expSnap.docs.length - 1];
      if (expSnap.docs.length < 500) break;
    }
    const out: DayExpense[] = [];
    for (let i = 0; i < dayCount; i++) {
      const date = addDaysVN(start, i);
      out.push({ date, expense: byDay.get(date) ?? 0 });
    }
    return out;
  } catch (e) {
    throw toDbError(e);
  }
}

/** Tổng CHI PHÍ VẬN HÀNH (khoản 'chi' trong sổ quỹ) theo khoảng ngày — dùng để
 *  trừ vào lợi nhuận. Đã loại: chuyển quỹ nội bộ, nhập hàng, trả nợ NCC
 *  (isOperatingExpense); ngày xếp theo GIỜ VN (vnDateKeyOf) cho khớp Sổ Quỹ và
 *  business_date của đơn; quy tắc kho khớp orderInScope (cashbookInScope). */
export async function getExpensesTotal(start: string, end: string, warehouseIds?: string[] | null): Promise<number> {
  try {
    let total = 0;
    let last: unknown = null;
    for (let page = 0; page < 200; page++) {
      const q =
        last == null
          ? query(
              collection(db, 'cashbook_entries'),
              where('type', '==', 'chi'),
              orderBy('__name__'),
              limit(500),
            )
          : query(
              collection(db, 'cashbook_entries'),
              where('type', '==', 'chi'),
              orderBy('__name__'),
              limit(500),
              startAfter(last as never),
            );
      const snap = await getDocs(q);
      if (snap.docs.length === 0) break;
      for (const d of snap.docs) {
        const data = d.data() as Record<string, unknown>;
        if (!isOperatingExpense(data)) continue;
        const dayKey = vnDateKeyOf(data.created_at);
        if (dayKey < start || dayKey > end) continue;
        const wid = typeof data.warehouse_id === 'string' ? data.warehouse_id : null;
        if (!cashbookInScope(wid, warehouseIds)) continue;
        total += Number(data.amount ?? 0);
      }
      last = snap.docs[snap.docs.length - 1];
      if (snap.docs.length < 500) break;
    }
    return total;
  } catch (e) {
    throw toDbError(e);
  }
}

export async function getRangeReport(start: string, end: string, warehouseIds?: string[] | null): Promise<DailyReport> {
  const valid = /^\d{4}-\d{2}-\d{2}$/;
  if (!valid.test(start) || !valid.test(end) || start > end) {
    throw new DbError('invalid-argument', 'Khoảng ngày không hợp lệ.');
  }
  try {
    const [allFetched, costNow, expenses] = await Promise.all([
      fetchOrdersInRange(start, end),
      loadCostMap(),
      getExpensesTotal(start, end, warehouseIds),
    ]);
    const allOrders = allFetched.filter((o) => orderInScope(o, warehouseIds));
    const cancelled_count = allOrders.filter((o) => o.status === 'cancelled').length;
    const orders = allOrders.filter((o) => o.status !== 'cancelled');
    const report = buildDailyReport(orders, `${start}→${end}`, costNow, expenses);
    report.cancelled_count = cancelled_count;
    return report;
  } catch (e) {
    throw toDbError(e);
  }
}

/** Tổng số lượng đã bán theo món trong [start, end] (loại đơn hủy) — dùng cho
 *  sắp xếp "Bán chạy" ở màn Bán hàng. */
export async function getSoldQtyByProduct(start: string, end: string): Promise<Record<string, number>> {
  const orders = await fetchOrdersInRange(start, end);
  const out: Record<string, number> = {};
  for (const o of orders) {
    if (o.status === 'cancelled') continue;
    for (const it of o.items) {
      out[it.product_id] = (out[it.product_id] ?? 0) + it.qty;
    }
  }
  return out;
}

/** Khách đang nợ nhiều nhất (cho trợ lý AI hỏi-đáp số liệu). */
export async function getTopDebtors(limitN = 10): Promise<{ name: string; phone: string; debt: number }[]> {
  try {
    const snap = await getDocs(
      query(collection(db, 'customers'), where('debt', '>', 0), orderBy('debt', 'desc'), limit(limitN)),
    );
    return snap.docs.map((d) => {
      const c = toCustomer(d.id, d.data());
      return { name: c.name, phone: c.phone, debt: c.debt };
    });
  } catch (e) {
    throw toDbError(e);
  }
}

// ------------------------------------------------------------------ backup ---
const EXPORT_TABLES = [
  'categories',
  'products',
  'modifierGroups',
  'modifierOptions',
  'customers',
  'orders',
  'settings',
  'counters',
  'payment_methods',
  'ingredients',
  'stock_logs',
  'warehouses',
  'stock_levels',
  'users', // {id, email, full_name, role} — không chứa mật khẩu
  // Bổ sung v5.5: trước đây Sổ quỹ và nhiều bảng nghiệp vụ KHÔNG nằm trong bản
  // sao lưu — khôi phục xong là mất toàn bộ sổ quỹ/voucher/phiếu nhập...
  'cashbook_entries',
  'vouchers',
  'combos',
  'suppliers',
  'purchase_orders',
  'stock_exports',
  'production_orders',
  'online_orders',
  'day_closes',
  'managed_shops',
] as const;

function plainValue(v: unknown): unknown {
  if (v instanceof Timestamp) return v.toDate().toISOString();
  if (Array.isArray(v)) return v.map(plainValue);
  if (v && typeof v === 'object') {
    const out: Record<string, unknown> = {};
    for (const [k, val] of Object.entries(v)) out[k] = plainValue(val);
    return out;
  }
  return v;
}

export async function exportAllJson(): Promise<Record<string, unknown[]>> {
  try {
    const out: Record<string, unknown[]> = {};
    for (const t of EXPORT_TABLES) {
      // Phân trang theo document id — bản cũ limit(5000) khiến quán nhiều đơn
      // bị thiếu dữ liệu trong bản sao lưu mà không hề cảnh báo.
      const rows: unknown[] = [];
      let lastId: string | null = null;
      for (;;) {
        const q = lastId
          ? query(collection(db, t), orderBy(documentId()), startAfter(lastId), limit(1000))
          : query(collection(db, t), orderBy(documentId()), limit(1000));
        const snap: QuerySnapshot = await getDocs(q);
        for (const d of snap.docs) rows.push(plainValue({ id: d.id, ...d.data() }) as unknown);
        if (snap.docs.length < 1000) break;
        lastId = snap.docs[snap.docs.length - 1].id;
      }
      out[t] = rows;
    }
    // Lịch sử công nợ nằm ở subcollection customers/{id}/debt_logs — xuất kèm
    // dưới khóa riêng để khôi phục ghi lại đúng chỗ.
    const debtLogs: unknown[] = [];
    for (const c of out['customers'] ?? []) {
      const cid = String((c as Record<string, unknown>).id ?? '');
      if (!cid) continue;
      const snap = await getDocs(query(collection(db, 'customers', cid, 'debt_logs'), limit(1000)));
      for (const d of snap.docs) {
        debtLogs.push(plainValue({ id: d.id, customer_id: cid, ...d.data() }) as unknown);
      }
    }
    out['customers_debt_logs'] = debtLogs;
    return out;
  } catch (e) {
    throw toDbError(e);
  }
}

// Header CSV tiếng Việt — mirror backend routes/backup.js#CSV_HEADERS
const CSV_HEADERS: Record<'orders' | 'products' | 'customers' | 'categories' | 'payment_methods', [string, string][]> = {
  orders: [
    ['id', 'Mã nội bộ'], ['client_uuid', 'Mã chống trùng'], ['code', 'Mã đơn'],
    ['business_date', 'Ngày bán'], ['customer_id', 'Mã KH'], ['status', 'Trạng thái'],
    ['payment_method', 'Mã thanh toán'], ['payment_method_name', 'Thanh toán'], ['subtotal', 'Tạm tính (VND)'],
    ['discount', 'Giảm giá (VND)'], ['total', 'Tổng tiền (VND)'],
    ['amount_received', 'Tiền nhận (VND)'], ['change_amount', 'Tiền thừa (VND)'],
    ['note', 'Ghi chú'], ['created_by', 'Người tạo'], ['created_at', 'Thời gian tạo'],
  ],
  products: [
    ['id', 'Mã nội bộ'], ['name', 'Tên món'], ['category_id', 'Mã danh mục'],
    ['base_price', 'Giá bán (VND)'], ['cost_price', 'Giá vốn (VND)'], ['unit', 'Đơn vị'],
    ['image_url', 'Ảnh'],
    ['active', 'Đang bán'], ['sort_order', 'Thứ tự'], ['created_at', 'Ngày tạo'],
  ],
  customers: [
    ['id', 'Mã nội bộ'], ['name', 'Tên khách'], ['phone', 'Số điện thoại'],
    ['birthday', 'Ngày sinh'], ['address', 'Địa chỉ'], ['stamps', 'Số tem'],
    ['reward_available', 'Có thưởng'], ['debt', 'Công nợ (VND)'], ['note', 'Ghi chú'], ['created_at', 'Ngày tạo'],
  ],
  categories: [
    ['id', 'Mã nội bộ'], ['name', 'Tên danh mục'],
    ['sort_order', 'Thứ tự'], ['active', 'Đang dùng'],
  ],
  payment_methods: [
    ['id', 'Mã nội bộ'], ['name', 'Tên phương thức'], ['kind', 'Loại'],
    ['icon', 'Biểu tượng'], ['bank_bin', 'Mã BIN'], ['bank_account', 'Số tài khoản'],
    ['bank_account_name', 'Chủ tài khoản'], ['active', 'Đang dùng'], ['sort_order', 'Thứ tự'],
  ],
};

function csvCell(v: unknown): string {
  if (v === null || v === undefined) return '';
  const s = typeof v === 'object' ? JSON.stringify(v) : String(v);
  if (/[",\n\r]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

export async function exportTableCsv(
  table: 'orders' | 'products' | 'customers' | 'categories' | 'payment_methods',
): Promise<string> {
  const header = CSV_HEADERS[table];
  if (!header) throw new DbError('invalid-argument', `Bảng không hỗ trợ: ${table}.`);
  try {
    const snap = await getDocs(query(collection(db, table), limit(5000)));
    const lines = [header.map(([, label]) => csvCell(label)).join(',')];
    for (const d of snap.docs) {
      const data = d.data() as Record<string, unknown>;
      lines.push(
        header
          .map(([col]) => {
            if (col === 'id') return csvCell(d.id);
            if (col === 'created_at') {
              // products/categories seed không có created_at → để trống thay vì ngày hiện tại
              return data[col] == null ? '' : csvCell(tsToIso(data[col]));
            }
            return csvCell(data[col]);
          })
          .join(','),
      );
    }
    return '﻿' + lines.join('\r\n'); // BOM để Excel mở đúng tiếng Việt
  } catch (e) {
    throw toDbError(e);
  }
}

export function downloadFile(filename: string, content: string, mime: string): void {
  const blob = new Blob([content], { type: `${mime};charset=utf-8` });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

// ================= KHUYẾN MÃI (giờ vàng) =================
// Lưu ở settings/promotions { items: Promotion[] } — chỉ chủ quán sửa (rules settings).

function sanitizePromotion(p: unknown): Promotion | null {
  const o = p as Record<string, unknown>;
  if (!o || typeof o !== 'object') return null;
  const type = o.type === 'amount' ? 'amount' : 'percent';
  const value = Math.max(0, Math.round(Number(o.value) || 0));
  const hhmm = (v: unknown) =>
    typeof v === 'string' && /^\d{2}:\d{2}$/.test(v) ? v : '00:00';
  return {
    id: String(o.id ?? uuid()),
    name: String(o.name ?? 'Khuyến mãi').slice(0, 100),
    type,
    value: type === 'percent' ? Math.min(100, value) : value,
    start: hhmm(o.start),
    end: hhmm(o.end),
    active: o.active !== false,
  };
}

export async function getPromotions(): Promise<Promotion[]> {
  try {
    const snap = await getDoc(doc(db, 'settings', 'promotions'));
    const items = snap.exists() ? (snap.data() as Record<string, unknown>).items : [];
    return (Array.isArray(items) ? items : []).map(sanitizePromotion).filter((p): p is Promotion => !!p);
  } catch (e) {
    throw toDbError(e);
  }
}

export async function savePromotions(items: Promotion[]): Promise<void> {
  try {
    const clean = items.map(sanitizePromotion).filter((p): p is Promotion => !!p);
    await setDoc(doc(db, 'settings', 'promotions'), { items: clean }, { merge: true });
  } catch (e) {
    throw toDbError(e);
  }
}


// ================= VOUCHER / MÃ GIẢM GIÁ =================
// Doc id = mã chữ thường → tra cứu trực tiếp, chống trùng mã.

function voucherFromDoc(snap: QueryDocumentSnapshot | DocumentSnapshot): Voucher | null {
  if (!snap.exists()) return null;
  const d = snap.data() as Record<string, unknown>;
  const t = d.type === 'amount' ? 'amount' : 'percent';
  return {
    id: snap.id,
    code: String(d.code ?? snap.id).toUpperCase(),
    name: String(d.name ?? ''),
    type: t,
    value: Math.max(0, Number(d.value ?? 0)),
    max_discount: d.max_discount == null ? null : Math.max(0, Number(d.max_discount)),
    min_order: Math.max(0, Number(d.min_order ?? 0)),
    usage_limit: d.usage_limit == null ? null : Math.max(0, Number(d.usage_limit)),
    used_count: Math.max(0, Number(d.used_count ?? 0)),
    start_date: typeof d.start_date === 'string' && d.start_date ? d.start_date : null,
    end_date: typeof d.end_date === 'string' && d.end_date ? d.end_date : null,
    active: d.active !== false,
    created_at: tsToIso(d.created_at),
  };
}

export async function listVouchers(): Promise<Voucher[]> {
  try {
    const snap = await getDocs(query(collection(db, 'vouchers'), orderBy('created_at', 'desc'), limit(200)));
    return snap.docs.map(voucherFromDoc).filter((v): v is Voucher => !!v);
  } catch (e) {
    throw toDbError(e);
  }
}

export async function getVoucherByCode(code: string): Promise<Voucher | null> {
  const c = code.trim().toLowerCase();
  if (!c) return null;
  try {
    return voucherFromDoc(await getDoc(doc(db, 'vouchers', c)));
  } catch (e) {
    throw toDbError(e);
  }
}

export interface VoucherInput {
  code: string;
  name: string;
  type: 'percent' | 'amount';
  value: number;
  max_discount?: number | null;
  min_order?: number;
  usage_limit?: number | null;
  start_date?: string | null;
  end_date?: string | null;
  active?: boolean;
}

/** Tạo/sửa voucher — chỉ chủ quán. */
export async function saveVoucher(input: VoucherInput, oldId?: string): Promise<Voucher> {
  const code = input.code.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (!code) throw new DbError('invalid-argument', 'Mã voucher chỉ gồm chữ và số.');
  if (code.length > 20) throw new DbError('invalid-argument', 'Mã voucher tối đa 20 ký tự.');
  const id = code.toLowerCase();
  if (oldId && oldId !== id) await deleteDoc(doc(db, 'vouchers', oldId)); // đổi mã = tạo mới
  const payload = {
    id,
    code,
    name: input.name.trim().slice(0, 100) || code,
    type: input.type === 'amount' ? 'amount' : 'percent',
    value: Math.max(0, Math.round(Number(input.value) || 0)),
    max_discount: input.max_discount == null ? null : Math.max(0, Math.round(Number(input.max_discount))),
    min_order: Math.max(0, Math.round(Number(input.min_order) || 0)),
    usage_limit: input.usage_limit == null ? null : Math.max(0, Math.round(Number(input.usage_limit))),
    start_date: input.start_date || null,
    end_date: input.end_date || null,
    active: input.active !== false,
    created_at: serverTimestamp(),
  };
  try {
    const ref = doc(db, 'vouchers', id);
    const ex = await getDoc(ref);
    await setDoc(ref, ex.exists() ? { ...payload, created_at: ex.data()?.created_at ?? serverTimestamp() } : payload, { merge: true });
    // Giữ used_count khi sửa
    if (ex.exists()) await updateDoc(ref, { used_count: Number((ex.data() as Record<string, unknown>).used_count ?? 0) });
    logAudit('voucher.save', `Lưu voucher ${code}`, { type: 'voucher', id });
    const v = voucherFromDoc(await getDoc(ref));
    if (!v) throw new DbError('unknown', 'Không đọc được voucher vừa lưu.');
    return v;
  } catch (e) {
    throw toDbError(e);
  }
}

export async function deleteVoucher(id: string): Promise<void> {
  try {
    const snap = await getDoc(doc(db, 'vouchers', id));
    const code = snap.exists() ? String((snap.data() as Record<string, unknown>).code ?? id) : id;
    await deleteDoc(doc(db, 'vouchers', id));
    logAudit('voucher.delete', `Xóa voucher ${code}`, { type: 'voucher', id });
  } catch (e) {
    throw toDbError(e);
  }
}

/** Kiểm tra voucher có dùng được cho đơn subtotal tại ngày dateYMD không. Trả về lỗi hoặc null. */
export function validateVoucher(v: Voucher, subtotal: number, dateYMD: string): string | null {
  if (!v.active) return 'Voucher này đã bị tắt.';
  if (v.start_date && dateYMD < v.start_date) return `Voucher có hiệu lực từ ${v.start_date}.`;
  if (v.end_date && dateYMD > v.end_date) return 'Voucher đã hết hạn.';
  if (v.usage_limit != null && v.used_count >= v.usage_limit) return 'Voucher đã hết lượt sử dụng.';
  if (subtotal < v.min_order) return `Đơn tối thiểu ${v.min_order.toLocaleString('vi-VN')}đ để dùng voucher này.`;
  return null;
}

/** Tiền giảm từ voucher (không vượt subtotal; percent có thể bị trần max_discount). */
export function calcVoucherDiscount(subtotal: number, v: Voucher): number {
  const st = Math.max(0, Math.round(Number(subtotal) || 0));
  if (st <= 0) return 0;
  let d = v.type === 'percent' ? Math.round((st * Math.min(100, v.value)) / 100) : Math.round(v.value);
  if (v.type === 'percent' && v.max_discount != null) d = Math.min(d, v.max_discount);
  return Math.min(d, st);
}

/** Khuyến mãi đang diễn ra tại thời điểm hiện tại (giờ VN). */
export function findActivePromotion(promos: Promotion[], now = new Date()): Promotion | null {
  const hh = String(now.getHours()).padStart(2, '0');
  const mm = String(now.getMinutes()).padStart(2, '0');
  const cur = `${hh}:${mm}`;
  for (const p of promos) {
    if (!p.active || !p.value) continue;
    if (p.start <= p.end ? cur >= p.start && cur <= p.end : cur >= p.start || cur <= p.end) {
      return p;
    }
  }
  return null;
}

// ================= NHẬT KÝ THAO TÁC =================

/**
 * Ghi nhật ký thao tác — fire-and-forget, không throw để không chặn nghiệp vụ chính.
 */
export function logAudit(
  action: string,
  detail?: string | null,
  target?: { type?: string | null; id?: string | null } | null,
): void {
  try {
    const u = auth.currentUser;
    const ref = doc(collection(db, 'audit_logs'));
    void setDoc(ref, {
      id: ref.id,
      action: String(action).slice(0, 60),
      actor_id: u?.uid ?? null,
      actor_name: u?.displayName ?? u?.email ?? null,
      target_type: target?.type ?? null,
      target_id: target?.id ?? null,
      detail: typeof detail === 'string' ? detail.slice(0, 500) : null,
      created_at: serverTimestamp(),
    }).catch(() => {});
  } catch {
    /* bỏ qua */
  }
}

function auditFromDoc(snap: QueryDocumentSnapshot): AuditLog {
  const d = snap.data() as Record<string, unknown>;
  return {
    id: snap.id,
    action: String(d.action ?? ''),
    actor_id: (d.actor_id as string | null) ?? null,
    actor_name: (d.actor_name as string | null) ?? null,
    target_type: (d.target_type as string | null) ?? null,
    target_id: (d.target_id as string | null) ?? null,
    detail: (d.detail as string | null) ?? null,
    created_at: tsToIso(d.created_at),
  };
}

/** Nhãn hiển thị cho từng loại thao tác trong nhật ký. */
export const AUDIT_LABELS: Record<string, string> = {
  'order.delete': '🗑️ Xóa đơn hàng',
  'order.edit': '✏️ Sửa đơn hàng',
  'product.price': '💲 Đổi giá món',
  'product.update': '📋 Sửa món',
  'product.delete': '🗑️ Xóa món',
  'staff.role': '👤 Đổi vai trò nhân viên',
  'staff.warehouse': '🗃️ Gán kho nhân viên',
  'promo.save': '🎁 Lưu khuyến mãi',
  'voucher.save': '🎟️ Lưu voucher',
  'voucher.delete': '🎟️ Xóa voucher',
  'order.online': '🌐 Đơn đặt online',
  'supplier.save': '🏭 Lưu NCC',
  'supplier.delete': '🏭 Xóa NCC',
  'supplier.pay': '🏭 Trả nợ NCC',
  'purchase.create': '📥 Nhập hàng',
  'stock_export.create': '📤 Xuất kho',
  'purchase.delete': '🗑️ Xóa phiếu nhập',
  'stock_export.delete': '🗑️ Xóa phiếu xuất',
  'stock.check': '📦 Kiểm kho',
  'product.stock_tracking': '📦 Tồn kho món',
  'settings.stock_reasons': '📦 Lý do nhập/xuất',
  'combo.save': '🍱 Lưu combo',
  'combo.delete': '🍱 Xóa combo',
  'day.close': '🌙 Chốt ngày',
  'cashbook.delete': '🧾 Xóa khoản thu/chi',
};

export async function listAuditLogs(limitN = 100): Promise<AuditLog[]> {
  const n = Math.min(Math.max(limitN, 1), 500);
  try {
    const snap = await getDocs(query(collection(db, 'audit_logs'), orderBy('created_at', 'desc'), limit(n)));
    return snap.docs.map(auditFromDoc);
  } catch (e) {
    throw toDbError(e);
  }
}

// ================= ĐỐI SOÁT CUỐI NGÀY (Z-REPORT) =================

function dayCloseFromDoc(snap: DocumentSnapshot): DayClose | null {
  if (!snap.exists()) return null;
  const d = snap.data() as Record<string, unknown>;
  return {
    id: snap.id,
    business_date: String(d.business_date ?? snap.id),
    closed_at: tsToIso(d.closed_at),
    closed_by: (d.closed_by as string | null) ?? null,
    closed_by_name: (d.closed_by_name as string | null) ?? null,
    revenue: Number(d.revenue ?? 0),
    orders_count: Number(d.orders_count ?? 0),
    discount_total: Number(d.discount_total ?? 0),
    by_method: Array.isArray(d.by_method)
      ? (d.by_method as Record<string, unknown>[]).map((m) => ({
          method_id: String(m.method_id ?? ''),
          name: String(m.name ?? ''),
          kind: (m.kind as DayClose['by_method'][number]['kind']) ?? 'cash',
          amount: Number(m.amount ?? 0),
          count: Number(m.count ?? 0),
        }))
      : [],
    cash_expected: Number(d.cash_expected ?? 0),
    cash_actual: Number(d.cash_actual ?? 0),
    cash_diff: Number(d.cash_diff ?? 0),
    cash_denoms:
      d.cash_denoms && typeof d.cash_denoms === 'object'
        ? Object.fromEntries(
            Object.entries(d.cash_denoms as Record<string, unknown>)
              .filter(([k, v]) => /^\d+$/.test(k) && Number(v) > 0)
              .map(([k, v]) => [k, Math.round(Number(v))]),
          )
        : null,
    funds: Array.isArray(d.funds)
      ? (d.funds as Record<string, unknown>[]).map((m) => ({
          fund_id: String(m.fund_id ?? ''),
          name: String(m.name ?? ''),
          expected: Number(m.expected ?? 0),
          actual: Number(m.actual ?? 0),
          diff: Number(m.diff ?? 0),
        }))
      : undefined,
    total_expected: d.total_expected != null ? Number(d.total_expected) : undefined,
    total_actual: d.total_actual != null ? Number(d.total_actual) : undefined,
    total_diff: d.total_diff != null ? Number(d.total_diff) : undefined,
    note: (d.note as string | null) ?? null,
  };
}

export async function getDayClose(date: string): Promise<DayClose | null> {
  try {
    // Tương thích phiếu cũ (doc id = ngày) + phiếu mới (auto-id)
    const oldDoc = await getDoc(doc(db, 'day_closes', date));
    const oldOne = dayCloseFromDoc(oldDoc);
    const list = await listDayCloses(date);
    const all = [...list];
    if (oldOne && !all.some((x) => x.id === oldOne.id)) all.push(oldOne);
    if (all.length === 0) return null;
    // Trả về lần chốt mới nhất
    all.sort((a, b) => (b.closed_at > a.closed_at ? 1 : b.closed_at < a.closed_at ? -1 : 0));
    return all[0];
  } catch (e) {
    throw toDbError(e);
  }
}

export interface DayCloseInput {
  business_date: string;
  revenue: number;
  orders_count: number;
  discount_total: number;
  by_method: DayClose['by_method'];
  cash_expected: number;
  cash_actual: number;
  cash_denoms?: Record<string, number> | null;
  funds?: DayClose['funds'];
  total_expected?: number;
  total_actual?: number;
  total_diff?: number;
  note?: string | null;
}

/** Chốt két — cho phép chốt nhiều lần trong 1 ngày (mỗi lần 1 document riêng). */
export async function saveDayClose(input: DayCloseInput): Promise<DayClose> {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(input.business_date)) {
    throw new DbError('invalid-argument', 'Ngày không hợp lệ.');
  }
  try {
    const ref = doc(collection(db, 'day_closes'));
    const u = auth.currentUser;
    const cashActual = Math.max(0, Math.round(Number(input.cash_actual) || 0));
    const cashExpected = Math.max(0, Math.round(Number(input.cash_expected) || 0));
    const funds = Array.isArray(input.funds)
      ? input.funds.map((m) => ({
          fund_id: String(m?.fund_id ?? ''),
          name: String(m?.name ?? ''),
          expected: Math.round(Number(m?.expected ?? 0)),
          actual: Math.max(0, Math.round(Number(m?.actual ?? 0))),
          diff: Math.max(0, Math.round(Number(m?.actual ?? 0))) - Math.round(Number(m?.expected ?? 0)),
        }))
      : undefined;
    const payload = {
      id: ref.id,
      business_date: input.business_date,
      closed_at: serverTimestamp(),
      closed_by: u?.uid ?? null,
      closed_by_name: u?.displayName ?? u?.email ?? null,
      revenue: Math.max(0, Math.round(Number(input.revenue) || 0)),
      orders_count: Math.max(0, Math.round(Number(input.orders_count) || 0)),
      discount_total: Math.max(0, Math.round(Number(input.discount_total) || 0)),
      by_method: input.by_method,
      cash_expected: cashExpected,
      cash_actual: cashActual,
      cash_diff: cashActual - cashExpected,
      cash_denoms: input.cash_denoms ?? null,
      funds: funds ?? null,
      total_expected: funds ? funds.reduce((s, m) => s + m.expected, 0) : (input.total_expected ?? null),
      total_actual: funds ? funds.reduce((s, m) => s + m.actual, 0) : (input.total_actual ?? null),
      total_diff: funds
        ? funds.reduce((s, m) => s + m.diff, 0)
        : (input.total_diff ?? null),
      note: typeof input.note === 'string' && input.note.trim() ? input.note.trim().slice(0, 500) : null,
    };
    await setDoc(ref, payload);
    logAudit('day.close', `Chốt ngày ${input.business_date}: tổng thực ${(payload.total_actual ?? cashActual).toLocaleString('vi-VN')}đ, chênh ${(payload.total_diff ?? payload.cash_diff).toLocaleString('vi-VN')}đ`, {
      type: 'day_close',
      id: ref.id,
    });
    const saved = await getDoc(ref);
    const dc = dayCloseFromDoc(saved);
    if (!dc) throw new DbError('unknown', 'Không đọc được phiếu chốt vừa tạo.');
    return dc;
  } catch (e) {
    throw toDbError(e);
  }
}

/** Danh sách các lần chốt két trong 1 ngày — mới nhất trước. */
export async function listDayCloses(businessDate: string): Promise<DayClose[]> {
  try {
    const snap = await getDocs(
      query(collection(db, 'day_closes'), where('business_date', '==', businessDate), limit(100)),
    );
    const list = snap.docs.map((d) => dayCloseFromDoc(d)).filter((x): x is DayClose => !!x);
    list.sort((a, b) => (b.closed_at > a.closed_at ? 1 : b.closed_at < a.closed_at ? -1 : 0));
    return list;
  } catch (e) {
    throw toDbError(e);
  }
}

/** Sửa 1 lần chốt két (chỉ chủ quán): tiền thực tế, kiểm tiền, ghi chú. */
export async function updateDayClose(
  id: string,
  patch: { cash_actual?: number; cash_denoms?: Record<string, number> | null; note?: string | null; funds?: DayClose['funds']; total_expected?: number; total_actual?: number; total_diff?: number },
): Promise<void> {
  const eid = String(id ?? '').trim();
  if (!eid) throw new DbError('invalid-argument', 'Thiếu id phiếu chốt.');
  try {
    const ref = doc(db, 'day_closes', eid);
    const snap = await getDoc(ref);
    if (!snap.exists()) throw new DbError('not-found', 'Không tìm thấy phiếu chốt.');
    const data: Record<string, unknown> = {};
    if (patch.cash_actual !== undefined) {
      const actual = Math.max(0, Math.round(Number(patch.cash_actual) || 0));
      const expected = Number((snap.data() as Record<string, unknown>).cash_expected ?? 0);
      data.cash_actual = actual;
      data.cash_diff = actual - expected;
    }
    if (patch.funds !== undefined) {
      const funds = patch.funds.map((m) => ({
        fund_id: String(m?.fund_id ?? ''),
        name: String(m?.name ?? ''),
        expected: Math.round(Number(m?.expected ?? 0)),
        actual: Math.max(0, Math.round(Number(m?.actual ?? 0))),
        diff: Math.max(0, Math.round(Number(m?.actual ?? 0))) - Math.round(Number(m?.expected ?? 0)),
      }));
      data.funds = funds;
      data.total_expected = funds.reduce((s, m) => s + m.expected, 0);
      data.total_actual = funds.reduce((s, m) => s + m.actual, 0);
      data.total_diff = funds.reduce((s, m) => s + m.diff, 0);
    } else {
      if (patch.total_expected !== undefined) data.total_expected = patch.total_expected;
      if (patch.total_actual !== undefined) data.total_actual = patch.total_actual;
      if (patch.total_diff !== undefined) data.total_diff = patch.total_diff;
    }
    if (patch.cash_denoms !== undefined) data.cash_denoms = patch.cash_denoms;
    if (patch.note !== undefined) {
      data.note = typeof patch.note === 'string' && patch.note.trim() ? patch.note.trim().slice(0, 500) : null;
    }
    if (Object.keys(data).length === 0) return;
    await updateDoc(ref, data);
    logAudit('day.close.update', `Sửa phiếu chốt két ${eid}`, { type: 'day_close', id: eid });
  } catch (e) {
    throw toDbError(e);
  }
}

/** Xóa 1 lần chốt két (chỉ chủ quán). */
export async function deleteDayClose(id: string): Promise<void> {
  const eid = String(id ?? '').trim();
  if (!eid) throw new DbError('invalid-argument', 'Thiếu id phiếu chốt.');
  try {
    const ref = doc(db, 'day_closes', eid);
    const snap = await getDoc(ref);
    if (!snap.exists()) throw new DbError('not-found', 'Không tìm thấy phiếu chốt.');
    await deleteDoc(ref);
    logAudit('day.close.delete', `Xóa phiếu chốt két ${eid}`, { type: 'day_close', id: eid });
  } catch (e) {
    throw toDbError(e);
  }
}

// ================= GIÁ VỐN TỰ ĐỘNG =================

/** Giá nhập bình quân của các nguyên liệu tại 1 kho — dùng để tính giá vốn món. */
export async function getIngredientAvgCosts(warehouseId: string): Promise<Map<string, number>> {
  const map = new Map<string, number>();
  try {
    const snap = await getDocs(query(collection(db, 'stock_levels'), where('warehouse_id', '==', warehouseId)));
    for (const d of snap.docs) {
      const data = d.data() as Record<string, unknown>;
      const cost = Number(data.avg_cost ?? 0);
      if (cost > 0) map.set(String(data.ingredient_id ?? ''), cost);
    }
    return map;
  } catch (e) {
    throw toDbError(e);
  }
}

// ================= XUẤT BÁO CÁO CSV =================

/** Xuất chi tiết đơn trong khoảng ngày ra CSV (mở được bằng Excel). */
export async function exportOrdersCsv(start: string, end: string, warehouseIds?: string[] | null): Promise<string> {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(start) || !/^\d{4}-\d{2}-\d{2}$/.test(end)) {
    throw new DbError('invalid-argument', 'Khoảng ngày không hợp lệ.');
  }
  try {
    const allOrders = await fetchOrdersInRange(start, end);
    const lines = [
      ['Mã đơn', 'Ngày', 'Giờ', 'Khách hàng', 'Phương thức', 'Kho', 'Tạm tính', 'Giảm giá', 'Tổng tiền', 'Ghi chú', 'Món (SL x Đơn giá)']
        .map(csvCell)
        .join(','),
    ];
    for (const o of allOrders) {
      // Đơn hủy không tính vào doanh thu — xuất Excel cũng phải loại như báo cáo
      if (o.status === 'cancelled') continue;
      if (!orderInScope(o, warehouseIds)) continue;
      const dt = new Date(o.created_at);
      const time = `${String(dt.getHours()).padStart(2, '0')}:${String(dt.getMinutes()).padStart(2, '0')}`;
      const itemsTxt = o.items
        .map((it) => `${it.product_name} (${it.qty} x ${it.unit_price})`)
        .join('; ');
      lines.push(
        [
          o.code,
          o.business_date,
          time,
          '',
          o.payment_method_name ?? o.payment_method,
          o.warehouse_name ?? '',
          o.subtotal,
          o.discount,
          o.total,
          o.note ?? '',
          itemsTxt,
        ]
          .map(csvCell)
          .join(','),
      );
    }
    return '﻿' + lines.join('\r\n');
  } catch (e) {
    throw toDbError(e);
  }
}

/** Tổng tiền giảm giá + doanh thu chi tiết 1 ngày — dùng cho đối soát cuối ngày. */
export async function getDaySummary(date: string, warehouseIds?: string[] | null): Promise<{ revenue: number; orders_count: number; discount_total: number }> {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new DbError('invalid-argument', 'Ngày không hợp lệ.');
  try {
    const snap = await getDocs(
      query(collection(db, 'orders'), where('business_date', '==', date), limit(1000)),
    );
    let revenue = 0;
    let discount = 0;
    let count = 0;
    for (const d of snap.docs) {
      const o = orderFromDoc(d);
      if (!o || o.status === 'cancelled') continue;
      if (!orderInScope(o, warehouseIds)) continue;
      // DayClose hien so nay o dong "Doanh thu ngay" nen cung loai phi ship
      // (cach B). Tien mat trong ket van doi chieu qua by_payment cua
      // getRangeReport, von gom ca ship thu ho, nen khong lech ket.
      revenue += o.total - Math.max(0, o.shipping_fee ?? 0);
      discount += o.discount;
      count += 1;
    }
    return { revenue, orders_count: count, discount_total: discount };
  } catch (e) {
    throw toDbError(e);
  }
}

/* ============================================================================
 * CÔNG CỤ RÀ SOÁT & TÍNH LẠI QUỸ TỪ ĐẦU
 * Dùng khi dữ liệu sổ quỹ bị lệch do các lỗi cũ (sửa đơn sai ngày, xóa sót, v.v.)
 * ========================================================================== */

export interface FundIssue {
  kind:
    | 'orphan_order_entry' // khoản của đơn không tồn tại → xóa
    | 'cancelled_order_entry' // khoản của đơn đã hủy → xóa
    | 'date_mismatch' // khoản sai ngày so với đơn → sửa ngày
    | 'amount_mismatch' // khoản sai số tiền so với đơn → sửa số tiền
    | 'missing_entry' // đơn thiếu khoản quỹ → tạo mới
    | 'orphan_transfer' // chuyển quỹ lẻ 1 vế → xóa
    | 'timestamp_date' // created_at dạng Timestamp → chuyển sang chuỗi ISO
    | 'duplicate_entry'; // khoản trùng lặp → xóa bản trùng
  entryId: string;
  fundId: string;
  amount: number;
  entryDate: string; // YYYY-MM-DD (giờ VN)
  orderId?: string;
  orderCode?: string;
  expectedAmount?: number;
  expectedDate?: string;
  description: string;
}

/** YYYY-MM-DD theo giờ VN từ ISO string hoặc Timestamp. */
function vnDateKeyLocal(iso: string): string {
  try {
    return new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Ho_Chi_Minh',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    }).format(new Date(iso));
  } catch {
    return '';
  }
}

/** Tải TOÀN BỘ cashbook entries (phân trang, không giới hạn 500). */
async function listAllCashbookEntriesRaw(): Promise<Array<{ id: string; d: Record<string, unknown> }>> {
  const out: Array<{ id: string; d: Record<string, unknown> }> = [];
  let last: unknown = null;
  for (let page = 0; page < 100; page++) {
    const q =
      last == null
        ? query(collection(db, 'cashbook_entries'), orderBy('created_at', 'desc'), limit(500))
        : query(
            collection(db, 'cashbook_entries'),
            orderBy('created_at', 'desc'),
            limit(500),
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            startAfter(last as unknown),
          );
    const snap = await getDocs(q);
    if (snap.docs.length === 0) break;
    for (const docSnap of snap.docs) {
      out.push({ id: docSnap.id, d: docSnap.data() as Record<string, unknown> });
    }
    last = snap.docs[snap.docs.length - 1];
    if (snap.docs.length < 500) break;
  }
  return out;
}

/** Tải TOÀN BỘ orders (phân trang). */
async function listAllOrdersRaw(): Promise<Order[]> {
  const out: Order[] = [];
  let last: unknown = null;
  for (let page = 0; page < 100; page++) {
    const q =
      last == null
        ? query(collection(db, 'orders'), orderBy('created_at', 'desc'), limit(500))
        : query(
            collection(db, 'orders'),
            orderBy('created_at', 'desc'),
            limit(500),
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            startAfter(last as unknown),
          );
    const snap = await getDocs(q);
    if (snap.docs.length === 0) break;
    for (const docSnap of snap.docs) {
      const o = orderFromDoc(docSnap);
      if (o) out.push(o);
    }
    last = snap.docs[snap.docs.length - 1];
    if (snap.docs.length < 500) break;
  }
  return out;
}

/**
 * Rà soát toàn bộ sổ quỹ, phát hiện các lệch lạc so với chứng từ gốc.
 * - Đơn đã xóa/hủy nhưng khoản quỹ còn → đề xuất xóa
 * - Khoản quỹ sai ngày/sai số tiền so với đơn → đề xuất sửa
 * - Đơn thiếu khoản quỹ → đề xuất tạo
 * - Chuyển quỹ lẻ 1 vế → đề xuất xóa
 */
export async function scanFundIssues(): Promise<FundIssue[]> {
  try {
    const [rawEntries, orders] = await Promise.all([listAllCashbookEntriesRaw(), listAllOrdersRaw()]);
    const issues: FundIssue[] = [];
    const orderById = new Map(orders.map((o) => [o.id, o]));

    // Nhóm entries theo ref_id để phát hiện trùng
    const entriesByRefId = new Map<string, Array<{ id: string; d: Record<string, unknown> }>>();
    for (const e of rawEntries) {
      const refId = typeof e.d.ref_id === 'string' ? e.d.ref_id : '';
      if (!entriesByRefId.has(refId)) entriesByRefId.set(refId, []);
      entriesByRefId.get(refId)!.push(e);
    }

    // 1. Kiểm tra từng khoản có ref_type='order' (đọc thô từ Firestore)
    for (const e of rawEntries) {
      const rt = e.d.ref_type;
      if (rt !== 'order') continue;
      const refId = typeof e.d.ref_id === 'string' ? e.d.ref_id : '';
      const order = orderById.get(refId);
      const amount = Number(e.d.amount ?? 0);
      const fundId = String(e.d.fund_id ?? '');
      const entryDate = vnDateKeyLocal(tsToIso(e.d.created_at));

      if (!order) {
        issues.push({
          kind: 'orphan_order_entry',
          entryId: e.id,
          fundId,
          amount,
          entryDate,
          orderId: refId,
          description: `Khoản mồ côi: đơn ${refId.slice(0, 8)}… không tồn tại (đã xóa)`,
        });
        continue;
      }
      if (order.status === 'cancelled') {
        issues.push({
          kind: 'cancelled_order_entry',
          entryId: e.id,
          fundId,
          amount,
          entryDate,
          orderId: order.id,
          orderCode: order.code,
          description: `Khoản của đơn ${order.code} đã hủy nhưng vẫn còn trong quỹ`,
        });
        continue;
      }
      // Tính số tiền kỳ vọng từ splits (dùng hàm chuẩn)
      const orderDate = vnDateKeyLocal(order.created_at);

      // Kiểm tra ngày
      if (entryDate && orderDate && entryDate !== orderDate) {
        issues.push({
          kind: 'date_mismatch',
          entryId: e.id,
          fundId,
          amount,
          entryDate,
          orderId: order.id,
          orderCode: order.code,
          expectedDate: orderDate,
          description: `Khoản đơn ${order.code} sai ngày: đang ở ${entryDate}, đúng phải ${orderDate}`,
        });
      }
    }

    // 2. Kiểm tra đơn thiếu khoản quỹ (đơn còn hiệu lực, có thu tiền, nhưng không có entry)
    for (const order of orders) {
      if (order.status === 'cancelled') continue;
      const paidSplits = orderPaymentSplits(order).filter(
        (p) => p.kind === 'cash' || p.kind === 'transfer',
      );
      if (paidSplits.length === 0) continue; // đơn ghi nợ toàn phần → không có khoản quỹ là đúng
      const entries = (entriesByRefId.get(order.id) ?? []).filter((e) => e.d.ref_type === 'order');
      const entryTotal = entries.reduce((s, e) => s + Number(e.d.amount ?? 0), 0);
      const expectedTotal = paidSplits.reduce((s, p) => s + Number(p.amount ?? 0), 0);
      if (entries.length === 0) {
        issues.push({
          kind: 'missing_entry',
          entryId: '',
          fundId: String(paidSplits[0].method_id),
          amount: 0,
          entryDate: vnDateKeyLocal(order.created_at),
          orderId: order.id,
          orderCode: order.code,
          expectedAmount: expectedTotal,
          expectedDate: vnDateKeyLocal(order.created_at),
          description: `Đơn ${order.code} thiếu khoản quỹ (phải có ${expectedTotal.toLocaleString('vi-VN')}đ)`,
        });
      } else if (Math.abs(entryTotal - expectedTotal) > 0.5) {
        issues.push({
          kind: 'amount_mismatch',
          entryId: entries[0].id,
          fundId: String(entries[0].d.fund_id ?? ''),
          amount: entryTotal,
          entryDate: vnDateKeyLocal(tsToIso(entries[0].d.created_at)),
          orderId: order.id,
          orderCode: order.code,
          expectedAmount: expectedTotal,
          description: `Khoản đơn ${order.code} sai số tiền: đang ${entryTotal.toLocaleString('vi-VN')}đ, đúng phải ${expectedTotal.toLocaleString('vi-VN')}đ`,
        });
      }
    }

    // 3. Kiểm tra chuyển quỹ lẻ 1 vế
    for (const e of rawEntries) {
      if (e.d.ref_type !== 'transfer') continue;
      const refId = typeof e.d.ref_id === 'string' ? e.d.ref_id : '';
      if (!refId) continue;
      const pair = rawEntries.find((x) => x.id === refId && x.d.ref_type === 'transfer');
      if (!pair) {
        issues.push({
          kind: 'orphan_transfer',
          entryId: e.id,
          fundId: String(e.d.fund_id ?? ''),
          amount: Number(e.d.amount ?? 0),
          entryDate: vnDateKeyLocal(tsToIso(e.d.created_at)),
          description: `Chuyển quỹ lẻ 1 vế (${Number(e.d.amount ?? 0).toLocaleString('vi-VN')}đ) — mất cặp đối ứng`,
        });
      }
    }

    // 4. Phát hiện created_at dạng Timestamp (cần chuyển sang chuỗi ISO để query đúng)
    for (const e of rawEntries) {
      const ca = e.d.created_at;
      // Timestamp có method toDate(); chuỗi thì không
      if (ca && typeof ca === 'object' && typeof (ca as { toDate?: unknown }).toDate === 'function') {
        issues.push({
          kind: 'timestamp_date',
          entryId: e.id,
          fundId: String(e.d.fund_id ?? ''),
          amount: Number(e.d.amount ?? 0),
          entryDate: vnDateKeyLocal(tsToIso(ca)),
          description: `Khoản "${String(e.d.note ?? '').slice(0, 30)}" đang lưu ngày dạng Timestamp — cần chuẩn hóa`,
        });
      }
    }

    return issues;
  } catch (e) {
    throw toDbError(e);
  }
}

/**
 * Áp dụng sửa các lỗi đã rà soát. Mỗi thao tác ghi nhật ký.
 * Trả về số lượng đã sửa và lỗi (nếu có).
 */
export async function repairFundIssues(issues: FundIssue[]): Promise<{ fixed: number; errors: string[] }> {
  let fixed = 0;
  const errors: string[] = [];
  try {
    for (const issue of issues) {
      try {
        const batch = writeBatch(db);
        if (issue.kind === 'orphan_order_entry' || issue.kind === 'cancelled_order_entry' || issue.kind === 'orphan_transfer') {
          batch.delete(doc(db, 'cashbook_entries', issue.entryId));
          logAudit('fund.repair', `Xóa khoản lệch: ${issue.description}`, { type: 'cashbook_entry', id: issue.entryId });
        } else if (issue.kind === 'date_mismatch' && issue.expectedDate) {
          // Đổi created_at về đúng ngày của đơn (giữ nguyên giờ)
          const snap = await getDoc(doc(db, 'cashbook_entries', issue.entryId));
          if (snap.exists()) {
            const oldIso = tsToIso((snap.data() as Record<string, unknown>).created_at);
            const oldD = new Date(oldIso);
            // Giữ giờ VN của khoản gốc, đổi ngày về đúng ngày đơn
            const vnOffset = 7 * 60;
            const localMinutes = oldD.getUTCHours() * 60 + oldD.getUTCMinutes() + vnOffset;
            const hh = String(Math.floor(localMinutes / 60) % 24).padStart(2, '0');
            const mm = String(localMinutes % 60).padStart(2, '0');
            const newIso = new Date(`${issue.expectedDate}T${hh}:${mm}:00+07:00`).toISOString();
            batch.update(doc(db, 'cashbook_entries', issue.entryId), { created_at: newIso });
            logAudit('fund.repair', `Sửa ngày khoản: ${issue.description}`, { type: 'cashbook_entry', id: issue.entryId });
          }
        } else if (issue.kind === 'amount_mismatch' && issue.expectedAmount != null) {
          batch.update(doc(db, 'cashbook_entries', issue.entryId), { amount: Math.round(issue.expectedAmount) });
          logAudit('fund.repair', `Sửa số tiền khoản: ${issue.description}`, { type: 'cashbook_entry', id: issue.entryId });
        } else if (issue.kind === 'timestamp_date') {
          // Chuyển created_at từ Timestamp sang chuỗi ISO
          const snap = await getDoc(doc(db, 'cashbook_entries', issue.entryId));
          if (snap.exists()) {
            const ca = (snap.data() as Record<string, unknown>).created_at;
            const iso = tsToIso(ca);
            batch.update(doc(db, 'cashbook_entries', issue.entryId), { created_at: iso });
            logAudit('fund.repair', `Chuẩn hóa ngày khoản: ${issue.description}`, { type: 'cashbook_entry', id: issue.entryId });
          }
        } else if (issue.kind === 'missing_entry' && issue.orderId && issue.expectedAmount != null) {
          const newRef = doc(collection(db, 'cashbook_entries'));
          const createdAt = issue.expectedDate
            ? new Date(`${issue.expectedDate}T12:00:00+07:00`).toISOString()
            : serverTimestamp();
          batch.set(newRef, {
            id: newRef.id,
            type: 'thu',
            amount: Math.round(issue.expectedAmount),
            note: 'Doanh thu bán hàng',
            category: 'Bán hàng',
            fund_id: issue.fundId,
            ref_type: 'order',
            ref_id: issue.orderId,
            ref_code: issue.orderCode ?? null,
            method: 'cash',
            warehouse_id: null,
            created_by: auth.currentUser?.uid ?? null,
            created_at: createdAt,
          });
          logAudit('fund.repair', `Tạo khoản quỹ còn thiếu: ${issue.description}`, { type: 'cashbook_entry', id: newRef.id });
        } else {
          continue;
        }
        await batch.commit();
        fixed += 1;
      } catch (e) {
        errors.push(`${issue.description}: ${e instanceof Error ? e.message : 'lỗi'}`);
      }
    }
    return { fixed, errors };
  } catch (e) {
    throw toDbError(e);
  }
}

/**
 * Xuất sổ quỹ ra CSV (mở được bằng Excel) để đối chiếu.
 * Xuất TOÀN BỘ khoản trong khoảng ngày (không giới hạn 500).
 */
export async function exportCashbookCsv(
  start: string,
  end: string,
  fundId: string | 'all',
  warehouseIds: string[],
  typeFilter: 'all' | 'thu' | 'chi' = 'all',
  catFilter: string[] = [],
): Promise<string> {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(start) || !/^\d{4}-\d{2}-\d{2}$/.test(end)) {
    throw new DbError('invalid-argument', 'Khoảng ngày không hợp lệ.');
  }
  try {
    const funds = await getFunds();
    const fundName = new Map(funds.map((f) => [f.id, f.name]));
    const rawEntries = await listAllCashbookEntriesRaw();
    const validIds = new Set(funds.map((f) => f.id));

    const refTypeLabel = (rt: string): string => {
      switch (rt) {
        case 'order': return 'Đơn bán';
        case 'debt_pay': return 'Thu nợ KH';
        case 'supplier_pay': return 'Trả nợ NCC';
        case 'transfer': return 'Chuyển quỹ';
        case 'purchase': return 'Phiếu nhập';
        case 'stock_export': return 'Phiếu xuất';
        default: return 'Nhập tay';
      }
    };

    const lines = [
      ['Ngày', 'Giờ', 'Số phiếu', 'Loại', 'Số tiền', 'Danh mục', 'Quỹ', 'Nguồn', 'Mã đơn', 'Ghi chú']
        .map(csvCell).join(','),
    ];
    // Sắp xếp cũ → mới để dễ đối chiếu
    const sorted = [...rawEntries].sort((a, b) => {
      const ta = tsToIso(a.d.created_at);
      const tb = tsToIso(b.d.created_at);
      return ta < tb ? -1 : ta > tb ? 1 : 0;
    });
    for (const e of sorted) {
      const d = e.d;
      const iso = tsToIso(d.created_at);
      const dateKey = vnDateKeyLocal(iso);
      if (dateKey < start || dateKey > end) continue;
      const fid = normalizeFundId(String(d.fund_id ?? 'cash'), validIds);
      if (fundId !== 'all' && fid !== fundId) continue;
      if (typeFilter !== 'all' && d.type !== typeFilter) continue;
      if (catFilter.length > 0 && !catFilter.includes(String(d.category ?? ''))) continue;
      const wid = typeof d.warehouse_id === 'string' ? d.warehouse_id : '';
      if (warehouseIds.length > 0 && wid && !warehouseIds.includes(wid)) continue;
      const dt = new Date(iso);
      // Giờ VN
      const vnH = (dt.getUTCHours() + 7) % 24;
      const time = `${String(vnH).padStart(2, '0')}:${String(dt.getUTCMinutes()).padStart(2, '0')}`;
      lines.push(
        [
          dateKey,
          time,
          String((d.code as string | null) ?? (d.ref_code as string | null) ?? ''),
          d.type === 'chi' ? 'Chi' : 'Thu',
          Number(d.amount ?? 0),
          String(d.category ?? ''),
          fundName.get(fid) ?? fid,
          refTypeLabel(String(d.ref_type ?? 'manual')),
          String(d.ref_code ?? ''),
          String(d.note ?? ''),
        ].map(csvCell).join(','),
      );
    }
    // BOM để Excel hiển thị tiếng Việt đúng
    return '\uFEFF' + lines.join('\n');
  } catch (e) {
    throw toDbError(e);
  }
}

/**
 * Kiểm tra tính liên tục: cuối kỳ ngày D phải bằng đầu kỳ ngày D+1 cho mỗi quỹ.
 * Trả về danh sách các điểm lệch kèm chi tiết.
 */
export async function checkBalanceContinuity(days = 7): Promise<Array<{
  fundId: string;
  fundName: string;
  date: string; // ngày D (YYYY-MM-DD)
  closeD: number;
  openD1: number;
  diff: number;
}>> {
  const results: Array<{ fundId: string; fundName: string; date: string; closeD: number; openD1: number; diff: number }> = [];
  try {
    const funds = await getFunds();
    const today = todayVN();
    for (const f of funds) {
      const fromIso = f.opening_date ? new Date(`${f.opening_date}T00:00:00+07:00`).toISOString() : undefined;
      for (let i = days; i >= 1; i--) {
        const d = addDays(today, -i);
        if (f.opening_date && d < f.opening_date) continue; // quỹ chưa bắt đầu theo dõi
        const d1 = addDays(today, -i + 1);
        // Tính close(d) = open(d) + sum(d)
        const openD = await getFundSumsBefore(new Date(`${d}T00:00:00+07:00`).toISOString(), f.id, [], fromIso);
        const sumD = await getFundSumsOn(d, f.id);
        const closeD = f.opening_balance + (openD.thu - openD.chi) + (sumD.thu - sumD.chi);
        // Tính open(d+1)
        const openD1 = await getFundSumsBefore(new Date(`${d1}T00:00:00+07:00`).toISOString(), f.id, [], fromIso);
        const openD1Val = f.opening_balance + (openD1.thu - openD1.chi);
        const diff = Math.round(closeD - openD1Val);
        if (diff !== 0) {
          results.push({ fundId: f.id, fundName: f.name, date: d, closeD: Math.round(closeD), openD1: Math.round(openD1Val), diff });
        }
      }
    }
  } catch (e) {
    throw toDbError(e);
  }
  return results;
}

/** Tính tổng thu/chi trong 1 ngày cụ thể cho 1 quỹ. */
async function getFundSumsOn(dateYMD: string, fundId: string): Promise<{ thu: number; chi: number }> {
  let thu = 0;
  let chi = 0;
  let last: unknown = null;
  for (let page = 0; page < 200; page++) {
    const q =
      last == null
        ? query(collection(db, 'cashbook_entries'), where('fund_id', '==', fundId), orderBy('__name__'), limit(500))
        : query(collection(db, 'cashbook_entries'), where('fund_id', '==', fundId), orderBy('__name__'), limit(500), startAfter(last as never));
    const snap = await getDocs(q);
    if (snap.docs.length === 0) break;
    for (const d of snap.docs) {
      const data = d.data() as Record<string, unknown>;
      const k = vnDateKeyLocal(tsToIso(data.created_at));
      if (k !== dateYMD) continue;
      const amt = Number(data.amount ?? 0);
      if (data.type === 'thu') thu += amt;
      else chi += amt;
    }
    last = snap.docs[snap.docs.length - 1];
    if (snap.docs.length < 500) break;
  }
  return { thu, chi };
}

function addDays(ymd: string, n: number): string {
  const d = new Date(ymd + 'T12:00:00+07:00');
  d.setDate(d.getDate() + n);
  return d.toISOString().slice(0, 10);
}
