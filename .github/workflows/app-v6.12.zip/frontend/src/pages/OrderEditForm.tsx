// Form sửa toàn bộ đơn hàng: món, số lượng, giảm giá, voucher,
// phương thức thanh toán, khách hàng, ghi chú (chỉ chủ quán).
import { useEffect, useMemo, useState } from 'react';
import {
  DbError,
  calcDiscount,
  calcVoucherDiscount,
  getVoucherByCode,
  listPaymentMethods,
  listProducts,
  updateOrderFull,
  validateVoucher,
  isoToVNDateTimeInput,
  toLocalDateTimeInput,
  type UpdateOrderFullInput,
} from '../lib/db';
import { formatVND, todayVN } from '../lib/format';
import { useToast } from '../components/Toast';
import { CustomerPickSheet } from '../components/CustomerPickSheet';
import { Sheet } from '../components/Sheet';
import { discountAmountFor } from '../lib/types';
import type { Customer, Order, PaymentMethodDef, Product, Voucher } from '../lib/types';

interface EditLine {
  key: string;
  productId: string;
  productName: string;
  qty: number;
  modifierOptionIds: string[];
  modifierLabel: string;
  note: string;
  unitPrice: number; // giá hiện tại — dùng để ước tính tổng
  discountType: 'percent' | 'amount' | null;
  discountValue: number | null;
}

let lineSeq = 0;
const nextKey = () => `el_${Date.now()}_${lineSeq++}`;

export function OrderEditForm({
  order,
  customer,
  onClose,
  onSaved,
}: {
  order: Order;
  customer: Customer | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const toast = useToast();
  const [lines, setLines] = useState<EditLine[]>(() =>
    order.items.map((it) => ({
      key: nextKey(),
      productId: it.product_id,
      productName: it.product_name,
      qty: it.qty,
      modifierOptionIds: (it.modifiers ?? []).map((m) => m.option_id),
      modifierLabel: (it.modifiers ?? []).map((m) => `${m.group}: ${m.option}`).join(' · '),
      note: it.note ?? '',
      unitPrice: it.unit_price,
      discountType: it.discount_type ?? null,
      discountValue: it.discount_value ?? null,
    })),
  );
  const [products, setProducts] = useState<Product[]>([]);
  const [prodQ, setProdQ] = useState('');
  const [addingProduct, setAddingProduct] = useState(false);
  const [methods, setMethods] = useState<PaymentMethodDef[]>([]);
  const [methodId, setMethodId] = useState(order.payment_method);
  const [cust, setCust] = useState<Customer | null>(customer);
  const [pickOpen, setPickOpen] = useState(false);
  const [discountType, setDiscountType] = useState<'percent' | 'amount' | null>(order.discount_type);
  const [discountValue, setDiscountValue] = useState(
    order.discount_value != null ? String(order.discount_value) : '',
  );
  // Phí ship của đơn (v5.15) — giữ nguyên khi mở form, sửa được tại đây
  const [shipFee, setShipFee] = useState(order.shipping_fee > 0 ? String(order.shipping_fee) : '');
  const [voucherInput, setVoucherInput] = useState(order.voucher_code ?? '');
  const [voucher, setVoucher] = useState<Voucher | null>(null);
  const [voucherBusy, setVoucherBusy] = useState(false);
  const [note, setNote] = useState(order.note ?? '');
  // v6.3: sửa đơn được sửa cả ngày + giờ (datetime-local, giờ VN), nạp từ giờ
  // thật của đơn (created_at). Chỉ khi chạm vào trường này thì giờ mới đổi
  // (kèm khoản quỹ doanh thu); không chạm thì giữ nguyên ngày + giờ gốc.
  const [dateTime, setDateTime] = useState(
    () => isoToVNDateTimeInput(order.created_at) ?? toLocalDateTimeInput(),
  );
  const [dateTimeTouched, setDateTimeTouched] = useState(false);
  const [received, setReceived] = useState(
    order.amount_received != null ? String(order.amount_received) : '',
  );
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    listPaymentMethods(true)
      .then(setMethods)
      .catch(() => toast.show('Không tải được phương thức thanh toán'));
    listProducts()
      .then((ps) => setProducts(ps.filter((p) => p.active)))
      .catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const methodMap = useMemo(() => new Map(methods.map((m) => [m.id, m])), [methods]);
  const oldKind = methodMap.get(order.payment_method)?.kind ?? '';
  const newKind = methodMap.get(methodId)?.kind ?? '';

  // Ước tính tổng (giá chính xác do server tính lại khi lưu) — đã trừ giảm giá từng món
  const subtotal = lines.reduce(
    (s, l) => s + l.unitPrice * l.qty - discountAmountFor(l.unitPrice * l.qty, l.discountType, l.discountValue),
    0,
  );
  const discount = voucher
    ? calcVoucherDiscount(subtotal, voucher)
    : calcDiscount(subtotal, discountType, Number(discountValue) || 0);
  const shipFeeNum = Math.max(0, parseInt(shipFee.replace(/\D/g, ''), 10) || 0);
  const total = Math.max(0, subtotal - discount) + shipFeeNum;

  const filteredProducts = useMemo(() => {
    const q = prodQ.trim().toLowerCase();
    const list = q ? products.filter((p) => p.name.toLowerCase().includes(q)) : products;
    return list.slice(0, 60);
  }, [products, prodQ]);

  const addProduct = (p: Product) => {
    setLines((ls) => {
      const ex = ls.find((l) => l.productId === p.id && l.modifierOptionIds.length === 0 && !l.note);
      if (ex) return ls.map((l) => (l === ex ? { ...l, qty: l.qty + 1 } : l));
      return [
        ...ls,
        {
          key: nextKey(),
          productId: p.id,
          productName: p.name,
          qty: 1,
          modifierOptionIds: [],
          modifierLabel: '',
          note: '',
          unitPrice: p.base_price,
          discountType: null,
          discountValue: null,
        },
      ];
    });
    // Cập nhật giá ước tính theo giá hiện tại của món
    setProdQ('');
  };

  const setQty = (key: string, qty: number) => {
    const q = Math.max(1, Math.round(qty) || 1);
    setLines((ls) => ls.map((l) => (l.key === key ? { ...l, qty: q } : l)));
  };
  const removeLine = (key: string) => setLines((ls) => ls.filter((l) => l.key !== key));

  const clearVoucher = () => setVoucher(null);
  const onVoucherInput = (v: string) => {
    setVoucherInput(v);
    clearVoucher();
  };
  const onDiscountChange = (t: 'percent' | 'amount' | null, v: string) => {
    setDiscountType(t);
    setDiscountValue(v);
    if (t) clearVoucher(); // voucher và giảm giá tay không dùng chung
  };

  const checkVoucher = async (): Promise<Voucher | null> => {
    const code = voucherInput.trim().toLowerCase();
    if (!code) {
      setVoucher(null);
      return null;
    }
    if (voucher && voucher.code.toLowerCase() === code) return voucher;
    setVoucherBusy(true);
    try {
      const v = await getVoucherByCode(code);
      if (!v) throw new DbError('invalid-argument', 'Mã voucher không tồn tại.');
      const err = validateVoucher(v, subtotal, todayVN());
      if (err) throw new DbError('invalid-argument', err);
      setVoucher(v);
      setDiscountType(null);
      setDiscountValue('');
      toast.show(`Đã áp voucher ${v.code}`);
      return v;
    } catch (e) {
      setVoucher(null);
      throw e;
    } finally {
      setVoucherBusy(false);
    }
  };

  const doSave = async () => {
    if (lines.length === 0) {
      toast.show('Đơn hàng phải có ít nhất một món.');
      return;
    }
    const sel = methodMap.get(methodId);
    if (!sel) {
      toast.show('Vui lòng chọn phương thức thanh toán.');
      return;
    }
    if (sel.kind === 'debt' && !cust) {
      toast.show('Ghi nợ cần chọn khách hàng cho đơn này.');
      return;
    }
    setBusy(true);
    try {
      let v: Voucher | null = null;
      if (voucherInput.trim()) {
        try {
          v = await checkVoucher();
        } catch (e) {
          toast.show(e instanceof DbError ? e.message : 'Voucher không hợp lệ.');
          setBusy(false);
          return;
        }
      }
      const recvRaw = Number(received);
      const input: UpdateOrderFullInput = {
        items: lines.map((l) => ({
          productId: l.productId,
          qty: l.qty,
          modifierOptionIds: l.modifierOptionIds,
          note: l.note || undefined,
          discountType: l.discountType,
          discountValue: l.discountValue,
        })),
        paymentMethod: methodId,
        customerId: cust ? cust.id : null,
        note: note.trim() || null,
        discountType: v ? null : discountType,
        discountValue: v || !discountType ? null : Number(discountValue) || 0,
        shippingFee: shipFeeNum > 0 ? shipFeeNum : null,
        voucherCode: v ? v.code : null,
        warehouseId: order.warehouse_id,
        amountReceived:
          sel.kind === 'cash' ? (recvRaw > 0 ? Math.round(recvRaw) : Math.round(total)) : null,
        businessDateTime: dateTimeTouched ? dateTime : null,
      };
      await updateOrderFull(order.id, input);
      toast.show(`Đã lưu thay đổi đơn ${order.code}`);
      onSaved();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  const debtWarn =
    oldKind === 'debt' && newKind !== 'debt'
      ? 'Đơn cũ ghi nợ — công nợ của khách sẽ được hoàn lại số tiền đơn cũ.'
      : oldKind !== 'debt' && newKind === 'debt'
        ? 'Đơn sẽ chuyển thành ghi nợ — công nợ của khách sẽ tăng thêm.'
        : null;

  return (
    <Sheet
      title={`✏️ Sửa đơn ${order.code}`}
      onClose={onClose}
      footer={
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 8 }}>
          <button className="btn btn-outline btn-lg" style={{ width: '100%' }} disabled={busy} onClick={onClose}>
            Hủy
          </button>
          <button className="btn btn-lg" style={{ width: '100%' }} disabled={busy} onClick={() => void doSave()}>
            {busy ? 'Đang lưu…' : '💾 Lưu thay đổi'}
          </button>
        </div>
      }
    >
      {/* Món */}
      <div className="field">
        <label>
          Món ({lines.length}) — <span className="muted">giá tính lại theo menu hiện tại</span>
        </label>
        {lines.length === 0 ? (
          <p className="small muted">Chưa có món nào — bấm “＋ Thêm món” bên dưới.</p>
        ) : (
          <div className="sb-section" style={{ padding: '4px 16px', marginBottom: 8 }}>
            {lines.map((l) => (
              <div key={l.key} className="sb-row" style={{ cursor: 'default', alignItems: 'center' }}>
                <span className="rbody">
                  <span className="rtitle">{l.productName}</span>
                  {l.modifierLabel && <span className="rsub">{l.modifierLabel}</span>}
                  {l.note && <span className="rsub">“{l.note}”</span>}
                  <span className="rsub">{formatVND(l.unitPrice)} / món</span>
                  {(() => {
                    const ld = discountAmountFor(l.unitPrice * l.qty, l.discountType, l.discountValue);
                    return ld > 0 ? (
                      <span className="rsub" style={{ color: 'var(--green)', fontWeight: 600 }}>
                        Giảm {l.discountType === 'percent' ? `${l.discountValue}%` : ''} −{formatVND(ld)} → còn {formatVND(l.unitPrice * l.qty - ld)}
                      </span>
                    ) : null;
                  })()}
                  <span className="row" style={{ gap: 4, alignItems: 'center', marginTop: 2 }}>
                    <select
                      className="input"
                      style={{ width: 86, minHeight: 30, padding: '2px 6px', fontSize: 12 }}
                      value={l.discountType ?? ''}
                      onChange={(e) =>
                        setLines((ls) =>
                          ls.map((x) =>
                            x.key === l.key
                              ? { ...x, discountType: (e.target.value || null) as 'percent' | 'amount' | null }
                              : x,
                          ),
                        )
                      }
                      aria-label="Kiểu giảm giá món"
                    >
                      <option value="">Không giảm</option>
                      <option value="percent">Giảm %</option>
                      <option value="amount">Giảm tiền</option>
                    </select>
                    {l.discountType && (
                      <input
                        className="input"
                        style={{ width: 90, minHeight: 30, padding: '2px 6px', fontSize: 12 }}
                        inputMode="numeric"
                        value={l.discountValue ?? ''}
                        onChange={(e) =>
                          setLines((ls) =>
                            ls.map((x) =>
                              x.key === l.key
                                ? { ...x, discountValue: Math.max(0, parseInt(e.target.value.replace(/\D/g, ''), 10) || 0) }
                                : x,
                            ),
                          )
                        }
                        placeholder={l.discountType === 'percent' ? '%' : 'đ'}
                        aria-label="Mức giảm giá món"
                      />
                    )}
                  </span>
                </span>
                <span className="row" style={{ gap: 4, alignItems: 'center', flex: '0 0 auto' }}>
                  <button
                    type="button"
                    className="btn btn-ghost btn-sm"
                    style={{ minWidth: 36 }}
                    onClick={() => setQty(l.key, l.qty - 1)}
                    aria-label="Giảm"
                  >
                    −
                  </button>
                  <b style={{ minWidth: 28, textAlign: 'center' }}>{l.qty}</b>
                  <button
                    type="button"
                    className="btn btn-ghost btn-sm"
                    style={{ minWidth: 36 }}
                    onClick={() => setQty(l.key, l.qty + 1)}
                    aria-label="Tăng"
                  >
                    ＋
                  </button>
                  <button
                    type="button"
                    className="btn btn-ghost btn-sm"
                    style={{ color: 'var(--red)' }}
                    onClick={() => removeLine(l.key)}
                    aria-label={`Xóa ${l.productName}`}
                  >
                    ×
                  </button>
                </span>
              </div>
            ))}
          </div>
        )}
        {!addingProduct ? (
          <button
            type="button"
            className="btn btn-outline btn-block"
            onClick={() => setAddingProduct(true)}
          >
            ＋ Thêm món
          </button>
        ) : (
          <div className="sb-section" style={{ padding: '8px 12px' }}>
            <div className="row" style={{ gap: 8, marginBottom: 8 }}>
              <input
                className="input"
                value={prodQ}
                onChange={(e) => setProdQ(e.target.value)}
                placeholder="🔍 Tìm món…"
                autoFocus
              />
              <button type="button" className="btn btn-ghost" onClick={() => setAddingProduct(false)}>
                ✕
              </button>
            </div>
            <div style={{ maxHeight: 240, overflowY: 'auto' }}>
              {filteredProducts.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  className="sb-row"
                  style={{ width: '100%', textAlign: 'left' }}
                  onClick={() => addProduct(p)}
                >
                  <span className="rbody">
                    <span className="rtitle">{p.name}</span>
                  </span>
                  <span className="ramount">{formatVND(p.base_price)}</span>
                </button>
              ))}
              {filteredProducts.length === 0 && (
                <p className="small muted" style={{ textAlign: 'center' }}>
                  Không tìm thấy món.
                </p>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Giảm giá */}
      <div className="field">
        <label>Giảm giá</label>
        <div className="row" style={{ gap: 8 }}>
          <select
            className="input"
            style={{ flex: '0 0 130px' }}
            value={discountType ?? ''}
            onChange={(e) =>
              onDiscountChange((e.target.value || null) as 'percent' | 'amount' | null, discountValue)
            }
          >
            <option value="">Không giảm</option>
            <option value="percent">Theo %</option>
            <option value="amount">Số tiền</option>
          </select>
          {discountType && (
            <input
              className="input"
              type="number"
              min={0}
              value={discountValue}
              onChange={(e) => onDiscountChange(discountType, e.target.value)}
              placeholder={discountType === 'percent' ? '% (0-100)' : 'Số tiền (đ)'}
            />
          )}
        </div>
      </div>

      {/* Phí ship (v5.15) */}
      <div className="field">
        <label>Phí ship (đ)</label>
        <input
          className="input"
          type="number"
          min={0}
          value={shipFee}
          onChange={(e) => setShipFee(e.target.value)}
          placeholder="0"
        />
      </div>

      {/* Voucher */}
      <div className="field">
        <label>Mã voucher</label>
        <div className="row" style={{ gap: 8 }}>
          <input
            className="input"
            value={voucherInput}
            onChange={(e) => onVoucherInput(e.target.value)}
            placeholder="Nhập mã voucher…"
            style={{ textTransform: 'uppercase' }}
          />
          <button
            type="button"
            className="btn btn-outline"
            disabled={voucherBusy || !voucherInput.trim()}
            onClick={() => void checkVoucher().catch((e) => toast.show(e instanceof DbError ? e.message : 'Voucher không hợp lệ'))}
          >
            {voucherBusy ? '…' : 'Áp'}
          </button>
        </div>
        {voucher && (
          <p className="small text-green" style={{ marginTop: 4 }}>
            ✓ {voucher.code} — giảm {formatVND(calcVoucherDiscount(subtotal, voucher))}
          </p>
        )}
        {voucher && <p className="small muted">Voucher được ưu tiên, giảm giá tay sẽ bị bỏ qua.</p>}
      </div>

      {/* Phương thức thanh toán */}
      <div className="field">
        <label>Phương thức thanh toán</label>
        <div className="chip-row">
          {methods.map((m) => (
            <button
              key={m.id}
              type="button"
              className={`sb-chip${methodId === m.id ? ' selected' : ''}`}
              onClick={() => setMethodId(m.id)}
            >
              {m.icon} {m.name}
            </button>
          ))}
        </div>
        {debtWarn && (
          <p className="small" style={{ color: 'var(--orange)', marginTop: 6 }}>
            ⚠️ {debtWarn}
          </p>
        )}
        {newKind === 'cash' && (
          <div style={{ marginTop: 8 }}>
            <label className="small muted">Tiền khách đưa (đ)</label>
            <input
              className="input"
              type="number"
              min={0}
              value={received}
              onChange={(e) => setReceived(e.target.value)}
              placeholder={`Mặc định = tổng tiền (${formatVND(total)})`}
            />
          </div>
        )}
      </div>

      {/* Khách hàng */}
      <div className="field">
        <label>Khách hàng</label>
        <button className="sb-row" type="button" onClick={() => setPickOpen(true)}>
          <span className="avatar">{cust ? cust.name.charAt(0).toUpperCase() : '👤'}</span>
          <span className="rbody">
            <span className="rtitle">{cust ? cust.name : 'Khách lẻ'}</span>
            <span className="rsub">{cust ? cust.phone : 'Bấm để chọn khách'}</span>
          </span>
          <span className="text-green" style={{ fontWeight: 600 }}>
            Đổi ›
          </span>
        </button>
        {cust && (
          <button
            type="button"
            className="btn btn-ghost btn-sm"
            style={{ marginTop: 6 }}
            onClick={() => setCust(null)}
          >
            Bỏ chọn (về khách lẻ)
          </button>
        )}
      </div>

      {/* Ngày giờ đơn (v6.3: sửa được cả giờ, khoản quỹ đổi theo) */}
      <div className="field">
        <label>Ngày giờ đơn</label>
        <input
          className="input"
          type="datetime-local"
          value={dateTime}
          onChange={(e) => { if (e.target.value) { setDateTime(e.target.value); setDateTimeTouched(true); } }}
        />
      </div>

      {/* Ghi chú */}
      <div className="field">
        <label>Ghi chú đơn</label>
        <input
          className="input"
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="Ghi chú…"
          maxLength={1000}
        />
      </div>

      {/* Tổng ước tính */}
      <div className="sb-section">
        <div className="row" style={{ justifyContent: 'space-between' }}>
          <span className="muted">Tạm tính</span>
          <span>{formatVND(subtotal)}</span>
        </div>
        {discount > 0 && (
          <div className="row" style={{ justifyContent: 'space-between', color: 'var(--green)' }}>
            <span>Giảm giá{voucher ? ` (${voucher.code})` : ''}</span>
            <span>-{formatVND(discount)}</span>
          </div>
        )}
        <div className="row" style={{ justifyContent: 'space-between' }}>
          <b style={{ fontSize: 17 }}>Tổng cộng (ước tính)</b>
          <b className="money text-orange" style={{ fontSize: 24 }}>
            {formatVND(total)}
          </b>
        </div>
        <p className="small muted">Giá chính xác được tính lại khi lưu.</p>
      </div>

      {pickOpen && (
        <CustomerPickSheet
          onClose={() => setPickOpen(false)}
          onPick={(c) => {
            setCust(c);
            setPickOpen(false);
          }}
        />
      )}
    </Sheet>
  );
}
