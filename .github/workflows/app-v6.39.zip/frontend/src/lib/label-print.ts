// In tem món qua hộp thoại in của hệ thống (máy in WiFi / máy in share qua LAN
// đã cài trên điện thoại hoặc máy tính). Khác với in Bluetooth (ESC/POS,
// không dấu): in qua hệ thống render HTML nên giữ nguyên dấu tiếng Việt.
// Dùng chung cơ chế #print-root với BillPrint: tem ghi vào #label-print-area,
// body thêm class 'print-labels' để CSS @media print chỉ hiện tem (ẩn bill)
// trong lúc in, gỡ class sau khi in xong.

import type { LabelPaperSize, Order } from './types';

function esc(s: string): string {
  return s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c] ?? c));
}

/** Số ly trong đơn = số tem cần in (mỗi ly 1 tem). */
export function cupCount(order: Order): number {
  return order.items.reduce((a, it) => a + Math.max(0, Math.floor(it.qty)), 0);
}

/** HTML cho toàn bộ tem của 1 đơn — mỗi ly 1 trang tem 50x30mm (mẫu B:
 * tên món đậm to nhất, lựa chọn chữ thường, ghi chú gạch chân, mã đơn
 * nhỏ cuối tem). Thuần logic, không chạm DOM nên test được. */
export function buildLabelHtml(order: Order): string {
  const pages: string[] = [];
  for (const it of order.items) {
    const qty = Math.max(0, Math.floor(it.qty));
    for (let cup = 0; cup < qty; cup++) {
      const mods = (it.modifiers || []).map((m) => m.option).filter(Boolean);
      pages.push(
        `<div class="label-page">` +
          `<div class="label-name">${esc(it.product_name)}</div>` +
          (mods.length ? `<div class="label-mod">${esc(mods.join(', '))}</div>` : '') +
          (it.note && it.note.trim() ? `<div class="label-note">Ghi chú: ${esc(it.note.trim())}</div>` : '') +
          `<div class="label-code">Mã đơn: ${esc(order.code)}</div>` +
          `</div>`,
      );
    }
  }
  return `<div id="label-print-area">${pages.join('')}</div>`;
}

/** Ghi tem vào #print-root rồi mở hộp thoại in của hệ thống để chọn máy in
 * WiFi/LAN. Khổ tem lấy theo cài đặt (mặc định 50x30mm) — CSS đổi khổ qua
 * class label-<khổ> trên body. Không xóa HTML bill trong #print-root
 * (chỉ thêm khu vực tem), để in bill qua hệ thống vẫn dùng được sau đó. */
export function printLabelsViaSystem(order: Order, size: LabelPaperSize = '50x30'): void {
  if (cupCount(order) === 0) return;
  let root = document.getElementById('print-root');
  if (!root) {
    root = document.createElement('div');
    root.id = 'print-root';
    document.body.appendChild(root);
  }
  const old = document.getElementById('label-print-area');
  if (old) old.remove();
  root.insertAdjacentHTML('beforeend', buildLabelHtml(order));
  document.body.classList.add('print-labels');
  const sizeClass = size === '50x30' ? null : `label-${size}`;
  if (sizeClass) document.body.classList.add(sizeClass);
  const done = () => {
    document.body.classList.remove('print-labels');
    if (sizeClass) document.body.classList.remove(sizeClass);
    window.removeEventListener('afterprint', done);
  };
  window.addEventListener('afterprint', done);
  // Dự phòng: một số trình duyệt không bắn afterprint khi hủy hộp thoại.
  window.setTimeout(done, 10000);
  window.print();
}
