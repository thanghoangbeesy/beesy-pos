// Nhập đơn sàn GrabFood / ShopeeFood (v6.25) + ghi nhận tiền về.
// - Không đồng bộ tự động: Grab/Shopee không mở API miễn phí cho quán nhỏ,
//   nên đơn sàn được nhập tay trong POS, dùng chung đơn bán hàng (trừ kho,
//   tính doanh thu như đơn tại quầy).
// - Lúc tạo đơn KHÔNG ghi tiền vào quỹ. Tiền chỉ ghi khi chủ quán bấm
//   "Đã về tiền" (markPlatformOrderReceived): thu gộp = tổng đơn, chi phí
//   sàn, chi thuế sàn — số dư quỹ khớp đúng tiền thực về tài khoản.
// - Giá sàn gợi ý = giá quán +25%, làm tròn lên 1.000đ (bảng chốt 03/11/2026).
//   Giá trên app GrabMerchant mới là chuẩn (VD Trà Tắc Siêu To 20.000đ),
//   nên giá gợi ý chỉ để nhập nhanh, sửa tay được từng dòng.
import { useEffect, useMemo, useState } from 'react';
import {
  DbError,
  calcPlatformSettlement,
  createOrder,
  getAllowedWarehouses,
  getDefaultWarehouseId,
  listPaymentMethods,
  listProducts,
  markPlatformOrderReceived,
  toLocalDateTimeInput,
  type CreateOrderItemInput,
} from '../lib/db';
import { formatVND, todayVN, uuid } from '../lib/format';
import { useToast } from '../components/Toast';
import { Sheet } from '../components/Sheet';
import type { Order, PaymentMethodDef, Product, Warehouse } from '../lib/types';
import { PLATFORM_STATUS_LABEL } from '../lib/types';

/** Giá sàn gợi ý: giá quán +25%, làm tròn LÊN tới 1.000đ. */
export function suggestPlatformPrice(shopPrice: number): number {
  const p = Math.max(0, Math.round(shopPrice));
  return Math.ceil((p * 1.25) / 1000) * 1000;
}

const PLATFORM_NAME: Record<'grabfood' | 'shopeefood', string> = {
  grabfood: 'GrabFood',
  shopeefood: 'ShopeeFood',
};

interface Line {
  key: string;
  productId: string;
  qty: number;
  price: number; // giá sàn 1 cốc (đã sửa tay nếu cần)
}

function numOrNull(s: string): number | null {
  const v = s.trim();
  if (v === '') return null;
  const n = Math.round(Number(v));
  return Number.isFinite(n) ? n : null;
}

export function PlatformOrderForm({
  onClose,
  onDone,
}: {
  onClose: () => void;
  onDone: (order: Order) => void;
}) {
  const toast = useToast();
  const [loading, setLoading] = useState(true);
  const [products, setProducts] = useState<Product[]>([]);
  const [methods, setMethods] = useState<PaymentMethodDef[]>([]);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [warehouseId, setWarehouseId] = useState('');
  const [platform, setPlatform] = useState<'grabfood' | 'shopeefood'>('grabfood');
  const [code, setCode] = useState('');
  const [dateTime, setDateTime] = useState(() => toLocalDateTimeInput(new Date()));
  const [lines, setLines] = useState<Line[]>([
    { key: uuid(), productId: '', qty: 1, price: 0 },
  ]);
  const [feeText, setFeeText] = useState('');
  const [taxVatText, setTaxVatText] = useState('');
  const [taxPitText, setTaxPitText] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [prods, meths, allowed, defWid] = await Promise.all([
          listProducts(),
          listPaymentMethods(true),
          getAllowedWarehouses().catch(() => ({ warehouses: [], isOwner: true })),
          getDefaultWarehouseId().catch(() => null),
        ]);
        if (cancelled) return;
        setProducts(prods.filter((p) => p.active));
        setMethods(meths);
        setWarehouses(allowed.warehouses);
        setWarehouseId(defWid ?? allowed.warehouses[0]?.id ?? '');
      } catch (e) {
        if (!cancelled) toast.show(e instanceof DbError ? e.message : 'Không tải được menu');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const transferMethod = methods.find((m) => m.kind === 'transfer' && m.active !== false) ?? null;
  const total = lines.reduce((s, l) => s + l.qty * Math.max(0, l.price), 0);
  const settlement = useMemo(
    () =>
      calcPlatformSettlement(
        total,
        platform,
        numOrNull(feeText),
        numOrNull(taxVatText),
        numOrNull(taxPitText),
      ),
    [total, platform, feeText, taxVatText, taxPitText],
  );

  const pickProduct = (key: string, productId: string) => {
    const p = products.find((x) => x.id === productId);
    setLines((prev) =>
      prev.map((l) =>
        l.key === key
          ? { ...l, productId, price: p ? suggestPlatformPrice(p.base_price) : l.price }
          : l,
      ),
    );
  };

  const applyAllPlatformPrices = () => {
    setLines((prev) =>
      prev.map((l) => {
        const p = products.find((x) => x.id === l.productId);
        return p ? { ...l, price: suggestPlatformPrice(p.base_price) } : l;
      }),
    );
    toast.show('Đã đặt lại giá sàn +25% cho các dòng đã chọn món');
  };

  const submit = async () => {
    if (!transferMethod) {
      toast.show('Chưa có phương thức chuyển khoản đang bật — vào Cài đặt thêm phương thức chuyển khoản trước.');
      return;
    }
    if (!code.trim()) {
      toast.show('Nhập mã đơn trên sàn (VD GF-300).');
      return;
    }
    const items: CreateOrderItemInput[] = [];
    for (const l of lines) {
      const p = products.find((x) => x.id === l.productId);
      if (!p) {
        toast.show('Chọn món cho mọi dòng trước khi lưu.');
        return;
      }
      if (!Number.isInteger(l.qty) || l.qty < 1) {
        toast.show(`Số lượng của món ${p.name} phải từ 1 trở lên.`);
        return;
      }
      if (!Number.isFinite(l.price) || l.price <= 0) {
        toast.show(`Nhập giá sàn cho món ${p.name}.`);
        return;
      }
      items.push({ productId: p.id, qty: l.qty, unitPrice: Math.round(l.price) });
    }
    if (total <= 0) {
      toast.show('Tổng đơn phải lớn hơn 0.');
      return;
    }
    if (platform === 'shopeefood' && (feeText.trim() === '' || taxVatText.trim() === '' || taxPitText.trim() === '')) {
      toast.show('ShopeeFood chưa có tỷ lệ mặc định — nhập tay phí sàn, thuế GTGT và thuế TNCN theo Shopee Seller.');
      return;
    }
    if (settlement.fee + settlement.tax >= total) {
      toast.show('Phí sàn + thuế không được lớn hơn hoặc bằng tổng đơn.');
      return;
    }
    setBusy(true);
    try {
      const businessDate = dateTime.slice(0, 10) || todayVN();
      const createdAt = dateTime ? new Date(dateTime).toISOString() : new Date().toISOString();
      const order = await createOrder({
        clientUuid: uuid(),
        customerId: null,
        items,
        paymentMethod: transferMethod.id,
        warehouseId: warehouseId || undefined,
        businessDate,
        createdAt,
        source: platform,
        platformCode: code.trim(),
        platformFee: numOrNull(feeText),
        platformTaxVat: numOrNull(taxVatText),
        platformTaxPit: numOrNull(taxPitText),
      });
      toast.show(`Đã nhập đơn sàn ${order.code} (${PLATFORM_NAME[platform]} ${code.trim()}) — đang chờ tiền về.`);
      onDone(order);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu đơn sàn thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet title={`Nhập đơn sàn — ${PLATFORM_NAME[platform]}`} onClose={onClose}>
      {loading ? (
        <p className="muted">Đang tải menu…</p>
      ) : (
        <div style={{ display: 'grid', gap: 10 }}>
          <div className="field">
            <label>Sàn bán</label>
            <div className="row" style={{ gap: 8 }}>
              {(['grabfood', 'shopeefood'] as const).map((p) => (
                <button
                  key={p}
                  type="button"
                  className={`sb-chip${platform === p ? ' selected' : ''}`}
                  onClick={() => setPlatform(p)}
                >
                  {PLATFORM_NAME[p]}
                </button>
              ))}
            </div>
          </div>

          <div className="field">
            <label>Mã đơn trên sàn</label>
            <input
              className="input"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="VD GF-300"
              maxLength={50}
            />
          </div>

          <div className="field">
            <label>Ngày / giờ đơn</label>
            <input
              className="input"
              type="datetime-local"
              value={dateTime}
              max={toLocalDateTimeInput(new Date())}
              onChange={(e) => setDateTime(e.target.value)}
            />
          </div>

          {warehouses.length > 1 && (
            <div className="field">
              <label>Kho trừ tồn</label>
              <select className="input" value={warehouseId} onChange={(e) => setWarehouseId(e.target.value)}>
                {warehouses.map((w) => (
                  <option key={w.id} value={w.id}>
                    {w.name}
                  </option>
                ))}
              </select>
            </div>
          )}

          <div>
            <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
              <b>Món trong đơn</b>
              <button type="button" className="btn btn-ghost btn-sm" onClick={applyAllPlatformPrices}>
                Đặt lại giá sàn +25%
              </button>
            </div>
            {lines.map((l) => (
              <div key={l.key} style={{ display: 'grid', gridTemplateColumns: '1fr 64px 96px 32px', gap: 6, marginBottom: 6, alignItems: 'center' }}>
                <select
                  className="input"
                  value={l.productId}
                  onChange={(e) => pickProduct(l.key, e.target.value)}
                  aria-label="Chọn món"
                >
                  <option value="">Chọn món…</option>
                  {products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({formatVND(p.base_price)})
                    </option>
                  ))}
                </select>
                <input
                  className="input"
                  type="number"
                  min={1}
                  step={1}
                  value={l.qty}
                  onChange={(e) =>
                    setLines((prev) => prev.map((x) => (x.key === l.key ? { ...x, qty: Math.max(0, Math.round(Number(e.target.value) || 0)) } : x)))
                  }
                  aria-label="Số lượng"
                />
                <input
                  className="input"
                  type="number"
                  min={0}
                  step={1000}
                  value={l.price || ''}
                  placeholder="Giá sàn"
                  onChange={(e) =>
                    setLines((prev) => prev.map((x) => (x.key === l.key ? { ...x, price: Math.max(0, Math.round(Number(e.target.value) || 0)) } : x)))
                  }
                  aria-label="Giá sàn 1 cốc"
                />
                <button
                  type="button"
                  className="btn btn-ghost btn-sm"
                  aria-label="Xóa dòng"
                  disabled={lines.length <= 1}
                  onClick={() => setLines((prev) => prev.filter((x) => x.key !== l.key))}
                >
                  ×
                </button>
              </div>
            ))}
            <button
              type="button"
              className="btn btn-outline btn-sm"
              onClick={() => setLines((prev) => [...prev, { key: uuid(), productId: '', qty: 1, price: 0 }])}
            >
              + Thêm món
            </button>
            <p className="small muted" style={{ marginTop: 6 }}>
              Giá gợi ý = giá quán +25%, làm tròn lên 1.000đ. Giá trên app sàn mới là chuẩn — sửa tay từng
              dòng nếu khác (VD Trà Tắc Siêu To trên Grab là 20.000đ).
            </p>
          </div>

          <div className="field">
            <label>Chiết khấu sàn (đ) — để trống = tự tính</label>
            <input
              className="input"
              type="number"
              min={0}
              step={1}
              value={feeText}
              placeholder={platform === 'grabfood' ? `Tự tính ${formatVND(settlement.fee)} (19,634%)` : 'Nhập theo Shopee Seller'}
              onChange={(e) => setFeeText(e.target.value)}
            />
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
            <div className="field">
              <label>Thuế GTGT (đ) — để trống = tự tính</label>
              <input
                className="input"
                type="number"
                min={0}
                step={1}
                value={taxVatText}
                placeholder={platform === 'grabfood' ? `Tự tính ${formatVND(settlement.taxVat)} (3%)` : 'Nhập tay'}
                onChange={(e) => setTaxVatText(e.target.value)}
              />
            </div>
            <div className="field">
              <label>Thuế TNCN (đ) — để trống = tự tính</label>
              <input
                className="input"
                type="number"
                min={0}
                step={1}
                value={taxPitText}
                placeholder={platform === 'grabfood' ? `Tự tính ${formatVND(settlement.taxPit)} (1,5%)` : 'Nhập tay'}
                onChange={(e) => setTaxPitText(e.target.value)}
              />
            </div>
          </div>

          <div className="card" style={{ margin: 0 }}>
            <div className="row" style={{ justifyContent: 'space-between' }}>
              <span className="muted">Tổng tiền khách trả</span>
              <b>{formatVND(total)}</b>
            </div>
            <div className="row" style={{ justifyContent: 'space-between' }}>
              <span className="muted">Chiết khấu sàn</span>
              <span>-{formatVND(settlement.fee)}</span>
            </div>
            <div className="row" style={{ justifyContent: 'space-between' }}>
              <span className="muted">Thuế sàn (GTGT + TNCN)</span>
              <span>-{formatVND(settlement.tax)}</span>
            </div>
            <div className="row" style={{ justifyContent: 'space-between' }}>
              <span>Tiền về dự kiến</span>
              <b className="text-green">{formatVND(settlement.netExpected)}</b>
            </div>
            <p className="small muted" style={{ margin: '6px 0 0' }}>
              Lúc lưu đơn, tiền CHƯA vào quỹ. Khi sàn chuyển tiền về, mở đơn này và bấm “Đã về tiền”
              thì tiền mới vào quỹ Chuyển khoản.
            </p>
          </div>

          {!transferMethod && (
            <p style={{ color: '#DC2626' }}>
              Chưa có phương thức chuyển khoản đang bật — vào Cài đặt thêm phương thức chuyển khoản trước khi nhập đơn sàn.
            </p>
          )}
          <button className="btn btn-block" style={{ minHeight: 48 }} disabled={busy || loading} onClick={() => void submit()}>
            {busy ? 'Đang lưu…' : 'Lưu đơn sàn (chờ tiền về)'}
          </button>
        </div>
      )}
    </Sheet>
  );
}

/** Form ghi nhận tiền đơn sàn đã về — chỉ chủ quán (rules chỉ cho chủ quán sửa đơn). */
export function PlatformSettlementSheet({
  order,
  onClose,
  onDone,
}: {
  order: Order;
  onClose: () => void;
  onDone: (order: Order) => void;
}) {
  const toast = useToast();
  const [feeText, setFeeText] = useState(String(order.platform_fee ?? 0));
  const [taxVatText, setTaxVatText] = useState(String(order.platform_tax_vat ?? 0));
  const [taxPitText, setTaxPitText] = useState(String(order.platform_tax_pit ?? 0));
  const [actualText, setActualText] = useState(String(order.platform_net_expected ?? 0));
  const [busy, setBusy] = useState(false);

  const fee = Math.max(0, Math.round(Number(feeText) || 0));
  const taxVat = Math.max(0, Math.round(Number(taxVatText) || 0));
  const taxPit = Math.max(0, Math.round(Number(taxPitText) || 0));
  const tax = taxVat + taxPit;
  const actual = Math.max(0, Math.round(Number(actualText) || 0));
  const expectedFromFeeTax = order.total - fee - tax;
  const diff = actual - expectedFromFeeTax;
  const platformName = order.source === 'grabfood' ? 'GrabFood' : order.source === 'shopeefood' ? 'ShopeeFood' : '';

  const submit = async () => {
    if (actual <= 0) {
      toast.show('Nhập tiền thực về tài khoản.');
      return;
    }
    if (actual > order.total) {
      toast.show('Tiền thực về không được lớn hơn tổng đơn.');
      return;
    }
    if (fee + tax >= order.total) {
      toast.show('Phí sàn + thuế không được lớn hơn hoặc bằng tổng đơn.');
      return;
    }
    setBusy(true);
    try {
      const updated = await markPlatformOrderReceived(order.id, {
        actualAmount: actual,
        fee,
        taxVat,
        taxPit,
      });
      toast.show(`Đã ghi nhận tiền về đơn ${order.code}: ${formatVND(actual)}.`);
      onDone(updated);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Ghi nhận tiền về thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet title={`Đã về tiền — đơn ${order.code}`} onClose={onClose}>
      <div style={{ display: 'grid', gap: 10 }}>
        <p className="small" style={{ margin: 0 }}>
          {platformName} {order.platform_order_code ? `· Mã sàn ${order.platform_order_code}` : ''} · Tổng đơn{' '}
          <b>{formatVND(order.total)}</b>
        </p>
        <div className="field">
          <label>Chiết khấu sàn thực tế (đ) — sửa theo sao kê sàn nếu khác số dự kiến</label>
          <input className="input" type="number" min={0} step={1} value={feeText} onChange={(e) => setFeeText(e.target.value)} />
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
          <div className="field">
            <label>Thuế GTGT thực tế (đ)</label>
            <input className="input" type="number" min={0} step={1} value={taxVatText} onChange={(e) => setTaxVatText(e.target.value)} />
          </div>
          <div className="field">
            <label>Thuế TNCN thực tế (đ)</label>
            <input className="input" type="number" min={0} step={1} value={taxPitText} onChange={(e) => setTaxPitText(e.target.value)} />
          </div>
        </div>
        <div className="field">
          <label>Tiền thực về tài khoản (đ) — nhập theo sao kê ngân hàng / GrabMerchant</label>
          <input className="input" type="number" min={0} step={1} value={actualText} onChange={(e) => setActualText(e.target.value)} />
        </div>
        <div className="card" style={{ margin: 0 }}>
          <div className="row" style={{ justifyContent: 'space-between' }}>
            <span className="muted">Tổng đơn − phí − thuế</span>
            <b>{formatVND(expectedFromFeeTax)}</b>
          </div>
          <div className="row" style={{ justifyContent: 'space-between' }}>
            <span className="muted">Tiền thực về nhập vào</span>
            <b>{formatVND(actual)}</b>
          </div>
          {diff !== 0 && (
            <p className="small" style={{ margin: '6px 0 0', color: '#B45309' }}>
              Chênh {formatVND(Math.abs(diff))} so với tổng đơn − phí − thuế. Kiểm tra lại phí/thuế theo sao kê
              sàn trước khi lưu — tiền thực về và phí/thuế phải khớp nhau thì sổ quỹ mới đối chiếu đúng.
            </p>
          )}
          <p className="small muted" style={{ margin: '6px 0 0' }}>
            Sau khi lưu: quỹ Chuyển khoản ghi thu {formatVND(order.total)} (tổng đơn), chi phí sàn{' '}
            {formatVND(fee)}, chi thuế sàn {formatVND(tax)} — số dư quỹ tăng đúng {formatVND(expectedFromFeeTax)}.
            Trạng thái đơn chuyển thành “{PLATFORM_STATUS_LABEL['da-ve']}”.
          </p>
        </div>
        <button className="btn btn-block" style={{ minHeight: 48 }} disabled={busy} onClick={() => void submit()}>
          {busy ? 'Đang lưu…' : 'Xác nhận đã về tiền'}
        </button>
      </div>
    </Sheet>
  );
}
