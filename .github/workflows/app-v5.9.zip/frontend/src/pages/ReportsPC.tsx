import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { DbError, getAllowedWarehouses, getDailyBreakdown, getRangeReport } from '../lib/db';
import {
  addDaysVN,
  formatDMY,
  formatVND,
  startOfMonthVN,
  startOfWeekVN,
  todayVN,
} from '../lib/format';
import { useToast } from '../components/Toast';
import { DayCloseSheet } from './DayCloseSheet';
import { useAuth } from '../lib/auth';
import { TIcon } from '../components/TIcon';
import type { DailyReport, Warehouse } from '../lib/types';

type PresetKey = 'today' | 'yesterday' | 'thisWeek' | 'lastWeek' | 'thisMonth' | 'lastMonth';

const PRESETS: { key: PresetKey; label: string }[] = [
  { key: 'today', label: 'Hôm nay' },
  { key: 'yesterday', label: 'Hôm qua' },
  { key: 'thisWeek', label: 'Tuần này' },
  { key: 'lastWeek', label: 'Tuần trước' },
  { key: 'thisMonth', label: 'Tháng này' },
  { key: 'lastMonth', label: 'Tháng trước' },
];

function presetRange(key: PresetKey): [string, string] {
  const t = todayVN();
  switch (key) {
    case 'today': return [t, t];
    case 'yesterday': { const y = addDaysVN(t, -1); return [y, y]; }
    case 'thisWeek': return [startOfWeekVN(t), t];
    case 'lastWeek': {
      const mondayThis = startOfWeekVN(t);
      const mondayLast = addDaysVN(mondayThis, -7);
      return [mondayLast, addDaysVN(mondayLast, 6)];
    }
    case 'thisMonth': return [startOfMonthVN(t), t];
    case 'lastMonth': {
      const firstThisMonth = startOfMonthVN(t);
      const lastDayPrev = addDaysVN(firstThisMonth, -1);
      return [startOfMonthVN(lastDayPrev), lastDayPrev];
    }
  }
}

function prevRange(key: PresetKey): [string, string] {
  const t = todayVN();
  switch (key) {
    case 'today': { const y = addDaysVN(t, -1); return [y, y]; }
    case 'yesterday': { const y = addDaysVN(t, -2); return [y, y]; }
    case 'thisWeek': {
      const mondayThis = startOfWeekVN(t);
      const mondayLast = addDaysVN(mondayThis, -7);
      return [mondayLast, addDaysVN(mondayLast, 6)];
    }
    case 'lastWeek': {
      const mondayThis = startOfWeekVN(t);
      const mondayLast2 = addDaysVN(mondayThis, -14);
      return [mondayLast2, addDaysVN(mondayLast2, 6)];
    }
    case 'thisMonth': {
      const firstThisMonth = startOfMonthVN(t);
      const lastDayPrev = addDaysVN(firstThisMonth, -1);
      return [startOfMonthVN(lastDayPrev), lastDayPrev];
    }
    case 'lastMonth': {
      const firstThisMonth = startOfMonthVN(t);
      const lastDayPrev = addDaysVN(firstThisMonth, -1);
      const firstPrev = startOfMonthVN(lastDayPrev);
      const lastDayPrev2 = addDaysVN(firstPrev, -1);
      return [startOfMonthVN(lastDayPrev2), lastDayPrev2];
    }
  }
}

function pctChange(cur: number, prev: number): number | null {
  if (prev === 0) return cur > 0 ? 100 : null;
  return ((cur - prev) / prev) * 100;
}

export function ReportsPC() {
  const toast = useToast();
  const { can, user } = useAuth();
  const navigate = useNavigate();
  const [preset, setPreset] = useState<PresetKey>('today');
  const [report, setReport] = useState<DailyReport | null>(null);
  const [prevReport, setPrevReport] = useState<DailyReport | null>(null);
  const [weekData, setWeekData] = useState<{ date: string; dayLabel: string; thisRevenue: number; thisProfit: number; lastRevenue: number; lastProfit: number }[]>([]);
  const [chartMetric, setChartMetric] = useState<'revenue' | 'profit'>('revenue');
  const [busy, setBusy] = useState(false);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [isOwner, setIsOwner] = useState(false);
  const [dayCloseOpen, setDayCloseOpen] = useState(false);

  const load = useCallback(async (key: PresetKey, ids?: string[]) => {
    setBusy(true);
    try {
      const [s, e] = presetRange(key);
      const [ps, pe] = prevRange(key);
      const t = todayVN();
      const [cur, prev] = await Promise.all([
        getRangeReport(s, e, ids),
        getRangeReport(ps, pe, ids),
      ]);
      setReport(cur);
      setPrevReport(prev);
      // So sánh tuần này vs tuần trước theo từng ngày (T2..CN) — 2 truy vấn gom nhóm
      const mondayThis = startOfWeekVN(t);
      const mondayLast = addDaysVN(mondayThis, -7);
      const sundayThis = addDaysVN(mondayThis, 6);
      const sundayLast = addDaysVN(mondayLast, 6);
      const dayLabels = ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'];
      const [thisWeekDays, lastWeekDays] = await Promise.all([
        getDailyBreakdown(mondayThis, sundayThis, ids),
        getDailyBreakdown(mondayLast, sundayLast, ids),
      ]);
      setWeekData(dayLabels.map((dayLabel, i) => ({
        date: addDaysVN(mondayThis, i),
        dayLabel,
        thisRevenue: thisWeekDays[i]?.revenue ?? 0,
        thisProfit: thisWeekDays[i]?.profit ?? 0,
        lastRevenue: lastWeekDays[i]?.revenue ?? 0,
        lastProfit: lastWeekDays[i]?.profit ?? 0,
      })));
    } catch (err) {
      toast.show(err instanceof DbError ? err.message : 'Không tải được báo cáo');
    } finally {
      setBusy(false);
    }
  }, [toast]);

  useEffect(() => {
    getAllowedWarehouses()
      .then(({ warehouses: ws, isOwner: ow }) => {
        setWarehouses(ws);
        setIsOwner(ow);
        const ids = ow ? undefined : ws.map((w) => w.id);
        void load('today', ids);
      })
      .catch(() => { void load('today'); });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const pickPreset = (key: PresetKey) => {
    setPreset(key);
    const ids = isOwner ? undefined : warehouses.map((w) => w.id);
    void load(key, ids);
  };

  const kpis = useMemo(() => {
    if (!report) return [];
    const p = prevReport;
    return [
      { label: 'Doanh thu', value: formatVND(report.revenue), icon: '💰', bg: '#EFF4FF', change: p ? pctChange(report.revenue, p.revenue) : null },
      { label: 'Lợi nhuận', value: formatVND(report.profit), icon: '📈', bg: '#ECFDF5', change: p ? pctChange(report.profit, p.profit) : null },
      { label: 'Số đơn', value: String(report.order_count), icon: '🧾', bg: '#F5F0FF', change: p ? pctChange(report.order_count, p.order_count) : null },
      { label: 'TB/đơn', value: formatVND(Math.round(report.avg_order)), icon: '🧮', bg: '#FFFBEB', change: p ? pctChange(report.avg_order, p.avg_order) : null },
    ];
  }, [report, prevReport]);

  const maxWeekValue = Math.max(1, ...weekData.map((d) =>
    chartMetric === 'revenue' ? Math.max(d.thisRevenue, d.lastRevenue) : Math.max(d.thisProfit, d.lastProfit)
  ));
  const weekThisTotal = weekData.reduce((s, d) => s + (chartMetric === 'revenue' ? d.thisRevenue : d.thisProfit), 0);
  const weekLastTotal = weekData.reduce((s, d) => s + (chartMetric === 'revenue' ? d.lastRevenue : d.lastProfit), 0);
  const topProducts = useMemo(() => (report?.top_products ?? []).slice(0, 8), [report]);

  // Khung "Top món theo doanh thu": xếp theo DOANH THU thật trên toàn bộ món,
  // tỉ lệ tính trên tổng doanh thu mọi món. (Trước đây lấy nhầm nhóm top theo
  // SỐ LƯỢNG nên món doanh thu cao nhưng bán ít không lọt vào khung này.)
  const catData = useMemo(() => {
    const all = report?.top_products ?? [];
    const total = all.reduce((s, p) => s + p.revenue, 0) || 1;
    return [...all]
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 5)
      .map((p, i) => ({
        name: p.name,
        value: p.revenue,
        pct: (p.revenue / total) * 100,
        color: ['#00B14F', '#00D15F', '#10B981', '#F59E0B', '#9CA3AF'][i % 5],
      }));
  }, [report]);

  if (!can('reports')) {
    return <div className="page"><div className="card">🔒 Chỉ Quản lý trở lên mới được xem báo cáo.</div></div>;
  }

  return (
    <div className="pc-ov">
      {/* Top bar PC */}
      <div className="pc-ov-topbar">
        <h1>Tổng quan</h1>
        <div className="pc-ov-topbar-right">
          <select value={preset} onChange={(e) => pickPreset(e.target.value as PresetKey)} className="pc-select" aria-label="Chọn kỳ">
            {PRESETS.map((p) => <option key={p.key} value={p.key}>{p.label}</option>)}
          </select>
          <button className="pc-btn-primary" onClick={() => setDayCloseOpen(true)}>
            <TIcon emoji="💰" size={16} /> Chốt két
          </button>
          <span className="pc-user">{user?.full_name || user?.email}</span>
        </div>
      </div>

      {/* 4 KPI cards */}
      <div className="pc-kpis">
        {kpis.map((k) => (
          <div className="pc-kpi" key={k.label}>
            <div className="pc-kpi-icon" style={{ background: k.bg }}><TIcon emoji={k.icon} size={24} /></div>
            <div className="pc-kpi-info">
              <div className="pc-kpi-label">{k.label}</div>
              <div className="pc-kpi-value">{busy && !report ? '…' : k.value}</div>
              {k.change !== null && k.change !== undefined && (
                <div className={`pc-kpi-change ${k.change >= 0 ? 'up' : 'down'}`}>
                  {k.change >= 0 ? '↑' : '↓'} {Math.abs(Math.round(k.change))}% so với kỳ trước
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Chart + Donut */}
      <div className="pc-ov-grid2">
        <div className="pc-card">
          <div className="pc-card-head">
            <h3>Tuần này so với tuần trước</h3>
            <div className="ov-metric-toggle">
              <button
                className={chartMetric === 'revenue' ? 'active' : ''}
                onClick={() => setChartMetric('revenue')}
              >Doanh thu</button>
              <button
                className={chartMetric === 'profit' ? 'active' : ''}
                onClick={() => setChartMetric('profit')}
              >Lợi nhuận</button>
            </div>
          </div>
          <div className="ov-week-summary" style={{ padding: '0 20px' }}>
            <div className="ov-week-item">
              <span className="ov-week-dot" style={{ background: '#00B14F' }} />
              <span>Tuần này: <b>{formatVND(weekThisTotal)}</b></span>
            </div>
            <div className="ov-week-item">
              <span className="ov-week-dot" style={{ background: '#CBD5E1' }} />
              <span>Tuần trước: <b>{formatVND(weekLastTotal)}</b></span>
            </div>
          </div>
          <div className="pc-chart">
            {weekData.map((d) => {
              const thisVal = chartMetric === 'revenue' ? d.thisRevenue : d.thisProfit;
              const lastVal = chartMetric === 'revenue' ? d.lastRevenue : d.lastProfit;
              return (
                <div className="pc-bar-col" key={d.date}
                  title={`${d.dayLabel} ${formatDMY(d.date)} — Tuần này: ${formatVND(thisVal)}, tuần trước: ${formatVND(lastVal)}`}
                  style={{ cursor: 'pointer' }}
                  onClick={() => toast.show(`${d.dayLabel} ${formatDMY(d.date)} — ${chartMetric === 'revenue' ? 'Doanh thu' : 'Lợi nhuận'}: tuần này ${formatVND(thisVal)}, tuần trước ${formatVND(lastVal)}`)}>
                  <div className="pc-bar-track" style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'center', gap: 5 }}>
                    <div className="pc-bar" style={{
                      height: `${Math.max(3, Math.round((thisVal / maxWeekValue) * 100))}%`,
                      background: '#00B14F', width: 18,
                    }} />
                    <div className="pc-bar" style={{
                      height: `${Math.max(3, Math.round((lastVal / maxWeekValue) * 100))}%`,
                      background: '#CBD5E1', width: 18,
                    }} />
                  </div>
                  <div className="pc-bar-label">{d.dayLabel}</div>
                </div>
              );
            })}
          </div>
        </div>
        <div className="pc-card">
          <div className="pc-card-head"><h3>Top món theo doanh thu</h3></div>
          <div className="pc-donut-wrap">
            <div className="pc-cat-list">
              {catData.map((c) => (
                <div className="pc-cat-row" key={c.name}>
                  <span className="pc-dot" style={{ background: c.color }} />
                  <span className="pc-cat-name">{c.name}</span>
                  <span className="pc-cat-val">{formatVND(c.value)}</span>
                  <span className="pc-cat-pct">{c.pct.toFixed(1)}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Bảng món bán chạy */}
      <div className="pc-card">
        <div className="pc-card-head">
          <h3>Món bán chạy</h3>
          <button className="pc-link" onClick={() => navigate('/pos')}>Bán hàng →</button>
        </div>
        <table className="pc-table">
          <thead>
            <tr>
              <th>#</th>
              <th>Món</th>
              <th className="r">Số lượng</th>
              <th className="r">Doanh thu</th>
              <th className="r">Giá vốn</th>
              <th className="r">Lợi nhuận gộp</th>
            </tr>
          </thead>
          <tbody>
            {topProducts.map((p, i) => (
              <tr key={p.product_id}>
                <td>{i + 1}</td>
                <td><b>{p.name}</b></td>
                <td className="r">{p.qty}</td>
                <td className="r">{formatVND(p.revenue)}</td>
                <td className="r">{formatVND(p.cost)}</td>
                <td className="r" style={{ color: '#16A34A', fontWeight: 600 }}>{formatVND(p.profit)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {topProducts.length === 0 && <p className="muted small" style={{ padding: 12 }}>Chưa có dữ liệu</p>}
      </div>

      {dayCloseOpen && <DayCloseSheet onClose={() => setDayCloseOpen(false)} />}
    </div>
  );
}
