import { LineIcon } from './LineIcon';
import { useAppTheme } from '../lib/useAppTheme';

// Icon tự đổi theo theme: v3 dùng lineal SVG, v1/v2 dùng emoji như cũ.
// Dùng cho các nút và tiêu đề: <TIcon emoji="🖨️" line="print" />
// Thêm icon mới vào LINE_ICONS khi cần.
const LINE_ICONS: Record<string, string> = {
  '🖨️': 'receipt', // in
  '📋': 'clipboard',
  '✏️': 'edit',
  '🗑️': 'trash',
  '💾': 'save',
  '➕': 'plus',
  '📦': 'package',
  '📊': 'chart',
  '💰': 'wallet',
  '⚙️': 'gear',
  '🔍': 'search',
  '📥': 'truck',
  '📤': 'truck',
  '🧾': 'receipt',
  '💳': 'card',
  '🏭': 'archive',
  '🔄': 'refresh',
  '📝': 'edit',
  '❌': 'x',
  '✅': 'check',
  '👥': 'users',
  '📒': 'ledger',
  '🌐': 'globe',
  '🗃️': 'archive',
  '📜': 'scroll',
  '🔑': 'key',
  '🧪': 'flask',
  '💵': 'wallet',
  '📱': 'phone',
};

export function TIcon({
  emoji,
  size = 18,
  style,
}: {
  emoji: string;
  size?: number;
  style?: React.CSSProperties;
}) {
  const theme = useAppTheme();
  if (theme === 'v3') {
    const lineName = LINE_ICONS[emoji];
    if (lineName) return <LineIcon name={lineName} size={size} style={style} />;
  }
  return (
    <span style={{ fontSize: size, lineHeight: 1, ...style }} aria-hidden>
      {emoji}
    </span>
  );
}
