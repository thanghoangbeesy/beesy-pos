// Lưu bill thành ảnh PNG và gửi bill qua Zalo.
// html2canvas được import động — chỉ tải về khi bấm nút, không làm nặng
// bundle chính của app.
import { formatVND } from './format';
import type { Order } from './types';
import { isSplitPayment, orderPaymentSplits } from './types';

/** Chụp vùng bill đang hiển thị (#bill-capture) thành ảnh PNG (nét gấp đôi). */
export async function captureBillImage(): Promise<Blob> {
  const el = document.getElementById('bill-capture');
  if (!el) throw new Error('Không tìm thấy hóa đơn để chụp.');

  // Mã QR VietQR là ảnh từ máy chủ ngoài (img.vietqr.io). Thư viện chụp ảnh
  // (html2canvas) chụp trên một BẢN SAO của trang và phải tải lại ảnh QR trong
  // bản sao — bước tải lại này trên điện thoại hay chậm/lỗi nên ảnh bill ra bị
  // TRỐNG đúng chỗ mã QR (đã gặp thực tế 22/10). Khắc phục: tải QR về trước,
  // đổi thành data URL (không cần mạng, không dính CORS) rồi nhét vào bản sao
  // qua onclone — QR luôn hiện trong ảnh chụp.
  let qrDataUrl: string | null = null;
  const qrImg = el.querySelector<HTMLImageElement>('img[alt="QR thanh toán"]');
  const qrSrc = qrImg?.getAttribute('src') || '';
  if (qrSrc && !qrSrc.startsWith('data:')) {
    try {
      const res = await fetch(qrSrc);
      if (res.ok) {
        const blob = await res.blob();
        qrDataUrl = await new Promise<string>((resolve, reject) => {
          const fr = new FileReader();
          fr.onload = () => resolve(String(fr.result));
          fr.onerror = () => reject(new Error('Không đọc được ảnh QR.'));
          fr.readAsDataURL(blob);
        });
      }
    } catch {
      qrDataUrl = null; // tải QR lỗi thì để thư viện tự thử như cũ
    }
  }

  const { default: html2canvas } = await import('html2canvas');
  const canvas = await html2canvas(el, {
    backgroundColor: '#ffffff',
    scale: 2,
    useCORS: true,
    logging: false,
    onclone: (clonedDoc) => {
      if (qrDataUrl) {
        const clonedQr = clonedDoc.querySelector<HTMLImageElement>(
          '#bill-capture img[alt="QR thanh toán"]',
        );
        if (clonedQr) clonedQr.src = qrDataUrl;
      }
    },
  });
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (b) => (b ? resolve(b) : reject(new Error('Không tạo được ảnh hóa đơn.'))),
      'image/png',
    );
  });
}

export function downloadImage(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

/** Lưu ảnh bill xuống máy (tên file bill-<mã đơn>.png). */
export async function saveBillImage(orderCode: string): Promise<void> {
  const blob = await captureBillImage();
  downloadImage(blob, `bill-${orderCode}.png`);
}

export type ShareBillResult = 'shared' | 'fallback';

/**
 * Gửi bill qua Zalo bằng hộp chia sẻ của hệ điều hành: chọn Zalo, chọn người
 * nhận là gửi kèm ảnh bill. Máy/trình duyệt không hỗ trợ chia sẻ file thì tải
 * ảnh xuống máy + chép nội dung bill dạng chữ để dán vào Zalo (trả 'fallback').
 */
export async function shareBillImage(orderCode: string, billText: string): Promise<ShareBillResult> {
  const blob = await captureBillImage();
  const file = new File([blob], `bill-${orderCode}.png`, { type: 'image/png' });
  const nav = navigator as Navigator & { canShare?: (data: ShareData) => boolean };
  if (nav.canShare && nav.canShare({ files: [file] })) {
    await nav.share({ files: [file], title: `Hóa đơn ${orderCode}`, text: billText });
    return 'shared';
  }
  downloadImage(blob, `bill-${orderCode}.png`);
  try {
    await navigator.clipboard.writeText(billText);
  } catch {
    /* clipboard không khả dụng thì bỏ qua */
  }
  return 'fallback';
}

/** Nội dung bill dạng chữ — đính kèm khi chia sẻ hoặc dán vào Zalo. */
export function buildBillText(order: Order, shopName: string): string {
  const lines: string[] = [];
  lines.push(shopName);
  lines.push(`Hóa đơn ${order.code}`);
  lines.push('------------------------------');
  for (const it of order.items) {
    lines.push(`${it.qty} x ${it.product_name}: ${formatVND(it.line_total)}`);
    for (const m of it.modifiers || []) {
      lines.push(`   + ${m.option}${m.price_delta ? ` (+${formatVND(m.price_delta)})` : ''}`);
    }
    if (it.note) lines.push(`   Ghi chú: ${it.note}`);
  }
  lines.push('------------------------------');
  if (order.discount > 0) lines.push(`Giảm giá: -${formatVND(order.discount)}`);
  lines.push(`Tổng cộng: ${formatVND(order.total)}`);
  if (isSplitPayment(order)) {
    for (const sp of orderPaymentSplits(order)) {
      lines.push(`${sp.method_name}: ${formatVND(sp.amount)}`);
    }
  } else {
    lines.push(`Thanh toán: ${order.payment_method_name ?? order.payment_method}`);
    if (order.payment_method === 'cash' && order.amount_received != null) {
      lines.push(`Khách đưa: ${formatVND(order.amount_received)} - Thối lại: ${formatVND(order.change_amount ?? 0)}`);
    }
  }
  if (order.note) lines.push(`Ghi chú: ${order.note}`);
  lines.push('Cảm ơn quý khách!');
  return lines.join('\n');
}

/** Chuẩn hóa SĐT VN sang dạng link Zalo (84...). */
export function zaloPhone(phone: string): string {
  let p = (phone || '').replace(/\D/g, '');
  if (p.startsWith('0')) p = '84' + p.slice(1);
  return p;
}
