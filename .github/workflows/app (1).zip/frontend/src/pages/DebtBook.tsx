// Sổ nợ — thao tác nhanh kiểu "Tôi đã đưa / Tôi đã nhận".
// Dùng dữ liệu công nợ sẵn có (Customer.debt + adjustDebt trong lib/db.ts).
import { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { DbError, addCashbookEntry, adjustDebt, getFunds, searchCustomers } from '../lib/db';
import { formatVND, unsignVietnamese } from '../lib/format';
import { Sheet } from '../components/Sheet';
import { PageHead } from '../components/PageHead';
import { useToast } from '../components/Toast';
import type { Customer, Fund } from '../lib/types';

export function DebtBook() {
  const navigate = useNavigate();
  const toast = useToast();
  const [list, setList] = useState<Customer[]>([]);
  const [q, setQ] = useState('');
  const [busy, setBusy] = useState(true);
  const [sheet, setSheet] = useState<'give' | 'receive' | null>(null);

  const load = useCallback(async () => {
    setBusy(true);
    try {
      const all = await searchCustomers('');
      setList(all.filter((c) => c.debt > 0));
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tải được sổ nợ');
    } finally {
      setBusy(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const needle = unsignVietnamese(q.trim()).toLowerCase();
  const filtered = needle
    ? list.filter((c) => unsignVietnamese(`${c.name} ${c.phone}`).toLowerCase().includes(needle))
    : list;
  const total = list.reduce((s, c) => s + c.debt, 0);

  return (
    <div className="page with-dual-actions">
      <PageHead title="Sổ nợ" back />

      <div className="sb-search" style={{ marginBottom: 12 }}>
        <span className="sico">🔍</span>
        <input
          placeholder="Tìm tên, số điện thoại…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          aria-label="Tìm khách nợ"
        />
      </div>

      <div className="sb-section" style={{ marginBottom: 12, textAlign: 'center' }}>
        <div className="small muted">Tổng công nợ cần thu</div>
        <div className="money text-orange" style={{ fontSize: 32, margin: '4px 0' }}>
          {formatVND(total)}
        </div>
        <div className="small muted">{list.length} khách đang nợ</div>
      </div>

      <div className="sb-section" style={{ padding: '4px 16px' }}>
        {busy ? (
          <p className="muted" style={{ textAlign: 'center' }}>
            Đang tải…
          </p>
        ) : filtered.length === 0 ? (
          <div className="sb-empty">
            <div className="eico">📒</div>
            <p>
              Chưa có khoản nợ nào.
              <br />
              Ghi chép rõ ràng, thu hồi dễ dàng.
            </p>
          </div>
        ) : (
          filtered.map((c) => (
            <button key={c.id} className="sb-row" onClick={() => navigate('/customers')}>
              <span className="avatar">{c.name.charAt(0).toUpperCase()}</span>
              <span className="rbody">
                <span className="rtitle">{c.name}</span>
                <span className="rsub">{c.phone}</span>
              </span>
              <span className="ramount text-orange">{formatVND(c.debt)}</span>
              <span className="chev muted" style={{ fontSize: 22 }}>›</span>
            </button>
          ))
        )}
      </div>

      <div className="sb-dual-actions">
        <div className="inner">
          <button className="btn sb-btn-orange btn-block btn-lg" onClick={() => setSheet('give')}>
            Tôi đã đưa
          </button>
          <button className="btn btn-block btn-lg" onClick={() => setSheet('receive')}>
            Tôi đã nhận
          </button>
        </div>
      </div>

      {sheet && (
        <DebtSheet
          mode={sheet}
          onClose={() => setSheet(null)}
          onDone={() => {
            setSheet(null);
            void load();
          }}
        />
      )}
    </div>
  );
}

function DebtSheet({
  mode,
  onClose,
  onDone,
}: {
  mode: 'give' | 'receive';
  onClose: () => void;
  onDone: () => void;
}) {
  const toast = useToast();
  const [q, setQ] = useState('');
  const [results, setResults] = useState<Customer[]>([]);
  const [searched, setSearched] = useState(false);
  const [selected, setSelected] = useState<Customer | null>(null);
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [funds, setFunds] = useState<Fund[]>([]);
  const [fundId, setFundId] = useState('cash');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    // Thu nợ = tiền về quỹ → cần chọn quỹ nhận (chỉ ở chế độ "Tôi đã nhận")
    if (mode !== 'receive') return;
    getFunds()
      .then((fl) => {
        const act = fl.filter((f) => f.active);
        setFunds(act);
        if (!act.some((f) => f.id === fundId) && act[0]) setFundId(act[0].id);
      })
      .catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode]);

  const doSearch = async () => {
    setBusy(true);
    try {
      const r = await searchCustomers(q.trim());
      setResults(r);
      setSearched(true);
      if (r.length === 0) toast.show('Không tìm thấy khách hàng');
    } catch {
      toast.show('Không tìm được, kiểm tra mạng');
    } finally {
      setBusy(false);
    }
  };

  const submit = async () => {
    if (!selected) {
      toast.show('Hãy chọn khách hàng trước');
      return;
    }
    const v = parseInt(amount.replace(/\D/g, ''), 10);
    if (!v || v <= 0) {
      toast.show('Nhập số tiền hợp lệ');
      return;
    }
    setBusy(true);
    try {
      const finalNote = note.trim() || (mode === 'receive' ? `Thu nợ — ${selected.name}` : null);
      await adjustDebt(selected.id, mode === 'give' ? v : -v, finalNote);
      // Thu nợ = tiền về quỹ → tự ghi vào sổ quỹ (ghi nợ thêm thì không, vì chưa thu tiền)
      if (mode === 'receive') {
        try {
          await addCashbookEntry('thu', v, finalNote, 'Thu nợ', {
            refType: 'debt_pay',
            refId: selected.id,
            method: funds.find((f) => f.id === fundId)?.kind === 'transfer' ? 'transfer' : 'cash',
            fundId,
          });
        } catch (e) {
          // Nợ đã thu thành công, chỉ ghi quỹ thất bại → báo để nhập tay, không rollback nợ
          toast.show(
            `Đã thu ${formatVND(v)} nhưng chưa ghi được vào sổ quỹ — hãy nhập tay.`,
          );
        }
      }
      toast.show(
        mode === 'give'
          ? `Đã ghi nợ ${formatVND(v)} cho ${selected.name}`
          : `Đã thu ${formatVND(v)} của ${selected.name}`,
      );
      onDone();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet
      title={mode === 'give' ? 'Tôi đã đưa (ghi nợ)' : 'Tôi đã nhận (thu nợ)'}
      onClose={onClose}
      footer={
        <button
          className={`btn btn-block btn-lg${mode === 'give' ? ' sb-btn-orange' : ''}`}
          disabled={busy}
          onClick={submit}
        >
          {busy ? 'Đang lưu…' : 'Xác nhận'}
        </button>
      }
    >
      {!selected ? (
        <>
          <div className="row" style={{ marginBottom: 12 }}>
            <div className="sb-search grow">
              <span className="sico">🔍</span>
              <input
                placeholder="Nhập tên hoặc SĐT…"
                value={q}
                onChange={(e) => setQ(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && doSearch()}
              />
            </div>
            <button className="btn" style={{ minHeight: 44 }} onClick={doSearch} disabled={busy}>
              Tìm
            </button>
          </div>
          {results.map((c) => (
            <button key={c.id} className="sb-row" onClick={() => setSelected(c)}>
              <span className="avatar">{c.name.charAt(0).toUpperCase()}</span>
              <span className="rbody">
                <span className="rtitle">{c.name}</span>
                <span className="rsub">{c.phone}</span>
              </span>
              <span className={`ramount ${c.debt > 0 ? 'text-orange' : ''}`}>
                {c.debt > 0 ? formatVND(c.debt) : <span className="muted">—</span>}
              </span>
            </button>
          ))}
          {searched && results.length === 0 && (
            <p className="muted small" style={{ textAlign: 'center' }}>
              Không tìm thấy khách hàng
            </p>
          )}
        </>
      ) : (
        <>
          <button className="sb-row" onClick={() => setSelected(null)} aria-label="Đổi khách hàng">
            <span className="avatar">{selected.name.charAt(0).toUpperCase()}</span>
            <span className="rbody">
              <span className="rtitle">{selected.name}</span>
              <span className="rsub">
                {selected.phone} · đang nợ {formatVND(selected.debt)}
              </span>
            </span>
            <span className="text-green" style={{ fontWeight: 600 }}>
              Đổi ›
            </span>
          </button>
          <div className="field" style={{ marginTop: 12 }}>
            <label>Số tiền</label>
            <input
              className="sb-money-input"
              inputMode="numeric"
              placeholder="0"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              autoFocus
            />
          </div>
          <div className="field">
            <label>Ghi chú (không bắt buộc)</label>
            <input
              className="input"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="VD: tiền nước tuần này…"
            />
          </div>
          {mode === 'receive' && funds.length > 1 && (
            <div className="field">
              <label>Tiền vào quỹ</label>
              <div className="row" style={{ flexWrap: 'wrap', gap: 8 }}>
                {funds.map((f) => (
                  <button
                    key={f.id}
                    type="button"
                    className={`sb-chip${fundId === f.id ? ' selected' : ''}`}
                    onClick={() => setFundId(f.id)}
                  >
                    {f.name}
                  </button>
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </Sheet>
  );
}
