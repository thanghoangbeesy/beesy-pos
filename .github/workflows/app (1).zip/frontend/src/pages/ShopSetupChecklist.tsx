// Checklist setup quán mới — dành cho Hoàng khi triển khai cho khách.
// Lưu tiến độ vào localStorage (theo trình duyệt).
import { useState } from 'react';
import { Navigate } from 'react-router-dom';
import { PageHead } from '../components/PageHead';
import { useAuth } from '../lib/auth';

interface Step {
  id: string;
  title: string;
  detail?: string;
  link?: string;
}

interface Phase {
  title: string;
  icon: string;
  steps: Step[];
}

const PHASES: Phase[] = [
  {
    title: 'Firebase project mới',
    icon: '🔥',
    steps: [
      {
        id: 'fb-project',
        title: 'Tạo project mới',
        detail: 'console.firebase.google.com → Add project → đặt tên (VD: beesy-quan-a) → TẮT Google Analytics.',
        link: 'https://console.firebase.google.com',
      },
      {
        id: 'fb-auth',
        title: 'Bật Authentication',
        detail: 'Build → Authentication → Sign-in method → bật Email/Password.',
      },
      {
        id: 'fb-firestore',
        title: 'Tạo Firestore Database',
        detail: 'Build → Firestore Database → Create database → region asia-southeast1 → Start in production mode.',
      },
      {
        id: 'fb-hosting',
        title: 'Tạo Hosting site',
        detail: 'Build → Hosting → Get started → tạo site (VD: beesy-quan-a).',
      },
      {
        id: 'fb-rules',
        title: 'Dán Firestore rules',
        detail: 'Firestore → Rules → xóa hết → dán toàn bộ file firestore.rules (trong app.zip) → Publish.',
      },
      {
        id: 'fb-indexes',
        title: 'Tạo indexes',
        detail: 'Firestore → Indexes → Add index: collection online_orders, fields status (ASC) + created_at (DESC). Hoặc deploy từ file firestore.indexes.json.',
      },
    ],
  },
  {
    title: 'GitHub + Deploy',
    icon: '🐙',
    steps: [
      {
        id: 'gh-repo',
        title: 'Tạo repo mới',
        detail: 'github.com → New repository (VD: beesy-quan-a) → tạo file .github/workflows/deploy.yml (copy từ source).',
        link: 'https://github.com/new',
      },
      {
        id: 'gh-zip',
        title: 'Upload app.zip',
        detail: 'Trong repo: Add file → Upload files → chọn app.zip bản mới nhất → Commit.',
      },
      {
        id: 'gh-secrets',
        title: 'Thêm secrets',
        detail: 'Settings → Secrets → Actions → thêm: FIREBASE_SERVICE_ACCOUNT (JSON key từ Project settings → Service accounts), FIREBASE_PROJECT_ID, và 6 giá trị VITE_FIREBASE_* (từ Project settings → Your apps → Web app).',
      },
      {
        id: 'gh-deploy',
        title: 'Chạy workflow Deploy',
        detail: 'Tab Actions → Deploy to Firebase → Run workflow → đợi xanh.',
      },
    ],
  },
  {
    title: 'Cấu hình quán',
    icon: '⚙️',
    steps: [
      {
        id: 'cfg-owner',
        title: 'Tạo chủ quán',
        detail: 'Mở https://<site>.web.app/setup → tạo tài khoản chủ quán.',
      },
      {
        id: 'cfg-menu',
        title: 'Nạp menu mẫu',
        detail: 'Ở /setup: chọn ngành nghề (trà sữa/cà phê, ăn vặt, cơm/bún/phở) → nạp menu mẫu.',
      },
      {
        id: 'cfg-brand',
        title: 'Đổi tên/logo/màu',
        detail: 'Cài đặt → Thông tin quán (tên, link đặt hàng) + Thương hiệu (logo, màu).',
      },
      {
        id: 'cfg-license',
        title: 'Tạo license key',
        detail: 'Cài đặt → Giấy phép sử dụng → tạo mã theo gói đã bán → gửi cho chủ quán nhập để kích hoạt.',
      },
      {
        id: 'cfg-qr',
        title: 'In QR đặt hàng',
        detail: 'Cài đặt → Thông tin quán → copy link + QR /dat-hang → in dán tại quầy.',
      },
    ],
  },
  {
    title: 'Kiểm tra + Bàn giao',
    icon: '✅',
    steps: [
      {
        id: 'test-pos',
        title: 'Test bán 1 đơn',
        detail: 'Bán thử 1 đơn ở POS → KDS hiện → báo cáo đúng số.',
      },
      {
        id: 'test-online',
        title: 'Test đặt online',
        detail: 'Mở /dat-hang trên điện thoại khác (không đăng nhập) → đặt thử → duyệt ở KDS.',
      },
      {
        id: 'test-notify',
        title: 'Test thông báo',
        detail: 'Ở màn Pha chế: bấm "📢 Bật thông báo" → đặt đơn test → kiểm tra chuông + thông báo hiện.',
      },
      {
        id: 'handover',
        title: 'Bàn giao',
        detail: 'Giao tài khoản chủ quán + hướng dẫn cơ bản. Nhắc bật Sao lưu định kỳ (Cài đặt).',
      },
    ],
  },
];

const LS_KEY = 'beesy_shop_setup_checklist';

function loadChecked(): Record<string, boolean> {
  try {
    return JSON.parse(localStorage.getItem(LS_KEY) ?? '{}');
  } catch {
    return {};
  }
}

export function ShopSetupChecklist() {
  const { user } = useAuth();
  const [checked, setChecked] = useState<Record<string, boolean>>(loadChecked);
  const [openPhase, setOpenPhase] = useState<number>(0);

  const toggle = (id: string) => {
    setChecked((prev) => {
      const next = { ...prev, [id]: !prev[id] };
      try {
        localStorage.setItem(LS_KEY, JSON.stringify(next));
      } catch {
        /* bo qua */
      }
      return next;
    });
  };

  const total = PHASES.reduce((s, p) => s + p.steps.length, 0);
  const done = Object.values(checked).filter(Boolean).length;
  const pct = Math.round((done / total) * 100);

  if (user && user.role !== 'owner') return <Navigate to="/" replace />;

  const reset = () => {
    if (!window.confirm('Xóa hết tiến độ checklist?')) return;
    setChecked({});
    try {
      localStorage.removeItem(LS_KEY);
    } catch {
      /* bo qua */
    }
  };

  return (
    <div className="page">
      <PageHead title="Checklist setup quán mới" back />
      <div className="card" style={{ marginBottom: 12 }}>
        <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
          <div style={{ fontWeight: 700 }}>
            Tiến độ: {done}/{total} ({pct}%)
          </div>
          <button type="button" className="sb-chip" style={{ minHeight: 36 }} onClick={reset}>
            🔄 Làm lại
          </button>
        </div>
        <div style={{ height: 10, borderRadius: 5, background: 'var(--border)', overflow: 'hidden' }}>
          <div
            style={{
              height: '100%',
              width: `${pct}%`,
              background: 'var(--brand)',
              borderRadius: 5,
              transition: 'width 0.3s',
            }}
          />
        </div>
        <p className="small muted" style={{ margin: '8px 0 0' }}>
          Dành cho chủ Beesy khi triển khai quán mới. Tick từng bước khi xong — tiến độ lưu trên máy này.
        </p>
      </div>

      {PHASES.map((phase, pi) => {
        const phaseDone = phase.steps.filter((st) => checked[st.id]).length;
        const open = openPhase === pi;
        return (
          <div className="card" key={phase.title} style={{ marginBottom: 10 }}>
            <button
              type="button"
              className="sb-menu-row"
              style={{ width: '100%', textAlign: 'left' }}
              onClick={() => setOpenPhase(open ? -1 : pi)}
            >
              <span style={{ fontSize: 22 }}>{phase.icon}</span>
              <span style={{ fontWeight: 700, flex: 1 }}>
                {phase.title}{' '}
                <span className="small muted">
                  ({phaseDone}/{phase.steps.length})
                </span>
              </span>
              <span>{open ? '▾' : '▸'}</span>
            </button>
            {open && (
              <div style={{ paddingTop: 8 }}>
                {phase.steps.map((st, si) => (
                  <label
                    key={st.id}
                    style={{
                      display: 'flex',
                      gap: 10,
                      padding: '10px 4px',
                      borderTop: si > 0 ? '1px solid var(--border)' : undefined,
                      cursor: 'pointer',
                      opacity: checked[st.id] ? 0.6 : 1,
                    }}
                  >
                    <input
                      type="checkbox"
                      checked={!!checked[st.id]}
                      onChange={() => toggle(st.id)}
                      style={{ width: 22, height: 22, marginTop: 2, flexShrink: 0 }}
                    />
                    <div style={{ flex: 1 }}>
                      <div
                        style={{
                          fontWeight: 600,
                          textDecoration: checked[st.id] ? 'line-through' : undefined,
                        }}
                      >
                        {si + 1}. {st.title}
                      </div>
                      {st.detail && (
                        <p className="small muted" style={{ margin: '4px 0 0' }}>
                          {st.detail}
                        </p>
                      )}
                      {st.link && (
                        <a
                          href={st.link}
                          target="_blank"
                          rel="noreferrer"
                          className="small"
                          onClick={(e) => e.stopPropagation()}
                        >
                          Mở link ↗
                        </a>
                      )}
                    </div>
                  </label>
                ))}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
