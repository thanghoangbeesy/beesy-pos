declare const __APP_VERSION__: string;
import { useState } from 'react';
import type { FormEvent } from 'react';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import { sendPasswordResetEmail } from 'firebase/auth';
import { auth } from '../lib/firebase';
import { useAuth } from '../lib/auth';
import { DbError } from '../lib/db';

export function Login() {
  const { user, login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [forgotMode, setForgotMode] = useState(false);
  const [forgotSent, setForgotSent] = useState(false);
  const [forgotBusy, setForgotBusy] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [remember, setRemember] = useState(() => {
    try { return localStorage.getItem('beesy-remember') !== '0'; } catch { return true; }
  });

  if (user) return <Navigate to="/pos" replace />;

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password) {
      setErr('Vui lòng nhập email và mật khẩu');
      return;
    }
    setBusy(true);
    setErr('');
    try {
      try { localStorage.setItem('beesy-remember', remember ? '1' : '0'); } catch { /* bỏ qua */ }
      await login(email.trim(), password, remember);
      navigate('/pos', { replace: true });
    } catch (ex) {
      setErr(ex instanceof DbError ? ex.message : 'Đăng nhập thất bại, thử lại sau');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="login-wrap">
      <div className="card login-card">
        <div className="login-logo">
          <img src="/coffee-cup.svg" alt="Beesy POS" />
          <h1>Beesy POS</h1>
          <div className="muted">Phần mềm quản lý bán hàng cho cửa hàng F&B</div>
        </div>
        {err && <div className="err">{err}</div>}
        <form onSubmit={submit}>
          <div className="sb-float">
            <label htmlFor="u">Email</label>
            <input
              id="u"
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="VD: admin@beesy.local"
            />
          </div>
          <div className="sb-float" style={{ position: 'relative' }}>
            <label htmlFor="p">Mật khẩu</label>
            <input
              id="p"
              type={showPassword ? 'text' : 'password'}
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••"
              style={{ paddingRight: 44 }}
            />
            <button
              type="button"
              aria-label={showPassword ? 'Ẩn mật khẩu' : 'Hiện mật khẩu'}
              onClick={() => setShowPassword((v) => !v)}
              style={{
                position: 'absolute', right: 6, bottom: 6, width: 36, height: 36,
                border: 'none', background: 'transparent', cursor: 'pointer', fontSize: 18,
              }}
            >
              {showPassword ? '🙈' : '👁️'}
            </button>
          </div>
          <label className="login-remember">
            <input
              type="checkbox"
              checked={remember}
              onChange={(e) => setRemember(e.target.checked)}
            />
            <span>Duy trì đăng nhập</span>
          </label>
          <button type="submit" className="btn btn-block btn-lg" disabled={busy}>
            {busy ? 'Đang đăng nhập…' : 'Đăng nhập'}
          </button>
        </form>
        {forgotMode ? (
          <div style={{ marginTop: 14 }}>
            <p className="muted small" style={{ margin: '0 0 8px' }}>
              Nhập email tài khoản, hệ thống sẽ gửi link đặt lại mật khẩu về email đó.
            </p>
            {forgotSent ? (
              <div className="ok-box" style={{ marginBottom: 10 }}>
                ✅ Đã gửi email đặt lại mật khẩu. Anh/chị mở email và làm theo hướng dẫn nhé
                (kiểm tra cả mục Spam nếu không thấy).
              </div>
            ) : (
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  if (!email.trim()) {
                    setErr('Vui lòng nhập email tài khoản.');
                    return;
                  }
                  setForgotBusy(true);
                  setErr('');
                  try {
                    await sendPasswordResetEmail(auth, email.trim());
                    setForgotSent(true);
                  } catch (ex) {
                    const code = (ex as { code?: string } | null)?.code ?? '';
                    setErr(
                      code === 'auth/user-not-found'
                        ? 'Email này chưa có tài khoản.'
                        : code === 'auth/invalid-email'
                          ? 'Email không hợp lệ.'
                          : 'Gửi email thất bại. Thử lại sau.',
                    );
                  } finally {
                    setForgotBusy(false);
                  }
                }}
              >
                <button type="submit" className="btn btn-block" disabled={forgotBusy}>
                  {forgotBusy ? 'Đang gửi…' : 'Gửi email đặt lại mật khẩu'}
                </button>
              </form>
            )}
            <button
              type="button"
              className="btn btn-ghost btn-block"
              style={{ marginTop: 8 }}
              onClick={() => {
                setForgotMode(false);
                setForgotSent(false);
                setErr('');
              }}
            >
              ← Quay lại đăng nhập
            </button>
          </div>
        ) : (
          <p className="muted small" style={{ marginTop: 14, textAlign: 'center' }}>
            <button
              type="button"
              className="link-like"
              onClick={() => {
                setForgotMode(true);
                setForgotSent(false);
                setErr('');
              }}
            >
              Quên mật khẩu?
            </button>
            <br />
            Quán mới chưa có tài khoản? <Link to="/setup">Thiết lập lần đầu →</Link>
          </p>
        )}
        <p className="muted small" style={{ marginTop: 10, textAlign: 'center', opacity: 0.55 }}>
          Bản {__APP_VERSION__}
        </p>
      </div>
    </div>
  );
}