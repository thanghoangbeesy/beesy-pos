import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { DbError, getAllowedWarehouses, getDailyBreakdown, getRangeReport } from '../lib/db';
import {
  addDaysVN,
  formatDMY,
  formatVND,
  startOfMonthVN,
  startOfWeekVN,
  todayVN,
} from '../lib/format';
import { useToast } from '../components/Toast';
import { DayCloseSheet } from './DayCloseSheet';
import { useAuth } from '../lib/auth';
import { TIcon } from '../components/TIcon';
import type { DailyReport, Warehouse } from '../lib/types';

type PresetKey = 'today' | 'yesterday' | 'thisWeek' | 'lastWeek' | 'thisMonth' | 'lastMonth';

const PRESETS: { key: PresetKey; label: string }[] = [
  { key: 'today', label: 'Hôm nay' },
  { key: 'yesterday', label: 'Hôm qua' },
  { key: 'thisWeek', label: 'Tuần này' },
  { key: 'lastWeek', label: 'Tuần trước' },
  { key: 'thisMonth', label: 'Tháng này' },
  { key: 'lastMonth', label: 'Tháng trước' },
];

function presetRange(key: PresetKey): [string, string] {
  const t = todayVN();
  switch (key) {
    case 'today': return [t, t];
    case 'yesterday': { const y = addDaysVN(t, -1); return [y, y]; }
    case 'thisWeek': return [startOfWeekVN(t), t];
    case 'lastWeek': {
      const mondayThis = startOfWeekVN(t);
      const mondayLast = addDaysVN(mondayThis, -7);
      return [mondayLast, addDaysVN(mondayLast, 6)];
    }
    case 'thisMonth': return [startOfMonthVN(t), t];
    case 'lastMonth': {
      const firstThisMonth = startOfMonthVN(t);
      const lastDayPrev = addDaysVN(firstThisMonth, -1);
      return [startOfMonthVN(lastDayPrev), lastDayPrev];
    }
  }
}

/** Kỳ trước tương ứng để so sánh. */
function prevRange(key: PresetKey): [string, string] {
  const t = todayVN();
  switch (key) {
    case 'today': { const y = addDaysVN(t, -1); return [y, y]; }
    case 'yesterday': { const y = addDaysVN(t, -2); return [y, y]; }
    case 'thisWeek': {
      const mondayThis = startOfWeekVN(t);
      const mondayLast = addDaysVN(mondayThis, -7);
      return [mondayLast, addDaysVN(mondayLast, 6)];
    }
    case 'lastWeek': {
      const mondayThis = startOfWeekVN(t);
      const mondayLast2 = addDaysVN(mondayThis, -14);
      return [mondayLast2, addDaysVN(mondayLast2, 6)];
    }
    case 'thisMonth': {
      const firstThisMonth = startOfMonthVN(t);
      const lastDayPrev = addDaysVN(firstThisMonth, -1);
      return [startOfMonthVN(lastDayPrev), lastDayPrev];
    }
    case 'lastMonth': {
      const firstThisMonth = startOfMonthVN(t);
      const lastDayPrev = addDaysVN(firstThisMonth, -1);
      const firstPrev = startOfMonthVN(lastDayPrev);
      const lastDayPrev2 = addDaysVN(firstPrev, -1);
      return [startOfMonthVN(lastDayPrev2), lastDayPrev2];
    }
  }
}

function pctChange(cur: number, prev: number): number | null {
  if (prev === 0) return cur > 0 ? 100 : null;
  return ((cur - prev) / prev) * 100;
}

export function ReportsMobile() {
  const toast = useToast();
  const { can } = useAuth();
  const navigate = useNavigate();
  const [preset, setPreset] = useState<PresetKey>('today');
  const [report, setReport] = useState<DailyReport | null>(null);
  const [prevReport, setPrevReport] = useState<DailyReport | null>(null);
  const [weekData, setWeekData] = useState<{ date: string; dayLabel: string; thisRevenue: number; thisProfit: number; lastRevenue: number; lastProfit: number }[]>([]);
  const [chartMetric, setChartMetric] = useState<'revenue' | 'profit'>('revenue');
  const [busy, setBusy] = useState(false);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [isOwner, setIsOwner] = useState(false);
  const [dayCloseOpen, setDayCloseOpen] = useState(false);
  const [topSort, setTopSort] = useState<'qty' | 'revenue' | 'profit'>('qty');
  const [topDir, setTopDir] = useState<'desc' | 'asc'>('desc');

  const load = useCallback(async (key: PresetKey, ids?: string[]) => {
    setBusy(true);
    try {
      const [s, e] = presetRange(key);
      const [ps, pe] = prevRange(key);
      const t = todayVN();
      const [cur, prev] = await Promise.all([
        getRangeReport(s, e, ids),
        getRangeReport(ps, pe, ids),
      ]);
      setReport(cur);
      setPrevReport(prev);
      // So sánh tuần này vs tuần trước theo từng ngày (T2..CN) — 2 truy vấn gom nhóm
      const mondayThis = startOfWeekVN(t);
      const mondayLast = addDaysVN(mondayThis, -7);
      const sundayThis = addDaysVN(mondayThis, 6);
      const sundayLast = addDaysVN(mondayLast, 6);
      const dayLabels = ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'];
      const [thisWeekDays, lastWeekDays] = await Promise.all([
        getDailyBreakdown(mondayThis, sundayThis, ids),
        getDailyBreakdown(mondayLast, sundayLast, ids),
      ]);
      const cmp = dayLabels.map((dayLabel, i) => ({
        date: addDaysVN(mondayThis, i),
        dayLabel,
        thisRevenue: thisWeekDays[i]?.revenue ?? 0,
        thisProfit: thisWeekDays[i]?.profit ?? 0,
        lastRevenue: lastWeekDays[i]?.revenue ?? 0,
        lastProfit: lastWeekDays[i]?.profit ?? 0,
      }));
      setWeekData(cmp);
    } catch (err) {
      toast.show(err instanceof DbError ? err.message : 'Không tải được báo cáo');
    } finally {
      setBusy(false);
    }
  }, [toast]);

  useEffect(() => {
    getAllowedWarehouses()
      .then(({ warehouses: ws, isOwner: ow }) => {
        setWarehouses(ws);
        setIsOwner(ow);
        const ids = ow ? undefined : ws.map((w) => w.id);
        void load('today', ids);
      })
      .catch(() => { void load('today'); });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const pickPreset = (key: PresetKey) => {
    setPreset(key);
    const ids = isOwner ? undefined : warehouses.map((w) => w.id);
    void load(key, ids);
  };

  const kpis = useMemo(() => {
    if (!report) return [];
    const p = prevReport;
    return [
      {
        label: 'Doanh thu',
        value: formatVND(report.revenue),
        icon: '💰',
        change: p ? pctChange(report.revenue, p.revenue) : null,
        changeLabel: 'so với kỳ trước',
      },
      {
        label: 'Lợi nhuận',
        value: formatVND(report.profit),
        icon: '📈',
        change: p ? pctChange(report.profit, p.profit) : null,
        changeLabel: 'so với kỳ trước',
      },
      {
        label: 'Số đơn',
        value: String(report.order_count),
        icon: '🧾',
        change: p ? pctChange(report.order_count, p.order_count) : null,
        changeLabel: 'so với kỳ trước',
      },
      {
        label: 'TB/đơn',
        value: formatVND(Math.round(report.avg_order)),
        icon: '🧮',
        change: p ? pctChange(report.avg_order, p.avg_order) : null,
        changeLabel: 'so với kỳ trước',
      },
    ];
  }, [report, prevReport]);

  const maxWeekValue = Math.max(1, ...weekData.map((d) =>
    chartMetric === 'revenue' ? Math.max(d.thisRevenue, d.lastRevenue) : Math.max(d.thisProfit, d.lastProfit)
  ));
  const weekThisTotal = weekData.reduce((s, d) => s + (chartMetric === 'revenue' ? d.thisRevenue : d.thisProfit), 0);
  const weekLastTotal = weekData.reduce((s, d) => s + (chartMetric === 'revenue' ? d.lastRevenue : d.lastProfit), 0);
  const topProducts = useMemo(() => {
    const arr = [...(report?.top_products ?? [])];
    arr.sort((a, b) => {
      const d = a[topSort] - b[topSort];
      return topDir === 'desc' ? -d : d;
    });
    return arr.slice(0, 5);
  }, [report, topSort, topDir]);

  if (!can('reports')) {
    return (
      <div className="page">
        <div className="card">🔒 Chỉ Quản lý trở lên mới được xem báo cáo.</div>
      </div>
    );
  }

  return (
    <div className="page ov-page">
      {/* Header xanh theo mẫu */}
      <div className="ov-header">
        <div className="ov-header-top">
          <h1 className="ov-title">Tổng quan</h1>
          <div className="ov-header-actions">
            <select
              className="ov-preset"
              value={preset}
              onChange={(e) => pickPreset(e.target.value as PresetKey)}
              aria-label="Chọn kỳ báo cáo"
            >
              {PRESETS.map((p) => (
                <option key={p.key} value={p.key}>{p.label}</option>
              ))}
            </select>
            <button className="ov-icon-btn" onClick={() => setDayCloseOpen(true)} aria-label="Chốt két">
              <TIcon emoji="💰" size={20} />
            </button>
          </div>
        </div>
      </div>

      {/* 4 thẻ KPI */}
      <div className="ov-kpis">
        {kpis.map((k) => (
          <div className="ov-kpi" key={k.label}>
            <div className="ov-kpi-top">
              <span className="ov-kpi-icon"><TIcon emoji={k.icon} size={20} /></span>
              <span className="ov-kpi-label">{k.label}</span>
            </div>
            <div className="ov-kpi-value">{busy && !report ? '…' : k.value}</div>
            {k.change !== null && k.change !== undefined && (
              <div className={`ov-kpi-change ${k.change >= 0 ? 'up' : 'down'}`}>
                {k.change >= 0 ? '↑' : '↓'} {Math.abs(Math.round(k.change))}% {k.changeLabel}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Biểu đồ tuần này so với tuần trước */}
      <div className="ov-card">
        <div className="ov-card-head">
          <h3>Tuần này so với tuần trước</h3>
          <div className="ov-metric-toggle">
            <button
              className={chartMetric === 'revenue' ? 'active' : ''}
              onClick={() => setChartMetric('revenue')}
            >Doanh thu</button>
            <button
              className={chartMetric === 'profit' ? 'active' : ''}
              onClick={() => setChartMetric('profit')}
            >Lợi nhuận</button>
          </div>
        </div>
        <div className="ov-week-summary">
          <div className="ov-week-item">
            <span className="ov-week-dot" style={{ background: '#00B14F' }} />
            <span>Tuần này: <b>{formatVND(weekThisTotal)}</b></span>
          </div>
          <div className="ov-week-item">
            <span className="ov-week-dot" style={{ background: '#CBD5E1' }} />
            <span>Tuần trước: <b>{formatVND(weekLastTotal)}</b></span>
          </div>
        </div>
        <div className="ov-chart">
          {weekData.map((d) => {
            const thisVal = chartMetric === 'revenue' ? d.thisRevenue : d.thisProfit;
            const lastVal = chartMetric === 'revenue' ? d.lastRevenue : d.lastProfit;
            return (
              <div className="ov-bar-col" key={d.date}
                title={`${d.dayLabel} ${formatDMY(d.date)} — Tuần này: ${formatVND(thisVal)}, tuần trước: ${formatVND(lastVal)}`}
                style={{ cursor: 'pointer' }}
                onClick={() => toast.show(`${d.dayLabel} ${formatDMY(d.date)} — ${chartMetric === 'revenue' ? 'Doanh thu' : 'Lợi nhuận'}: tuần này ${formatVND(thisVal)}, tuần trước ${formatVND(lastVal)}`)}>
                <div className="ov-bar-track ov-bar-group">
                  <div
                    className="ov-bar"
                    style={{
                      height: `${Math.max(4, Math.round((thisVal / maxWeekValue) * 100))}%`,
                      background: '#00B14F',
                    }}
                  />
                  <div
                    className="ov-bar"
                    style={{
                      height: `${Math.max(4, Math.round((lastVal / maxWeekValue) * 100))}%`,
                      background: '#CBD5E1',
                    }}
                  />
                </div>
                <div className="ov-bar-label">{d.dayLabel}</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Món bán chạy */}
      <div className="ov-card">
        <div className="ov-card-head">
          <h3>Món bán chạy</h3>
        </div>
        <div className="ov-filter-row">
          <select
            className="ov-filter-select"
            value={topSort}
            onChange={(e) => setTopSort(e.target.value as 'qty' | 'revenue' | 'profit')}
            aria-label="Sắp xếp theo"
          >
            <option value="qty">Số lượng</option>
            <option value="revenue">Doanh thu</option>
            <option value="profit">Lợi nhuận</option>
          </select>
          <button
            className="ov-filter-dir"
            onClick={() => setTopDir((d) => (d === 'desc' ? 'asc' : 'desc'))}
            aria-label="Đổi thứ tự"
          >
            {topDir === 'desc' ? '↓ Giảm dần' : '↑ Tăng dần'}
          </button>
        </div>
        {topProducts.length === 0 ? (
          <p className="muted small">Chưa có dữ liệu</p>
        ) : (
          topProducts.map((p, i) => (
            <div className="ov-row" key={p.product_id}>
              <span className="ov-rank">{i + 1}</span>
              <div className="ov-row-body">
                <span className="ov-row-title">{p.name}</span>
                <span className="ov-row-sub">{p.qty} món · lãi {formatVND(p.profit)}</span>
              </div>
              <span className="ov-row-amount">{formatVND(p.revenue)}</span>
            </div>
          ))
        )}
      </div>

      {/* Thao tác nhanh */}
      <div className="ov-card">
        <div className="ov-card-head"><h3>Thao tác nhanh</h3></div>
        <div className="ov-actions">
          <button onClick={() => navigate('/menu')}><TIcon emoji="📋" size={20} /><span>Menu</span></button>
          <button onClick={() => navigate('/customers')}><TIcon emoji="👥" size={20} /><span>Khách hàng</span></button>
          <button onClick={() => navigate('/inventory')}><TIcon emoji="🗃️" size={20} /><span>Tồn kho</span></button>
          <button onClick={() => navigate('/so-quy')}><TIcon emoji="💰" size={20} /><span>Sổ quỹ</span></button>
        </div>
      </div>

      {dayCloseOpen && <DayCloseSheet onClose={() => setDayCloseOpen(false)} />}
    </div>
  );
}
