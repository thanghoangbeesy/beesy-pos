declare const __APP_VERSION__: string;
import { useCallback, useEffect, useState } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../lib/auth';
import type { ActionKey } from '../lib/permissions';
import { ROLE_LABELS } from '../lib/permissions';
import { getSettings } from '../lib/db';
import { applyBrandColor, loadBrand } from '../lib/brand';
import { getLicense, type License } from '../lib/license';
import { useOnlineStatus } from '../lib/offline';
import { useToast } from './Toast';
import { Sheet } from './Sheet';
import AppIcon, { type AppIconName } from './AppIcon';
import { LineIcon } from './LineIcon';
import { useAppTheme } from '../lib/useAppTheme';
import type { ReactNode } from 'react';

// Icon điều hướng: v3 dùng lineal SVG, v1/v2 dùng icon 3D/emoji như cũ
function NavIcon({ name, fb, size = 22 }: { name: string; fb: string; size?: number }) {
  const theme = useAppTheme();
  if (theme === 'v3') {
    // Map tên icon sang LineIcon
    const map: Record<string, string> = {
      chart: 'chart',
      receipt: 'receipt',
      package: 'package',
      clipboard: 'clipboard',
      gear: 'gear',
      ledger: 'ledger',
      moneybag: 'wallet',
      globe: 'globe',
      archive: 'archive',
      truck: 'truck',
      scroll: 'scroll',
      key: 'key',
      users: 'users',
      gift: 'package',
      cloud: 'archive',
      card: 'wallet',
      chef: 'clipboard',
    };
    return <LineIcon name={map[name] ?? 'package'} size={size} />;
  }
  return <AppIcon name={name} fallback={fb} size={size} />;
}

// Sidebar bản web: nhóm điều hướng theo phong cách Sổ Bán Hàng
interface NavItem { to: string; icon: AppIconName; fb: string; label: string; action: ActionKey }
interface NavGroup { title: string; items: NavItem[] }

const NAV_GROUPS: NavGroup[] = [
  {
    title: 'TỔNG QUAN',
    items: [{ to: '/reports', icon: 'chart', fb: '📊', label: 'Tổng quan', action: 'reports' }],
  },
  {
    title: 'BÁN HÀNG',
    items: [
      { to: '/pos', icon: 'receipt', fb: '🧾', label: 'Bán hàng', action: 'pos' },
      { to: '/orders', icon: 'package', fb: '📦', label: 'Đơn hàng', action: 'orders.view' },
      { to: '/don-online', icon: 'globe', fb: '🌐', label: 'Đơn online', action: 'orders.view' },
    ],
  },
  {
    title: 'SỔ SÁCH',
    items: [
      { to: '/debt', icon: 'ledger', fb: '📒', label: 'Sổ nợ', action: 'debt' },
      { to: '/so-quy', icon: 'moneybag', fb: '💰', label: 'Sổ quỹ', action: 'cashbook' },
    ],
  },
  {
    title: 'HÀNG HÓA',
    items: [
      { to: '/menu', icon: 'clipboard', fb: '📋', label: 'Menu', action: 'menu' },
      { to: '/inventory', icon: 'archive', fb: '🗃️', label: 'Tồn kho', action: 'inventory' },
      { to: '/nhap-hang', icon: 'truck', fb: '📥', label: 'Nhập Xuất Hàng', action: 'purchase' },
    ],
  },
  { title: 'KHÁCH HÀNG', items: [{ to: '/customers', icon: 'users', fb: '👥', label: 'Khách hàng', action: 'customers' }] },
  {
    title: 'HỆ THỐNG',
    items: [
      { to: '/settings', icon: 'gear', fb: '⚙️', label: 'Cài đặt', action: 'settings' },
      { to: '/nhat-ky', icon: 'scroll', fb: '📜', label: 'Nhật ký', action: 'audit' },
      { to: '/doi-mat-khau', icon: 'key', fb: '🔑', label: 'Đổi mật khẩu', action: 'pos' },
    ],
  },
];

// Bottom tab bar bản mobile V5: Tổng Quan, Đơn Hàng, [+ Bán Hàng], Sổ Quỹ, Báo Cáo
const MOBILE_TABS: NavItem[] = [
  { to: '/reports', icon: 'chart', fb: '📊', label: 'Tổng quan', action: 'reports' },
  { to: '/orders', icon: 'package', fb: '📦', label: 'Đơn hàng', action: 'orders.view' },
  { to: '/so-quy', icon: 'moneybag', fb: '💰', label: 'Sổ quỹ', action: 'cashbook' },
  { to: '/bao-cao', icon: 'scroll', fb: '📜', label: 'Báo cáo', action: 'reports' },
];

// Các mục còn lại trên mobile nằm trong menu "Thêm"
// Menu tổng trên mobile (nút ☰ góc phải): TẤT CẢ các menu chức năng
const MORE_LINKS: NavItem[] = [
  { to: '/reports', icon: 'chart', fb: '📊', label: 'Tổng quan', action: 'reports' },
  { to: '/pos', icon: 'receipt', fb: '🧾', label: 'Bán hàng', action: 'pos' },
  { to: '/orders', icon: 'package', fb: '📦', label: 'Đơn hàng', action: 'orders.view' },
  { to: '/don-online', icon: 'globe', fb: '🌐', label: 'Đơn online', action: 'orders.view' },
  { to: '/menu', icon: 'clipboard', fb: '📋', label: 'Menu', action: 'menu' },
  { to: '/customers', icon: 'users', fb: '👥', label: 'Khách hàng', action: 'customers' },
  { to: '/inventory', icon: 'archive', fb: '🗃️', label: 'Tồn kho', action: 'inventory' },
  { to: '/nhap-hang', icon: 'truck', fb: '📥', label: 'Nhập Xuất Hàng', action: 'purchase' },
  { to: '/debt', icon: 'ledger', fb: '📒', label: 'Sổ nợ', action: 'debt' },
  { to: '/so-quy', icon: 'moneybag', fb: '💰', label: 'Sổ quỹ', action: 'cashbook' },
  { to: '/bao-cao', icon: 'scroll', fb: '📜', label: 'Báo cáo', action: 'reports' },
  { to: '/settings', icon: 'gear', fb: '⚙️', label: 'Cài đặt', action: 'settings' },
  { to: '/nhat-ky', icon: 'scroll', fb: '📜', label: 'Nhật ký', action: 'audit' },
  { to: '/doi-mat-khau', icon: 'key', fb: '🔑', label: 'Đổi mật khẩu', action: 'pos' },
];

function SideNav() {
  const { can } = useAuth();
  const groups = NAV_GROUPS.map((g) => ({ ...g, items: g.items.filter((n) => can(n.action)) })).filter(
    (g) => g.items.length > 0,
  );
  return (
    <>
      {groups.map((g) => (
        <div className="nav-group" key={g.title}>
          <div className="nav-group-title">{g.title}</div>
          {g.items.map((n) => (
            <NavLink key={n.to} to={n.to} className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}>
              <span className="ico"><NavIcon name={n.icon} fb={n.fb} size={22} /></span>
              <span>{n.label}</span>
            </NavLink>
          ))}
        </div>
      ))}
    </>
  );
}

export function Layout({ children }: { children?: ReactNode }) {
  const { user, logout, can } = useAuth();
  const mobileTabs = MOBILE_TABS.filter((n) => can(n.action));
  const moreLinks = MORE_LINKS.filter((l) => can(l.action));
  const navigate = useNavigate();
  const toast = useToast();
  const [shopName, setShopName] = useState('Beesy POS');
  const [brandLogo, setBrandLogo] = useState('');
  const [license, setLicense] = useState<License | null>(null);
  const [moreOpen, setMoreOpen] = useState(false);
  const onSynced = useCallback(
    (r: { ok: number; fail: number }) => {
      if (r.ok > 0) toast.show(`Đã đồng bộ ${r.ok} đơn chờ lên server`);
    },
    [toast],
  );
  const { online, pending } = useOnlineStatus(onSynced);

  useEffect(() => {
    getSettings()
      .then((s) => {
        if (s.shop_name) setShopName(s.shop_name);
      })
      .catch(() => {});
    loadBrand()
      .then((b) => {
        if (b.shop_name) setShopName(b.shop_name);
        if (b.logo) setBrandLogo(b.logo);
        applyBrandColor(b.color);
      })
      .catch(() => {});
    getLicense().then(setLicense).catch(() => {});
  }, []);

  const doLogout = async () => {
    setMoreOpen(false);
    await logout();
    navigate('/login');
  };

  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="nav-logo">
          <img src="/coffee-cup.svg" alt="Beesy" />
          <span>Beesy POS</span>
        </div>
        <SideNav />
        <div className="nav-user">
          <span className="avatar">{(user?.full_name || user?.email || 'B').charAt(0).toUpperCase()}</span>
          <div className="uinfo">
            <div className="uname">{user?.full_name || user?.email || ''}</div>
            <div className="urole">{user?.role ? (ROLE_LABELS[user.role] ?? user.role) : ''} · Bản {__APP_VERSION__}</div>
          </div>
        </div>
      </aside>
      <div className="main">
        {!online && (
          <div className="offline-banner">
            ⚠️ Đang offline{pending > 0 ? ` — ${pending} đơn chờ đồng bộ` : ' — vẫn bán được, đơn sẽ tự đồng bộ khi có mạng'}
          </div>
        )}
        {online && pending > 0 && <div className="offline-banner online">⏳ Đang đồng bộ {pending} đơn chờ…</div>}
        {license && !license.valid && (
          <div className="offline-banner" style={{ background: '#FEE2E2', color: '#991B1B' }}>
            🔑 Giấy phép đã hết hạn ({license.expires}) — vào Cài đặt → Giấy phép sử dụng để gia hạn.
          </div>
        )}
        {license && license.valid && license.daysLeft <= 7 && (
          <div className="offline-banner" style={{ background: '#FEF3C7', color: '#92400E' }}>
            🔑 Giấy phép còn {license.daysLeft} ngày ({license.expires}) — nhớ gia hạn nhé.
          </div>
        )}
        <header className="topbar">
          {brandLogo ? (
            brandLogo.startsWith('data:image') ? (
              <img src={brandLogo} alt="" style={{ width: 30, height: 30, borderRadius: 8, objectFit: 'cover' }} />
            ) : (
              <span style={{ fontSize: 24 }}>{brandLogo}</span>
            )
          ) : null}
          <span className="shop-name">{shopName}</span>
          <span className="spacer" />
          <span className="user-chip">
            {user ? `${user.full_name || user.email} · ${ROLE_LABELS[user.role] ?? user.role}` : ''}
          </span>
          <button className="btn btn-ghost logout-btn" style={{ minHeight: 44, padding: '6px 14px' }} onClick={doLogout}>
            Đăng xuất
          </button>
          <button className="more-btn" onClick={() => setMoreOpen(true)} aria-label="Thêm">
            ☰
          </button>
        </header>
        <main style={{ flex: 1 }}>{children ?? <Outlet />}</main>
      </div>
      <nav className="mobile-nav">
        {mobileTabs.slice(0, 2).map((n) => (
          <NavLink key={n.to + n.label} to={n.to} className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}>
            <span className="ico"><NavIcon name={n.icon} fb={n.fb} size={22} /></span>
            <span>{n.label}</span>
          </NavLink>
        ))}
        <button className="nav-fab" onClick={() => navigate('/pos')} aria-label="Bán hàng">
          <span className="fab-plus">+</span>
          <span className="fab-label">Bán hàng</span>
        </button>
        {mobileTabs.slice(2, 4).map((n) => (
          <NavLink key={n.to + n.label} to={n.to} className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}>
            <span className="ico"><NavIcon name={n.icon} fb={n.fb} size={22} /></span>
            <span>{n.label}</span>
          </NavLink>
        ))}
      </nav>
      {moreOpen && (
        <Sheet title="☰ Menu" onClose={() => setMoreOpen(false)}>
          {moreLinks.map((l) => (
            <NavLink key={l.to} to={l.to} className="more-link" onClick={() => setMoreOpen(false)}>
              <span className="ico"><NavIcon name={l.icon} fb={l.fb} size={22} /></span>
              <span>{l.label}</span>
              <span className="chev">›</span>
            </NavLink>
          ))}
          <button className="btn btn-ghost btn-block" style={{ marginTop: 12 }} onClick={doLogout}>
            Đăng xuất
          </button>
        </Sheet>
      )}
    </div>
  );
}
