// Đơn hàng — xem / sửa / xóa các đơn đã bán.
// Sửa nhanh: ghi chú + khách hàng (quản lý trở lên).
// Sửa toàn bộ: món, số lượng, giảm giá, voucher, phương thức thanh toán (chỉ chủ quán;
//   tồn kho, sổ quỹ, công nợ, tem/điểm được tính lại theo).
// Xóa: chỉ chủ quán; đơn ghi nợ được hoàn công nợ, khoản quỹ tự động của đơn bị xóa theo.
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  DbError,
  deleteOrder,
  getAllowedWarehouses,
  getOrder,
  getSettings,
  listOrders,
  listPaymentMethods,
  searchCustomers,
  updateOrderMeta,
} from '../lib/db';
import {
  addDaysVN,
  formatDMY,
  formatTime,
  formatVND,
  startOfMonthVN,
  startOfWeekVN,
  todayVN,
  unsignVietnamese,
} from '../lib/format';
import { BluetoothPrintButton } from '../components/BluetoothPrintButton';
import { PageHead } from '../components/PageHead';
import { LineIcon } from '../components/LineIcon';
import './pc-orders.css';
import './v6demo-theme.css';
import './v6demo-orders.css';
import { CustomerPickSheet } from '../components/CustomerPickSheet';
import { OrderEditForm } from './OrderEditForm';
import { BillPrint } from './BillPrint';
import { saveBillImage, shareBillImage, zaloPhone } from '../lib/bill-image';
import { loadBrand } from '../lib/brand';
import { useToast } from '../components/Toast';
import { useAuth } from '../lib/auth';
import type { Customer, Order, PaymentMethodDef, Warehouse } from '../lib/types';
import { isSplitPayment, orderPaymentSplits } from '../lib/types';

type FilterKey = 'today' | 'yesterday' | 'week' | 'lastweek' | 'month' | 'lastmonth' | 'custom';
const FILTERS: { key: FilterKey; label: string }[] = [
  { key: 'today', label: 'Hôm nay' },
  { key: 'yesterday', label: 'Hôm qua' },
  { key: 'week', label: 'Tuần này' },
  { key: 'lastweek', label: 'Tuần trước' },
  { key: 'month', label: 'Tháng này' },
  { key: 'lastmonth', label: 'Tháng trước' },
  { key: 'custom', label: 'Tùy chọn' },
];

const STATUS_LABEL: Record<string, string> = {
  new: 'Mới',
  preparing: 'Đang pha',
  ready: 'Sẵn sàng',
  done: 'Hoàn tất',
  cancelled: 'Đã hủy',
};

function rangeOf(key: FilterKey, customFrom?: string, customTo?: string): [string, string] {
  const t = todayVN();
  switch (key) {
    case 'today':
      return [t, t];
    case 'yesterday': {
      const y = addDaysVN(t, -1);
      return [y, y];
    }
    case 'week':
      return [startOfWeekVN(t), t];
    case 'lastweek': {
      const ws = startOfWeekVN(t);
      const we = addDaysVN(ws, -1);
      return [addDaysVN(ws, -7), we];
    }
    case 'month':
      return [startOfMonthVN(t), t];
    case 'lastmonth': {
      const ms = startOfMonthVN(t);
      const me = addDaysVN(ms, -1);
      return [startOfMonthVN(me), me];
    }
    case 'custom':
      return [customFrom || t, customTo || t];
  }
}

/** Hook phat hien man hinh PC (>= 1024px), theo mau pages/Reports.tsx. */
function useIsPC(): boolean {
  const [isPC, setIsPC] = useState(() => typeof window !== 'undefined' && window.innerWidth >= 1024);
  useEffect(() => {
    const onResize = () => setIsPC(window.innerWidth >= 1024);
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);
  return isPC;
}

export function Orders() {
  const isPC = useIsPC();
  const toast = useToast();
  const { can } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [custMap, setCustMap] = useState<Map<string, Customer>>(new Map());
  const [kindMap, setKindMap] = useState<Map<string, string>>(new Map());
  // v6.3: dữ liệu để xem lại bill của đơn đã lưu (như lúc thanh toán ở Checkout).
  const [methods, setMethods] = useState<PaymentMethodDef[]>([]);
  const [fallbackBank, setFallbackBank] = useState({ bin: '', account: '', name: '' });
  const [shopName, setShopName] = useState('Beesy Coffee & Tea');
  const [shopPhone, setShopPhone] = useState('');
  const [shopAddress, setShopAddress] = useState('');
  const [shopLogo, setShopLogo] = useState('');
  const [q, setQ] = useState('');
  const [searchParams, setSearchParams] = useSearchParams();
  // Deep-link từ Tổng quan: /orders?from=..&to=.. -> mở sẵn kỳ tùy chọn đó
  const deepRange = (() => {
    const f = searchParams.get('from');
    const t = searchParams.get('to');
    if (!f || !t || !/^\d{4}-\d{2}-\d{2}$/.test(f) || !/^\d{4}-\d{2}-\d{2}$/.test(t) || f > t) return null;
    return { from: f, to: t };
  })();
  const [filter, setFilter] = useState<FilterKey>(deepRange ? 'custom' : 'today');
  const [customFrom, setCustomFrom] = useState(deepRange?.from ?? todayVN());
  const [customTo, setCustomTo] = useState(deepRange?.to ?? todayVN());
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [whFilter, setWhFilter] = useState('all');
  const [busy, setBusy] = useState(true);
  // Thẻ đơn đang mở rộng chi tiết (v5.16: chi tiết mở ngay trong thẻ như bản demo Beesy Store)
  const [expandedId, setExpandedId] = useState<string | null>(null);
  // Đơn được mở qua deep-link (?open=orderId) từ Sổ quỹ — có thể nằm ngoài khoảng lọc hiện tại
  const [deepOrder, setDeepOrder] = useState<Order | null>(null);
  // PC: loc phuong thuc (loc client-side tren danh sach da tai, khong doi loader)
  // va don dang mo form sua nhanh tu panel PC (xem nhanh PC ben duoi).
  const [payFilter, setPayFilter] = useState('all');
  const [pcEditFor, setPcEditFor] = useState<string | null>(null);
  const [pcEditKey, setPcEditKey] = useState(0);

  const load = useCallback(
    async (fk: FilterKey, whId: string = 'all', cFrom?: string, cTo?: string) => {
      setBusy(true);
      try {
        const [from, to] = rangeOf(fk, cFrom ?? customFrom, cTo ?? customTo);
        const allowed = await getAllowedWarehouses();
        setWarehouses(allowed.warehouses);
        const ids =
          whId === 'all'
            ? allowed.isOwner
              ? undefined
              : allowed.warehouses.map((w) => w.id)
            : [whId];
        const [list, customers, methods] = await Promise.all([
          listOrders({ from, to, warehouseIds: ids }),
          searchCustomers(''),
          listPaymentMethods(false),
        ]);
        setOrders(list);
        setCustMap(new Map(customers.map((c) => [c.id, c])));
        setKindMap(new Map(methods.map((m) => [m.id, m.kind])));
        setMethods(methods);
      } catch (e) {
        toast.show(e instanceof DbError ? e.message : 'Không tải được đơn hàng');
      } finally {
        setBusy(false);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [],
  );

  // Cấu hình quán + ngân hàng dự phòng cho bill (như CheckoutModal).
  useEffect(() => {
    getSettings()
      .then((s) => {
        setShopName(s.shop_name || 'Beesy Coffee & Tea');
        setShopPhone(s.shop_phone || '');
        setShopAddress(s.shop_address || '');
        setFallbackBank({
          bin: s.bank_bin || '',
          account: s.bank_account || '',
          name: s.bank_account_name || '',
        });
      })
      .catch(() => {});
    loadBrand().then((b) => setShopLogo(b.logo || '')).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    void load(filter, whFilter);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filter, whFilter]);

  const changeWh = (id: string) => setWhFilter(id);

  // Deep-link từ Sổ quỹ: /orders?open=<orderId> → mở ngay chi tiết đơn
  useEffect(() => {
    const openId = searchParams.get('open');
    if (!openId) return;
    setSearchParams({}, { replace: true });
    getOrder(openId)
      .then((o) => {
        if (!o) {
          toast.show('Không tìm thấy đơn hàng');
          return;
        }
        setDeepOrder(o);
        setExpandedId(o.id);
      })
      .catch(() => toast.show('Không mở được đơn hàng'));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const needle = unsignVietnamese(q.trim()).toLowerCase();
  const canDeleteRow = can('orders.delete');
  const quickDelete = async (o: { id: string; code: string; total: number }) => {
    if (!window.confirm(`Xóa đơn ${o.code} (${formatVND(o.total)})? Khoản quỹ và công nợ liên quan sẽ được hoàn/xóa theo.`))
      return;
    try {
      await deleteOrder(o.id);
      toast.show(`Đã xóa đơn ${o.code}`);
      void load(filter, whFilter);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Xóa thất bại');
    }
  };
  const filtered = useMemo(
    () =>
      orders.filter((o) => {
        if (!needle) return true;
        const c = o.customer_id ? custMap.get(o.customer_id) : undefined;
        const hay = unsignVietnamese(
          `${o.code} ${o.note ?? ''} ${c ? `${c.name} ${c.phone}` : 'khách lẻ'}`,
        ).toLowerCase();
        return hay.includes(needle);
      }),
    [orders, custMap, needle],
  );
  // Loc phuong thuc dung chung ca 2 nhanh (PC va mobile): loc client-side
  // tren danh sach da tai, khong doi loader.
  const matchesPay = (o: Order): boolean => {
    if (payFilter === 'all') return true;
    if (isSplitPayment(o)) return orderPaymentSplits(o).some((sp) => sp.method_id === payFilter);
    const m = methods.find((x) => x.id === payFilter);
    return o.payment_method === payFilter || (m ? o.payment_method_name === m.name : false);
  };
  const isDebtOrder = (o: Order): boolean => {
    if (isSplitPayment(o)) return orderPaymentSplits(o).some((sp) => sp.kind === 'debt');
    if (o.payment_method_name === 'Ghi nợ') return true;
    return kindMap.get(o.payment_method) === 'debt';
  };
  // Danh sach mobile ap them loc phuong thuc (nhu PC) + don mo trong sheet.
  const mobileFiltered = filtered.filter(matchesPay);
  const mobileRevenue = mobileFiltered.reduce((s, o) => s + o.total, 0);
  const mobileSheetOrder: Order | null = expandedId
    ? (deepOrder && deepOrder.id === expandedId
      ? deepOrder
      : (mobileFiltered.find((o) => o.id === expandedId) ?? null))
    : null;
  const closeMobileSheet = () => {
    setPcEditFor(null);
    setExpandedId(null);
    if (
      mobileSheetOrder &&
      deepOrder &&
      mobileSheetOrder.id === deepOrder.id &&
      !filtered.some((o) => o.id === deepOrder.id)
    ) {
      setDeepOrder(null);
    }
  };
  const openMobileEdit = (o: Order) => {
    setExpandedId(o.id);
    setPcEditFor(o.id);
    setPcEditKey((k) => k + 1);
  };


  const handleChanged = () => {
    setExpandedId(null);
    setDeepOrder(null);
    void load(filter, whFilter);
  };


  // Nhanh PC (>= 1024px): bang 8 cot + panel phai co dinh.
  // Chi khac JSX trinh bay; toan bo state, loader, handler, phan quyen,
  // deep-link from/to va deep-link open tu So quy deu dung chung code tren.
  // Chi tiet don khong phai modal/sheet ma la the mo rong inline
  // (OrderCardExpanded) nen panel PC tai dung dung component do thay vi
  // mo sheet rieng; 2 nut panel mo thang form sua nhanh cua no.
  if (isPC) {
    const payLabel = (o: Order): string => {
      if (isSplitPayment(o)) return 'Hỗn hợp';
      if (o.payment_method_name) return o.payment_method_name;
      const kind = kindMap.get(o.payment_method) ?? '';
      if (kind === 'cash') return 'Tiền mặt';
      if (kind === 'transfer') return 'Chuyển khoản';
      if (kind === 'debt') return 'Ghi nợ';
      return o.payment_method;
    };
    const itemsSummary = (o: Order): string => {
      const parts = o.items.map((it) => `${it.product_name} x${it.qty}`);
      if (parts.length === 0) return 'Không có món';
      const head = parts.slice(0, 3).join(', ');
      const rest = parts.length - 3;
      return rest > 0 ? `${head} và ${rest} món khác` : head;
    };
    const itemsFull = (o: Order): string => {
      if (o.items.length === 0) return 'Không có món';
      return o.items.map((it) => `${it.product_name} x${it.qty}`).join(', ');
    };
    const customerOf = (o: Order): Customer | null =>
      o.customer_id ? custMap.get(o.customer_id) ?? null : null;
    // Don mo tu So quy nam ngoai khoang loc van hien o dau bang PC
    // (ban mobile hien rieng phia tren danh sach).
    const pcBase: Order[] =
      deepOrder && !filtered.some((o) => o.id === deepOrder.id)
        ? [deepOrder, ...filtered]
        : filtered;
    const pcRows = pcBase.filter(matchesPay);
    const selectedOrder: Order | null =
      (expandedId ? pcRows.find((o) => o.id === expandedId) : undefined) ?? pcRows[0] ?? null;
    const pcRevenue = pcRows.reduce((s, o) => s + o.total, 0);
    const pcChanged = () => {
      setPcEditFor(null);
      handleChanged();
    };
    const selectRow = (o: Order) => {
      setPcEditFor(null);
      setExpandedId(o.id);
    };
    const openPcEdit = (o: Order) => {
      setExpandedId(o.id);
      setPcEditFor(o.id);
      setPcEditKey((k) => k + 1);
    };
    return (
      <div className="page v6demo-orders v6demo-page">
        <div className="v6demo-aurora" aria-hidden />
        <div className="v6demo-content">
          <div className="v6demo-page-head v6demo-rise">
            <h1>Đơn hàng</h1>
            <p>Xem, sửa ghi chú và khách hàng, xóa đơn đã bán. Bấm một dòng để mở chi tiết.</p>
          </div>

          <div className="v6demo-stat-strip">
            <div className="v6demo-glass v6demo-glass-sm v6demo-stat v6demo-rise-1">
              <b>{pcRows.length} đơn</b>
              <span>Trong kỳ đang chọn</span>
            </div>
            <div className="v6demo-glass v6demo-glass-sm v6demo-stat v6demo-rise-2">
              <b className="v6demo-price">{formatVND(pcRevenue)}</b>
              <span>Tổng tiền các đơn hiển thị</span>
            </div>
            <div className="v6demo-glass v6demo-glass-sm v6demo-stat v6demo-rise-3">
              <b>{pcRows.filter(isDebtOrder).length} đơn ghi nợ</b>
              <span>Cần đối soát công nợ</span>
            </div>
          </div>

          <section className="v6demo-glass v6demo-dock v6demo-rise-2" aria-label="Bộ lọc đơn hàng">
            <div className="v6demo-dock-row">
              <label className="v6demo-search">
                <LineIcon name="search" size={18} />
                <input
                  placeholder="Tìm mã đơn, tên, SĐT khách…"
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  aria-label="Tìm đơn hàng"
                />
              </label>
              <select
                className="v6demo-input v6demo-payselect"
                value={payFilter}
                onChange={(e) => setPayFilter(e.target.value)}
                aria-label="Lọc theo phương thức thanh toán"
              >
                <option value="all">Tất cả phương thức</option>
                {methods.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.name}
                  </option>
                ))}
              </select>
            </div>
            <div className="v6demo-dock-row">
              <div className="v6demo-seg" role="tablist" aria-label="Lọc theo thời gian">
                {FILTERS.map((f) => (
                  <button
                    key={f.key}
                    type="button"
                    className={filter === f.key ? 'active' : ''}
                    onClick={() => {
                      setFilter(f.key);
                      void load(f.key, whFilter);
                    }}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            </div>
            {filter === 'custom' && (
              <div className="v6demo-dock-row v6demo-date-row">
                <label className="v6demo-date-label" htmlFor="v6demo-pc-from">
                  Từ ngày
                </label>
                <input
                  id="v6demo-pc-from"
                  className="v6demo-input v6demo-date-input"
                  type="date"
                  value={customFrom}
                  max={todayVN()}
                  onChange={(e) => {
                    const v = e.target.value;
                    if (v) {
                      setCustomFrom(v);
                      if (v > customTo) setCustomTo(v);
                    }
                  }}
                  aria-label="Từ ngày"
                />
                <label className="v6demo-date-label" htmlFor="v6demo-pc-to">
                  Đến ngày
                </label>
                <input
                  id="v6demo-pc-to"
                  className="v6demo-input v6demo-date-input"
                  type="date"
                  value={customTo}
                  max={todayVN()}
                  min={customFrom}
                  onChange={(e) => {
                    const v = e.target.value;
                    if (v) setCustomTo(v);
                  }}
                  aria-label="Đến ngày"
                />
                <button
                  type="button"
                  className="v6demo-btn v6demo-btn-dark v6demo-btn-sm"
                  onClick={() => void load('custom', whFilter, customFrom, customTo)}
                >
                  Áp dụng kỳ
                </button>
              </div>
            )}
            {warehouses.length > 1 && (
              <div className="v6demo-dock-row">
                <button
                  type="button"
                  className={`v6demo-chip${whFilter === 'all' ? ' active' : ''}`}
                  onClick={() => changeWh('all')}
                >
                  Mọi kho
                </button>
                {warehouses.map((w) => (
                  <button
                    key={w.id}
                    type="button"
                    className={`v6demo-chip${whFilter === w.id ? ' active' : ''}`}
                    onClick={() => changeWh(w.id)}
                  >
                    {w.name}
                  </button>
                ))}
                <span className="v6demo-small v6demo-muted">
                  Kỳ: {FILTERS.find((f) => f.key === filter)?.label}
                  {filter === 'custom' ? ` (${customFrom} đến ${customTo})` : ''}
                </span>
              </div>
            )}
          </section>

          <section className="v6demo-glass v6demo-ledger v6demo-rise-3">
            <div className="v6demo-ledger-head">
              <h2>Danh sách đơn</h2>
              <span>
                {pcRows.length} đơn - Tổng {formatVND(pcRevenue)}
              </span>
            </div>
            {deepOrder && !filtered.some((o) => o.id === deepOrder.id) && (
              <p className="v6demo-deep-hint">Đơn mở từ Sổ quỹ đang hiển thị ở đầu danh sách.</p>
            )}
            {busy ? (
              <p className="v6demo-empty">Đang tải…</p>
            ) : pcRows.length === 0 ? (
              <p className="v6demo-empty">Chưa có đơn hàng nào trong khoảng này.</p>
            ) : (
              <div>
                {pcRows.map((o) => {
                  const cust = customerOf(o);
                  const isOpen = expandedId === o.id;
                  const badgeCls = isSplitPayment(o)
                    ? 'v6demo-badge mute'
                    : isDebtOrder(o)
                      ? 'v6demo-badge debt'
                      : 'v6demo-badge';
                  return (
                    <article
                      key={o.id}
                      className={`v6demo-order-row${isOpen ? ' is-open' : ''}`}
                      onClick={() => selectRow(o)}
                      title={itemsFull(o)}
                    >
                      <div className="v6demo-code-badge">
                        {o.code}
                        <small>{formatTime(o.created_at)}</small>
                      </div>
                      <div className="v6demo-row-main">
                        <b className="v6demo-ellipsis">{cust ? cust.name : 'Khách lẻ'}</b>
                        <p className="v6demo-ellipsis">{itemsSummary(o)}</p>
                        <div className="v6demo-row-meta">
                          {formatDMY(o.business_date)}
                          {o.warehouse_name ? ` - ${o.warehouse_name}` : ''} -{' '}
                          <span className={badgeCls}>{payLabel(o)}</span>
                          {o.status !== 'done' && (
                            <>
                              {' '}
                              <span className="v6demo-badge mute">
                                {STATUS_LABEL[o.status] ?? o.status}
                              </span>
                            </>
                          )}
                        </div>
                      </div>
                      <div className="v6demo-row-right">
                        <span className="v6demo-price v6demo-row-total">{formatVND(o.total)}</span>
                        <div className="v6demo-row-acts">
                          <button
                            type="button"
                            className="v6demo-mini-btn"
                            aria-label={`Xem chi tiết đơn ${o.code}`}
                            onClick={(e) => {
                              e.stopPropagation();
                              selectRow(o);
                            }}
                          >
                            <LineIcon name="eye" size={14} /> Xem
                          </button>
                          {can('orders.edit') && (
                            <button
                              type="button"
                              className="v6demo-mini-btn"
                              aria-label={`Sửa đơn ${o.code}`}
                              onClick={(e) => {
                                e.stopPropagation();
                                openPcEdit(o);
                              }}
                            >
                              <LineIcon name="edit" size={14} /> Sửa
                            </button>
                          )}
                          {canDeleteRow && o.status !== 'cancelled' && (
                            <button
                              type="button"
                              className="v6demo-mini-btn danger"
                              aria-label={`Xóa đơn ${o.code}`}
                              onClick={(e) => {
                                e.stopPropagation();
                                void quickDelete(o);
                              }}
                            >
                              <LineIcon name="trash" size={14} /> Xóa
                            </button>
                          )}
                        </div>
                      </div>
                    </article>
                  );
                })}
              </div>
            )}
            <p className="v6demo-ledger-foot">
              Xóa đơn chỉ dành cho chủ quán. Đơn ghi nợ khi xóa sẽ được hoàn công nợ, khoản quỹ tự
              động của đơn bị xóa theo.
            </p>
          </section>
        </div>
        {selectedOrder && expandedId === selectedOrder.id && (
          <>
            <div
              className="v6demo-backdrop"
              onClick={() => {
                setPcEditFor(null);
                setExpandedId(null);
              }}
            />
            <section className="v6demo-panel v6demo-panel-in" aria-label="Chi tiết đơn hàng">
              <div className="v6demo-panel-head">
                <div>
                  <h2>Chi tiết đơn {selectedOrder.code}</h2>
                  <p>
                    {formatDMY(selectedOrder.business_date)} - {formatTime(selectedOrder.created_at)}{' '}
                    - {payLabel(selectedOrder)} - {STATUS_LABEL[selectedOrder.status] ?? selectedOrder.status}
                  </p>
                </div>
                <button
                  className="v6demo-close-btn"
                  type="button"
                  onClick={() => {
                    setPcEditFor(null);
                    setExpandedId(null);
                  }}
                  aria-label="Đóng chi tiết"
                >
                  <LineIcon name="x" size={18} />
                </button>
              </div>
              {can('orders.edit') && (
                <>
                  <div className="v6demo-panel-acts">
                    <button
                      type="button"
                      className="v6demo-btn v6demo-btn-ghost v6demo-btn-sm"
                      onClick={() => openPcEdit(selectedOrder)}
                    >
                      <LineIcon name="edit" size={16} /> Sửa ghi chú
                    </button>
                    <button
                      type="button"
                      className="v6demo-btn v6demo-btn-ghost v6demo-btn-sm"
                      onClick={() => openPcEdit(selectedOrder)}
                    >
                      <LineIcon name="users" size={16} /> Sửa khách hàng
                    </button>
                  </div>
                  <p className="v6demo-panel-hint">
                    Cả hai nút đều mở form sửa nhanh của đơn (ghi chú và khách hàng).
                  </p>
                </>
              )}
              <div className="v6demo-panel-body">
                <OrderCardExpanded
                  key={
                    pcEditFor === selectedOrder.id
                      ? `${selectedOrder.id}:edit:${pcEditKey}`
                      : selectedOrder.id
                  }
                  initialMode={pcEditFor === selectedOrder.id ? 'edit' : 'view'}
                  order={selectedOrder}
                  customer={customerOf(selectedOrder)}
                  canEdit={can('orders.edit')}
                  canDelete={can('orders.delete')}
                  onChanged={pcChanged}
                  methods={methods}
                  fallbackBank={fallbackBank}
                  shopName={shopName}
                  shopPhone={shopPhone}
                  shopAddress={shopAddress}
                  shopLogo={shopLogo}
                />
              </div>
            </section>
          </>
        )}
      </div>
    );
  }

  return (
    <div className="page v6demo-orders v6demo-page">
      <div className="v6demo-aurora" aria-hidden />
      <div className="v6demo-content">
        <PageHead title="Đơn hàng" back />

        <div className="v6demo-page-head v6demo-rise">
          <p>Xem, sửa và xóa các đơn đã bán. Bấm một dòng để mở chi tiết.</p>
        </div>

        <section className="v6demo-glass v6demo-dock v6demo-rise-2" aria-label="Bộ lọc đơn hàng">
          <div className="v6demo-dock-row">
            <label className="v6demo-search">
              <LineIcon name="search" size={18} />
              <input
                placeholder="Tìm mã đơn, tên, SĐT khách…"
                value={q}
                onChange={(e) => setQ(e.target.value)}
                aria-label="Tìm đơn hàng"
              />
            </label>
            <select
              className="v6demo-input v6demo-payselect"
              value={payFilter}
              onChange={(e) => setPayFilter(e.target.value)}
              aria-label="Lọc theo phương thức thanh toán"
            >
              <option value="all">Tất cả phương thức</option>
              {methods.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name}
                </option>
              ))}
            </select>
          </div>
          <div className="v6demo-dock-row">
            <label className="v6demo-date-label" htmlFor="v6demo-mb-period">
              Kỳ
            </label>
            <select
              id="v6demo-mb-period"
              className="v6demo-input v6demo-orders-period"
              value={filter}
              onChange={(e) => {
                const k = e.target.value as FilterKey;
                setFilter(k);
                void load(k, whFilter);
              }}
              aria-label="Lọc theo thời gian"
            >
              {FILTERS.map((f) => (
                <option key={f.key} value={f.key}>
                  {f.label}
                </option>
              ))}
            </select>
          </div>
          {filter === 'custom' && (
            <div className="v6demo-dock-row v6demo-date-row">
              <label className="v6demo-date-label" htmlFor="v6demo-mb-from">
                Từ ngày
              </label>
              <input
                id="v6demo-mb-from"
                className="v6demo-input v6demo-date-input"
                type="date"
                value={customFrom}
                max={todayVN()}
                onChange={(e) => {
                  const v = e.target.value;
                  if (v) {
                    setCustomFrom(v);
                    if (v > customTo) setCustomTo(v);
                  }
                }}
                aria-label="Từ ngày"
              />
              <label className="v6demo-date-label" htmlFor="v6demo-mb-to">
                Đến ngày
              </label>
              <input
                id="v6demo-mb-to"
                className="v6demo-input v6demo-date-input"
                type="date"
                value={customTo}
                max={todayVN()}
                min={customFrom}
                onChange={(e) => {
                  const v = e.target.value;
                  if (v) setCustomTo(v);
                }}
                aria-label="Đến ngày"
              />
              <button
                type="button"
                className="v6demo-btn v6demo-btn-dark v6demo-btn-sm"
                onClick={() => void load('custom', whFilter, customFrom, customTo)}
              >
                Áp dụng kỳ
              </button>
            </div>
          )}
          {warehouses.length > 1 && (
            <div className="v6demo-dock-row">
              <button
                type="button"
                className={`v6demo-chip${whFilter === 'all' ? ' active' : ''}`}
                onClick={() => changeWh('all')}
              >
                Mọi kho
              </button>
              {warehouses.map((w) => (
                <button
                  key={w.id}
                  type="button"
                  className={`v6demo-chip${whFilter === w.id ? ' active' : ''}`}
                  onClick={() => changeWh(w.id)}
                >
                  {w.name}
                </button>
              ))}
            </div>
          )}
        </section>

        <section className="v6demo-glass v6demo-ledger v6demo-rise-3">
          <div className="v6demo-ledger-head">
            <h2>Danh sách đơn</h2>
            <span>
              {mobileFiltered.length} đơn - Tổng {formatVND(mobileRevenue)}
            </span>
          </div>
          {busy ? (
            <p className="v6demo-empty">Đang tải…</p>
          ) : (
            <>
              {deepOrder && !filtered.some((o) => o.id === deepOrder.id) && (
                <>
                  <p className="v6demo-deep-hint">Đơn mở từ Sổ quỹ đang hiển thị ở đầu danh sách.</p>
                  <OrderCard
                    order={deepOrder}
                    customer={deepOrder.customer_id ? custMap.get(deepOrder.customer_id) ?? null : null}
                    kindMap={kindMap}
                    onOpen={() => setExpandedId(deepOrder.id)}
                    onEdit={() => openMobileEdit(deepOrder)}
                    canQuickDelete={canDeleteRow}
                    onQuickDelete={quickDelete}
                    canEdit={can('orders.edit')}
                  />
                </>
              )}
              {mobileFiltered.length === 0 && !deepOrder ? (
                <p className="v6demo-empty">Chưa có đơn hàng nào trong khoảng này.</p>
              ) : (
                <div>
                  {mobileFiltered.map((o) => (
                    <OrderCard
                      key={o.id}
                      order={o}
                      customer={o.customer_id ? custMap.get(o.customer_id) ?? null : null}
                      kindMap={kindMap}
                      onOpen={() => setExpandedId(o.id)}
                      onEdit={() => openMobileEdit(o)}
                      canQuickDelete={canDeleteRow}
                      onQuickDelete={quickDelete}
                      canEdit={can('orders.edit')}
                    />
                  ))}
                </div>
              )}
            </>
          )}
          <p className="v6demo-ledger-foot">
            Xóa đơn chỉ dành cho chủ quán. Đơn ghi nợ khi xóa sẽ được hoàn công nợ, khoản quỹ tự
            động của đơn bị xóa theo.
          </p>
        </section>
      </div>
      {mobileSheetOrder && (
        <>
          <div className="v6demo-backdrop" onClick={closeMobileSheet} />
          <section className="v6demo-sheet v6demo-sheet-in" aria-label="Chi tiết đơn hàng">
            <div className="v6demo-panel-head">
              <div>
                <h2>Chi tiết đơn {mobileSheetOrder.code}</h2>
                <p>
                  {formatDMY(mobileSheetOrder.business_date)} -{' '}
                  {formatTime(mobileSheetOrder.created_at)} -{' '}
                  {STATUS_LABEL[mobileSheetOrder.status] ?? mobileSheetOrder.status}
                </p>
              </div>
              <button
                className="v6demo-close-btn"
                type="button"
                onClick={closeMobileSheet}
                aria-label="Đóng chi tiết"
              >
                <LineIcon name="x" size={18} />
              </button>
            </div>
            {can('orders.edit') && (
              <>
                <div className="v6demo-panel-acts">
                  <button
                    type="button"
                    className="v6demo-btn v6demo-btn-ghost v6demo-btn-sm"
                    onClick={() => openMobileEdit(mobileSheetOrder)}
                  >
                    <LineIcon name="edit" size={16} /> Sửa ghi chú
                  </button>
                  <button
                    type="button"
                    className="v6demo-btn v6demo-btn-ghost v6demo-btn-sm"
                    onClick={() => openMobileEdit(mobileSheetOrder)}
                  >
                    <LineIcon name="users" size={16} /> Sửa khách hàng
                  </button>
                </div>
                <p className="v6demo-panel-hint">
                  Cả hai nút đều mở form sửa nhanh của đơn (ghi chú và khách hàng).
                </p>
              </>
            )}
            <div className="v6demo-panel-body">
              <OrderCardExpanded
                key={
                  pcEditFor === mobileSheetOrder.id
                    ? `${mobileSheetOrder.id}:edit:${pcEditKey}`
                    : mobileSheetOrder.id
                }
                initialMode={pcEditFor === mobileSheetOrder.id ? 'edit' : 'view'}
                order={mobileSheetOrder}
                customer={
                  mobileSheetOrder.customer_id
                    ? custMap.get(mobileSheetOrder.customer_id) ?? null
                    : null
                }
                canEdit={can('orders.edit')}
                canDelete={can('orders.delete')}
                onChanged={handleChanged}
                methods={methods}
                fallbackBank={fallbackBank}
                shopName={shopName}
                shopPhone={shopPhone}
                shopAddress={shopAddress}
                shopLogo={shopLogo}
              />
            </div>
          </section>
        </>
      )}
    </div>
  );
}


/**
 * Một dòng sổ cái trong danh sách đơn (bố cục mới v6 demo): mã đơn + giờ,
 * khách hàng, món tóm tắt, ngày - kho - phương thức, tổng tiền và 3 nút
 * Xem / Sửa / Xóa. Bấm dòng hoặc nút Xem để mở panel chi tiết (PC) hoặc
 * sheet chi tiết (mobile); chi tiết đầy đủ nằm trong OrderCardExpanded.
 */
function OrderCard({
  order,
  customer,
  kindMap,
  onOpen,
  onEdit,
  canQuickDelete,
  onQuickDelete,
  canEdit,
}: {
  order: Order;
  customer: Customer | null;
  kindMap: Map<string, string>;
  onOpen: () => void;
  onEdit: () => void;
  canQuickDelete: boolean;
  onQuickDelete: (o: { id: string; code: string; total: number }) => void;
  canEdit: boolean;
}) {
  const parts = order.items.map((it) => `${it.product_name} x${it.qty}`);
  const summary =
    parts.length === 0
      ? 'Không có món'
      : parts.length <= 3
        ? parts.join(', ')
        : `${parts.slice(0, 3).join(', ')} và ${parts.length - 3} món khác`;
  const full = parts.length === 0 ? 'Không có món' : parts.join(', ');
  const kind = kindMap.get(order.payment_method) ?? '';
  const methodLabel = isSplitPayment(order)
    ? 'Hỗn hợp'
    : (order.payment_method_name ??
      (kind === 'cash'
        ? 'Tiền mặt'
        : kind === 'transfer'
          ? 'Chuyển khoản'
          : kind === 'debt'
            ? 'Ghi nợ'
            : order.payment_method));
  const methodBadgeCls = isSplitPayment(order)
    ? 'v6demo-badge mute'
    : kind === 'debt'
      ? 'v6demo-badge debt'
      : 'v6demo-badge';
  return (
    <article className="v6demo-order-row" onClick={onOpen} title={full}>
      <div className="v6demo-code-badge">
        {order.code}
        <small>{formatTime(order.created_at)}</small>
      </div>
      <div className="v6demo-row-main">
        <b className="v6demo-ellipsis">{customer ? customer.name : 'Khách lẻ'}</b>
        <p className="v6demo-ellipsis">{summary}</p>
        <div className="v6demo-row-meta">
          {formatDMY(order.business_date)}
          {order.warehouse_name ? ` - ${order.warehouse_name}` : ''} -{' '}
          <span className={methodBadgeCls}>{methodLabel}</span>
          {order.status !== 'done' && (
            <>
              {' '}
              <span className="v6demo-badge mute">{STATUS_LABEL[order.status] ?? order.status}</span>
            </>
          )}
        </div>
      </div>
      <div className="v6demo-row-right">
        <span className="v6demo-price v6demo-row-total">{formatVND(order.total)}</span>
        <div className="v6demo-row-acts">
          <button
            type="button"
            className="v6demo-mini-btn"
            aria-label={`Xem chi tiết đơn ${order.code}`}
            onClick={(e) => {
              e.stopPropagation();
              onOpen();
            }}
          >
            <LineIcon name="eye" size={14} /> Xem
          </button>
          {canEdit && (
            <button
              type="button"
              className="v6demo-mini-btn"
              aria-label={`Sửa đơn ${order.code}`}
              onClick={(e) => {
                e.stopPropagation();
                onEdit();
              }}
            >
              <LineIcon name="edit" size={14} /> Sửa
            </button>
          )}
          {canQuickDelete && order.status !== 'cancelled' && (
            <button
              type="button"
              className="v6demo-mini-btn danger"
              aria-label={`Xóa đơn ${order.code}`}
              onClick={(e) => {
                e.stopPropagation();
                void onQuickDelete(order);
              }}
            >
              <LineIcon name="trash" size={14} /> Xóa
            </button>
          )}
        </div>
      </div>
    </article>
  );
}

/** Phần chi tiết mở rộng trong thẻ đơn: thay cho Sheet chi tiết cũ, giữ nguyên mọi thao tác. */
function OrderCardExpanded({
  order,
  customer,
  canEdit,
  canDelete,
  onChanged,
  methods,
  fallbackBank,
  shopName,
  shopPhone,
  shopAddress,
  shopLogo,
  // PC: cho phep panel PC mo thang form sua nhanh (mode 'edit').
  // Mobile khong truyen prop nay nen mac dinh 'view', hanh vi khong doi.
  initialMode = 'view',
}: {
  order: Order;
  customer: Customer | null;
  canEdit: boolean;
  canDelete: boolean;
  onChanged: () => void;
  methods: PaymentMethodDef[];
  fallbackBank: { bin: string; account: string; name: string };
  shopName: string;
  shopPhone: string;
  shopAddress: string;
  shopLogo: string;
  initialMode?: 'view' | 'edit';
}) {
  const toast = useToast();
  const [mode, setMode] = useState<'view' | 'edit' | 'confirmDelete' | 'bill'>(initialMode);
  const [editFull, setEditFull] = useState(false);
  const [note, setNote] = useState(order.note ?? '');
  const [cust, setCust] = useState<Customer | null>(customer);
  const [pickOpen, setPickOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [billBusy, setBillBusy] = useState(false);
  const canFullEdit = canDelete && order.status !== 'cancelled';

  // v6.3: xem lại bill của đơn đã lưu — tính QR đúng logic lúc thanh toán
  // (CheckoutModal): chỉ đơn có phần chuyển khoản + quán đã cấu hình BIN/STK
  // cho phương thức đó mới có QR; đơn chỉ tiền mặt hoặc chỉ ghi nợ thì không.
  const split = isSplitPayment(order);
  const splits = split ? orderPaymentSplits(order) : [];
  const transferSplits = splits.filter((sp) => sp.kind === 'transfer');
  const transferMethod = transferSplits.length > 0
    ? (methods.find((m) => m.id === transferSplits[0].method_id) ?? null)
    : null;
  const singleMethod = !split ? (methods.find((m) => m.id === order.payment_method) ?? null) : null;
  let transferTotal = 0;
  let qrBin = '';
  let qrAccount = '';
  let qrName = shopName;
  if (split) {
    transferTotal = transferSplits.reduce((a, sp) => a + sp.amount, 0);
    qrBin = transferMethod?.bank_bin ?? '';
    qrAccount = transferMethod?.bank_account ?? '';
    qrName = transferMethod?.bank_account_name ?? fallbackBank.name ?? shopName;
  } else if (singleMethod?.kind === 'transfer') {
    transferTotal = order.total;
    qrBin = singleMethod.bank_bin ?? fallbackBank.bin ?? '';
    qrAccount = singleMethod.bank_account ?? fallbackBank.account ?? '';
    qrName = singleMethod.bank_account_name ?? fallbackBank.name ?? shopName;
  } else if (order.payment_method === 'transfer') {
    // Đơn cũ lưu phương thức dạng kind, không tra được method def: dùng
    // cấu hình ngân hàng dự phòng trong settings (như CheckoutModal).
    transferTotal = order.total;
    qrBin = fallbackBank.bin;
    qrAccount = fallbackBank.account;
    qrName = fallbackBank.name || shopName;
  }
  const showBillQR = transferTotal > 0 && !!qrBin && !!qrAccount;

  const handleSaveBillImage = async () => {
    if (billBusy) return;
    setBillBusy(true);
    try {
      await saveBillImage(order.code);
      toast.show('Đã lưu ảnh hóa đơn');
    } catch (e) {
      console.error('saveBillImage failed', e);
      toast.show(`Không lưu được ảnh: ${e instanceof Error ? e.message : 'lỗi không rõ'}`);
    } finally {
      setBillBusy(false);
    }
  };

  const handleShareBillZalo = async () => {
    if (billBusy) return;
    setBillBusy(true);
    try {
      // Chỉ gửi ẢNH bill, không kèm bất kỳ chữ nào (như v5.15).
      const res = await shareBillImage(order.code);
      if (res === 'fallback') {
        toast.show('Đã tải ảnh bill. Mở Zalo để gửi cho khách.');
        if (customer?.phone) {
          window.open(`https://zalo.me/${zaloPhone(customer.phone)}`, '_blank');
        }
      }
    } catch (e) {
      if (e instanceof DOMException && e.name === 'AbortError') return;
      console.error('shareBillImage failed', e);
      toast.show(`Không gửi được bill: ${e instanceof Error ? e.message : 'lỗi không rõ'}`);
    } finally {
      setBillBusy(false);
    }
  };

  const doSave = async () => {
    setBusy(true);
    try {
      await updateOrderMeta(order.id, { note: note.trim() || null, customerId: cust ? cust.id : null });
      toast.show(`Đã lưu thay đổi đơn ${order.code}`);
      onChanged();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  const doDelete = async () => {
    setBusy(true);
    try {
      await deleteOrder(order.id);
      toast.show(`Đã xóa đơn ${order.code}`);
      onChanged();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Xóa thất bại');
    } finally {
      setBusy(false);
    }
  };

  if (editFull) {
    return (
      <OrderEditForm
        order={order}
        customer={cust ?? customer}
        onClose={() => setEditFull(false)}
        onSaved={onChanged}
      />
    );
  }

  return (
    <div className="ord-detail">
      {mode === 'bill' ? (
        <>
          <BillPrint
            order={order}
            shopName={shopName}
            shopPhone={shopPhone}
            shopAddress={shopAddress}
            shopLogo={shopLogo}
            qrBin={showBillQR ? qrBin : null}
            qrName={showBillQR ? qrName : undefined}
            qrAccount={showBillQR ? qrAccount : undefined}
            qrAmount={showBillQR ? transferTotal : undefined}
          />
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 8, marginTop: 10 }}>
            <button className="btn btn-outline btn-block co-ico-label v6demo-btn v6demo-btn-ghost" disabled={billBusy} onClick={() => void handleSaveBillImage()}>
              {billBusy ? 'Đang xử lý…' : <><LineIcon name="camera" size={16} /> Lưu ảnh bill</>}
            </button>
            <button className="btn btn-outline btn-block co-ico-label v6demo-btn v6demo-btn-ghost" disabled={billBusy} onClick={() => void handleShareBillZalo()}>
              {billBusy ? 'Đang xử lý…' : <><LineIcon name="chat" size={16} /> Gửi Zalo</>}
            </button>
          </div>
          <button className="btn btn-ghost btn-block v6demo-btn v6demo-btn-ghost" style={{ marginTop: 8 }} onClick={() => setMode('view')}>
            Quay lại chi tiết đơn
          </button>
        </>
      ) : mode === 'confirmDelete' ? (
        <>
          <p style={{ margin: '4px 0 12px', lineHeight: 1.6 }}>
            Xóa đơn <b>{order.code}</b> ({formatVND(order.total)})? Doanh thu và công nợ liên quan sẽ
            được hoàn lại. Thao tác này không thể hoàn tác.
          </p>
          <div className="row" style={{ gap: 8 }}>
            <button className="btn btn-outline btn-block v6demo-btn v6demo-btn-ghost" disabled={busy} onClick={() => setMode('view')}>
              Giữ lại
            </button>
            <button className="btn btn-block v6demo-btn v6demo-btn-danger" disabled={busy} onClick={doDelete}>
              {busy ? 'Đang xóa…' : 'Xóa đơn'}
            </button>
          </div>
        </>
      ) : mode === 'edit' ? (
        <>
          <div className="field">
            <label>Khách hàng</label>
            <button className="sb-row" type="button" onClick={() => setPickOpen(true)}>
              <span className="avatar">{cust ? cust.name.charAt(0).toUpperCase() : <LineIcon name="users" size={16} />}</span>
              <span className="rbody">
                <span className="rtitle">{cust ? cust.name : 'Khách lẻ'}</span>
                <span className="rsub">{cust ? cust.phone : 'Bấm để chọn khách'}</span>
              </span>
              <span className="text-green" style={{ fontWeight: 600 }}>
                Đổi ›
              </span>
            </button>
            {cust && (
              <button
                type="button"
                className="btn btn-ghost btn-sm"
                style={{ marginTop: 6 }}
                onClick={() => setCust(null)}
              >
                Bỏ chọn (về khách lẻ)
              </button>
            )}
          </div>
          <div className="field">
            <label>Ghi chú đơn</label>
            <input
              className="input"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Ghi chú…"
              maxLength={1000}
            />
          </div>
          <p className="small muted">Sửa nhanh ghi chú và khách hàng. Muốn sửa món/giá/voucher/thanh toán thì dùng “Sửa đơn” (chỉ chủ quán).</p>
          <div className="row" style={{ gap: 8 }}>
            <button className="btn btn-outline btn-block v6demo-btn v6demo-btn-ghost" disabled={busy} onClick={() => setMode('view')}>
              Hủy
            </button>
            <button className="btn btn-block v6demo-btn v6demo-btn-primary" disabled={busy} onClick={doSave}>
              {busy ? 'Đang lưu…' : 'Lưu'}
            </button>
          </div>
        </>
      ) : (
        <>
          <div className="ord-section" style={{ marginBottom: 10 }}>
            <div className="row" style={{ justifyContent: 'space-between', marginBottom: 6 }}>
              <span className="muted">Khách hàng</span>
              <b>{customer ? `${customer.name} · ${customer.phone}` : 'Khách lẻ'}</b>
            </div>
            <div className="row" style={{ justifyContent: 'space-between', marginBottom: 6 }}>
              <span className="muted">Thanh toán</span>
              <b>{isSplitPayment(order) ? (<><LineIcon name="card" size={14} style={{ display: 'inline-block', verticalAlign: '-3px' }} /> Hỗn hợp</>) : (order.payment_method_name ?? order.payment_method)}</b>
            </div>
            {isSplitPayment(order) &&
              orderPaymentSplits(order).map((sp) => (
                <div className="row" key={sp.method_id} style={{ justifyContent: 'space-between', marginBottom: 4 }}>
                  <span className="muted small" style={{ paddingLeft: 12 }}>
                    {sp.kind === 'cash' ? (<LineIcon name="wallet" size={14} style={{ display: 'inline-block', verticalAlign: '-3px' }} />) : sp.kind === 'transfer' ? (<LineIcon name="phone" size={14} style={{ display: 'inline-block', verticalAlign: '-3px' }} />) : (<LineIcon name="ledger" size={14} style={{ display: 'inline-block', verticalAlign: '-3px' }} />)}{' '}{sp.method_name}
                  </span>
                  <b className="money">{formatVND(sp.amount)}</b>
                </div>
              ))}
            {order.payment_method === 'cash' && order.amount_received != null && (
              <div className="row" style={{ justifyContent: 'space-between', marginBottom: 6 }}>
                <span className="muted">Khách đưa / thối lại</span>
                <b>{formatVND(order.amount_received)} / {formatVND(order.change_amount ?? 0)}</b>
              </div>
            )}
            {order.warehouse_name && (
              <div className="row" style={{ justifyContent: 'space-between', marginBottom: 6 }}>
                <span className="muted">Kho trừ tồn</span>
                <b><LineIcon name="archive" size={14} style={{ display: "inline-block", verticalAlign: "-3px" }} /> {order.warehouse_name}</b>
              </div>
            )}
            {order.note && (
              <div className="row" style={{ justifyContent: 'space-between' }}>
                <span className="muted">Ghi chú</span>
                <b style={{ textAlign: 'right', maxWidth: '60%' }}>{order.note}</b>
              </div>
            )}
          </div>

          <div className="ord-section" style={{ marginBottom: 10 }}>
            <div className="small muted" style={{ fontWeight: 600, padding: '4px 0 2px' }}>
              Tất cả món ({order.items.length})
            </div>
            {order.items.map((it) => (
              <div className="ord-item" key={it.id}>
                <span className="ord-item-name">
                  {it.product_name} <span className="muted">× {it.qty}</span>
                  {it.modifiers.length > 0 && (
                    <span className="rsub" style={{ display: 'block' }}>
                      {it.modifiers.map((m) => `${m.group}: ${m.option}`).join(' · ')}
                    </span>
                  )}
                  {it.note && <span className="rsub" style={{ display: 'block' }}>“{it.note}”</span>}
                  {it.discount ? (
                    <span className="rsub" style={{ display: 'block', color: 'var(--green)' }}>
                      Giảm {it.discount_type === 'percent' ? `${it.discount_value}%` : 'tiền'}: −{formatVND(it.discount)}
                    </span>
                  ) : null}
                </span>
                <span className="ord-item-price">{formatVND(it.line_total)}</span>
              </div>
            ))}
          </div>

          <div className="ord-section">
            {(order.discount > 0 || order.shipping_fee > 0) && (
              <div className="row" style={{ justifyContent: 'space-between' }}>
                <span className="muted">Tạm tính</span>
                <span>{formatVND(order.subtotal)}</span>
              </div>
            )}
            {order.discount > 0 && (
              <div className="row" style={{ justifyContent: 'space-between', color: 'var(--green)' }}>
                <span>
                  Giảm giá{order.discount_label ? ` (${order.discount_label})` : ''}
                </span>
                <span>-{formatVND(order.discount)}</span>
              </div>
            )}
            {order.shipping_fee > 0 && (
              <div className="row" style={{ justifyContent: 'space-between' }}>
                <span className="muted">Phí ship</span>
                <span>+{formatVND(order.shipping_fee)}</span>
              </div>
            )}
          </div>

          <div className="ord-actions ord-section">
            <BluetoothPrintButton order={order} small />
            {order.status !== 'cancelled' && (
              <button className="btn btn-outline btn-sm" style={{ padding: '8px 4px', fontSize: 13 }} onClick={() => setMode('bill')}>
                <LineIcon name="receipt" size={14} /> Xem bill
              </button>
            )}
            {canFullEdit && (
              <button className="btn btn-outline btn-sm" style={{ padding: '8px 4px', fontSize: 13 }} onClick={() => setEditFull(true)}>
                <LineIcon name="edit" size={14} /> Sửa đơn
              </button>
            )}
            {canEdit && (
              <button className="btn btn-outline btn-sm" style={{ padding: '8px 4px', fontSize: 13 }} onClick={() => setMode('edit')}>
                Sửa ghi chú
              </button>
            )}
            {canDelete && order.status !== 'cancelled' && (
              <button
                className="btn btn-sm v6demo-btn v6demo-btn-danger v6demo-btn-sm"
                style={{ padding: '8px 4px', fontSize: 13 }}
                onClick={() => setMode('confirmDelete')}
              >
                Xóa đơn
              </button>
            )}
          </div>
        </>
      )}

      {pickOpen && (
        <CustomerPickSheet
          onClose={() => setPickOpen(false)}
          onPick={(c) => {
            setCust(c);
            setPickOpen(false);
          }}
        />
      )}
    </div>
  );
}
