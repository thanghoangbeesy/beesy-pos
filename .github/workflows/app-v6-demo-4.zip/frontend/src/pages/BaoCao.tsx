import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { DbError, applyGoodsCosts, downloadFile, exportOrdersCsv, getAllowedWarehouses, getRangeReport, getSettings, listAllCashbookEntries, listAllStockLogs, listLowStock, listWarehouseStock } from '../lib/db';
import { inventoryValueOf, ledgerValueTotals, summarizeLedger } from '../lib/stock-ledger';
import {
  addDaysVN,
  formatVND,
  startOfMonthVN,
  startOfWeekVN,
  todayVN,
} from '../lib/format';
import { useToast } from '../components/Toast';
import { useAuth } from '../lib/auth';
import { LineIcon } from '../components/LineIcon';
import type { CashbookEntry, DailyReport, IngredientWithStock, Warehouse } from '../lib/types';
import './v6demo-theme.css';
import './v6demo-baocao.css';

type PresetKey = 'today' | 'yesterday' | 'thisWeek' | 'lastWeek' | 'thisMonth' | 'lastMonth' | 'custom';
type TabKey = 'products' | 'hours' | 'promo' | 'cashflow' | 'profit' | 'stock';

const PRESETS: { key: PresetKey; label: string }[] = [
  { key: 'today', label: 'Hôm nay' },
  { key: 'yesterday', label: 'Hôm qua' },
  { key: 'thisWeek', label: 'Tuần này' },
  { key: 'lastWeek', label: 'Tuần trước' },
  { key: 'thisMonth', label: 'Tháng này' },
  { key: 'lastMonth', label: 'Tháng trước' },
  { key: 'custom', label: 'Tùy chọn' },
];

/** YYYY-MM-DD theo giờ VN từ chuỗi ISO — cùng cách Sổ Quỹ xếp ngày khoản quỹ. */
function vnDateKey(iso: string): string {
  try {
    return new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Ho_Chi_Minh',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    }).format(new Date(iso));
  } catch {
    return (iso || '').slice(0, 10);
  }
}

function presetRange(key: PresetKey, cs: string, ce: string): [string, string] {
  const t = todayVN();
  switch (key) {
    case 'today': return [t, t];
    case 'yesterday': { const y = addDaysVN(t, -1); return [y, y]; }
    case 'thisWeek': return [startOfWeekVN(t), t];
    case 'lastWeek': {
      const m = startOfWeekVN(t);
      const ml = addDaysVN(m, -7);
      return [ml, addDaysVN(ml, 6)];
    }
    case 'thisMonth': return [startOfMonthVN(t), t];
    case 'lastMonth': {
      const f = startOfMonthVN(t);
      const l = addDaysVN(f, -1);
      return [startOfMonthVN(l), l];
    }
    case 'custom': return [cs, ce];
  }
}

const TABS: { key: TabKey; label: string; icon: string }[] = [
  { key: 'products', label: 'Món bán', icon: 'receipt' },
  { key: 'hours', label: 'Theo giờ', icon: 'clock' },
  { key: 'promo', label: 'Khuyến mại', icon: 'gift' },
  { key: 'cashflow', label: 'Dòng tiền', icon: 'wallet' },
  { key: 'profit', label: 'Lợi nhuận', icon: 'chart' },
  { key: 'stock', label: 'Tồn kho', icon: 'archive' },
];

export function BaoCao() {
  const toast = useToast();
  const { can } = useAuth();
  const [tab, setTab] = useState<TabKey>('products');
  const [preset, setPreset] = useState<PresetKey>('today');
  const [customStart, setCustomStart] = useState(todayVN());
  const [customEnd, setCustomEnd] = useState(todayVN());
  const [report, setReport] = useState<DailyReport | null>(null);
  const [cashflow, setCashflow] = useState<CashbookEntry[]>([]);
  const [busy, setBusy] = useState(false);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [isOwner, setIsOwner] = useState(false);
  const [whFilter, setWhFilter] = useState('all');
  const [sortKey, setSortKey] = useState<'qty' | 'revenue' | 'profit'>('revenue');
  const [sortDir, setSortDir] = useState<'desc' | 'asc'>('desc');
  const [includeGoods, setIncludeGoods] = useState(false);
  const [exportBusy, setExportBusy] = useState(false);

  const scopeIds = whFilter === 'all' ? (isOwner ? undefined : warehouses.map((w) => w.id)) : [whFilter];

  const load = useCallback(async (key: PresetKey, cs: string, ce: string, ids?: string[]) => {
    const [s, e] = presetRange(key, cs, ce);
    if (!s || !e || s > e) { toast.show('Khoảng ngày không hợp lệ'); return; }
    setBusy(true);
    try {
      const [data, entries, st] = await Promise.all([
        getRangeReport(s, e, ids),
        listAllCashbookEntries(),
        getSettings(),
      ]);
      setReport(data);
      setIncludeGoods(st['include_goods_costs'] === '1');
      // Lọc khoản quỹ trong kỳ: ngày theo GIỜ VN (khớp Sổ Quỹ — trước đây cắt
      // chuỗi UTC nên khoản 00:00-06:59 bị tính sang ngày trước) và lọc theo kho
      // như các tab khác (trước đây tab Dòng tiền hiện mọi kho).
      setCashflow(entries.filter((en) => {
        const d = vnDateKey(en.created_at || '');
        if (d < s || d > e) return false;
        if (ids && ids.length > 0) return !!en.warehouse_id && ids.includes(en.warehouse_id);
        return true;
      }));
    } catch (err) {
      toast.show(err instanceof DbError ? err.message : 'Không tải được báo cáo');
    } finally {
      setBusy(false);
    }
  }, [toast]);

  useEffect(() => {
    getAllowedWarehouses()
      .then(({ warehouses: ws, isOwner: ow }) => {
        setWarehouses(ws);
        setIsOwner(ow);
        const ids = ow ? undefined : ws.map((w) => w.id);
        void load('today', todayVN(), todayVN(), ids);
      })
      .catch(() => { void load('today', todayVN(), todayVN()); });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const pickPreset = (key: PresetKey) => {
    setPreset(key);
    void load(key, customStart, customEnd, scopeIds);
  };

  const changeWh = (id: string) => {
    setWhFilter(id);
    const ids = id === 'all' ? (isOwner ? undefined : warehouses.map((w) => w.id)) : [id];
    void load(preset, customStart, customEnd, ids);
  };

  const sortedProducts = useMemo(() => {
    const arr = [...(report?.top_products ?? [])];
    arr.sort((a, b) => {
      const d = a[sortKey] - b[sortKey];
      return sortDir === 'desc' ? -d : d;
    });
    return arr;
  }, [report, sortKey, sortDir]);

  const maxHour = Math.max(1, ...(report?.by_hour.map((h) => h.revenue) ?? [1]));
  const bestHour = useMemo(() => {
    if (!report) return null;
    return [...report.by_hour].sort((a, b) => b.revenue - a.revenue)[0];
  }, [report]);

  // Dòng tiền: tổng thu/chi
  const cashStats = useMemo(() => {
    let thu = 0, chi = 0;
    const byCat: Record<string, { name: string; thu: number; chi: number }> = {};
    for (const en of cashflow) {
      // Chuyển quỹ nội bộ không phải thu/chi thực — loại khỏi tổng như Sổ Quỹ
      // khi xem tất cả quỹ (trước đây cộng cả 2 vế nên Tổng thu/chi phồng lên)
      if (en.ref_type === 'transfer') continue;
      const amt = en.amount || 0;
      if (en.type === 'thu') thu += amt;
      else chi += amt;
      const cat = en.category || 'Khác';
      const slot = byCat[cat] ?? { name: cat, thu: 0, chi: 0 };
      if (en.type === 'thu') slot.thu += amt;
      else slot.chi += amt;
      byCat[cat] = slot;
    }
    return { thu, chi, net: thu - chi, byCat: Object.values(byCat).sort((a, b) => (b.thu + b.chi) - (a.thu + a.chi)) };
  }, [cashflow]);

  const doExport = async () => {
    setExportBusy(true);
    try {
      const [s, e] = presetRange(preset, customStart, customEnd);
      const csv = await exportOrdersCsv(s, e, scopeIds);
      const tabName = TABS.find((t) => t.key === tab)?.label ?? 'bao-cao';
      downloadFile(`beesy-${tabName}_${s}_${e}.csv`, csv, 'text/csv');
      toast.show('Đã xuất file Excel');
    } catch (err) {
      toast.show(err instanceof DbError ? err.message : 'Xuất file thất bại');
    } finally {
      setExportBusy(false);
    }
  };

  if (!can('reports')) {
    return (
      <div className="v6demo-page v6demo-baocao">
        <div className="v6demo-aurora" aria-hidden />
        <div className="v6demo-content">
          <div className="v6demo-glass v6demo-baocao-denied">
            <LineIcon name="lock" size={20} /> Chỉ Quản lý trở lên mới được xem báo cáo.
          </div>
        </div>
      </div>
    );
  }

  const rangeLabel = (() => {
    const [s, e] = presetRange(preset, customStart, customEnd);
    return s === e ? s : `${s} → ${e}`;
  })();
  const presetLabel = PRESETS.find((p) => p.key === preset)?.label ?? '';
  const whScopeText = whFilter === 'all' ? 'Mọi kho' : (warehouses.find((w) => w.id === whFilter)?.name ?? '');

  const summaryKpis = report ? [
    { label: 'Doanh thu', value: formatVND(report.revenue), icon: 'wallet', tone: '' },
    { label: 'Phí ship thu hộ', value: formatVND(report.shipping_total ?? 0), icon: 'truck', tone: '' },
    { label: 'Giá vốn', value: formatVND(report.cost), icon: 'package', tone: '' },
    { label: 'Lợi nhuận ròng', value: formatVND(applyGoodsCosts(report, includeGoods).profit), icon: 'chart', tone: 'green' },
    { label: 'Đơn bán', value: String(report.order_count), icon: 'receipt', tone: '' },
    { label: 'Đơn hủy', value: String(report.cancelled_count), icon: 'x', tone: 'red' },
    { label: 'TB/đơn', value: formatVND(Math.round(report.avg_order)), icon: 'tag', tone: '' },
  ] : [];

  return (
    <div className="v6demo-page v6demo-baocao">
      <div className="v6demo-aurora" aria-hidden />
      <div className="v6demo-content">
        <div className="v6demo-baocao-layout">
          <div className="v6demo-baocao-main">
            {/* Hero: doanh thu ky dang xem */}
            <section className="v6demo-baocao-hero v6demo-rise">
              <p className="v6demo-baocao-hero-eyebrow">Báo cáo chi tiết</p>
              <h1>{presetLabel}</h1>
              <div className="v6demo-baocao-hero-big">{busy && !report ? '…' : report ? formatVND(report.revenue) : '—'}</div>
              {report && (
                <p className="v6demo-baocao-hero-cmp">
                  Lợi nhuận ròng <b>{formatVND(applyGoodsCosts(report, includeGoods).profit)}</b> · {report.order_count} đơn bán · {report.cancelled_count} đơn hủy
                </p>
              )}
              <p className="v6demo-baocao-hero-meta">Kỳ {rangeLabel} · Kho: {whScopeText}</p>
            </section>

            {/* Dock loc: ky (listbox du 7 moc) + ngay tuy chon + kho */}
            <section className="v6demo-glass v6demo-baocao-filter v6demo-rise-1">
              <p className="v6demo-section-label" style={{ margin: 0 }}>Chọn kỳ báo cáo</p>
              <select value={preset} onChange={(e) => pickPreset(e.target.value as PresetKey)} className="v6demo-input" aria-label="Chọn kỳ">
                {PRESETS.map((p) => <option key={p.key} value={p.key}>{p.label}</option>)}
              </select>
              {preset === 'custom' && (
                <div className="v6demo-baocao-custom-row">
                  <input type="date" className="v6demo-input" value={customStart} max={todayVN()} onChange={(e) => setCustomStart(e.target.value)} />
                  <span className="v6demo-small v6demo-muted">đến</span>
                  <input type="date" className="v6demo-input" value={customEnd} max={todayVN()} onChange={(e) => setCustomEnd(e.target.value)} />
                  <button className="v6demo-btn v6demo-btn-primary v6demo-btn-sm" onClick={() => pickPreset('custom')}>Xem</button>
                </div>
              )}
              {warehouses.length > 1 && (
                <div className="v6demo-baocao-chips-row">
                  <button className={`v6demo-chip${whFilter === 'all' ? ' active' : ''}`} onClick={() => changeWh('all')}>Mọi kho</button>
                  {warehouses.map((w) => (
                    <button key={w.id} className={`v6demo-chip${whFilter === w.id ? ' active' : ''}`} onClick={() => changeWh(w.id)}>{w.name}</button>
                  ))}
                </div>
              )}
            </section>

            {/* Dai KPI tong hop ky */}
            {report && (
              <div className="v6demo-baocao-kpi-grid v6demo-rise-2">
                {summaryKpis.map((k) => (
                  <div key={k.label} className="v6demo-glass v6demo-glass-sm v6demo-baocao-kpi">
                    <div className="v6demo-baocao-kpi-top">
                      <span
                        className="v6demo-baocao-kpi-ico"
                        style={k.tone === 'red'
                          ? { background: 'var(--vd-red-soft)', color: 'var(--vd-red)' }
                          : { background: 'var(--vd-green-soft)', color: 'var(--vd-green-700)' }}
                      >
                        <LineIcon name={k.icon} size={18} />
                      </span>
                      <span className="v6demo-baocao-kpi-label">{k.label}</span>
                    </div>
                    <div
                      className="v6demo-baocao-kpi-value"
                      style={k.tone === 'green' ? { color: 'var(--vd-green-700)' } : k.tone === 'red' ? { color: 'var(--vd-red)' } : undefined}
                    >
                      {k.value}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Tabs — 6 tab, icon line + chu day du, truot ngang o mobile */}
            <div className="v6demo-baocao-tabs v6demo-rise-3" role="tablist">
              {TABS.map((t) => (
                <button key={t.key} type="button" className={`v6demo-chip${tab === t.key ? ' active' : ''}`} onClick={() => setTab(t.key)}>
                  <LineIcon name={t.icon} size={16} />
                  <span>{t.label}</span>
                </button>
              ))}
            </div>

            {tab === 'stock' ? (
              <div key="stock" className="v6demo-tab-swap">
                <StockReportTab
                  warehouseIds={whFilter === 'all' ? warehouses.map((w) => w.id) : [whFilter]}
                  warehouseNameOf={(id) => warehouses.find((w) => w.id === id)?.name ?? ''}
                  range={presetRange(preset, customStart, customEnd)}
                />
              </div>
            ) : busy && !report ? (
              <div className="v6demo-glass v6demo-card-pad"><p className="v6demo-baocao-note" style={{ margin: 0 }}>Đang tải…</p></div>
            ) : !report ? (
              <div className="v6demo-glass v6demo-card-pad"><p className="v6demo-baocao-note" style={{ margin: 0 }}>Không có dữ liệu</p></div>
            ) : (
              <div key={tab} className="v6demo-tab-swap" style={{ display: 'grid', gap: 18, alignContent: 'start' }}>
                {/* Nut xuat file trong tung tab */}
                <div>
                  <div className="v6demo-baocao-export-row">
                    <button className="v6demo-btn v6demo-btn-ghost v6demo-btn-sm" disabled={exportBusy} onClick={doExport}>
                      {exportBusy ? 'Đang xuất…' : <><LineIcon name="download" size={14} /> Xuất {TABS.find((t) => t.key === tab)?.label}</>}
                    </button>
                  </div>
                  <p className="v6demo-baocao-range-line">Kỳ: {rangeLabel}</p>
                </div>

                {tab === 'products' && (
                  <div className="v6demo-glass v6demo-card-pad">
                    <div className="v6demo-baocao-sort-row">
                      {([['qty', 'Số lượng'], ['revenue', 'Doanh thu'], ['profit', 'Lợi nhuận gộp']] as const).map(([k, label]) => (
                        <button key={k} className={`v6demo-chip${sortKey === k ? ' active' : ''}`} onClick={() => setSortKey(k)}>{label}</button>
                      ))}
                      <button className="v6demo-chip" onClick={() => setSortDir((d) => d === 'desc' ? 'asc' : 'desc')}>
                        {sortDir === 'desc' ? 'Giảm dần' : 'Tăng dần'}
                      </button>
                    </div>
                    <div className="v6demo-table-wrap">
                      <table className="v6demo-tbl">
                        <thead>
                          <tr><th>#</th><th>Món</th><th className="r">SL</th><th className="r">Doanh thu</th><th className="r">Giá vốn</th><th className="r">Lợi nhuận gộp</th></tr>
                        </thead>
                        <tbody>
                          {sortedProducts.map((p, i) => (
                            <tr key={p.product_id}>
                              <td>{i + 1}</td>
                              <td><b>{p.name}</b></td>
                              <td className="r">{p.qty}</td>
                              <td className="r">{formatVND(p.revenue)}</td>
                              <td className="r">{formatVND(p.cost)}</td>
                              <td className="r" style={{ color: '#16A34A', fontWeight: 600 }}>{formatVND(p.profit)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    {sortedProducts.length === 0 && <p className="v6demo-baocao-empty">Chưa có dữ liệu</p>}
                  </div>
                )}

                {tab === 'hours' && (
                  <div className="v6demo-glass v6demo-card-pad">
                    <h3 className="v6demo-card-title">Doanh thu theo giờ</h3>
                    {bestHour && bestHour.revenue > 0 && (
                      <p className="v6demo-card-sub">
                        Giờ bán tốt nhất: <b>{bestHour.hour}h</b> - {formatVND(bestHour.revenue)} ({bestHour.count} đơn)
                      </p>
                    )}
                    <div className="v6demo-baocao-hours">
                      {report.by_hour.map((h) => (
                        <div className="v6demo-baocao-hour" key={h.hour} title={`${h.hour}h: ${formatVND(h.revenue)} (${h.count} đơn)`}>
                          <div className="v6demo-baocao-hour-track">
                            <div className="v6demo-baocao-hour-fill" style={{ height: `${Math.round((h.revenue / maxHour) * 100)}%` }} />
                          </div>
                          <div className="v6demo-baocao-hour-lab">{h.hour}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {tab === 'promo' && (
                  <div className="v6demo-glass v6demo-card-pad">
                    <h3 className="v6demo-card-title">Khuyến mại</h3>
                    <div className="v6demo-baocao-mini-grid">
                      <div className="v6demo-baocao-mini"><span className="v6demo-baocao-mini-label">Đơn KM</span><span className="v6demo-baocao-mini-value">{report.promo_count}</span></div>
                      <div className="v6demo-baocao-mini"><span className="v6demo-baocao-mini-label">Tiền giảm</span><span className="v6demo-baocao-mini-value">{formatVND(report.promo_discount)}</span></div>
                      <div className="v6demo-baocao-mini"><span className="v6demo-baocao-mini-label">Tỉ lệ</span><span className="v6demo-baocao-mini-value">{report.order_count > 0 ? Math.round((report.promo_count / report.order_count) * 100) : 0}%</span></div>
                    </div>
                  </div>
                )}

                {tab === 'cashflow' && (
                  <div className="v6demo-glass v6demo-card-pad">
                    <h3 className="v6demo-card-title">Dòng tiền</h3>
                    <p className="v6demo-card-sub">
                      Tiền thực vào/ra quỹ trong kỳ (gồm thu nợ khách, tiền nhập hàng; đã loại chuyển quỹ
                      nội bộ) - khác Doanh thu bán hàng ở tab Lợi nhuận.
                    </p>
                    <div className="v6demo-baocao-mini-grid" style={{ marginBottom: 12 }}>
                      <div className="v6demo-baocao-mini"><span className="v6demo-baocao-mini-label">Tổng thu</span><span className="v6demo-baocao-mini-value" style={{ color: 'var(--vd-green-700)' }}>{formatVND(cashStats.thu)}</span></div>
                      <div className="v6demo-baocao-mini"><span className="v6demo-baocao-mini-label">Tổng chi</span><span className="v6demo-baocao-mini-value" style={{ color: 'var(--vd-red)' }}>{formatVND(cashStats.chi)}</span></div>
                      <div className="v6demo-baocao-mini"><span className="v6demo-baocao-mini-label">Chênh lệch</span><span className="v6demo-baocao-mini-value">{formatVND(cashStats.net)}</span></div>
                    </div>
                    <h4 className="v6demo-baocao-h4">Theo danh mục</h4>
                    {cashStats.byCat.length === 0 ? (
                      <p className="v6demo-baocao-empty">Chưa có dữ liệu</p>
                    ) : (
                      cashStats.byCat.map((c) => (
                        <div className="v6demo-rowline" key={c.name}>
                          <div style={{ minWidth: 0 }}>
                            <span className="v6demo-baocao-row-title">{c.name}</span>
                            <span className="v6demo-baocao-row-sub">Thu {formatVND(c.thu)} · Chi {formatVND(c.chi)}</span>
                          </div>
                          <span className="v6demo-baocao-row-amount">{formatVND(c.thu - c.chi)}</span>
                        </div>
                      ))
                    )}
                  </div>
                )}

                {tab === 'profit' && (
                  <div className="v6demo-glass v6demo-card-pad">
                    <h3 className="v6demo-card-title">Lợi nhuận</h3>
                    <div className="v6demo-baocao-mini-grid" style={{ marginBottom: 12 }}>
                      <div className="v6demo-baocao-mini"><span className="v6demo-baocao-mini-label">Doanh thu</span><span className="v6demo-baocao-mini-value">{formatVND(report.revenue)}</span></div>
                      <div className="v6demo-baocao-mini"><span className="v6demo-baocao-mini-label">Phí ship thu hộ</span><span className="v6demo-baocao-mini-value">{formatVND(report.shipping_total ?? 0)}</span></div>
                      <div className="v6demo-baocao-mini"><span className="v6demo-baocao-mini-label">Giá vốn</span><span className="v6demo-baocao-mini-value">{formatVND(report.cost)}</span></div>
                      <div className="v6demo-baocao-mini"><span className="v6demo-baocao-mini-label">Chi phí</span><span className="v6demo-baocao-mini-value">{formatVND(applyGoodsCosts(report, includeGoods).expense)}</span></div>
                      {includeGoods && (
                        <div className="v6demo-baocao-mini"><span className="v6demo-baocao-mini-label">Gồm Vận hành + Nhập hàng + Nguyên liệu</span><span className="v6demo-baocao-mini-value">{formatVND(report.expenses)} + {formatVND(report.purchase_costs ?? 0)} + {formatVND(report.cost)}</span></div>
                      )}
                      <div className="v6demo-baocao-mini"><span className="v6demo-baocao-mini-label">Lợi nhuận ròng</span><span className="v6demo-baocao-mini-value" style={{ color: 'var(--vd-green-700)' }}>{formatVND(applyGoodsCosts(report, includeGoods).profit)}</span></div>
                      <div className="v6demo-baocao-mini"><span className="v6demo-baocao-mini-label">Biên LN</span><span className="v6demo-baocao-mini-value">{report.revenue > 0 ? ((applyGoodsCosts(report, includeGoods).profit / report.revenue) * 100).toFixed(1) : 0}%</span></div>
                      <div className="v6demo-baocao-mini"><span className="v6demo-baocao-mini-label">Giảm giá KM</span><span className="v6demo-baocao-mini-value">{formatVND(report.promo_discount)}</span></div>
                      <div className="v6demo-baocao-mini"><span className="v6demo-baocao-mini-label">Số món</span><span className="v6demo-baocao-mini-value">{report.top_products.length}</span></div>
                    </div>
                    <h4 className="v6demo-baocao-h4">Top món lợi nhuận gộp cao</h4>
                    {[...report.top_products].sort((a, b) => b.profit - a.profit).slice(0, 10).map((p, i) => (
                      <div className="v6demo-rowline" key={p.product_id}>
                        <span className="v6demo-baocao-rank">{i + 1}</span>
                        <div style={{ minWidth: 0, flex: 1 }}>
                          <span className="v6demo-baocao-row-title">{p.name}</span>
                          <span className="v6demo-baocao-row-sub">{p.qty} món · vốn {formatVND(p.cost)}</span>
                        </div>
                        <span className="v6demo-baocao-row-amount" style={{ color: '#16A34A' }}>{formatVND(p.profit)}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Rail phai (PC): tom tat ky dang xem + ghi chu cach tinh */}
          {report && (
            <aside className="v6demo-baocao-rail">
              <div className="v6demo-glass v6demo-card-pad v6demo-rise-2">
                <h3 className="v6demo-card-title">Kỳ báo cáo</h3>
                <div className="v6demo-rowline">
                  <span className="v6demo-baocao-row-sub">Kỳ</span>
                  <b style={{ fontSize: 14 }}>{presetLabel}</b>
                </div>
                <div className="v6demo-rowline">
                  <span className="v6demo-baocao-row-sub">Khoảng ngày</span>
                  <b style={{ fontSize: 14 }}>{rangeLabel}</b>
                </div>
                <div className="v6demo-rowline">
                  <span className="v6demo-baocao-row-sub">Kho</span>
                  <b style={{ fontSize: 14 }}>{whScopeText}</b>
                </div>
                <div className="v6demo-rowline">
                  <span className="v6demo-baocao-row-sub">Đơn bán</span>
                  <b style={{ fontSize: 14 }}>{report.order_count} đơn</b>
                </div>
              </div>
              <div className="v6demo-glass v6demo-card-pad v6demo-rise-3">
                <h3 className="v6demo-card-title">Ghi chú</h3>
                {includeGoods && (
                  <p className="v6demo-baocao-note">
                    Chi phí tổng kỳ này: Vận hành {formatVND(report.expenses)} + Nhập hàng {formatVND(report.purchase_costs ?? 0)} + Nguyên liệu {formatVND(report.cost)} = {formatVND(applyGoodsCosts(report, true).expense)}
                  </p>
                )}
                <p className="v6demo-baocao-note">
                  Doanh thu gồm cả đơn ghi nợ nhưng KHÔNG gồm phí ship (phí ship chỉ thu hộ rồi trả cho đơn vị vận chuyển, không tính vào doanh thu hay lợi nhuận).
                </p>
                <p className="v6demo-baocao-note">
                  {includeGoods ? 'Lợi nhuận ròng = Doanh thu - Chi phí tổng (Vận hành + Nhập hàng + Nguyên liệu)' : 'Lợi nhuận ròng = Doanh thu - Giá vốn - Chi phí vận hành'}
                  {' '}(không gồm tiền nhập hàng, trả nợ NCC và chuyển quỹ nội bộ).
                </p>
              </div>
            </aside>
          )}
        </div>
      </div>
    </div>
  );
}

// ---------- Tab Báo cáo tồn kho (v5.14) ----------
// Phát triển từ KPI "Giá trị tồn kho hiện tại" đã bỏ khỏi trang Tổng quan:
// giá trị tồn hiện tại theo từng nguyên liệu/kho + biến động giá trị trong
// kỳ (đầu/nhập/xuất/cuối, cùng cơ sở giá vốn hiện tại như Sổ kho) + danh
// sách sắp hết (tôn trọng công tắc cảnh báo riêng từng nguyên liệu).

interface StockRow extends IngredientWithStock {
  warehouse_id: string;
  warehouse_name: string;
}

type StockLowRow = Awaited<ReturnType<typeof listLowStock>>[number];

function csvCellStock(v: unknown): string {
  const s = String(v ?? '');
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

function fmtQtyStock(v: number): string {
  const n = parseFloat(v.toFixed(3));
  return n.toLocaleString('vi-VN', { maximumFractionDigits: 3 });
}

function StockReportTab({
  warehouseIds,
  warehouseNameOf,
  range,
}: {
  warehouseIds: string[];
  warehouseNameOf: (id: string) => string;
  range: [string, string];
}) {
  const toast = useToast();
  const navigate = useNavigate();
  const [busy, setBusy] = useState(true);
  const [exportBusy, setExportBusy] = useState(false);
  const [rows, setRows] = useState<StockRow[]>([]);
  const [totals, setTotals] = useState<{ openingValue: number; importValue: number; exportValue: number; closingValue: number } | null>(null);
  const [low, setLow] = useState<StockLowRow[]>([]);
  const [query, setQuery] = useState('');

  const scopeKey = warehouseIds.join(',');
  const [rs, re] = range;

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setBusy(true);
      try {
        const ids = scopeKey ? scopeKey.split(',') : [];
        const perWh = await Promise.all(
          ids.map(async (id) => {
            // SUA 25/10/2026: tai toan bo log de So kho ky qua khu tinh dung.
            const [items, logs] = await Promise.all([listWarehouseStock(id), listAllStockLogs(id)]);
            return { id, items, logs };
          }),
        );
        if (cancelled) return;
        setRows(
          perWh.flatMap(({ id, items }) =>
            items
              .filter((i) => i.active)
              .map((i) => ({ ...i, warehouse_id: id, warehouse_name: warehouseNameOf(id) })),
          ),
        );
        const summaries = perWh.flatMap(({ items, logs }) =>
          summarizeLedger(
            items.map((i) => ({
              ingredient_id: i.id,
              ingredient_name: i.name,
              unit: i.unit,
              current_stock: i.stock,
              cost_per_unit: i.cost_per_unit,
            })),
            logs
              .filter((l) => {
                const k = vnDateKey(l.created_at);
                return k >= rs && k <= re;
              })
              .map((l) => ({
                ingredient_id: l.ingredient_id,
                ingredient_name: l.ingredient_name,
                change: l.change,
                balance_after: l.balance_after,
                created_at: l.created_at,
              })),
            logs
              .filter((l) => vnDateKey(l.created_at) > re)
              .map((l) => ({
                ingredient_id: l.ingredient_id,
                ingredient_name: l.ingredient_name,
                change: l.change,
                balance_after: l.balance_after,
                created_at: l.created_at,
              })),
          ),
        );
        setTotals(ledgerValueTotals(summaries));
        const lowRows = await listLowStock(ids);
        if (!cancelled) setLow(lowRows);
      } catch (err) {
        if (!cancelled) toast.show(err instanceof DbError ? err.message : 'Không tải được báo cáo tồn kho');
      } finally {
        if (!cancelled) setBusy(false);
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [scopeKey, rs, re]);

  const totalValue = useMemo(() => inventoryValueOf(rows), [rows]);
  const stockedCount = useMemo(() => rows.filter((r) => r.stock > 0).length, [rows]);
  const multiWh = warehouseIds.length > 1;

  const sortedRows = useMemo(() => {
    const q = query.trim().toLowerCase();
    return rows
      .filter((r) => r.stock !== 0)
      .filter((r) => !q || r.name.toLowerCase().includes(q))
      .sort((a, b) => Math.abs(b.stock * b.cost_per_unit) - Math.abs(a.stock * a.cost_per_unit));
  }, [rows, query]);

  const doExportStock = () => {
    setExportBusy(true);
    try {
      const all = rows
        .filter((r) => r.stock !== 0)
        .sort((a, b) => Math.abs(b.stock * b.cost_per_unit) - Math.abs(a.stock * a.cost_per_unit));
      const lines: string[] = [
        ['Nguyên liệu', 'Kho', 'ĐVT', 'Tồn', 'Giá vốn BQ (đ)', 'Giá trị (đ)'].map(csvCellStock).join(','),
        ...all.map((r) =>
          [r.name, r.warehouse_name, r.unit, r.stock, r.cost_per_unit, Math.round(r.stock * r.cost_per_unit)]
            .map(csvCellStock)
            .join(','),
        ),
        ['TỔNG GIÁ TRỊ TỒN', '', '', '', '', totalValue].map(csvCellStock).join(','),
        '',
        [`Biến động giá trị trong kỳ ${rs} - ${re} (theo giá vốn hiện tại, chỉ hàng có nhập/xuất)`].map(csvCellStock).join(','),
        ['Đầu kỳ', totals?.openingValue ?? 0].map(csvCellStock).join(','),
        ['Nhập trong kỳ', totals?.importValue ?? 0].map(csvCellStock).join(','),
        ['Xuất trong kỳ', totals?.exportValue ?? 0].map(csvCellStock).join(','),
        ['Cuối kỳ', totals?.closingValue ?? 0].map(csvCellStock).join(','),
      ];
      downloadFile(`beesy-TonKho_${rs}_${re}.csv`, '﻿' + lines.join('\r\n'), 'text/csv');
      toast.show('Đã xuất file Excel');
    } catch {
      toast.show('Xuất file thất bại');
    } finally {
      setExportBusy(false);
    }
  };

  const rangeLabel = rs === re ? rs : `${rs} → ${re}`;

  const stockKpis = [
    { label: 'Giá trị tồn hiện tại', value: formatVND(totalValue), icon: 'archive', tone: '' },
    { label: 'Mặt hàng có tồn', value: String(stockedCount), icon: 'package', tone: '' },
    { label: 'Cảnh báo sắp hết', value: String(low.length), icon: 'bell', tone: low.length > 0 ? 'red' : '' },
    { label: 'Kho đang xem', value: String(warehouseIds.length), icon: 'store', tone: '' },
  ];

  return (
    <div style={{ display: 'grid', gap: 18, alignContent: 'start' }}>
      <div>
        <div className="v6demo-baocao-export-row">
          <button className="v6demo-btn v6demo-btn-ghost v6demo-btn-sm" disabled={exportBusy || busy} onClick={doExportStock}>
            {exportBusy ? 'Đang xuất…' : <><LineIcon name="download" size={14} /> Xuất Tồn kho</>}
          </button>
        </div>
        <p className="v6demo-baocao-range-line">Kỳ: {rangeLabel}</p>
      </div>

      {busy ? (
        <div className="v6demo-glass v6demo-card-pad"><p className="v6demo-baocao-note" style={{ margin: 0 }}>Đang tải…</p></div>
      ) : (
        <>
          <div className="v6demo-baocao-kpi-grid">
            {stockKpis.map((k) => (
              <div key={k.label} className="v6demo-glass v6demo-glass-sm v6demo-baocao-kpi">
                <div className="v6demo-baocao-kpi-top">
                  <span
                    className="v6demo-baocao-kpi-ico"
                    style={k.tone === 'red'
                      ? { background: 'var(--vd-red-soft)', color: 'var(--vd-red)' }
                      : { background: 'var(--vd-green-soft)', color: 'var(--vd-green-700)' }}
                  >
                    <LineIcon name={k.icon} size={18} />
                  </span>
                  <span className="v6demo-baocao-kpi-label">{k.label}</span>
                </div>
                <div
                  className="v6demo-baocao-kpi-value"
                  style={k.tone === 'red' ? { color: 'var(--vd-red)' } : undefined}
                >
                  {k.value}
                </div>
              </div>
            ))}
          </div>

          <div className="v6demo-glass v6demo-card-pad">
            <h4 className="v6demo-baocao-h4">Biến động giá trị trong kỳ (theo giá vốn bình quân hiện tại)</h4>
            <div className="v6demo-baocao-mini-grid cols-4">
              <div className="v6demo-baocao-mini"><span className="v6demo-baocao-mini-label">Đầu kỳ</span><span className="v6demo-baocao-mini-value">{formatVND(totals?.openingValue ?? 0)}</span></div>
              <div className="v6demo-baocao-mini"><span className="v6demo-baocao-mini-label">Nhập trong kỳ</span><span className="v6demo-baocao-mini-value">{formatVND(totals?.importValue ?? 0)}</span></div>
              <div className="v6demo-baocao-mini"><span className="v6demo-baocao-mini-label">Xuất trong kỳ</span><span className="v6demo-baocao-mini-value">{formatVND(totals?.exportValue ?? 0)}</span></div>
              <div className="v6demo-baocao-mini"><span className="v6demo-baocao-mini-label">Cuối kỳ</span><span className="v6demo-baocao-mini-value">{formatVND(totals?.closingValue ?? 0)}</span></div>
            </div>
            <p className="v6demo-baocao-note" style={{ marginTop: 12 }}>
              Biến động chỉ tính các mặt hàng có nhập/xuất trong kỳ - cùng cách tính với Sổ kho ở trang Tồn kho.
            </p>
          </div>

          <div className="v6demo-glass v6demo-card-pad">
            <div className="v6demo-baocao-stock-head">
              <b>Giá trị theo nguyên liệu</b>
              <label className="v6demo-search">
                <LineIcon name="search" size={16} />
                <input
                  placeholder="Tìm nguyên liệu…"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                />
              </label>
            </div>
            <div className="v6demo-table-wrap">
              <table className="v6demo-tbl">
                <thead>
                  <tr>
                    <th>Nguyên liệu</th>
                    {multiWh && <th>Kho</th>}
                    <th className="r">Tồn</th>
                    <th className="r">Giá vốn BQ</th>
                    <th className="r">Giá trị</th>
                  </tr>
                </thead>
                <tbody>
                  {sortedRows.map((r) => (
                    <tr key={`${r.warehouse_id}-${r.id}`}>
                      <td><b>{r.name}</b> <span className="v6demo-small v6demo-muted">({r.unit})</span></td>
                      {multiWh && <td>{r.warehouse_name}</td>}
                      <td className="r" style={r.stock < 0 ? { color: 'var(--vd-red)', fontWeight: 600 } : undefined}>
                        {fmtQtyStock(r.stock)}
                      </td>
                      <td className="r">{formatVND(r.cost_per_unit)}</td>
                      <td className="r" style={{ fontWeight: 600 }}>{formatVND(Math.round(r.stock * r.cost_per_unit))}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr>
                    <td colSpan={multiWh ? 4 : 3} style={{ fontWeight: 700 }}>Tổng giá trị tồn</td>
                    <td className="r" style={{ fontWeight: 700 }}>{formatVND(totalValue)}</td>
                  </tr>
                </tfoot>
              </table>
            </div>
            {sortedRows.length === 0 && <p className="v6demo-baocao-empty">Không có nguyên liệu nào còn tồn.</p>}
          </div>

          {low.length > 0 && (
            <div className="v6demo-glass v6demo-card-pad">
              <div className="v6demo-baocao-low-head">
                <b><LineIcon name="bell" size={18} /> <span>Sắp hết / hết hàng ({low.length})</span></b>
                <button className="v6demo-btn v6demo-btn-ghost v6demo-btn-sm" onClick={() => navigate('/inventory')}>Mở trang Tồn kho</button>
              </div>
              {low.slice(0, 8).map((r) => (
                <div
                  key={`${r.warehouse_id}-${r.ingredient_id}`}
                  className="v6demo-rowline"
                >
                  <div style={{ minWidth: 0 }}>
                    <span className="v6demo-baocao-row-title">{r.name}{multiWh ? <span className="v6demo-small v6demo-muted"> · {r.warehouse_name}</span> : null}</span>
                  </div>
                  <span className="v6demo-baocao-row-amount" style={r.stock <= 0 ? { color: 'var(--vd-red)', fontWeight: 700 } : undefined}>
                    Còn {fmtQtyStock(r.stock)} / tối thiểu {fmtQtyStock(r.min_stock)} {r.unit}
                  </span>
                </div>
              ))}
              {low.length > 8 && <p className="v6demo-baocao-empty">... và {low.length - 8} mặt hàng nữa</p>}
            </div>
          )}
        </>
      )}
    </div>
  );
}
