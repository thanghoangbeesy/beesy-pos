// Nhập hàng & nhà cung cấp: phiếu nhập (cộng tồn + công nợ NCC + chi quỹ),
// quản lý NCC (trả nợ), cảnh báo nguyên liệu sắp hết.
import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  DbError,
  collectExportReceivable,
  createPurchaseOrder,
  createStockExport,
  deletePurchaseOrder,
  deleteStockExport,
  updatePurchaseOrder,
  updateStockExport,
  deleteSupplier,
  getAllowedWarehouses,
  getFunds,
  listIngredients,
  listLowStock,
  listPurchaseOrders,
  listStockExports,
  listSuppliers,
  paySupplierDebt,
  saveSupplier,
  getStockReasons,
  exportReasonBehavior,
  saveStockReasons,
  datePartOfDateTimeInput,
  isoToVNDateTimeInput,
  toLocalDateTimeInput,
} from '../lib/db';
import type { CreatePOItemInput, CreateStockExportItemInput } from '../lib/db';
import { formatVND, todayVN, unsignVietnamese } from '../lib/format';
import type { Customer, Fund, Ingredient, PurchaseOrder, StockExport, StockExportReason, Supplier, Warehouse,
  StockReason,
  StockReasonsSettings,
  StockExportBehavior,
} from '../lib/types';
import { CustomerPickSheet } from '../components/CustomerPickSheet';
import { Sheet } from '../components/Sheet';
import { StockDocPrint, type StockDocPrintData } from '../components/StockDocPrint';
import { AttachmentsInput, AttachmentsView } from '../components/Attachments';
import { useAuth } from '../lib/auth';
import { canUsePro } from '../lib/license';
import { useToast } from '../components/Toast';
import { LineIcon } from '../components/LineIcon';
import './pc-purchase.css';
import './v6demo-theme.css';
import './v6demo-purchase.css';

type Tab = 'po' | 'export' | 'supplier' | 'low' | 'reasons';

/** Hook phát hiện màn hình PC (>= 1024px), theo mẫu pages/Reports.tsx. */
function useIsPC(): boolean {
  const [isPC, setIsPC] = useState(() => typeof window !== 'undefined' && window.innerWidth >= 1024);
  useEffect(() => {
    const onResize = () => setIsPC(window.innerWidth >= 1024);
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);
  return isPC;
}

export function Purchase() {
  const isPC = useIsPC();
  const toast = useToast();
  const { can } = useAuth();
  const isOwner = can('cashbook.settings');
  const canCollectDebt = can('debt');
  const [searchParams, setSearchParams] = useSearchParams();
  const initialTab: Tab = ((): Tab => {
    const t = searchParams.get('tab');
    return t === 'export' || t === 'supplier' || t === 'low' || t === 'reasons' ? t : 'po';
  })();
  const [tab, setTab] = useState<Tab>(initialTab);
  const [busy, setBusy] = useState(true);
  const [pos, setPos] = useState<PurchaseOrder[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [low, setLow] = useState<Awaited<ReturnType<typeof listLowStock>>>([]);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [poForm, setPoForm] = useState<{ editing?: PurchaseOrder } | null>(null);
  const [poDetail, setPoDetail] = useState<PurchaseOrder | null>(null);
  const [poQuery, setPoQuery] = useState('');
  const [poWh, setPoWh] = useState('all');
  const [poFrom, setPoFrom] = useState('');
  const [poTo, setPoTo] = useState('');
  const [exQuery, setExQuery] = useState('');
  const [exWh, setExWh] = useState('all');
  const [exFrom, setExFrom] = useState('');
  const [exTo, setExTo] = useState('');
  const [exports, setExports] = useState<StockExport[]>([]);
  const [exportForm, setExportForm] = useState<{ editing?: StockExport } | null>(null);
  const [exportDetail, setExportDetail] = useState<StockExport | null>(null);
  const [proOk, setProOk] = useState<boolean | null>(null);
  const [supForm, setSupForm] = useState<Supplier | 'new' | null>(null);
  const [payForm, setPayForm] = useState<Supplier | null>(null);
  const [reasons, setReasons] = useState<StockReasonsSettings | null>(null);
  const [printDoc, setPrintDoc] = useState<StockDocPrintData | null>(null);

  const load = async () => {
    setBusy(true);
    try {
      const allowed = await getAllowedWarehouses().catch(() => ({ warehouses: [] as Warehouse[], isOwner: false }));
      setWarehouses(allowed.warehouses);
      const ids = allowed.isOwner ? undefined : allowed.warehouses.map((w) => w.id);
      const [p, ex, s, l, r] = await Promise.all([
        listPurchaseOrders(100),
        listStockExports(100),
        listSuppliers(),
        listLowStock(ids),
        getStockReasons(),
      ]);
      setReasons(r);
      setPos(p);
      setExports(ex);
      setSuppliers(s);
      setLow(l);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tải được dữ liệu');
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => {
    canUsePro().then((v) => {
      setProOk(v);
      if (v) void load();
    }).catch(() => setProOk(true));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Deep-link từ Sổ quỹ: /nhap-hang?open=<poId|exportId> → mở ngay chi tiết phiếu
  useEffect(() => {
    const openId = searchParams.get('open');
    if (!openId || busy || pos.length === 0) return;
    setSearchParams({}, { replace: true });
    const po = pos.find((p) => p.id === openId);
    if (po) {
      setTab('po');
      setPoDetail(po);
      return;
    }
    const ex = exports.find((e) => e.id === openId);
    if (ex) {
      setTab('export');
      setExportDetail(ex);
      return;
    }
    toast.show('Không tìm thấy phiếu');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [busy, pos, exports]);

  const delPO = async (po: PurchaseOrder) => {
    if (!window.confirm(`Xóa phiếu nhập ${po.code}? Tồn kho, khoản chi và công nợ liên quan sẽ được hoàn tác.`)) return;
    try {
      await deletePurchaseOrder(po.id);
      toast.show('Đã xóa phiếu nhập');
      void load();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Xóa phiếu thất bại');
    }
  };

  const delExport = async (ex: StockExport) => {
    if (!window.confirm(`Xóa phiếu xuất ${ex.code}? Tồn kho, khoản thu và công nợ liên quan sẽ được hoàn tác.`)) return;
    try {
      await deleteStockExport(ex.id);
      toast.show('Đã xóa phiếu xuất');
      void load();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Xóa phiếu thất bại');
    }
  };

  const matchDoc = (q: string, hay: string) => {
    const n = unsignVietnamese(q.trim()).toLowerCase();
    return !n || unsignVietnamese(hay).toLowerCase().includes(n);
  };
  const inRange = (d: string, from: string, to: string) => (!from || d >= from) && (!to || d <= to);
  const visiblePos = pos.filter((p) =>
    matchDoc(poQuery, `${p.code} ${p.supplier_name} ${p.items.map((i) => i.ingredient_name).join(' ')}`) &&
    (poWh === 'all' || p.warehouse_id === poWh) &&
    inRange(p.business_date, poFrom, poTo),
  );
  const visibleExports = exports.filter((x) =>
    matchDoc(exQuery, `${x.code} ${x.supplier_name ?? ''} ${x.items.map((i) => i.ingredient_name).join(' ')}`) &&
    (exWh === 'all' || x.warehouse_id === exWh) &&
    inRange(x.business_date, exFrom, exTo),
  );

  // ---- Nhánh PC (>= 1024px): chỉ khác JSX trình bày, dùng chung toàn bộ
  // state, loader, handler, validation, phân quyền và phạm vi kho ở trên.
  // Form tạo/sửa phiếu KHÔNG nhúng lại vào cột phải (xem ghi chú ở panel
  // phải): bấm Tạo phiếu vẫn mở đúng Sheet form sẵn có, trong đó bảng chọn
  // nguyên liệu vẫn là IngredientPickSheet sẵn có trong file này.
  if (isPC) {
    const fmtDate = (d: string) => {
      const parts = d.split('-');
      return parts.length === 3 ? `${parts[2]}/${parts[1]}/${parts[0]}` : d;
    };
    const ingSummary = (items: { ingredient_name: string; qty: number; unit: string }[]) => {
      const shown = items.slice(0, 2);
      const rest = items.length - shown.length;
      return (
        <>
          {shown.map((it, i) => (
            <span key={i} className="v6demo-purchase-ing-line" title={`${it.ingredient_name} ${it.qty} ${it.unit}`}>
              <b>{it.ingredient_name}</b> {it.qty} {it.unit}
            </span>
          ))}
          {rest > 0 && <span className="v6demo-purchase-ing-more">+ {rest} nguyên liệu nữa</span>}
        </>
      );
    };
    const poTotal = visiblePos.reduce((s, p) => s + p.subtotal, 0);
    const poDebt = visiblePos.reduce((s, p) => s + p.debt_amount, 0);
    const poLines = visiblePos.reduce((s, p) => s + p.items.length, 0);
    const exTotal = visibleExports.reduce((s, x) => s + x.subtotal, 0);
    const supplierDebtTotal = suppliers.reduce((s, x) => s + (x.debt || 0), 0);
    const supplierDebtCount = suppliers.filter((x) => x.debt > 0).length;
    const pcTabs: [Tab, string][] = [
      ['po', 'Phiếu nhập'],
      ['export', 'Phiếu xuất'],
      ['supplier', 'Nhà cung cấp'],
      ['low', `Cần nhập${low.length > 0 ? ` (${low.length})` : ''}`],
      ...(isOwner ? [['reasons', 'Lý do'] as [Tab, string]] : []),
    ];
    return (
      <div className="pc-purchase-page v6demo-purchase v6demo-page">
        <div className="v6demo-aurora" aria-hidden />
        <div className="v6demo-content">
        <div className="v6demo-page-head v6demo-rise">
          <h1>Nhập xuất hàng</h1>
          <p>Phiếu nhập cộng tồn kho và công nợ nhà cung cấp. Phiếu xuất trừ tồn kho theo lý do.</p>
        </div>

        {proOk === null || busy ? (
          <p className="muted v6demo-purchase-loading">Đang tải…</p>
        ) : !proOk ? (
          <div className="v6demo-glass v6demo-purchase-lock">
            <LineIcon name="lock" size={40} />
            <h3>Tính năng Pro</h3>
            <p className="muted">Nhập hàng &amp; nhà cung cấp thuộc gói Nâng cao (Pro).<br />Vào Cài đặt → Giấy phép để kích hoạt.</p>
          </div>
        ) : (
          <>
            <div className="v6demo-purchase-stats v6demo-rise-1">
              <div className="v6demo-glass v6demo-glass-sm v6demo-purchase-stat">
                <span className="v6demo-purchase-stat-icon"><LineIcon name="wallet" size={22} /></span>
                <span className="v6demo-purchase-stat-body">
                  <span className="v6demo-purchase-stat-label">Tổng tiền nhập (đang lọc)</span>
                  <span className="v6demo-purchase-stat-value">{formatVND(poTotal)}</span>
                  <span className="v6demo-purchase-stat-sub">{visiblePos.length} phiếu nhập · {poLines} dòng nguyên liệu</span>
                </span>
              </div>
              <div className="v6demo-glass v6demo-glass-sm v6demo-purchase-stat">
                <span className="v6demo-purchase-stat-icon"><LineIcon name="ledger" size={22} /></span>
                <span className="v6demo-purchase-stat-body">
                  <span className="v6demo-purchase-stat-label">Còn nợ nhà cung cấp</span>
                  <span className="v6demo-purchase-stat-value v6demo-negative">{formatVND(supplierDebtTotal)}</span>
                  <span className="v6demo-purchase-stat-sub">{supplierDebtCount} nhà cung cấp còn nợ · trong kỳ lọc còn nợ {formatVND(poDebt)}</span>
                </span>
              </div>
              <div className="v6demo-glass v6demo-glass-sm v6demo-purchase-stat">
                <span className="v6demo-purchase-stat-icon"><LineIcon name="archive" size={22} /></span>
                <span className="v6demo-purchase-stat-body">
                  <span className="v6demo-purchase-stat-label">Phiếu xuất (đang lọc)</span>
                  <span className="v6demo-purchase-stat-value">{visibleExports.length} phiếu</span>
                  <span className="v6demo-purchase-stat-sub">Tổng tiền xuất {formatVND(exTotal)}</span>
                </span>
              </div>
              <div className="v6demo-glass v6demo-glass-sm v6demo-purchase-stat">
                <span className="v6demo-purchase-stat-icon"><LineIcon name="package" size={22} /></span>
                <span className="v6demo-purchase-stat-body">
                  <span className="v6demo-purchase-stat-label">Cần nhập thêm</span>
                  <span className="v6demo-purchase-stat-value">{low.length} nguyên liệu</span>
                  <span className="v6demo-purchase-stat-sub" title={low.map((l) => `${l.name} (${l.warehouse_name})`).join(', ') || 'Tồn kho đang đủ'}>
                    {low.length > 0 ? 'Tồn kho dưới ngưỡng tối thiểu' : 'Tồn kho đang đủ, chưa cần nhập gì'}
                  </span>
                </span>
              </div>
            </div>

            <div className="v6demo-seg v6demo-purchase-tabs v6demo-rise-2" role="tablist">
              {pcTabs.map(([k, label]) => (
                <button key={k} type="button" className={tab === k ? 'active' : ''} onClick={() => setTab(k)}>
                  {label}
                </button>
              ))}
            </div>

            {(tab === 'po' || tab === 'export') && (
              <div className="v6demo-glass v6demo-purchase-dock">
                <label className="v6demo-search">
                  <LineIcon name="search" size={18} />
                  <input
                    value={tab === 'po' ? poQuery : exQuery}
                    onChange={(e) => (tab === 'po' ? setPoQuery(e.target.value) : setExQuery(e.target.value))}
                    placeholder="Tìm theo tên nguyên liệu, nhà cung cấp, mã phiếu…"
                    aria-label={tab === 'po' ? 'Tìm phiếu nhập' : 'Tìm phiếu xuất'}
                  />
                </label>
                <select
                  className="v6demo-input v6demo-purchase-wh"
                  value={tab === 'po' ? poWh : exWh}
                  onChange={(e) => (tab === 'po' ? setPoWh(e.target.value) : setExWh(e.target.value))}
                  aria-label={tab === 'po' ? 'Lọc phiếu nhập theo kho' : 'Lọc phiếu xuất theo kho'}
                >
                  <option value="all">Tất cả kho</option>
                  {warehouses.map((w) => (
                    <option key={w.id} value={w.id}>{w.name}</option>
                  ))}
                </select>
                <span className="v6demo-purchase-date-label">Từ</span>
                <input className="v6demo-input v6demo-purchase-date" type="date" value={tab === 'po' ? poFrom : exFrom} onChange={(e) => (tab === 'po' ? setPoFrom(e.target.value) : setExFrom(e.target.value))} aria-label="Từ ngày" />
                <span className="v6demo-purchase-date-label">Đến</span>
                <input className="v6demo-input v6demo-purchase-date" type="date" value={tab === 'po' ? poTo : exTo} onChange={(e) => (tab === 'po' ? setPoTo(e.target.value) : setExTo(e.target.value))} aria-label="Đến ngày" />
                <span className="v6demo-purchase-dock-break" />
                <button type="button" className="v6demo-btn v6demo-btn-primary" onClick={() => setPoForm({})}>
                  <LineIcon name="plus" size={18} /> Tạo phiếu nhập
                </button>
                <button type="button" className="v6demo-btn v6demo-btn-ghost" onClick={() => setExportForm({})}>
                  <LineIcon name="plus" size={18} /> Tạo phiếu xuất
                </button>
              </div>
            )}

            <div className="v6demo-purchase-layout">
              <section className="v6demo-glass v6demo-purchase-table-card">
                {tab === 'po' ? (
                  pos.length === 0 ? (
                    <p className="muted v6demo-purchase-empty">Chưa có phiếu nhập nào.</p>
                  ) : visiblePos.length === 0 ? (
                    <p className="muted v6demo-purchase-empty">Không tìm thấy phiếu phù hợp.</p>
                  ) : (
                    <>
                      <div className="v6demo-table-wrap">
                        <table className="v6demo-tbl">
                          <thead>
                            <tr>
                              <th>Mã phiếu</th>
                              <th>Ngày</th>
                              <th>Kho</th>
                              <th>Nhà cung cấp</th>
                              <th>Nguyên liệu</th>
                              <th className="r">Tổng tiền</th>
                              <th>Thanh toán</th>
                              <th>Thao tác</th>
                            </tr>
                          </thead>
                          <tbody>
                            {visiblePos.map((p) => (
                              <tr key={p.id}>
                                <td><b title={p.code}>{p.code}</b></td>
                                <td className="r">{fmtDate(p.business_date)}</td>
                                <td><span className="v6demo-purchase-cell" title={p.warehouse_name}>{p.warehouse_name}</span></td>
                                <td>
                                  <span className="v6demo-purchase-cell" title={p.supplier_name}>{p.supplier_name}</span>
                                  {p.reason_id && reasons?.import_reasons.find((r) => r.id === p.reason_id) && (
                                    <span className="v6demo-purchase-sub" title={reasons.import_reasons.find((r) => r.id === p.reason_id)?.label}>
                                      {reasons.import_reasons.find((r) => r.id === p.reason_id)?.label}
                                    </span>
                                  )}
                                </td>
                                <td>
                                  <span className="v6demo-purchase-ing">{ingSummary(p.items)}</span>
                                  {p.attachments && p.attachments.length > 0 && (
                                    <span className="v6demo-purchase-sub">Kèm ảnh chứng từ ({p.attachments.length})</span>
                                  )}
                                </td>
                                <td className="r"><b>{formatVND(p.subtotal)}</b></td>
                                <td>
                                  {p.debt_amount > 0 ? (
                                    <>
                                      <span className="v6demo-badge warn">Còn nợ</span>
                                      <span className="v6demo-purchase-sub v6demo-negative">Còn nợ {formatVND(p.debt_amount)}</span>
                                    </>
                                  ) : (
                                    <span className="v6demo-badge">Đã trả đủ</span>
                                  )}
                                  {p.paid_amount > 0 && <span className="v6demo-purchase-sub">Đã trả {formatVND(p.paid_amount)}</span>}
                                </td>
                                <td>
                                  <span className="v6demo-purchase-actions">
                                    <button type="button" className="v6demo-btn v6demo-btn-ghost v6demo-btn-sm" onClick={() => setPoDetail(p)}>
                                      <LineIcon name="eye" size={16} /> Xem
                                    </button>
                                    {isOwner && (
                                      <>
                                        <button type="button" className="v6demo-btn v6demo-btn-ghost v6demo-btn-sm" onClick={() => setPoForm({ editing: p })}>
                                          <LineIcon name="edit" size={16} /> Sửa
                                        </button>
                                        <button type="button" className="v6demo-btn v6demo-btn-danger v6demo-btn-sm" aria-label={`Xóa ${p.code}`} onClick={() => void delPO(p)}>
                                          <LineIcon name="trash" size={16} /> Xóa
                                        </button>
                                      </>
                                    )}
                                  </span>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                      <p className="v6demo-purchase-pager">Đang xem {visiblePos.length} / {pos.length} phiếu nhập</p>
                    </>
                  )
                ) : tab === 'export' ? (
                  exports.length === 0 ? (
                    <p className="muted v6demo-purchase-empty">Chưa có phiếu xuất nào.</p>
                  ) : visibleExports.length === 0 ? (
                    <p className="muted v6demo-purchase-empty">Không tìm thấy phiếu phù hợp.</p>
                  ) : (
                    <>
                      <div className="v6demo-table-wrap">
                        <table className="v6demo-tbl">
                          <thead>
                            <tr>
                              <th>Mã phiếu</th>
                              <th>Ngày</th>
                              <th>Kho</th>
                              <th>Lý do</th>
                              <th>Nguyên liệu</th>
                              <th className="r">Tổng tiền</th>
                              <th>Thu / Phải thu</th>
                              <th>Thao tác</th>
                            </tr>
                          </thead>
                          <tbody>
                            {visibleExports.map((x) => (
                              <tr key={x.id}>
                                <td><b title={x.code}>{x.code}</b></td>
                                <td className="r">{fmtDate(x.business_date)}</td>
                                <td><span className="v6demo-purchase-cell" title={x.warehouse_name}>{x.warehouse_name}</span></td>
                                <td>
                                  <span className="v6demo-purchase-cell" title={reasons?.export_reasons.find((r) => r.id === x.reason)?.label ?? 'Xuất kho'}>
                                    {reasons?.export_reasons.find((r) => r.id === x.reason)?.label ?? 'Xuất kho'}
                                  </span>
                                  {x.supplier_name && <span className="v6demo-purchase-sub" title={x.supplier_name}>{x.supplier_name}</span>}
                                  {x.customer_name && <span className="v6demo-purchase-sub" title={x.customer_name}>{x.customer_name}</span>}
                                </td>
                                <td>
                                  <span className="v6demo-purchase-ing">{ingSummary(x.items)}</span>
                                  {x.attachments && x.attachments.length > 0 && (
                                    <span className="v6demo-purchase-sub">Kèm ảnh chứng từ ({x.attachments.length})</span>
                                  )}
                                </td>
                                <td className="r"><b>{formatVND(x.subtotal)}</b></td>
                                <td>
                                  {x.received_amount > 0 && <span className="v6demo-purchase-sub">Đã thu {formatVND(x.received_amount)}</span>}
                                  {x.receivable_amount > 0 ? (
                                    <span className="v6demo-purchase-sub v6demo-negative">Còn phải thu {formatVND(x.receivable_amount)}</span>
                                  ) : (
                                    <span className="v6demo-purchase-sub">Không còn phải thu</span>
                                  )}
                                </td>
                                <td>
                                  <span className="v6demo-purchase-actions">
                                    <button type="button" className="v6demo-btn v6demo-btn-ghost v6demo-btn-sm" onClick={() => setExportDetail(x)}>
                                      <LineIcon name="eye" size={16} /> Xem
                                    </button>
                                    {isOwner && (
                                      <>
                                        <button type="button" className="v6demo-btn v6demo-btn-ghost v6demo-btn-sm" onClick={() => setExportForm({ editing: x })}>
                                          <LineIcon name="edit" size={16} /> Sửa
                                        </button>
                                        <button type="button" className="v6demo-btn v6demo-btn-danger v6demo-btn-sm" aria-label={`Xóa ${x.code}`} onClick={() => void delExport(x)}>
                                          <LineIcon name="trash" size={16} /> Xóa
                                        </button>
                                      </>
                                    )}
                                  </span>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                      <p className="v6demo-purchase-pager">Đang xem {visibleExports.length} / {exports.length} phiếu xuất</p>
                    </>
                  )
                ) : tab === 'supplier' ? (
                  suppliers.length === 0 ? (
                    <p className="muted v6demo-purchase-empty">Chưa có nhà cung cấp nào.</p>
                  ) : (
                    <div className="v6demo-table-wrap">
                      <table className="v6demo-tbl">
                        <thead>
                          <tr>
                            <th>Nhà cung cấp</th>
                            <th>Số điện thoại</th>
                            <th>Địa chỉ</th>
                            <th className="r">Còn nợ</th>
                            <th>Thao tác</th>
                          </tr>
                        </thead>
                        <tbody>
                          {suppliers.map((s) => (
                            <tr key={s.id} style={s.active ? undefined : { opacity: 0.6 }}>
                              <td><b title={s.name}>{s.name}</b>{!s.active && <span className="v6demo-purchase-sub">Đã ẩn</span>}</td>
                              <td><span className="v6demo-purchase-cell" title={s.phone}>{s.phone || '—'}</span></td>
                              <td><span className="v6demo-purchase-cell" title={s.address ?? ''}>{s.address || '—'}</span></td>
                              <td className="r">
                                {s.debt > 0 ? <b className="v6demo-negative">{formatVND(s.debt)}</b> : <span>0đ</span>}
                              </td>
                              <td>
                                <span className="v6demo-purchase-actions">
                                  {s.debt > 0 && (
                                    <button type="button" className="v6demo-btn v6demo-btn-ghost v6demo-btn-sm" onClick={() => setPayForm(s)}>
                                      <LineIcon name="wallet" size={16} /> Trả nợ
                                    </button>
                                  )}
                                  <button type="button" className="v6demo-btn v6demo-btn-ghost v6demo-btn-sm" onClick={() => setSupForm(s)}>
                                    <LineIcon name="edit" size={16} /> Sửa
                                  </button>
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )
                ) : tab === 'low' ? (
                  low.length === 0 ? (
                    <p className="muted v6demo-purchase-empty">Tồn kho đang đủ, chưa cần nhập gì.</p>
                  ) : (
                    <div className="v6demo-table-wrap">
                      <table className="v6demo-tbl">
                        <thead>
                          <tr>
                            <th>Nguyên liệu</th>
                            <th>Kho</th>
                            <th className="r">Tồn hiện tại</th>
                            <th className="r">Ngưỡng tối thiểu</th>
                          </tr>
                        </thead>
                        <tbody>
                          {low.map((l, i) => (
                            <tr key={`${l.warehouse_id}_${l.ingredient_id}_${i}`}>
                              <td><b title={l.name}>{l.name}</b></td>
                              <td><span className="v6demo-purchase-cell" title={l.warehouse_name}>{l.warehouse_name}</span></td>
                              <td className="r"><b className="v6demo-negative">{l.stock} {l.unit}</b></td>
                              <td className="r">{l.min_stock} {l.unit}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )
                ) : tab === 'reasons' ? (
                  isOwner ? (
                    <ReasonsTab reasons={reasons} onSaved={async () => { const r = await getStockReasons(); setReasons(r); }} />
                  ) : (
                    <p className="muted v6demo-purchase-empty">Chỉ chủ quán quản lý lý do.</p>
                  )
                ) : null}
              </section>

              <aside className="v6demo-glass v6demo-purchase-side">
                {tab === 'supplier' ? (
                  <>
                    <h3 className="v6demo-purchase-side-title"><LineIcon name="truck" size={20} /> Nhà cung cấp</h3>
                    <p className="v6demo-purchase-note">
                      Nợ nhà cung cấp phát sinh khi phiếu nhập trả chưa đủ. Bấm Trả nợ ở bảng để trả từ quỹ,
                      hoặc bấm Sửa để đổi tên, số điện thoại, địa chỉ.
                    </p>
                    <button type="button" className="v6demo-btn v6demo-btn-primary v6demo-btn-block" onClick={() => setSupForm('new')}>
                      <LineIcon name="plus" size={18} /> Thêm nhà cung cấp
                    </button>
                    <button type="button" className="v6demo-btn v6demo-btn-ghost v6demo-btn-block" onClick={() => setTab('po')}>
                      Sang phiếu nhập
                    </button>
                  </>
                ) : tab === 'low' ? (
                  <>
                    <h3 className="v6demo-purchase-side-title"><LineIcon name="alert" size={20} /> Cần nhập thêm</h3>
                    <p className="v6demo-purchase-note">
                      Danh sách này chỉ gồm nguyên liệu đang dưới ngưỡng tối thiểu, trong phạm vi kho bạn được dùng.
                      Tạo phiếu nhập rồi chọn đúng nguyên liệu trong bảng chọn có tìm kiếm.
                    </p>
                    <button type="button" className="v6demo-btn v6demo-btn-primary v6demo-btn-block" onClick={() => setPoForm({})}>
                      <LineIcon name="plus" size={18} /> Tạo phiếu nhập
                    </button>
                  </>
                ) : tab === 'reasons' ? (
                  <>
                    <h3 className="v6demo-purchase-side-title"><LineIcon name="clipboard" size={20} /> Lý do nhập / xuất</h3>
                    <p className="v6demo-purchase-note">
                      Chỉ chủ quán quản lý lý do. Lý do xuất còn kèm hành vi: bán thì thu tiền vào quỹ,
                      trả nhà cung cấp thì trừ công nợ, còn lại chỉ trừ tồn kho.
                    </p>
                  </>
                ) : (
                  <>
                    <h3 className="v6demo-purchase-side-title">
                      <LineIcon name={tab === 'export' ? 'archive' : 'package'} size={20} />
                      {tab === 'export' ? 'Tạo phiếu xuất' : 'Tạo phiếu nhập'}
                    </h3>
                    <p className="v6demo-purchase-note">
                      Bấm nút dưới để mở đúng form sẵn có (không làm lại form ở cột này, để khỏi nhân đôi logic).
                      Trong form, bấm ô nguyên liệu để mở bảng chọn có tìm kiếm theo tên, giá vốn tự điền theo
                      nguyên liệu đã chọn.
                    </p>
                    <ul className="v6demo-purchase-side-list">
                      <li>Chọn kho đúng trước khi lưu, vì phiếu cộng/trừ tồn kho theo kho đó.</li>
                      <li>Phiếu nhập trả chưa đủ thì chọn nhà cung cấp để phần thiếu ghi vào công nợ.</li>
                      <li>Trả hoặc thu ngay thì chọn quỹ; đính kèm được ảnh chứng từ.</li>
                      <li>Phiếu xuất bán thu thiếu thì phần thiếu ghi phải thu, thu sau ở chi tiết phiếu.</li>
                    </ul>
                    <button type="button" className="v6demo-btn v6demo-btn-primary v6demo-btn-block" onClick={() => setPoForm({})}>
                      <LineIcon name="plus" size={18} /> Tạo phiếu nhập
                    </button>
                    <button type="button" className="v6demo-btn v6demo-btn-ghost v6demo-btn-block" onClick={() => setExportForm({})}>
                      <LineIcon name="plus" size={18} /> Tạo phiếu xuất
                    </button>
                  </>
                )}
              </aside>
            </div>
          </>
        )}

        {poForm && (
          <PurchaseOrderForm
            warehouses={warehouses}
            reasons={reasons}
            editing={poForm.editing}
            onClose={() => setPoForm(null)}
            onSaved={() => {
              setPoForm(null);
              void load();
            }}
          />
        )}
        {exportForm && (
          <StockExportForm
            warehouses={warehouses}
            reasons={reasons}
            editing={exportForm.editing}
            onClose={() => setExportForm(null)}
            onSaved={() => {
              setExportForm(null);
              void load();
            }}
          />
        )}
        {poDetail && (
          <PurchaseOrderDetail
            po={poDetail}
            reasons={reasons}
            isOwner={isOwner}
            onClose={() => setPoDetail(null)}
            onEdit={() => {
              setPoDetail(null);
              setPoForm({ editing: poDetail });
            }}
            onPrint={(label) => setPrintDoc({ kind: 'in', doc: poDetail, reasonLabel: label })}
          />
        )}
        {exportDetail && (
          <StockExportDetail
            ex={exportDetail}
            reasons={reasons}
            isOwner={isOwner}
            canCollect={canCollectDebt}
            onClose={() => setExportDetail(null)}
            onEdit={() => {
              setExportDetail(null);
              setExportForm({ editing: exportDetail });
            }}
            onPrint={(label) => setPrintDoc({ kind: 'out', doc: exportDetail, reasonLabel: label })}
            onCollected={(updated) => {
              setExportDetail(updated);
              void load();
            }}
          />
        )}
        {printDoc && <StockDocPrint data={printDoc} onDone={() => setPrintDoc(null)} />}
        {supForm && (
          <SupplierForm
            initial={supForm === 'new' ? null : supForm}
            onClose={() => setSupForm(null)}
            onSaved={() => {
              setSupForm(null);
              void load();
            }}
          />
        )}
        {payForm && (
          <PaySupplierSheet
            supplier={payForm}
            warehouses={warehouses}
            onClose={() => setPayForm(null)}
            onSaved={() => {
              setPayForm(null);
              void load();
            }}
          />
        )}
        </div>
      </div>
    );
  }

  // 4 so lieu tong dung chung cho ca mobile (tinh giong nhanh PC).
  const mPoTotal = visiblePos.reduce((s, p) => s + p.subtotal, 0);
  const mPoDebt = visiblePos.reduce((s, p) => s + p.debt_amount, 0);
  const mExTotal = visibleExports.reduce((s, x) => s + x.subtotal, 0);
  const mSupDebtTotal = suppliers.reduce((s, x) => s + (x.debt || 0), 0);
  const mSupDebtCount = suppliers.filter((x) => x.debt > 0).length;

  return (
    <div className="page v6demo-purchase v6demo-page">
      <div className="v6demo-aurora" aria-hidden />
      <div className="v6demo-content">
      <div className="v6demo-page-head v6demo-rise">
        <h1>Nhập Xuất Hàng</h1>
        <p>Phiếu nhập cộng tồn kho và công nợ nhà cung cấp. Phiếu xuất trừ tồn kho theo lý do.</p>
      </div>
      <div className="v6demo-purchase-stats v6demo-rise-1">
        <div className="v6demo-glass v6demo-glass-sm v6demo-purchase-stat">
          <span className="v6demo-purchase-stat-icon"><LineIcon name="wallet" size={20} /></span>
          <span className="v6demo-purchase-stat-body">
            <span className="v6demo-purchase-stat-label">Tiền nhập (đang lọc)</span>
            <span className="v6demo-purchase-stat-value">{formatVND(mPoTotal)}</span>
            <span className="v6demo-purchase-stat-sub">{visiblePos.length} phiếu · nợ {formatVND(mPoDebt)}</span>
          </span>
        </div>
        <div className="v6demo-glass v6demo-glass-sm v6demo-purchase-stat">
          <span className="v6demo-purchase-stat-icon"><LineIcon name="ledger" size={20} /></span>
          <span className="v6demo-purchase-stat-body">
            <span className="v6demo-purchase-stat-label">Còn nợ nhà cung cấp</span>
            <span className="v6demo-purchase-stat-value v6demo-negative">{formatVND(mSupDebtTotal)}</span>
            <span className="v6demo-purchase-stat-sub">{mSupDebtCount} nhà cung cấp còn nợ</span>
          </span>
        </div>
        <div className="v6demo-glass v6demo-glass-sm v6demo-purchase-stat">
          <span className="v6demo-purchase-stat-icon"><LineIcon name="archive" size={20} /></span>
          <span className="v6demo-purchase-stat-body">
            <span className="v6demo-purchase-stat-label">Phiếu xuất (đang lọc)</span>
            <span className="v6demo-purchase-stat-value">{visibleExports.length} phiếu</span>
            <span className="v6demo-purchase-stat-sub">Tổng tiền xuất {formatVND(mExTotal)}</span>
          </span>
        </div>
        <div className="v6demo-glass v6demo-glass-sm v6demo-purchase-stat">
          <span className="v6demo-purchase-stat-icon"><LineIcon name="package" size={20} /></span>
          <span className="v6demo-purchase-stat-body">
            <span className="v6demo-purchase-stat-label">Cần nhập thêm</span>
            <span className="v6demo-purchase-stat-value">{low.length} nguyên liệu</span>
            <span className="v6demo-purchase-stat-sub">{low.length > 0 ? 'Tồn kho dưới ngưỡng tối thiểu' : 'Tồn kho đang đủ'}</span>
          </span>
        </div>
      </div>
      <div className="v6demo-seg v6demo-purchase-tabs v6demo-rise-1" role="tablist">
        {(
          [
            ['po', 'Phiếu nhập'],
            ['export', 'Phiếu xuất'],
            ['supplier', 'Nhà cung cấp'],
            ['low', `Cần nhập${low.length > 0 ? ` (${low.length})` : ''}`],
            ...(isOwner ? [['reasons', 'Lý do'] as [Tab, string]] : []),
          ] as [Tab, string][]
        ).map(([k, label]) => (
          <button key={k} type="button" className={tab === k ? 'active' : ''} onClick={() => setTab(k)}>
            {label}
          </button>
        ))}
      </div>

      {proOk === null || busy ? (
        <p className="v6demo-purchase-loading">Đang tải…</p>
      ) : !proOk ? (
        <div className="v6demo-glass v6demo-purchase-lock">
          <LineIcon name="lock" size={40} />
          <h3>Tính năng Pro</h3>
          <p className="muted">Nhập hàng & nhà cung cấp thuộc gói Nâng cao (Pro).<br />Vào Cài đặt → Giấy phép để kích hoạt.</p>
        </div>
      ) : tab === 'po' ? (
        <>
          <button className="v6demo-btn v6demo-btn-primary v6demo-btn-block v6demo-purchase-create" onClick={() => setPoForm({})}>
            <LineIcon name="plus" size={18} /> Tạo phiếu nhập
          </button>
          <div className="v6demo-search v6demo-purchase-search">
            <LineIcon name="search" size={18} />
            <input value={poQuery} onChange={(e) => setPoQuery(e.target.value)} placeholder="Tìm theo tên nguyên liệu, nhà cung cấp, mã phiếu…" aria-label="Tìm phiếu nhập" />
          </div>
          <div className="v6demo-purchase-filters">
            <select className="v6demo-input" value={poWh} onChange={(e) => setPoWh(e.target.value)} aria-label="Lọc phiếu nhập theo kho">
              <option value="all">Tất cả kho</option>
              {warehouses.map((w) => (
                <option key={w.id} value={w.id}>{w.name}</option>
              ))}
            </select>
            <input className="v6demo-input" type="date" value={poFrom} onChange={(e) => setPoFrom(e.target.value)} aria-label="Phiếu nhập từ ngày" />
            <input className="v6demo-input" type="date" value={poTo} onChange={(e) => setPoTo(e.target.value)} aria-label="Phiếu nhập đến ngày" />
          </div>
          {pos.length === 0 ? (
            <div className="v6demo-purchase-empty">
              <LineIcon name="package" size={32} />
              <p>Chưa có phiếu nhập nào.</p>
            </div>
          ) : visiblePos.length === 0 ? (
            <div className="v6demo-purchase-empty">
              <LineIcon name="search" size={32} />
              <p>Không tìm thấy phiếu phù hợp.</p>
            </div>
          ) : (
            <div className="v6demo-glass v6demo-purchase-list">
              {visiblePos.map((p) => (
                <div key={p.id} className="v6demo-purchase-row" onClick={() => setPoDetail(p)}>
                  <span className="v6demo-purchase-rbody">
                    <span className="v6demo-purchase-rtitle">
                      {p.code} <span className="v6demo-purchase-rsub">· {p.supplier_name}</span>
                    </span>
                    <span className="v6demo-purchase-rsub">
                      {p.items.length} nguyên liệu · {p.warehouse_name} · {p.business_date}
                      {p.reason_id && reasons?.import_reasons.find((r) => r.id === p.reason_id) && (
                        <> · {reasons.import_reasons.find((r) => r.id === p.reason_id)?.label}</>
                      )}
                      {p.debt_amount > 0 && <span className="v6demo-negative"> · Nợ NCC {formatVND(p.debt_amount)}</span>}
                    </span>
                    <AttachmentsView value={p.attachments} />
                  </span>
                  <span className="v6demo-purchase-rbody v6demo-purchase-rbody-right">
                    <span className="v6demo-purchase-ramount">{formatVND(p.subtotal)}</span>
                    {p.paid_amount > 0 && <span className="v6demo-purchase-rsub">Đã trả {formatVND(p.paid_amount)}</span>}
                  </span>
                  {isOwner && (
                    <button type="button" className="v6demo-purchase-row-del" aria-label={`Xóa ${p.code}`} onClick={(e) => { e.stopPropagation(); void delPO(p); }}>
                      <LineIcon name="trash" size={16} />
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </>
      ) : tab === 'export' ? (
        <>
          <button className="v6demo-btn v6demo-btn-primary v6demo-btn-block v6demo-purchase-create" onClick={() => setExportForm({})}>
            <LineIcon name="plus" size={18} /> Tạo phiếu xuất
          </button>
          <div className="v6demo-search v6demo-purchase-search">
            <LineIcon name="search" size={18} />
            <input value={exQuery} onChange={(e) => setExQuery(e.target.value)} placeholder="Tìm theo tên nguyên liệu, nhà cung cấp, mã phiếu…" aria-label="Tìm phiếu xuất" />
          </div>
          <div className="v6demo-purchase-filters">
            <select className="v6demo-input" value={exWh} onChange={(e) => setExWh(e.target.value)} aria-label="Lọc phiếu xuất theo kho">
              <option value="all">Tất cả kho</option>
              {warehouses.map((w) => (
                <option key={w.id} value={w.id}>{w.name}</option>
              ))}
            </select>
            <input className="v6demo-input" type="date" value={exFrom} onChange={(e) => setExFrom(e.target.value)} aria-label="Phiếu xuất từ ngày" />
            <input className="v6demo-input" type="date" value={exTo} onChange={(e) => setExTo(e.target.value)} aria-label="Phiếu xuất đến ngày" />
          </div>
          {exports.length === 0 ? (
            <div className="v6demo-purchase-empty">
              <LineIcon name="archive" size={32} />
              <p>Chưa có phiếu xuất nào.</p>
            </div>
          ) : visibleExports.length === 0 ? (
            <div className="v6demo-purchase-empty">
              <LineIcon name="search" size={32} />
              <p>Không tìm thấy phiếu phù hợp.</p>
            </div>
          ) : (
            <div className="v6demo-glass v6demo-purchase-list">
              {visibleExports.map((x) => (
                <div key={x.id} className="v6demo-purchase-row" onClick={() => setExportDetail(x)}>
                  <span className="v6demo-purchase-rbody">
                    <span className="v6demo-purchase-rtitle">
                      {x.code}{' '}
                      <span className="v6demo-purchase-rsub">
                        · {reasons?.export_reasons.find((r) => r.id === x.reason)?.label ?? 'Xuất kho'}
                      </span>
                    </span>
                    <span className="v6demo-purchase-rsub">
                      {x.items.length} nguyên liệu · {x.warehouse_name} · {x.business_date}
                      {x.supplier_name && <> · {x.supplier_name}</>}
                    </span>
                    <AttachmentsView value={x.attachments} />
                  </span>
                  <span className="v6demo-purchase-rbody v6demo-purchase-rbody-right">
                    <span className="v6demo-purchase-ramount">{formatVND(x.subtotal)}</span>
                    {x.received_amount > 0 && <span className="v6demo-purchase-rsub">Đã thu {formatVND(x.received_amount)}</span>}
                    {x.receivable_amount > 0 && <span className="v6demo-purchase-rsub">Còn phải thu {formatVND(x.receivable_amount)}</span>}
                  </span>
                  {isOwner && (
                    <button type="button" className="v6demo-purchase-row-del" aria-label={`Xóa ${x.code}`} onClick={(e) => { e.stopPropagation(); void delExport(x); }}>
                      <LineIcon name="trash" size={16} />
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </>
      ) : tab === 'supplier' ? (
        <>
          <button className="v6demo-btn v6demo-btn-primary v6demo-btn-block v6demo-purchase-create" onClick={() => setSupForm('new')}>
            <LineIcon name="plus" size={18} /> Thêm nhà cung cấp
          </button>
          {suppliers.length === 0 ? (
            <div className="v6demo-purchase-empty">
              <LineIcon name="truck" size={32} />
              <p>Chưa có nhà cung cấp nào.</p>
            </div>
          ) : (
            <div className="v6demo-glass v6demo-purchase-list">
              {suppliers.map((s) => (
                <div key={s.id} className="v6demo-purchase-row v6demo-purchase-row-static" style={{ opacity: s.active ? 1 : 0.6 }}>
                  <span className="v6demo-purchase-rbody">
                    <span className="v6demo-purchase-rtitle">
                      {s.name}
                    </span>
                    <span className="v6demo-purchase-rsub">
                      {s.phone}
                      {s.debt > 0 && <span className="v6demo-negative"> · Nợ {formatVND(s.debt)}</span>}
                    </span>
                  </span>
                  <span className="row" style={{ gap: 6, flex: '0 0 auto' }}>
                    {s.debt > 0 && (
                      <button type="button" className="v6demo-btn v6demo-btn-ghost v6demo-btn-sm" onClick={() => setPayForm(s)}>
                        <LineIcon name="wallet" size={14} /> Trả nợ
                      </button>
                    )}
                    <button type="button" className="v6demo-btn v6demo-btn-ghost v6demo-btn-sm" onClick={() => setSupForm(s)}>
                      <LineIcon name="edit" size={14} /> Sửa
                    </button>
                  </span>
                </div>
              ))}
            </div>
          )}
        </>
      ) : tab === 'low' ? (
        low.length === 0 ? (
          <div className="v6demo-purchase-empty">
            <LineIcon name="check" size={32} />
            <p>Tồn kho đang đủ, chưa cần nhập gì.</p>
          </div>
        ) : (
          <div className="v6demo-glass v6demo-purchase-list">
            {low.map((l, i) => (
              <div key={`${l.warehouse_id}_${l.ingredient_id}_${i}`} className="v6demo-purchase-row v6demo-purchase-row-static">
                <span className="v6demo-purchase-rbody">
                  <span className="v6demo-purchase-rtitle">
                    {l.name}
                  </span>
                  <span className="v6demo-purchase-rsub">{l.warehouse_name}</span>
                </span>
                <span className="v6demo-purchase-rbody v6demo-purchase-rbody-right">
                  <span className="v6demo-purchase-ramount v6demo-negative">
                    {l.stock} {l.unit}
                  </span>
                  <span className="v6demo-purchase-rsub">Ngưỡng {l.min_stock}</span>
                </span>
              </div>
            ))}
          </div>
        )
      ) : tab === 'reasons' ? (
        isOwner ? (
          <ReasonsTab reasons={reasons} onSaved={async () => { const r = await getStockReasons(); setReasons(r); }} />
        ) : (
          <div className="v6demo-purchase-empty"><p>Chỉ chủ quán quản lý lý do.</p></div>
        )
      ) : null}

      {poForm && (
        <PurchaseOrderForm
          warehouses={warehouses}
          reasons={reasons}
          editing={poForm.editing}
          onClose={() => setPoForm(null)}
          onSaved={() => {
            setPoForm(null);
            void load();
          }}
        />
      )}
      {exportForm && (
        <StockExportForm
          warehouses={warehouses}
          reasons={reasons}
          editing={exportForm.editing}
          onClose={() => setExportForm(null)}
          onSaved={() => {
            setExportForm(null);
            void load();
          }}
        />
      )}
      {poDetail && (
        <PurchaseOrderDetail
          po={poDetail}
          reasons={reasons}
          isOwner={isOwner}
          onClose={() => setPoDetail(null)}
          onEdit={() => {
            setPoDetail(null);
            setPoForm({ editing: poDetail });
          }}
          onPrint={(label) => setPrintDoc({ kind: 'in', doc: poDetail, reasonLabel: label })}
        />
      )}
      {exportDetail && (
        <StockExportDetail
          ex={exportDetail}
          reasons={reasons}
          isOwner={isOwner}
          canCollect={canCollectDebt}
          onClose={() => setExportDetail(null)}
          onEdit={() => {
            setExportDetail(null);
            setExportForm({ editing: exportDetail });
          }}
          onPrint={(label) => setPrintDoc({ kind: 'out', doc: exportDetail, reasonLabel: label })}
          onCollected={(updated) => {
            setExportDetail(updated);
            void load();
          }}
        />
      )}
      {printDoc && <StockDocPrint data={printDoc} onDone={() => setPrintDoc(null)} />}
      {supForm && (
        <SupplierForm
          initial={supForm === 'new' ? null : supForm}
          onClose={() => setSupForm(null)}
          onSaved={() => {
            setSupForm(null);
            void load();
          }}
        />
      )}
      {payForm && (
        <PaySupplierSheet
          supplier={payForm}
          warehouses={warehouses}
          onClose={() => setPayForm(null)}
          onSaved={() => {
            setPayForm(null);
            void load();
          }}
        />
      )}
      </div>
    </div>
  );
}

function DetailRow({ label, value, danger }: { label: string; value: string; danger?: boolean }) {
  return (
    <div className="row" style={{ justifyContent: 'space-between', padding: '4px 0' }}>
      <span className="muted">{label}</span>
      <b style={danger ? { color: 'var(--red)' } : undefined}>{value}</b>
    </div>
  );
}

/** Modal xem chi tiết phiếu nhập. */
function PurchaseOrderDetail({
  po,
  reasons,
  isOwner,
  onClose,
  onEdit,
  onPrint,
}: {
  po: PurchaseOrder;
  reasons: StockReasonsSettings | null;
  isOwner: boolean;
  onClose: () => void;
  onEdit: () => void;
  onPrint: (reasonLabel: string | null) => void;
}) {
  const reasonLabel = po.reason_id ? reasons?.import_reasons.find((r) => r.id === po.reason_id)?.label : null;
  return (
    <Sheet title={`Phiếu nhập ${po.code}`} onClose={onClose}>
      <div className="card" style={{ marginBottom: 12 }}>
        <DetailRow label="Ngày nhập" value={po.business_date} />
        <DetailRow label="Kho" value={po.warehouse_name} />
        <DetailRow label="Nhà cung cấp" value={po.supplier_name} />
        {reasonLabel && <DetailRow label="Lý do" value={reasonLabel} />}
      </div>
      <div className="card" style={{ marginBottom: 12 }}>
        {po.items.map((it, i) => (
          <div
            key={i}
            className="row"
            style={{ justifyContent: 'space-between', padding: '6px 0', borderTop: i > 0 ? '1px solid var(--line)' : undefined }}
          >
            <span style={{ flex: 1 }}>
              <div style={{ fontWeight: 600 }}>{it.ingredient_name}</div>
              <div className="small muted">
                {it.qty} {it.unit} × {formatVND(it.unit_cost)}
              </div>
            </span>
            <b>{formatVND(it.line_total)}</b>
          </div>
        ))}
        <div className="co-total-row grand" style={{ marginTop: 8 }}>
          <span>Tổng tiền</span>
          <span className="money">{formatVND(po.subtotal)}</span>
        </div>
        <DetailRow label="Đã trả" value={formatVND(po.paid_amount)} />
        {po.debt_amount > 0 && <DetailRow label="Còn nợ NCC" value={formatVND(po.debt_amount)} danger />}
      </div>
      {po.note && (
        <div className="field">
          <label>Ghi chú</label>
          <p className="small" style={{ margin: 0 }}>
            {po.note}
          </p>
        </div>
      )}
      <AttachmentsView value={po.attachments} />
      <div className="row" style={{ gap: 8, marginTop: 12 }}>
        <button type="button" className="v6demo-btn v6demo-btn-primary" style={{ flex: 1 }} onClick={() => onPrint(reasonLabel ?? null)}>
          <LineIcon name="receipt" size={16} /> In phiếu
        </button>
        {isOwner && (
          <button type="button" className="v6demo-btn v6demo-btn-dark" style={{ flex: 1 }} onClick={onEdit}>
            <LineIcon name="edit" size={16} /> Sửa
          </button>
        )}
        <button type="button" className="v6demo-btn v6demo-btn-ghost" style={{ flex: 1 }} onClick={onClose}>
          Đóng
        </button>
      </div>
    </Sheet>
  );
}

/** Modal xem chi tiết phiếu xuất. */
function StockExportDetail({
  ex,
  reasons,
  isOwner,
  canCollect,
  onClose,
  onEdit,
  onPrint,
  onCollected,
}: {
  ex: StockExport;
  reasons: StockReasonsSettings | null;
  isOwner: boolean;
  canCollect: boolean;
  onClose: () => void;
  onEdit: () => void;
  onPrint: (reasonLabel: string) => void;
  onCollected: (updated: StockExport) => void;
}) {
  const toast = useToast();
  const [showCollect, setShowCollect] = useState(false);
  const [collectAmount, setCollectAmount] = useState('');
  const [collectFundId, setCollectFundId] = useState('');
  const [funds, setFunds] = useState<Fund[]>([]);
  const [collecting, setCollecting] = useState(false);
  const openCollect = () => {
    setCollectAmount(String(ex.receivable_amount || ''));
    setCollectFundId(ex.fund_id ?? '');
    getFunds().then(setFunds).catch(() => {});
    setShowCollect(true);
  };
  const doCollect = async () => {
    const v = parseInt(collectAmount.replace(/\D/g, ''), 10) || 0;
    if (v <= 0) return toast.show('Nhập số tiền thu lớn hơn 0');
    if (v > ex.receivable_amount) return toast.show('Số tiền thu lớn hơn phải thu còn lại');
    setCollecting(true);
    try {
      const updated = await collectExportReceivable(ex.id, v, collectFundId || null);
      toast.show(`Đã thu phải thu ${formatVND(v)}`);
      setShowCollect(false);
      onCollected(updated);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Thu phải thu thất bại');
    } finally {
      setCollecting(false);
    }
  };
  const reasonLabel = reasons?.export_reasons.find((r) => r.id === ex.reason)?.label ?? 'Xuất kho';
  const behaviorLabel: Record<string, string> =
    ex.behavior === 'sale'
      ? { v: 'Bán — thu tiền vào quỹ' }
      : ex.behavior === 'return_supplier'
        ? { v: 'Trả NCC — trừ công nợ' }
        : { v: 'Chỉ trừ tồn kho' };
  return (
    <Sheet title={`Phiếu xuất ${ex.code}`} onClose={onClose}>
      <div className="card" style={{ marginBottom: 12 }}>
        <DetailRow label="Ngày xuất" value={ex.business_date} />
        <DetailRow label="Kho" value={ex.warehouse_name} />
        <DetailRow label="Lý do" value={reasonLabel} />
        <DetailRow label="Hành vi" value={behaviorLabel.v} />
        {ex.supplier_name && <DetailRow label="Nhà cung cấp" value={ex.supplier_name} />}
        {ex.customer_name && <DetailRow label="Khách hàng" value={ex.customer_name} />}
      </div>
      <div className="card" style={{ marginBottom: 12 }}>
        {ex.items.map((it, i) => (
          <div
            key={i}
            className="row"
            style={{ justifyContent: 'space-between', padding: '6px 0', borderTop: i > 0 ? '1px solid var(--line)' : undefined }}
          >
            <span style={{ flex: 1 }}>
              <div style={{ fontWeight: 600 }}>{it.ingredient_name}</div>
              <div className="small muted">
                {it.qty} {it.unit} × {formatVND(it.unit_price)}
              </div>
            </span>
            <b>{formatVND(it.line_total)}</b>
          </div>
        ))}
        <div className="co-total-row grand" style={{ marginTop: 8 }}>
          <span>Tổng tiền</span>
          <span className="money">{formatVND(ex.subtotal)}</span>
        </div>
        {ex.received_amount > 0 && <DetailRow label="Đã thu" value={formatVND(ex.received_amount)} />}
        {ex.receivable_amount > 0 && <DetailRow label="Còn phải thu" value={formatVND(ex.receivable_amount)} />}
      </div>
      {ex.note && (
        <div className="field">
          <label>Ghi chú</label>
          <p className="small" style={{ margin: 0 }}>
            {ex.note}
          </p>
        </div>
      )}
      <AttachmentsView value={ex.attachments} />
      <div className="row" style={{ gap: 8, marginTop: 12 }}>
        <button type="button" className="v6demo-btn v6demo-btn-primary" style={{ flex: 1 }} onClick={() => onPrint(reasonLabel)}>
          <LineIcon name="receipt" size={16} /> In phiếu
        </button>
        {isOwner && (
          <button type="button" className="v6demo-btn v6demo-btn-dark" style={{ flex: 1 }} onClick={onEdit}>
            <LineIcon name="edit" size={16} /> Sửa
          </button>
        )}
        <button type="button" className="v6demo-btn v6demo-btn-ghost" style={{ flex: 1 }} onClick={onClose}>
          Đóng
        </button>
      </div>
      {canCollect && ex.receivable_amount > 0 && (
        <button type="button" className="v6demo-btn v6demo-btn-primary v6demo-btn-block" style={{ marginTop: 8 }} onClick={openCollect}>
          <LineIcon name="wallet" size={16} /> Thu phải thu ({formatVND(ex.receivable_amount)})
        </button>
      )}
      {showCollect && (
        <Sheet title={`Thu phải thu ${ex.code}`} onClose={() => setShowCollect(false)}>
          <div className="field">
            <label>Số tiền thu (đ) — tối đa {formatVND(ex.receivable_amount)}</label>
            <input className="input" inputMode="numeric" value={collectAmount} onChange={(e) => setCollectAmount(e.target.value)} />
          </div>
          <div className="field">
            <label>Thu vào quỹ</label>
            <select className="input" value={collectFundId} onChange={(e) => setCollectFundId(e.target.value)}>
              <option value="">— Chọn quỹ —</option>
              {funds.filter((f) => f.active).map((f) => (
                <option key={f.id} value={f.id}>
                  {f.name}
                </option>
              ))}
            </select>
          </div>
          {ex.customer_name && (
            <p className="small muted">Thu này đồng thời giảm nợ của {ex.customer_name} (nếu phần phải thu đã ghi vào nợ khách).</p>
          )}
          <button type="button" className="v6demo-btn v6demo-btn-primary v6demo-btn-block" disabled={collecting} onClick={() => void doCollect()}>
            {collecting ? 'Đang lưu…' : <><LineIcon name="check" size={16} /> Xác nhận thu</>}
          </button>
        </Sheet>
      )}
    </Sheet>
  );
}

// Bảng chọn nguyên liệu có tìm kiếm (thay cho <select> mặc định vốn không
// tìm được trong lúc chọn): bấm vào ô nguyên liệu ở dòng phiếu là mở bảng
// này, gõ tên để lọc, bấm vào dòng là chọn.
function IngredientPickSheet({ ingredients, onClose, onPick }: {
  ingredients: Ingredient[];
  onClose: () => void;
  onPick: (g: Ingredient) => void;
}) {
  const [q, setQ] = useState('');
  const needle = unsignVietnamese(q.trim()).toLowerCase();
  const visible = needle ? ingredients.filter((g) => unsignVietnamese(g.name).toLowerCase().includes(needle)) : ingredients;
  return (
    <Sheet title="Chọn nguyên liệu" onClose={onClose}>
      <div className="v6demo-search v6demo-purchase-search">
        <LineIcon name="search" size={18} />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Tìm nguyên liệu theo tên…" aria-label="Tìm nguyên liệu theo tên" autoFocus />
      </div>
      {ingredients.length === 0 ? (
        <p className="muted" style={{ textAlign: 'center' }}>Chưa có nguyên liệu nào.</p>
      ) : visible.length === 0 ? (
        <p className="muted" style={{ textAlign: 'center' }}>Không tìm thấy nguyên liệu phù hợp.</p>
      ) : (
        <div className="v6demo-glass v6demo-purchase-list">
          {visible.map((g) => (
            <div key={g.id} className="v6demo-purchase-row" onClick={() => onPick(g)}>
              <span className="v6demo-purchase-rbody">
                <span className="v6demo-purchase-rtitle">{g.name}</span>
                <span className="v6demo-purchase-rsub">{g.unit}{g.cost_per_unit > 0 && <> · {formatVND(g.cost_per_unit)}/{g.unit}</>}</span>
              </span>
            </div>
          ))}
        </div>
      )}
    </Sheet>
  );
}

function PurchaseOrderForm({
  warehouses,
  reasons,
  editing,
  onClose,
  onSaved,
}: {
  warehouses: Warehouse[];
  reasons: StockReasonsSettings | null;
  editing?: PurchaseOrder;
  onClose: () => void;
  onSaved: () => void;
}) {
  const toast = useToast();
  const [ingredients, setIngredients] = useState<Ingredient[]>([]);
  const [funds, setFunds] = useState<Fund[]>([]);
  const [supplierId, setSupplierId] = useState(editing?.supplier_id ?? '');
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [reasonId, setReasonId] = useState(editing?.reason_id ?? '');
  const [attachments, setAttachments] = useState<string[]>(editing?.attachments ?? []);
  const [warehouseId, setWarehouseId] = useState(editing?.warehouse_id ?? warehouses[0]?.id ?? '');
  // v6.3: ngày + giờ của phiếu (datetime-local, giờ VN). Tạo mới mặc định giờ
  // hiện tại; sửa phiếu cũ thì nạp giờ thật của phiếu (business_datetime, nếu
  // có) hoặc giờ tạo phiếu — KHÔNG nạp 07:00. Chỉ khi người dùng chạm vào
  // trường này thì giờ mới được gửi lên (giữ nguyên giờ quỹ cũ nếu không chạm).
  const [dateTime, setDateTime] = useState(() =>
    editing
      ? (isoToVNDateTimeInput(editing.business_datetime) ??
        isoToVNDateTimeInput(editing.created_at) ??
        `${editing.business_date}T00:00`)
      : toLocalDateTimeInput(),
  );
  const [dateTimeTouched, setDateTimeTouched] = useState(false);
  const [rows, setRows] = useState<{ ingredientId: string; qty: string; unitCost: string }[]>(
    editing && editing.items.length > 0
      ? editing.items.map((it) => ({
          ingredientId: it.ingredient_id,
          qty: String(it.qty),
          unitCost: String(it.unit_cost),
        }))
      : [{ ingredientId: '', qty: '', unitCost: '' }],
  );
  const [pickRow, setPickRow] = useState<number | null>(null);
  const [paid, setPaid] = useState(editing ? String(editing.paid_amount || '') : '');
  const [fundId, setFundId] = useState(editing?.fund_id ?? '');
  const [note, setNote] = useState(editing?.note ?? '');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    listIngredients(true).then(setIngredients).catch(() => {});
    getFunds().then(setFunds).catch(() => {});
    listSuppliers().then(setSuppliers).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const items: CreatePOItemInput[] = rows
    .map((r) => ({
      ingredientId: r.ingredientId,
      qty: parseFloat(r.qty) || 0,
      unitCost: parseInt(r.unitCost.replace(/\D/g, ''), 10) || 0,
    }))
    .filter((r) => r.ingredientId && r.qty > 0);
  const total = rows.reduce((s, r) => {
    const q = parseFloat(r.qty) || 0;
    const c = parseInt(r.unitCost.replace(/\D/g, ''), 10) || 0;
    return s + q * c;
  }, 0);
  const paidNum = parseInt(paid.replace(/\D/g, ''), 10) || 0;

  const setRow = (i: number, patch: Partial<(typeof rows)[number]>) =>
    setRows((prev) => prev.map((r, j) => (j === i ? { ...r, ...patch } : r)));

  const submit = async () => {
    if (!warehouseId) return toast.show('Chọn kho nhập');
    if (items.length === 0) return toast.show('Thêm ít nhất một nguyên liệu');
    setSaving(true);
    try {
      const input = {
        supplierId: supplierId || null,
        warehouseId,
        items,
        paidAmount: paidNum,
        fundId: paidNum > 0 ? fundId || null : null,
        note: note.trim() || null,
        businessDate: editing && !dateTimeTouched ? editing.business_date : (datePartOfDateTimeInput(dateTime) ?? editing?.business_date ?? todayVN()),
        businessDateTime: editing && !dateTimeTouched ? null : dateTime,
        reasonId: reasonId || null,
        attachments,
      };
      if (editing) {
        await updatePurchaseOrder(editing.id, input);
        toast.show(`Đã sửa phiếu nhập ${editing.code}`);
      } else {
        await createPurchaseOrder(input);
        toast.show('Đã tạo phiếu nhập');
      }
      onSaved();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : editing ? 'Sửa phiếu nhập thất bại' : 'Tạo phiếu nhập thất bại');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Sheet title={editing ? `Sửa phiếu nhập ${editing.code}` : 'Tạo phiếu nhập'} onClose={onClose}>
      <div className="row" style={{ gap: 8 }}>
        <div className="field" style={{ flex: 1 }}>
          <label>Nhà cung cấp</label>
          <select className="input" value={supplierId} onChange={(e) => setSupplierId(e.target.value)}>
            <option value="">Mua lẻ (không NCC)</option>
            {suppliers.filter((s) => s.active).map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        </div>
        <div className="field" style={{ flex: 1 }}>
          <label>Kho nhập</label>
          <select className="input" value={warehouseId} onChange={(e) => setWarehouseId(e.target.value)}>
            {warehouses.map((w) => (
              <option key={w.id} value={w.id}>
                {w.name}
              </option>
            ))}
          </select>
        </div>
        <div className="field" style={{ flex: 1 }}>
          <label>Lý do nhập</label>
          <select className="input" value={reasonId} onChange={(e) => setReasonId(e.target.value)}>
            <option value="">— Chọn lý do —</option>
            {(reasons?.import_reasons ?? []).map((r) => (
              <option key={r.id} value={r.id}>
                {r.label}
              </option>
            ))}
          </select>
        </div>
      </div>
      <div className="field">
        <label>Ngày giờ nhập</label>
        <input className="input" type="datetime-local" max={toLocalDateTimeInput()} value={dateTime} onChange={(e) => { if (e.target.value) { setDateTime(e.target.value); setDateTimeTouched(true); } }} />
      </div>
      {rows.map((r, i) => {
        const ing = ingredients.find((x) => x.id === r.ingredientId);
        return (
          <div key={i} className="v6demo-glass v6demo-glass-sm v6demo-purchase-form-row">
            <div className="field" style={{ marginBottom: 8 }}>
              <label>Nguyên liệu</label>
              <div className="v6demo-input v6demo-purchase-pick" onClick={() => setPickRow(i)} role="button" aria-label="Chọn nguyên liệu">
                <span>{ing ? `${ing.name} (${ing.unit})` : '— Chọn nguyên liệu —'}</span>
                
              </div>
            </div>
            <div className="row" style={{ gap: 8 }}>
              <div className="field" style={{ flex: 1, margin: 0 }}>
                <label>Số lượng{ing ? ` (${ing.unit})` : ''}</label>
                <input className="input" inputMode="decimal" placeholder="0" value={r.qty} onChange={(e) => setRow(i, { qty: e.target.value.replace(/[^\d.]/g, '') })} />
              </div>
              <div className="field" style={{ flex: 1, margin: 0 }}>
                <label>Đơn giá (đ)</label>
                <input className="input" inputMode="numeric" placeholder="0" value={r.unitCost} onChange={(e) => setRow(i, { unitCost: e.target.value })} />
              </div>
              <button
                type="button"
                className="v6demo-btn v6demo-btn-ghost v6demo-btn-sm"
                onClick={() => setRows((prev) => prev.filter((_, j) => j !== i))}
                disabled={rows.length === 1}
              >
                <LineIcon name="x" size={16} />
              </button>
            </div>
          </div>
        );
      })}
      <button className="v6demo-btn v6demo-btn-ghost v6demo-btn-block v6demo-purchase-add-row" onClick={() => setRows((prev) => [...prev, { ingredientId: '', qty: '', unitCost: '' }])}>
        <LineIcon name="plus" size={16} /> Thêm dòng
      </button>
      {pickRow !== null && (
        <IngredientPickSheet
          ingredients={ingredients}
          onClose={() => setPickRow(null)}
          onPick={(g) => {
            setRow(pickRow, { ingredientId: g.id, unitCost: String(g.cost_per_unit ?? '') });
            setPickRow(null);
          }}
        />
      )}
      <div className="card" style={{ marginBottom: 12 }}>
        <div className="co-total-row grand">
          <span>Tổng tiền nhập</span>
          <span className="money">{formatVND(Math.round(total))}</span>
        </div>
      </div>
      <div className="row" style={{ gap: 8 }}>
        <div className="field" style={{ flex: 1 }}>
          <label>Trả ngay (đ)</label>
          <input className="input" inputMode="numeric" placeholder="0" value={paid} onChange={(e) => setPaid(e.target.value)} />
        </div>
        <div className="field" style={{ flex: 1 }}>
          <label>Trả từ quỹ</label>
          <select className="input" value={fundId} onChange={(e) => setFundId(e.target.value)}>
            <option value="">— Chọn quỹ —</option>
            {funds.filter((f) => f.active).map((f) => (
              <option key={f.id} value={f.id}>
                {f.name}
              </option>
            ))}
          </select>
        </div>
      </div>
      {paidNum > 0 && total > paidNum && (
        <p className="small" style={{ color: 'var(--red)' }}>
          Còn nợ NCC: {formatVND(Math.round(total) - paidNum)}
        </p>
      )}
      <div className="field">
        <label>Ghi chú</label>
        <input className="input" value={note} onChange={(e) => setNote(e.target.value)} placeholder="VD: nhập sáng thứ 2…" />
      </div>
      <AttachmentsInput value={attachments} onChange={setAttachments} />
      <button className="v6demo-btn v6demo-btn-primary v6demo-btn-block" disabled={saving} onClick={() => void submit()}>
        {saving ? 'Đang lưu…' : editing ? <><LineIcon name="check" size={16} /> Lưu thay đổi</> : <><LineIcon name="check" size={16} /> Tạo phiếu nhập</>}
      </button>
    </Sheet>
  );
}

/** Tab quản lý lý do nhập/xuất kho (chỉ chủ quán). */
function ReasonsTab({
  reasons,
  onSaved,
}: {
  reasons: StockReasonsSettings | null;
  onSaved: () => Promise<void>;
}) {
  const toast = useToast();
  const [importList, setImportList] = useState<StockReason[]>(reasons?.import_reasons ?? []);
  const [exportList, setExportList] = useState<StockReason[]>(reasons?.export_reasons ?? []);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    setImportList(reasons?.import_reasons ?? []);
    setExportList(reasons?.export_reasons ?? []);
  }, [reasons]);

  const behaviorLabel: Record<string, string> = {
    sale: 'Bán (thu tiền vào quỹ)',
    return_supplier: 'Trả NCC (trừ công nợ)',
    none: 'Chỉ trừ tồn kho',
  };

  const save = async (imp: StockReason[], exp: StockReason[]) => {
    setBusy(true);
    try {
      await saveStockReasons({ import_reasons: imp, export_reasons: exp });
      toast.show('Đã lưu lý do');
      await onSaved();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  const addReason = (kind: 'import' | 'export') => {
    const label = window.prompt(kind === 'import' ? 'Tên lý do nhập:' : 'Tên lý do xuất:');
    if (!label?.trim()) return;
    const r: StockReason = {
      id: 'custom_' + Date.now().toString(36),
      label: label.trim(),
      behavior: kind === 'export' ? 'none' : undefined,
    };
    if (kind === 'import') {
      const next = [...importList, r];
      setImportList(next);
      void save(next, exportList);
    } else {
      const next = [...exportList, r];
      setExportList(next);
      void save(importList, next);
    }
  };

  const renameReason = (kind: 'import' | 'export', id: string) => {
    const list = kind === 'import' ? importList : exportList;
    const cur = list.find((x) => x.id === id);
    const label = window.prompt('Tên lý do:', cur?.label ?? '');
    if (!label?.trim() || label.trim() === cur?.label) return;
    const next = list.map((x) => (x.id === id ? { ...x, label: label.trim() } : x));
    if (kind === 'import') {
      setImportList(next);
      void save(next, exportList);
    } else {
      setExportList(next);
      void save(importList, next);
    }
  };

  const deleteReason = (kind: 'import' | 'export', id: string) => {
    const list = kind === 'import' ? importList : exportList;
    const cur = list.find((x) => x.id === id);
    if (cur?.builtin) return toast.show('Lý do mặc định không xóa được');
    if (!window.confirm(`Xóa lý do "${cur?.label}"?`)) return;
    const next = list.filter((x) => x.id !== id);
    if (kind === 'import') {
      setImportList(next);
      void save(next, exportList);
    } else {
      setExportList(next);
      void save(importList, next);
    }
  };

  const changeBehavior = (id: string, behavior: StockExportBehavior) => {
    const next = exportList.map((x) => (x.id === id ? { ...x, behavior } : x));
    setExportList(next);
    void save(importList, next);
  };

  return (
    <>
      <div className="v6demo-glass v6demo-purchase-reasons-card">
        <div className="row" style={{ justifyContent: 'space-between', marginBottom: 8 }}>
          <b><LineIcon name="download" size={16} /> Lý do nhập kho</b>
          <button type="button" className="v6demo-btn v6demo-btn-ghost v6demo-btn-sm" onClick={() => addReason('import')} disabled={busy}>
            <LineIcon name="plus" size={16} /> Thêm
          </button>
        </div>
        {importList.map((r) => (
          <div key={r.id} className="v6demo-purchase-reason-row">
            <span>{r.label}</span>
            <span className="row" style={{ gap: 4 }}>
              <button type="button" className="v6demo-btn v6demo-btn-ghost v6demo-btn-sm" onClick={() => renameReason('import', r.id)} disabled={busy}>
                Sửa
              </button>
              {!r.builtin && (
                <button type="button" className="v6demo-btn v6demo-btn-danger v6demo-btn-sm" onClick={() => deleteReason('import', r.id)} disabled={busy}>
                  Xóa
                </button>
              )}
            </span>
          </div>
        ))}
      </div>
      <div className="v6demo-glass v6demo-purchase-reasons-card">
        <div className="row" style={{ justifyContent: 'space-between', marginBottom: 8 }}>
          <b><LineIcon name="package" size={16} /> Lý do xuất kho</b>
          <button type="button" className="v6demo-btn v6demo-btn-ghost v6demo-btn-sm" onClick={() => addReason('export')} disabled={busy}>
            <LineIcon name="plus" size={16} /> Thêm
          </button>
        </div>
        {exportList.map((r) => (
          <div key={r.id} className="v6demo-purchase-reason-row v6demo-purchase-reason-col">
            <div className="row" style={{ justifyContent: 'space-between' }}>
              <span>{r.label}</span>
              <span className="row" style={{ gap: 4 }}>
                <button type="button" className="v6demo-btn v6demo-btn-ghost v6demo-btn-sm" onClick={() => renameReason('export', r.id)} disabled={busy}>
                  Sửa
                </button>
                {!r.builtin && (
                  <button type="button" className="v6demo-btn v6demo-btn-danger v6demo-btn-sm" onClick={() => deleteReason('export', r.id)} disabled={busy}>
                    Xóa
                  </button>
                )}
              </span>
            </div>
            <div className="field" style={{ marginTop: 6 }}>
              <label>Hành vi</label>
              <select className="input" value={r.behavior ?? 'none'} onChange={(e) => changeBehavior(r.id, e.target.value as StockExportBehavior)} disabled={busy}>
                <option value="sale">{behaviorLabel.sale}</option>
                <option value="return_supplier">{behaviorLabel.return_supplier}</option>
                <option value="none">{behaviorLabel.none}</option>
              </select>
            </div>
          </div>
        ))}
        <p className="small muted" style={{ marginTop: 8 }}>
          Hành vi quyết định phiếu xuất làm gì thêm: thu tiền vào quỹ, trừ công nợ NCC, hay chỉ trừ tồn kho.
        </p>
      </div>
    </>
  );
}

function StockExportForm({
  warehouses,
  reasons,
  editing,
  onClose,
  onSaved,
}: {
  warehouses: Warehouse[];
  reasons: StockReasonsSettings | null;
  editing?: StockExport;
  onClose: () => void;
  onSaved: () => void;
}) {
  const toast = useToast();
  const [ingredients, setIngredients] = useState<Ingredient[]>([]);
  const [funds, setFunds] = useState<Fund[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [reason, setReason] = useState<StockExportReason>(editing?.reason ?? 'ban');
  const [supplierId, setSupplierId] = useState(editing?.supplier_id ?? '');
  const [warehouseId, setWarehouseId] = useState(editing?.warehouse_id ?? warehouses[0]?.id ?? '');
  // v6.3: ngày + giờ của phiếu (như form nhập: tạo mới mặc định giờ hiện tại;
  // sửa mà không chạm trường giờ thì giữ nguyên giờ quỹ cũ).
  const [dateTime, setDateTime] = useState(() =>
    editing
      ? (isoToVNDateTimeInput(editing.business_datetime) ??
        isoToVNDateTimeInput(editing.created_at) ??
        `${editing.business_date}T00:00`)
      : toLocalDateTimeInput(),
  );
  const [dateTimeTouched, setDateTimeTouched] = useState(false);
  const [rows, setRows] = useState<{ ingredientId: string; qty: string; unitPrice: string }[]>(
    editing && editing.items.length > 0
      ? editing.items.map((it) => ({
          ingredientId: it.ingredient_id,
          qty: String(it.qty),
          unitPrice: String(it.unit_price),
        }))
      : [{ ingredientId: '', qty: '', unitPrice: '' }],
  );
  const [pickRow, setPickRow] = useState<number | null>(null);
  const [received, setReceived] = useState(editing ? String(editing.received_amount || '') : '');
  const [fundId, setFundId] = useState(editing?.fund_id ?? '');
  const [customerId, setCustomerId] = useState(editing?.customer_id ?? '');
  const [customerName, setCustomerName] = useState(editing?.customer_name ?? '');
  const [showPick, setShowPick] = useState(false);
  const [note, setNote] = useState(editing?.note ?? '');
  const [attachments, setAttachments] = useState<string[]>(editing?.attachments ?? []);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    listIngredients(true).then(setIngredients).catch(() => {});
    getFunds().then(setFunds).catch(() => {});
    listSuppliers().then(setSuppliers).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const items: CreateStockExportItemInput[] = rows
    .map((r) => ({
      ingredientId: r.ingredientId,
      qty: parseFloat(r.qty) || 0,
      unitPrice: parseInt(r.unitPrice.replace(/\D/g, ''), 10) || 0,
    }))
    .filter((r) => r.ingredientId && r.qty > 0);
  const total = rows.reduce((s, r) => {
    const q = parseFloat(r.qty) || 0;
    const c = parseInt(r.unitPrice.replace(/\D/g, ''), 10) || 0;
    return s + q * c;
  }, 0);
  const receivedNum = parseInt(received.replace(/\D/g, ''), 10) || 0;

  const setRow = (i: number, patch: Partial<(typeof rows)[number]>) =>
    setRows((prev) => prev.map((r, j) => (j === i ? { ...r, ...patch } : r)));

  const behavior = exportReasonBehavior(reasons?.export_reasons ?? [], reason);
  const submit = async () => {
    if (!warehouseId) return toast.show('Chọn kho xuất');
    if (items.length === 0) return toast.show('Thêm ít nhất một nguyên liệu');
    if (behavior === 'return_supplier' && !supplierId) return toast.show('Chọn nhà cung cấp để trả hàng');
    setSaving(true);
    try {
      const input = {
        reason,
        behavior,
        supplierId: behavior === 'return_supplier' ? supplierId || null : null,
        customerId: behavior === 'sale' ? customerId || null : null,
        warehouseId,
        items,
        receivedAmount: behavior === 'sale' ? receivedNum : 0,
        fundId: behavior === 'sale' && receivedNum > 0 ? fundId || null : null,
        note: note.trim() || null,
        businessDate: editing && !dateTimeTouched ? editing.business_date : (datePartOfDateTimeInput(dateTime) ?? editing?.business_date ?? todayVN()),
        businessDateTime: editing && !dateTimeTouched ? null : dateTime,
        attachments,
      };
      if (editing) {
        await updateStockExport(editing.id, input);
        toast.show(`Đã sửa phiếu xuất ${editing.code}`);
      } else {
        await createStockExport(input);
        toast.show('Đã tạo phiếu xuất');
      }
      onSaved();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : editing ? 'Sửa phiếu xuất thất bại' : 'Tạo phiếu xuất thất bại');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Sheet title={editing ? `Sửa phiếu xuất ${editing.code}` : 'Tạo phiếu xuất'} onClose={onClose}>
      <div className="row" style={{ gap: 8 }}>
        <div className="field" style={{ flex: 1 }}>
          <label>Lý do xuất</label>
          <select className="input" value={reason} onChange={(e) => setReason(e.target.value)}>
            {(reasons?.export_reasons ?? []).map((r) => (
              <option key={r.id} value={r.id}>
                {r.label}
              </option>
            ))}
          </select>
        </div>
        <div className="field" style={{ flex: 1 }}>
          <label>Kho xuất</label>
          <select className="input" value={warehouseId} onChange={(e) => setWarehouseId(e.target.value)}>
            {warehouses.map((w) => (
              <option key={w.id} value={w.id}>
                {w.name}
              </option>
            ))}
          </select>
        </div>
      </div>
      {reason === 'tra_ncc' && (
        <div className="field">
          <label>Nhà cung cấp (trả hàng)</label>
          <select className="input" value={supplierId} onChange={(e) => setSupplierId(e.target.value)}>
            <option value="">— Chọn NCC —</option>
            {suppliers.filter((sp) => sp.active).map((sp) => (
              <option key={sp.id} value={sp.id}>
                {sp.name}{sp.debt > 0 ? ` (đang nợ ${formatVND(sp.debt)})` : ''}
              </option>
            ))}
          </select>
        </div>
      )}
      <div className="field">
        <label>Ngày giờ xuất</label>
        <input className="input" type="datetime-local" max={toLocalDateTimeInput()} value={dateTime} onChange={(e) => { if (e.target.value) { setDateTime(e.target.value); setDateTimeTouched(true); } }} />
      </div>
      {rows.map((r, i) => {
        const ing = ingredients.find((x) => x.id === r.ingredientId);
        return (
          <div key={i} className="v6demo-glass v6demo-glass-sm v6demo-purchase-form-row">
            <div className="field" style={{ marginBottom: 8 }}>
              <label>Nguyên liệu</label>
              <div className="v6demo-input v6demo-purchase-pick" onClick={() => setPickRow(i)} role="button" aria-label="Chọn nguyên liệu">
                <span>{ing ? `${ing.name} (${ing.unit})` : '— Chọn nguyên liệu —'}</span>
                
              </div>
            </div>
            <div className="row" style={{ gap: 8 }}>
              <div className="field" style={{ flex: 1, margin: 0 }}>
                <label>Số lượng{ing ? ` (${ing.unit})` : ''}</label>
                <input className="input" inputMode="decimal" placeholder="0" value={r.qty} onChange={(e) => setRow(i, { qty: e.target.value.replace(/[^\d.]/g, '') })} />
              </div>
              <div className="field" style={{ flex: 1, margin: 0 }}>
                <label>Đơn giá (đ)</label>
                <input className="input" inputMode="numeric" placeholder="0" value={r.unitPrice} onChange={(e) => setRow(i, { unitPrice: e.target.value })} />
              </div>
              <button
                type="button"
                className="v6demo-btn v6demo-btn-ghost v6demo-btn-sm"
                onClick={() => setRows((prev) => prev.filter((_, j) => j !== i))}
                disabled={rows.length === 1}
              >
                <LineIcon name="x" size={16} />
              </button>
            </div>
          </div>
        );
      })}
      <button className="v6demo-btn v6demo-btn-ghost v6demo-btn-block v6demo-purchase-add-row" onClick={() => setRows((prev) => [...prev, { ingredientId: '', qty: '', unitPrice: '' }])}>
        <LineIcon name="plus" size={16} /> Thêm dòng
      </button>
      {pickRow !== null && (
        <IngredientPickSheet
          ingredients={ingredients}
          onClose={() => setPickRow(null)}
          onPick={(g) => {
            setRow(pickRow, { ingredientId: g.id });
            setPickRow(null);
          }}
        />
      )}
      <div className="card" style={{ marginBottom: 12 }}>
        <div className="co-total-row grand">
          <span>Tổng tiền xuất</span>
          <span className="money">{formatVND(Math.round(total))}</span>
        </div>
      </div>
      {reason === 'ban' && (
        <div className="field">
          <label>Khách mua (không bắt buộc — chọn để phần thu thiếu ghi vào công nợ khách)</label>
          <div className="row" style={{ gap: 8 }}>
            <button type="button" className="v6demo-btn v6demo-btn-ghost" style={{ flex: 1 }} onClick={() => setShowPick(true)}>
              {customerName ? <><LineIcon name="users" size={16} /> {customerName}</> : '— Chọn khách hàng —'}
            </button>
            {customerId && (
              <button
                type="button"
                className="v6demo-btn v6demo-btn-ghost v6demo-btn-sm"
                onClick={() => {
                  setCustomerId('');
                  setCustomerName('');
                }}
              >
                <LineIcon name="x" size={16} />
              </button>
            )}
          </div>
          {showPick && (
            <CustomerPickSheet
              warehouseId={warehouseId || null}
              onClose={() => setShowPick(false)}
              onPick={(c: Customer) => {
                setCustomerId(c.id);
                setCustomerName(c.name);
                setShowPick(false);
              }}
            />
          )}
        </div>
      )}
      {reason === 'ban' && (
        <div className="row" style={{ gap: 8 }}>
          <div className="field" style={{ flex: 1 }}>
            <label>Thu tiền (đ)</label>
            <input className="input" inputMode="numeric" placeholder="0" value={received} onChange={(e) => setReceived(e.target.value)} />
          </div>
          <div className="field" style={{ flex: 1 }}>
            <label>Thu vào quỹ</label>
            <select className="input" value={fundId} onChange={(e) => setFundId(e.target.value)}>
              <option value="">— Chọn quỹ —</option>
              {funds.filter((f) => f.active).map((f) => (
                <option key={f.id} value={f.id}>
                  {f.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      )}
      {reason === 'tra_ncc' && total > 0 && (
        <p className="small muted">Trả hàng sẽ trừ {formatVND(Math.round(total))} vào công nợ NCC đã chọn.</p>
      )}
      {reason === 'huy' && (
        <p className="small muted">Hủy hàng chỉ trừ tồn kho, không phát sinh thu/chi tiền.</p>
      )}
      <div className="field">
        <label>Ghi chú</label>
        <input className="input" value={note} onChange={(e) => setNote(e.target.value)} placeholder="VD: trả sữa hết hạn cho NCC…" />
      </div>
      <AttachmentsInput value={attachments} onChange={setAttachments} />
      <button className="v6demo-btn v6demo-btn-primary v6demo-btn-block" disabled={saving} onClick={() => void submit()}>
        {saving ? 'Đang lưu…' : editing ? <><LineIcon name="check" size={16} /> Lưu thay đổi</> : <><LineIcon name="check" size={16} /> Tạo phiếu xuất</>}
      </button>
    </Sheet>
  );
}

function SupplierForm({
  initial,
  onClose,
  onSaved,
}: {
  initial: Supplier | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const toast = useToast();
  const [name, setName] = useState(initial?.name ?? '');
  const [phone, setPhone] = useState(initial?.phone ?? '');
  const [address, setAddress] = useState(initial?.address ?? '');
  const [note, setNote] = useState(initial?.note ?? '');
  const [saving, setSaving] = useState(false);

  const submit = async () => {
    if (!name.trim()) return toast.show('Nhập tên NCC');
    setSaving(true);
    try {
      await saveSupplier({
        id: initial?.id,
        name,
        phone,
        address: address || null,
        note: note || null,
      });
      toast.show('Đã lưu NCC');
      onSaved();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    } finally {
      setSaving(false);
    }
  };

  const remove = async () => {
    if (!initial || !window.confirm(`Xóa NCC "${initial.name}"?`)) return;
    try {
      await deleteSupplier(initial.id);
      toast.show('Đã xóa NCC');
      onSaved();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Xóa thất bại');
    }
  };

  return (
    <Sheet title={initial ? 'Sửa nhà cung cấp' : 'Thêm nhà cung cấp'} onClose={onClose}>
      <div className="field">
        <label>Tên NCC *</label>
        <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="VD: Chợ đầu mối" />
      </div>
      <div className="field">
        <label>Số điện thoại</label>
        <input className="input" inputMode="tel" value={phone} onChange={(e) => setPhone(e.target.value)} />
      </div>
      <div className="field">
        <label>Địa chỉ</label>
        <input className="input" value={address} onChange={(e) => setAddress(e.target.value)} />
      </div>
      <div className="field">
        <label>Ghi chú</label>
        <input className="input" value={note} onChange={(e) => setNote(e.target.value)} />
      </div>
      <button className="v6demo-btn v6demo-btn-primary v6demo-btn-block" disabled={saving} onClick={() => void submit()}>
        {saving ? 'Đang lưu…' : 'Lưu'}
      </button>
      {initial && (
        <button className="v6demo-btn v6demo-btn-danger v6demo-btn-block" style={{ marginTop: 8 }} onClick={() => void remove()}>
          <LineIcon name="trash" size={16} /> Xóa NCC
        </button>
      )}
    </Sheet>
  );
}

function PaySupplierSheet({
  supplier,
  warehouses,
  onClose,
  onSaved,
}: {
  supplier: Supplier;
  warehouses: Warehouse[];
  onClose: () => void;
  onSaved: () => void;
}) {
  const toast = useToast();
  const [amount, setAmount] = useState(String(supplier.debt));
  const [fundId, setFundId] = useState('');
  const [funds, setFunds] = useState<Fund[]>([]);
  const [warehouseId, setWarehouseId] = useState(warehouses[0]?.id ?? '');
  const [note, setNote] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    getFunds().then(setFunds).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const submit = async () => {
    const amt = parseInt(amount.replace(/\D/g, ''), 10) || 0;
    if (amt <= 0) return toast.show('Nhập số tiền');
    if (!warehouseId) return toast.show('Chọn kho (để ghi sổ quỹ)');
    setSaving(true);
    try {
      await paySupplierDebt(supplier.id, amt, fundId || null, warehouseId, note.trim() || null);
      toast.show('Đã trả nợ NCC');
      onSaved();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Trả nợ thất bại');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Sheet title={`Trả nợ ${supplier.name}`} onClose={onClose}>
      <p className="muted" style={{ marginTop: 0 }}>
        Đang nợ: <b style={{ color: 'var(--red)' }}>{formatVND(supplier.debt)}</b>
      </p>
      <div className="field">
        <label>Số tiền trả (đ)</label>
        <input className="input" inputMode="numeric" value={amount} onChange={(e) => setAmount(e.target.value)} />
      </div>
      <div className="row" style={{ gap: 8 }}>
        <div className="field" style={{ flex: 1 }}>
          <label>Trả từ quỹ</label>
          <select className="input" value={fundId} onChange={(e) => setFundId(e.target.value)}>
            <option value="">— Chọn quỹ —</option>
            {funds.filter((f) => f.active).map((f) => (
              <option key={f.id} value={f.id}>
                {f.name}
              </option>
            ))}
          </select>
        </div>
        <div className="field" style={{ flex: 1 }}>
          <label>Kho (sổ quỹ)</label>
          <select className="input" value={warehouseId} onChange={(e) => setWarehouseId(e.target.value)}>
            {warehouses.map((w) => (
              <option key={w.id} value={w.id}>
                {w.name}
              </option>
            ))}
          </select>
        </div>
      </div>
      <div className="field">
        <label>Ghi chú</label>
        <input className="input" value={note} onChange={(e) => setNote(e.target.value)} />
      </div>
      <button className="v6demo-btn v6demo-btn-primary v6demo-btn-block" disabled={saving} onClick={() => void submit()}>
        {saving ? 'Đang trả…' : <><LineIcon name="check" size={16} /> Xác nhận trả nợ</>}
      </button>
    </Sheet>
  );
}
