// Nhat ky thao tac — bao cao rieng: loc theo khoang ngay, nguoi dung, loai thao tac.
// Ban v6 demo: giao dien moi (nen xanh la dam + the glass + icon line net manh),
// GIU NGUYEN 100% logic/tinh nang goc: tai toi da 500 log moi nhat, loc ngay /
// nguoi dung / loai thao tac, hien thi nhan + chi tiet + nguoi thuc hien + gio VN.
// Them (khong bot tinh nang cu): chip ky nhanh, tim kiem chuoi, bam dong mo
// panel chi tiet (PC: cot phu phai; mobile: sheet nen dac).
import { useEffect, useMemo, useState } from 'react';
import { AUDIT_LABELS, DbError, listAuditLogs } from '../lib/db';
import { formatDMY, todayVN, unsignVietnamese } from '../lib/format';
import type { AuditLog } from '../lib/types';
import { useToast } from '../components/Toast';
import { PageHead } from '../components/PageHead';
import { LineIcon } from '../components/LineIcon';
import './v6demo-theme.css';
import './v6demo-audit.css';

function shiftDate(ymd: string, days: number): string {
  const [y, m, d] = ymd.split('-').map(Number);
  const dt = new Date(y, m - 1, d);
  dt.setDate(dt.getDate() + days);
  const mm = String(dt.getMonth() + 1).padStart(2, '0');
  const dd = String(dt.getDate()).padStart(2, '0');
  return `${dt.getFullYear()}-${mm}-${dd}`;
}

function fmtTime(iso: string): string {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleString('vi-VN', {
      timeZone: 'Asia/Ho_Chi_Minh',
      day: '2-digit',
      month: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return iso;
  }
}

/** Bo emoji dau nhan goc (AUDIT_LABELS luu kem emoji) de hien text sach. */
function cleanLabel(action: string): string {
  return (AUDIT_LABELS[action] ?? action).replace(/^[^\s]+\s/, '');
}

/** Icon line net manh theo loai thao tac (thay emoji trong AUDIT_LABELS). */
const ACTION_ICONS: Record<string, string> = {
  'order.delete': 'trash',
  'order.edit': 'edit',
  'product.price': 'tag',
  'product.update': 'package',
  'product.delete': 'trash',
  'staff.role': 'users',
  'staff.warehouse': 'archive',
  'promo.save': 'gift',
  'voucher.save': 'ticket',
  'voucher.delete': 'trash',
  'order.online': 'globe',
  'supplier.save': 'truck',
  'supplier.delete': 'trash',
  'supplier.pay': 'wallet',
  'purchase.create': 'download',
  'stock_export.create': 'package',
  'purchase.delete': 'trash',
  'stock_export.delete': 'trash',
  'stock.check': 'clipboard',
  'product.stock_tracking': 'package',
  'settings.stock_reasons': 'gear',
  'combo.save': 'star',
  'combo.delete': 'trash',
  'day.close': 'clock',
  'cashbook.delete': 'receipt',
};

function iconFor(action: string): string {
  return ACTION_ICONS[action] ?? 'scroll';
}

function actorKey(l: AuditLog): string {
  return l.actor_id ?? `name:${l.actor_name ?? '—'}`;
}

/** Hook phat hien man hinh PC (>= 1024px), theo mau pages/Reports.tsx. */
function useIsPC(): boolean {
  const [isPC, setIsPC] = useState(() => typeof window !== 'undefined' && window.innerWidth >= 1024);
  useEffect(() => {
    const onResize = () => setIsPC(window.innerWidth >= 1024);
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);
  return isPC;
}

const PRESETS: { key: string; label: string; days: number }[] = [
  { key: 'today', label: 'Hôm nay', days: 1 },
  { key: '7d', label: '7 ngày qua', days: 7 },
  { key: '30d', label: '30 ngày qua', days: 30 },
];

function presetOf(fromDate: string, toDate: string): string {
  const t = todayVN();
  if (toDate !== t) return '';
  if (fromDate === t) return 'today';
  if (fromDate === shiftDate(t, -6)) return '7d';
  if (fromDate === shiftDate(t, -29)) return '30d';
  return '';
}

function DetailBody({ log, onClose }: { log: AuditLog; onClose: () => void }) {
  return (
    <div className="v6demo-audit-detail">
      <div className="v6demo-audit-detail-head">
        <span className="v6demo-audit-ico" aria-hidden>
          <LineIcon name={iconFor(log.action)} size={20} />
        </span>
        <div className="v6demo-audit-detail-title">
          <b>{cleanLabel(log.action)}</b>
          <span>{fmtTime(log.created_at)}</span>
        </div>
        <button type="button" className="v6demo-audit-close" onClick={onClose} aria-label="Đóng chi tiết">
          <LineIcon name="x" size={18} />
        </button>
      </div>
      <dl className="v6demo-audit-kv">
        <div>
          <dt>Người thực hiện</dt>
          <dd>{log.actor_name ?? '—'}</dd>
        </div>
        <div>
          <dt>Ngày</dt>
          <dd>{formatDMY(log.created_at.slice(0, 10))}</dd>
        </div>
        <div>
          <dt>Loại thao tác</dt>
          <dd>{log.action}</dd>
        </div>
        {log.target_type && (
          <div>
            <dt>Đối tượng</dt>
            <dd>
              {log.target_type}
              {log.target_id ? ` · ${log.target_id}` : ''}
            </dd>
          </div>
        )}
      </dl>
      {log.detail && (
        <div className="v6demo-audit-detail-note">
          <span className="v6demo-section-label">Chi tiết</span>
          <p>{log.detail}</p>
        </div>
      )}
    </div>
  );
}

export function AuditLogPage() {
  const isPC = useIsPC();
  const toast = useToast();
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [busy, setBusy] = useState(true);
  const [fromDate, setFromDate] = useState(() => shiftDate(todayVN(), -6));
  const [toDate, setToDate] = useState(() => todayVN());
  const [userFilter, setUserFilter] = useState('all');
  const [actionFilter, setActionFilter] = useState('all');
  const [q, setQ] = useState('');
  const [selectedId, setSelectedId] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      setBusy(true);
      try {
        setLogs(await listAuditLogs(500));
      } catch (e) {
        toast.show(e instanceof DbError ? e.message : 'Không tải được nhật ký');
      } finally {
        setBusy(false);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const users = useMemo(() => {
    const set = new Map<string, string>();
    for (const l of logs) {
      const key = actorKey(l);
      if (!set.has(key)) set.set(key, l.actor_name ?? '—');
    }
    return [...set.entries()].sort((a, b) => a[1].localeCompare(b[1], 'vi'));
  }, [logs]);

  const actions = useMemo(() => {
    const set = new Set(logs.map((l) => l.action));
    return [...set].sort();
  }, [logs]);

  const filtered = useMemo(() => {
    return logs.filter((l) => {
      const day = l.created_at.slice(0, 10);
      if (day < fromDate || day > toDate) return false;
      if (userFilter !== 'all' && actorKey(l) !== userFilter) return false;
      if (actionFilter !== 'all' && l.action !== actionFilter) return false;
      return true;
    });
  }, [logs, fromDate, toDate, userFilter, actionFilter]);

  const stats = useMemo(() => {
    const userSet = new Set(filtered.map(actorKey));
    const actionSet = new Set(filtered.map((l) => l.action));
    return { total: filtered.length, users: userSet.size, actions: actionSet.size };
  }, [filtered]);

  const displayed = useMemo(() => {
    const needle = unsignVietnamese(q.trim().toLowerCase());
    if (!needle) return filtered;
    return filtered.filter((l) => {
      const hay = unsignVietnamese(
        `${cleanLabel(l.action)} ${l.detail ?? ''} ${l.actor_name ?? ''} ${l.target_id ?? ''}`.toLowerCase(),
      );
      return hay.includes(needle);
    });
  }, [filtered, q]);

  const selectedLog = selectedId ? displayed.find((l) => l.id === selectedId) ?? null : null;
  const activePreset = presetOf(fromDate, toDate);

  const applyPreset = (days: number) => {
    const t = todayVN();
    setToDate(t);
    setFromDate(shiftDate(t, -(days - 1)));
  };

  return (
    <div className="page v6demo-audit v6demo-page">
      <div className="v6demo-aurora" aria-hidden />
      <div className="v6demo-content">
        <PageHead title="Nhật ký thao tác" back />
        <div className="v6demo-page-head v6demo-rise">
          <p>Lịch sử thao tác của mọi người dùng trong quán. Bấm một dòng để xem chi tiết.</p>
        </div>

        <div className="v6demo-stat-strip">
          <div className="v6demo-glass v6demo-glass-sm v6demo-stat v6demo-rise-1">
            <b>{stats.total} thao tác</b>
            <span>Trong kỳ đang chọn</span>
          </div>
          <div className="v6demo-glass v6demo-glass-sm v6demo-stat v6demo-rise-2">
            <b>{stats.users} người</b>
            <span>Đã thao tác trong kỳ</span>
          </div>
          <div className="v6demo-glass v6demo-glass-sm v6demo-stat v6demo-rise-3">
            <b>{stats.actions} loại</b>
            <span>Loại thao tác khác nhau</span>
          </div>
        </div>

        <section className="v6demo-glass v6demo-dock v6demo-rise-2" aria-label="Bộ lọc nhật ký">
          <div className="v6demo-dock-row">
            <label className="v6demo-search">
              <LineIcon name="search" size={18} />
              <input
                placeholder="Tìm thao tác, nội dung, người làm…"
                value={q}
                onChange={(e) => setQ(e.target.value)}
                aria-label="Tìm trong nhật ký"
              />
              {q && (
                <button
                  type="button"
                  className="v6demo-audit-clear-q"
                  onClick={() => setQ('')}
                  aria-label="Xóa tìm kiếm"
                >
                  <LineIcon name="x" size={16} />
                </button>
              )}
            </label>
          </div>
          <div className="v6demo-dock-row">
            <div className="v6demo-seg" role="tablist" aria-label="Kỳ nhanh">
              {PRESETS.map((p) => (
                <button
                  key={p.key}
                  type="button"
                  className={activePreset === p.key ? 'active' : ''}
                  onClick={() => applyPreset(p.days)}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>
          <div className="v6demo-dock-row">
            <label className="v6demo-date-label" htmlFor="v6demo-audit-from">
              Từ ngày
            </label>
            <input
              id="v6demo-audit-from"
              className="v6demo-input v6demo-date-input"
              type="date"
              max={toDate}
              value={fromDate}
              onChange={(e) => e.target.value && setFromDate(e.target.value)}
              aria-label="Từ ngày"
            />
            <label className="v6demo-date-label" htmlFor="v6demo-audit-to">
              Đến ngày
            </label>
            <input
              id="v6demo-audit-to"
              className="v6demo-input v6demo-date-input"
              type="date"
              min={fromDate}
              max={todayVN()}
              value={toDate}
              onChange={(e) => e.target.value && setToDate(e.target.value)}
              aria-label="Đến ngày"
            />
          </div>
          <div className="v6demo-dock-row">
            <select
              className="v6demo-input v6demo-audit-select"
              value={userFilter}
              onChange={(e) => setUserFilter(e.target.value)}
              aria-label="Lọc theo người dùng"
            >
              <option value="all">Tất cả người dùng</option>
              {users.map(([key, name]) => (
                <option key={key} value={key}>
                  {name}
                </option>
              ))}
            </select>
            <select
              className="v6demo-input v6demo-audit-select"
              value={actionFilter}
              onChange={(e) => setActionFilter(e.target.value)}
              aria-label="Lọc theo loại thao tác"
            >
              <option value="all">Tất cả loại thao tác</option>
              {actions.map((a) => (
                <option key={a} value={a}>
                  {cleanLabel(a)}
                </option>
              ))}
            </select>
          </div>
        </section>

        <div className="v6demo-audit-layout">
          <section className="v6demo-glass v6demo-ledger v6demo-rise-3" aria-label="Danh sách thao tác">
            <div className="v6demo-ledger-head">
              <h2>Danh sách thao tác</h2>
              <span>
                {displayed.length} thao tác · {formatDMY(fromDate)} → {formatDMY(toDate)}
              </span>
            </div>
            {busy ? (
              <p className="v6demo-audit-loading">Đang tải…</p>
            ) : displayed.length === 0 ? (
              <div className="v6demo-empty">
                <span className="v6demo-audit-empty-ico" aria-hidden>
                  <LineIcon name="scroll" size={28} />
                </span>
                <p>
                  {filtered.length === 0
                    ? 'Không có thao tác nào trong khoảng này.'
                    : 'Không có thao tác nào khớp từ khóa tìm kiếm.'}
                </p>
              </div>
            ) : (
              <div className="v6demo-audit-rows">
                {displayed.map((a) => (
                  <button
                    key={a.id}
                    type="button"
                    className={`v6demo-audit-row${selectedLog?.id === a.id ? ' is-open' : ''}`}
                    onClick={() => setSelectedId(selectedLog?.id === a.id ? null : a.id)}
                    aria-expanded={selectedLog?.id === a.id}
                  >
                    <span className="v6demo-audit-ico" aria-hidden>
                      <LineIcon name={iconFor(a.action)} size={18} />
                    </span>
                    <span className="v6demo-audit-row-main">
                      <b>{cleanLabel(a.action)}</b>
                      {a.detail && <span className="v6demo-audit-detail-line">{a.detail}</span>}
                      <span className="v6demo-audit-meta">
                        <LineIcon name="users" size={13} /> {a.actor_name ?? '—'}
                        {' · '}
                        <LineIcon name="clock" size={13} /> {fmtTime(a.created_at)}
                      </span>
                    </span>
                    <LineIcon name="eye" size={16} />
                  </button>
                ))}
              </div>
            )}
            <p className="v6demo-ledger-foot">Hiển thị tối đa 500 thao tác mới nhất. Thu hẹp khoảng ngày để xem các thao tác cũ hơn.</p>
          </section>

          {isPC && selectedLog && (
            <aside className="v6demo-glass v6demo-audit-panel v6demo-panel-in" aria-label="Chi tiết thao tác">
              <DetailBody log={selectedLog} onClose={() => setSelectedId(null)} />
            </aside>
          )}
        </div>
      </div>

      {!isPC && selectedLog && (
        <div
          className="v6demo-audit-sheet-backdrop"
          role="presentation"
          onClick={() => setSelectedId(null)}
        >
          <div
            className="v6demo-audit-sheet v6demo-sheet-in"
            role="dialog"
            aria-label="Chi tiết thao tác"
            onClick={(e) => e.stopPropagation()}
          >
            <DetailBody log={selectedLog} onClose={() => setSelectedId(null)} />
          </div>
        </div>
      )}
    </div>
  );
}
