// Sổ nợ — thao tác nhanh kiểu "Tôi đã đưa / Tôi đã nhận".
// Dùng dữ liệu công nợ sẵn có (Customer.debt + adjustDebt trong lib/db.ts).
import { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { DbError, adjustDebt, collectCustomerDebt, getAllowedWarehouses, getFunds, listDebtLogs, listSuppliers, searchCustomers, toLocalDateTimeInput } from '../lib/db';
import { formatDMY, formatVND, unsignVietnamese } from '../lib/format';
import { Sheet } from '../components/Sheet';
import { PageHead } from '../components/PageHead';
import { useToast } from '../components/Toast';
import { useAuth } from '../lib/auth';
import { LineIcon } from '../components/LineIcon';
import type { Customer, DebtLog, Fund, Supplier, Warehouse } from '../lib/types';
import './pc-debt.css';
import './v6demo-theme.css';
import './v6demo-debt.css';

/** Hook phat hien man hinh PC (>= 1024px), theo mau pages/Reports.tsx. */
function useIsPC(): boolean {
  const [isPC, setIsPC] = useState(() => typeof window !== 'undefined' && window.innerWidth >= 1024);
  useEffect(() => {
    const onResize = () => setIsPC(window.innerWidth >= 1024);
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);
  return isPC;
}

/** Nhan hang thanh vien that (khong dung emoji cua TIER_LABEL trong JSX PC). */
function tierLabel(tier: Customer['tier'] | undefined): string {
  if (tier === 'gold') return 'Vàng';
  if (tier === 'silver') return 'Bạc';
  return 'Thành viên';
}

export function DebtBook() {
  const navigate = useNavigate();
  const toast = useToast();
  const { can } = useAuth();
  const canDebt = can('debt');
  const isPC = useIsPC();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [list, setList] = useState<Customer[]>([]);
  // Cong no phai tra NCC (v5.7): tab "phai tra" trong bao cao cong no
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [tab, setTab] = useState<'receivable' | 'payable'>('receivable');
  const [q, setQ] = useState('');
  const [busy, setBusy] = useState(true);
  const [sheet, setSheet] = useState<'give' | 'receive' | null>(null);
  // Khách chọn sẵn cho sheet Thu/Ghi nợ khi bấm từ panel PC (mobile không
  // đặt nên luôn null → hành vi mobile y nguyên).
  const [sheetCustomer, setSheetCustomer] = useState<Customer | null>(null);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [whFilter, setWhFilter] = useState('all');

  const load = useCallback(async () => {
    setBusy(true);
    try {
      const [all, allowed, sups] = await Promise.all([
        searchCustomers(''),
        getAllowedWarehouses(),
        listSuppliers().catch(() => [] as Supplier[]),
      ]);
      const ws = allowed.warehouses;
      setList(all.filter((c) => c.debt > 0));
      setSuppliers(sups.filter((s) => s.debt > 0).sort((a, b) => b.debt - a.debt));
      setWarehouses(ws);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tải được sổ nợ');
    } finally {
      setBusy(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const needle = unsignVietnamese(q.trim()).toLowerCase();
  const whList = whFilter === 'all' ? list : list.filter((c) => !c.warehouse_id || c.warehouse_id === whFilter);
  const filtered = needle
    ? whList.filter((c) => unsignVietnamese(`${c.name} ${c.phone}`).toLowerCase().includes(needle))
    : whList;
  const total = whList.reduce((s, c) => s + c.debt, 0);
  const supFiltered = needle
    ? suppliers.filter((s) => unsignVietnamese(`${s.name} ${s.phone}`).toLowerCase().includes(needle))
    : suppliers;
  const totalPayable = suppliers.reduce((s, x) => s + x.debt, 0);

  // ---- Nhanh PC (chi them, khong dung toi JSX mobile phia duoi) ----
  // Sap xep ban PC theo cong no giam dan nhu demo; ban mobile giu nguyen thu tu cu.
  const pcCustomers = [...filtered].sort((a, b) => b.debt - a.debt);
  const pcSuppliers = [...supFiltered].sort((a, b) => b.debt - a.debt);
  const pcRows = tab === 'receivable' ? pcCustomers : pcSuppliers;
  const pcSelectedCustomer = tab === 'receivable'
    ? (pcCustomers.find((c) => c.id === selectedId) ?? pcCustomers[0] ?? null)
    : null;
  const pcSelectedSupplier = tab === 'payable'
    ? (pcSuppliers.find((s) => s.id === selectedId) ?? pcSuppliers[0] ?? null)
    : null;
  const warehouseName = (id: string | null) =>
    warehouses.find((w) => w.id === id)?.name ?? '';

  // Loc kho dung chung 2 nhanh: listbox gon thay hang chip (gia tri y nhu cu).
  const warehouseSelect = (
    <select
      className="v6demo-input v6demo-debt-whselect"
      value={whFilter}
      onChange={(e) => setWhFilter(e.target.value)}
      aria-label="Lọc theo kho"
    >
      <option value="all">Mọi kho</option>
      {warehouses.map((w) => (
        <option key={w.id} value={w.id}>{w.name}</option>
      ))}
    </select>
  );

  if (isPC) {
    return (
      <div className="pc-debt-page v6demo-debt v6demo-page">
        <div className="v6demo-aurora" aria-hidden />
        <div className="v6demo-content">
          <div className="v6demo-page-head v6demo-rise">
            <div className="v6demo-debt-head-row">
              <div className="v6demo-debt-head-text">
                <h1>Sổ nợ</h1>
                <p>Theo dõi tiền khách nợ quán và tiền quán nợ nhà cung cấp, thu nợ và ghi nợ mới ngay tại quầy.</p>
              </div>
              <button className="btn btn-outline pc-debt-refresh v6demo-btn v6demo-btn-ghost v6demo-btn-sm" type="button" onClick={() => void load()} disabled={busy}>
                <LineIcon name="refresh" size={18} />
                <span>{busy ? 'Đang tải...' : 'Tải lại'}</span>
              </button>
            </div>
          </div>

          {/* 4 the tong: phai thu / phai tra / chenh lech / so khach dang no */}
          <div className="v6demo-debt-stats v6demo-rise-1">
            <div className="v6demo-glass v6demo-debt-stat">
              <span className="v6demo-debt-stat-ico"><LineIcon name="wallet" size={20} /></span>
              <div className="v6demo-debt-stat-label">Tổng phải thu</div>
              <div className="v6demo-debt-stat-value v6demo-debt-amber">{formatVND(total)}</div>
              <div className="v6demo-debt-stat-sub">Tiền khách đang nợ quán</div>
            </div>
            <div className="v6demo-glass v6demo-debt-stat">
              <span className="v6demo-debt-stat-ico"><LineIcon name="truck" size={20} /></span>
              <div className="v6demo-debt-stat-label">Tổng phải trả</div>
              <div className="v6demo-debt-stat-value v6demo-negative">{formatVND(totalPayable)}</div>
              <div className="v6demo-debt-stat-sub">Tiền quán nợ nhà cung cấp</div>
            </div>
            <div className="v6demo-glass v6demo-debt-stat">
              <span className="v6demo-debt-stat-ico"><LineIcon name="chart" size={20} /></span>
              <div className="v6demo-debt-stat-label">Chênh lệch</div>
              <div className="v6demo-debt-stat-value" style={{ color: total - totalPayable >= 0 ? 'var(--vd-green-700)' : 'var(--vd-red)' }}>
                {formatVND(total - totalPayable)}
              </div>
              <div className="v6demo-debt-stat-sub">Phải thu trừ phải trả</div>
            </div>
            <div className="v6demo-glass v6demo-debt-stat">
              <span className="v6demo-debt-stat-ico"><LineIcon name="users" size={20} /></span>
              <div className="v6demo-debt-stat-label">Số khách đang nợ</div>
              <div className="v6demo-debt-stat-value">{whList.length} khách</div>
              <div className="v6demo-debt-stat-sub">Chỉ tính khách còn nợ trên 0đ</div>
            </div>
          </div>

          <div className="v6demo-debt-dock v6demo-glass v6demo-rise-2">
            <div className="v6demo-seg" role="tablist" aria-label="Loại công nợ">
              <button
                type="button"
                className={tab === 'receivable' ? 'active' : ''}
                onClick={() => setTab('receivable')}
              >
                Phải thu ({list.length})
              </button>
              <button
                type="button"
                className={tab === 'payable' ? 'active' : ''}
                onClick={() => setTab('payable')}
              >
                Phải trả ({suppliers.length})
              </button>
            </div>
            <label className="v6demo-search">
              <LineIcon name="search" size={18} />
              <input
                placeholder="Tìm khách theo tên hoặc SĐT..."
                value={q}
                onChange={(e) => setQ(e.target.value)}
                aria-label="Tìm khách theo tên hoặc SĐT"
              />
            </label>
            {tab === 'receivable' && warehouses.length > 1 && warehouseSelect}
          </div>

          <div className="pc-debt-layout v6demo-rise-3">
            <section className="pc-debt-card pc-debt-table-card">
              <div className="pc-debt-card-head">
                <h3>{tab === 'receivable' ? 'Khách đang nợ' : 'Nhà cung cấp đang chờ thanh toán'}</h3>
                <span className="muted small">{pcRows.length} {tab === 'receivable' ? 'khách' : 'nhà cung cấp'} - sắp xếp theo công nợ giảm dần</span>
              </div>
              {busy ? (
                <p className="muted pc-debt-empty">Đang tải...</p>
              ) : pcRows.length === 0 ? (
                <p className="muted pc-debt-empty">
                  {tab === 'receivable' ? 'Chưa có khoản nợ nào.' : 'Không nợ nhà cung cấp nào.'}
                </p>
              ) : (
                <div className="pc-debt-table-wrap">
                  <table className="pc-debt-table">
                    <thead>
                      <tr>
                        <th>{tab === 'receivable' ? 'Khách hàng' : 'Nhà cung cấp'}</th>
                        <th>SĐT</th>
                        <th className="pc-debt-r">Công nợ</th>
                        <th>Ghi chú</th>
                        <th>Thao tác</th>
                      </tr>
                    </thead>
                    <tbody>
                      {pcRows.map((row) => {
                        const isSelected = tab === 'receivable'
                          ? pcSelectedCustomer?.id === row.id
                          : pcSelectedSupplier?.id === row.id;
                        const note = (row as Customer).note ?? (row as Supplier).note ?? '';
                        return (
                          <tr
                            key={row.id}
                            className={isSelected ? 'pc-debt-row-selected' : ''}
                            onClick={() => setSelectedId(row.id)}
                          >
                            <td>
                              <span className="pc-debt-cust">
                                <span className="pc-debt-avatar">{row.name.charAt(0).toUpperCase()}</span>
                                <span className="pc-debt-cust-text">
                                  <b title={row.name}>{row.name}</b>
                                  {tab === 'receivable' && (
                                    <span className="pc-debt-tag">{tierLabel((row as Customer).tier)}</span>
                                  )}
                                </span>
                              </span>
                            </td>
                            <td className="pc-debt-nowrap">{row.phone || 'Chưa có SĐT'}</td>
                            <td className="pc-debt-r pc-debt-money pc-debt-red">{formatVND(row.debt)}</td>
                            <td className="pc-debt-note" title={note || undefined}>{note || '—'}</td>
                            <td>
                              <button
                                type="button"
                                className="pc-debt-view"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setSelectedId(row.id);
                                }}
                              >
                                <LineIcon name="eye" size={18} />
                                <span>Xem chi tiết</span>
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
              <div className="pc-debt-pager">
                <span>Hiển thị {pcRows.length} trên {pcRows.length} {tab === 'receivable' ? 'khách đang nợ' : 'nhà cung cấp'}</span>
              </div>
            </section>

            <aside className="pc-debt-card pc-debt-detail">
              {tab === 'receivable' ? (
                pcSelectedCustomer ? (
                  <>
                    <div className="pc-debt-detail-head">
                      <span className="pc-debt-avatar pc-debt-avatar-lg">{pcSelectedCustomer.name.charAt(0).toUpperCase()}</span>
                      <div className="pc-debt-detail-head-text">
                        <b title={pcSelectedCustomer.name}>{pcSelectedCustomer.name}</b>
                        <div>
                          <span className="pc-debt-tag">{tierLabel(pcSelectedCustomer.tier)}</span>
                          <span className="muted small"> Đang chọn</span>
                        </div>
                      </div>
                    </div>
                    <div className="pc-debt-contact">
                      <div className="pc-debt-rowline"><span className="muted">SĐT</span><span className="pc-debt-nowrap">{pcSelectedCustomer.phone || 'Chưa có SĐT'}</span></div>
                      {pcSelectedCustomer.address && (
                        <div className="pc-debt-rowline"><span className="muted">Địa chỉ</span><span title={pcSelectedCustomer.address}>{pcSelectedCustomer.address}</span></div>
                      )}
                      {pcSelectedCustomer.warehouse_id && warehouseName(pcSelectedCustomer.warehouse_id) && (
                        <div className="pc-debt-rowline"><span className="muted">Kho</span><span>{warehouseName(pcSelectedCustomer.warehouse_id)}</span></div>
                      )}
                      <div className="pc-debt-rowline"><span className="muted">Điểm tích lũy</span><span>{pcSelectedCustomer.points} điểm</span></div>
                      {pcSelectedCustomer.note && (
                        <div className="pc-debt-rowline"><span className="muted">Ghi chú</span><span title={pcSelectedCustomer.note}>{pcSelectedCustomer.note}</span></div>
                      )}
                    </div>
                    <div className="pc-debt-detail-total">
                      <div className="pc-debt-detail-total-label">Tổng công nợ</div>
                      <div className="pc-debt-detail-total-value">{formatVND(pcSelectedCustomer.debt)}</div>
                      <div className="muted small">Khách còn nợ quán</div>
                    </div>
                    <h3 className="pc-debt-detail-title">Lịch sử công nợ</h3>
                    <PcDebtHistory customerId={pcSelectedCustomer.id} />
                    <div className="pc-debt-detail-actions">
                      <button
                        type="button"
                        className="btn btn-block v6demo-btn v6demo-btn-primary"
                        onClick={() => (canDebt ? (setSheetCustomer(pcSelectedCustomer), setSheet('receive')) : toast.show('Chỉ Thu ngân trở lên mới được thu nợ'))}
                      >
                        <LineIcon name="wallet" size={18} />
                        <span>Thu nợ</span>
                      </button>
                      <button
                        type="button"
                        className="btn btn-outline btn-block v6demo-btn v6demo-btn-ghost"
                        onClick={() => (canDebt ? (setSheetCustomer(pcSelectedCustomer), setSheet('give')) : toast.show('Chỉ Thu ngân trở lên mới được ghi nợ'))}
                      >
                        <LineIcon name="plus" size={18} />
                        <span>Ghi nợ mới</span>
                      </button>
                      <button type="button" className="btn btn-ghost btn-block v6demo-btn v6demo-btn-ghost" onClick={() => navigate('/customers')}>
                        <LineIcon name="users" size={18} />
                        <span>Xem chi tiết đầy đủ</span>
                      </button>
                    </div>
                    <p className="muted small pc-debt-detail-note">Thu nợ sẽ trừ công nợ và ghi vào Sổ quỹ. Ghi nợ mới chỉ tăng công nợ, chưa thu tiền. Sheet mở ra với khách đang chọn sẵn (bấm Đổi để chọn khách khác).</p>
                  </>
                ) : (
                  <p className="muted pc-debt-empty">Chưa có khách nợ nào để hiển thị.</p>
                )
              ) : (
                pcSelectedSupplier ? (
                  <>
                    <div className="pc-debt-detail-head">
                      <span className="pc-debt-avatar pc-debt-avatar-lg">{pcSelectedSupplier.name.charAt(0).toUpperCase()}</span>
                      <div className="pc-debt-detail-head-text">
                        <b title={pcSelectedSupplier.name}>{pcSelectedSupplier.name}</b>
                        <div><span className="muted small">Đang chọn</span></div>
                      </div>
                    </div>
                    <div className="pc-debt-contact">
                      <div className="pc-debt-rowline"><span className="muted">SĐT</span><span className="pc-debt-nowrap">{pcSelectedSupplier.phone || 'Chưa có SĐT'}</span></div>
                      {pcSelectedSupplier.address && (
                        <div className="pc-debt-rowline"><span className="muted">Địa chỉ</span><span title={pcSelectedSupplier.address}>{pcSelectedSupplier.address}</span></div>
                      )}
                      {pcSelectedSupplier.note && (
                        <div className="pc-debt-rowline"><span className="muted">Ghi chú</span><span title={pcSelectedSupplier.note}>{pcSelectedSupplier.note}</span></div>
                      )}
                    </div>
                    <div className="pc-debt-detail-total">
                      <div className="pc-debt-detail-total-label">Tổng công nợ phải trả</div>
                      <div className="pc-debt-detail-total-value">{formatVND(pcSelectedSupplier.debt)}</div>
                      <div className="muted small">Quán còn nợ nhà cung cấp</div>
                    </div>
                    <div className="pc-debt-detail-actions">
                      <button type="button" className="btn btn-block v6demo-btn v6demo-btn-primary" onClick={() => navigate('/nhap-hang')}>
                        <LineIcon name="truck" size={18} />
                        <span>Sang trang Nhập hàng</span>
                      </button>
                    </div>
                    <p className="muted small pc-debt-detail-note">Bấm vào nhà cung cấp để sang trang Nhập hàng - trả nợ tại đó sẽ ghi vào Sổ quỹ (dùng cơ chế như bản mobile).</p>
                  </>
                ) : (
                  <p className="muted pc-debt-empty">Không nợ nhà cung cấp nào.</p>
                )
              )}
            </aside>
          </div>
        </div>

        {sheet && (
          <DebtSheet
            mode={sheet}
            initialCustomer={sheetCustomer}
            onClose={() => { setSheet(null); setSheetCustomer(null); }}
            onDone={() => {
              setSheet(null);
              setSheetCustomer(null);
              void load();
            }}
          />
        )}
      </div>
    );
  }

  return (
    <div className="page with-dual-actions v6demo-debt v6demo-page">
      <div className="v6demo-aurora" aria-hidden />
      <div className="v6demo-content">
        <PageHead title="Công nợ" back />

        {/* Hero: tong cong no cua tab dang xem */}
        <div className="v6demo-debt-hero v6demo-rise">
          <div className="v6demo-debt-hero-top">
            <div className="v6demo-debt-hero-main">
              <div className="v6demo-debt-hero-label">
                {tab === 'receivable' ? 'Tổng công nợ cần thu' : 'Tổng công nợ phải trả NCC'}
              </div>
              <div className="v6demo-debt-hero-total">
                {formatVND(tab === 'receivable' ? total : totalPayable)}
              </div>
              <div className="v6demo-debt-hero-sub">
                {tab === 'receivable'
                  ? `${list.length} khách đang nợ`
                  : `${suppliers.length} nhà cung cấp đang chờ thanh toán`}
              </div>
            </div>
            <span className="v6demo-debt-hero-ico">
              <LineIcon name={tab === 'receivable' ? 'ledger' : 'archive'} size={26} />
            </span>
          </div>
        </div>

        {/* 4 the tong: phai thu / phai tra / chenh lech / so khach dang no */}
        <div className="v6demo-debt-stats v6demo-debt-stats-mobile v6demo-rise-1">
          <div className="v6demo-glass v6demo-debt-stat">
            <div className="v6demo-debt-stat-label">Phải thu</div>
            <div className="v6demo-debt-stat-value v6demo-debt-amber">{formatVND(total)}</div>
            <div className="v6demo-debt-stat-sub">Khách nợ quán</div>
          </div>
          <div className="v6demo-glass v6demo-debt-stat">
            <div className="v6demo-debt-stat-label">Phải trả</div>
            <div className="v6demo-debt-stat-value v6demo-negative">{formatVND(totalPayable)}</div>
            <div className="v6demo-debt-stat-sub">Quán nợ NCC</div>
          </div>
          <div className="v6demo-glass v6demo-debt-stat">
            <div className="v6demo-debt-stat-label">Chênh lệch</div>
            <div className="v6demo-debt-stat-value" style={{ color: total - totalPayable >= 0 ? 'var(--vd-green-700)' : 'var(--vd-red)' }}>
              {formatVND(total - totalPayable)}
            </div>
            <div className="v6demo-debt-stat-sub">Phải thu trừ phải trả</div>
          </div>
          <div className="v6demo-glass v6demo-debt-stat">
            <div className="v6demo-debt-stat-label">Số khách đang nợ</div>
            <div className="v6demo-debt-stat-value">{whList.length} khách</div>
            <div className="v6demo-debt-stat-sub">Chỉ tính khách còn nợ trên 0đ</div>
          </div>
        </div>

        {/* Dock loc duy nhat: tim kiem + 2 tab + loc kho dang listbox */}
        <div className="v6demo-debt-dock v6demo-glass v6demo-rise-2">
          <label className="v6demo-search">
            <LineIcon name="search" size={18} />
            <input
              placeholder="Tìm tên, số điện thoại…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              aria-label="Tìm khách nợ"
            />
          </label>
          <div className="v6demo-seg" role="tablist" aria-label="Loại công nợ">
            <button
              type="button"
              className={tab === 'receivable' ? 'active' : ''}
              onClick={() => setTab('receivable')}
            >
              Khách nợ quán ({list.length})
            </button>
            <button
              type="button"
              className={tab === 'payable' ? 'active' : ''}
              onClick={() => setTab('payable')}
            >
              Quán nợ NCC ({suppliers.length})
            </button>
          </div>
          {tab === 'receivable' && warehouses.length > 1 && warehouseSelect}
        </div>

        {/* Danh sach so cai: 1 cot, sap xep nhu cu (mobile giu nguyen thu tu cu) */}
        <div className="v6demo-debt-ledger v6demo-glass v6demo-rise-3" key={tab}>
          <div className="v6demo-debt-ledger-head">
            <h2>{tab === 'receivable' ? 'Khách đang nợ' : 'Nhà cung cấp đang chờ thanh toán'}</h2>
            <span>{tab === 'receivable' ? filtered.length : supFiltered.length} khoản nợ</span>
          </div>
          {tab === 'receivable' ? (
            busy ? (
              <p className="v6demo-debt-empty">Đang tải…</p>
            ) : filtered.length === 0 ? (
              <div className="v6demo-debt-empty">
                <span className="v6demo-debt-empty-ico"><LineIcon name="ledger" size={28} /></span>
                <p>
                  Chưa có khoản nợ nào.
                  <br />
                  Ghi chép rõ ràng, thu hồi dễ dàng.
                </p>
              </div>
            ) : (
              filtered.map((c) => (
                <button key={c.id} className="v6demo-debt-row" onClick={() => navigate('/customers')}>
                  <span className="v6demo-debt-avatar">{c.name.charAt(0).toUpperCase()}</span>
                  <span className="v6demo-debt-row-main">
                    <b>{c.name}</b>
                    <span>{c.phone}</span>
                  </span>
                  <span className="v6demo-debt-row-right">
                    <span className="v6demo-debt-amount v6demo-debt-amber">{formatVND(c.debt)}</span>
                    <span className="v6demo-debt-chev" aria-hidden>›</span>
                  </span>
                </button>
              ))
            )
          ) : (
            busy ? (
              <p className="v6demo-debt-empty">Đang tải…</p>
            ) : supFiltered.length === 0 ? (
              <div className="v6demo-debt-empty">
                <span className="v6demo-debt-empty-ico"><LineIcon name="archive" size={28} /></span>
                <p>
                  Không nợ nhà cung cấp nào.
                  <br />
                  Thanh toán sòng phẳng, nhập hàng dễ dàng.
                </p>
              </div>
            ) : (
              supFiltered.map((s) => (
                <button key={s.id} className="v6demo-debt-row" onClick={() => navigate('/nhap-hang')}>
                  <span className="v6demo-debt-avatar">{s.name.charAt(0).toUpperCase()}</span>
                  <span className="v6demo-debt-row-main">
                    <b>{s.name}</b>
                    <span>{s.phone || 'Chưa có SĐT'}</span>
                  </span>
                  <span className="v6demo-debt-row-right">
                    <span className="v6demo-debt-amount v6demo-negative">{formatVND(s.debt)}</span>
                    <span className="v6demo-debt-chev" aria-hidden>›</span>
                  </span>
                </button>
              ))
            )
          )}
        </div>
        {tab === 'payable' && (
          <p className="v6demo-debt-note">
            Bấm vào nhà cung cấp để sang trang Nhập hàng — trả nợ tại đó sẽ ghi vào Sổ quỹ.
          </p>
        )}
      </div>

      {tab === 'receivable' && (
        <div className="sb-dual-actions">
          <div className="inner">
            <button
              className="btn btn-block btn-lg v6demo-btn v6demo-btn-dark"
              onClick={() => (canDebt ? setSheet('give') : toast.show('Chỉ Thu ngân trở lên mới được ghi nợ'))}
            >
              Tôi đã đưa
            </button>
            <button
              className="btn btn-block btn-lg v6demo-btn v6demo-btn-primary"
              onClick={() => (canDebt ? setSheet('receive') : toast.show('Chỉ Thu ngân trở lên mới được thu nợ'))}
            >
              Tôi đã nhận
            </button>
          </div>
        </div>
      )}

      {sheet && (
        <DebtSheet
          mode={sheet}
          initialCustomer={sheetCustomer}
          onClose={() => { setSheet(null); setSheetCustomer(null); }}
          onDone={() => {
            setSheet(null);
            setSheetCustomer(null);
            void load();
          }}
        />
      )}
    </div>
  );
}

/** Lịch sử công nợ that cua khach dang chon (chi dung o panel PC, dung loader listDebtLogs san co nhu trang Khách hàng). */
function PcDebtHistory({ customerId }: { customerId: string }) {
  const [logs, setLogs] = useState<DebtLog[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    let alive = true;
    setLoading(true);
    listDebtLogs(customerId)
      .then((r) => { if (alive) setLogs(r); })
      .catch(() => { if (alive) setLogs([]); })
      .finally(() => { if (alive) setLoading(false); });
    return () => { alive = false; };
  }, [customerId]);
  if (loading) return <p className="muted small">Đang tải lịch sử...</p>;
  if (logs.length === 0) return <p className="muted small">Chưa có lịch sử công nợ ghi nhận.</p>;
  return (
    <div className="v6demo-debt-history">
      {logs.map((l) => (
        <div key={l.id} className="v6demo-debt-hist-row">
          <div className="v6demo-debt-hist-text">
            <b title={l.note ?? undefined}>{l.note || (l.amount > 0 ? 'Ghi nợ' : 'Thu nợ')}</b>
            <div className="muted small">{formatDMY(l.created_at.slice(0, 10))}</div>
          </div>
          <span className={l.amount > 0 ? 'v6demo-debt-plus' : 'v6demo-debt-minus'}>
            {l.amount > 0 ? '+' : ''}{formatVND(l.amount)}
          </span>
        </div>
      ))}
    </div>
  );
}

function DebtSheet({
  mode,
  initialCustomer,
  onClose,
  onDone,
}: {
  mode: 'give' | 'receive';
  /** Khách chọn sẵn (panel PC truyền vào); không truyền thì mở ra ở ô tìm như cũ. */
  initialCustomer?: Customer | null;
  onClose: () => void;
  onDone: () => void;
}) {
  const toast = useToast();
  const [q, setQ] = useState('');
  const [results, setResults] = useState<Customer[]>([]);
  const [searched, setSearched] = useState(false);
  const [selected, setSelected] = useState<Customer | null>(initialCustomer ?? null);
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [funds, setFunds] = useState<Fund[]>([]);
  const [fundId, setFundId] = useState('cash');
  const [occurredAt, setOccurredAt] = useState(() => toLocalDateTimeInput());
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    // Thu nợ = tiền về quỹ → cần chọn quỹ nhận (chỉ ở chế độ "Tôi đã nhận")
    if (mode !== 'receive') return;
    getFunds()
      .then((fl) => {
        const act = fl.filter((f) => f.active);
        setFunds(act);
        if (!act.some((f) => f.id === fundId) && act[0]) setFundId(act[0].id);
      })
      .catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode]);

  const doSearch = async () => {
    setBusy(true);
    try {
      const r = await searchCustomers(q.trim());
      setResults(r);
      setSearched(true);
      if (r.length === 0) toast.show('Không tìm thấy khách hàng');
    } catch {
      toast.show('Không tìm được, kiểm tra mạng');
    } finally {
      setBusy(false);
    }
  };

  const submit = async () => {
    if (!selected) {
      toast.show('Hãy chọn khách hàng trước');
      return;
    }
    const v = parseInt(amount.replace(/\D/g, ''), 10);
    if (!v || v <= 0) {
      toast.show('Nhập số tiền hợp lệ');
      return;
    }
    setBusy(true);
    try {
      const finalNote = note.trim() || (mode === 'receive' ? `Thu nợ — ${selected.name}` : null);
      if (mode === 'receive') {
        // Thu nợ: trừ công nợ + ghi quỹ trong 1 transaction (không bao giờ lệch nhau)
        await collectCustomerDebt(selected.id, v, {
          note: finalNote,
          fundId,
          method: funds.find((f) => f.id === fundId)?.kind === 'transfer' ? 'transfer' : 'cash',
          warehouseId: selected.warehouse_id ?? null,
          occurredAt: occurredAt ? new Date(occurredAt).toISOString() : null,
        });
      } else {
        // Ghi nợ thêm: chỉ tăng công nợ (chưa thu tiền nên không ghi quỹ)
        await adjustDebt(selected.id, v, finalNote);
      }
      toast.show(
        mode === 'give'
          ? `Đã ghi nợ ${formatVND(v)} cho ${selected.name}`
          : `Đã thu ${formatVND(v)} của ${selected.name}`,
      );
      onDone();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet
      title={mode === 'give' ? 'Tôi đã đưa (ghi nợ)' : 'Tôi đã nhận (thu nợ)'}
      onClose={onClose}
      footer={
        <button
          className="v6demo-btn v6demo-btn-primary v6demo-btn-block"
          disabled={busy}
          onClick={submit}
        >
          {busy ? 'Đang lưu…' : 'Xác nhận'}
        </button>
      }
    >
      <div className="v6demo-debt-sheet">
        {!selected ? (
          <>
            <div className="v6demo-debt-sheet-search">
              <label className="v6demo-search">
                <LineIcon name="search" size={18} />
                <input
                  placeholder="Nhập tên hoặc SĐT…"
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && doSearch()}
                />
              </label>
              <button className="v6demo-btn v6demo-btn-dark v6demo-btn-sm v6demo-debt-sheet-find" onClick={doSearch} disabled={busy}>
                Tìm
              </button>
            </div>
            {results.map((c) => (
              <button key={c.id} className="v6demo-debt-row" onClick={() => setSelected(c)}>
                <span className="v6demo-debt-avatar">{c.name.charAt(0).toUpperCase()}</span>
                <span className="v6demo-debt-row-main">
                  <b>{c.name}</b>
                  <span>{c.phone}</span>
                </span>
                <span className="v6demo-debt-row-right">
                  <span className={`v6demo-debt-amount ${c.debt > 0 ? 'v6demo-debt-amber' : ''}`}>
                    {c.debt > 0 ? formatVND(c.debt) : <span className="v6demo-muted">—</span>}
                  </span>
                </span>
              </button>
            ))}
            {searched && results.length === 0 && (
              <p className="v6demo-muted v6demo-small" style={{ textAlign: 'center' }}>
                Không tìm thấy khách hàng
              </p>
            )}
          </>
        ) : (
          <>
            <button className="v6demo-debt-row v6demo-debt-row-picked" onClick={() => setSelected(null)} aria-label="Đổi khách hàng">
              <span className="v6demo-debt-avatar">{selected.name.charAt(0).toUpperCase()}</span>
              <span className="v6demo-debt-row-main">
                <b>{selected.name}</b>
                <span>
                  {selected.phone} · đang nợ {formatVND(selected.debt)}
                </span>
              </span>
              <span className="v6demo-debt-change">Đổi ›</span>
            </button>
            <div className="v6demo-debt-field">
              <label>Số tiền</label>
              <input
                className="v6demo-input v6demo-debt-money"
                inputMode="numeric"
                placeholder="0"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                autoFocus
              />
            </div>
            <div className="v6demo-debt-field">
              <label>Ghi chú (không bắt buộc)</label>
              <input
                className="v6demo-input"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="VD: tiền nước tuần này…"
              />
            </div>
            <div className="v6demo-debt-field">
              <label><LineIcon name="clock" size={16} /> Thời gian</label>
              <input
                type="datetime-local"
                className="v6demo-input"
                value={occurredAt}
                onChange={(e) => setOccurredAt(e.target.value)}
              />
            </div>
            {mode === 'receive' && funds.length > 1 && (
              <div className="v6demo-debt-field">
                <label>Tiền vào quỹ</label>
                <div className="v6demo-debt-funds">
                  {funds.map((f) => (
                    <button
                      key={f.id}
                      type="button"
                      className={`v6demo-chip${fundId === f.id ? ' active' : ''}`}
                      onClick={() => setFundId(f.id)}
                    >
                      {f.name}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </Sheet>
  );
}
