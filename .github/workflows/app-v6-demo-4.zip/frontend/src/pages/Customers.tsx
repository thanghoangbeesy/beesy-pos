import { useEffect, useState } from 'react';
import type { FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  DbError,
  adjustDebt,
  collectCustomerDebt,
  createCustomer,
  getCustomer,
  getFunds,
  getSettings,
  listDebtLogs,
  redeemReward,
  getAllowedWarehouses,
  searchCustomers,
  updateCustomer,
} from '../lib/db';
import { formatDateTime, formatVND } from '../lib/format';
import { Sheet } from '../components/Sheet';
import { useToast } from '../components/Toast';
import { LineIcon } from '../components/LineIcon';
import './pc-customers.css';
import './v6demo-theme.css';
import './v6demo-customers.css';
import type { Customer, DebtLog, Fund, Warehouse } from '../lib/types';

function zaloPhone(phone: string): string {
  const d = phone.replace(/\D/g, '');
  if (d.startsWith('84')) return d;
  if (d.startsWith('0')) return d;
  return d;
}

function upcomingBirthdays(list: Customer[]): { c: Customer; inDays: number; dateLabel: string }[] {
  const now = new Date();
  const out: { c: Customer; inDays: number; dateLabel: string }[] = [];
  for (const c of list) {
    if (!c.birthday || !/^\d{4}-\d{2}-\d{2}$/.test(c.birthday)) continue;
    const [, m, d] = c.birthday.split('-').map(Number);
    const thisYear = new Date(now.getFullYear(), m - 1, d);
    let next = thisYear;
    if (thisYear.getTime() < new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime()) {
      next = new Date(now.getFullYear() + 1, m - 1, d);
    }
    const inDays = Math.round((next.getTime() - new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime()) / 86400000);
    if (inDays <= 30) {
      out.push({
        c,
        inDays,
        dateLabel: `${String(d).padStart(2, '0')}/${String(m).padStart(2, '0')}`,
      });
    }
  }
  return out.sort((a, b) => a.inDays - b.inDays);
}

function BirthdayZaloTab({ list, shopName }: { list: Customer[]; shopName: string }) {
  const [copied, setCopied] = useState<string | null>(null);

  const upcoming = upcomingBirthdays(list);

  const copyMsg = async (key: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(key);
      setTimeout(() => setCopied(null), 2000);
    } catch {
      /* bo qua */
    }
  };

  const openChat = (c: Customer, msg: string) => {
    void copyMsg(`z_${c.id}`, msg);
    if (c.phone) window.open(`https://zalo.me/${zaloPhone(c.phone)}`, '_blank');
  };

  const templates: { key: string; title: string; icon: string; text: (name: string) => string }[] = [
    {
      key: 'birthday',
      title: 'Chúc mừng sinh nhật',
      icon: 'gift',
      text: (name) =>
        `Chúc mừng sinh nhật ${name}! 🎂 ${shopName} tặng bạn voucher giảm 20% nhân dịp đặc biệt này. Ghé quán nhé!`,
    },
    {
      key: 'promo',
      title: 'Khuyến mãi chung',
      icon: 'tag',
      text: (name) =>
        `Chào ${name}! ${shopName} đang có ưu đãi mới, ghé quán thưởng thức nhé. Cảm ơn bạn đã ủng hộ!`,
    },
    {
      key: 'gold',
      title: 'Tri ân hạng Vàng',
      icon: 'star',
      text: (name) =>
        `Chào ${name}! Cảm ơn bạn đã là khách hàng Vàng của ${shopName}. Tuần này bạn được giảm thêm 5% mọi hóa đơn đấy!`,
    },
  ];

  return (
    <div className="v6demo-cust-bz">
      <div className="v6demo-glass v6demo-glass-sm v6demo-cust-bz-card v6demo-rise">
        <div className="v6demo-cust-bz-title">
          <LineIcon name="gift" size={18} /> Sinh nhật trong 30 ngày tới ({upcoming.length})
        </div>
        {upcoming.length === 0 ? (
          <p className="v6demo-cust-hint" style={{ margin: 0 }}>
            Không có sinh nhật nào sắp tới.
          </p>
        ) : (
          upcoming.map(({ c, inDays, dateLabel }) => {
            const msg = templates[0].text(c.name);
            return (
              <div key={c.id} className="v6demo-cust-bz-item">
                <div className="v6demo-cust-bz-row">
                  <div className="v6demo-cust-bz-name">
                    {c.name} <span className="v6demo-cust-bz-date">{dateLabel}</span>
                  </div>
                  <span className={`v6demo-badge${inDays === 0 ? ' warn' : ''}`}>
                    {inDays === 0 ? 'Hôm nay!' : `còn ${inDays} ngày`}
                  </span>
                </div>
                <div className="v6demo-cust-bz-acts">
                  <button type="button" className="v6demo-btn v6demo-btn-primary v6demo-btn-sm" onClick={() => openChat(c, msg)}>
                    <LineIcon name="chat" size={16} /> Nhắn Zalo
                  </button>
                  <button type="button" className="v6demo-btn v6demo-btn-ghost v6demo-btn-sm" onClick={() => void copyMsg(`b_${c.id}`, msg)}>
                    {copied === `b_${c.id}` ? (
                      <><LineIcon name="check" size={16} /> Đã chép</>
                    ) : (
                      <><LineIcon name="clipboard" size={16} /> Chép lời chúc</>
                    )}
                  </button>
                </div>
                <p className="v6demo-cust-hint">
                  Bấm "Nhắn Zalo" sẽ tự chép tin + mở chat - bạn chỉ cần dán và gửi.
                </p>
              </div>
            );
          })
        )}
      </div>

      <div className="v6demo-glass v6demo-glass-sm v6demo-cust-bz-card">
        <div className="v6demo-cust-bz-title">
          <LineIcon name="chat" size={18} /> Mẫu tin nhắn
        </div>
        {templates.map((t) => (
          <div key={t.key} className="v6demo-cust-bz-item">
            <div className="v6demo-cust-bz-tpl">
              <LineIcon name={t.icon} size={18} /> {t.title}
            </div>
            <p className="v6demo-cust-hint" style={{ margin: '0 0 8px' }}>
              {t.text('{Tên khách}')}
            </p>
            <button type="button" className="v6demo-btn v6demo-btn-ghost v6demo-btn-sm" onClick={() => void copyMsg(t.key, t.text('{Tên khách}'))}>
              {copied === t.key ? (
                <><LineIcon name="check" size={16} /> Đã chép</>
              ) : (
                <><LineIcon name="clipboard" size={16} /> Chép mẫu</>
              )}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

/** Hook phát hiện màn hình PC (>= 1024px), theo mẫu pages/Reports.tsx. */
function useIsPC(): boolean {
  const [isPC, setIsPC] = useState(() => typeof window !== 'undefined' && window.innerWidth >= 1024);
  useEffect(() => {
    const onResize = () => setIsPC(window.innerWidth >= 1024);
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);
  return isPC;
}

/** Nhãn hạng: chữ thường, không dùng emoji của TIER_LABEL. */
function pcTierLabel(tier: Customer['tier'] | undefined): string {
  if (tier === 'gold') return 'Vàng';
  if (tier === 'silver') return 'Bạc';
  return 'Thành viên';
}

function pcBirthdayLabel(birthday: string | null): string {
  if (!birthday || !/^\d{4}-\d{2}-\d{2}$/.test(birthday)) return '—';
  const [y, m, d] = birthday.split('-');
  return `${d}/${m}/${y}`;
}

/**
 * Khối tem + đổi thưởng cho panel PC. Logic giống CustomerDetail.redeem
 * (đòi hỏi khách có đơn, xác nhận, gọi redeemReward rồi tải lại khách).
 */
function PcRewardBlock({ customer, stampsTarget, onChanged }: {
  customer: Customer;
  stampsTarget: number;
  onChanged: (c: Customer) => void;
}) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const redeem = async () => {
    const lastOrder = customer.recent_orders?.[0];
    if (!lastOrder) {
      toast.show('Khách chưa có đơn nào để đổi thưởng');
      return;
    }
    if (!window.confirm(`Đổi thưởng cho ${customer.name}? (mua ${stampsTarget} tặng 1)`)) return;
    setBusy(true);
    try {
      await redeemReward(customer.id);
      toast.show('Đã đổi thưởng thành công!');
      const c = await getCustomer(customer.id);
      if (c) onChanged(c);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Đổi thưởng thất bại');
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="v6demo-cust-block">
      <div className="v6demo-cust-block-title">Tích tem ({customer.stamps}/{stampsTarget})</div>
      <div className="v6demo-cust-stamps" aria-label={`Đã tích ${customer.stamps} trên ${stampsTarget} tem`}>
        {Array.from({ length: stampsTarget }).map((_, i) => (
          <span key={i} className={`v6demo-cust-stamp${i < customer.stamps ? ' on' : ''}`} title={i < customer.stamps ? 'Đã tích' : 'Chưa tích'}>
            {i + 1}
          </span>
        ))}
      </div>
      {customer.reward_available ? (
        <button type="button" className="v6demo-btn v6demo-btn-primary v6demo-btn-block" disabled={busy} onClick={redeem}>
          <LineIcon name="gift" size={18} /> Đổi thưởng (mua {stampsTarget} tặng 1)
        </button>
      ) : (
        <p className="v6demo-cust-hint">Còn {stampsTarget - customer.stamps} tem nữa để nhận 1 ly miễn phí.</p>
      )}
    </div>
  );
}

export function Customers() {
  const navigate = useNavigate();
  const toast = useToast();
  const [q, setQ] = useState('');
  const [list, setList] = useState<Customer[]>([]);
  const [busy, setBusy] = useState(false);
  const [selected, setSelected] = useState<Customer | null>(null);
  const [formOpen, setFormOpen] = useState<Customer | 'new' | null>(null);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [whFilter, setWhFilter] = useState('all');
  const [stampsTarget, setStampsTarget] = useState(9);
  const [custTab, setCustTab] = useState<'list' | 'birthday'>('list');
  const [shopName, setShopName] = useState('quán');
  const isPC = useIsPC();
  const [pcFilter, setPcFilter] = useState<'all' | 'debt' | 'gold' | 'silver'>('all');

  useEffect(() => {
    getSettings().then((s) => {
      const t = parseInt(s.stamps_target ?? '', 10);
      if (!Number.isNaN(t) && t > 0) setStampsTarget(t);
      if (s.shop_name) setShopName(s.shop_name);
    }).catch(() => {});
    void search('');
    getAllowedWarehouses().then(({ warehouses: ws }) => setWarehouses(ws)).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const search = async (keyword: string) => {
    setBusy(true);
    try {
      const data = await searchCustomers(keyword.trim());
      setList(data.filter((c) => whFilter === 'all' || !c.warehouse_id || c.warehouse_id === whFilter));
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tìm được');
    } finally {
      setBusy(false);
    }
  };

  const openDetail = async (id: string) => {
    try {
      const c = await getCustomer(id);
      setSelected(c);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không mở được');
    }
  };

  const visible = list.filter(
    (c) => whFilter === 'all' || !c.warehouse_id || c.warehouse_id === whFilter,
  );

  // 3 số tổng dùng chung cả mobile lẫn PC (cùng nguồn visible).
  const now = new Date();
  const debtCount = visible.filter((c) => c.debt > 0).length;
  const newThisMonth = visible.filter((c) => {
    const d = new Date(c.created_at);
    return !Number.isNaN(d.getTime()) && d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth();
  }).length;

  // Nhánh PC: chỉ khác JSX trình bày, dùng chung state/loader/handler/phân quyền
  // của code cũ. JSX mobile phía dưới dùng cùng state/handler đó.
  if (isPC) {
    const pcFiltered = visible.filter((c) =>
      pcFilter === 'all' ? true : pcFilter === 'debt' ? c.debt > 0 : c.tier === pcFilter,
    );
    const pcScrollTo = (cls: string) => {
      document.querySelector(`.${cls}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    };
    const pcRefreshSelected = async (id: string) => {
      const c = await getCustomer(id);
      if (c) setSelected(c);
      void search(q);
    };
    const pcFilters: { key: 'all' | 'debt' | 'gold' | 'silver'; label: string }[] = [
      { key: 'all', label: 'Tất cả' },
      { key: 'debt', label: 'Đang nợ' },
      { key: 'gold', label: 'Vàng' },
      { key: 'silver', label: 'Bạc' },
    ];
    return (
      <div className="page v6demo-customers v6demo-page">
        <div className="v6demo-aurora" aria-hidden />
        <div className="v6demo-content">
          <div className="v6demo-page-head v6demo-rise">
            <h1>Khách hàng</h1>
            <p>Quản lý thông tin khách, công nợ và điểm tích lũy của quán Beesy Coffee &amp; Tea.</p>
            <div className="v6demo-cust-head-actions">
              <button type="button" className="v6demo-btn v6demo-btn-ghost" onClick={() => navigate('/debt')}>
                <LineIcon name="ledger" size={18} /> Sổ nợ
              </button>
              <button type="button" className="v6demo-btn v6demo-btn-ghost" onClick={() => pcScrollTo('pc-customers-birthday')}>
                <LineIcon name="gift" size={18} /> Sinh nhật &amp; Zalo
              </button>
              <button type="button" className="v6demo-btn v6demo-btn-primary" onClick={() => setFormOpen('new')}>
                <LineIcon name="plus" size={18} /> Thêm khách hàng
              </button>
            </div>
          </div>

          <div className="v6demo-cust-stats v6demo-rise-1">
            <div className="v6demo-glass v6demo-glass-sm v6demo-cust-stat">
              <span className="v6demo-cust-stat-ico"><LineIcon name="users" size={20} /></span>
              <div className="v6demo-cust-stat-body">
                <div className="v6demo-cust-stat-label">Tổng khách</div>
                <div className="v6demo-kpi-value">{visible.length}</div>
                <div className="v6demo-cust-stat-sub">Tất cả khách đã lưu</div>
              </div>
            </div>
            <div className="v6demo-glass v6demo-glass-sm v6demo-cust-stat">
              <span className="v6demo-cust-stat-ico warn"><LineIcon name="wallet" size={20} /></span>
              <div className="v6demo-cust-stat-body">
                <div className="v6demo-cust-stat-label">Khách đang nợ</div>
                <div className="v6demo-kpi-value v6demo-negative">{debtCount}</div>
                <div className="v6demo-cust-stat-sub">Cần thu hồi công nợ</div>
              </div>
            </div>
            <div className="v6demo-glass v6demo-glass-sm v6demo-cust-stat">
              <span className="v6demo-cust-stat-ico"><LineIcon name="star" size={20} /></span>
              <div className="v6demo-cust-stat-body">
                <div className="v6demo-cust-stat-label">Khách mới tháng này</div>
                <div className="v6demo-kpi-value">{newThisMonth}</div>
                <div className="v6demo-cust-stat-sub">Tháng {now.getMonth() + 1}/{now.getFullYear()}</div>
              </div>
            </div>
          </div>

          <section className="v6demo-glass v6demo-cust-dock v6demo-rise-2" aria-label="Tìm và lọc khách hàng">
            <div className="v6demo-cust-dock-row">
              <label className="v6demo-search">
                <LineIcon name="search" size={18} />
                <input
                  placeholder="Tìm khách theo tên hoặc SĐT..."
                  value={q}
                  onChange={(e) => {
                    setQ(e.target.value);
                    void search(e.target.value);
                  }}
                  aria-label="Tìm khách hàng"
                />
              </label>
              {warehouses.length > 1 && (
                <select
                  className="v6demo-input v6demo-cust-whselect"
                  value={whFilter}
                  onChange={(e) => setWhFilter(e.target.value)}
                  aria-label="Lọc theo kho"
                >
                  <option value="all">Mọi kho</option>
                  {warehouses.map((w) => (
                    <option key={w.id} value={w.id}>{w.name}</option>
                  ))}
                </select>
              )}
            </div>
            <div className="v6demo-cust-dock-row">
              <div className="v6demo-seg" role="group" aria-label="Lọc khách hàng">
                {pcFilters.map((f) => (
                  <button key={f.key} type="button" className={pcFilter === f.key ? 'active' : ''} onClick={() => setPcFilter(f.key)}>
                    {f.label}
                  </button>
                ))}
              </div>
            </div>
          </section>

          <div className="v6demo-cust-layout v6demo-rise-3">
            <section className="v6demo-glass v6demo-cust-table-card" aria-label="Danh sách khách hàng">
              <div className="v6demo-table-wrap">
                <table className="v6demo-tbl v6demo-cust-table">
                  <thead>
                    <tr>
                      <th>Khách hàng</th>
                      <th>SĐT</th>
                      <th>Ngày sinh</th>
                      <th>Địa chỉ</th>
                      <th style={{ textAlign: 'right' }}>Công nợ</th>
                      <th style={{ textAlign: 'right' }}>Điểm tích lũy</th>
                      <th>Mua gần nhất</th>
                      <th>Thao tác</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pcFiltered.map((c) => {
                      const lastOrder = selected && c.id === selected.id ? selected.recent_orders?.[0] : undefined;
                      return (
                        <tr key={c.id} className={selected?.id === c.id ? 'selected' : ''} onClick={() => void openDetail(c.id)}>
                          <td>
                            <div className="v6demo-cust-cust">
                              <span className="v6demo-cust-avatar">{c.name.charAt(0).toUpperCase()}</span>
                              <span className="v6demo-cust-cust-text">
                                <b title={c.name}>{c.name}</b>
                                <span className="v6demo-cust-tags">
                                  <span className={`v6demo-cust-tag tier-${c.tier ?? 'member'}`}>{pcTierLabel(c.tier)}</span>
                                  {c.reward_available && <span className="v6demo-cust-tag reward">Có thưởng</span>}
                                </span>
                              </span>
                            </div>
                          </td>
                          <td className="v6demo-cust-nowrap">{c.phone || '—'}</td>
                          <td className="v6demo-cust-nowrap">{pcBirthdayLabel(c.birthday)}</td>
                          <td className="v6demo-cust-addr" title={c.address ?? ''}>{c.address || '—'}</td>
                          <td style={{ textAlign: 'right', whiteSpace: 'nowrap' }} className={c.debt > 0 ? 'v6demo-negative' : ''}>{formatVND(c.debt)}</td>
                          <td style={{ textAlign: 'right', whiteSpace: 'nowrap' }}>{(c.points ?? 0).toLocaleString('vi-VN')}</td>
                          <td className="v6demo-cust-nowrap">{lastOrder ? formatDateTime(lastOrder.created_at) : '—'}</td>
                          <td>
                            <button type="button" className="v6demo-btn v6demo-btn-ghost v6demo-btn-sm" onClick={(e) => { e.stopPropagation(); void openDetail(c.id); }}>
                              <LineIcon name="eye" size={16} /> Xem
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              {pcFiltered.length === 0 && !busy && (
                <div className="v6demo-cust-empty">
                  <LineIcon name="users" size={32} />
                  <p><b>Chưa có khách hàng nào phù hợp.</b></p>
                  <p>Thêm khách để tích tem và theo dõi công nợ.</p>
                </div>
              )}
              {busy && <div className="v6demo-cust-empty"><p>Đang tìm...</p></div>}
              <div className="v6demo-cust-pager">
                <span>Hiển thị {pcFiltered.length} / {visible.length} khách</span>
                <span>{selected ? `Đang xem: ${selected.name}` : 'Chưa chọn khách hàng'}</span>
              </div>
            </section>

            <aside className="v6demo-glass v6demo-cust-panel v6demo-panel-in" aria-label="Chi tiết khách hàng">
              {selected ? (
                <>
                  <div className="v6demo-cust-detail-head">
                    <div className="v6demo-cust-detail-title">
                      <span className="v6demo-cust-avatar lg">{selected.name.charAt(0).toUpperCase()}</span>
                      <span className="v6demo-cust-detail-name">
                        <b title={selected.name}>{selected.name}</b>
                        <span className={`v6demo-cust-tag tier-${selected.tier ?? 'member'}`}>{pcTierLabel(selected.tier)}</span>
                      </span>
                    </div>
                    <button type="button" className="v6demo-cust-close" aria-label="Đóng chi tiết" onClick={() => setSelected(null)}>
                      <LineIcon name="x" size={18} />
                    </button>
                  </div>

                  <div className="v6demo-cust-info-grid">
                    <div><div className="v6demo-cust-lbl">Họ tên</div><div className="v6demo-cust-val" title={selected.name}>{selected.name}</div></div>
                    <div><div className="v6demo-cust-lbl">Hạng</div><div className="v6demo-cust-val">{pcTierLabel(selected.tier)}</div></div>
                    <div><div className="v6demo-cust-lbl">Ngày sinh</div><div className="v6demo-cust-val">{pcBirthdayLabel(selected.birthday)}</div></div>
                    <div><div className="v6demo-cust-lbl">Số điện thoại</div><div className="v6demo-cust-val v6demo-cust-nowrap">{selected.phone}</div></div>
                    <div className="v6demo-cust-full"><div className="v6demo-cust-lbl">Địa chỉ</div><div className="v6demo-cust-val">{selected.address || '—'}</div></div>
                    {selected.note && <div className="v6demo-cust-full"><div className="v6demo-cust-lbl">Ghi chú</div><div className="v6demo-cust-val">{selected.note}</div></div>}
                    {warehouses.length > 1 && selected.warehouse_id && (
                      <div className="v6demo-cust-full"><div className="v6demo-cust-lbl">Kho của khách</div><div className="v6demo-cust-val">{warehouses.find((w) => w.id === selected.warehouse_id)?.name ?? ''}</div></div>
                    )}
                  </div>

                  <div className="v6demo-cust-highlights">
                    <div className="v6demo-cust-hl"><div className="v6demo-cust-lbl">Tổng mua</div><div className="v6demo-cust-hl-val">{formatVND(selected.total_spent ?? 0)}</div></div>
                    <div className="v6demo-cust-hl"><div className="v6demo-cust-lbl">Công nợ</div><div className="v6demo-cust-hl-val v6demo-negative">{formatVND(selected.debt)}</div></div>
                    <div className="v6demo-cust-hl"><div className="v6demo-cust-lbl">Điểm</div><div className="v6demo-cust-hl-val">{(selected.points ?? 0).toLocaleString('vi-VN')}</div></div>
                  </div>

                  <PcRewardBlock
                    customer={selected}
                    stampsTarget={stampsTarget}
                    onChanged={(c) => { setSelected(c); void search(q); }}
                  />

                  <div className="v6demo-cust-actions">
                    <button type="button" className="v6demo-btn v6demo-btn-ghost v6demo-btn-block" onClick={() => setFormOpen(selected)}>
                      <LineIcon name="edit" size={18} /> Sửa
                    </button>
                    <button type="button" className="v6demo-btn v6demo-btn-primary v6demo-btn-block" onClick={() => pcScrollTo('pc-customers-debt')}>
                      <LineIcon name="wallet" size={18} /> Thu nợ
                    </button>
                  </div>

                  <div className="v6demo-cust-block">
                    <div className="v6demo-cust-block-title">Lịch sử mua hàng</div>
                    {(selected.recent_orders ?? []).length === 0 && <p className="v6demo-cust-hint">Chưa có đơn nào</p>}
                    {(selected.recent_orders ?? []).map((o) => (
                      <div key={o.id} className="v6demo-cust-hist">
                        <div className="v6demo-cust-hist-main">
                          <b>{o.code}</b>
                          <span className="v6demo-cust-hist-sub" title={(o.items ?? []).map((i) => i.product_name).join(', ')}>
                            {formatDateTime(o.created_at)}{(o.items ?? []).length > 0 ? ` - ${(o.items ?? []).map((i) => i.product_name).join(', ')}` : ''}
                          </span>
                        </div>
                        <span className="v6demo-cust-hist-amount v6demo-cust-nowrap">{formatVND(o.total)}</span>
                      </div>
                    ))}
                  </div>

                  <div className="v6demo-cust-debt pc-customers-debt">
                    <div className="v6demo-cust-block-title">Công nợ - Thu nợ theo quỹ</div>
                    <DebtCard
                      customer={selected}
                      onChanged={async () => { if (selected) await pcRefreshSelected(selected.id); }}
                    />
                  </div>
                </>
              ) : (
                <div className="v6demo-cust-placeholder">
                  <LineIcon name="users" size={40} />
                  <p><b>Chọn một khách hàng</b></p>
                  <p>Bấm một dòng ở bảng bên trái để xem chi tiết, công nợ, điểm và lịch sử mua hàng ở đây.</p>
                </div>
              )}

              <div className="v6demo-cust-birthday pc-customers-birthday">
                <div className="v6demo-cust-block-title">Sinh nhật &amp; Zalo</div>
                <p className="v6demo-cust-hint">Sinh nhật trong 30 ngày tới, kèm mẫu tin nhắn và nút mở chat Zalo.</p>
                <BirthdayZaloTab list={visible} shopName={shopName} />
              </div>
            </aside>
          </div>

          {formOpen && (
            <CustomerForm
              customer={formOpen === 'new' ? null : formOpen}
              warehouses={warehouses}
              onClose={() => setFormOpen(null)}
              onSaved={() => void search(q)}
            />
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="page v6demo-customers v6demo-page">
      <div className="v6demo-aurora" aria-hidden />
      <div className="v6demo-content">
        <div className="v6demo-page-head v6demo-rise">
          <h1>Khách hàng</h1>
          <p>Tìm khách, tích tem, thu nợ và nhắn Zalo chăm sóc khách quen.</p>
          <div className="v6demo-cust-head-actions">
            <button type="button" className="v6demo-btn v6demo-btn-primary" onClick={() => setFormOpen('new')}>
              <LineIcon name="plus" size={18} /> Thêm khách
            </button>
          </div>
        </div>

        <div className="v6demo-seg v6demo-cust-tabs v6demo-rise-1" role="tablist" aria-label="Chế độ xem khách hàng">
          <button type="button" className={custTab === 'list' ? 'active' : ''} onClick={() => setCustTab('list')}>
            <LineIcon name="users" size={16} /> Danh sách
          </button>
          <button type="button" className={custTab === 'birthday' ? 'active' : ''} onClick={() => setCustTab('birthday')}>
            <LineIcon name="gift" size={16} /> Sinh nhật &amp; Zalo
          </button>
        </div>

        {custTab === 'birthday' ? (
          <div className="v6demo-tab-swap">
            <BirthdayZaloTab list={visible} shopName={shopName} />
          </div>
        ) : (
        <div className="v6demo-tab-swap">
          <div className="v6demo-cust-stats v6demo-rise-1">
            <div className="v6demo-glass v6demo-glass-sm v6demo-cust-stat">
              <span className="v6demo-cust-stat-ico"><LineIcon name="users" size={20} /></span>
              <div className="v6demo-cust-stat-body">
                <div className="v6demo-cust-stat-label">Tổng khách</div>
                <div className="v6demo-kpi-value">{visible.length}</div>
              </div>
            </div>
            <div className="v6demo-glass v6demo-glass-sm v6demo-cust-stat">
              <span className="v6demo-cust-stat-ico warn"><LineIcon name="wallet" size={20} /></span>
              <div className="v6demo-cust-stat-body">
                <div className="v6demo-cust-stat-label">Đang nợ</div>
                <div className="v6demo-kpi-value v6demo-negative">{debtCount}</div>
              </div>
            </div>
            <div className="v6demo-glass v6demo-glass-sm v6demo-cust-stat">
              <span className="v6demo-cust-stat-ico"><LineIcon name="star" size={20} /></span>
              <div className="v6demo-cust-stat-body">
                <div className="v6demo-cust-stat-label">Mới tháng này</div>
                <div className="v6demo-kpi-value">{newThisMonth}</div>
              </div>
            </div>
          </div>

          <section className="v6demo-glass v6demo-cust-dock v6demo-rise-2" aria-label="Tìm và lọc khách hàng">
            <label className="v6demo-search">
              <LineIcon name="search" size={18} />
              <input
                placeholder="Tìm tên, số điện thoại..."
                value={q}
                onChange={(e) => {
                  setQ(e.target.value);
                  void search(e.target.value);
                }}
                aria-label="Tìm khách hàng"
              />
            </label>
            {warehouses.length > 1 && (
              <select
                className="v6demo-input v6demo-cust-whselect"
                value={whFilter}
                onChange={(e) => setWhFilter(e.target.value)}
                aria-label="Lọc theo kho"
              >
                <option value="all">Mọi kho</option>
                {warehouses.map((w) => (
                  <option key={w.id} value={w.id}>{w.name}</option>
                ))}
              </select>
            )}
          </section>

          <button type="button" className="v6demo-glass v6demo-glass-sm v6demo-cust-debtlink v6demo-rise-2" onClick={() => navigate('/debt')}>
            <span className="v6demo-cust-debtlink-ico"><LineIcon name="ledger" size={20} /></span>
            <span className="v6demo-cust-debtlink-text">Sổ nợ</span>
            <span className="v6demo-cust-debtlink-sub">Xem và thu công nợ tất cả khách</span>
            <span className="v6demo-cust-chev" aria-hidden>›</span>
          </button>

          <section className="v6demo-glass v6demo-cust-ledger v6demo-rise-3" aria-label="Danh sách khách hàng">
            <div className="v6demo-cust-ledger-head">
              <h2>Danh sách</h2>
              <span>{visible.length} khách</span>
            </div>
            {visible.map((c) => (
              <button key={c.id} type="button" className="v6demo-cust-row" onClick={() => void openDetail(c.id)}>
                <span className="v6demo-cust-avatar">{c.name.charAt(0).toUpperCase()}</span>
                <span className="v6demo-cust-row-main">
                  <span className="v6demo-cust-row-name">
                    {c.name}
                    {c.reward_available && (
                      <span className="v6demo-cust-tag reward"><LineIcon name="gift" size={12} /> Có thưởng</span>
                    )}
                  </span>
                  <span className="v6demo-cust-row-sub">
                    <LineIcon name="phone" size={13} /> {c.phone}
                    {warehouses.length > 1 && c.warehouse_id
                      ? ` - ${warehouses.find((w) => w.id === c.warehouse_id)?.name ?? ''}`
                      : ''}
                    {c.tier && c.tier !== 'member' && (
                      <span className={`v6demo-cust-tag tier-${c.tier}`}>{pcTierLabel(c.tier)}</span>
                    )}
                  </span>
                </span>
                <span className="v6demo-cust-row-right">
                  <span className="v6demo-cust-row-meta">
                    <LineIcon name="ticket" size={13} /> {c.stamps}/{stampsTarget} tem
                    {' - '}
                    <LineIcon name="star" size={13} /> {(c.points ?? 0).toLocaleString('vi-VN')} điểm
                  </span>
                  {c.debt > 0 && (
                    <span className="v6demo-cust-row-debt">{formatVND(c.debt)}</span>
                  )}
                </span>
                <span className="v6demo-cust-chev" aria-hidden>›</span>
              </button>
            ))}
            {visible.length === 0 && !busy && (
              <div className="v6demo-cust-empty">
                <LineIcon name="users" size={32} />
                <p><b>Chưa có khách hàng nào.</b></p>
                <p>Thêm khách để tích tem và theo dõi công nợ.</p>
              </div>
            )}
            {busy && <div className="v6demo-cust-empty"><p>Đang tìm...</p></div>}
          </section>
        </div>
        )}

        {selected && (
          <CustomerDetail
            customer={selected}
            stampsTarget={stampsTarget}
            onClose={() => setSelected(null)}
            onEdit={() => setFormOpen(selected)}
            onChanged={(c) => {
              setSelected(c);
              void search(q);
            }}
          />
        )}
        {formOpen && (
          <CustomerForm
            customer={formOpen === 'new' ? null : formOpen}
            warehouses={warehouses}
            onClose={() => setFormOpen(null)}
            onSaved={() => void search(q)}
          />
        )}
      </div>
    </div>
  );
}

function CustomerDetail({ customer, stampsTarget, onClose, onEdit, onChanged }: {
  customer: Customer;
  stampsTarget: number;
  onClose: () => void;
  onEdit: () => void;
  onChanged: (c: Customer) => void;
}) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);

  const redeem = async () => {
    const lastOrder = customer.recent_orders?.[0];
    if (!lastOrder) {
      toast.show('Khách chưa có đơn nào để đổi thưởng');
      return;
    }
    if (!window.confirm(`Đổi thưởng cho ${customer.name}? (mua ${stampsTarget} tặng 1)`)) return;
    setBusy(true);
    try {
      await redeemReward(customer.id);
      toast.show('Đã đổi thưởng thành công!');
      const c = await getCustomer(customer.id);
      if (c) onChanged(c);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Đổi thưởng thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet title={customer.name} onClose={onClose}>
      <div className="v6demo-cust-sheet">
        <div className="v6demo-cust-block">
          <div className="v6demo-cust-block-head">
            <h3 className="v6demo-cust-block-title" style={{ margin: 0 }}>Thông tin</h3>
            <button type="button" className="v6demo-btn v6demo-btn-ghost v6demo-btn-sm" onClick={onEdit}>
              <LineIcon name="edit" size={16} /> Sửa
            </button>
          </div>
          <div className="v6demo-cust-kv">
            <span className="v6demo-cust-lbl">Số điện thoại</span>
            <b>{customer.phone}</b>
          </div>
          {customer.birthday && (
            <div className="v6demo-cust-kv">
              <span className="v6demo-cust-lbl">Ngày sinh</span>
              <b>{pcBirthdayLabel(customer.birthday)}</b>
            </div>
          )}
          {customer.address && (
            <div className="v6demo-cust-kv">
              <span className="v6demo-cust-lbl">Địa chỉ</span>
              <b>{customer.address}</b>
            </div>
          )}
          {customer.note && <p className="v6demo-cust-hint">{customer.note}</p>}
        </div>

        <div className="v6demo-cust-block">
          <div className="v6demo-cust-block-title"><LineIcon name="star" size={18} /> Tích điểm &amp; hạng</div>
          <div className="v6demo-cust-points-row">
            <div>
              <div className="v6demo-cust-points-big">{(customer.points ?? 0).toLocaleString('vi-VN')} <span className="v6demo-cust-lbl">điểm</span></div>
              <div className="v6demo-cust-hint">Đã chi tiêu: {formatVND(customer.total_spent ?? 0)}</div>
            </div>
            <span className={`v6demo-cust-tag tier-${customer.tier ?? 'member'}`}>{pcTierLabel(customer.tier)}</span>
          </div>
        </div>

        <div className="v6demo-cust-block">
          <div className="v6demo-cust-block-title">
            <LineIcon name="ticket" size={18} /> Tích tem <span className="v6demo-cust-lbl">({customer.stamps}/{stampsTarget})</span>
          </div>
          <div className="v6demo-cust-stamps" aria-label={`Đã tích ${customer.stamps} trên ${stampsTarget} tem`}>
            {Array.from({ length: stampsTarget }).map((_, i) => (
              <span key={i} className={`v6demo-cust-stamp${i < customer.stamps ? ' on' : ''}`}>{i + 1}</span>
            ))}
          </div>
          {customer.reward_available ? (
            <button type="button" className="v6demo-btn v6demo-btn-primary v6demo-btn-block" disabled={busy} onClick={redeem}>
              <LineIcon name="gift" size={18} /> Đổi thưởng (mua {stampsTarget} tặng 1)
            </button>
          ) : (
            <p className="v6demo-cust-hint" style={{ margin: 0 }}>
              Còn {stampsTarget - customer.stamps} tem nữa để nhận 1 ly miễn phí.
            </p>
          )}
        </div>

        <DebtCard
          customer={customer}
          onChanged={async () => {
            const c = await getCustomer(customer.id);
            if (c) onChanged(c);
          }}
        />

        <div className="v6demo-cust-block">
          <div className="v6demo-cust-block-title">Đơn gần nhất</div>
          {(customer.recent_orders ?? []).map((o) => (
            <div key={o.id} className="v6demo-cust-hist">
              <div className="v6demo-cust-hist-main">
                <b>{o.code}</b>
                <span className="v6demo-cust-hist-sub">{formatDateTime(o.created_at)}</span>
              </div>
              <span className="v6demo-cust-hist-amount v6demo-cust-nowrap">{formatVND(o.total)}</span>
            </div>
          ))}
          {(customer.recent_orders ?? []).length === 0 && (
            <p className="v6demo-cust-hint" style={{ margin: '8px 0' }}>Chưa có đơn nào</p>
          )}
        </div>
      </div>
    </Sheet>
  );
}

function DebtCard({ customer, onChanged }: { customer: Customer; onChanged: () => Promise<void> }) {
  const toast = useToast();
  const [logs, setLogs] = useState<DebtLog[]>([]);
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const [funds, setFunds] = useState<Fund[]>([]);
  const [fundId, setFundId] = useState('');

  useEffect(() => {
    listDebtLogs(customer.id).then(setLogs).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [customer.id, customer.debt]);

  useEffect(() => {
    getFunds()
      .then((fs) => {
        const act = fs.filter((f) => f.active);
        setFunds(act);
        setFundId((cur) => cur || act.find((f) => f.kind === 'cash')?.id || act[0]?.id || '');
      })
      .catch(() => {});
  }, []);

  const submit = async (isPayment: boolean) => {
    const v = parseInt(amount.replace(/\D/g, ''), 10);
    if (!v || v <= 0) {
      toast.show('Nhập số tiền hợp lệ');
      return;
    }
    setBusy(true);
    try {
      if (isPayment) {
        // Thu nợ QUA collectCustomerDebt: trừ nợ + ghi khoản thu vào Sổ quỹ
        // trong CÙNG 1 transaction (giống màn Sổ nợ). Bản cũ thu bằng
        // adjustDebt nên tiền thu ở màn này không bao giờ vào Sổ quỹ.
        await collectCustomerDebt(customer.id, v, {
          note: note.trim() || `Thu nợ — ${customer.name}`,
          fundId: fundId || null,
          method: funds.find((f) => f.id === fundId)?.kind === 'transfer' ? 'transfer' : 'cash',
          warehouseId: customer.warehouse_id ?? null,
        });
      } else {
        await adjustDebt(customer.id, v, note.trim() || null);
      }
      toast.show(isPayment ? `Đã thu ${formatVND(v)}` : `Đã ghi nợ ${formatVND(v)}`);
      setAmount('');
      setNote('');
      await onChanged();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Cập nhật công nợ thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="v6demo-cust-block v6demo-cust-debt">
      <div className="v6demo-cust-block-head">
        <h3 className="v6demo-cust-block-title" style={{ margin: 0 }}>Công nợ</h3>
        <b className="v6demo-cust-debt-total v6demo-negative">{formatVND(customer.debt)}</b>
      </div>
      <div className="v6demo-cust-field">
        <label className="v6demo-cust-lbl" htmlFor={`v6demo-debt-amount-${customer.id}`}>Số tiền</label>
        <input
          id={`v6demo-debt-amount-${customer.id}`}
          className="v6demo-input"
          inputMode="numeric"
          placeholder="Nhập số tiền"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
      </div>
      <div className="v6demo-cust-field">
        <label className="v6demo-cust-lbl" htmlFor={`v6demo-debt-note-${customer.id}`}>Ghi chú (không bắt buộc)</label>
        <input
          id={`v6demo-debt-note-${customer.id}`}
          className="v6demo-input"
          placeholder="Nhập ghi chú"
          value={note}
          onChange={(e) => setNote(e.target.value)}
        />
      </div>
      {funds.length > 0 && (
        <div className="v6demo-cust-field">
          <label className="v6demo-cust-lbl" htmlFor={`v6demo-debt-fund-${customer.id}`}>Thu nợ vào quỹ</label>
          <select
            id={`v6demo-debt-fund-${customer.id}`}
            className="v6demo-input"
            value={fundId}
            onChange={(e) => setFundId(e.target.value)}
          >
            {funds.map((f) => (
              <option key={f.id} value={f.id}>{f.name}</option>
            ))}
          </select>
        </div>
      )}
      <div className="v6demo-cust-actions">
        <button type="button" className="v6demo-btn v6demo-btn-ghost v6demo-btn-block" disabled={busy} onClick={() => submit(false)}>
          Ghi nợ
        </button>
        <button type="button" className="v6demo-btn v6demo-btn-primary v6demo-btn-block" disabled={busy || customer.debt <= 0} onClick={() => submit(true)}>
          <LineIcon name="wallet" size={18} /> Thu nợ
        </button>
      </div>
      {logs.length > 0 && (
        <div className="v6demo-cust-logs">
          {logs.map((l) => (
            <div key={l.id} className="v6demo-cust-hist">
              <div className="v6demo-cust-hist-main">
                <span className="v6demo-cust-hist-sub">{formatDateTime(l.created_at)}</span>
                {l.note && <b className="v6demo-cust-log-note">{l.note}</b>}
              </div>
              <span style={{ textAlign: 'right', flexShrink: 0 }}>
                <b className={l.amount > 0 ? 'v6demo-negative' : 'v6demo-positive'}>
                  {l.amount > 0 ? '+' : '-'}{formatVND(Math.abs(l.amount))}
                </b>
                <span className="v6demo-cust-hist-sub" style={{ display: 'block' }}>Còn {formatVND(l.balance_after)}</span>
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function CustomerForm({ customer, warehouses, onClose, onSaved }: {
  customer: Customer | null;
  warehouses: Warehouse[];
  onClose: () => void;
  onSaved: () => void;
}) {
  const toast = useToast();
  const [name, setName] = useState(customer?.name ?? '');
  const [phone, setPhone] = useState(customer?.phone ?? '');
  const [birthday, setBirthday] = useState(customer?.birthday ?? '');
  const [address, setAddress] = useState(customer?.address ?? '');
  const [note, setNote] = useState(customer?.note ?? '');
  const [whId, setWhId] = useState(customer?.warehouse_id ?? '');
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) {
      toast.show('Nhập tên và SĐT');
      return;
    }
    setBusy(true);
    try {
      const body = { name: name.trim(), phone: phone.trim(), birthday: birthday || null, address: address.trim() || null, note: note.trim() || null, warehouse_id: whId || null };
      if (customer) await updateCustomer(customer.id, body);
      else await createCustomer(body);
      toast.show(customer ? 'Đã cập nhật' : 'Đã thêm khách hàng');
      onSaved();
      onClose();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet title={customer ? 'Sửa khách hàng' : 'Thêm khách hàng'} onClose={onClose}>
      <form className="v6demo-cust-form" onSubmit={submit}>
        <div className="v6demo-cust-field">
          <label className="v6demo-cust-lbl" htmlFor="v6demo-cf-name">Tên <span className="v6demo-cust-req">*</span></label>
          <input id="v6demo-cf-name" className="v6demo-input" placeholder="Tên khách hàng" value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div className="v6demo-cust-field">
          <label className="v6demo-cust-lbl" htmlFor="v6demo-cf-phone">SĐT <span className="v6demo-cust-req">*</span></label>
          <input id="v6demo-cf-phone" className="v6demo-input" placeholder="Số điện thoại" inputMode="tel" value={phone} onChange={(e) => setPhone(e.target.value)} />
        </div>
        <div className="v6demo-cust-field">
          <label className="v6demo-cust-lbl" htmlFor="v6demo-cf-birthday">Ngày sinh</label>
          <input id="v6demo-cf-birthday" className="v6demo-input" type="date" value={birthday} onChange={(e) => setBirthday(e.target.value)} />
        </div>
        <div className="v6demo-cust-field">
          <label className="v6demo-cust-lbl" htmlFor="v6demo-cf-address">Địa chỉ</label>
          <input id="v6demo-cf-address" className="v6demo-input" placeholder="Địa chỉ" value={address} onChange={(e) => setAddress(e.target.value)} />
        </div>
        <div className="v6demo-cust-field">
          <label className="v6demo-cust-lbl" htmlFor="v6demo-cf-note">Ghi chú</label>
          <textarea id="v6demo-cf-note" className="v6demo-input" placeholder="Ghi chú" value={note} onChange={(e) => setNote(e.target.value)} />
        </div>
        {warehouses.length > 1 && (
          <div className="v6demo-cust-field">
            <label className="v6demo-cust-lbl" htmlFor="v6demo-cf-wh">Kho của khách</label>
            <select id="v6demo-cf-wh" className="v6demo-input" value={whId} onChange={(e) => setWhId(e.target.value)} aria-label="Kho của khách">
              <option value="">Mọi kho</option>
              {warehouses.map((w) => (
                <option key={w.id} value={w.id}>{w.name}</option>
              ))}
            </select>
          </div>
        )}
        <button type="submit" className="v6demo-btn v6demo-btn-primary v6demo-btn-block" style={{ minHeight: 52 }} disabled={busy}>
          {busy ? 'Đang lưu...' : 'Lưu'}
        </button>
      </form>
    </Sheet>
  );
}
