// Định dạng bản tóm tắt số liệu gửi cho AI (hàm thuần, không gọi mạng/DB
// nên test được độc lập). Chỉ gửi số TỔNG HỢP - không gửi dữ liệu khách
// hàng chi tiết ngoài tên + số nợ của nhóm khách nợ nhiều nhất.
import { formatVND } from './format';
import type { DailyReport } from './types';

export interface AiDebtor {
  name: string;
  phone: string;
  debt: number;
}

export interface AiContextData {
  shopName: string;
  generatedAt: Date;
  todayLabel: string;
  yesterdayLabel: string;
  weekLabel: string;
  prevWeekLabel: string;
  monthLabel: string;
  today: DailyReport;
  yesterday: DailyReport;
  week: DailyReport;
  prevWeek: DailyReport;
  month: DailyReport;
  debtors: AiDebtor[];
}

function reportBlock(title: string, r: DailyReport): string {
  const lines: string[] = [
    `${title}:`,
    `- Doanh thu: ${formatVND(r.revenue)} | Số đơn: ${r.order_count} | Đơn hủy: ${r.cancelled_count} | Giá trị TB/đơn: ${formatVND(r.avg_order)}`,
    `- Giá vốn: ${formatVND(r.cost)} | Chi phí vận hành: ${formatVND(r.expenses)} | Lợi nhuận ròng: ${formatVND(r.profit)}`,
  ];
  if (r.promo_count > 0) {
    lines.push(`- Đơn có khuyến mại/giảm giá: ${r.promo_count} đơn, tổng giảm ${formatVND(r.promo_discount)}`);
  }
  const pays = Object.values(r.by_payment ?? {});
  if (pays.length > 0) {
    lines.push(
      `- Doanh thu theo phương thức: ${pays.map((p) => `${p.name} ${formatVND(p.revenue)} (${p.count} đơn)`).join('; ')}`,
    );
  }
  const top = (r.top_products ?? []).slice(0, 5);
  if (top.length > 0) {
    lines.push(
      `- Món bán chạy nhất: ${top.map((p) => `${p.name} x${p.qty} (${formatVND(p.revenue)}, lãi gộp ${formatVND(p.profit)})`).join('; ')}`,
    );
  }
  const hours = (r.by_hour ?? []).filter((h) => h.count > 0);
  if (hours.length > 0) {
    const peak = [...hours].sort((a, b) => b.revenue - a.revenue)[0];
    lines.push(`- Giờ cao điểm: ${peak.hour}h (${peak.count} đơn, ${formatVND(peak.revenue)})`);
  }
  return lines.join('\n');
}

export function formatAiContext(d: AiContextData): string {
  const parts: string[] = [];
  parts.push(`Quán: ${d.shopName}`);
  parts.push(
    `Thời điểm tổng hợp số liệu: ${d.generatedAt.toLocaleString('vi-VN', { timeZone: 'Asia/Ho_Chi_Minh' })} (giờ Việt Nam)`,
  );
  parts.push('');
  parts.push(reportBlock(`HÔM NAY (${d.todayLabel})`, d.today));
  parts.push('');
  parts.push(reportBlock(`HÔM QUA (${d.yesterdayLabel})`, d.yesterday));
  parts.push('');
  parts.push(reportBlock(`TUẦN NÀY (${d.weekLabel})`, d.week));
  parts.push('');
  parts.push(reportBlock(`TUẦN TRƯỚC (${d.prevWeekLabel})`, d.prevWeek));
  parts.push('');
  parts.push(reportBlock(`THÁNG NÀY (${d.monthLabel})`, d.month));
  parts.push('');
  if (d.debtors.length > 0) {
    const totalTop = d.debtors.reduce((s, x) => s + x.debt, 0);
    parts.push('CÔNG NỢ KHÁCH HÀNG:');
    parts.push(`- ${d.debtors.length} khách đang nợ nhiều nhất (tổng nhóm này: ${formatVND(totalTop)}):`);
    for (const c of d.debtors) {
      parts.push(`  + ${c.name}${c.phone ? ` (${c.phone})` : ''}: nợ ${formatVND(c.debt)}`);
    }
  } else {
    parts.push('CÔNG NỢ KHÁCH HÀNG: hiện không có khách nào đang nợ.');
  }
  return parts.join('\n');
}
