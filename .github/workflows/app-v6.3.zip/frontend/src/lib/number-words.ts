// Doc so tien VND thanh chu tieng Viet (dung cho "Tong so tien (viet bang
// chu)" tren phieu nhap/xuat kho mau 01-VT / 02-VT). Ham thuan, da kiem chung
// bang fixture voi cac so viet tay.

const DIGITS = ['không', 'một', 'hai', 'ba', 'bốn', 'năm', 'sáu', 'bảy', 'tám', 'chín'];
const SCALES = ['', 'nghìn', 'triệu', 'tỷ', 'nghìn tỷ', 'triệu tỷ'];

/** Doc 1 nhom 3 chu so. hasHigher=true khi con nhom lon hon phia truoc
 * (khi do phai doc ca "khong tram" neu hang tram bang 0). */
function readGroup(h: number, t: number, u: number, hasHigher: boolean): string {
  const parts: string[] = [];
  if (h > 0 || hasHigher) {
    parts.push(`${DIGITS[h]} trăm`);
    if (t === 0 && u > 0) parts.push('lẻ', DIGITS[u]);
  }
  if (t > 1) {
    parts.push(`${DIGITS[t]} mươi`);
    if (u === 1) parts.push('mốt');
    else if (u === 5) parts.push('lăm');
    else if (u > 0) parts.push(DIGITS[u]);
  } else if (t === 1) {
    parts.push('mười');
    if (u === 5) parts.push('lăm');
    else if (u > 0) parts.push(DIGITS[u]);
  } else if (u > 0 && h === 0 && !hasHigher) {
    parts.push(DIGITS[u]);
  }
  return parts.join(' ');
}

/** VD: 1234567 -> "Một triệu hai trăm ba mươi bốn nghìn năm trăm sáu mươi bảy đồng" */
export function moneyToWords(amount: number): string {
  const n = Math.round(Math.abs(Number(amount) || 0));
  if (n === 0) return 'Không đồng';
  const groups: number[] = [];
  let rest = n;
  while (rest > 0) {
    groups.push(rest % 1000);
    rest = Math.floor(rest / 1000);
  }
  const out: string[] = [];
  for (let i = groups.length - 1; i >= 0; i--) {
    const g = groups[i];
    if (g === 0) continue;
    const h = Math.floor(g / 100);
    const t = Math.floor((g % 100) / 10);
    const u = g % 10;
    const isHighest = i === groups.length - 1;
    const text = readGroup(h, t, u, !isHighest);
    out.push(SCALES[i] ? `${text} ${SCALES[i]}` : text);
  }
  const s = out.join(' ');
  return `${s.charAt(0).toUpperCase()}${s.slice(1)} đồng`;
}
