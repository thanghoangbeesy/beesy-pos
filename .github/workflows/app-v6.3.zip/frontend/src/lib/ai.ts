// Gọi trợ lý AI (Gemini bản miễn phí) qua Cloudflare Worker trung gian.
//
// Vì sao phải qua Worker: khóa API của Google không được nằm trong app
// (ai mở app cũng moi được khóa và dùng chùa, đốt hết hạn mức miễn phí).
// Worker giữ khóa, app chỉ gọi POST {worker_url}/ask.
//
// Cấu hình nằm ở settings/ai_worker_url và settings/ai_app_token
// (nhập ở Cài đặt -> Trợ lý AI).
import { doc, getDoc } from 'firebase/firestore';
import { db } from './firebase';
import { setSetting } from './db';

export interface AiConfig {
  worker_url: string;
  app_token: string;
  configured: boolean;
}

export async function getAiConfig(): Promise<AiConfig> {
  try {
    const [w, t] = await Promise.all([
      getDoc(doc(db, 'settings', 'ai_worker_url')),
      getDoc(doc(db, 'settings', 'ai_app_token')),
    ]);
    const worker_url = w.exists() ? String((w.data() as Record<string, unknown>).value ?? '').trim().replace(/\/$/, '') : '';
    const app_token = t.exists() ? String((t.data() as Record<string, unknown>).value ?? '').trim() : '';
    return { worker_url, app_token, configured: !!worker_url };
  } catch {
    return { worker_url: '', app_token: '', configured: false };
  }
}

export async function saveAiConfig(worker_url: string, app_token: string): Promise<void> {
  await setSetting('ai_worker_url', worker_url.trim().replace(/\/$/, ''));
  await setSetting('ai_app_token', app_token.trim());
}

export interface AiHistoryItem {
  role: 'user' | 'assistant';
  text: string;
}

export interface AskAiResult {
  ok: boolean;
  answer?: string;
  error?: string;
}

/** Hỏi AI 1 câu, kèm bản tóm tắt số liệu của quán và lịch sử chat gần nhất. */
export async function askAI(question: string, context: string, history: AiHistoryItem[]): Promise<AskAiResult> {
  const cfg = await getAiConfig();
  if (!cfg.configured) return { ok: false, error: 'Chưa cấu hình Trợ lý AI. Vào Cài đặt -> Trợ lý AI để nhập Worker URL.' };
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 45000);
  try {
    const r = await fetch(`${cfg.worker_url}/ask`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(cfg.app_token ? { 'X-Beesy-Token': cfg.app_token } : {}),
      },
      body: JSON.stringify({ question, context, history }),
      signal: ctrl.signal,
    });
    const data = (await r.json().catch(() => ({}))) as Record<string, unknown>;
    if (r.ok && typeof data.answer === 'string' && data.answer) return { ok: true, answer: data.answer };
    return { ok: false, error: String(data.error ?? `Worker trả lỗi HTTP ${r.status}`) };
  } catch (e) {
    if (e instanceof DOMException && e.name === 'AbortError') {
      return { ok: false, error: 'AI trả lời quá lâu (quá 45 giây). Kiểm tra mạng rồi thử lại.' };
    }
    return { ok: false, error: 'Không gọi được Worker. Kiểm tra lại Worker URL trong Cài đặt.' };
  } finally {
    clearTimeout(timer);
  }
}

/** Kiểm tra kết nối Worker (dùng ở Cài đặt): trả về trạng thái + Worker đã có key chưa. */
export async function pingAI(workerUrl: string): Promise<{ ok: boolean; hasKey: boolean; error?: string }> {
  try {
    const r = await fetch(`${workerUrl.replace(/\/$/, '')}/ping`);
    const data = (await r.json().catch(() => ({}))) as Record<string, unknown>;
    if (r.ok && data.ok === true) return { ok: true, hasKey: data.ai === true };
    return { ok: false, hasKey: false, error: `HTTP ${r.status}` };
  } catch {
    return { ok: false, hasKey: false, error: 'Không gọi được địa chỉ này' };
  }
}
