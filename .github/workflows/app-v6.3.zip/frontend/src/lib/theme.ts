// App chỉ dùng duy nhất giao diện v3 (lineal icon, thẻ bo mềm, gọn).
// Đã bỏ chọn theme v1/v2 trong Cài đặt theo yêu cầu của Hoàng (2026-10-18).
export type AppTheme = 'v3';

export function getTheme(): AppTheme {
  return 'v3';
}

export function setTheme(_t: AppTheme): void {
  document.documentElement.setAttribute('data-theme', 'v3');
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', '#00B14F');
}

// Gọi sớm khi app khởi động (index.html đã set sẵn để tránh nháy)
export function initTheme(): void {
  document.documentElement.setAttribute('data-theme', 'v3');
  try { localStorage.removeItem('beesy-theme'); } catch { /* bỏ qua */ }
}
