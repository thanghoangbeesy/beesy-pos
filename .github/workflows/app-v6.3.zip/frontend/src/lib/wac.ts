// Giá vốn bình quân gia quyền (weighted average cost) — hàm thuần, không phụ
// thuộc Firebase để test được độc lập. Dùng cho phiếu nhập (cộng/gỡ lớp nhập)
// và phiếu sản xuất bán thành phẩm.

/** Làm tròn 2 số thập phân — giá vốn đơn vị g/ml cần phần lẻ, tròn số nguyên lệch nhiều. */
export function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

/**
 * Cộng 1 lớp nhập (qty đơn vị, value = tổng tiền của lớp) vào tồn hiện tại.
 * Tồn <= 0 hoặc chưa có giá vốn -> lấy giá của lớp nhập.
 */
export function wacAdd(stock: number, avg: number, qty: number, value: number): number {
  if (qty <= 0) return avg;
  const total = stock + qty;
  if (total <= 0) return avg;
  if (stock <= 0 || avg <= 0) return round2(value / qty);
  return round2((stock * avg + value) / total);
}

/**
 * Gỡ 1 lớp nhập khỏi giá vốn bình quân (khi sửa/xóa phiếu nhập, xóa phiếu SX).
 * Không gỡ sạch được (hết tồn, hoặc giá tính ra âm do đã bán xen kẽ) -> giữ nguyên.
 */
export function wacRemove(stock: number, avg: number, qty: number, value: number): number {
  if (qty <= 0 || avg <= 0) return avg;
  const rest = stock - qty;
  if (rest <= 0) return avg;
  const v = (stock * avg - value) / rest;
  return v >= 0 ? round2(v) : avg;
}
