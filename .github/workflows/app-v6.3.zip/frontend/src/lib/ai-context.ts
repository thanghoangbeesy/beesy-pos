// Gom số liệu báo cáo thành bản tóm tắt cho AI.
// Đọc 5 báo cáo có sẵn (hôm nay, hôm qua, tuần này, tuần trước, tháng này)
// + nhóm khách nợ nhiều nhất. Việc gom này tốn lượt đọc Firestore nên phía
// giao diện chỉ gọi 1 lần khi mở màn hình Hỏi AI (và khi bấm Cập nhật).
import { getDailyReport, getRangeReport, getTopDebtors } from './db';
import { addDaysVN, todayVN } from './format';
import { formatAiContext } from './ai-format';

function dmy(ymd: string): string {
  const [y, m, d] = ymd.split('-');
  return `${d}/${m}/${y}`;
}

export async function buildAiContext(shopName: string): Promise<string> {
  const today = todayVN();
  const yesterday = addDaysVN(today, -1);
  // Tuần tính từ thứ 2
  const dow = new Date(`${today}T12:00:00`).getDay(); // 0 = chủ nhật
  const weekStart = addDaysVN(today, -((dow + 6) % 7));
  const prevWeekStart = addDaysVN(weekStart, -7);
  const prevWeekEnd = addDaysVN(weekStart, -1);
  const monthStart = `${today.slice(0, 8)}01`;

  const [repToday, repYesterday, repWeek, repPrevWeek, repMonth, debtors] = await Promise.all([
    getDailyReport(today),
    getDailyReport(yesterday),
    getRangeReport(weekStart, today),
    getRangeReport(prevWeekStart, prevWeekEnd),
    getRangeReport(monthStart, today),
    getTopDebtors(10).catch(() => []),
  ]);

  return formatAiContext({
    shopName,
    generatedAt: new Date(),
    todayLabel: dmy(today),
    yesterdayLabel: dmy(yesterday),
    weekLabel: `${dmy(weekStart)} - ${dmy(today)}`,
    prevWeekLabel: `${dmy(prevWeekStart)} - ${dmy(prevWeekEnd)}`,
    monthLabel: `tháng ${today.slice(5, 7)}/${today.slice(0, 4)} (từ ${dmy(monthStart)} đến ${dmy(today)})`,
    today: repToday,
    yesterday: repYesterday,
    week: repWeek,
    prevWeek: repPrevWeek,
    month: repMonth,
    debtors,
  });
}
