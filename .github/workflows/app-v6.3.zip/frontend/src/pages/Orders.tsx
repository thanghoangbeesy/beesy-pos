// Đơn hàng — xem / sửa / xóa các đơn đã bán.
// Sửa nhanh: ghi chú + khách hàng (quản lý trở lên).
// Sửa toàn bộ: món, số lượng, giảm giá, voucher, phương thức thanh toán (chỉ chủ quán;
//   tồn kho, sổ quỹ, công nợ, tem/điểm được tính lại theo).
// Xóa: chỉ chủ quán; đơn ghi nợ được hoàn công nợ, khoản quỹ tự động của đơn bị xóa theo.
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  DbError,
  deleteOrder,
  getAllowedWarehouses,
  getOrder,
  getSettings,
  listOrders,
  listPaymentMethods,
  searchCustomers,
  updateOrderMeta,
} from '../lib/db';
import {
  addDaysVN,
  formatDMY,
  formatTime,
  formatVND,
  startOfMonthVN,
  startOfWeekVN,
  todayVN,
  unsignVietnamese,
} from '../lib/format';
import { BluetoothPrintButton } from '../components/BluetoothPrintButton';
import { TIcon } from '../components/TIcon';
import { PageHead } from '../components/PageHead';
import { CustomerPickSheet } from '../components/CustomerPickSheet';
import { OrderEditForm } from './OrderEditForm';
import { BillPrint } from './BillPrint';
import { saveBillImage, shareBillImage, zaloPhone } from '../lib/bill-image';
import { loadBrand } from '../lib/brand';
import { useToast } from '../components/Toast';
import { useAuth } from '../lib/auth';
import type { Customer, Order, PaymentMethodDef, Warehouse } from '../lib/types';
import { isSplitPayment, orderPaymentSplits } from '../lib/types';

type FilterKey = 'today' | 'yesterday' | 'week' | 'lastweek' | 'month' | 'lastmonth' | 'custom';
const FILTERS: { key: FilterKey; label: string }[] = [
  { key: 'today', label: 'Hôm nay' },
  { key: 'yesterday', label: 'Hôm qua' },
  { key: 'week', label: 'Tuần này' },
  { key: 'lastweek', label: 'Tuần trước' },
  { key: 'month', label: 'Tháng này' },
  { key: 'lastmonth', label: 'Tháng trước' },
  { key: 'custom', label: 'Tùy chọn' },
];

const STATUS_LABEL: Record<string, string> = {
  new: 'Mới',
  preparing: 'Đang pha',
  ready: 'Sẵn sàng',
  done: 'Hoàn tất',
  cancelled: 'Đã hủy',
};

function rangeOf(key: FilterKey, customFrom?: string, customTo?: string): [string, string] {
  const t = todayVN();
  switch (key) {
    case 'today':
      return [t, t];
    case 'yesterday': {
      const y = addDaysVN(t, -1);
      return [y, y];
    }
    case 'week':
      return [startOfWeekVN(t), t];
    case 'lastweek': {
      const ws = startOfWeekVN(t);
      const we = addDaysVN(ws, -1);
      return [addDaysVN(ws, -7), we];
    }
    case 'month':
      return [startOfMonthVN(t), t];
    case 'lastmonth': {
      const ms = startOfMonthVN(t);
      const me = addDaysVN(ms, -1);
      return [startOfMonthVN(me), me];
    }
    case 'custom':
      return [customFrom || t, customTo || t];
  }
}

export function Orders() {
  const toast = useToast();
  const { can } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [custMap, setCustMap] = useState<Map<string, Customer>>(new Map());
  const [kindMap, setKindMap] = useState<Map<string, string>>(new Map());
  // v6.3: dữ liệu để xem lại bill của đơn đã lưu (như lúc thanh toán ở Checkout).
  const [methods, setMethods] = useState<PaymentMethodDef[]>([]);
  const [fallbackBank, setFallbackBank] = useState({ bin: '', account: '', name: '' });
  const [shopName, setShopName] = useState('Beesy Coffee & Tea');
  const [shopPhone, setShopPhone] = useState('');
  const [shopAddress, setShopAddress] = useState('');
  const [shopLogo, setShopLogo] = useState('');
  const [q, setQ] = useState('');
  const [filter, setFilter] = useState<FilterKey>('today');
  const [customFrom, setCustomFrom] = useState(todayVN());
  const [customTo, setCustomTo] = useState(todayVN());
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [whFilter, setWhFilter] = useState('all');
  const [busy, setBusy] = useState(true);
  // Thẻ đơn đang mở rộng chi tiết (v5.16: chi tiết mở ngay trong thẻ như bản demo Beesy Store)
  const [expandedId, setExpandedId] = useState<string | null>(null);
  // Đơn được mở qua deep-link (?open=orderId) từ Sổ quỹ — có thể nằm ngoài khoảng lọc hiện tại
  const [deepOrder, setDeepOrder] = useState<Order | null>(null);
  const [searchParams, setSearchParams] = useSearchParams();

  const load = useCallback(
    async (fk: FilterKey, whId: string = 'all', cFrom?: string, cTo?: string) => {
      setBusy(true);
      try {
        const [from, to] = rangeOf(fk, cFrom ?? customFrom, cTo ?? customTo);
        const allowed = await getAllowedWarehouses();
        setWarehouses(allowed.warehouses);
        const ids =
          whId === 'all'
            ? allowed.isOwner
              ? undefined
              : allowed.warehouses.map((w) => w.id)
            : [whId];
        const [list, customers, methods] = await Promise.all([
          listOrders({ from, to, warehouseIds: ids }),
          searchCustomers(''),
          listPaymentMethods(false),
        ]);
        setOrders(list);
        setCustMap(new Map(customers.map((c) => [c.id, c])));
        setKindMap(new Map(methods.map((m) => [m.id, m.kind])));
        setMethods(methods);
      } catch (e) {
        toast.show(e instanceof DbError ? e.message : 'Không tải được đơn hàng');
      } finally {
        setBusy(false);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [],
  );

  // Cấu hình quán + ngân hàng dự phòng cho bill (như CheckoutModal).
  useEffect(() => {
    getSettings()
      .then((s) => {
        setShopName(s.shop_name || 'Beesy Coffee & Tea');
        setShopPhone(s.shop_phone || '');
        setShopAddress(s.shop_address || '');
        setFallbackBank({
          bin: s.bank_bin || '',
          account: s.bank_account || '',
          name: s.bank_account_name || '',
        });
      })
      .catch(() => {});
    loadBrand().then((b) => setShopLogo(b.logo || '')).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    void load(filter, whFilter);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filter, whFilter]);

  const changeWh = (id: string) => setWhFilter(id);

  // Deep-link từ Sổ quỹ: /orders?open=<orderId> → mở ngay chi tiết đơn
  useEffect(() => {
    const openId = searchParams.get('open');
    if (!openId) return;
    setSearchParams({}, { replace: true });
    getOrder(openId)
      .then((o) => {
        if (!o) {
          toast.show('Không tìm thấy đơn hàng');
          return;
        }
        setDeepOrder(o);
        setExpandedId(o.id);
      })
      .catch(() => toast.show('Không mở được đơn hàng'));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const needle = unsignVietnamese(q.trim()).toLowerCase();
  const canDeleteRow = can('orders.delete');
  const quickDelete = async (o: { id: string; code: string; total: number }) => {
    if (!window.confirm(`Xóa đơn ${o.code} (${formatVND(o.total)})? Khoản quỹ và công nợ liên quan sẽ được hoàn/xóa theo.`))
      return;
    try {
      await deleteOrder(o.id);
      toast.show(`Đã xóa đơn ${o.code}`);
      void load(filter, whFilter);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Xóa thất bại');
    }
  };
  const filtered = useMemo(
    () =>
      orders.filter((o) => {
        if (!needle) return true;
        const c = o.customer_id ? custMap.get(o.customer_id) : undefined;
        const hay = unsignVietnamese(
          `${o.code} ${o.note ?? ''} ${c ? `${c.name} ${c.phone}` : 'khách lẻ'}`,
        ).toLowerCase();
        return hay.includes(needle);
      }),
    [orders, custMap, needle],
  );

  const handleChanged = () => {
    setExpandedId(null);
    setDeepOrder(null);
    void load(filter, whFilter);
  };

  const orderGroups = useMemo(() => {
    const groups = new Map<string, typeof filtered>();
    for (const o of filtered) {
      const k = o.business_date;
      const arr = groups.get(k);
      if (arr) arr.push(o);
      else groups.set(k, [o]);
    }
    return [...groups.entries()]
      .sort((a, b) => b[0].localeCompare(a[0]))
      .map(([date, list]) => ({ date, list, revenue: list.reduce((s, o) => s + o.total, 0) }));
  }, [filtered]);

  return (
    <div className="page">
      <PageHead title="Đơn hàng" back />

      <div className="sb-search" style={{ marginBottom: 12 }}>
        <span className="sico"><TIcon emoji="🔍" size={18} /></span>
        <input
          placeholder="Tìm mã đơn, tên, SĐT khách…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          aria-label="Tìm đơn hàng"
        />
      </div>

      {warehouses.length > 1 && (
        <div className="row" style={{ gap: 8, marginBottom: 12, flexWrap: 'wrap' }}>
          <button className={`sb-chip${whFilter === 'all' ? ' selected' : ''}`} onClick={() => changeWh('all')}>
            Mọi kho
          </button>
          {warehouses.map((w) => (
            <button key={w.id} className={`sb-chip${whFilter === w.id ? ' selected' : ''}`} onClick={() => changeWh(w.id)}>
              {w.name}
            </button>
          ))}
        </div>
      )}

      <div className="row" style={{ gap: 8, marginBottom: 12, flexWrap: 'wrap' }}>
        <select
          className="input"
          style={{ flex: '1 1 130px', minWidth: 0 }}
          value={filter}
          onChange={(e) => {
            const fk = e.target.value as FilterKey;
            setFilter(fk);
            void load(fk, whFilter);
          }}
          aria-label="Lọc theo thời gian"
        >
          {FILTERS.map((f) => (
            <option key={f.key} value={f.key}>
              {f.label}
            </option>
          ))}
        </select>
      </div>
      {filter === 'custom' && (
        <div className="row" style={{ gap: 8, marginBottom: 12 }}>
          <input
            className="input"
            type="date"
            value={customFrom}
            max={todayVN()}
            onChange={(e) => {
              const v = e.target.value;
              if (v) {
                setCustomFrom(v);
                if (v > customTo) setCustomTo(v);
              }
            }}
            aria-label="Từ ngày"
            style={{ flex: 1 }}
          />
          <input
            className="input"
            type="date"
            value={customTo}
            max={todayVN()}
            min={customFrom}
            onChange={(e) => {
              const v = e.target.value;
              if (v) setCustomTo(v);
            }}
            aria-label="Đến ngày"
            style={{ flex: 1 }}
          />
          <button
            className="btn btn-outline"
            style={{ minHeight: 44 }}
            onClick={() => void load('custom', whFilter, customFrom, customTo)}
          >
            Lọc
          </button>
        </div>
      )}

      <div>
        {busy ? (
          <p className="muted" style={{ textAlign: 'center' }}>
            Đang tải…
          </p>
        ) : (
          <>
            {deepOrder && !filtered.some((o) => o.id === deepOrder.id) && (
              <div style={{ marginBottom: 16 }}>
                <div className="row" style={{ alignItems: 'center', marginBottom: 8, padding: '0 4px' }}>
                  <b style={{ fontSize: 15 }}>📌 Đơn mở từ Sổ quỹ</b>
                </div>
                <OrderCard
                  order={deepOrder}
                  customer={deepOrder.customer_id ? custMap.get(deepOrder.customer_id) ?? null : null}
                  kindMap={kindMap}
                  expanded
                  onToggle={() => {
                    setExpandedId(null);
                    setDeepOrder(null);
                  }}
                  canQuickDelete={canDeleteRow}
                  onQuickDelete={quickDelete}
                  canEdit={can('orders.edit')}
                  canDelete={can('orders.delete')}
                  onChanged={handleChanged}
                  methods={methods}
                  fallbackBank={fallbackBank}
                  shopName={shopName}
                  shopPhone={shopPhone}
                  shopAddress={shopAddress}
                  shopLogo={shopLogo}
                />
              </div>
            )}
            {filtered.length === 0 && !deepOrder ? (
              <div className="sb-empty">
                <div className="eico"><TIcon emoji="🧾" size={28} /></div>
                <p>Chưa có đơn hàng nào trong khoảng này.</p>
              </div>
            ) : (
              orderGroups.map((g) => (
                <div key={g.date} style={{ marginBottom: 16 }}>
                  <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center', marginBottom: 8, padding: '0 4px' }}>
                    <b style={{ fontSize: 15 }}>📅 {formatDMY(g.date)}</b>
                    <span className="money text-green" style={{ fontSize: 15 }}>
                      {formatVND(g.revenue)} <span className="small muted">({g.list.length} đơn)</span>
                    </span>
                  </div>
                  {g.list.map((o) => (
                    <OrderCard
                      key={o.id}
                      order={o}
                      customer={o.customer_id ? custMap.get(o.customer_id) ?? null : null}
                      kindMap={kindMap}
                      expanded={expandedId === o.id}
                      onToggle={() => setExpandedId(expandedId === o.id ? null : o.id)}
                      canQuickDelete={canDeleteRow}
                      onQuickDelete={quickDelete}
                      canEdit={can('orders.edit')}
                      canDelete={can('orders.delete')}
                      onChanged={handleChanged}
                      methods={methods}
                      fallbackBank={fallbackBank}
                      shopName={shopName}
                      shopPhone={shopPhone}
                      shopAddress={shopAddress}
                      shopLogo={shopLogo}
                    />
                  ))}
                </div>
              ))
            )}
          </>
        )}
      </div>
    </div>
  );
}

/** Nhãn phương thức thanh toán dạng pill (màu như bản demo Beesy Store). */
function payPill(o: Order, kindMap: Map<string, string>) {
  if (isSplitPayment(o)) {
    return <span className="sb-status-pill info"><TIcon emoji="💳" size={13} /> Hỗn hợp</span>;
  }
  const kind = kindMap.get(o.payment_method) ?? '';
  const label = o.payment_method_name ?? (kind === 'cash' ? 'Tiền mặt' : kind === 'transfer' ? 'Chuyển khoản' : kind === 'debt' ? 'Ghi nợ' : o.payment_method);
  const cls = kind === 'debt' ? 'sb-status-pill warn' : kind === 'transfer' ? 'sb-status-pill info' : 'sb-status-pill';
  return <span className={cls}>{label}</span>;
}

/**
 * Thẻ đơn hàng theo mẫu bản demo Beesy Store (v5.16): mã đơn + nhãn, khách,
 * các dòng món kèm giá, tổng cộng, giờ đặt và nút Xem chi tiết mở rộng ngay
 * trong thẻ. Thu gọn hiện tối đa 3 món đầu.
 */
function OrderCard({
  order,
  customer,
  kindMap,
  expanded,
  onToggle,
  canQuickDelete,
  onQuickDelete,
  canEdit,
  canDelete,
  onChanged,
  methods,
  fallbackBank,
  shopName,
  shopPhone,
  shopAddress,
  shopLogo,
}: {
  order: Order;
  customer: Customer | null;
  kindMap: Map<string, string>;
  expanded: boolean;
  onToggle: () => void;
  canQuickDelete: boolean;
  onQuickDelete: (o: { id: string; code: string; total: number }) => void;
  canEdit: boolean;
  canDelete: boolean;
  onChanged: () => void;
  methods: PaymentMethodDef[];
  fallbackBank: { bin: string; account: string; name: string };
  shopName: string;
  shopPhone: string;
  shopAddress: string;
  shopLogo: string;
}) {
  const preview = order.items.slice(0, 3);
  const moreCount = order.items.length - preview.length;
  return (
    <div className="ord-card">
      {canQuickDelete && order.status !== 'cancelled' && (
        <button
          type="button"
          className="ord-del"
          aria-label={`Xóa đơn ${order.code}`}
          onClick={() => void onQuickDelete(order)}
        >
          ×
        </button>
      )}
      <div className="ord-head">
        <span className="ord-code">{order.code}</span>
        {payPill(order, kindMap)}
        {order.status === 'cancelled' ? (
          <span className="sb-status-pill" style={{ background: '#F3F4F6', color: '#6B7280' }}>Đã hủy</span>
        ) : order.status !== 'done' ? (
          <span className="sb-status-pill info">{STATUS_LABEL[order.status] ?? order.status}</span>
        ) : null}
      </div>
      <div className="ord-cust">
        👤 {customer ? <><b>{customer.name}</b> · {customer.phone}</> : 'Khách lẻ'}
        {order.online_name ? <> · {order.online_name}</> : null}
      </div>
      <div className="ord-div" />
      <div>
        {preview.map((it) => {
          const mods = (it.modifiers ?? []).map((m) => m.option).filter(Boolean).join(', ');
          return (
            <div className="ord-item" key={it.id}>
              <span className="ord-item-name">
                {it.product_name}
                {mods ? <span className="muted"> ({mods})</span> : null} × {it.qty}
              </span>
              <span className="ord-item-price">{formatVND(it.line_total)}</span>
            </div>
          );
        })}
        {moreCount > 0 && <div className="ord-more">+ {moreCount} món nữa</div>}
        {order.items.length === 0 && <div className="ord-more">Không có món</div>}
      </div>
      <div className="ord-div" />
      <div className="ord-total">
        <span>Tổng cộng</span>
        <b>{formatVND(order.total)}</b>
      </div>
      <div className="ord-time">
        🕐 Đặt lúc {formatTime(order.created_at)} · {formatDMY(order.business_date)}
      </div>
      <button type="button" className="ord-toggle" onClick={onToggle} aria-expanded={expanded}>
        {expanded ? 'Thu gọn ⌃' : 'Xem chi tiết ⌄'}
      </button>
      {expanded && (
        <OrderCardExpanded
          order={order}
          customer={customer}
          canEdit={canEdit}
          canDelete={canDelete}
          onChanged={onChanged}
          methods={methods}
          fallbackBank={fallbackBank}
          shopName={shopName}
          shopPhone={shopPhone}
          shopAddress={shopAddress}
          shopLogo={shopLogo}
        />
      )}
    </div>
  );
}

/** Phần chi tiết mở rộng trong thẻ đơn: thay cho Sheet chi tiết cũ, giữ nguyên mọi thao tác. */
function OrderCardExpanded({
  order,
  customer,
  canEdit,
  canDelete,
  onChanged,
  methods,
  fallbackBank,
  shopName,
  shopPhone,
  shopAddress,
  shopLogo,
}: {
  order: Order;
  customer: Customer | null;
  canEdit: boolean;
  canDelete: boolean;
  onChanged: () => void;
  methods: PaymentMethodDef[];
  fallbackBank: { bin: string; account: string; name: string };
  shopName: string;
  shopPhone: string;
  shopAddress: string;
  shopLogo: string;
}) {
  const toast = useToast();
  const [mode, setMode] = useState<'view' | 'edit' | 'confirmDelete' | 'bill'>('view');
  const [editFull, setEditFull] = useState(false);
  const [note, setNote] = useState(order.note ?? '');
  const [cust, setCust] = useState<Customer | null>(customer);
  const [pickOpen, setPickOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [billBusy, setBillBusy] = useState(false);
  const canFullEdit = canDelete && order.status !== 'cancelled';

  // v6.3: xem lại bill của đơn đã lưu — tính QR đúng logic lúc thanh toán
  // (CheckoutModal): chỉ đơn có phần chuyển khoản + quán đã cấu hình BIN/STK
  // cho phương thức đó mới có QR; đơn chỉ tiền mặt hoặc chỉ ghi nợ thì không.
  const split = isSplitPayment(order);
  const splits = split ? orderPaymentSplits(order) : [];
  const transferSplits = splits.filter((sp) => sp.kind === 'transfer');
  const transferMethod = transferSplits.length > 0
    ? (methods.find((m) => m.id === transferSplits[0].method_id) ?? null)
    : null;
  const singleMethod = !split ? (methods.find((m) => m.id === order.payment_method) ?? null) : null;
  let transferTotal = 0;
  let qrBin = '';
  let qrAccount = '';
  let qrName = shopName;
  if (split) {
    transferTotal = transferSplits.reduce((a, sp) => a + sp.amount, 0);
    qrBin = transferMethod?.bank_bin ?? '';
    qrAccount = transferMethod?.bank_account ?? '';
    qrName = transferMethod?.bank_account_name ?? fallbackBank.name ?? shopName;
  } else if (singleMethod?.kind === 'transfer') {
    transferTotal = order.total;
    qrBin = singleMethod.bank_bin ?? fallbackBank.bin ?? '';
    qrAccount = singleMethod.bank_account ?? fallbackBank.account ?? '';
    qrName = singleMethod.bank_account_name ?? fallbackBank.name ?? shopName;
  } else if (order.payment_method === 'transfer') {
    // Đơn cũ lưu phương thức dạng kind, không tra được method def: dùng
    // cấu hình ngân hàng dự phòng trong settings (như CheckoutModal).
    transferTotal = order.total;
    qrBin = fallbackBank.bin;
    qrAccount = fallbackBank.account;
    qrName = fallbackBank.name || shopName;
  }
  const showBillQR = transferTotal > 0 && !!qrBin && !!qrAccount;

  const handleSaveBillImage = async () => {
    if (billBusy) return;
    setBillBusy(true);
    try {
      await saveBillImage(order.code);
      toast.show('Đã lưu ảnh hóa đơn');
    } catch (e) {
      console.error('saveBillImage failed', e);
      toast.show(`Không lưu được ảnh: ${e instanceof Error ? e.message : 'lỗi không rõ'}`);
    } finally {
      setBillBusy(false);
    }
  };

  const handleShareBillZalo = async () => {
    if (billBusy) return;
    setBillBusy(true);
    try {
      // Chỉ gửi ẢNH bill, không kèm bất kỳ chữ nào (như v5.15).
      const res = await shareBillImage(order.code);
      if (res === 'fallback') {
        toast.show('Đã tải ảnh bill. Mở Zalo để gửi cho khách.');
        if (customer?.phone) {
          window.open(`https://zalo.me/${zaloPhone(customer.phone)}`, '_blank');
        }
      }
    } catch (e) {
      if (e instanceof DOMException && e.name === 'AbortError') return;
      console.error('shareBillImage failed', e);
      toast.show(`Không gửi được bill: ${e instanceof Error ? e.message : 'lỗi không rõ'}`);
    } finally {
      setBillBusy(false);
    }
  };

  const doSave = async () => {
    setBusy(true);
    try {
      await updateOrderMeta(order.id, { note: note.trim() || null, customerId: cust ? cust.id : null });
      toast.show(`Đã lưu thay đổi đơn ${order.code}`);
      onChanged();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  const doDelete = async () => {
    setBusy(true);
    try {
      await deleteOrder(order.id);
      toast.show(`Đã xóa đơn ${order.code}`);
      onChanged();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Xóa thất bại');
    } finally {
      setBusy(false);
    }
  };

  if (editFull) {
    return (
      <OrderEditForm
        order={order}
        customer={cust ?? customer}
        onClose={() => setEditFull(false)}
        onSaved={onChanged}
      />
    );
  }

  return (
    <div className="ord-detail">
      {mode === 'bill' ? (
        <>
          <BillPrint
            order={order}
            shopName={shopName}
            shopPhone={shopPhone}
            shopAddress={shopAddress}
            shopLogo={shopLogo}
            qrBin={showBillQR ? qrBin : null}
            qrName={showBillQR ? qrName : undefined}
            qrAccount={showBillQR ? qrAccount : undefined}
            qrAmount={showBillQR ? transferTotal : undefined}
          />
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 8, marginTop: 10 }}>
            <button className="btn btn-outline btn-block co-ico-label" disabled={billBusy} onClick={() => void handleSaveBillImage()}>
              {billBusy ? 'Đang xử lý…' : <><TIcon emoji="📷" size={17} /> Lưu ảnh bill</>}
            </button>
            <button className="btn btn-outline btn-block co-ico-label" disabled={billBusy} onClick={() => void handleShareBillZalo()}>
              {billBusy ? 'Đang xử lý…' : <><TIcon emoji="💬" size={17} /> Gửi Zalo</>}
            </button>
          </div>
          <button className="btn btn-ghost btn-block" style={{ marginTop: 8 }} onClick={() => setMode('view')}>
            Quay lại chi tiết đơn
          </button>
        </>
      ) : mode === 'confirmDelete' ? (
        <>
          <p style={{ margin: '4px 0 12px', lineHeight: 1.6 }}>
            Xóa đơn <b>{order.code}</b> ({formatVND(order.total)})? Doanh thu và công nợ liên quan sẽ
            được hoàn lại. Thao tác này không thể hoàn tác.
          </p>
          <div className="row" style={{ gap: 8 }}>
            <button className="btn btn-outline btn-block" disabled={busy} onClick={() => setMode('view')}>
              Giữ lại
            </button>
            <button className="btn btn-block" disabled={busy} onClick={doDelete}>
              {busy ? 'Đang xóa…' : 'Xóa đơn'}
            </button>
          </div>
        </>
      ) : mode === 'edit' ? (
        <>
          <div className="field">
            <label>Khách hàng</label>
            <button className="sb-row" type="button" onClick={() => setPickOpen(true)}>
              <span className="avatar">{cust ? cust.name.charAt(0).toUpperCase() : '👤'}</span>
              <span className="rbody">
                <span className="rtitle">{cust ? cust.name : 'Khách lẻ'}</span>
                <span className="rsub">{cust ? cust.phone : 'Bấm để chọn khách'}</span>
              </span>
              <span className="text-green" style={{ fontWeight: 600 }}>
                Đổi ›
              </span>
            </button>
            {cust && (
              <button
                type="button"
                className="btn btn-ghost btn-sm"
                style={{ marginTop: 6 }}
                onClick={() => setCust(null)}
              >
                Bỏ chọn (về khách lẻ)
              </button>
            )}
          </div>
          <div className="field">
            <label>Ghi chú đơn</label>
            <input
              className="input"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Ghi chú…"
              maxLength={1000}
            />
          </div>
          <p className="small muted">Sửa nhanh ghi chú và khách hàng. Muốn sửa món/giá/voucher/thanh toán thì dùng “✏️ Sửa đơn” (chỉ chủ quán).</p>
          <div className="row" style={{ gap: 8 }}>
            <button className="btn btn-outline btn-block" disabled={busy} onClick={() => setMode('view')}>
              Hủy
            </button>
            <button className="btn btn-block" disabled={busy} onClick={doSave}>
              {busy ? 'Đang lưu…' : 'Lưu'}
            </button>
          </div>
        </>
      ) : (
        <>
          <div style={{ marginBottom: 10 }}>
            <div className="row" style={{ justifyContent: 'space-between', marginBottom: 6 }}>
              <span className="muted">Khách hàng</span>
              <b>{customer ? `${customer.name} · ${customer.phone}` : 'Khách lẻ'}</b>
            </div>
            <div className="row" style={{ justifyContent: 'space-between', marginBottom: 6 }}>
              <span className="muted">Thanh toán</span>
              <b>{isSplitPayment(order) ? <><TIcon emoji="💳" size={13} /> Hỗn hợp</> : (order.payment_method_name ?? order.payment_method)}</b>
            </div>
            {isSplitPayment(order) &&
              orderPaymentSplits(order).map((sp) => (
                <div className="row" key={sp.method_id} style={{ justifyContent: 'space-between', marginBottom: 4 }}>
                  <span className="muted small" style={{ paddingLeft: 12 }}>
                    {sp.kind === 'cash' ? '💵' : sp.kind === 'transfer' ? '📱' : '📒'} {sp.method_name}
                  </span>
                  <b className="money">{formatVND(sp.amount)}</b>
                </div>
              ))}
            {order.payment_method === 'cash' && order.amount_received != null && (
              <div className="row" style={{ justifyContent: 'space-between', marginBottom: 6 }}>
                <span className="muted">Khách đưa / thối lại</span>
                <b>{formatVND(order.amount_received)} / {formatVND(order.change_amount ?? 0)}</b>
              </div>
            )}
            {order.warehouse_name && (
              <div className="row" style={{ justifyContent: 'space-between', marginBottom: 6 }}>
                <span className="muted">Kho trừ tồn</span>
                <b>🗃️ {order.warehouse_name}</b>
              </div>
            )}
            {order.note && (
              <div className="row" style={{ justifyContent: 'space-between' }}>
                <span className="muted">Ghi chú</span>
                <b style={{ textAlign: 'right', maxWidth: '60%' }}>{order.note}</b>
              </div>
            )}
          </div>

          <div style={{ marginBottom: 10 }}>
            <div className="small muted" style={{ fontWeight: 600, padding: '4px 0 2px' }}>
              Tất cả món ({order.items.length})
            </div>
            {order.items.map((it) => (
              <div className="ord-item" key={it.id}>
                <span className="ord-item-name">
                  {it.product_name} <span className="muted">× {it.qty}</span>
                  {it.modifiers.length > 0 && (
                    <span className="rsub" style={{ display: 'block' }}>
                      {it.modifiers.map((m) => `${m.group}: ${m.option}`).join(' · ')}
                    </span>
                  )}
                  {it.note && <span className="rsub" style={{ display: 'block' }}>“{it.note}”</span>}
                  {it.discount ? (
                    <span className="rsub" style={{ display: 'block', color: 'var(--green)' }}>
                      Giảm {it.discount_type === 'percent' ? `${it.discount_value}%` : 'tiền'}: −{formatVND(it.discount)}
                    </span>
                  ) : null}
                </span>
                <span className="ord-item-price">{formatVND(it.line_total)}</span>
              </div>
            ))}
          </div>

          <div>
            {(order.discount > 0 || order.shipping_fee > 0) && (
              <div className="row" style={{ justifyContent: 'space-between' }}>
                <span className="muted">Tạm tính</span>
                <span>{formatVND(order.subtotal)}</span>
              </div>
            )}
            {order.discount > 0 && (
              <div className="row" style={{ justifyContent: 'space-between', color: 'var(--green)' }}>
                <span>
                  Giảm giá{order.discount_label ? ` (${order.discount_label})` : ''}
                </span>
                <span>-{formatVND(order.discount)}</span>
              </div>
            )}
            {order.shipping_fee > 0 && (
              <div className="row" style={{ justifyContent: 'space-between' }}>
                <span className="muted">Phí ship</span>
                <span>+{formatVND(order.shipping_fee)}</span>
              </div>
            )}
          </div>

          <div className="ord-actions">
            <BluetoothPrintButton order={order} small />
            {order.status !== 'cancelled' && (
              <button className="btn btn-outline btn-sm" style={{ padding: '8px 4px', fontSize: 13 }} onClick={() => setMode('bill')}>
                <TIcon emoji="🧾" size={14} /> Xem bill
              </button>
            )}
            {canFullEdit && (
              <button className="btn btn-outline btn-sm" style={{ padding: '8px 4px', fontSize: 13 }} onClick={() => setEditFull(true)}>
                <TIcon emoji="✏️" size={14} /> Sửa đơn
              </button>
            )}
            {canEdit && (
              <button className="btn btn-outline btn-sm" style={{ padding: '8px 4px', fontSize: 13 }} onClick={() => setMode('edit')}>
                Sửa ghi chú
              </button>
            )}
            {canDelete && order.status !== 'cancelled' && (
              <button
                className="btn btn-sm"
                style={{ padding: '8px 4px', fontSize: 13 }}
                onClick={() => setMode('confirmDelete')}
              >
                Xóa đơn
              </button>
            )}
          </div>
        </>
      )}

      {pickOpen && (
        <CustomerPickSheet
          onClose={() => setPickOpen(false)}
          onPick={(c) => {
            setCust(c);
            setPickOpen(false);
          }}
        />
      )}
    </div>
  );
}
