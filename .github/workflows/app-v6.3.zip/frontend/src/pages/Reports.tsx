import { useEffect, useState } from 'react';
import { ReportsPC } from './ReportsPC';
import { ReportsMobile } from './ReportsMobile';

/** Hook phát hiện màn hình PC (>= 1024px). */
function useIsPC(): boolean {
  const [isPC, setIsPC] = useState(() => typeof window !== 'undefined' && window.innerWidth >= 1024);
  useEffect(() => {
    const onResize = () => setIsPC(window.innerWidth >= 1024);
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);
  return isPC;
}

/**
 * Trang Tổng quan — PC và Mobile là 2 giao diện riêng biệt.
 * PC: layout StockPro (sidebar + KPI row + chart + bảng).
 * Mobile: layout gọn (header xanh + KPI 2x2 + chart + list).
 */
export function Reports() {
  const isPC = useIsPC();
  return isPC ? <ReportsPC /> : <ReportsMobile />;
}
