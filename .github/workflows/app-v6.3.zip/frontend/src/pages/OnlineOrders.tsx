import { useEffect, useRef, useState } from 'react';
import { TIcon } from '../components/TIcon';
import {
  DbError,
  cancelOnlineOrder,
  confirmOnlineOrder,
  subscribePendingOnlineOrders,
} from '../lib/db';
import { playNewOrderSound } from '../lib/realtime';
import {
  getNotifyPermission,
  isNotifyEnabled,
  isNotifySupported,
  requestNotifyPermission,
  setNotifyEnabled,
  showOrderNotification,
} from '../lib/notify';
import { useToast } from '../components/Toast';
import { PageHead } from '../components/PageHead';
import type { OnlineOrder } from '../lib/types';

const SOUND_KEY = 'beesy_online_sound';

/** Đơn online: theo dõi và duyệt/từ chối đơn đặt qua web. */
export function OnlineOrders() {
  const toast = useToast();
  const [orders, setOrders] = useState<OnlineOrder[]>([]);
  const [busy, setBusy] = useState<string | null>(null);
  const [soundOn, setSoundOn] = useState(() => localStorage.getItem(SOUND_KEY) !== 'off');
  const [notifyPerm, setNotifyPerm] = useState<NotificationPermission | 'unsupported'>(() => getNotifyPermission());
  const [notifyOn, setNotifyOn] = useState(() => isNotifyEnabled());
  const soundRef = useRef(soundOn);
  soundRef.current = soundOn;

  useEffect(() => {
    const unsub = subscribePendingOnlineOrders(
      (items) => {
        setOrders((prev) => {
          if (prev.length < items.length && soundRef.current) {
            playNewOrderSound();
            if (notifyOn) {
              showOrderNotification(
                `🔔 Đơn online mới (${items.length} chờ duyệt)`,
                items[0] ? `${items[0].customer_name} — ${items[0].total.toLocaleString('vi-VN')}đ` : '',
              );
            }
          }
          return items;
        });
      },
      (e) => {
        const code = (e as { code?: string })?.code ?? '';
        const msg = e instanceof Error ? e.message : String(e);
        if (code === 'failed-precondition') {
          toast.show('⚠️ Đơn online: thiếu index Firestore — vào console tạo index cho online_orders (status + created_at)');
        } else if (code === 'permission-denied') {
          toast.show('⚠️ Đơn online: chưa dán rules mới — dán lại firestore.rules rồi thử lại');
        } else {
          toast.show(`⚠️ Đơn online lỗi (${code || 'unknown'}): ${msg}`);
        }
      },
    );
    return unsub;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [notifyOn]);

  const approve = async (oo: OnlineOrder) => {
    setBusy(oo.id);
    try {
      const order = await confirmOnlineOrder(oo.id);
      toast.show(`Đã duyệt → đơn ${order.code} ✅`);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Duyệt đơn thất bại');
    } finally {
      setBusy(null);
    }
  };

  const reject = async (oo: OnlineOrder) => {
    if (!window.confirm(`Từ chối đơn online của ${oo.customer_name}?`)) return;
    setBusy(oo.id);
    try {
      await cancelOnlineOrder(oo.id);
      toast.show('Đã từ chối đơn online');
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Thất bại');
    } finally {
      setBusy(null);
    }
  };

  const toggleSound = () => {
    const v = !soundOn;
    setSoundOn(v);
    localStorage.setItem(SOUND_KEY, v ? 'on' : 'off');
    if (v) playNewOrderSound();
  };

  return (
    <div className="page">
      <PageHead
        title="🌐 Đơn online"
        right={
          <>
            <button
              className="btn btn-ghost"
              style={{ width: 44, height: 44, minHeight: 44, padding: 0, borderRadius: '50%', fontSize: 22 }}
              onClick={toggleSound}
              title={soundOn ? 'Tắt âm báo' : 'Bật âm báo'}
            >
              {soundOn ? '🔔' : '🔕'}
            </button>
            {isNotifySupported() && notifyPerm !== 'granted' && (
              <button
                className="btn btn-ghost"
                style={{ width: 44, height: 44, minHeight: 44, padding: 0, borderRadius: '50%', fontSize: 22, marginLeft: 8 }}
                onClick={async () => {
                  const p = await requestNotifyPermission();
                  setNotifyPerm(p);
                  if (p === 'granted') {
                    setNotifyOn(true);
                    setNotifyEnabled(true);
                    showOrderNotification('🔔 Đã bật thông báo', 'Có đơn online mới sẽ báo ngay trên máy này.');
                  }
                }}
                title="Bật thông báo đơn online trên máy này"
              >
                📲
              </button>
            )}
            {isNotifySupported() && notifyPerm === 'granted' && (
              <button
                className="btn btn-ghost"
                style={{ width: 44, height: 44, minHeight: 44, padding: 0, borderRadius: '50%', fontSize: 22, marginLeft: 8 }}
                onClick={() => {
                  const v = !notifyOn;
                  setNotifyOn(v);
                  setNotifyEnabled(v);
                }}
                title={notifyOn ? 'Tắt thông báo hệ thống' : 'Bật thông báo hệ thống'}
              >
                {notifyOn ? '📢' : '📪'}
              </button>
            )}
          </>
        }
      />
      {orders.length > 0 && (
        <p className="small muted" style={{ margin: '0 0 12px' }}>
          {orders.length} đơn chờ duyệt
        </p>
      )}
      {orders.length === 0 ? (
        <div className="sb-empty">
          <div className="eico"><TIcon emoji="🌐" size={28} /></div>
          <p>Chưa có đơn online chờ duyệt.</p>
          <p className="small muted">Đơn khách đặt qua trang /dat-hang sẽ hiện ở đây để anh duyệt.</p>
        </div>
      ) : (
        orders.map((oo) => (
          <div key={oo.id} className="card" style={{ marginBottom: 12, border: '2px solid var(--amber, #f59e0b)' }}>
            <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ fontWeight: 700, fontSize: 16 }}>
                {oo.customer_name} · {oo.customer_phone}
              </div>
              <div className="money" style={{ color: 'var(--green)', fontSize: 18 }}>
                {oo.total.toLocaleString('vi-VN')}đ
              </div>
            </div>
            <div className="small" style={{ margin: '8px 0' }}>
              {oo.items.map((it) => `${it.qty}× ${it.product_name}${it.modifiers.length ? ` (${it.modifiers.map((m) => m.option).join(', ')})` : ''}`).join(' · ')}
            </div>
            <div className="small muted">
              {oo.payment_kind === 'cash' ? '💵 Tiền mặt khi nhận' : '🏦 Chuyển khoản'} ·{' '}
              {new Date(oo.created_at).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}
              {oo.note ? ` · 📝 ${oo.note}` : ''}
            </div>
            <div className="row" style={{ gap: 8, marginTop: 12 }}>
              <button
                className="btn btn-block"
                disabled={busy === oo.id}
                onClick={() => void approve(oo)}
              >
                {busy === oo.id ? 'Đang duyệt…' : '✅ Duyệt → tạo đơn'}
              </button>
              <button
                className="btn btn-outline"
                disabled={busy === oo.id}
                onClick={() => void reject(oo)}
              >
                Từ chối
              </button>
            </div>
          </div>
        ))
      )}
    </div>
  );
}
