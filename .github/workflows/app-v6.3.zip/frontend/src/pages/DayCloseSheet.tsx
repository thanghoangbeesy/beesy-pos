// Chốt két tiền: cho phép chốt nhiều lần trong 1 ngày,
// xem danh sách các lần chốt, sửa/xóa (chỉ chủ quán).
import { useEffect, useState } from 'react';
import { DbError, deleteDayClose, getAllowedWarehouses, getDaySummary, getRangeReport, listDayCloses, listPaymentMethods, saveDayClose, updateDayClose } from '../lib/db';
import { formatVND, todayVN } from '../lib/format';
import { useToast } from '../components/Toast';
import { Sheet } from '../components/Sheet';
import { TIcon } from '../components/TIcon';
import type { DayClose, DayCloseMethod } from '../lib/types';

const DENOMS = [500000, 200000, 100000, 50000, 20000, 10000, 5000, 2000, 1000];

export function DayCloseSheet({ onClose }: { onClose: () => void }) {
  const toast = useToast();
  const [busy, setBusy] = useState(true);
  const [saving, setSaving] = useState(false);
  const [closes, setCloses] = useState<DayClose[]>([]);
  const [methods, setMethods] = useState<DayCloseMethod[]>([]);
  const [revenue, setRevenue] = useState(0);
  const [orderCount, setOrderCount] = useState(0);
  const [discountTotal, setDiscountTotal] = useState(0);
  const [cashActual, setCashActual] = useState('');
  const [note, setNote] = useState('');
  const [closeDate, setCloseDate] = useState(todayVN());
  const [denomQty, setDenomQty] = useState<Record<string, string>>({});
  const [showForm, setShowForm] = useState(false);
  const [viewing, setViewing] = useState<DayClose | null>(null);
  const [editing, setEditing] = useState<DayClose | null>(null);
  const [isOwner, setIsOwner] = useState(false);

  const loadData = async (t: string) => {
    setBusy(true);
    try {
      const allowed = await getAllowedWarehouses().catch(() => ({ warehouses: [] as { id: string }[], isOwner: false }));
      setIsOwner(allowed.isOwner);
      const ids = allowed.isOwner ? undefined : allowed.warehouses.map((w) => w.id);
      const [list, rep, pms, sum] = await Promise.all([
        listDayCloses(t),
        getRangeReport(t, t, ids),
        listPaymentMethods(false),
        getDaySummary(t, ids),
      ]);
      setCloses(list);
      setRevenue(sum.revenue);
      setOrderCount(sum.orders_count);
      setDiscountTotal(sum.discount_total);
      const kindById = new Map(pms.map((m) => [m.id, m.kind]));
      const byMethod: DayCloseMethod[] = Object.entries(rep.by_payment).map(([id, v]) => ({
        method_id: id,
        name: v.name,
        kind: kindById.get(id) ?? 'cash',
        amount: v.revenue,
        count: v.count,
      }));
      setMethods(byMethod);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tải được số liệu');
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => {
    void loadData(closeDate);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [closeDate]);

  const denomTotal = DENOMS.reduce((s, d) => s + d * (parseInt(denomQty[String(d)] ?? '', 10) || 0), 0);
  const applyDenomTotal = () => setCashActual(String(denomTotal));

  const cashExpected = methods.filter((m) => m.kind === 'cash').reduce((s, m) => s + m.amount, 0);
  const actualNum = Math.max(0, parseInt(cashActual.replace(/\D/g, ''), 10) || 0);
  const diff = actualNum - cashExpected;

  const resetForm = () => {
    setCashActual('');
    setNote('');
    setDenomQty({});
    setShowForm(false);
  };

  const doClose = async () => {
    if (!window.confirm(`Chốt két ngày ${closeDate}?`)) return;
    setSaving(true);
    try {
      const denoms: Record<string, number> = {};
      for (const d of DENOMS) {
        const q = parseInt(denomQty[String(d)] ?? '', 10) || 0;
        if (q > 0) denoms[String(d)] = q;
      }
      await saveDayClose({
        business_date: closeDate,
        revenue,
        orders_count: orderCount,
        discount_total: discountTotal,
        by_method: methods,
        cash_expected: cashExpected,
        cash_actual: actualNum,
        cash_denoms: Object.keys(denoms).length > 0 ? denoms : null,
        note: note.trim() || null,
      });
      resetForm();
      await loadData(closeDate);
      toast.show('Đã chốt két ✅');
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Chốt két thất bại');
    } finally {
      setSaving(false);
    }
  };

  const doDelete = async (dc: DayClose) => {
    if (!window.confirm(`Xóa lần chốt lúc ${formatTime(dc.closed_at)} ngày ${dc.business_date}?`)) return;
    try {
      await deleteDayClose(dc.id);
      setViewing(null);
      await loadData(closeDate);
      toast.show('Đã xóa');
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Xóa thất bại');
    }
  };

  const doSaveEdit = async () => {
    if (!editing) return;
    const actual = Math.max(0, parseInt(cashActual.replace(/\D/g, ''), 10) || 0);
    const denoms: Record<string, number> = {};
    for (const d of DENOMS) {
      const q = parseInt(denomQty[String(d)] ?? '', 10) || 0;
      if (q > 0) denoms[String(d)] = q;
    }
    try {
      await updateDayClose(editing.id, {
        cash_actual: actual,
        cash_denoms: Object.keys(denoms).length > 0 ? denoms : null,
        note: note.trim() || null,
      });
      setEditing(null);
      setViewing(null);
      resetForm();
      await loadData(closeDate);
      toast.show('Đã lưu');
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    }
  };

  const startEdit = (dc: DayClose) => {
    setCashActual(String(dc.cash_actual));
    setNote(dc.note ?? '');
    const dq: Record<string, string> = {};
    if (dc.cash_denoms) {
      for (const [k, v] of Object.entries(dc.cash_denoms)) dq[k] = String(v);
    }
    setDenomQty(dq);
    setEditing(dc);
    setViewing(null);
  };

  const formatTime = (iso: string) => {
    try {
      const d = new Date(iso);
      return d.toLocaleString('vi-VN', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' });
    } catch {
      return iso;
    }
  };

  const renderDetail = (dc: DayClose, allowEdit: boolean) => (
    <div className="card" style={{ background: 'var(--green-bg)', marginBottom: 12 }}>
      <div style={{ fontWeight: 700, marginBottom: 8 }}>
        💰 Chốt két {formatTime(dc.closed_at)}
      </div>
      <div className="co-total-row"><span>Doanh thu</span><span className="money">{formatVND(dc.revenue)}</span></div>
      <div className="co-total-row"><span>Số đơn</span><span>{dc.orders_count}</span></div>
      <div className="co-total-row"><span>Tiền mặt hệ thống</span><span>{formatVND(dc.cash_expected)}</span></div>
      <div className="co-total-row"><span>Tiền mặt thực tế</span><span>{formatVND(dc.cash_actual)}</span></div>
      <div className="co-total-row grand">
        <span>Chênh lệch két</span>
        <span className="money" style={{ color: dc.cash_diff === 0 ? 'var(--green)' : 'var(--red)' }}>
          {dc.cash_diff > 0 ? '+' : ''}{formatVND(dc.cash_diff)}
        </span>
      </div>
      {dc.cash_denoms && (
        <details className="small" style={{ marginTop: 8 }}>
          <summary className="muted">💵 Chi tiết kiểm tiền</summary>
          <div style={{ marginTop: 6 }}>
            {Object.entries(dc.cash_denoms)
              .sort((a, b) => Number(b[0]) - Number(a[0]))
              .map(([d, q]) => (
                <div className="co-total-row" key={d}>
                  <span>{formatVND(Number(d))} × {q}</span>
                  <span>{formatVND(Number(d) * q)}</span>
                </div>
              ))}
          </div>
        </details>
      )}
      {dc.note && <p className="small muted">📝 {dc.note}</p>}
      <p className="small muted">Người chốt: {dc.closed_by_name ?? '—'}</p>
      {allowEdit && isOwner && (
        <div className="row" style={{ marginTop: 8, gap: 8 }}>
          <button className="btn btn-outline" onClick={() => startEdit(dc)}><TIcon emoji="✏️" size={14} /> Sửa</button>
          <button className="btn btn-ghost" style={{ color: 'var(--red)' }} onClick={() => doDelete(dc)}><TIcon emoji="🗑️" size={14} /> Xóa</button>
        </div>
      )}
    </div>
  );

  const renderDenomTable = () => (
    <div className="card" style={{ marginBottom: 12 }}>
      <div style={{ fontWeight: 700, marginBottom: 8 }}>💵 Kiểm tiền mặt trong két</div>
      <div className="denom-table">
        <div className="denom-head denom-row">
          <span>Mệnh giá</span>
          <span style={{ textAlign: 'center' }}>Số tờ</span>
          <span style={{ textAlign: 'right' }}>Thành tiền</span>
        </div>
        {DENOMS.map((d) => {
          const q = parseInt(denomQty[String(d)] ?? '', 10) || 0;
          return (
            <div className="denom-row" key={d}>
              <span className="money">{formatVND(d)}</span>
              <input
                className="input denom-qty"
                inputMode="numeric"
                placeholder="0"
                value={denomQty[String(d)] ?? ''}
                onChange={(e) => setDenomQty((prev) => ({ ...prev, [String(d)]: e.target.value.replace(/\D/g, '') }))}
              />
              <span className="money" style={{ textAlign: 'right' }}>{formatVND(d * q)}</span>
            </div>
          );
        })}
        <div className="denom-row denom-total">
          <span style={{ fontWeight: 700 }}>Tổng</span>
          <span />
          <span className="money" style={{ textAlign: 'right', fontWeight: 800 }}>{formatVND(denomTotal)}</span>
        </div>
      </div>
      {denomTotal > 0 && (
        <button className="btn btn-block" style={{ marginTop: 8 }} onClick={applyDenomTotal}>
          Dùng {formatVND(denomTotal)} làm tiền thực tế
        </button>
      )}
    </div>
  );

  const renderForm = (isEditMode: boolean) => (
    <>
      <div className="card" style={{ marginBottom: 12 }}>
        <div className="co-total-row"><span>Doanh thu ngày {closeDate}</span><span className="money">{formatVND(revenue)}</span></div>
        <div className="co-total-row"><span>Số đơn</span><span>{orderCount}</span></div>
        {discountTotal > 0 && (
          <div className="co-total-row"><span>Đã giảm giá</span><span>-{formatVND(discountTotal)}</span></div>
        )}
        {methods.map((m) => (
          <div className="co-total-row" key={m.method_id}>
            <span>{m.name} ({m.count} đơn)</span>
            <span>{formatVND(m.amount)}</span>
          </div>
        ))}
      </div>
      <div className="field">
        <label>Tiền mặt hệ thống ghi nhận</label>
        <input className="input" value={formatVND(isEditMode && editing ? editing.cash_expected : cashExpected)} disabled />
      </div>
      <div className="field">
        <label>Tiền mặt thực tế trong két</label>
        <input
          className="input"
          inputMode="numeric"
          placeholder="Đếm két rồi nhập…"
          value={cashActual}
          onChange={(e) => setCashActual(e.target.value)}
        />
      </div>
      {renderDenomTable()}
      {cashActual && (
        <div
          className="card"
          style={{
            marginBottom: 12,
            background: diff === 0 ? 'var(--green-bg)' : 'var(--red-bg)',
            color: diff === 0 ? 'var(--green)' : 'var(--red)',
            fontWeight: 700,
          }}
        >
          {diff === 0 ? '✅ Khớp két' : `⚠️ Chênh lệch: ${diff > 0 ? '+' : ''}${formatVND(diff)}`}
        </div>
      )}
      <div className="field">
        <label>Ghi chú (không bắt buộc)</label>
        <input
          className="input"
          placeholder="VD: chốt ca sáng…"
          value={note}
          onChange={(e) => setNote(e.target.value)}
        />
      </div>
      <div className="row" style={{ gap: 8 }}>
        <button
          className="btn btn-ghost grow"
          onClick={() => { setShowForm(false); setEditing(null); resetForm(); }}
        >
          Hủy
        </button>
        <button
          className="btn btn-block grow"
          disabled={saving}
          onClick={() => { if (isEditMode) void doSaveEdit(); else void doClose(); }}
        >
          {saving ? 'Đang lưu…' : isEditMode ? '💾 Lưu' : '💰 Chốt két'}
        </button>
      </div>
    </>
  );

  return (
    <Sheet title="💰 Chốt két tiền" onClose={onClose}>
      <div className="field">
        <label>📅 Ngày</label>
        <input
          className="input"
          type="date"
          max={todayVN()}
          value={closeDate}
          onChange={(e) => {
            if (e.target.value) { setCloseDate(e.target.value); setShowForm(false); setEditing(null); setViewing(null); }
          }}
        />
      </div>

      {busy ? (
        <div className="muted">Đang tải số liệu…</div>
      ) : editing ? (
        renderForm(true)
      ) : viewing ? (
        <>
          {renderDetail(viewing, true)}
          <button className="btn btn-block btn-ghost" onClick={() => setViewing(null)}>← Quay lại danh sách</button>
        </>
      ) : showForm ? (
        renderForm(false)
      ) : (
        <>
          {closes.length === 0 ? (
            <div className="sb-empty">
              <div className="eico">💰</div>
              <p>Chưa chốt két ngày {closeDate}.</p>
            </div>
          ) : (
            <div style={{ marginBottom: 12 }}>
              <div className="small muted" style={{ marginBottom: 8 }}>
                Đã chốt {closes.length} lần ngày {closeDate}:
              </div>
              {closes.map((dc) => (
                <button key={dc.id} className="sb-row" onClick={() => setViewing(dc)}>
                  <span className="rbody">
                    <span className="rtitle">🕐 {formatTime(dc.closed_at)}</span>
                    <span className="rsub">
                      Thực tế {formatVND(dc.cash_actual)} · {dc.cash_diff === 0 ? '✅ khớp' : `⚠️ lệch ${dc.cash_diff > 0 ? '+' : ''}${formatVND(dc.cash_diff)}`}
                    </span>
                  </span>
                  <span style={{ color: 'var(--muted)', fontSize: 24 }}>›</span>
                </button>
              ))}
            </div>
          )}
          <button className="btn btn-block btn-lg" onClick={() => { resetForm(); setShowForm(true); }}>
            ＋ Chốt két mới
          </button>
        </>
      )}
    </Sheet>
  );
}
