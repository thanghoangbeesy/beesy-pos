import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../lib/auth';
import { getPublicSettings } from '../lib/db';
import { askAI, getAiConfig, type AiHistoryItem } from '../lib/ai';
import { buildAiContext } from '../lib/ai-context';
import { PageHead } from '../components/PageHead';
import { useToast } from '../components/Toast';
import { LineIcon } from '../components/LineIcon';

interface Msg {
  role: 'user' | 'assistant';
  text: string;
}

const SUGGESTIONS = [
  'Hôm nay doanh thu và lợi nhuận thế nào?',
  'Món nào bán chạy nhất tuần này?',
  'Tuần này so với tuần trước ra sao?',
  'Tháng này chi phí vận hành là bao nhiêu?',
  'Ai đang nợ nhiều nhất?',
  'Giờ nào quán đông khách nhất?',
];

// Trợ lý AI hỏi-đáp số liệu (Gemini miễn phí qua Cloudflare Worker).
// Chỉ chủ quán (quyền 'ai') mới vào được - số liệu có cả lợi nhuận.
export function AskAI() {
  const { can } = useAuth();
  const toast = useToast();
  const allowed = can('ai');
  const [configured, setConfigured] = useState<boolean | null>(null);
  const [context, setContext] = useState<string | null>(null);
  const [ctxLoading, setCtxLoading] = useState(false);
  const [ctxAt, setCtxAt] = useState<Date | null>(null);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const bottomRef = useRef<HTMLDivElement | null>(null);

  const loadContext = async () => {
    setCtxLoading(true);
    try {
      const { shop_name } = await getPublicSettings();
      const ctx = await buildAiContext(shop_name || 'Beesy Coffee & Tea');
      setContext(ctx);
      setCtxAt(new Date());
    } catch {
      toast.show('Không tổng hợp được số liệu');
    } finally {
      setCtxLoading(false);
    }
  };

  useEffect(() => {
    if (!allowed) return;
    void (async () => {
      const cfg = await getAiConfig();
      setConfigured(cfg.configured);
      if (cfg.configured) await loadContext();
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [allowed]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [msgs, sending]);

  const send = async (raw?: string) => {
    const q = (raw ?? input).trim();
    if (!q || sending) return;
    if (!context) {
      toast.show('Đang tổng hợp số liệu, đợi một chút rồi hỏi lại');
      return;
    }
    setInput('');
    const history: AiHistoryItem[] = msgs.slice(-6).map((m) => ({ role: m.role, text: m.text }));
    setMsgs((prev) => [...prev, { role: 'user', text: q }]);
    setSending(true);
    try {
      const res = await askAI(q, context, history);
      if (res.ok && res.answer) {
        setMsgs((prev) => [...prev, { role: 'assistant', text: res.answer as string }]);
      } else {
        setMsgs((prev) => [...prev, { role: 'assistant', text: `Có lỗi: ${res.error ?? 'không rõ'}` }]);
      }
    } finally {
      setSending(false);
    }
  };

  if (!allowed) {
    return (
      <div>
        <PageHead title="Hỏi AI" />
        <div className="card">
          Mục này chỉ dành cho <b>chủ quán</b> vì trợ lý AI trả lời cả số liệu lợi nhuận của quán.
        </div>
      </div>
    );
  }

  if (configured === false) {
    return (
      <div>
        <PageHead title="Hỏi AI" />
        <div className="card">
          <p style={{ marginTop: 0 }}>
            <b>Chưa cấu hình Trợ lý AI.</b>
          </p>
          <p className="muted">
            Trợ lý dùng Gemini (bản miễn phí của Google) qua một Cloudflare Worker trung gian giữ khóa API.
            Cần làm 1 lần: lấy API key miễn phí ở aistudio.google.com, tạo Worker theo file hướng dẫn kèm bản
            cập nhật này, rồi dán địa chỉ Worker vào Cài đặt.
          </p>
          <Link className="btn" to="/settings">
            Mở Cài đặt - mục Trợ lý AI
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: 760, margin: '0 auto' }}>
      <PageHead title="Hỏi AI" />
      <div className="row" style={{ gap: 8, marginBottom: 10, alignItems: 'center' }}>
        <span className="small muted grow">
          {ctxLoading
            ? 'Đang tổng hợp số liệu…'
            : ctxAt
              ? `Số liệu tính lúc ${ctxAt.toLocaleTimeString('vi-VN')}`
              : 'Chưa có số liệu'}
        </span>
        <button className="btn btn-outline btn-sm" disabled={ctxLoading} onClick={() => void loadContext()}>
          Cập nhật số liệu
        </button>
      </div>

      {msgs.length === 0 && (
        <div className="card" style={{ marginBottom: 12 }}>
          <p style={{ marginTop: 0 }}>
            Chào anh, em là trợ lý số liệu của quán. Anh cứ hỏi tự nhiên, ví dụ:
          </p>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
            {SUGGESTIONS.map((s) => (
              <button key={s} className="sb-chip" onClick={() => void send(s)}>
                {s}
              </button>
            ))}
          </div>
          <p className="small muted" style={{ marginBottom: 0 }}>
            Em trả lời từ số liệu tổng hợp (hôm nay, hôm qua, tuần này, tuần trước, tháng này và công nợ).
            Số liệu không có em sẽ nói rõ là không có, không đoán số.
          </p>
        </div>
      )}

      <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 12 }}>
        {msgs.map((m, i) =>
          m.role === 'user' ? (
            <div
              key={i}
              style={{
                alignSelf: 'flex-end',
                maxWidth: '85%',
                background: 'var(--brand)',
                color: '#fff',
                borderRadius: 14,
                padding: '9px 13px',
                whiteSpace: 'pre-wrap',
              }}
            >
              {m.text}
            </div>
          ) : (
            <div
              key={i}
              style={{
                alignSelf: 'flex-start',
                maxWidth: '92%',
                background: '#fff',
                border: '1px solid var(--line)',
                borderRadius: 14,
                padding: '9px 13px',
                whiteSpace: 'pre-wrap',
              }}
            >
              {m.text}
            </div>
          ),
        )}
        {sending && (
          <div
            style={{
              alignSelf: 'flex-start',
              background: '#fff',
              border: '1px solid var(--line)',
              borderRadius: 14,
              padding: '9px 13px',
            }}
            className="muted"
          >
            Đang hỏi AI…
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      <div
        className="row"
        style={{
          gap: 8,
          position: 'sticky',
          bottom: 12,
          background: 'var(--bg, #f6f7f6)',
          padding: '8px 0',
        }}
      >
        <input
          className="input grow"
          placeholder="Hỏi về doanh thu, lợi nhuận, món bán chạy…"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') void send();
          }}
          disabled={sending}
        />
        <button
          className="btn"
          style={{ minHeight: 48, display: 'inline-flex', alignItems: 'center', gap: 6 }}
          disabled={sending || !input.trim()}
          onClick={() => void send()}
        >
          <LineIcon name="chat" size={18} /> Gửi
        </button>
      </div>
    </div>
  );
}
