import AppIcon from './AppIcon';
import { LineIcon } from './LineIcon';
import { useAppTheme } from '../lib/useAppTheme';

// Icon cho các dòng menu (Cài đặt...): v3 dùng lineal SVG trong ô xanh nhạt,
// v1/v2 dùng icon 3D như cũ.
const LINE_MAP: Record<string, string> = {
  gear: 'gear',
  users: 'users',
  archive: 'archive',
  gift: 'package',
  star: 'star',
  key: 'key',
  card: 'card',
  bell: 'bell',
  cloud: 'archive',
  store: 'store',
  clipboard: 'clipboard',
  globe: 'globe',
  ledger: 'ledger',
  moneybag: 'wallet',
  truck: 'truck',
};

export function MenuIcon({ name, fallback }: { name: string; fallback: string }) {
  const theme = useAppTheme();
  if (theme === 'v3') {
    return (
      <span
        className="sb-ico-lineal"
        style={{
          width: 40,
          height: 40,
          borderRadius: 12,
          background: 'var(--brand-light, #EAF0FE)',
          color: 'var(--brand-darker, #2F5BC4)',
          display: 'inline-flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexShrink: 0,
        }}
      >
        <LineIcon name={LINE_MAP[name] ?? 'package'} size={22} />
      </span>
    );
  }
  return (
    <span className="sb-ico-box3d">
      <AppIcon name={name} fallback={fallback} size={34} />
    </span>
  );
}
