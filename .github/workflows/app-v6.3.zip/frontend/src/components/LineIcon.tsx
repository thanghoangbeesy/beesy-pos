import type { CSSProperties, ReactElement } from 'react';

// Bộ icon lineal (nét mảnh) cho theme V3 — SVG 24x24, stroke 1.5px, currentColor.
export const LINE_PATHS: Record<string, ReactElement> = {
  chart: (
    <>
      <path d="M4 20V10" />
      <path d="M10 20V4" />
      <path d="M16 20v-7" />
      <path d="M22 20H2" />
    </>
  ),
  receipt: (
    <>
      <path d="M5 3h14v18l-2.3-1.5L14.4 21l-2.4-1.5L9.6 21l-2.3-1.5L5 21V3z" />
      <path d="M9 8h6M9 12h6" />
    </>
  ),
  cart: (
    <>
      <path d="M3 4h2l2.4 12.2a1 1 0 0 0 1 .8h8.9a1 1 0 0 0 1-.8L20 8H6" />
      <circle cx="10" cy="20" r="1.4" />
      <circle cx="17" cy="20" r="1.4" />
    </>
  ),
  package: (
    <>
      <path d="M12 3l8 4v10l-8 4-8-4V7l8-4z" />
      <path d="M12 3v8m0 0l8-4m-8 4L4 7" />
      <path d="M12 11v10" />
    </>
  ),
  clipboard: (
    <>
      <rect x="5" y="4" width="14" height="17" rx="2" />
      <path d="M9 4a3 3 0 0 1 6 0" />
      <path d="M9 11h6M9 15h4" />
    </>
  ),
  gear: (
    <>
      <circle cx="12" cy="12" r="3.2" />
      <path d="M12 2.8v3M12 18.2v3M2.8 12h3M18.2 12h3M5.5 5.5l2.1 2.1M16.4 16.4l2.1 2.1M18.5 5.5l-2.1 2.1M7.6 16.4l-2.1 2.1" />
    </>
  ),
  wallet: (
    <>
      <path d="M3 7a2 2 0 0 1 2-2h13v3" />
      <path d="M3 7v10a2 2 0 0 0 2 2h16a1 1 0 0 0 1-1v-8a1 1 0 0 0-1-1H5" />
      <circle cx="16.5" cy="14" r="1.2" />
    </>
  ),
  ledger: (
    <>
      <path d="M6 3h12a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z" />
      <path d="M9 8h6M9 12h6M9 16h4" />
    </>
  ),
  globe: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M3 12h18M12 3c2.5 2.6 3.8 5.7 3.8 9S14.5 18.4 12 21c-2.5-2.6-3.8-5.7-3.8-9S9.5 5.6 12 3z" />
    </>
  ),
  archive: (
    <>
      <rect x="3" y="4" width="18" height="5" rx="1" />
      <path d="M5 9v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V9" />
      <path d="M10 13h4" />
    </>
  ),
  truck: (
    <>
      <path d="M2 6h12v10H2z" />
      <path d="M14 10h4l4 4v2h-8" />
      <circle cx="6.5" cy="18" r="1.8" />
      <circle cx="17.5" cy="18" r="1.8" />
    </>
  ),
  scroll: (
    <>
      <path d="M7 4h11a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H7" />
      <path d="M7 4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2" />
      <path d="M10 9h6M10 13h6" />
    </>
  ),
  key: (
    <>
      <circle cx="8" cy="12" r="4.5" />
      <path d="M12.5 12H21m-3 0v3m3-3v2" />
    </>
  ),
  users: (
    <>
      <circle cx="9" cy="8" r="3.5" />
      <path d="M2.5 20c.8-3.2 3.4-5 6.5-5s5.7 1.8 6.5 5" />
      <path d="M16 4.6a3.5 3.5 0 0 1 0 6.8M18.5 15.4c1.7.8 2.7 2.3 3 4.6" />
    </>
  ),
  plus: (
    <>
      <path d="M12 5v14M5 12h14" />
    </>
  ),
  minus: (
    <>
      <path d="M5 12h14" />
    </>
  ),
  search: (
    <>
      <circle cx="11" cy="11" r="7" />
      <path d="M20 20l-3.5-3.5" />
    </>
  ),
  home: (
    <>
      <path d="M3 11l9-8 9 8" />
      <path d="M5 10v10h14V10" />
    </>
  ),
  edit: (
    <>
      <path d="M14.5 5.5l4 4L8 20l-5 1 1-5L14.5 5.5z" />
      <path d="M13 7l4 4" />
    </>
  ),
  trash: (
    <>
      <path d="M4 7h16M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" />
      <path d="M6 7l1 13a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1l1-13" />
      <path d="M10 11v6M14 11v6" />
    </>
  ),
  save: (
    <>
      <path d="M5 3h11l3 3v13a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z" />
      <path d="M8 3v5h7V3M8 21v-7h8v7" />
    </>
  ),
  refresh: (
    <>
      <path d="M20 11a8 8 0 0 0-14.9-3M4 13a8 8 0 0 0 14.9 3" />
      <path d="M5 4v5h5M19 20v-5h-5" />
    </>
  ),
  x: (
    <>
      <path d="M6 6l12 12M18 6L6 18" />
    </>
  ),
  check: (
    <>
      <path d="M4 12.5l5 5L20 6.5" />
    </>
  ),
  flask: (
    <>
      <path d="M10 3h4M10 3v6l-5.5 9.5A2 2 0 0 0 6.2 21h11.6a2 2 0 0 0 1.7-2.5L14 9V3" />
      <path d="M8 15h8" />
    </>
  ),
  phone: (
    <>
      <rect x="7" y="2" width="10" height="20" rx="2" />
      <path d="M11 18h2" />
    </>
  ),
  card: (
    <>
      <rect x="2" y="5" width="20" height="14" rx="2" />
      <path d="M2 10h20" />
    </>
  ),
  star: (
    <>
      <path d="M12 3l2.7 5.6 6.1.8-4.5 4.2 1.1 6-5.4-3-5.4 3 1.1-6L3.2 9.4l6.1-.8L12 3z" />
    </>
  ),
  bell: (
    <>
      <path d="M6 10a6 6 0 0 1 12 0c0 5 2 6 2 6H4s2-1 2-6" />
      <path d="M10 20a2 2 0 0 0 4 0" />
    </>
  ),
  store: (
    <>
      <path d="M4 7l1.5-4h13L20 7" />
      <path d="M4 7h16v3a2.5 2.5 0 0 1-5 0 2.5 2.5 0 0 1-5 0 2.5 2.5 0 0 1-5 0" />
      <path d="M5.5 12.5V21h13v-8.5" />
      <path d="M9.5 21v-5h5v5" />
    </>
  ),
  folder: (
    <>
      <path d="M3 6a2 2 0 0 1 2-2h4l2 2.5h8a2 2 0 0 1 2 2V18a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6z" />
    </>
  ),
  download: (
    <>
      <path d="M12 4v11m0 0l-4-4m4 4l4-4" />
      <path d="M4 19h16" />
    </>
  ),
  palette: (
    <>
      <path d="M12 3a9 9 0 1 0 0 18c1.5 0 2-1 1.4-2.1-.7-1.2-.2-2.9 1.3-2.9H17a4 4 0 0 0 4-4c0-4.9-4-9-9-9z" />
      <circle cx="8.5" cy="10.5" r="1.1" />
      <circle cx="12" cy="7.5" r="1.1" />
      <circle cx="15.5" cy="10.5" r="1.1" />
    </>
  ),
  gift: (
    <>
      <rect x="4" y="9" width="16" height="4" rx="1" />
      <path d="M6 13v7a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1v-7" />
      <path d="M12 9v12" />
      <path d="M12 9C12 6 10 4.5 8.3 4.5c-1.4 0-2.3 1-2 2.2C6.6 8 9 9 12 9zm0 0c0-3 2-4.5 3.7-4.5 1.4 0 2.3 1 2 2.2C17.4 8 15 9 12 9z" />
    </>
  ),
  ticket: (
    <>
      <path d="M4 7a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v3a2 2 0 0 0 0 4v3a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-3a2 2 0 0 0 0-4V7z" />
      <path d="M14 5v2m0 3v2m0 3v2" />
    </>
  ),
  clock: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5l3 2" />
    </>
  ),
  tag: (
    <>
      <path d="M20.6 13.4 13.4 20.6a2 2 0 0 1-2.8 0L3 13V3h10l7.6 7.6a2 2 0 0 1 0 2.8z" />
      <circle cx="7.5" cy="7.5" r="1.2" />
    </>
  ),
  alert: (
    <>
      <path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z" />
      <path d="M12 9v4m0 4h.01" />
    </>
  ),
  wifi: (
    <>
      <path d="M1.4 9a16 16 0 0 1 21.2 0" />
      <path d="M5 12.6a11 11 0 0 1 14.1 0" />
      <path d="M8.5 16.1a6 6 0 0 1 7 0" />
      <path d="M12 20h.01" />
    </>
  ),
  camera: (
    <>
      <path d="M21 19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h3l2-3h4l2 3h3a2 2 0 0 1 2 2z" />
      <circle cx="12" cy="13" r="4" />
    </>
  ),
  lock: (
    <>
      <rect x="5" y="10" width="14" height="10" rx="2" />
      <path d="M8 10V7a4 4 0 0 1 8 0v3" />
      <circle cx="12" cy="15" r="1.3" />
    </>
  ),
  eye: (
    <>
      <path d="M2.5 12C4.8 7 8.2 4.8 12 4.8s7.2 2.2 9.5 7.2c-2.3 5-5.7 7.2-9.5 7.2S4.8 17 2.5 12z" />
      <circle cx="12" cy="12" r="3.1" />
    </>
  ),
  'eye-off': (
    <>
      <path d="M2.5 12C4.8 7 8.2 4.8 12 4.8s7.2 2.2 9.5 7.2c-2.3 5-5.7 7.2-9.5 7.2S4.8 17 2.5 12z" />
      <circle cx="12" cy="12" r="3.1" />
      <path d="M4 4l16 16" />
    </>
  ),
  chat: (
    <>
      <rect x="3" y="4.5" width="18" height="12.5" rx="3" />
      <path d="M8 17v3.5l4.5-3.5" />
    </>
  ),
};

export function LineIcon({
  name,
  size = 22,
  strokeWidth = 1.5,
  style,
}: {
  name: keyof typeof LINE_PATHS | string;
  size?: number;
  strokeWidth?: number;
  style?: CSSProperties;
}) {
  const paths = (LINE_PATHS as Record<string, ReactElement>)[name];
  if (!paths) return null;
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      style={{ display: 'block', flexShrink: 0, ...style }}
      aria-hidden
    >
      {paths}
    </svg>
  );
}
