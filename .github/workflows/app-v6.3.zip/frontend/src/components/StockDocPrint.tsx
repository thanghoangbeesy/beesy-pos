// In phieu nhap kho (mau 01-VT) / phieu xuat kho (mau 02-VT) - v5.13.
// Dung lai co che in cua BillPrint: render vao #print-root voi vung
// #report-print-area (CSS @media print A4 san co trong index.css) roi
// window.print(). Man hinh xem truoc chinh la Sheet chi tiet phieu.
//
// CO SO DON GIA: phieu nhap dung don gia nhap tren tung dong cua phieu;
// phieu xuat dung don gia xuat tren phieu, dong nao khong co don gia xuat
// (VD xuat huy) thi dung gia von binh quan hien tai cua nguyen lieu va
// ghi chu ro "gia von" duoi bang.
import { useEffect, useRef } from 'react';
import { getSettings, listIngredients } from '../lib/db';
import { formatVND } from '../lib/format';
import { moneyToWords } from '../lib/number-words';
import type { PurchaseOrder, StockExport } from '../lib/types';

export type StockDocPrintData =
  | { kind: 'in'; doc: PurchaseOrder; reasonLabel?: string | null }
  | { kind: 'out'; doc: StockExport; reasonLabel?: string | null };

function esc(s: string): string {
  return s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c] ?? c);
}

function fmtQty(v: number): string {
  const n = parseFloat(v.toFixed(3));
  return n.toLocaleString('vi-VN', { maximumFractionDigits: 3 });
}

interface PrintLine {
  name: string;
  unit: string;
  qty: number;
  price: number;
  total: number;
  costFallback: boolean;
}

export function StockDocPrint({ data, onDone }: { data: StockDocPrintData; onDone: () => void }) {
  const doneRef = useRef(false);
  const finish = () => {
    if (doneRef.current) return;
    doneRef.current = true;
    const r = document.getElementById('print-root');
    if (r) r.innerHTML = '';
    onDone();
  };

  useEffect(() => {
    let root = document.getElementById('print-root');
    if (!root) {
      root = document.createElement('div');
      root.id = 'print-root';
      document.body.appendChild(root);
    }
    let cancelled = false;
    (async () => {
      const [settings, ingredients] = await Promise.all([
        getSettings().catch(() => ({}) as Record<string, string>),
        listIngredients(false).catch(() => []),
      ]);
      if (cancelled) return;
      const costById = new Map(ingredients.map((i) => [i.id, i.cost_per_unit]));
      const shopName = settings.shop_name || 'Beesy Coffee & Tea';
      const shopAddress = settings.shop_address || '';
      const shopPhone = settings.shop_phone || '';

      const isIn = data.kind === 'in';
      const doc = data.doc;
      const lines: PrintLine[] = isIn
        ? (doc as PurchaseOrder).items.map((it) => ({
            name: it.ingredient_name,
            unit: it.unit,
            qty: it.qty,
            price: it.unit_cost,
            total: it.line_total,
            costFallback: false,
          }))
        : (doc as StockExport).items.map((it) => {
            const hasPrice = it.unit_price > 0;
            const price = hasPrice ? it.unit_price : costById.get(it.ingredient_id) ?? 0;
            return {
              name: it.ingredient_name,
              unit: it.unit,
              qty: it.qty,
              price,
              total: hasPrice ? it.line_total : Math.round(it.qty * price),
              costFallback: !hasPrice,
            };
          });
      const total = lines.reduce((s, l) => s + l.total, 0);
      const anyFallback = lines.some((l) => l.costFallback);
      const [yy, mm, dd] = doc.business_date.split('-');
      const partner = isIn
        ? (doc as PurchaseOrder).supplier_name
        : (doc as StockExport).supplier_name ?? '';
      const partnerLabel = isIn ? 'Họ tên người giao hàng' : 'Họ tên người nhận hàng';
      const reasonText = [data.reasonLabel, doc.note].filter(Boolean).join(' — ');
      const signCols = isIn
        ? ['Người lập phiếu', 'Người giao hàng', 'Thủ kho', 'Kế toán trưởng']
        : ['Người lập phiếu', 'Người nhận hàng', 'Thủ kho', 'Kế toán trưởng'];

      const rows = lines
        .map(
          (l, i) => `<tr>
            <td style="text-align:center">${i + 1}</td>
            <td>${esc(l.name)}</td>
            <td style="text-align:center">—</td>
            <td style="text-align:center">${esc(l.unit)}</td>
            <td class="r">${fmtQty(l.qty)}</td>
            <td class="r">${formatVND(l.price)}${l.costFallback ? ' *' : ''}</td>
            <td class="r">${formatVND(l.total)}</td>
          </tr>`,
        )
        .join('');

      root!.innerHTML = `
      <div id="report-print-area">
        <div style="display:flex;justify-content:space-between;gap:16px;align-items:flex-start">
          <div>
            <div style="font-weight:700;text-transform:uppercase">${esc(shopName)}</div>
            ${shopAddress ? `<div class="small">${esc(shopAddress)}</div>` : ''}
            ${shopPhone ? `<div class="small">ĐT: ${esc(shopPhone)}</div>` : ''}
          </div>
          <div style="text-align:center;flex-shrink:0">
            <div style="font-weight:700">Mẫu số: ${isIn ? '01-VT' : '02-VT'}</div>
            <div class="small">(Ban hành theo Thông tư số 133/2016/TT-BTC<br/>ngày 26/8/2016 của Bộ Tài chính)</div>
          </div>
        </div>
        <h2>PHIẾU ${isIn ? 'NHẬP' : 'XUẤT'} KHO</h2>
        <div class="center">Ngày ${dd} tháng ${mm} năm ${yy}</div>
        <div class="center">Số phiếu: <b>${esc(doc.code)}</b></div>
        <div style="margin-top:10px">
          <div>${partnerLabel}: <b>${esc(partner)}</b></div>
          <div>Lý do ${isIn ? 'nhập' : 'xuất'}: ${esc(reasonText)}</div>
          <div>${isIn ? 'Nhập' : 'Xuất'} tại kho: <b>${esc(doc.warehouse_name)}</b></div>
        </div>
        <table>
          <thead>
            <tr>
              <th style="text-align:center;width:36px">STT</th>
              <th>Tên hàng hóa / nguyên liệu</th>
              <th style="text-align:center;width:52px">Mã</th>
              <th style="text-align:center;width:64px">Đơn vị tính</th>
              <th class="r" style="width:80px">Số lượng</th>
              <th class="r" style="width:110px">Đơn giá</th>
              <th class="r" style="width:120px">Thành tiền</th>
            </tr>
          </thead>
          <tbody>
            ${rows}
            <tr>
              <td colspan="6" style="text-align:right"><b>Tổng cộng</b></td>
              <td class="r"><b>${formatVND(total)}</b></td>
            </tr>
          </tbody>
        </table>
        ${anyFallback ? '<div class="small">* Đơn giá tính theo giá vốn bình quân hiện tại của nguyên liệu (dòng phiếu không ghi đơn giá xuất).</div>' : ''}
        <div style="margin-top:6px"><b>Tổng số tiền (viết bằng chữ):</b> <i>${esc(moneyToWords(total))}</i></div>
        <div style="display:flex;justify-content:space-between;margin-top:28px;text-align:center">
          ${signCols.map((c) => `<div style="flex:1"><div style="font-weight:700">${c}</div><div class="small"><i>(Ký, họ tên)</i></div></div>`).join('')}
        </div>
      </div>`;

      const onAfter = () => finish();
      window.addEventListener('afterprint', onAfter, { once: true });
      setTimeout(() => {
        if (!cancelled) window.print();
      }, 80);
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return null;
}
