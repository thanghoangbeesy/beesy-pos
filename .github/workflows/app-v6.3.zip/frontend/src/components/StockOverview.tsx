// Canh bao ton kho cho trang Tong quan:
// - Panel "Canh bao ton kho": dung lai dung du lieu listLowStock cua
//   trang Ton kho (stock <= min_stock theo tung kho, ton trong cong tac
//   canh bao rieng tung nguyen lieu - v5.14).
// - KPI "Gia tri ton kho hien tai" da BO khoi Tong quan o v5.14 theo yeu
//   cau cua Hoang: gia tri ton kho chuyen thanh Bao cao ton kho rieng
//   (tab Ton kho o trang Bao cao) nen hook nay chi tai canh bao.
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { listLowStock } from '../lib/db';
import { TIcon } from './TIcon';
import type { Warehouse } from '../lib/types';

export interface LowStockRow {
  ingredient_id: string;
  name: string;
  unit: string;
  warehouse_id: string;
  warehouse_name: string;
  stock: number;
  min_stock: number;
}

export function useStockOverview(warehouses: Warehouse[]): { low: LowStockRow[] } {
  const [low, setLow] = useState<LowStockRow[]>([]);

  useEffect(() => {
    if (warehouses.length === 0) return;
    let cancelled = false;
    (async () => {
      try {
        const ids = warehouses.map((w) => w.id);
        const lowRows = await listLowStock(ids);
        if (cancelled) return;
        // Het hang len truoc, sau do ti le ton/toi-thieu thap nhat truoc.
        const ratio = (r: LowStockRow) => (r.min_stock > 0 ? r.stock / r.min_stock : 0);
        setLow(
          [...lowRows].sort((a, b) => {
            const aOut = a.stock <= 0 ? 0 : 1;
            const bOut = b.stock <= 0 ? 0 : 1;
            if (aOut !== bOut) return aOut - bOut;
            return ratio(a) - ratio(b);
          }),
        );
      } catch {
        // Panel phu: loi tai ton kho khong duoc chan bao cao chinh.
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [warehouses]);

  return { low };
}

function fmtQty(v: number): string {
  const n = parseFloat(v.toFixed(3));
  return n.toLocaleString('vi-VN', { maximumFractionDigits: 3 });
}

/** Panel canh bao ton kho - dung chung PC/Mobile, chi khac class vo card. */
export function LowStockPanel({
  low,
  multiWarehouse,
  variant,
}: {
  low: LowStockRow[];
  multiWarehouse: boolean;
  variant: 'pc' | 'mobile';
}) {
  const navigate = useNavigate();
  const cardClass = variant === 'pc' ? 'pc-card' : 'ov-card';
  const headClass = variant === 'pc' ? 'pc-card-head' : 'ov-card-head';
  return (
    <div className={cardClass}>
      <div className={headClass}>
        <h3>
          Cảnh báo tồn kho
          {low.length > 0 && (
            <span
              style={{
                marginLeft: 8,
                background: '#FEF3C7',
                color: '#92400E',
                borderRadius: 999,
                padding: '1px 8px',
                fontSize: 12,
                fontWeight: 700,
              }}
            >
              {low.length}
            </span>
          )}
        </h3>
        <button className={variant === 'pc' ? 'pc-link' : 'ov-link'} onClick={() => navigate('/inventory')}>
          Xem tồn kho →
        </button>
      </div>
      {low.length === 0 ? (
        <p className="small" style={{ padding: '0 0 4px', margin: 0, color: 'var(--brand-dark, #15803d)' }}>
          <TIcon emoji="✅" size={14} /> Tất cả nguyên liệu đều đủ tồn.
        </p>
      ) : (
        <div>
          {low.slice(0, 10).map((r) => {
            const pct = r.min_stock > 0 ? Math.min(100, Math.max(0, (r.stock / r.min_stock) * 100)) : r.stock <= 0 ? 0 : 100;
            const out = r.stock <= 0;
            return (
              <div
                key={`${r.warehouse_id}-${r.ingredient_id}`}
                onClick={() => navigate('/inventory')}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 12,
                  padding: '8px 0',
                  borderTop: '1px solid var(--line)',
                  cursor: 'pointer',
                }}
              >
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{r.name}</div>
                  <div className="small muted">
                    {multiWarehouse ? `${r.warehouse_name} · ` : ''}
                    Còn {fmtQty(r.stock)} / tối thiểu {fmtQty(r.min_stock)} {r.unit}
                    {out && <span style={{ color: 'var(--red, #dc2626)', fontWeight: 700 }}> · Hết hàng</span>}
                  </div>
                </div>
                <div
                  style={{ width: 72, height: 6, borderRadius: 999, background: '#E5E7EB', overflow: 'hidden', flexShrink: 0 }}
                  aria-hidden
                >
                  <div style={{ width: `${pct}%`, height: '100%', background: out ? '#DC2626' : '#F59E0B', borderRadius: 999 }} />
                </div>
              </div>
            );
          })}
          {low.length > 10 && <p className="small muted" style={{ margin: '4px 0 8px' }}>… và {low.length - 10} nguyên liệu nữa</p>}
        </div>
      )}
    </div>
  );
}
