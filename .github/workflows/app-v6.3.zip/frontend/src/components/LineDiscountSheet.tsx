import { useState } from 'react';
import { Sheet } from './Sheet';
import { formatVND } from '../lib/format';
import { discountAmountFor } from '../lib/types';
import type { CartLine } from '../lib/types';

/**
 * Form giảm giá riêng cho 1 dòng món (% hoặc số tiền) - dùng chung cho
 * giỏ hàng (POS) và màn xác nhận thanh toán (CheckoutModal). Từ v5.12
 * đặt ngay trong màn thanh toán theo yêu cầu của Hoàng: giảm trên
 * từng dòng món tại chỗ, không tách màn hình riêng thêm thao tác.
 */
export function LineDiscountSheet({
  line,
  onClose,
  onApply,
}: {
  line: CartLine;
  onClose: () => void;
  onApply: (type: 'percent' | 'amount' | null, value: number | null) => void;
}) {
  const gross =
    line.qty * (line.product.base_price + line.modifiers.reduce((a, m) => a + m.price_delta, 0));
  const [type, setType] = useState<'percent' | 'amount'>(line.discountType ?? 'percent');
  const [raw, setRaw] = useState(line.discountValue != null ? String(line.discountValue) : '');
  const value = Math.max(0, parseInt(raw.replace(/\D/g, ''), 10) || 0);
  const disc = discountAmountFor(gross, type, value);
  return (
    <Sheet title={`🏷️ Giảm giá: ${line.product.name}`} onClose={onClose}>
      <div className="small muted" style={{ marginBottom: 8 }}>
        Tổng dòng: <b className="money">{formatVND(gross)}</b> ({line.qty} x{' '}
        {formatVND(line.product.base_price + line.modifiers.reduce((a, m) => a + m.price_delta, 0))})
      </div>
      <div className="row" style={{ gap: 8, marginBottom: 8 }}>
        <button
          className={`btn btn-sm ${type === 'percent' ? '' : 'btn-outline'}`}
          onClick={() => setType('percent')}
        >
          Theo %
        </button>
        <button
          className={`btn btn-sm ${type === 'amount' ? '' : 'btn-outline'}`}
          onClick={() => setType('amount')}
        >
          Số tiền
        </button>
      </div>
      {type === 'percent' && (
        <div className="row" style={{ gap: 6, marginBottom: 8, flexWrap: 'wrap' }}>
          {[5, 10, 15, 20, 30, 50].map((p) => (
            <button key={p} className="btn btn-outline btn-sm" onClick={() => setRaw(String(p))}>
              {p}%
            </button>
          ))}
        </div>
      )}
      <input
        className="input"
        inputMode="numeric"
        autoFocus
        value={raw}
        onChange={(e) => setRaw(e.target.value)}
        placeholder={type === 'percent' ? 'Nhập % giảm (0-100)' : 'Nhập số tiền giảm (đ)'}
        style={{ marginBottom: 8 }}
      />
      {disc > 0 && (
        <div className="small" style={{ marginBottom: 8, color: 'var(--green)', fontWeight: 600 }}>
          Giảm {formatVND(disc)} → dòng còn {formatVND(gross - disc)}
        </div>
      )}
      <div className="row" style={{ gap: 8 }}>
        {line.discountType && (
          <button className="btn btn-outline" onClick={() => onApply(null, null)}>
            Xóa giảm
          </button>
        )}
        <button className="btn grow" disabled={value <= 0} onClick={() => onApply(type, value)}>
          Áp dụng
        </button>
      </div>
    </Sheet>
  );
}
