// Nhập hàng & nhà cung cấp: phiếu nhập (cộng tồn + công nợ NCC + chi quỹ),
// quản lý NCC (trả nợ), cảnh báo nguyên liệu sắp hết.
import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  DbError,
  createPurchaseOrder,
  createStockExport,
  deletePurchaseOrder,
  deleteStockExport,
  deleteSupplier,
  getAllowedWarehouses,
  getFunds,
  listIngredients,
  listLowStock,
  listPurchaseOrders,
  listStockExports,
  listSuppliers,
  paySupplierDebt,
  saveSupplier,
  getStockReasons,
  exportReasonBehavior,
  saveStockReasons,
} from '../lib/db';
import type { CreatePOItemInput, CreateStockExportItemInput } from '../lib/db';
import { formatVND, todayVN } from '../lib/format';
import type { Fund, Ingredient, PurchaseOrder, StockExport, StockExportReason, Supplier, Warehouse,
  StockReason,
  StockReasonsSettings,
  StockExportBehavior,
} from '../lib/types';
import { Sheet } from '../components/Sheet';
import { AttachmentsInput, AttachmentsView } from '../components/Attachments';
import { useAuth } from '../lib/auth';
import { canUsePro } from '../lib/license';
import { useToast } from '../components/Toast';

type Tab = 'po' | 'export' | 'supplier' | 'low' | 'reasons';

export function Purchase() {
  const toast = useToast();
  const { can } = useAuth();
  const isOwner = can('cashbook.settings');
  const [searchParams] = useSearchParams();
  const initialTab: Tab = ((): Tab => {
    const t = searchParams.get('tab');
    return t === 'export' || t === 'supplier' || t === 'low' || t === 'reasons' ? t : 'po';
  })();
  const [tab, setTab] = useState<Tab>(initialTab);
  const [busy, setBusy] = useState(true);
  const [pos, setPos] = useState<PurchaseOrder[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [low, setLow] = useState<Awaited<ReturnType<typeof listLowStock>>>([]);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [poForm, setPoForm] = useState(false);
  const [exports, setExports] = useState<StockExport[]>([]);
  const [exportForm, setExportForm] = useState(false);
  const [proOk, setProOk] = useState<boolean | null>(null);
  const [supForm, setSupForm] = useState<Supplier | 'new' | null>(null);
  const [payForm, setPayForm] = useState<Supplier | null>(null);
  const [reasons, setReasons] = useState<StockReasonsSettings | null>(null);

  const load = async () => {
    setBusy(true);
    try {
      const allowed = await getAllowedWarehouses().catch(() => ({ warehouses: [] as Warehouse[], isOwner: false }));
      setWarehouses(allowed.warehouses);
      const ids = allowed.isOwner ? undefined : allowed.warehouses.map((w) => w.id);
      const [p, ex, s, l, r] = await Promise.all([
        listPurchaseOrders(100),
        listStockExports(100),
        listSuppliers(),
        listLowStock(ids),
        getStockReasons(),
      ]);
      setReasons(r);
      setPos(p);
      setExports(ex);
      setSuppliers(s);
      setLow(l);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tải được dữ liệu');
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => {
    canUsePro().then((v) => {
      setProOk(v);
      if (v) void load();
    }).catch(() => setProOk(true));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const delPO = async (po: PurchaseOrder) => {
    if (!window.confirm(`Xóa phiếu nhập ${po.code}? Tồn kho, khoản chi và công nợ liên quan sẽ được hoàn tác.`)) return;
    try {
      await deletePurchaseOrder(po.id);
      toast.show('Đã xóa phiếu nhập');
      void load();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Xóa phiếu thất bại');
    }
  };

  const delExport = async (ex: StockExport) => {
    if (!window.confirm(`Xóa phiếu xuất ${ex.code}? Tồn kho, khoản thu và công nợ liên quan sẽ được hoàn tác.`)) return;
    try {
      await deleteStockExport(ex.id);
      toast.show('Đã xóa phiếu xuất');
      void load();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Xóa phiếu thất bại');
    }
  };

  return (
    <div className="page">
      <h1 className="page-title">Nhập Xuất Hàng</h1>
      <div className="row" style={{ gap: 8, marginBottom: 12 }}>
        {(
          [
            ['po', 'Phiếu nhập'],
            ['export', 'Phiếu xuất'],
            ['supplier', 'Nhà cung cấp'],
            ['low', `Cần nhập${low.length > 0 ? ` (${low.length})` : ''}`],
            ...(isOwner ? [['reasons', 'Lý do'] as [Tab, string]] : []),
          ] as [Tab, string][]
        ).map(([k, label]) => (
          <button key={k} type="button" className={`sb-chip${tab === k ? ' selected' : ''}`} onClick={() => setTab(k)}>
            {label}
          </button>
        ))}
      </div>

      {proOk === null || busy ? (
        <p className="muted" style={{ textAlign: 'center' }}>
          Đang tải…
        </p>
      ) : !proOk ? (
        <div className="card" style={{ textAlign: 'center', padding: '40px 20px' }}>
          <div style={{ fontSize: 48 }}>🔒</div>
          <h3>Tính năng Pro</h3>
          <p className="muted">Nhập hàng & nhà cung cấp thuộc gói Nâng cao (Pro).<br />Vào Cài đặt → Giấy phép để kích hoạt.</p>
        </div>
      ) : tab === 'po' ? (
        <>
          <button className="btn btn-block" style={{ marginBottom: 12 }} onClick={() => setPoForm(true)}>
            ＋ Tạo phiếu nhập
          </button>
          {pos.length === 0 ? (
            <div className="sb-empty">
              <div className="eico">📥</div>
              <p>Chưa có phiếu nhập nào.</p>
            </div>
          ) : (
            <div className="sb-section" style={{ padding: '4px 16px' }}>
              {pos.map((p) => (
                <div key={p.id} className="sb-row" style={{ cursor: 'default', paddingRight: isOwner ? 42 : undefined, position: 'relative' }}>
                  <span className="rbody">
                    <span className="rtitle" style={{ fontWeight: 700 }}>
                      {p.code} <span className="rsub">· {p.supplier_name}</span>
                    </span>
                    <span className="rsub">
                      {p.items.length} nguyên liệu · {p.warehouse_name} · {p.business_date}
                      {p.reason_id && reasons?.import_reasons.find((r) => r.id === p.reason_id) && (
                        <> · {reasons.import_reasons.find((r) => r.id === p.reason_id)?.label}</>
                      )}
                      {p.debt_amount > 0 && <span style={{ color: 'var(--red)' }}> · Nợ NCC {formatVND(p.debt_amount)}</span>}
                    </span>
                    <AttachmentsView value={p.attachments} />
                  </span>
                  <span className="rbody" style={{ alignItems: 'flex-end', flex: '0 0 auto' }}>
                    <span className="ramount">{formatVND(p.subtotal)}</span>
                    {p.paid_amount > 0 && <span className="rsub">Đã trả {formatVND(p.paid_amount)}</span>}
                  </span>
                  {isOwner && (
                    <button type="button" className="sb-row-del" aria-label={`Xóa ${p.code}`} onClick={() => void delPO(p)}>
                      ×
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </>
      ) : tab === 'export' ? (
        <>
          <button className="btn btn-block" style={{ marginBottom: 12 }} onClick={() => setExportForm(true)}>
            ＋ Tạo phiếu xuất
          </button>
          {exports.length === 0 ? (
            <div className="sb-empty">
              <div className="eico">📤</div>
              <p>Chưa có phiếu xuất nào.</p>
            </div>
          ) : (
            <div className="sb-section" style={{ padding: '4px 16px' }}>
              {exports.map((x) => (
                <div key={x.id} className="sb-row" style={{ cursor: 'default', paddingRight: isOwner ? 42 : undefined, position: 'relative' }}>
                  <span className="rbody">
                    <span className="rtitle" style={{ fontWeight: 700 }}>
                      {x.code}{' '}
                      <span className="rsub">
                        · {reasons?.export_reasons.find((r) => r.id === x.reason)?.label ?? 'Xuất kho'}
                      </span>
                    </span>
                    <span className="rsub">
                      {x.items.length} nguyên liệu · {x.warehouse_name} · {x.business_date}
                      {x.supplier_name && <> · {x.supplier_name}</>}
                    </span>
                    <AttachmentsView value={x.attachments} />
                  </span>
                  <span className="rbody" style={{ alignItems: 'flex-end', flex: '0 0 auto' }}>
                    <span className="ramount">{formatVND(x.subtotal)}</span>
                    {x.received_amount > 0 && <span className="rsub">Đã thu {formatVND(x.received_amount)}</span>}
                  </span>
                  {isOwner && (
                    <button type="button" className="sb-row-del" aria-label={`Xóa ${x.code}`} onClick={() => void delExport(x)}>
                      ×
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </>
      ) : tab === 'supplier' ? (
        <>
          <button className="btn btn-block" style={{ marginBottom: 12 }} onClick={() => setSupForm('new')}>
            ＋ Thêm nhà cung cấp
          </button>
          {suppliers.length === 0 ? (
            <div className="sb-empty">
              <div className="eico">🏭</div>
              <p>Chưa có nhà cung cấp nào.</p>
            </div>
          ) : (
            <div className="sb-section" style={{ padding: '4px 16px' }}>
              {suppliers.map((s) => (
                <div key={s.id} className="sb-row" style={{ cursor: 'default', opacity: s.active ? 1 : 0.6 }}>
                  <span className="rbody">
                    <span className="rtitle" style={{ fontWeight: 700 }}>
                      {s.name}
                    </span>
                    <span className="rsub">
                      {s.phone}
                      {s.debt > 0 && <span style={{ color: 'var(--red)', fontWeight: 700 }}> · Nợ {formatVND(s.debt)}</span>}
                    </span>
                  </span>
                  <span className="row" style={{ gap: 6, flex: '0 0 auto' }}>
                    {s.debt > 0 && (
                      <button type="button" className="sb-chip" onClick={() => setPayForm(s)}>
                        Trả nợ
                      </button>
                    )}
                    <button type="button" className="sb-chip" onClick={() => setSupForm(s)}>
                      Sửa
                    </button>
                  </span>
                </div>
              ))}
            </div>
          )}
        </>
      ) : tab === 'low' ? (
        low.length === 0 ? (
          <div className="sb-empty">
            <div className="eico">✅</div>
            <p>Tồn kho đang đủ, chưa cần nhập gì.</p>
          </div>
        ) : (
          <div className="sb-section" style={{ padding: '4px 16px' }}>
            {low.map((l, i) => (
              <div key={`${l.warehouse_id}_${l.ingredient_id}_${i}`} className="sb-row" style={{ cursor: 'default' }}>
                <span className="rbody">
                  <span className="rtitle" style={{ fontWeight: 600 }}>
                    {l.name}
                  </span>
                  <span className="rsub">{l.warehouse_name}</span>
                </span>
                <span className="rbody" style={{ alignItems: 'flex-end', flex: '0 0 auto' }}>
                  <span className="ramount" style={{ color: 'var(--red)' }}>
                    {l.stock} {l.unit}
                  </span>
                  <span className="rsub">Ngưỡng {l.min_stock}</span>
                </span>
              </div>
            ))}
          </div>
        )
      ) : tab === 'reasons' ? (
        isOwner ? (
          <ReasonsTab reasons={reasons} onSaved={async () => { const r = await getStockReasons(); setReasons(r); }} />
        ) : (
          <div className="sb-empty"><p>Chỉ chủ quán quản lý lý do.</p></div>
        )
      ) : null}

      {poForm && (
        <PurchaseOrderForm
          warehouses={warehouses}
          reasons={reasons}
          onClose={() => setPoForm(false)}
          onSaved={() => {
            setPoForm(false);
            void load();
          }}
        />
      )}
      {exportForm && (
        <StockExportForm
          warehouses={warehouses}
          reasons={reasons}
          onClose={() => setExportForm(false)}
          onSaved={() => {
            setExportForm(false);
            void load();
          }}
        />
      )}
      {supForm && (
        <SupplierForm
          initial={supForm === 'new' ? null : supForm}
          onClose={() => setSupForm(null)}
          onSaved={() => {
            setSupForm(null);
            void load();
          }}
        />
      )}
      {payForm && (
        <PaySupplierSheet
          supplier={payForm}
          warehouses={warehouses}
          onClose={() => setPayForm(null)}
          onSaved={() => {
            setPayForm(null);
            void load();
          }}
        />
      )}
    </div>
  );
}

function PurchaseOrderForm({
  warehouses,
  reasons,
  onClose,
  onSaved,
}: {
  warehouses: Warehouse[];
  reasons: StockReasonsSettings | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const toast = useToast();
  const [ingredients, setIngredients] = useState<Ingredient[]>([]);
  const [funds, setFunds] = useState<Fund[]>([]);
  const [supplierId, setSupplierId] = useState('');
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [reasonId, setReasonId] = useState('');
  const [attachments, setAttachments] = useState<string[]>([]);
  const [warehouseId, setWarehouseId] = useState(warehouses[0]?.id ?? '');
  const [businessDate, setBusinessDate] = useState(todayVN());
  const [rows, setRows] = useState<{ ingredientId: string; qty: string; unitCost: string }[]>([
    { ingredientId: '', qty: '', unitCost: '' },
  ]);
  const [paid, setPaid] = useState('');
  const [fundId, setFundId] = useState('');
  const [note, setNote] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    listIngredients(true).then(setIngredients).catch(() => {});
    getFunds().then(setFunds).catch(() => {});
    listSuppliers().then(setSuppliers).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const items: CreatePOItemInput[] = rows
    .map((r) => ({
      ingredientId: r.ingredientId,
      qty: parseFloat(r.qty) || 0,
      unitCost: parseInt(r.unitCost.replace(/\D/g, ''), 10) || 0,
    }))
    .filter((r) => r.ingredientId && r.qty > 0);
  const total = rows.reduce((s, r) => {
    const q = parseFloat(r.qty) || 0;
    const c = parseInt(r.unitCost.replace(/\D/g, ''), 10) || 0;
    return s + q * c;
  }, 0);
  const paidNum = parseInt(paid.replace(/\D/g, ''), 10) || 0;

  const setRow = (i: number, patch: Partial<(typeof rows)[number]>) =>
    setRows((prev) => prev.map((r, j) => (j === i ? { ...r, ...patch } : r)));

  const submit = async () => {
    if (!warehouseId) return toast.show('Chọn kho nhập');
    if (items.length === 0) return toast.show('Thêm ít nhất một nguyên liệu');
    setSaving(true);
    try {
      await createPurchaseOrder({
        supplierId: supplierId || null,
        warehouseId,
        items,
        paidAmount: paidNum,
        fundId: paidNum > 0 ? fundId || null : null,
        note: note.trim() || null,
        businessDate,
        reasonId: reasonId || null,
        attachments,
      });
      toast.show('Đã tạo phiếu nhập ✅');
      onSaved();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Tạo phiếu nhập thất bại');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Sheet title="📥 Tạo phiếu nhập" onClose={onClose}>
      <div className="row" style={{ gap: 8 }}>
        <div className="field" style={{ flex: 1 }}>
          <label>Nhà cung cấp</label>
          <select className="input" value={supplierId} onChange={(e) => setSupplierId(e.target.value)}>
            <option value="">Mua lẻ (không NCC)</option>
            {suppliers.filter((s) => s.active).map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        </div>
        <div className="field" style={{ flex: 1 }}>
          <label>Kho nhập</label>
          <select className="input" value={warehouseId} onChange={(e) => setWarehouseId(e.target.value)}>
            {warehouses.map((w) => (
              <option key={w.id} value={w.id}>
                {w.name}
              </option>
            ))}
          </select>
        </div>
        <div className="field" style={{ flex: 1 }}>
          <label>Lý do nhập</label>
          <select className="input" value={reasonId} onChange={(e) => setReasonId(e.target.value)}>
            <option value="">— Chọn lý do —</option>
            {(reasons?.import_reasons ?? []).map((r) => (
              <option key={r.id} value={r.id}>
                {r.label}
              </option>
            ))}
          </select>
        </div>
      </div>
      <div className="field">
        <label>Ngày nhập</label>
        <input className="input" type="date" max={todayVN()} value={businessDate} onChange={(e) => e.target.value && setBusinessDate(e.target.value)} />
      </div>
      {rows.map((r, i) => {
        const ing = ingredients.find((x) => x.id === r.ingredientId);
        return (
          <div key={i} className="card" style={{ marginBottom: 8 }}>
            <div className="field" style={{ marginBottom: 8 }}>
              <label>Nguyên liệu</label>
              <select className="input" value={r.ingredientId} onChange={(e) => setRow(i, { ingredientId: e.target.value, unitCost: e.target.value ? String(ingredients.find((x) => x.id === e.target.value)?.cost_per_unit ?? '') : r.unitCost })}>
                <option value="">— Chọn —</option>
                {ingredients.map((g) => (
                  <option key={g.id} value={g.id}>
                    {g.name} ({g.unit})
                  </option>
                ))}
              </select>
            </div>
            <div className="row" style={{ gap: 8 }}>
              <div className="field" style={{ flex: 1, margin: 0 }}>
                <label>Số lượng{ing ? ` (${ing.unit})` : ''}</label>
                <input className="input" inputMode="decimal" placeholder="0" value={r.qty} onChange={(e) => setRow(i, { qty: e.target.value.replace(/[^\d.]/g, '') })} />
              </div>
              <div className="field" style={{ flex: 1, margin: 0 }}>
                <label>Đơn giá (đ)</label>
                <input className="input" inputMode="numeric" placeholder="0" value={r.unitCost} onChange={(e) => setRow(i, { unitCost: e.target.value })} />
              </div>
              <button
                type="button"
                className="btn btn-outline"
                style={{ alignSelf: 'flex-end', minHeight: 44 }}
                onClick={() => setRows((prev) => prev.filter((_, j) => j !== i))}
                disabled={rows.length === 1}
              >
                ✕
              </button>
            </div>
          </div>
        );
      })}
      <button className="btn btn-outline btn-block" style={{ marginBottom: 12 }} onClick={() => setRows((prev) => [...prev, { ingredientId: '', qty: '', unitCost: '' }])}>
        ＋ Thêm dòng
      </button>
      <div className="card" style={{ marginBottom: 12 }}>
        <div className="co-total-row grand">
          <span>Tổng tiền nhập</span>
          <span className="money">{formatVND(Math.round(total))}</span>
        </div>
      </div>
      <div className="row" style={{ gap: 8 }}>
        <div className="field" style={{ flex: 1 }}>
          <label>Trả ngay (đ)</label>
          <input className="input" inputMode="numeric" placeholder="0" value={paid} onChange={(e) => setPaid(e.target.value)} />
        </div>
        <div className="field" style={{ flex: 1 }}>
          <label>Trả từ quỹ</label>
          <select className="input" value={fundId} onChange={(e) => setFundId(e.target.value)}>
            <option value="">— Chọn quỹ —</option>
            {funds.filter((f) => f.active).map((f) => (
              <option key={f.id} value={f.id}>
                {f.name}
              </option>
            ))}
          </select>
        </div>
      </div>
      {paidNum > 0 && total > paidNum && (
        <p className="small" style={{ color: 'var(--red)' }}>
          Còn nợ NCC: {formatVND(Math.round(total) - paidNum)}
        </p>
      )}
      <div className="field">
        <label>Ghi chú</label>
        <input className="input" value={note} onChange={(e) => setNote(e.target.value)} placeholder="VD: nhập sáng thứ 2…" />
      </div>
      <AttachmentsInput value={attachments} onChange={setAttachments} />
      <button className="btn btn-block btn-lg" disabled={saving} onClick={() => void submit()}>
        {saving ? 'Đang lưu…' : '✅ Tạo phiếu nhập'}
      </button>
    </Sheet>
  );
}

/** Tab quản lý lý do nhập/xuất kho (chỉ chủ quán). */
function ReasonsTab({
  reasons,
  onSaved,
}: {
  reasons: StockReasonsSettings | null;
  onSaved: () => Promise<void>;
}) {
  const toast = useToast();
  const [importList, setImportList] = useState<StockReason[]>(reasons?.import_reasons ?? []);
  const [exportList, setExportList] = useState<StockReason[]>(reasons?.export_reasons ?? []);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    setImportList(reasons?.import_reasons ?? []);
    setExportList(reasons?.export_reasons ?? []);
  }, [reasons]);

  const behaviorLabel: Record<string, string> = {
    sale: '💰 Bán (thu tiền vào quỹ)',
    return_supplier: '🏭 Trả NCC (trừ công nợ)',
    none: '📦 Chỉ trừ tồn kho',
  };

  const save = async (imp: StockReason[], exp: StockReason[]) => {
    setBusy(true);
    try {
      await saveStockReasons({ import_reasons: imp, export_reasons: exp });
      toast.show('Đã lưu lý do ✅');
      await onSaved();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  const addReason = (kind: 'import' | 'export') => {
    const label = window.prompt(kind === 'import' ? 'Tên lý do nhập:' : 'Tên lý do xuất:');
    if (!label?.trim()) return;
    const r: StockReason = {
      id: 'custom_' + Date.now().toString(36),
      label: label.trim(),
      behavior: kind === 'export' ? 'none' : undefined,
    };
    if (kind === 'import') {
      const next = [...importList, r];
      setImportList(next);
      void save(next, exportList);
    } else {
      const next = [...exportList, r];
      setExportList(next);
      void save(importList, next);
    }
  };

  const renameReason = (kind: 'import' | 'export', id: string) => {
    const list = kind === 'import' ? importList : exportList;
    const cur = list.find((x) => x.id === id);
    const label = window.prompt('Tên lý do:', cur?.label ?? '');
    if (!label?.trim() || label.trim() === cur?.label) return;
    const next = list.map((x) => (x.id === id ? { ...x, label: label.trim() } : x));
    if (kind === 'import') {
      setImportList(next);
      void save(next, exportList);
    } else {
      setExportList(next);
      void save(importList, next);
    }
  };

  const deleteReason = (kind: 'import' | 'export', id: string) => {
    const list = kind === 'import' ? importList : exportList;
    const cur = list.find((x) => x.id === id);
    if (cur?.builtin) return toast.show('Lý do mặc định không xóa được');
    if (!window.confirm(`Xóa lý do "${cur?.label}"?`)) return;
    const next = list.filter((x) => x.id !== id);
    if (kind === 'import') {
      setImportList(next);
      void save(next, exportList);
    } else {
      setExportList(next);
      void save(importList, next);
    }
  };

  const changeBehavior = (id: string, behavior: StockExportBehavior) => {
    const next = exportList.map((x) => (x.id === id ? { ...x, behavior } : x));
    setExportList(next);
    void save(importList, next);
  };

  return (
    <>
      <div className="sb-section" style={{ marginBottom: 12, padding: '12px 16px' }}>
        <div className="row" style={{ justifyContent: 'space-between', marginBottom: 8 }}>
          <b>📥 Lý do nhập kho</b>
          <button type="button" className="btn btn-outline" style={{ minHeight: 36 }} onClick={() => addReason('import')} disabled={busy}>
            ＋ Thêm
          </button>
        </div>
        {importList.map((r) => (
          <div key={r.id} className="row" style={{ justifyContent: 'space-between', padding: '8px 0', borderTop: '1px solid var(--line)' }}>
            <span>{r.label}</span>
            <span className="row" style={{ gap: 4 }}>
              <button type="button" className="btn btn-ghost" style={{ minHeight: 32, padding: '0 10px' }} onClick={() => renameReason('import', r.id)} disabled={busy}>
                Sửa
              </button>
              {!r.builtin && (
                <button type="button" className="btn btn-ghost" style={{ minHeight: 32, padding: '0 10px', color: 'var(--red)' }} onClick={() => deleteReason('import', r.id)} disabled={busy}>
                  Xóa
                </button>
              )}
            </span>
          </div>
        ))}
      </div>
      <div className="sb-section" style={{ padding: '12px 16px' }}>
        <div className="row" style={{ justifyContent: 'space-between', marginBottom: 8 }}>
          <b>📤 Lý do xuất kho</b>
          <button type="button" className="btn btn-outline" style={{ minHeight: 36 }} onClick={() => addReason('export')} disabled={busy}>
            ＋ Thêm
          </button>
        </div>
        {exportList.map((r) => (
          <div key={r.id} style={{ padding: '8px 0', borderTop: '1px solid var(--line)' }}>
            <div className="row" style={{ justifyContent: 'space-between' }}>
              <span>{r.label}</span>
              <span className="row" style={{ gap: 4 }}>
                <button type="button" className="btn btn-ghost" style={{ minHeight: 32, padding: '0 10px' }} onClick={() => renameReason('export', r.id)} disabled={busy}>
                  Sửa
                </button>
                {!r.builtin && (
                  <button type="button" className="btn btn-ghost" style={{ minHeight: 32, padding: '0 10px', color: 'var(--red)' }} onClick={() => deleteReason('export', r.id)} disabled={busy}>
                    Xóa
                  </button>
                )}
              </span>
            </div>
            <div className="field" style={{ marginTop: 6 }}>
              <label>Hành vi</label>
              <select className="input" value={r.behavior ?? 'none'} onChange={(e) => changeBehavior(r.id, e.target.value as StockExportBehavior)} disabled={busy}>
                <option value="sale">{behaviorLabel.sale}</option>
                <option value="return_supplier">{behaviorLabel.return_supplier}</option>
                <option value="none">{behaviorLabel.none}</option>
              </select>
            </div>
          </div>
        ))}
        <p className="small muted" style={{ marginTop: 8 }}>
          Hành vi quyết định phiếu xuất làm gì thêm: thu tiền vào quỹ, trừ công nợ NCC, hay chỉ trừ tồn kho.
        </p>
      </div>
    </>
  );
}

function StockExportForm({
  warehouses,
  reasons,
  onClose,
  onSaved,
}: {
  warehouses: Warehouse[];
  reasons: StockReasonsSettings | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const toast = useToast();
  const [ingredients, setIngredients] = useState<Ingredient[]>([]);
  const [funds, setFunds] = useState<Fund[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [reason, setReason] = useState<StockExportReason>('ban');
  const [supplierId, setSupplierId] = useState('');
  const [warehouseId, setWarehouseId] = useState(warehouses[0]?.id ?? '');
  const [businessDate, setBusinessDate] = useState(todayVN());
  const [rows, setRows] = useState<{ ingredientId: string; qty: string; unitPrice: string }[]>([
    { ingredientId: '', qty: '', unitPrice: '' },
  ]);
  const [received, setReceived] = useState('');
  const [fundId, setFundId] = useState('');
  const [note, setNote] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    listIngredients(true).then(setIngredients).catch(() => {});
    getFunds().then(setFunds).catch(() => {});
    listSuppliers().then(setSuppliers).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const items: CreateStockExportItemInput[] = rows
    .map((r) => ({
      ingredientId: r.ingredientId,
      qty: parseFloat(r.qty) || 0,
      unitPrice: parseInt(r.unitPrice.replace(/\D/g, ''), 10) || 0,
    }))
    .filter((r) => r.ingredientId && r.qty > 0);
  const total = rows.reduce((s, r) => {
    const q = parseFloat(r.qty) || 0;
    const c = parseInt(r.unitPrice.replace(/\D/g, ''), 10) || 0;
    return s + q * c;
  }, 0);
  const receivedNum = parseInt(received.replace(/\D/g, ''), 10) || 0;

  const setRow = (i: number, patch: Partial<(typeof rows)[number]>) =>
    setRows((prev) => prev.map((r, j) => (j === i ? { ...r, ...patch } : r)));

  const behavior = exportReasonBehavior(reasons?.export_reasons ?? [], reason);
  const submit = async () => {
    if (!warehouseId) return toast.show('Chọn kho xuất');
    if (items.length === 0) return toast.show('Thêm ít nhất một nguyên liệu');
    if (behavior === 'return_supplier' && !supplierId) return toast.show('Chọn nhà cung cấp để trả hàng');
    setSaving(true);
    try {
      await createStockExport({
        reason,
        behavior,
        supplierId: behavior === 'return_supplier' ? supplierId || null : null,
        warehouseId,
        items,
        receivedAmount: behavior === 'sale' ? receivedNum : 0,
        fundId: behavior === 'sale' && receivedNum > 0 ? fundId || null : null,
        note: note.trim() || null,
        businessDate,
      });
      toast.show('Đã tạo phiếu xuất ✅');
      onSaved();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Tạo phiếu xuất thất bại');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Sheet title="📤 Tạo phiếu xuất" onClose={onClose}>
      <div className="row" style={{ gap: 8 }}>
        <div className="field" style={{ flex: 1 }}>
          <label>Lý do xuất</label>
          <select className="input" value={reason} onChange={(e) => setReason(e.target.value)}>
            {(reasons?.export_reasons ?? []).map((r) => (
              <option key={r.id} value={r.id}>
                {r.label}
              </option>
            ))}
          </select>
        </div>
        <div className="field" style={{ flex: 1 }}>
          <label>Kho xuất</label>
          <select className="input" value={warehouseId} onChange={(e) => setWarehouseId(e.target.value)}>
            {warehouses.map((w) => (
              <option key={w.id} value={w.id}>
                {w.name}
              </option>
            ))}
          </select>
        </div>
      </div>
      {reason === 'tra_ncc' && (
        <div className="field">
          <label>Nhà cung cấp (trả hàng)</label>
          <select className="input" value={supplierId} onChange={(e) => setSupplierId(e.target.value)}>
            <option value="">— Chọn NCC —</option>
            {suppliers.filter((sp) => sp.active).map((sp) => (
              <option key={sp.id} value={sp.id}>
                {sp.name}{sp.debt > 0 ? ` (đang nợ ${formatVND(sp.debt)})` : ''}
              </option>
            ))}
          </select>
        </div>
      )}
      <div className="field">
        <label>Ngày xuất</label>
        <input className="input" type="date" max={todayVN()} value={businessDate} onChange={(e) => e.target.value && setBusinessDate(e.target.value)} />
      </div>
      {rows.map((r, i) => {
        const ing = ingredients.find((x) => x.id === r.ingredientId);
        return (
          <div key={i} className="card" style={{ marginBottom: 8 }}>
            <div className="field" style={{ marginBottom: 8 }}>
              <label>Nguyên liệu</label>
              <select className="input" value={r.ingredientId} onChange={(e) => setRow(i, { ingredientId: e.target.value })}>
                <option value="">— Chọn —</option>
                {ingredients.map((g) => (
                  <option key={g.id} value={g.id}>
                    {g.name} ({g.unit})
                  </option>
                ))}
              </select>
            </div>
            <div className="row" style={{ gap: 8 }}>
              <div className="field" style={{ flex: 1, margin: 0 }}>
                <label>Số lượng{ing ? ` (${ing.unit})` : ''}</label>
                <input className="input" inputMode="decimal" placeholder="0" value={r.qty} onChange={(e) => setRow(i, { qty: e.target.value.replace(/[^\d.]/g, '') })} />
              </div>
              <div className="field" style={{ flex: 1, margin: 0 }}>
                <label>Đơn giá (đ)</label>
                <input className="input" inputMode="numeric" placeholder="0" value={r.unitPrice} onChange={(e) => setRow(i, { unitPrice: e.target.value })} />
              </div>
              <button
                type="button"
                className="btn btn-outline"
                style={{ alignSelf: 'flex-end', minHeight: 44 }}
                onClick={() => setRows((prev) => prev.filter((_, j) => j !== i))}
                disabled={rows.length === 1}
              >
                ✕
              </button>
            </div>
          </div>
        );
      })}
      <button className="btn btn-outline btn-block" style={{ marginBottom: 12 }} onClick={() => setRows((prev) => [...prev, { ingredientId: '', qty: '', unitPrice: '' }])}>
        ＋ Thêm dòng
      </button>
      <div className="card" style={{ marginBottom: 12 }}>
        <div className="co-total-row grand">
          <span>Tổng tiền xuất</span>
          <span className="money">{formatVND(Math.round(total))}</span>
        </div>
      </div>
      {reason === 'ban' && (
        <div className="row" style={{ gap: 8 }}>
          <div className="field" style={{ flex: 1 }}>
            <label>Thu tiền (đ)</label>
            <input className="input" inputMode="numeric" placeholder="0" value={received} onChange={(e) => setReceived(e.target.value)} />
          </div>
          <div className="field" style={{ flex: 1 }}>
            <label>Thu vào quỹ</label>
            <select className="input" value={fundId} onChange={(e) => setFundId(e.target.value)}>
              <option value="">— Chọn quỹ —</option>
              {funds.filter((f) => f.active).map((f) => (
                <option key={f.id} value={f.id}>
                  {f.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      )}
      {reason === 'tra_ncc' && total > 0 && (
        <p className="small muted">Trả hàng sẽ trừ {formatVND(Math.round(total))} vào công nợ NCC đã chọn.</p>
      )}
      {reason === 'huy' && (
        <p className="small muted">Hủy hàng chỉ trừ tồn kho, không phát sinh thu/chi tiền.</p>
      )}
      <div className="field">
        <label>Ghi chú</label>
        <input className="input" value={note} onChange={(e) => setNote(e.target.value)} placeholder="VD: trả sữa hết hạn cho NCC…" />
      </div>
      <button className="btn btn-block btn-lg" disabled={saving} onClick={() => void submit()}>
        {saving ? 'Đang lưu…' : '✅ Tạo phiếu xuất'}
      </button>
    </Sheet>
  );
}

function SupplierForm({
  initial,
  onClose,
  onSaved,
}: {
  initial: Supplier | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const toast = useToast();
  const [name, setName] = useState(initial?.name ?? '');
  const [phone, setPhone] = useState(initial?.phone ?? '');
  const [address, setAddress] = useState(initial?.address ?? '');
  const [note, setNote] = useState(initial?.note ?? '');
  const [saving, setSaving] = useState(false);

  const submit = async () => {
    if (!name.trim()) return toast.show('Nhập tên NCC');
    setSaving(true);
    try {
      await saveSupplier({
        id: initial?.id,
        name,
        phone,
        address: address || null,
        note: note || null,
      });
      toast.show('Đã lưu NCC');
      onSaved();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    } finally {
      setSaving(false);
    }
  };

  const remove = async () => {
    if (!initial || !window.confirm(`Xóa NCC "${initial.name}"?`)) return;
    try {
      await deleteSupplier(initial.id);
      toast.show('Đã xóa NCC');
      onSaved();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Xóa thất bại');
    }
  };

  return (
    <Sheet title={initial ? 'Sửa nhà cung cấp' : 'Thêm nhà cung cấp'} onClose={onClose}>
      <div className="field">
        <label>Tên NCC *</label>
        <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="VD: Chợ đầu mối" />
      </div>
      <div className="field">
        <label>Số điện thoại</label>
        <input className="input" inputMode="tel" value={phone} onChange={(e) => setPhone(e.target.value)} />
      </div>
      <div className="field">
        <label>Địa chỉ</label>
        <input className="input" value={address} onChange={(e) => setAddress(e.target.value)} />
      </div>
      <div className="field">
        <label>Ghi chú</label>
        <input className="input" value={note} onChange={(e) => setNote(e.target.value)} />
      </div>
      <button className="btn btn-block btn-lg" disabled={saving} onClick={() => void submit()}>
        {saving ? 'Đang lưu…' : 'Lưu'}
      </button>
      {initial && (
        <button className="btn btn-outline btn-block" style={{ marginTop: 8 }} onClick={() => void remove()}>
          🗑️ Xóa NCC
        </button>
      )}
    </Sheet>
  );
}

function PaySupplierSheet({
  supplier,
  warehouses,
  onClose,
  onSaved,
}: {
  supplier: Supplier;
  warehouses: Warehouse[];
  onClose: () => void;
  onSaved: () => void;
}) {
  const toast = useToast();
  const [amount, setAmount] = useState(String(supplier.debt));
  const [fundId, setFundId] = useState('');
  const [funds, setFunds] = useState<Fund[]>([]);
  const [warehouseId, setWarehouseId] = useState(warehouses[0]?.id ?? '');
  const [note, setNote] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    getFunds().then(setFunds).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const submit = async () => {
    const amt = parseInt(amount.replace(/\D/g, ''), 10) || 0;
    if (amt <= 0) return toast.show('Nhập số tiền');
    if (!warehouseId) return toast.show('Chọn kho (để ghi sổ quỹ)');
    setSaving(true);
    try {
      await paySupplierDebt(supplier.id, amt, fundId || null, warehouseId, note.trim() || null);
      toast.show('Đã trả nợ NCC ✅');
      onSaved();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Trả nợ thất bại');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Sheet title={`Trả nợ ${supplier.name}`} onClose={onClose}>
      <p className="muted" style={{ marginTop: 0 }}>
        Đang nợ: <b style={{ color: 'var(--red)' }}>{formatVND(supplier.debt)}</b>
      </p>
      <div className="field">
        <label>Số tiền trả (đ)</label>
        <input className="input" inputMode="numeric" value={amount} onChange={(e) => setAmount(e.target.value)} />
      </div>
      <div className="row" style={{ gap: 8 }}>
        <div className="field" style={{ flex: 1 }}>
          <label>Trả từ quỹ</label>
          <select className="input" value={fundId} onChange={(e) => setFundId(e.target.value)}>
            <option value="">— Chọn quỹ —</option>
            {funds.filter((f) => f.active).map((f) => (
              <option key={f.id} value={f.id}>
                {f.name}
              </option>
            ))}
          </select>
        </div>
        <div className="field" style={{ flex: 1 }}>
          <label>Kho (sổ quỹ)</label>
          <select className="input" value={warehouseId} onChange={(e) => setWarehouseId(e.target.value)}>
            {warehouses.map((w) => (
              <option key={w.id} value={w.id}>
                {w.name}
              </option>
            ))}
          </select>
        </div>
      </div>
      <div className="field">
        <label>Ghi chú</label>
        <input className="input" value={note} onChange={(e) => setNote(e.target.value)} />
      </div>
      <button className="btn btn-block btn-lg" disabled={saving} onClick={() => void submit()}>
        {saving ? 'Đang trả…' : '✅ Xác nhận trả nợ'}
      </button>
    </Sheet>
  );
}
