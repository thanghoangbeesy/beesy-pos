import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { DbError, applyGoodsCosts, applyGoodsCostsToPoint, getAllowedWarehouses, getDailyBreakdown, getDailyExpenses, getDailyPurchaseCosts, getFundCurrentBalances, getHourlyBreakdown, getRangeReport, getSettings, getTotalCustomerDebt, searchCustomers, type FundBalance } from '../lib/db';
import {
  addDaysVN,
  endOfMonthVN,
  formatDMY,
  formatVND,
  startOfMonthVN,
  startOfWeekVN,
  todayVN,
} from '../lib/format';
import { useToast } from '../components/Toast';
import { LowStockPanel, useStockOverview } from '../components/StockOverview';
import { useAuth } from '../lib/auth';
import { LineIcon } from '../components/LineIcon';
import './v6demo-theme.css';
import './v6demo-reports.css';
import type { Customer, DailyReport, Warehouse } from '../lib/types';

type PresetKey = 'today' | 'yesterday' | 'thisWeek' | 'lastWeek' | 'thisMonth' | 'lastMonth' | 'custom';

const PRESETS: { key: PresetKey; label: string }[] = [
  { key: 'today', label: 'Hôm nay' },
  { key: 'yesterday', label: 'Hôm qua' },
  { key: 'thisWeek', label: 'Tuần này' },
  { key: 'lastWeek', label: 'Tuần trước' },
  { key: 'thisMonth', label: 'Tháng này' },
  { key: 'lastMonth', label: 'Tháng trước' },
  { key: 'custom', label: 'Tùy chọn' },
];

function presetRange(key: PresetKey): [string, string] {
  const t = todayVN();
  switch (key) {
    case 'today': return [t, t];
    case 'yesterday': { const y = addDaysVN(t, -1); return [y, y]; }
    case 'thisWeek': return [startOfWeekVN(t), t];
    case 'lastWeek': {
      const mondayThis = startOfWeekVN(t);
      const mondayLast = addDaysVN(mondayThis, -7);
      return [mondayLast, addDaysVN(mondayLast, 6)];
    }
    case 'thisMonth': return [startOfMonthVN(t), t];
    case 'lastMonth': {
      const firstThisMonth = startOfMonthVN(t);
      const lastDayPrev = addDaysVN(firstThisMonth, -1);
      return [startOfMonthVN(lastDayPrev), lastDayPrev];
    }
    // Kỳ tùy chọn không đi qua hàm này (load lấy khoảng ngày từ state).
    case 'custom': return [t, t];
  }
}

function prevRange(key: PresetKey): [string, string] {
  const t = todayVN();
  switch (key) {
    case 'today': { const y = addDaysVN(t, -1); return [y, y]; }
    case 'yesterday': { const y = addDaysVN(t, -2); return [y, y]; }
    case 'thisWeek': {
      const mondayThis = startOfWeekVN(t);
      const mondayLast = addDaysVN(mondayThis, -7);
      return [mondayLast, addDaysVN(mondayLast, 6)];
    }
    case 'lastWeek': {
      const mondayThis = startOfWeekVN(t);
      const mondayLast2 = addDaysVN(mondayThis, -14);
      return [mondayLast2, addDaysVN(mondayLast2, 6)];
    }
    case 'thisMonth': {
      const firstThisMonth = startOfMonthVN(t);
      const lastDayPrev = addDaysVN(firstThisMonth, -1);
      return [startOfMonthVN(lastDayPrev), lastDayPrev];
    }
    case 'lastMonth': {
      const firstThisMonth = startOfMonthVN(t);
      const lastDayPrev = addDaysVN(firstThisMonth, -1);
      const firstPrev = startOfMonthVN(lastDayPrev);
      const lastDayPrev2 = addDaysVN(firstPrev, -1);
      return [startOfMonthVN(lastDayPrev2), lastDayPrev2];
    }
    // Kỳ tùy chọn không đi qua hàm này (load tự tính kỳ trước từ khoảng đã chọn).
    case 'custom': { const y = addDaysVN(t, -1); return [y, y]; }
  }
}

/** Nhãn kỳ này / kỳ trước cho tiêu đề biểu đồ so sánh (kỳ trước viết thường
 *  để ghép câu "Kỳ này so với kỳ trước", ví dụ "Hôm nay so với hôm qua"). */
function chartLabels(key: PresetKey): { cur: string; prev: string } {
  switch (key) {
    case 'today': return { cur: 'Hôm nay', prev: 'hôm qua' };
    case 'yesterday': return { cur: 'Hôm qua', prev: 'hôm kia' };
    case 'thisWeek': return { cur: 'Tuần này', prev: 'tuần trước' };
    case 'lastWeek': return { cur: 'Tuần trước', prev: 'tuần trước nữa' };
    case 'thisMonth': return { cur: 'Tháng này', prev: 'tháng trước' };
    case 'lastMonth': return { cur: 'Tháng trước', prev: 'tháng trước nữa' };
    case 'custom': return { cur: 'Kỳ đã chọn', prev: 'kỳ trước liền kề' };
  }
}

function cap(s: string): string {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

/** Số ngày từ a đến b (YYYY-MM-DD, b - a, có thể âm). */
function daysBetween(a: string, b: string): number {
  const pa = a.split('-').map(Number);
  const pb = b.split('-').map(Number);
  return Math.round((Date.UTC(pb[0], pb[1] - 1, pb[2]) - Date.UTC(pa[0], pa[1] - 1, pa[2])) / 86400000);
}

type ChartMetric = 'revenue' | 'profit' | 'expense';

/** Muc cua bieu do cot: mau cot ky nay dam, cot ky truoc nhat cung mau. */
const METRICS: { key: ChartMetric; label: string; curColor: string; prevColor: string }[] = [
  { key: 'revenue', label: 'Doanh thu', curColor: '#00B14F', prevColor: '#86EFAC' },
  { key: 'profit', label: 'Lợi nhuận', curColor: '#2563EB', prevColor: '#93C5FD' },
  { key: 'expense', label: 'Chi phí', curColor: '#DC2626', prevColor: '#FCA5A5' },
];

/** 1 điểm trên biểu đồ so sánh: nhãn trục + chi tiết tooltip + 2 cặp số.
 *  Chi phí mặc định = chi phí vận hành (tách riêng, không phải giá vốn);
 *  bật công tắc "tính chi phí nhập hàng + nguyên liệu" thì cộng thêm
 *  purchase (tiền nhập hàng) + cost (giá vốn) vào chi phí, lợi nhuận trừ thêm purchase. */
interface ChartPoint {
  key: string;
  label: string;
  detail: string;
  thisRevenue: number;
  thisProfit: number;
  thisExpense: number;
  thisPurchase: number;
  thisCost: number;
  lastRevenue: number;
  lastProfit: number;
  lastExpense: number;
  lastPurchase: number;
  lastCost: number;
}

type ChartMode = 'hour' | 'week' | 'month';

function pctChange(cur: number, prev: number): number | null {
  if (prev === 0) return cur > 0 ? 100 : null;
  return ((cur - prev) / prev) * 100;
}

const PAY_COLORS = ['#00B14F', '#2563EB', '#9333EA', '#F59E0B', '#9CA3AF'];

export function ReportsPC() {
  const toast = useToast();
  const { can, user } = useAuth();
  const navigate = useNavigate();
  const [preset, setPreset] = useState<PresetKey>('today');
  // Kỳ tùy chọn: khoảng ngày tự chọn (mặc định hôm nay).
  const [customFrom, setCustomFrom] = useState(() => todayVN());
  const [customTo, setCustomTo] = useState(() => todayVN());
  const [report, setReport] = useState<DailyReport | null>(null);
  const [prevReport, setPrevReport] = useState<DailyReport | null>(null);
  const [debtTotal, setDebtTotal] = useState<number | null>(null);
  const [chartData, setChartData] = useState<ChartPoint[]>([]);
  const [chartMeta, setChartMeta] = useState<{ mode: ChartMode; cur: string; prev: string }>({ mode: 'hour', cur: 'Hôm nay', prev: 'hôm qua' });
  const [chartMetric, setChartMetric] = useState<ChartMetric>('revenue');
  const [includeGoods, setIncludeGoods] = useState(false);
  const [selectedIdx, setSelectedIdx] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [isOwner, setIsOwner] = useState(false);
  const { low } = useStockOverview(warehouses);
  // Widget phụ (trạng thái hiện tại, không theo kỳ): số dư quỹ, khách nợ.
  const [funds, setFunds] = useState<FundBalance[]>([]);
  const [debtors, setDebtors] = useState<Customer[]>([]);
  // Sắp xếp món bán chạy (mặc định: số lượng, giảm dần — như bản demo đã duyệt).
  const [topSortKey, setTopSortKey] = useState<'qty' | 'revenue' | 'profit'>('qty');
  const [topSortDir, setTopSortDir] = useState<'desc' | 'asc'>('desc');

  const load = useCallback(async (key: PresetKey, ids?: string[], custom?: [string, string]) => {
    setBusy(true);
    try {
      // Kỳ tùy chọn lấy khoảng ngày từ state (hoặc khoảng truyền vào khi
      // vừa đổi ngày, tránh đọc state cũ chưa kịp cập nhật); kỳ trước của
      // kỳ tùy chọn là đúng số ngày liền trước khoảng đã chọn.
      const [s, e] = key === 'custom' ? (custom ?? [customFrom, customTo]) : presetRange(key);
      const [ps, pe] = key === 'custom'
        ? [addDaysVN(s, -(daysBetween(s, e) + 1)), addDaysVN(s, -1)]
        : prevRange(key);
      const t = todayVN();
      const [cur, prev, st, debt] = await Promise.all([
        getRangeReport(s, e, ids),
        getRangeReport(ps, pe, ids),
        getSettings(),
        getTotalCustomerDebt(ids),
      ]);
      setReport(cur);
      setPrevReport(prev);
      setIncludeGoods(st['include_goods_costs'] === '1');
      setDebtTotal(debt);
      // Biểu đồ so sánh chạy theo kỳ đã chọn (v6.4): kỳ 1 ngày -> theo giờ
      // (24 giờ, kỳ trước là ngày liền trước); kỳ nhiều ngày -> theo ngày
      // (tuần: T2-CN, kỳ trước là tuần liền trước; tháng: ngày 1-31, kỳ trước
      // là tháng liền trước, ngày không có trong tháng trước tính 0).
      const meta = chartLabels(key);
      if (key === 'today' || key === 'yesterday' || (key === 'custom' && s === e)) {
        const day = key === 'custom' ? s : presetRange(key)[0];
        const prevDay = key === 'custom' ? ps : prevRange(key)[0];
        const hours = await getHourlyBreakdown(day, prevDay, ids);
        setChartData(hours.map((h) => ({
          key: String(h.hour),
          label: String(h.hour),
          detail: `${h.hour}h`,
          thisRevenue: h.curRevenue,
          thisProfit: h.curProfit,
          thisExpense: h.curExpense,
          thisPurchase: h.curPurchase,
          thisCost: h.curCost,
          lastRevenue: h.prevRevenue,
          lastProfit: h.prevProfit,
          lastExpense: h.prevExpense,
          lastPurchase: h.prevPurchase,
          lastCost: h.prevCost,
        })));
        setChartMeta({ mode: 'hour', ...meta });
      } else if (key === 'thisWeek' || key === 'lastWeek') {
        const mondayThis = startOfWeekVN(t);
        const curMon = key === 'thisWeek' ? mondayThis : addDaysVN(mondayThis, -7);
        const prevMon = addDaysVN(curMon, -7);
        const dayLabels = ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'];
        const [curDays, prevDays, curExp, prevExp, curPur, prevPur] = await Promise.all([
          getDailyBreakdown(curMon, addDaysVN(curMon, 6), ids),
          getDailyBreakdown(prevMon, addDaysVN(prevMon, 6), ids),
          getDailyExpenses(curMon, addDaysVN(curMon, 6), ids),
          getDailyExpenses(prevMon, addDaysVN(prevMon, 6), ids),
          getDailyPurchaseCosts(curMon, addDaysVN(curMon, 6), ids),
          getDailyPurchaseCosts(prevMon, addDaysVN(prevMon, 6), ids),
        ]);
        setChartData(dayLabels.map((dayLabel, i) => ({
          key: addDaysVN(curMon, i),
          label: dayLabel,
          detail: `${dayLabel} ${formatDMY(addDaysVN(curMon, i))}`,
          thisRevenue: curDays[i]?.revenue ?? 0,
          thisProfit: curDays[i]?.profit ?? 0,
          thisExpense: curExp[i]?.expense ?? 0,
          thisPurchase: curPur[i]?.purchase ?? 0,
          thisCost: curDays[i]?.cost ?? 0,
          lastRevenue: prevDays[i]?.revenue ?? 0,
          lastProfit: prevDays[i]?.profit ?? 0,
          lastExpense: prevExp[i]?.expense ?? 0,
          lastPurchase: prevPur[i]?.purchase ?? 0,
          lastCost: prevDays[i]?.cost ?? 0,
        })));
        setChartMeta({ mode: 'week', ...meta });
      } else if (key === 'thisMonth' || key === 'lastMonth') {
        const firstThisMonth = startOfMonthVN(t);
        const curFirst = key === 'thisMonth' ? firstThisMonth : startOfMonthVN(addDaysVN(firstThisMonth, -1));
        const curLast = endOfMonthVN(curFirst);
        const prevFirst = startOfMonthVN(addDaysVN(curFirst, -1));
        const prevLast = addDaysVN(curFirst, -1);
        const [curDays, prevDays, curExp, prevExp, curPur, prevPur] = await Promise.all([
          getDailyBreakdown(curFirst, curLast, ids),
          getDailyBreakdown(prevFirst, prevLast, ids),
          getDailyExpenses(curFirst, curLast, ids),
          getDailyExpenses(prevFirst, prevLast, ids),
          getDailyPurchaseCosts(curFirst, curLast, ids),
          getDailyPurchaseCosts(prevFirst, prevLast, ids),
        ]);
        setChartData(curDays.map((d, i) => ({
          key: d.date,
          label: String(i + 1),
          detail: formatDMY(d.date),
          thisRevenue: d.revenue,
          thisProfit: d.profit,
          thisExpense: curExp[i]?.expense ?? 0,
          thisPurchase: curPur[i]?.purchase ?? 0,
          thisCost: d.cost,
          lastRevenue: prevDays[i]?.revenue ?? 0,
          lastProfit: prevDays[i]?.profit ?? 0,
          lastExpense: prevExp[i]?.expense ?? 0,
          lastPurchase: prevPur[i]?.purchase ?? 0,
          lastCost: prevDays[i]?.cost ?? 0,
        })));
        setChartMeta({ mode: 'month', ...meta });
      } else {
        // Kỳ tùy chọn nhiều ngày: biểu đồ theo từng ngày trong khoảng đã
        // chọn, kỳ trước là đúng số ngày liền trước khoảng đó.
        const [curDays, prevDays, curExp, prevExp, curPur, prevPur] = await Promise.all([
          getDailyBreakdown(s, e, ids),
          getDailyBreakdown(ps, pe, ids),
          getDailyExpenses(s, e, ids),
          getDailyExpenses(ps, pe, ids),
          getDailyPurchaseCosts(s, e, ids),
          getDailyPurchaseCosts(ps, pe, ids),
        ]);
        setChartData(curDays.map((d, i) => ({
          key: d.date,
          label: `${d.date.slice(8, 10)}/${d.date.slice(5, 7)}`,
          detail: formatDMY(d.date),
          thisRevenue: d.revenue,
          thisProfit: d.profit,
          thisExpense: curExp[i]?.expense ?? 0,
          thisPurchase: curPur[i]?.purchase ?? 0,
          thisCost: d.cost,
          lastRevenue: prevDays[i]?.revenue ?? 0,
          lastProfit: prevDays[i]?.profit ?? 0,
          lastExpense: prevExp[i]?.expense ?? 0,
          lastPurchase: prevPur[i]?.purchase ?? 0,
          lastCost: prevDays[i]?.cost ?? 0,
        })));
        setChartMeta({ mode: 'month', ...meta });
      }
    } catch (err) {
      toast.show(err instanceof DbError ? err.message : 'Không tải được báo cáo');
    } finally {
      setBusy(false);
    }
  }, [toast, customFrom, customTo]);

  // Widget phụ chỉ tải 1 lần (số dư quỹ + khách nợ là trạng thái hiện tại,
  // không đổi theo kỳ). Lỗi ở đây không chặn trang chính nên không toast.
  const loadWidgets = useCallback(async (ids?: string[]) => {
    try {
      const [fb, customers] = await Promise.all([
        getFundCurrentBalances(ids ?? []),
        searchCustomers(''),
      ]);
      setFunds(fb);
      const scoped = ids ? customers.filter((c) => !c.warehouse_id || ids.includes(c.warehouse_id)) : customers;
      setDebtors(scoped.filter((c) => c.debt > 0).sort((a, b) => b.debt - a.debt));
    } catch {
      // Giữ widget trống, trang chính vẫn hiện đủ số liệu kỳ đang xem.
    }
  }, []);

  useEffect(() => {
    getAllowedWarehouses()
      .then(({ warehouses: ws, isOwner: ow }) => {
        setWarehouses(ws);
        setIsOwner(ow);
        const ids = ow ? undefined : ws.map((w) => w.id);
        void load('today', ids);
        void loadWidgets(ids);
      })
      .catch(() => { void load('today'); void loadWidgets(); });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const pickPreset = (key: PresetKey) => {
    setPreset(key);
    setSelectedIdx(null);
    const ids = isOwner ? undefined : warehouses.map((w) => w.id);
    void load(key, ids);
  };

  // Kỳ tùy chọn: đổi 1 đầu mút mà vượt đầu kia thì đảo 2 đầu lại cho đúng
  // thứ tự (không để khoảng ngày ngược), rồi tải ngay với khoảng mới.
  const applyCustom = (from: string, to: string) => {
    const f = from <= to ? from : to;
    const t = from <= to ? to : from;
    setCustomFrom(f);
    setCustomTo(t);
    setPreset('custom');
    setSelectedIdx(null);
    const ids = isOwner ? undefined : warehouses.map((w) => w.id);
    void load('custom', ids, [f, t]);
  };


  // Kỳ đang xem (để thẻ Doanh thu/Tổng chi phí bấm sang trang chi tiết đúng kỳ)
  const [rs, re] = preset === 'custom' ? [customFrom, customTo] : presetRange(preset);
  const labels = chartLabels(preset);
  const kpis: { label: string; value: string; icon: string; iconColor: string; bg: string; change: number | null; to?: string; hint?: string }[] = useMemo(() => {
    if (!report) return [];
    const p = prevReport;
    const dispCur = applyGoodsCosts(report, includeGoods);
    const dispPrev = p ? applyGoodsCosts(p, includeGoods) : null;
    return [
      { label: 'Doanh thu', value: formatVND(report.revenue), icon: 'wallet', iconColor: '#2563EB', bg: '#EFF4FF', change: p ? pctChange(report.revenue, p.revenue) : null, to: `/so-quy?from=${rs}&to=${re}&type=thu`, hint: 'Bấm để xem các khoản thu' },
      { label: 'Lợi nhuận', value: formatVND(dispCur.profit), icon: 'chart', iconColor: '#15803D', bg: '#ECFDF5', change: dispPrev ? pctChange(dispCur.profit, dispPrev.profit) : null },
      { label: 'Số đơn', value: String(report.order_count), icon: 'receipt', iconColor: '#7C3AED', bg: '#F5F0FF', change: p ? pctChange(report.order_count, p.order_count) : null },
      { label: 'TB/đơn', value: formatVND(Math.round(report.avg_order)), icon: 'tag', iconColor: '#B45309', bg: '#FFFBEB', change: p ? pctChange(report.avg_order, p.avg_order) : null },
      { label: 'Tổng chi phí', value: formatVND(report.all_chi ?? 0), icon: 'ledger', iconColor: '#DC2626', bg: '#FEF2F2', change: p ? pctChange(report.all_chi ?? 0, p.all_chi ?? 0) : null, to: `/so-quy?from=${rs}&to=${re}&type=chi`, hint: 'Bấm để xem các khoản chi' },
      ...(can('debt') ? [{ label: 'Tổng công nợ', value: formatVND(debtTotal ?? 0), icon: 'users', iconColor: '#7C3AED', bg: '#F5F0FF', change: null, to: '/debt', hint: 'Bấm để xem Sổ nợ' }] : []),
    ];
  }, [report, prevReport, includeGoods, debtTotal, rs, re]);


  // Thang do bieu do cot: tinh theo MUC DANG CHON, ca 2 ky. Doanh thu /
  // chi phi chi co gia tri duong (truc 0 o day); loi nhuan co the am nen
  // thang gom ca phan am, cot am ve xuong duoi truc 0.
  const metricValues = (d: ChartPoint): [number, number] => {
    if (chartMetric === 'revenue') return [d.thisRevenue, d.lastRevenue];
    const cur = applyGoodsCostsToPoint({ profit: d.thisProfit, expense: d.thisExpense, purchase: d.thisPurchase, cost: d.thisCost }, includeGoods);
    const prev = applyGoodsCostsToPoint({ profit: d.lastProfit, expense: d.lastExpense, purchase: d.lastPurchase, cost: d.lastCost }, includeGoods);
    return chartMetric === 'profit' ? [cur.profit, prev.profit] : [cur.expense, prev.expense];
  };
  const metricVals = chartData.flatMap((d) => metricValues(d));
  const maxPos = Math.max(1, ...metricVals.filter((v) => v > 0));
  const maxNeg = Math.max(0, ...metricVals.filter((v) => v < 0).map((v) => -v));

  // Hinh hoc bieu do cot: thang tuyen tinh theo muc dang chon, truc 0 dam;
  // cot duong ve len tu truc 0, cot am (chi loi nhuan am) ve xuong duoi
  // truc 0. Thang khong doi khi an/hien vi khong con legend an duong.
  const svgW = 640;
  const svgH = 260;
  const svgPadT = 16;
  const svgPadB = 24;
  const svgPadX = 10;
  const svgPlotH = svgH - svgPadT - svgPadB;
  // Hinh hoc cot nhom: moi moc la 1 nhom 2 cot sat nhau (ky nay ben trai,
  // ky truoc ben phai). Cot rong toi da 22px de che do tuan khong bi be.
  const svgSlot = chartData.length > 0 ? (svgW - 2 * svgPadX) / chartData.length : svgW - 2 * svgPadX;
  const barW = Math.max(2, Math.min(svgSlot * 0.34, 22));
  const barGap = Math.max(1, svgSlot * 0.08);
  const svgX = (i: number) => svgPadX + svgSlot * (i + 0.5);
  const svgY = (v: number) => svgPadT + ((maxPos - v) / (maxPos + maxNeg)) * svgPlotH;
  const svgZeroY = svgY(0);
  const barRect = (v: number, x: number) => ({ x, y: Math.min(svgY(v), svgZeroY), height: Math.abs(svgY(v) - svgZeroY) });
  const showXLabel = (d: ChartPoint, i: number): boolean => {
    if (chartMeta.mode === 'week') return true;
    if (chartMeta.mode === 'hour') return Number(d.label) % 6 === 0;
    const day = i + 1;
    return day === 1 || day % 5 === 0;
  };
  const xLabelText = (d: ChartPoint) => chartMeta.mode === 'hour' ? `${d.label}h` : d.label;
  const sel = selectedIdx !== null ? chartData[selectedIdx] : undefined;
  const selMetricCur = sel ? metricValues(sel)[0] : 0;
  const selMetricPrev = sel ? metricValues(sel)[1] : 0;
  const selMetricDiff = selMetricCur - selMetricPrev;
  const selMetricPct = sel ? pctChange(selMetricCur, selMetricPrev) : null;
  // Bieu do cot (ve lai phuong an ban dau): 1 SVG duy nhat, moi moc 1 nhom
  // 2 cot (ky nay dam ben trai, ky truoc nhat ben phai), chi ve muc dang
  // chon. Thang do tinh theo muc dang chon nen chuyen muc khong bep hinh.
  // Cột đang chọn có viền đậm (theo bản demo đã duyệt).
  const metricMeta = METRICS.find((m) => m.key === chartMetric) ?? METRICS[0];
  const chartBars = (
    <svg width="100%" viewBox={`0 0 ${svgW} ${svgH}`} role="img" aria-label={`Biểu đồ cột ${metricMeta.label}`}>
      {chartData.map((d, idx) => showXLabel(d, idx) && (
        <line key={`g${d.key}`} x1={svgX(idx)} y1={svgPadT} x2={svgX(idx)} y2={svgH - svgPadB} stroke="#E2E8F0" strokeWidth={1} />
      ))}
      <line x1={svgPadX} y1={svgZeroY} x2={svgW - svgPadX} y2={svgZeroY} stroke="#64748B" strokeWidth={2} />
      <text x={svgPadX} y={svgPadT + 10} fontSize={10} fill="#94A3B8">{formatVND(maxPos)}</text>
      {maxNeg > 0 && (
        <text x={svgPadX} y={svgH - 4} fontSize={10} fill="#94A3B8">{`-${formatVND(maxNeg)}`}</text>
      )}
      {chartData.map((d, idx) => {
        const [curV, prevV] = metricValues(d);
        const cx = svgX(idx);
        const curR = barRect(curV, cx - barGap / 2 - barW);
        const prevR = barRect(prevV, cx + barGap / 2);
        const isSel = idx === selectedIdx;
        return (
          <g key={d.key}>
            {curV !== 0 && <rect x={curR.x} y={curR.y} width={barW} height={Math.max(curR.height, 1)} fill={metricMeta.curColor} rx={1} stroke={isSel ? '#0F172A' : undefined} strokeWidth={isSel ? 1.5 : undefined} />}
            {prevV !== 0 && <rect x={prevR.x} y={prevR.y} width={barW} height={Math.max(prevR.height, 1)} fill={metricMeta.prevColor} rx={1} />}
          </g>
        );
      })}
      {chartData.map((d, idx) => (
        <rect key={`h${d.key}`} x={svgPadX + svgSlot * idx} y={svgPadT} width={svgSlot} height={svgPlotH} fill="transparent" pointerEvents="all" style={{ cursor: 'pointer' }} onClick={() => setSelectedIdx(idx)} />
      ))}
      {sel && selectedIdx !== null && (
        <line x1={svgX(selectedIdx)} y1={svgPadT} x2={svgX(selectedIdx)} y2={svgH - svgPadB} stroke="#64748B" strokeWidth={1} strokeDasharray="3 3" />
      )}
      {chartData.map((d, idx) => showXLabel(d, idx) && (
        <text key={`x${d.key}`} x={svgX(idx)} y={svgH - 6} fontSize={11} fill="#64748B" textAnchor="middle">{xLabelText(d)}</text>
      ))}
    </svg>
  );

  // Cơ cấu thanh toán kỳ đang xem (từ by_payment của báo cáo kỳ, không cần
  // truy vấn thêm): xếp theo doanh thu giảm dần, tỉ lệ trên tổng doanh thu
  // theo phương thức.
  const payData = useMemo(() => {
    const entries = Object.values(report?.by_payment ?? {}).sort((a, b) => b.revenue - a.revenue);
    const total = entries.reduce((s, e) => s + e.revenue, 0) || 1;
    return entries.map((e, i) => ({ ...e, pct: (e.revenue / total) * 100, color: PAY_COLORS[i % PAY_COLORS.length] }));
  }, [report]);

  // Món bán chạy top 5, sắp xếp theo lựa chọn (mặc định: số lượng, giảm dần).
  const top5 = useMemo(() => {
    const dir = topSortDir === 'desc' ? -1 : 1;
    return [...(report?.top_products ?? [])]
      .sort((a, b) => dir * (a[topSortKey] - b[topSortKey]))
      .slice(0, 5);
  }, [report, topSortKey, topSortDir]);

  const fundsTotal = funds.reduce((s, f) => s + f.balance, 0);
  const debtTop = debtors.slice(0, 4);
  const debtRest = debtors.slice(4);
  const debtRestSum = debtRest.reduce((s, c) => s + c.debt, 0);
  const showDebt = can('debt');

  // Hero: ti le thay doi doanh thu so voi ky truoc (de hien tren hero).
  const heroPct = report && prevReport ? pctChange(report.revenue, prevReport.revenue) : null;

  if (!can('reports')) {
    return (
      <div className="v6demo-page v6demo-reports">
        <div className="v6demo-aurora" aria-hidden />
        <div className="v6demo-content">
          <div className="v6demo-glass v6demo-reports-denied">
            <LineIcon name="lock" size={20} />
            <span>Chỉ Quản lý trở lên mới được xem báo cáo.</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="v6demo-page v6demo-reports">
      <div className="v6demo-aurora" aria-hidden />
      <div className="v6demo-content" style={{ display: 'grid', gap: 18 }}>
        {/* Hero doanh thu tren cung */}
        <section className="v6demo-reports-hero v6demo-rise">
          <div className="v6demo-reports-hero-top">
            <p className="v6demo-reports-hero-eyebrow">Tổng quan</p>
            {user && <span className="v6demo-reports-hero-user">{user.full_name || user.email}</span>}
          </div>
          <h1>Doanh thu {labels.cur.toLowerCase()}</h1>
          <div className="v6demo-reports-hero-big">{busy && !report ? '…' : formatVND(report?.revenue ?? 0)}</div>
          <p className="v6demo-reports-hero-cmp">
            {report && prevReport && heroPct !== null ? (
              <>
                {heroPct >= 0 ? 'Tăng ' : 'Giảm '}
                <b>{Math.abs(Math.round(heroPct))}% so với {labels.prev} ({formatVND(prevReport.revenue)})</b>
                {' - '}{report.order_count} đơn hàng trong kỳ.
              </>
            ) : report ? (
              <>{report.order_count} đơn hàng trong kỳ.</>
            ) : (
              'Đang tải số liệu…'
            )}
          </p>
          <p className="v6demo-reports-hero-meta">Số liệu theo kỳ đang chọn ở dưới. Số dư quỹ và công nợ là trạng thái hiện tại, không theo kỳ.</p>
        </section>

        {/* Thanh loc ky rieng biet */}
        <section className="v6demo-glass v6demo-reports-filter v6demo-rise-1">
          <p className="v6demo-section-label">Chọn kỳ báo cáo</p>
          <div className="v6demo-reports-chips-row">
            {PRESETS.map((p) => (
              <button key={p.key} type="button" className={`v6demo-chip${preset === p.key ? ' active' : ''}`} onClick={() => pickPreset(p.key)}>
                {p.label}
              </button>
            ))}
          </div>
          {preset === 'custom' && (
            <div className="v6demo-reports-custom-row">
              <input
                type="date"
                className="v6demo-input"
                value={customFrom}
                onChange={(e) => e.target.value && applyCustom(e.target.value, customTo)}
                aria-label="Từ ngày"
              />
              <span className="v6demo-small v6demo-muted">đến</span>
              <input
                type="date"
                className="v6demo-input"
                value={customTo}
                onChange={(e) => e.target.value && applyCustom(customFrom, e.target.value)}
                aria-label="Đến ngày"
              />
              <span className="v6demo-small v6demo-muted">Đổi ngày là tải lại ngay; nếu ngày đầu vượt ngày cuối, 2 ngày tự đảo lại. Kỳ so sánh của Tùy chọn = đúng số ngày liền trước khoảng đã chọn.</span>
            </div>
          )}
          <p className="v6demo-reports-range-line">
            {formatDMY(rs)} - {formatDMY(re)} · Đang so sánh với {labels.prev}. Bấm vào thẻ Doanh thu / Tổng chi phí / Tổng công nợ để xem chi tiết.
          </p>
        </section>

        {/* Bieu do toan chieu rong, nut doi chi so phia tren */}
        <section className="v6demo-glass v6demo-reports-chart v6demo-rise-2">
          <div className="v6demo-reports-chart-head">
            <div>
              <h2 className="v6demo-card-title">{chartMeta.cur} so với {chartMeta.prev}</h2>
              <p className="v6demo-card-sub">
                {chartMeta.mode === 'hour'
                  ? 'Kỳ 1 ngày: biểu đồ theo từng giờ. Bấm 1 nhóm cột để xem chi tiết mốc đó.'
                  : 'Biểu đồ theo từng ngày. Bấm 1 nhóm cột để xem chi tiết mốc đó.'}
              </p>
            </div>
            <div className="v6demo-seg" role="group" aria-label="Chọn chỉ số">
              {METRICS.map((m) => (
                <button key={m.key} type="button" className={chartMetric === m.key ? 'active' : ''} onClick={() => setChartMetric(m.key)}>
                  {m.label}
                </button>
              ))}
            </div>
          </div>
          <div className="v6demo-reports-legend">
            <span><i style={{ background: metricMeta.curColor }} />{chartMeta.cur}</span>
            <span><i style={{ background: metricMeta.prevColor }} />{cap(chartMeta.prev)}</span>
          </div>
          {includeGoods && report && (
            <p className="v6demo-small v6demo-muted" style={{ margin: '8px 0 0' }}>
              Chi phí tổng kỳ này: Vận hành {formatVND(report.expenses)} + Nhập hàng {formatVND(report.purchase_costs ?? 0)} + Nguyên liệu {formatVND(report.cost)} = {formatVND(applyGoodsCosts(report, true).expense)} (Bật/tắt trong Cài đặt - Thông tin quán - Báo cáo)
            </p>
          )}
          <div key={`${preset}-${chartMetric}-${rs}-${re}`} className="v6demo-tab-swap">
            {chartBars}
          </div>
          {sel ? (
            <div key={selectedIdx} className="v6demo-reports-detail">
              <div><b>{sel.detail}</b></div>
              <div>{metricMeta.label}: {chartMeta.cur} {formatVND(selMetricCur)} · {cap(chartMeta.prev)} {formatVND(selMetricPrev)}</div>
              <div>Chênh lệch: {selMetricDiff >= 0 ? '↑' : '↓'} {formatVND(Math.abs(selMetricDiff))}{selMetricPct === null ? '' : ` (${selMetricPct >= 0 ? '+' : ''}${Math.round(selMetricPct)}%)`}</div>
            </div>
          ) : (
            <div className="v6demo-reports-detail-hint">Chạm vào 1 nhóm cột để xem {metricMeta.label} tại mốc đó.</div>
          )}
        </section>

        {/* Dai KPI (doi ky thi chay lai motion) */}
        <section className="v6demo-reports-kpi-grid" key={`${preset}-${rs}-${re}`}>
          {kpis.map((k, i) => (
            <div
              key={k.label}
              className={`v6demo-glass v6demo-glass-sm v6demo-hoverable v6demo-reports-kpi-card v6demo-rise-${(i % 4) + 1}${k.to ? ' clickable' : ''}`}
              onClick={k.to ? () => navigate(k.to as string) : undefined}
              style={k.to ? { cursor: 'pointer' } : undefined}
            >
              <div className="v6demo-reports-kpi-top">
                <span className="v6demo-reports-kpi-ico" style={{ background: k.bg, color: k.iconColor }}><LineIcon name={k.icon} size={18} /></span>
                <span className="v6demo-kpi-label v6demo-reports-kpi-label">{k.label}</span>
              </div>
              <div className="v6demo-reports-kpi-value">{busy && !report ? '…' : k.value}</div>
              {k.hint && <div className="v6demo-reports-kpi-hint">{k.hint}</div>}
              {k.change !== null && k.change !== undefined && (
                <div className={`v6demo-reports-kpi-delta ${k.change >= 0 ? 'up' : 'down'}`}>
                  {k.change >= 0 ? '↑' : '↓'} {Math.abs(Math.round(k.change))}% so với kỳ trước
                </div>
              )}
            </div>
          ))}
        </section>

        {/* Duoi bieu do: 2 cot */}
        <section className="v6demo-reports-cols2">
          <div className="v6demo-reports-stack">
            <div className="v6demo-glass v6demo-reports-card v6demo-rise-3">
              <h2 className="v6demo-card-title">Cơ cấu thanh toán</h2>
              <p className="v6demo-card-sub">Theo phương thức thanh toán trong kỳ đang chọn</p>
              {payData.length === 0 ? (
                <p className="v6demo-small v6demo-muted">Chưa có doanh thu trong kỳ.</p>
              ) : (
                <>
                  <div className="v6demo-reports-pay-bar">
                    {payData.map((e) => (
                      <div key={e.name} style={{ width: `${e.pct}%`, background: e.color }} />
                    ))}
                  </div>
                  {payData.map((e) => (
                    <div className="v6demo-reports-rowline" key={e.name}>
                      <span className="v6demo-reports-row-main">
                        <span style={{ width: 10, height: 10, borderRadius: 2, background: e.color, flexShrink: 0 }} />
                        <span className="v6demo-reports-ellipsis">{e.name}{e.count > 0 && <span className="v6demo-small v6demo-muted"> · {e.count} đơn</span>}</span>
                      </span>
                      <span className="v6demo-reports-row-amount">
                        <b>{formatVND(e.revenue)}</b>
                        <span className="v6demo-small v6demo-muted"> · {e.pct.toFixed(1)}%</span>
                      </span>
                    </div>
                  ))}
                </>
              )}
            </div>
            <div className="v6demo-glass v6demo-reports-card v6demo-rise-3">
              <h2 className="v6demo-card-title">Món bán chạy - Top 5</h2>
              <p className="v6demo-card-sub">Kỳ đang chọn</p>
              <div className="v6demo-reports-top-controls">
                {([
                  { key: 'qty', label: 'Số lượng' },
                  { key: 'revenue', label: 'Doanh thu' },
                  { key: 'profit', label: 'Lợi nhuận' },
                ] as const).map((o) => (
                  <button key={o.key} type="button" className={`v6demo-chip${topSortKey === o.key ? ' active' : ''}`} onClick={() => setTopSortKey(o.key)}>
                    {o.label}
                  </button>
                ))}
                <button type="button" className="v6demo-chip active" onClick={() => setTopSortDir((d) => (d === 'desc' ? 'asc' : 'desc'))}>
                  {topSortDir === 'desc' ? '↓ Giảm dần' : '↑ Tăng dần'}
                </button>
              </div>
              {top5.length === 0 ? (
                <p className="v6demo-small v6demo-muted">Chưa có dữ liệu</p>
              ) : (
                top5.map((p, i) => (
                  <div className="v6demo-reports-rowline" key={p.product_id}>
                    <span className="v6demo-reports-row-main">
                      <span className="v6demo-reports-rank">{i + 1}</span>
                      <span className="v6demo-reports-row-name" style={{ minWidth: 0 }}>
                        <b className="v6demo-reports-ellipsis" style={{ display: 'block' }}>{p.name}</b>
                        <span className="v6demo-small v6demo-muted">{p.qty} ly</span>
                      </span>
                    </span>
                    <span className="v6demo-reports-row-amount">
                      <b style={{ display: 'block' }}>{formatVND(p.revenue)}</b>
                      <span className="v6demo-reports-profit">LN {formatVND(p.profit)}</span>
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>
          <div className="v6demo-reports-stack">
            <div className="v6demo-glass v6demo-reports-card v6demo-rise-4">
              <h2 className="v6demo-card-title">Số dư các quỹ</h2>
              <p className="v6demo-reports-note-current">Số dư quỹ là trạng thái HIỆN TẠI, không theo kỳ đang chọn.</p>
              {funds.length === 0 ? (
                <p className="v6demo-small v6demo-muted">Không tải được số dư quỹ.</p>
              ) : (
                <>
                  {funds.map((f) => (
                    <div className="v6demo-reports-rowline" key={f.fund.id}>
                      <span className="v6demo-reports-ellipsis">{f.fund.name}</span>
                      <b className="v6demo-reports-row-amount">{formatVND(f.balance)}</b>
                    </div>
                  ))}
                  <div className="v6demo-reports-rowline">
                    <b>Tổng số dư</b>
                    <b>{formatVND(fundsTotal)}</b>
                  </div>
                </>
              )}
              <button type="button" className="v6demo-btn v6demo-btn-ghost v6demo-btn-block v6demo-btn-sm" style={{ marginTop: 12 }} onClick={() => navigate('/so-quy')}>
                Mở Sổ quỹ
              </button>
            </div>
            {showDebt && (
              <div className="v6demo-glass v6demo-reports-card v6demo-rise-4">
                <h2 className="v6demo-card-title">Công nợ khách hàng</h2>
                <p className="v6demo-reports-note-current">Công nợ là trạng thái HIỆN TẠI, không theo kỳ đang chọn.</p>
                {debtors.length === 0 ? (
                  <p className="v6demo-small v6demo-muted">Không có khách nợ.</p>
                ) : (
                  <>
                    {debtTop.map((c) => (
                      <div className="v6demo-reports-rowline" key={c.id}>
                        <span className="v6demo-reports-ellipsis">{c.name}</span>
                        <b className="v6demo-reports-row-amount">{formatVND(c.debt)}</b>
                      </div>
                    ))}
                    {debtRest.length > 0 && (
                      <div className="v6demo-reports-rowline">
                        <span>Khách khác ({debtRest.length} khách)</span>
                        <b>{formatVND(debtRestSum)}</b>
                      </div>
                    )}
                    <div className="v6demo-reports-rowline">
                      <b>Tổng công nợ</b>
                      <b>{formatVND(debtTotal ?? 0)}</b>
                    </div>
                  </>
                )}
                <button type="button" className="v6demo-btn v6demo-btn-ghost v6demo-btn-block v6demo-btn-sm" style={{ marginTop: 12 }} onClick={() => navigate('/debt')}>
                  Xem Sổ nợ
                </button>
              </div>
            )}
            <div className="v6demo-reports-lowstock">
              <LowStockPanel low={low} multiWarehouse={warehouses.length > 1} variant="pc" />
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
