// Chốt két tiền theo toàn bộ quỹ: cho phép chốt nhiều lần trong 1 ngày,
// xem danh sách các lần chốt, sửa/xóa (chỉ chủ quán).
// Từ v6.10: số chốt không còn là doanh thu trong ngày mà là số dư từng quỹ
// (tiền thực tế đếm được so với số phần mềm), vì tiền bán các ngày để chung.
import { useEffect, useState } from 'react';
import { DbError, deleteDayClose, getAllowedWarehouses, getDaySummary, getFundCurrentBalances, getRangeReport, listDayCloses, listPaymentMethods, saveDayClose, updateDayClose } from '../lib/db';
import type { FundBalance } from '../lib/db';
import { formatVND, todayVN } from '../lib/format';
import { useToast } from '../components/Toast';
import { Sheet } from '../components/Sheet';
import { LineIcon } from '../components/LineIcon';
import type { DayClose, DayCloseMethod } from '../lib/types';

const DENOMS = [500000, 200000, 100000, 50000, 20000, 10000, 5000, 2000, 1000];

interface FormRow {
  fund_id: string;
  name: string;
  expected: number;
}

const dcTotalActual = (dc: DayClose): number =>
  dc.funds?.length ? dc.funds.reduce((s, m) => s + m.actual, 0) : dc.cash_actual;
const dcTotalDiff = (dc: DayClose): number =>
  dc.funds?.length ? (dc.total_diff ?? dc.funds.reduce((s, m) => s + m.diff, 0)) : dc.cash_diff;

export function DayCloseSheet({ onClose }: { onClose: () => void }) {
  const toast = useToast();
  const [busy, setBusy] = useState(true);
  const [saving, setSaving] = useState(false);
  const [closes, setCloses] = useState<DayClose[]>([]);
  const [methods, setMethods] = useState<DayCloseMethod[]>([]);
  const [revenue, setRevenue] = useState(0);
  const [orderCount, setOrderCount] = useState(0);
  const [discountTotal, setDiscountTotal] = useState(0);
  const [fundBalances, setFundBalances] = useState<FundBalance[]>([]);
  const [actuals, setActuals] = useState<Record<string, string>>({});
  const [note, setNote] = useState('');
  const [closeDate, setCloseDate] = useState(todayVN());
  const [denomQty, setDenomQty] = useState<Record<string, string>>({});
  const [showForm, setShowForm] = useState(false);
  const [viewing, setViewing] = useState<DayClose | null>(null);
  const [editing, setEditing] = useState<DayClose | null>(null);
  const [isOwner, setIsOwner] = useState(false);

  const loadData = async (t: string) => {
    setBusy(true);
    try {
      const allowed = await getAllowedWarehouses().catch(() => ({ warehouses: [] as { id: string }[], isOwner: false }));
      setIsOwner(allowed.isOwner);
      const ids = allowed.isOwner ? undefined : allowed.warehouses.map((w) => w.id);
      const [list, rep, pms, sum, fb] = await Promise.all([
        listDayCloses(t),
        getRangeReport(t, t, ids),
        listPaymentMethods(false),
        getDaySummary(t, ids),
        getFundCurrentBalances(allowed.isOwner ? [] : (ids ?? []), t),
      ]);
      setCloses(list);
      setRevenue(sum.revenue);
      setOrderCount(sum.orders_count);
      setDiscountTotal(sum.discount_total);
      const kindById = new Map(pms.map((m) => [m.id, m.kind]));
      const byMethod: DayCloseMethod[] = Object.entries(rep.by_payment)
        .filter(([id]) => !(pms.find((m) => m.id === id)?.hide_reports ?? false))
        .map(([id, v]) => ({
          method_id: id,
          name: v.name,
          kind: kindById.get(id) ?? 'cash',
          amount: v.revenue,
          count: v.count,
        }));
      setMethods(byMethod);
      setFundBalances(fb);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tải được số liệu');
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => {
    void loadData(closeDate);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [closeDate]);

  const denomTotal = DENOMS.reduce((s, d) => s + d * (parseInt(denomQty[String(d)] ?? '', 10) || 0), 0);

  // Các dòng quỹ trong form: phiếu mới lấy số hệ thống hiện tại, phiếu sửa lấy số đã chốt
  const formRows: FormRow[] = editing
    ? (editing.funds?.length
        ? editing.funds.map((m) => ({ fund_id: m.fund_id, name: m.name, expected: m.expected }))
        : [{ fund_id: '__cash__', name: 'Tiền mặt', expected: editing.cash_expected }])
    : fundBalances.map((fb) => ({ fund_id: fb.fund.id, name: fb.fund.name, expected: fb.balance }));

  const parseActual = (fundId: string): number =>
    Math.max(0, parseInt((actuals[fundId] ?? '').replace(/\D/g, ''), 10) || 0);
  const allEntered = formRows.length > 0 && formRows.every((r) => (actuals[r.fund_id] ?? '').trim() !== '');
  const totalExpected = formRows.reduce((s, r) => s + r.expected, 0);
  const totalActual = formRows.reduce((s, r) => s + parseActual(r.fund_id), 0);
  const totalDiff = totalActual - totalExpected;

  // Quỹ tiền mặt để gắn bảng kiểm tiền (mệnh giá chỉ đếm được tiền mặt)
  const cashRowId = editing
    ? (editing.funds?.length
        ? (editing.funds.find((m) => fundBalances.find((fb) => fb.fund.id === m.fund_id)?.fund.kind === 'cash')?.fund_id ?? '__cash__')
        : '__cash__')
    : (fundBalances.find((fb) => fb.fund.kind === 'cash')?.fund.id ?? '');
  const denomTargetId = formRows.some((r) => r.fund_id === cashRowId) ? cashRowId : '';
  const applyDenomTotal = () => {
    if (denomTargetId) setActuals((prev) => ({ ...prev, [denomTargetId]: String(denomTotal) }));
  };

  const resetForm = () => {
    setActuals({});
    setNote('');
    setDenomQty({});
    setShowForm(false);
  };

  const buildFunds = () =>
    formRows.map((r) => {
      const actual = parseActual(r.fund_id);
      return { fund_id: r.fund_id, name: r.name, expected: r.expected, actual, diff: actual - r.expected };
    });

  const doClose = async () => {
    if (!allEntered) {
      toast.show('Nhập tiền thực tế cho tất cả các quỹ rồi mới chốt.');
      return;
    }
    if (!window.confirm(`Chốt két ngày ${closeDate}?`)) return;
    setSaving(true);
    try {
      const denoms: Record<string, number> = {};
      for (const d of DENOMS) {
        const q = parseInt(denomQty[String(d)] ?? '', 10) || 0;
        if (q > 0) denoms[String(d)] = q;
      }
      const funds = buildFunds();
      const cashRow = funds.find((m) => fundBalances.find((fb) => fb.fund.id === m.fund_id)?.fund.kind === 'cash');
      await saveDayClose({
        business_date: closeDate,
        revenue,
        orders_count: orderCount,
        discount_total: discountTotal,
        by_method: methods,
        cash_expected: cashRow?.expected ?? 0,
        cash_actual: cashRow?.actual ?? 0,
        cash_denoms: Object.keys(denoms).length > 0 ? denoms : null,
        funds,
        note: note.trim() || null,
      });
      resetForm();
      await loadData(closeDate);
      toast.show('Đã chốt két');
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Chốt két thất bại');
    } finally {
      setSaving(false);
    }
  };

  const doDelete = async (dc: DayClose) => {
    if (!window.confirm(`Xóa lần chốt lúc ${formatTime(dc.closed_at)} ngày ${dc.business_date}?`)) return;
    try {
      await deleteDayClose(dc.id);
      setViewing(null);
      await loadData(closeDate);
      toast.show('Đã xóa');
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Xóa thất bại');
    }
  };

  const doSaveEdit = async () => {
    if (!editing) return;
    if (editing.funds?.length && !allEntered) {
      toast.show('Nhập tiền thực tế cho tất cả các quỹ rồi mới lưu.');
      return;
    }
    const denoms: Record<string, number> = {};
    for (const d of DENOMS) {
      const q = parseInt(denomQty[String(d)] ?? '', 10) || 0;
      if (q > 0) denoms[String(d)] = q;
    }
    try {
      if (editing.funds?.length) {
        const funds = buildFunds();
        const cashRow = funds.find((m) => fundBalances.find((fb) => fb.fund.id === m.fund_id)?.fund.kind === 'cash');
        await updateDayClose(editing.id, {
          funds,
          cash_actual: cashRow?.actual,
          cash_denoms: Object.keys(denoms).length > 0 ? denoms : null,
          note: note.trim() || null,
        });
      } else {
        // Phiếu cũ (chỉ có tiền mặt): giữ nguyên dạng cũ
        const actual = parseActual('__cash__');
        await updateDayClose(editing.id, {
          cash_actual: actual,
          cash_denoms: Object.keys(denoms).length > 0 ? denoms : null,
          note: note.trim() || null,
        });
      }
      setEditing(null);
      setViewing(null);
      resetForm();
      await loadData(closeDate);
      toast.show('Đã lưu');
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    }
  };

  const startEdit = (dc: DayClose) => {
    const a: Record<string, string> = {};
    if (dc.funds?.length) {
      for (const m of dc.funds) a[m.fund_id] = String(m.actual);
    } else {
      a['__cash__'] = String(dc.cash_actual);
    }
    setActuals(a);
    setNote(dc.note ?? '');
    const dq: Record<string, string> = {};
    if (dc.cash_denoms) {
      for (const [k, v] of Object.entries(dc.cash_denoms)) dq[k] = String(v);
    }
    setDenomQty(dq);
    setEditing(dc);
    setViewing(null);
  };

  const formatTime = (iso: string) => {
    try {
      const d = new Date(iso);
      return d.toLocaleString('vi-VN', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' });
    } catch {
      return iso;
    }
  };

  const renderDetail = (dc: DayClose, allowEdit: boolean) => (
    <div className="card" style={{ background: 'var(--green-bg)', marginBottom: 12 }}>
      <div style={{ fontWeight: 700, marginBottom: 8, display: 'flex', alignItems: 'center', gap: 8 }}>
        <LineIcon name="wallet" size={18} /> Chốt két {formatTime(dc.closed_at)}
      </div>
      <div className="co-total-row"><span>Doanh thu ngày {dc.business_date}</span><span className="money">{formatVND(dc.revenue)}</span></div>
      <div className="co-total-row"><span>Số đơn</span><span>{dc.orders_count}</span></div>
      {dc.funds?.length ? (
        <>
          {dc.funds.map((m) => (
            <div className="co-total-row" key={m.fund_id}>
              <span>{m.name} (hệ thống)</span><span>{formatVND(m.expected)}</span>
            </div>
          ))}
          {dc.funds.map((m) => (
            <div className="co-total-row" key={`a-${m.fund_id}`}>
              <span>{m.name} (thực tế)</span><span>{formatVND(m.actual)}</span>
            </div>
          ))}
          <div className="co-total-row grand">
            <span>Chênh lệch tất cả quỹ</span>
            <span className="money" style={{ color: dcTotalDiff(dc) === 0 ? 'var(--green)' : 'var(--red)' }}>
              {dcTotalDiff(dc) > 0 ? '+' : ''}{formatVND(dcTotalDiff(dc))}
            </span>
          </div>
        </>
      ) : (
        <>
          <div className="co-total-row"><span>Tiền mặt hệ thống</span><span>{formatVND(dc.cash_expected)}</span></div>
          <div className="co-total-row"><span>Tiền mặt thực tế</span><span>{formatVND(dc.cash_actual)}</span></div>
          <div className="co-total-row grand">
            <span>Chênh lệch két</span>
            <span className="money" style={{ color: dc.cash_diff === 0 ? 'var(--green)' : 'var(--red)' }}>
              {dc.cash_diff > 0 ? '+' : ''}{formatVND(dc.cash_diff)}
            </span>
          </div>
        </>
      )}
      {dc.cash_denoms && (
        <details className="small" style={{ marginTop: 8 }}>
          <summary className="muted">Chi tiết kiểm tiền</summary>
          <div style={{ marginTop: 6 }}>
            {Object.entries(dc.cash_denoms)
              .sort((a, b) => Number(b[0]) - Number(a[0]))
              .map(([d, q]) => (
                <div className="co-total-row" key={d}>
                  <span>{formatVND(Number(d))} × {q}</span>
                  <span>{formatVND(Number(d) * q)}</span>
                </div>
              ))}
          </div>
        </details>
      )}
      {dc.note && <p className="small muted">{dc.note}</p>}
      <p className="small muted">Người chốt: {dc.closed_by_name ?? '—'}</p>
      {allowEdit && isOwner && (
        <div className="row" style={{ marginTop: 8, gap: 8 }}>
          <button className="btn btn-outline" onClick={() => startEdit(dc)}><LineIcon name="edit" size={14} /> Sửa</button>
          <button className="btn btn-ghost" style={{ color: 'var(--red)' }} onClick={() => doDelete(dc)}><LineIcon name="trash" size={14} /> Xóa</button>
        </div>
      )}
    </div>
  );

  const renderDenomTable = () => (
    <div className="card" style={{ marginBottom: 12 }}>
      <div style={{ fontWeight: 700, marginBottom: 8 }}>Kiểm tiền mặt trong két</div>
      <div className="denom-table">
        <div className="denom-head denom-row">
          <span>Mệnh giá</span>
          <span style={{ textAlign: 'center' }}>Số tờ</span>
          <span style={{ textAlign: 'right' }}>Thành tiền</span>
        </div>
        {DENOMS.map((d) => {
          const q = parseInt(denomQty[String(d)] ?? '', 10) || 0;
          return (
            <div className="denom-row" key={d}>
              <span className="money">{formatVND(d)}</span>
              <input
                className="input denom-qty"
                inputMode="numeric"
                placeholder="0"
                value={denomQty[String(d)] ?? ''}
                onChange={(e) => setDenomQty((prev) => ({ ...prev, [String(d)]: e.target.value.replace(/\D/g, '') }))}
              />
              <span className="money" style={{ textAlign: 'right' }}>{formatVND(d * q)}</span>
            </div>
          );
        })}
        <div className="denom-row denom-total">
          <span style={{ fontWeight: 700 }}>Tổng</span>
          <span />
          <span className="money" style={{ textAlign: 'right', fontWeight: 800 }}>{formatVND(denomTotal)}</span>
        </div>
      </div>
      {denomTotal > 0 && (
        <button className="btn btn-block" style={{ marginTop: 8 }} onClick={applyDenomTotal}>
          Dùng {formatVND(denomTotal)} làm tiền mặt thực tế
        </button>
      )}
    </div>
  );

  const renderForm = (isEditMode: boolean) => (
    <>
      <div className="card" style={{ marginBottom: 12 }}>
        <div className="co-total-row"><span>Doanh thu ngày {closeDate}</span><span className="money">{formatVND(revenue)}</span></div>
        <div className="co-total-row"><span>Số đơn</span><span>{orderCount}</span></div>
        {discountTotal > 0 && (
          <div className="co-total-row"><span>Đã giảm giá</span><span>-{formatVND(discountTotal)}</span></div>
        )}
        {methods.map((m) => (
          <div className="co-total-row" key={m.method_id}>
            <span>{m.name} ({m.count} đơn)</span>
            <span>{formatVND(m.amount)}</span>
          </div>
        ))}
      </div>
      <div className="card" style={{ marginBottom: 12 }}>
        <div style={{ fontWeight: 700, marginBottom: 8 }}>Tiền cần chốt (tất cả các quỹ)</div>
        <div className="co-total-row" style={{ fontWeight: 600 }}>
          <span>Quỹ</span>
          <span style={{ textAlign: 'right' }}>Hệ thống / Thực tế / Chênh</span>
        </div>
        {formRows.map((r) => {
          const entered = (actuals[r.fund_id] ?? '').trim() !== '';
          const actual = parseActual(r.fund_id);
          const diff = actual - r.expected;
          return (
            <div key={r.fund_id} style={{ padding: '8px 0', borderTop: '1px solid var(--line)' }}>
              <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center', gap: 8 }}>
                <span style={{ fontWeight: 600 }}>{r.name}</span>
                <span className="money muted">{formatVND(r.expected)}</span>
              </div>
              <div className="row" style={{ gap: 8, marginTop: 6, alignItems: 'center' }}>
                <input
                  className="input"
                  inputMode="numeric"
                  placeholder="Đếm rồi nhập tiền thực tế…"
                  value={actuals[r.fund_id] ?? ''}
                  onChange={(e) => setActuals((prev) => ({ ...prev, [r.fund_id]: e.target.value }))}
                />
                {entered && (
                  <span className="money" style={{ color: diff === 0 ? 'var(--green)' : 'var(--red)', fontWeight: 700, whiteSpace: 'nowrap' }}>
                    {diff === 0 ? 'khớp' : `${diff > 0 ? '+' : ''}${formatVND(diff)}`}
                  </span>
                )}
              </div>
            </div>
          );
        })}
        {!isEditMode && fundBalances.some((fb) => fb.fromDate) && (
          <p className="small muted" style={{ marginTop: 8 }}>
            Số hệ thống tính từ ngày đầu kỳ của từng quỹ (xem ở Sổ quỹ).
          </p>
        )}
      </div>
      {denomTargetId !== '' && renderDenomTable()}
      {allEntered && (
        <div
          className="card"
          style={{
            marginBottom: 12,
            background: totalDiff === 0 ? 'var(--green-bg)' : 'var(--red-bg)',
            color: totalDiff === 0 ? 'var(--green)' : 'var(--red)',
            fontWeight: 700,
          }}
        >
          Tổng hệ thống {formatVND(totalExpected)} · Tổng thực tế {formatVND(totalActual)} · {totalDiff === 0 ? 'Khớp tất cả quỹ' : `Chênh lệch: ${totalDiff > 0 ? '+' : ''}${formatVND(totalDiff)}`}
        </div>
      )}
      <div className="field">
        <label>Ghi chú (không bắt buộc)</label>
        <input
          className="input"
          placeholder="VD: chốt ca sáng…"
          value={note}
          onChange={(e) => setNote(e.target.value)}
        />
      </div>
      <div className="row" style={{ gap: 8 }}>
        <button
          className="btn btn-ghost grow"
          onClick={() => { setShowForm(false); setEditing(null); resetForm(); }}
        >
          Hủy
        </button>
        <button
          className="btn btn-block grow"
          disabled={saving}
          onClick={() => { if (isEditMode) void doSaveEdit(); else void doClose(); }}
        >
          {saving ? 'Đang lưu…' : isEditMode ? 'Lưu' : 'Chốt két'}
        </button>
      </div>
    </>
  );

  return (
    <Sheet title="Chốt két tiền" onClose={onClose}>
      <div className="v6demo-dayclose">
      <div className="field">
        <label>Ngày</label>
        <input
          className="input"
          type="date"
          max={todayVN()}
          value={closeDate}
          onChange={(e) => {
            if (e.target.value) { setCloseDate(e.target.value); setShowForm(false); setEditing(null); setViewing(null); }
          }}
        />
      </div>

      {busy ? (
        <div className="muted">Đang tải số liệu…</div>
      ) : editing ? (
        renderForm(true)
      ) : viewing ? (
        <>
          {renderDetail(viewing, true)}
          <button className="btn btn-block btn-ghost" onClick={() => setViewing(null)}>Quay lại danh sách</button>
        </>
      ) : showForm ? (
        renderForm(false)
      ) : (
        <>
          {closes.length === 0 ? (
            <div className="sb-empty">
              <div className="eico" style={{ display: 'flex', justifyContent: 'center' }}><LineIcon name="wallet" size={32} /></div>
              <p>Chưa chốt két ngày {closeDate}.</p>
            </div>
          ) : (
            <div style={{ marginBottom: 12 }}>
              <div className="small muted" style={{ marginBottom: 8 }}>
                Đã chốt {closes.length} lần ngày {closeDate}:
              </div>
              {closes.map((dc) => (
                <button key={dc.id} className="sb-row" onClick={() => setViewing(dc)}>
                  <span className="rbody">
                    <span className="rtitle">{formatTime(dc.closed_at)}</span>
                    <span className="rsub">
                      Thực tế {formatVND(dcTotalActual(dc))} · {dcTotalDiff(dc) === 0 ? 'khớp' : `lệch ${dcTotalDiff(dc) > 0 ? '+' : ''}${formatVND(dcTotalDiff(dc))}`}
                    </span>
                  </span>
                  <span style={{ color: 'var(--muted)', fontSize: 24 }}>›</span>
                </button>
              ))}
            </div>
          )}
          <button className="btn btn-block btn-lg" onClick={() => { resetForm(); setShowForm(true); }}>
            + Chốt két mới
          </button>
        </>
      )}
      </div>
    </Sheet>
  );
}
