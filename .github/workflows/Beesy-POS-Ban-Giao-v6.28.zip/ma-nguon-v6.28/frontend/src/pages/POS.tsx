import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  DbError,
  deleteDraftOrder,
  ensureWarehousesSeeded,
  getCustomer,
  getDefaultWarehouseId,
  getMyProfile,
  getSoldQtyByProduct,
  isPlatformSource,
  listCategories,
  listCombos,
  listDraftOrders,
  listModifierGroups,
  listProducts,
  listWarehouses,
  platformBaseUnitPrice,
  saveDraftOrder,
  suggestPlatformPrice,
} from '../lib/db';

import { addDaysVN, formatTime, formatVND, todayVN } from '../lib/format';
import { loadMenuCache, loadOutbox, removeOutboxOrder, saveMenuCache, useOnlineStatus, type OutboxOrder } from '../lib/offline';
import { useToast } from '../components/Toast';
import { PageHead } from '../components/PageHead';
import { Sheet } from '../components/Sheet';
import { TIcon } from '../components/TIcon';
import { ModifierModal } from './ModifierModal';
import { CheckoutModal } from './CheckoutModal';
import { discountAmountFor, ORDER_SOURCE_LABEL } from '../lib/types';
import type {
  CartLine,
  Category,
  Combo,
  Customer,
  DraftOrder,
  ModifierGroup,
  Order,
  Product,
  SaleSource,
  SelectedModifier,
  Warehouse,
} from '../lib/types';

// Nguồn đơn chọn ở màn Bán hàng (v6.26), theo thứ tự hiện trên màn hình.
// v6.27: chỉ giữ Tại quán / Mang đi / GrabFood theo yêu cầu của Hoàng.
// 'delivery' (Ship) và 'shopeefood' vẫn còn trong type Order.source, trong
// logic tính phí sàn và trong Cài đặt tỷ lệ sàn — chỉ ẩn khỏi giao diện
// chọn, để sau này cần thì hiện lại là xong, không phải viết lại code.
const SALE_SOURCES: SaleSource[] = ['pos', 'takeaway', 'grabfood'];


function lineKey(productId: string, mods: SelectedModifier[], note: string, unitPrice?: number): string {
  const ids = mods.map((m) => m.option_id).sort().join(',');
  return `${productId}|${ids}|${note}|${unitPrice ?? ''}`;
}

// Giá nhập tay chỉ là "ghi đè" khi khác giá menu — bằng giá menu thì coi như không ghi đè
// để dòng giá tay nhập về lại giá menu vẫn gộp chung với dòng giá menu bình thường.
function normalizeUnitPrice(product: Product, unitPrice?: number): number | undefined {
  return unitPrice !== undefined && unitPrice !== product.base_price ? unitPrice : undefined;
}



export function POS() {
  const toast = useToast();
  const { online, pending, refreshPending, doSync } = useOnlineStatus((r) => {
    if (r.fail > 0) {
      toast.show(`Có ${r.fail} đơn chờ đồng bộ bị lỗi — bấm nút "Chờ đồng bộ" ở màn bán hàng để xử lý`);
    } else if (r.ok > 0) {
      toast.show(`Đã đồng bộ xong ${r.ok} đơn chờ`);
    }
  });
  const [outboxSheet, setOutboxSheet] = useState(false);
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [combos, setCombos] = useState<Combo[]>([]);
  const [modGroups, setModGroups] = useState<ModifierGroup[]>([]);
  const [loading, setLoading] = useState(true);
  const [fromCache, setFromCache] = useState(false);
  const [activeCat, setActiveCat] = useState<string>('all');
  const [query, setQuery] = useState('');
  // Sắp xếp lưới món: mặc định (theo sort_order) / tên / bán chạy 7 ngày / giá
  const [sortMode, setSortMode] = useState<string>(() => localStorage.getItem('beesy_pos_sort') || 'default');
  const [soldQty, setSoldQty] = useState<Record<string, number>>({});

  const [cart, setCart] = useState<CartLine[]>([]);
  // Nguồn đơn (v6.26): mặc định 'pos' (Tại quán) để đơn cũ không đổi hành vi.
  // Không lưu localStorage — mỗi lần mở màn Bán hàng đều bắt đầu từ Tại quán
  // để khỏi vô tình bán đơn tại quán theo giá sàn.
  const [saleSource, setSaleSource] = useState<SaleSource>('pos');
  // Mã đơn trên sàn (VD GF-300) — bắt buộc nhập ở phần Thanh toán khi bán
  // đơn GrabFood/ShopeeFood, để đối chiếu tiền về.
  const [platformCode, setPlatformCode] = useState('');
  const isPlatform = isPlatformSource(saleSource);
  const [modProduct, setModProduct] = useState<Product | null>(null);
  const [editLine, setEditLine] = useState<CartLine | null>(null);
  const [checkoutOpen, setCheckoutOpen] = useState(false);

  // Giá 1 cốc theo nguồn đang bán: giá sàn = giá quán +25% làm tròn lên 1.000đ.
  const priceForSource = (product: Product): number =>
    isPlatformSource(saleSource) ? suggestPlatformPrice(product.base_price) : product.base_price;

  // Đổi nguồn đơn: giá các dòng đã chọn đổi theo đúng nguồn (combo giá cố định
  // thì giữ nguyên). Giá sàn đã là giá cuối nên phải trừ price_delta của
  // Size/topping đã chọn ra trước khi ghi đè, nếu không tổng đơn bị đội lên.
  const changeSource = (next: SaleSource) => {
    setSaleSource(next);
    // Đổi giá mọi dòng đã chọn theo nguồn mới (đổi qua lại Tại quán ↔
    // GrabFood thì giá đổi theo; combo giá cố định thì giữ nguyên).
    setCart((prev) =>
      prev.map((l) => {
        if (l.comboId) return l;
        const target = isPlatformSource(next) ? suggestPlatformPrice(l.product.base_price) : l.product.base_price;
        const override = platformBaseUnitPrice(target, l.modifiers);
        return { ...l, unitPrice: normalizeUnitPrice(l.product, override) };
      }),
    );
  };

  // Sau khi bán xong 1 đơn: về lại Tại quán + xóa mã sàn để đơn tiếp theo
  // không vô tình bán theo giá sàn.
  const resetSaleSource = () => {
    setSaleSource('pos');
    setPlatformCode('');
  };
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [drafts, setDrafts] = useState<DraftOrder[]>([]);
  const [draftSheet, setDraftSheet] = useState(false);
  // Kho bán: trừ tồn ở kho này khi tạo đơn (multi-kho)
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [warehouseId, setWarehouseId] = useState<string>(
    () => localStorage.getItem('beesy_warehouse_id') ?? '',
  );

  const pickWarehouse = useCallback(async () => {
    try {
      const me = await getMyProfile();
      const privileged = me.role === 'owner'; // CHỈ chủ quán thấy mọi kho
      let ws = await listWarehouses();
      if (privileged && ws.length === 0) ws = await ensureWarehousesSeeded();
      const allowed = privileged ? ws : ws.filter((w) => me.warehouse_ids.includes(w.id));
      setWarehouses(allowed);
      if (allowed.length === 0) {
        setWarehouseId('');
        return;
      }
      const saved = localStorage.getItem('beesy_warehouse_id');
      const def = await getDefaultWarehouseId();
      const pick =
        (saved && allowed.some((w) => w.id === saved) ? saved : null) ??
        (def && allowed.some((w) => w.id === def) ? def : null) ??
        allowed[0].id;
      setWarehouseId(pick);
      localStorage.setItem('beesy_warehouse_id', pick);
    } catch {
      // Không chặn bán hàng nếu lỗi tải kho — createOrder sẽ báo rõ
    }
  }, []);

  useEffect(() => {
    void pickWarehouse();
  }, [pickWarehouse]);

  const changeWarehouse = (id: string) => {
    setWarehouseId(id);
    localStorage.setItem('beesy_warehouse_id', id);
  };

  // Tải menu: ưu tiên db, rớt mạng → dùng cache localStorage
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [cats, prods, groups, cbs] = await Promise.all([
          listCategories(),
          listProducts(),
          listModifierGroups(),
          listCombos(true).catch(() => [] as Combo[]),
        ]);
        if (cancelled) return;
        setCategories(cats.filter((c) => c.active));
        setProducts(prods.filter((p) => p.active));
        setModGroups(groups.filter((x) => x.active));
        setCombos(cbs);
        saveMenuCache({ categories: cats, products: prods, modifierGroups: groups });
        setFromCache(false);
      } catch (e) {
        const cache = loadMenuCache();
        if (cache && !cancelled) {
          setCategories(cache.categories.filter((c) => c.active));
          setProducts(cache.products.filter((p) => p.active));
          setModGroups(cache.modifierGroups.filter((x) => x.active));
          setFromCache(true);
          if (e instanceof DbError && e.code === 'unavailable') toast.show('Đang offline — dùng menu đã lưu');
          else toast.show('Không tải được menu, dùng bản lưu');
        } else if (!cancelled) {
          toast.show('Không tải được menu');
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Số lượng bán 7 ngày gần nhất (cho sắp xếp "Bán chạy") — lỗi thì bỏ qua,
  // lưới món tự rơi về thứ tự mặc định.
  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const qty = await getSoldQtyByProduct(addDaysVN(todayVN(), -6), todayVN());
        if (!cancelled) setSoldQty(qty);
      } catch {
        /* bỏ qua */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const filtered = useMemo(() => {
    let list = products;
    if (warehouseId)
      list = list.filter((p) => p.warehouse_ids.length === 0 || p.warehouse_ids.includes(warehouseId));
    if (activeCat !== 'all') list = list.filter((p) => p.category_id === activeCat);
    const q = query.trim().toLowerCase();
    if (q) list = list.filter((p) => p.name.toLowerCase().includes(q));
    const arr = [...list];
    switch (sortMode) {
      case 'name':
        arr.sort((a, b) => a.name.localeCompare(b.name, 'vi') || a.sort_order - b.sort_order);
        break;
      case 'sold':
        arr.sort((a, b) => (soldQty[b.id] ?? 0) - (soldQty[a.id] ?? 0) || a.sort_order - b.sort_order);
        break;
      case 'price-asc':
        arr.sort((a, b) => a.base_price - b.base_price || a.sort_order - b.sort_order);
        break;
      case 'price-desc':
        arr.sort((a, b) => b.base_price - a.base_price || a.sort_order - b.sort_order);
        break;
      default:
        arr.sort((a, b) => a.sort_order - b.sort_order);
    }
    return arr;
  }, [products, activeCat, query, warehouseId, sortMode, soldQty]);

  // Giá ghi đè của 1 dòng: giá người bán nhập trong modal đã là GIÁ CUỐI.
  // Bán đơn sàn thì giá cuối là giá sàn, còn priceOrderLines cộng thêm
  // price_delta của Size/topping đã chọn — nên trừ delta ra trước, nếu không
  // tổng đơn bị đội lên đúng bằng delta. Bán tại quán thì giữ như cũ.
  const resolveLinePrice = (product: Product, modifiers: SelectedModifier[], unitPrice?: number) => {
    if (!isPlatformSource(saleSource)) return unitPrice;
    const finalPrice = unitPrice ?? suggestPlatformPrice(product.base_price);
    return platformBaseUnitPrice(finalPrice, modifiers);
  };

  const addLine = useCallback((product: Product, modifiers: SelectedModifier[], note: string, qty = 1, unitPrice?: number) => {
    const effPrice = normalizeUnitPrice(product, resolveLinePrice(product, modifiers, unitPrice));
    const key = lineKey(product.id, modifiers, note, effPrice);
    setCart((prev) => {
      const i = prev.findIndex((l) => l.key === key);
      if (i >= 0) {
        const next = [...prev];
        next[i] = { ...next[i], qty: next[i].qty + qty };
        return next;
      }
      return [...prev, { key, product, qty, modifiers, note, unitPrice: effPrice }];
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [saleSource]);

  // Sửa dòng đã có: đổi topping/ghi chú/số lượng/giá, giữ nguyên giảm giá dòng.
  // Dòng sửa xong trùng key với dòng khác thì gộp số lượng vào dòng đó.
  const updateLine = useCallback((oldKey: string, product: Product, modifiers: SelectedModifier[], note: string, qty: number, unitPrice?: number) => {
    const effPrice = normalizeUnitPrice(product, resolveLinePrice(product, modifiers, unitPrice));
    const newKey = lineKey(product.id, modifiers, note, effPrice);
    setCart((prev) => {
      const oldIndex = prev.findIndex((l) => l.key === oldKey);
      if (oldIndex < 0) return prev;
      const old = prev[oldIndex];
      const without = prev.filter((l) => l.key !== oldKey);
      const i = without.findIndex((l) => l.key === newKey);
      if (i >= 0) {
        const next = [...without];
        next[i] = { ...next[i], qty: next[i].qty + qty };
        return next;
      }
      const line: CartLine = {
        key: newKey,
        product,
        qty,
        modifiers,
        note,
        unitPrice: effPrice,
        comboId: old.comboId,
        discountType: old.discountType,
        discountValue: old.discountValue,
      };
      const next = [...without];
      next.splice(Math.min(oldIndex, next.length), 0, line);
      return next;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [saleSource]);

  const addComboLine = useCallback((combo: Combo) => {
    // Combo ban nhu 1 mon: gia co dinh, khong chon topping
    const pseudo: Product = {
      id: combo.id,
      name: `🍱 ${combo.name}`,
      category_id: null,
      base_price: combo.price,
      cost_price: 0,
      unit: 'combo',
      recipe: [],
      image_url: null,
      active: true,
      sort_order: 0,
      warehouse_ids: [],
    };
    const key = `combo:${combo.id}`;
    setCart((prev) => {
      const i = prev.findIndex((l) => l.key === key);
      if (i >= 0) {
        const next = [...prev];
        next[i] = { ...next[i], qty: next[i].qty + 1 };
        return next;
      }
      return [...prev, { key, product: pseudo, qty: 1, modifiers: [], note: '', comboId: combo.id }];
    });
    toast.show(`Đã thêm ${combo.name}`);
  }, []);

  const setQty = useCallback((key: string, qty: number) => {
    setCart((prev) =>
      qty <= 0 ? prev.filter((l) => l.key !== key) : prev.map((l) => (l.key === key ? { ...l, qty } : l)),
    );
  }, []);

  const clearCart = useCallback(() => {
    setCart([]);
    setCustomer(null);
  }, []);

  const refreshDrafts = useCallback(async () => {
    try {
      setDrafts(await listDraftOrders());
    } catch {
      // Không chặn bán hàng nếu tải hóa đơn tạm thất bại
    }
  }, []);

  useEffect(() => {
    void refreshDrafts();
  }, [refreshDrafts]);

  /** Lưu tạm giỏ hiện tại thành hóa đơn tạm rồi xóa giỏ. */
  const saveDraft = useCallback(async () => {
    if (cart.length === 0) {
      toast.show('Giỏ đang trống');
      return;
    }
    // Hóa đơn tạm không lưu nguồn đơn / mã sàn — mở lại sẽ thành đơn tại quán
    // theo giá quán, sai với đơn sàn. Nên đơn sàn không lưu tạm được.
    if (isPlatformSource(saleSource)) {
      toast.show('Đơn sàn không lưu tạm được — bán xong đơn này ở màn Bán hàng, hoặc xóa giỏ.');
      return;
    }
    try {
      await saveDraftOrder({
        items: cart.map((l) => ({
          product: l.product,
          qty: l.qty,
          modifiers: l.modifiers,
          note: l.note,
          unitPrice: l.unitPrice ?? null,
          discountType: l.discountType ?? null,
          discountValue: l.discountValue ?? null,
        })),
        customer_id: customer?.id ?? null,
        customer_name: customer?.name ?? null,
      });
      setCart([]);
      setCustomer(null);
      setCheckoutOpen(false);
      void refreshDrafts();
      toast.show('Đã lưu tạm hóa đơn');
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu tạm thất bại');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cart, customer, saleSource]);

  /** Mở lại hóa đơn tạm vào giỏ (chỉ khi giỏ đang trống). */
  const resumeDraft = useCallback(
    async (d: DraftOrder) => {
      if (cart.length > 0) {
        toast.show('Giỏ đang có món — hãy thanh toán, xóa giỏ hoặc lưu tạm trước');
        return;
      }
      try {
        setCart(
          d.items.map((i) => {
            const up = normalizeUnitPrice(i.product, i.unitPrice ?? undefined);
            return {
              key: lineKey(i.product.id, i.modifiers ?? [], i.note ?? '', up),
              product: i.product,
              qty: i.qty,
              modifiers: i.modifiers ?? [],
              note: i.note ?? '',
              unitPrice: up,
              discountType: i.discountType ?? null,
              discountValue: i.discountValue ?? null,
            };
          }),
        );
        if (d.customer_id) {
          try {
            setCustomer(await getCustomer(d.customer_id));
          } catch {
            setCustomer(null);
          }
        } else {
          setCustomer(null);
        }
        await deleteDraftOrder(d.id);
        void refreshDrafts();
        setDraftSheet(false);
        toast.show('Đã mở lại hóa đơn tạm');
      } catch (e) {
        toast.show(e instanceof DbError ? e.message : 'Mở lại thất bại');
      }
    },
    [cart.length],
    // eslint-disable-next-line react-hooks/exhaustive-deps
  );

  const removeDraft = useCallback(
    async (id: string) => {
      try {
        await deleteDraftOrder(id);
        void refreshDrafts();
        toast.show('Đã xóa hóa đơn tạm');
      } catch (e) {
        toast.show(e instanceof DbError ? e.message : 'Xóa thất bại');
      }
    },
    [refreshDrafts],
  );

  const totalQty = cart.reduce((s, l) => s + l.qty, 0);
  const grandTotal = cart.reduce((s, l) => {
    const gross = l.qty * ((l.unitPrice ?? l.product.base_price) + l.modifiers.reduce((a, m) => a + m.price_delta, 0));
    return s + gross - discountAmountFor(gross, l.discountType, l.discountValue);
  }, 0);

  // Tổng số lượng từng món (gộp các dòng cùng product id, kể cả khác topping)
  const qtyByProduct = useMemo(() => {
    const m: Record<string, number> = {};
    for (const l of cart) m[l.product.id] = (m[l.product.id] ?? 0) + l.qty;
    return m;
  }, [cart]);

  const openModifier = (p: Product) => {
    if (!modGroups.length) {
      addLine(p, [], '');
      toast.show(`Đã thêm ${p.name}`);
      return;
    }
    setModProduct(p);
  };

  return (
    <div className="pos">
      <div className="pos-left">
        <PageHead title="Bán hàng" />
        <div className="row" style={{ gap: 8, marginBottom: 10 }}>
          <div className="sb-search grow">
            <span className="sico"><TIcon emoji="🔍" size={18} /></span>
            <input
              placeholder="Tìm theo tên món…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>
          <button
            className="btn btn-outline"
            style={{ minHeight: 48, whiteSpace: 'nowrap' }}
            onClick={() => setDraftSheet(true)}
            aria-label="Hóa đơn tạm"
          >
            <TIcon emoji="🗂" size={14} /> Tạm{drafts.length > 0 ? ` (${drafts.length})` : ''}
          </button>
          {pending > 0 && (
            <button
              className="btn btn-outline"
              style={{ minHeight: 48, whiteSpace: 'nowrap', borderColor: '#dc2626', color: '#dc2626' }}
              onClick={() => setOutboxSheet(true)}
              aria-label="Đơn chờ đồng bộ"
            >
              <TIcon emoji="⚠️" size={14} /> Chờ đồng bộ ({pending})
            </button>
          )}
          <select
            className="ov-filter-select"
            style={{ minHeight: 48 }}
            value={sortMode}
            onChange={(e) => {
              setSortMode(e.target.value);
              localStorage.setItem('beesy_pos_sort', e.target.value);
            }}
            aria-label="Sắp xếp món"
            title="Sắp xếp món"
          >
            <option value="default">Mặc định</option>
            <option value="name">Tên A-Z</option>
            <option value="sold">Bán chạy (7 ngày)</option>
            <option value="price-asc">Giá thấp - cao</option>
            <option value="price-desc">Giá cao - thấp</option>
          </select>
          {fromCache && <span className="small muted">📦 menu offline</span>}
        </div>
        {/* Nguồn đơn (v6.26): chọn trước khi bấm món. Đổi nguồn thì giá các dòng đã chọn đổi theo. */}
        <div className="row" style={{ gap: 8, marginBottom: 10, flexWrap: 'wrap', alignItems: 'center' }}>
          <span className="small muted" style={{ alignSelf: 'center' }}>Nguồn đơn:</span>
          {SALE_SOURCES.map((s) => (
            <button
              key={s}
              type="button"
              className={`sb-chip${saleSource === s ? ' selected' : ''}`}
              style={{ minHeight: 36, padding: '4px 12px', fontSize: 13 }}
              onClick={() => changeSource(s)}
              aria-label={`Nguồn đơn ${ORDER_SOURCE_LABEL[s]}`}
            >
              {ORDER_SOURCE_LABEL[s]}
            </button>
          ))}
        </div>
        {isPlatform && (
          <p className="small" style={{ margin: '-4px 0 10px', color: 'var(--green)', fontWeight: 600 }}>
            Đang bán theo giá sàn {ORDER_SOURCE_LABEL[saleSource]} — giá món đã +25% so với giá quán.
            Nhập mã đơn sàn ở phần Thanh toán trước khi xác nhận.
          </p>
        )}
        {warehouses.length > 1 && (
          <div className="row" style={{ gap: 8, marginBottom: 10, flexWrap: 'wrap' }}>
            <span className="small muted" style={{ alignSelf: 'center' }}>🗃️ Kho bán:</span>
            {warehouses.map((w) => (
              <button
                key={w.id}
                type="button"
                className={`sb-chip${warehouseId === w.id ? ' selected' : ''}`}
                style={{ minHeight: 36, padding: '4px 12px', fontSize: 13 }}
                onClick={() => changeWarehouse(w.id)}
              >
                {w.name}
                {w.is_default ? ' ★' : ''}
              </button>
            ))}
          </div>
        )}
        <div className="chip-row">
          <button
            className={`sb-chip${activeCat === 'all' ? ' selected' : ''}`}
            onClick={() => setActiveCat('all')}
          >
            Tất cả
          </button>
          {combos.length > 0 && (
            <button
              className={`sb-chip${activeCat === 'combo' ? ' selected' : ''}`}
              onClick={() => setActiveCat('combo')}
            >
              🍱 Combo
            </button>
          )}
          {categories.map((c) => (
            <button
              key={c.id}
              className={`sb-chip${activeCat === c.id ? ' selected' : ''}`}
              onClick={() => setActiveCat(c.id)}
            >
              {c.name}
            </button>
          ))}
        </div>
        {loading ? (
          <div className="card">Đang tải menu…</div>
        ) : activeCat === 'combo' ? (
          <div className="product-grid">
            {combos.map((cb) => {
              const q = cart.find((l) => l.key === `combo:${cb.id}`)?.qty ?? 0;
              return (
                <button key={cb.id} className={`product-card${q > 0 ? ' in-cart' : ''}`} onClick={() => addComboLine(cb)}>
                  <span className="pname">🍱 {cb.name}</span>
                  <span className="psub" style={{ display: 'block', fontSize: 12, color: 'var(--muted)' }}>
                    {cb.items.map((it) => `${it.qty}× ${it.product_name}`).join(' + ')}
                  </span>
                  <span className="pprice">{formatVND(cb.price)}</span>
                  {q > 0 && <span className="qty-num">{q}</span>}
                </button>
              );
            })}
          </div>
        ) : filtered.length === 0 ? (
          <div className="card muted">Không có món nào. {online ? 'Thêm món ở trang Menu.' : 'Kiểm tra mạng.'}</div>
        ) : (
          <div className="product-grid">
            {filtered.map((p) => {
              const q = qtyByProduct[p.id] ?? 0;
              const lastLine = q > 0 ? [...cart].reverse().find((l) => l.product.id === p.id) : undefined;
              return (
                <button
                  key={p.id}
                  className={`product-card${q > 0 ? ' in-cart' : ''}`}
                  onClick={() => openModifier(p)}
                >
                  <span className="pname">{p.name}</span>
                  <span className="pprice">{formatVND(priceForSource(p))}{p.unit ? `/${p.unit}` : ''}</span>
                  {q > 0 && (
                    <span className="pstep">
                      <button
                        aria-label="Giảm"
                        onClick={(e) => {
                          e.stopPropagation();
                          if (lastLine) setQty(lastLine.key, lastLine.qty - 1);
                        }}
                      >
                        −
                      </button>
                      <span className="qty-num">{q}</span>
                      <button
                        aria-label="Tăng"
                        onClick={(e) => {
                          e.stopPropagation();
                          openModifier(p);
                        }}
                      >
                        +
                      </button>
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        )}
      </div>

      <aside className="pos-right">
        <CheckoutModal
          embedded
          lines={cart}
          customer={customer}
          total={grandTotal}
          warehouseId={warehouseId}
          source={saleSource}
          platformCode={platformCode}
          onPlatformCodeChange={setPlatformCode}
          onClose={() => {}}
          onUpdateQty={setQty}
          onEditLine={(line) => setEditLine(line)}
          onUpdateLineDiscount={(key, type, value) =>
            setCart((prev) =>
              prev.map((l) => (l.key === key ? { ...l, discountType: type, discountValue: value } : l)),
            )
          }
          onCustomerChange={setCustomer}
          onSaveDraft={() => void saveDraft()}
          onClearCart={clearCart}
          onDone={(order: Order | null, queued: boolean) => {
            clearCart();
            resetSaleSource();
            refreshPending();
            if (queued) toast.show('Đã lưu đơn chờ — sẽ tự đồng bộ khi có mạng');
            else if (order) toast.show(`Tạo đơn ${order.code} thành công`);
          }}
        />
      </aside>

      {totalQty > 0 && !checkoutOpen && (
        <button className="sb-cart-bar" onClick={() => setCheckoutOpen(true)}>
          <span>
            Số lượng<span className="qty-badge">{totalQty}</span>
          </span>
          <span className="money">{formatVND(grandTotal)} ›</span>
        </button>
      )}

      {modProduct && (
        <ModifierModal
          product={modProduct}
          groups={modGroups}
          allowCustomPrice
          priceBase={priceForSource(modProduct)}
          onClose={() => setModProduct(null)}
          onAdd={(mods, note, qty, price) => {
            addLine(modProduct, mods, note, qty, price);
            setModProduct(null);
            toast.show(`Đã thêm ${modProduct.name}`);
          }}
        />
      )}

      {editLine && (
        <ModifierModal
          product={editLine.product}
          groups={modGroups}
          initial={{ modifiers: editLine.modifiers, note: editLine.note, qty: editLine.qty, unitPrice: editLine.unitPrice }}
          allowCustomPrice
          priceBase={priceForSource(editLine.product)}
          onClose={() => setEditLine(null)}
          onAdd={(mods, note, qty, price) => {
            updateLine(editLine.key, editLine.product, mods, note, qty, price);
            setEditLine(null);
            toast.show(`Đã sửa ${editLine.product.name}`);
          }}
        />
      )}

      {checkoutOpen && (
        <CheckoutModal
          lines={cart}
          customer={customer}
          total={grandTotal}
          warehouseId={warehouseId}
          source={saleSource}
          platformCode={platformCode}
          onPlatformCodeChange={setPlatformCode}
          onClose={() => setCheckoutOpen(false)}
          onUpdateQty={setQty}
          onEditLine={(line) => setEditLine(line)}
          onUpdateLineDiscount={(key, type, value) =>
            setCart((prev) =>
              prev.map((l) => (l.key === key ? { ...l, discountType: type, discountValue: value } : l)),
            )
          }
          onCustomerChange={setCustomer}
          onSaveDraft={() => void saveDraft()}
          onDone={(order: Order | null, queued: boolean) => {
            setCheckoutOpen(false);
            clearCart();
            resetSaleSource();
            refreshPending();
            if (queued) toast.show('Đã lưu đơn chờ — sẽ tự đồng bộ khi có mạng');
            else if (order) toast.show(`Tạo đơn ${order.code} thành công`);
          }}
        />
      )}

      {draftSheet && (
        <DraftSheet
          drafts={drafts}
          onClose={() => setDraftSheet(false)}
          onResume={(d) => void resumeDraft(d)}
          onDelete={(id) => void removeDraft(id)}
        />
      )}
      {outboxSheet && (
        <OutboxSheet
          onClose={() => {
            setOutboxSheet(false);
            refreshPending();
          }}
          onRetry={async () => {
            await doSync();
          }}
        />
      )}
    </div>
  );
}

function DraftSheet({
  drafts,
  onClose,
  onResume,
  onDelete,
}: {
  drafts: DraftOrder[];
  onClose: () => void;
  onResume: (d: DraftOrder) => void;
  onDelete: (id: string) => void;
}) {
  return (
    <Sheet title={`Hóa đơn tạm (${drafts.length})`} onClose={onClose}>
      {drafts.length === 0 ? (
        <div className="sb-empty">
          <div className="eico">🗂</div>
          <p>Chưa có hóa đơn tạm nào.</p>
        </div>
      ) : (
        drafts.map((d) => {
          const qty = d.items.reduce((s, i) => s + i.qty, 0);
          const total = d.items.reduce(
            (s, i) =>
              s + i.qty * ((i.unitPrice ?? i.product.base_price) + (i.modifiers ?? []).reduce((a, m) => a + m.price_delta, 0)),
            0,
          );
          return (
            <div key={d.id} className="sb-section" style={{ marginBottom: 10 }}>
              <div className="row" style={{ justifyContent: 'space-between', marginBottom: 6 }}>
                <b>{d.customer_name ?? 'Khách lẻ'}</b>
                <span className="small muted">{formatTime(d.created_at)}</span>
              </div>
              <div className="small" style={{ marginBottom: 6 }}>
                {d.items.map((i) => `${i.qty}× ${i.product.name}`).join(', ')}
              </div>
              <div className="small muted" style={{ marginBottom: 10 }}>
                {qty} món · <span className="money">{formatVND(total)}</span>
              </div>
              <div className="row" style={{ gap: 8 }}>
                <button className="btn grow" onClick={() => onResume(d)}>
                  Mở lại
                </button>
                <button className="btn btn-outline" onClick={() => onDelete(d.id)}>
                  Xóa
                </button>
              </div>
            </div>
          );
        })
      )}
      <p className="small muted" style={{ marginTop: 12 }}>
        Mở lại chỉ dùng được khi giỏ đang trống. Hóa đơn tạm giữ nguyên giá món lúc lưu.
      </p>
    </Sheet>
  );
}

function OutboxSheet({ onClose, onRetry }: { onClose: () => void; onRetry: () => Promise<void> }) {
  const [items, setItems] = useState<OutboxOrder[]>(() => loadOutbox());
  const [busy, setBusy] = useState(false);
  const retry = async () => {
    setBusy(true);
    try {
      await onRetry();
      setItems(loadOutbox());
    } finally {
      setBusy(false);
    }
  };
  return (
    <Sheet title={`Đơn chờ đồng bộ (${items.length})`} onClose={onClose}>
      <p className="small muted" style={{ marginBottom: 12 }}>
        Các đơn này bán lúc mất mạng hoặc đồng bộ bị lỗi. Đơn lỗi KHÔNG tự bị xóa —
        hãy thử đồng bộ lại khi có mạng. Chỉ xóa khi chắc chắn đơn không còn cần
        (đơn có thể đã thu tiền khách ngoài đời).
      </p>
      {items.length === 0 && <p className="small">Không còn đơn chờ nào.</p>}
      {items.map((o) => (
        <div key={o.clientUuid} className="sb-row" style={{ cursor: 'default' }}>
          <span className="rbody">
            <span className="rtitle" style={{ fontSize: 14, fontWeight: 600 }}>
              {o.payload.items.reduce((s, it) => s + (Number(it.qty) || 0), 0)} món —{' '}
              {new Date(o.createdAt).toLocaleString('vi-VN')}
            </span>
            {o.lastError && (
              <span className="rsub" style={{ color: '#dc2626' }}>Lỗi: {o.lastError}</span>
            )}
          </span>
          <button
            className="btn btn-outline btn-sm"
            onClick={() => {
              if (window.confirm('Xóa hẳn đơn chờ này? Đơn sẽ không được đồng bộ lên hệ thống nữa.')) {
                removeOutboxOrder(o.clientUuid);
                setItems(loadOutbox());
              }
            }}
          >
            Xóa
          </button>
        </div>
      ))}
      {items.length > 0 && (
        <button className="btn btn-block" style={{ marginTop: 12, minHeight: 48 }} disabled={busy} onClick={() => void retry()}>
          {busy ? 'Đang đồng bộ…' : 'Thử đồng bộ lại'}
        </button>
      )}
    </Sheet>
  );
}

