﻿BAN GIAO DU AN BEESY POS - TINH DEN BAN v6.28
================================================

Ngay ban giao: 10/11/2026
Nguoi ban giao: Muse (AI dang lam viec voi Hoang)
Nguoi nhan: Hoang va AI tiep nhan du an
Muc dich: goi nay chua day du thong tin, ma nguon, cach cai dat, tinh nang
va tai khoan de AI khac co the tiep tuc lam viec tren du an Beesy POS
ma khong can hoi lai tu dau. Hoang se chay song song 2 AI tren du an
nay de doi chieu, tim loi.

QUY TAC DOC TAI LIEU NAY
- Mọi file văn bản trong goi nay chi dung ky tu ASCII va chu tieng Viet
  co dau, theo dung quy tac cua Hoang. File .md co BOM UTF-8.
- Tai lieu nay tom tat tu ghi chu lam viec thuc te den ngay 10/11/2026.
  Neu tai lieu va ma nguon lech nhau, MA NGUON LA CHUAN. AI tiep nhan
  phai tu kiem chung lai, khong tin tai lieu mot cach mu.

1. MUC DICH BAN GIAO
--------------------
- Beesy POS la webapp ban hang cho quan Beesy Coffee & Tea cua Hoang
  (Hai Phong, tu van hanh mot minh, khong thue nhan vien).
- Ban moi nhat da build xong la v6.28 (10/11/2026). Ban dang chay tren
  trang live van la v6.24 (kiem chung lan cuoi 08/11/2026). Cac ban
  v6.25, v6.26, v6.27, v6.28 da build xong nhung CHUA CO XAC NHAN da deploy.
- AI tiep nhan can: (a) doc het tai lieu nay; (b) tu build va kiem
  chung lai source v6.28; (c) ra soat loi (dac biet logic tien bac,
  ma chung tu, dong bo du lieu); (d) tiep tuc sua theo yeu cau cua Hoang.

2. TRANG THAI HIEN TAI (10/11/2026)
-----------------------------------
- Ban production moi nhat: v6.28, ngay 10/11/2026.
  File: app-v6.28.zip, 115 file, 2.388.033 byte,
  sha256: 46642e687bf0ede8229ab2c4d451a6f8fffda573cccd026e9ccb564f433e8795
- Ban truoc do: v6.27 (07/11/2026, 115 file, 2.378.569 byte,
  sha256: b217a11a2351089c5a722b18fe816847465dda784b39550257802466c8073610).
  v6.26 (07/11/2026, 115 file, 2.384.582 byte,
  sha256: 9f6b8aab6cf3dd5dca8041f2ae8dabc031a7642a802ceb5fb1ee2ec926633a21).
  v6.25 (07/11/2026) co form nhap don san rieng, DA BO, khong dung nua.
  v6.28 THAY THE v6.27: deploy thang v6.28 la du, khong can deploy
  v6.27 truoc.
- v6.28 sua gi: sap xep dung thu tu tao phieu, chuan toi tung giay.
  Truoc day o gio o man thanh toan va form nhap tay So quy luon gui
  kem gio phut hien tai nen moi phieu cung phut co created_at giong
  het nhau, cong comparator cu sai hop dong sort va xep theo ID ngau
  nhien khi trung gio. v6.28 chi gui gio khi nguoi ban da cham o gio
  (khong cham thi lay gio that co mili-giay) va moi danh sach sap
  bang compareSlipDesc/Asc (created_at toi giay, roi so ma phieu
  A/PN/XK/SX/PT/PC, roi hang bo 3 khoan don san). Test logic 11/11
  dung; UI chua kiem chung bang anh chup.
- Trang live: https://webapp-beesy-pos.web.app - van la v6.24
  (kiem chung lan cuoi 08/11/2026). Chua co xac nhan v6.28 da len live.
- Dong thu nghiem rieng (KHONG phai production): v6 demo 4, source tai
  beesy-pos-v6-demo/, file app-v6-demo-4.zip (127 file). Dong nay la
  giao dien moi hoan toan, chua duyet de dua vao production. KHONG DUOC
  nham lan 2 dong nay voi nhau.
- Vu viec chua co loi giai (05/11/2026): ban v6 demo 4 da upload len
  repo, lan chay Actions #313 luc 13:42 chay xanh (thanh cong), repo
  chi con dung 1 file zip la demo 4, nhung trang live van hien v6.24
  khi kiem tra moi hoan toan (khong dang nhap, khong cache). Nguyen
  nhan CHUA RO. AI tiep nhan can luu y khi deploy: phai kiem tra ten
  ban tren man hinh dang nhap sau moi lan deploy, khong do loi cho
  cache dien thoai khi chua kiem tra live that.

3. DU AN LA GI
--------------
- Ten: Beesy POS. Chu quan: Hoang. Quan: Beesy Coffee & Tea, Hai Phong.
- Loai hinh: webapp ban hang tai quay (POS), quan ly menu va kho, bao
  cao, nhan su co ban. Chay tren PC, tablet va dien thoai. Du lieu
  dong bo thoi gian thuc.
- Trang live: https://webapp-beesy-pos.web.app
- Repo: github.com/thanghoangbeesy/beesy-pos (public, nhanh main)
- Firebase project: webapp-beesy-pos, goi Spark (mien phi),
  KHONG dung Cloud Functions. Phu thuoc Google, phi theo luot doc/ghi.
- Dang nhap lan dau: mo /setup de tao chu quan (owner) va nap menu mau.
- Email chu quan (super admin): thanghoang.beesy@gmail.com
- SDT / Zalo du an: 0876 791 593

4. TAI KHOAN VA DICH VU
------------------------
GOI NAY KHONG CHUA BAT CU MAT KHAU, KHOA API, KHOA DICH VU NAO.
Chi liet ke ten tai khoan va noi luu tru de AI tiep nhan biet duong
tim, khong duoc doan gia tri.

- Firebase project: webapp-beesy-pos (Spark). Console:
  console.firebase.google.com. Can cac secret duoi day (luu trong
  GitHub Secrets cua repo, KHONG co trong goi nay):
  FIREBASE_SERVICE_ACCOUNT, FIREBASE_PROJECT_ID,
  VITE_FIREBASE_API_KEY, VITE_FIREBASE_AUTH_DOMAIN,
  VITE_FIREBASE_PROJECT_ID, VITE_FIREBASE_STORAGE_BUCKET,
  VITE_FIREBASE_MESSAGING_SENDER_ID, VITE_FIREBASE_APP_ID,
  VITE_GOOGLE_CLIENT_ID (tuy chon, cho sao luu Google Drive).
- GitHub repo: thanghoangbeesy/beesy-pos. Hoang tu upload file zip
  len repo va chay workflow bang dien thoai. AI KHONG tu push len
  repo, KHONG sua file trong .github/workflows/ (thieu quyen).
- MoMo (cau hinh thanh toan trong app, khong phai mat khau):
  STK PSP2625815400000051, ten Hoang Kim Thang, BIN 971025.
- Google AI Pro (5TB Drive) cua Hoang: dung de sao luu. Tinh nang
  sao luu/khoi phuc Google Drive DANG CHO Hoang gui OAuth Client ID
  (da gui 4 buoc cau hinh ngay 12/10/2026). Sao luu tu dong theo
  lich can goi Blaze (tra phi), chua lam.

5. CONG NGHE VA CAU TRUC MA NGUON
----------------------------------
- Frontend: Vite + React + TypeScript. Thu muc: frontend/src/
- Backend: Firestore + Firebase Auth + Firebase Hosting. Khong co
  may chu rieng, khong co Cloud Functions.
- PWA: vite-plugin-pwa (generateSW, precache). App cai duoc tren
  dien thoai nhu app thuong.
- Build: tsc -b && vite build. Len hien thi lay tu
  frontend/vite.config.ts (bien __APP_VERSION__).
- File cau hinh goc source: firebase.json, firestore.rules,
  firestore.indexes.json, PHIENBAN.txt (co BOM UTF-8).
- firestore.rules: md5 0bbc81e37dc76da2380be0868f7d1fbd, khong doi
  tu v5.6 den v6.28. v6.25 - v6.28 KHONG doi rules, KHONG them
  collection, KHONG them thu vien -> deploy khong can Publish rules moi.
- Cac file quan trong trong frontend/src/:
  - lib/db.ts: toan bo doc/ghi Firestore, transaction, migration ngam.
  - lib/types.ts: kieu du lieu (Order, Customer, Product...).
  - lib/wac.ts, lib/stock-ledger.ts: gia von binh quan gia quyen,
    so cai kho.
  - lib/vietqr.tsx, lib/banks.ts: tao QR VietQR.
  - lib/bill-image.ts, pages/BillPrint.tsx: in/luu anh bill.
  - Sap xep chuan (v6.28): compareSlipDesc / compareSlipAsc +
    codeSeq trong lib/db.ts (created_at toi giay, roi so ma phieu
    A/PN/XK/SX/PT/PC, roi hang bo 3 khoan don san). CheckoutModal va
    form nhap tay So quy chi gui gio khi nguoi ban da cham o gio
    (co orderTimeTouched / occurredTouched); khong cham thi lay gio
    that co mili-giay.
  - components/Layout.tsx: khung trang (sidebar PC 232px, nav mobile).
    Cac trang render ben trong Layout, KHONG tu dung sidebar moi.
  - components/TIcon.tsx, LineIcon.tsx, MenuIcon.tsx: icon lineal
    (net manh). TOAN BO giao dien dung lineal icon, KHONG dung emoji
    lam icon.
  - pages/POS.tsx: man Ban hang. pages/Orders.tsx: Don hang.
  - pages/CheckoutModal.tsx: thanh toan (1 man hinh, tach nhieu
    phuong thuc). pages/ModifierModal.tsx: chon topping.
  - pages/OrderEditForm.tsx: sua don da luu. pages/SoQuy.tsx: So quy.
  - pages/DayCloseSheet.tsx: Chot ket. pages/Reports.tsx +
    ReportsPC.tsx + ReportsMobile.tsx: Tong quan (PC/mobile rieng).
  - pages/Menu.tsx, Inventory.tsx, Purchase.tsx, DebtBook.tsx,
    Customers.tsx, Settings.tsx, BaoCao.tsx, KDS.tsx,
    OnlineOrder.tsx, OnlineOrders.tsx, AuditLog.tsx, Setup.tsx,
    Login.tsx, ChangePassword.tsx, ManagedShops.tsx.
  - pages/pc-*.css: CSS rieng cho cac trang PC.
- Luu y ky thuat:
  - tx.get() KHONG nhan Query trong SDK nay: doc collection bang
    getDocs TRUOC roi moi chay transaction.
  - useEffect tham chieu bien khai bao sau se loi TS (TDZ).
  - CSS index.css co nhieu khoi media query chong nhau (min-width
    769px o cuoi file co the de rule o khoi 1024px). Sua CSS PC phai
    grep moi rule cung selector trong toan file.
  - Khong cat ngam danh sach du lieu kinh doanh: moi truy van danh
    sach (don, phieu, so quy, khach...) phai phan trang tai HET,
    hoac hien ro "dang xem X/Y + nut tai them". (Bai hoc 24/10/2026:
    listOrders tung gioi han 300 don moi nhat lam don cu "bien mat"
    khoi man hinh, du du lieu van con nguyen.)
  - Ngay gio trong app luon theo gio Viet Nam (Asia/Saigon), khong
    dung gio UTC tho.

6. MO HINH DU LIEU (Firestore)
-------------------------------
- Danh sach day du xem trong frontend/src/lib/db.ts. Cac nhom chinh:
  - Don ban hang (orders): ma don duy nhat toan he thong, khong dung
    lai so da xoa. Co truong nguon don (Order.source): tai-quan,
    mang-di, ship, grabfood, shopeefood (xem muc 8).
  - Hang hoa / nguyen lieu (products, ingredients), danh muc
    (categories), topping theo nhom (modifiers).
  - Khach hang (customers): ten, ngay sinh, SDT, dia chi, lich su
    mua, cong no, tich diem.
  - So quy (fund_transactions) + quy (settings/funds: Tien mat tai
    quay, Chuyen khoan) + danh muc thu/chi (settings/fund_categories).
    'Ban hang' / 'Thu no' la danh muc khoa. Chi chu quan sua.
  - Cong no (debts), nha cung cap (suppliers), phieu nhap/xuat
    (purchase_orders), ton kho, phieu san xuat (production_orders,
    ma SX001), nhat ky thao tac (audit log).
  - Cai dat: settings/platform_rates (ty le san, xem muc 8),
    settings/fund_categories, settings/funds.
- Quy tac ma: MOI ma chung tu va ma hang hoa/nguyen lieu deu DUY NHAT
  toan he thong, so da xoa KHONG duoc dung lai, so moi luon la so
  tiep theo.
- Sua du lieu hang loat: app TU chay migration ngam mot lan duy nhat,
  khong dua nut bam thu cong cho Hoang. Truong moi co gia tri mac dinh
  thi khong can migration.

7. TINH NANG CHINH
------------------
- Ban hang: chon kho ban, luoi mon (tim kiem khong dau), chon topping
  theo nhom + nhap tay so luong + gia ban tay (0 = tang) + ghi chu
  pha che, sua mon / giam gia tung dong gio, giam gia don (%/tien),
  gio vang, voucher, giam theo hang, phi ship, ghi chu don, chon
  khach (ghi no bat buoc chon khach), tach nhieu phuong thuc thanh
  toan, tien khach tra + tien thua, VietQR / in bill / gui Zalo sau
  thanh toan, luu tam don.
- Phuong thuc thanh toan tuy chinh (Cai dat): ten, loai (Tien mat /
  Chuyen khoan / Ghi no), icon, STK/BIN; co 2 co an (hide_pos,
  hide_reports). Bao cao tach theo phuong thuc.
- Don hang: tim kiem + loc ngay, loc kho, loc nguon don; xem chi
  tiet, sua ghi chu/khach hang, xoa don chi chu quan (hoan no, xoa
  khoan quy lien quan, hoan tem -1 khong am, thu hoi thuong neu don
  kich hoat thuong ma khach chua doi); sua toan bo don (doi topping,
  mon, gia, voucher, thanh toan).
- So quy: don thu tien tu ghi 'Doanh thu ban hang' kem ma don (bam
  mo chi tiet); 'Thu no - ten khach'; tien khach tra mac dinh bang
  tong hoa don; nhap tay va thu no duoc chon quy; don tu ghi dung
  quy theo phuong thuc thanh toan; loc Ky du 7 moc (hom nay, hom
  qua, tuan nay, tuan truoc, thang nay, thang truoc, tuy chon);
  Danh muc / Ra soat / xuat Excel; sua/xoa khoan; Chot ket (chi con
  nut o So quy, chot toan bo quy).
- So no: theo doi cong no khach, thu no / ghi no, mo form voi khach
  chon san.
- Khach hang: the Cong no, lich su mua, tich diem, doi thuong.
- Menu: them mon, them hang loat, form mon 2 tab + cong thuc, an /
  hien / xoa mon, nhom topping, quan ly danh muc, tim kiem khong dau.
- Ton kho: da kho + phan quyen kho (Cai dat -> Nhan vien); POS chon
  kho ban; huy/xoa don hoan kho ve dung kho; tab Chuyen kho. Chi chu
  quan thay moi kho; moi nhan vien (ke ca Quan ly) chi thay/dung kho
  da gan, chan o ca rules lan client.
- Nhap xuat: phieu nhap/xuat (ma duy nhat), chon nguyen lieu, in
  phieu, tab 'Quan no NCC'.
- San xuat (ban thanh pham): cong thuc nhap theo me, tab San xuat,
  kiem tra du ton, phieu xem/xoa hoan tac; gia von BTP tinh binh quan
  gia quyen. Cong thuc that: cot cafe 185g bot tron + 15g bot nguyen
  chat -> 500ml/me; kem muoi 800ml kem beo + 50g muoi hong + 150ml
  sua dac -> 1000ml/me.
- Bao cao / Tong quan: loc thoi gian 7 moc + Tuy chon 2 o ngay; bieu
  do ky 1 ngay theo gio (24 cot), nhieu ngay theo ngay, luon co cap
  cot ky nay + ky truoc; 3 nut chi so Doanh thu / Loi nhuan / Chi
  phi; bam nhom cot xem chi tiet; KPI bam duoc (Doanh thu -> So quy
  muc Thu, Tong chi phi -> muc Chi, Tong cong no -> So no); Top 5
  co sap xep; khoi Canh bao sap het; cong no top 4 + "Khach khac".
  PC va mobile la 2 bo cuc rieng (ReportsPC.tsx / ReportsMobile.tsx,
  chuyen o 1024px).
- Cai dat: thong tin quan, nhan vien + phan quyen kho, phuong thuc
  thanh toan, ty le san (muc 8), cong tac 'Tinh chi phi nhap hang +
  nguyen lieu vao chi phi tong' (setting include_goods_costs, CHI
  o Cai dat).
- Chuan so lieu: 'Chi phi' mac dinh = CHI chi phi van hanh (loai
  transfer / purchase / supplier_pay / debt_refund va danh muc
  'Chuyen quy' / 'Nhap hang' / 'Tra no NCC'); ngay khoan quy theo
  gio VN o moi bao cao; huy don hoan tac day du nhu xoa don; nhan
  theo mon = 'Loi nhuan gop', tong = 'Loi nhuan rong'.
- Sap xep danh sach (v6.28): moi danh sach hoa don/chung tu (Don hang,
  So quy, Nhap xuat, San xuat, so ghi kho) sap theo dung thu tu tao
  phieu, chuan toi tung giay; cung moc thoi gian thi xep theo ma phieu.

8. DON SAN GRABFOOD / SHOPEEFOOD (v6.25 - v6.27)
------------------------------------------------
- Hoang bat dau ban tren GrabFood va ShopeeFood tu 07/11/2026. Don
  san va don POS khong cung he thong. Gia tren app san do Hoang tu
  dat, moi la chuan; bang +25% chi la tham khao.
- Gia san mac dinh trong app: gia tai quan +25%, lam tron LEN toi
  1.000d. VD: Nuoc Ep Luu Cam gia quan 30.400d thi gia san 38.000d.
  Bang gia day du 37 mon trong file tai-lieu-kem/
  Bang-Gia-GrabFood-ShopeeFood.csv (gia chua kem topping).
- v6.26: ban chung 1 man Ban hang, them o "Nguon don" gom 5 loai: Tai
  quan, Mang di, Ship, GrabFood, ShopeeFood. v6.27 (07/11/2026,
  theo yeu cau cua Hoang luc 18:41): CHI GIU 3 loai trong o chon:
  Tai quan, Mang di, GrabFood. Ship va ShopeeFood CHI AN khoi o
  chon va bo loc Don hang, KHONG xoa type, KHONG xoa ty le Shopee,
  KHONG xoa code tinh phi san. Don cu 2 nguon nay van hien khi loc
  "Moi nguon". Can them lai chi viec hien lai lua chon.
- Chon GrabFood: gia mon tren luoi tu doi sang gia san, doi nguon
  qua lai thi gia cac mon da chon doi theo dung nguon. Man hinh ghi
  ro "Dang ban theo gia san GrabFood". Combo KHONG doi gia theo
  nguon san (han che da biet).
- Thanh toan don san: NHAP MA DON TREN SAN la bat buoc (VD GF-300).
  Chua nhap thi nut Xac nhan bi khoa. Chi thanh toan Chuyen khoan,
  khong thu tien mat, khong ghi no, khong tach thanh toan, khong
  hien ma VietQR. Man thanh toan hien san chiet khau, thue, tien ve
  du kien.
- Ty le san (Cai dat -> Don san, settings/platform_rates), rieng
  tung san: chiet khau (%), GTGT (%), TNCN (%). GrabFood mac dinh:
  19,634% / 3% / 1,5%. ShopeeFood mac dinh 0% (nhap sau khi co don
  Shopee dau, khong dung ty le Grab cho Shopee).
- So lieu that da kiem chung tu 2 don GrabFood ngay 07/11/2026:
  GF-300 tong 76.000d, ve thuc 57.658d (phi 14.922d, thue 3.420d).
  GF-123 tong 96.000d, ve thuc 72.831d. Tong 172.000d / ve 130.489d.
  Chiet khau thuc 19,63% (nhan 18,18%, thap hon 20% phang), thue
  4,5% (GTGT 3% + TNCN 1,5%, Grab tru luon), tien ve thuc khoang
  75,9% tong don. Dieu khoan GrabFood: khong thu tien mat tu tai
  xe, chuyen khoan sau 24-48 tieng, khong phi duy tri, phi mo app
  490.000d khong hoan lai (da thanh toan).
- Tien ve: luc bam Xac nhan, tien CHUA vao quy. Don o trang thai
  "Cho tien". Khi tien thuc ve tai khoan, mo don o trang Don hang,
  bam "Da ve tien" (chi chu quan), nhap tien thuc ve theo sao ke.
  Quy Chuyen khoan ghi: thu GOP = tong don, chi phi san, chi thue
  san. So du quy tang dung bang tien thuc ve (tong don - phi - thue).
- Luu y: don san KHONG luu tam duoc (hoa don tam khong luu nguon
  don / ma san, mo lai se thanh don tai quan sai gia). Ban xong don
  san thi nguon don tu ve lai "Tai quan". Khuyen mai gio vang (neu
  dang bat) van tu ap vao don san nhu don thuong - kiem tra lai
  dong giam gia truoc khi bam Xac nhan. Don san da ve tien ma nhap
  sai thi phai xoa roi nhap lai. Test logic 26/26 dung toi tung
  dong (GF-300, GF-123). UI don san CHUA kiem chung bang anh chup.
- CHUA CO don san nao trong du lieu that cua POS (GF-300/GF-123 chi
  la so test tinh toan). So doi chieu don san cac ngay nam o thu muc
  appfood/ (file So-Doi-Chieu-Don-San-*.xlsx), khong nam trong goi nay.

9. CAC QUYET DINH NGHIEP VU DA CHOT (25/10/2026, van hieu luc)
--------------------------------------------------------------
1. Phi ship la CHI PHI, khong tinh la loi nhuan. Doanh thu loai ship
   han, ship chi thu ho / tra ho.
2. Phieu nhap tra thieu thi BAT BUOC chon nha cung cap.
3. Phieu xuat ban thu thieu thi THEM ban ghi phai thu va tinh cong no.
4. Xoa/huy don ghi no da thu mot phan thi HOAN LAI tien no tuong ung
   bang phieu chi.
- Quan ban ca ngay, khong thue nhan vien (tu van hanh). Module quan
  ly ca / ket tien chi la tuy chon mo rong, khong bat buoc.

10. CAI DAT VA DEPLOY
---------------------
- Cach deploy 100% bang dien thoai (Hoang tu lam, AI khong deploy):
  1. Tai file zip ban moi (VD app-v6.28.zip) ve dien thoai.
  2. Mo repo github.com/thanghoangbeesy/beesy-pos tren trinh duyet:
     Add file -> Upload files -> chon file zip -> Commit.
     File zip dat trong thu muc .github/workflows/ (cung deploy.yml).
  3. Vao tab Actions -> "Deploy to Firebase" -> Run workflow (hoac
     push bat ky cung tu chay).
  4. Cho chay xanh. Mo trang live kiem tra ten ban tren man hinh
     dang nhap (VD "Ban v6.28"). Ten ban khong doi = deploy chua co
     tac dung, phai tim nguyen nhan, khong do cho cache dien thoai
     khi chua kiem tra live that.
- Workflow (.github/workflows/deploy.yml) lam gi:
  tim file *.zip MOI NHAT theo gio sua file trong TOAN repo, giai
  nen de len source cu, npm ci, ghi frontend/.env tu secrets, build,
  deploy hosting + firestore rules + indexes len project trong
  secret FIREBASE_PROJECT_ID.
- QUY TAC QUAN TRONG: trong repo CHI GIU DUNG 1 FILE ZIP. File zip
  cu phai xoa khoi repo truoc khi upload file moi, neu khong workflow
  co the giai nen nham file cu (vi no chon theo gio sua file).
- Lan dau cai dat: mo /setup tren trang live, tao chu quan, nap menu
  mau. Logo POS Mau 2 da giao, Hoang chua xac nhan chot cuoi.
- Firestore rules KHONG tu deploy theo zip: neu co doi rules, Hoang
  phai dan vao Firebase Console va Publish thu cong. v6.25 - v6.28
  khong doi rules nen khong can buoc nay.

11. VAN DE CON TON TAI / CHUA KIEM CHUNG
----------------------------------------
- Live van la v6.24 (kiem chung 08/11/2026). v6.25 - v6.28 chua co
  xac nhan deploy. AI tiep nhan uu tien xac minh lai live truoc.
- Vu v6 demo 4 (05/11/2026): Actions #313 luc 13:42 chay xanh,
  repo chi con 1 zip demo 4, nhung live van v6.24. Nguyen nhan
  chua ro. Khong duoc ket luan la do cache khi chua kiem tra live.
- UI don san (v6.26/v6.27) va UI sap xep (v6.28) chua kiem chung bang
  anh chup tren app that.
- Han che v6.28: phieu thu/chi nhap tay dung 2 day so rieng (PT va
  PC); neu chon tay cung 1 phut cho ca thu va chi thi thu tu giua
  chung chi on dinh chu khong dam bao dung thu tu tao tuyet doi.
- Han che da biet cua don san: combo khong doi gia theo nguon san;
  khuyen mai gio vang van tu ap vao don san; don san da ve tien
  nhap sai phai xoa roi nhap lai; don san khong luu tam duoc.
- Cac muc chua kiem chung tren app that sau deploy (tu v6.16):
  So quy Momo dat so du dau ky + ngay tinh; Chot ket chi o So quy;
  2 nut an phuong thuc; gia tay / Sua mon / don tren 99 mon; sidebar
  PC co 'Bao cao'; cong tac chi phi o Cai dat; tim kiem Ton kho /
  Danh muc; IngredientPickSheet (v6.19); stepper gio + sua don doi
  topping (v6.20); Tong quan PC moi (v6.21); 7 trang PC (v6.22);
  chip Tuy chon + listbox Ky + luoi mon (v6.23); the Doanh thu sang
  So quy muc Thu + 1 nut Chot ket (v6.24). Ngoai ra: in phieu
  nhap/xuat that, tab 'Quan no NCC', Worker AI bang key that.
- Sao luu Google Drive: dang cho OAuth Client ID cua Hoang.

12. QUY TAC LAM VIEC BAT BUOC (Hoang dat ra, AI tiep nhan tuan theo)
--------------------------------------------------------------------
- Moi code / ban build phai TEST KY truoc khi gui: typecheck sach,
  build duoc, validate JSON, chup man hinh kiem tra giao dien.
  Khong giao khi chua kiem tra.
- KHONG DOAN MO. Khong kiem chung duoc thi noi ro "chua kiem chung
  duoc". Doan qua 2 lan khong ra thi dung lai, thu thap them bang
  chung (hoi Hoang, test thuc te) thay vi tiep tuc doan. Sai thi nhan
  ngay, khong bien ho.
- Chi sua dung pham vi duoc duyet. Lam truoc, bao ket qua sau, ngan gon.
- KHONG tu deploy Firebase, KHONG push GitHub, KHONG Publish rules.
  Hoang thao tac bang dien thoai. AI chi chuan bi file.
- Thiet ke lai giao dien: DEMO TRUOC, Hoang duyet ro roi moi sua code.
- Mobile va PC lam RIENG: moi man co 2 bo cuc rieng. Cam keo gian
  bo cuc mobile len PC.
- Tat ca giao dien dung LINEAL ICON (net manh), khong dung emoji
  lam icon.
- Danh sach phai gon, hien duoc nhieu thong tin (dong thap). Text va
  nut khong duoc vuot khung panel. Kiem chung o 1280px va 1024px (PC),
  390px (mobile).
- Moi file van ban giao Hoang (.md, .txt trong zip): CHI dung ky tu
  ASCII va chu tieng Viet co dau. Khong emoji, khong mui ten, khong
  gach ngang dai. Quet ky tu truoc khi giao, phai ve 0 ky tu la.
  File .md/.txt co BOM UTF-8. File Hoang doc tren may Windows cu:
  luu them ban UTF-16 LE + BOM va ban .rtf.
- Mot dong ban duy nhat cho moi san pham: khong chay song song 2 bien
  the, khong dung theme switcher gay nham. So ban KHONG dung lai,
  ke ca khi chi dong goi lai. Ten file build ghi ro so ban.
- Hoang lam ca ngay o quan, khong the lam viec lien tuc nhu AI.
  Khong xep lich hay ky vong buoi lam viec muon, keo dai lien tuc.
- Khi Hoang chat tren dien thoai tach yeu cau thanh nhieu tin ngan:
  chi xu ly khi co tin rieng chi co dung 1 chu "Xong!". Tin tu web
  la tin hoan chinh, xu ly ngay.
- Phan hoi giao dien cua Hoang -> AI phai TU MO app len kiem tra
  truc tiep, khong suy luan tu code. Anh chup cua Hoang luon chot
  duoc nguyen nhan.
- Hoang cho phep AI tu upload ban build moi ma khong can doi anh
  xac nhan truoc (chi thi lau dai). Nhung KHONG tu deploy.

13. KIEM CHUNG TRUOC KHI GIAO BAN MOI (checklist)
-------------------------------------------------
1. npx tsc -b --force phai sach (exit 0).
2. Validate JSON: firebase.json va firestore.indexes.json parse duoc.
3. Grep CSS nguy hiem: khong co display: none toan cuc tren
   .topbar, .sidebar, .mobile-nav, .main, .page (chi cho phep trong
   ngu canh ro rang, VD an FAB tren PC).
4. Build bang .env dummy du 6 bien VITE_FIREBASE_*, roi XOA .env
   ngay. Trong zip chi co .env.example, KHONG co .env that.
5. Voi thay doi UI: dung dist bang server local + chup man hinh
   kiem tra bang trinh duyet (mobile 390px va PC 1280px + 1024px)
   truoc khi dong goi zip.
6. Khong bao gio sua file config (firebase.json, rules, indexes)
   ma khong validate lai ngay.
7. Quet ky tu file van ban (ASCII + tieng Viet co dau), BOM day du.
8. Dem so file trong zip, ghi sha256, ghi ten ban trong
   vite.config.ts va PHIENBAN.txt (kha nhau la sai).
9. Kiem tra production khong bi sua (source production chi thay doi
   khi Hoang duyet ban production moi).

14. DANH MUC FILE TRONG GOI NAY
-------------------------------
- BAN-GIAO-v6.28.md: tai lieu nay (UTF-8 + BOM).
- BAN-GIAO-v6.28.rtf: cung noi dung, de doc tren may Windows cu.
- ma-nguon-v6.28/: toan bo source ban v6.28 (115 file, 2.388.033 byte
  khi dong goi, sha256 46642e687bf0ede8229ab2c4d451a6f8fffda573cccd026e9ccb564f433e8795),
  giai nen tu app-v6.28.zip, khong sua doi gi. Co PHIENBAN.txt, firebase.json,
  firestore.rules, firestore.indexes.json, .github/workflows/
  deploy.yml, frontend/ (khong co node_modules, dist, .env).
  Cai dependencies bang: cd frontend && npm ci
- tai-lieu-kem/Bang-Gia-GrabFood-ShopeeFood.csv: bang gia san 37 mon
  (gia tai quan +25%, lam tron len 1.000d, chua kem topping).
  Luu y: gia tren app GrabMerchant do Hoang tu dat moi la chuan,
  bang nay chi la tham khao.

15. CAC DU AN LIEN QUAN (chi de biet pham vi, khong thuoc goi nay)
------------------------------------------------------------------
- Beesy Store: web ban 3 app (POS, Tro, Class), live
  https://beesystore-bc82f.web.app, source tai beesy-store/.
- Beesy Tro: quan ly nha tro (Google Sheet + Apps Script), v2 gia
  469.000d mua dut 1 lan, khong DRM. Moi nhat v2.8.
- Beesy Class (ten cu Be Vui Hoc / LittleBees): web lop tien tieu
  hoc, live https://be-vui-hoc-558be.web.app.
- Beesy Nhan Su v1 Final va Beesy Cong Viec v1.0: tang mien phi dang
  1 file HTML. Beesy Control Panel v1.0: app noi bo, KHONG BAO GIO
  dua len Store.
- Anh lop 1A6 (con Hoang): Flickr Clone 1.0, chua deploy that.
- GrabFood: Hoang ban tren GrabFood/ShopeeFood tu 07/11/2026; ho
  tro ban hang o side chat rieng ten Appfood.
- Beesy Edu: du an moi (clone G-EDUCATION v3.0), dang o muc dac ta
  yeu cau v1, chua co file build.

---------------------------------------------------------------
HET TAI LIEU BAN GIAO. AI tiep nhan doc xong hay tu build lai
source v6.28, kiem chung lai tung muc, roi moi lam viec tiep.
