// Lưu bill thành ảnh PNG và gửi bill qua Zalo.
// html2canvas được import động — chỉ tải về khi bấm nút, không làm nặng
// bundle chính của app.
import { formatVND } from './format';
import type { Order } from './types';
import { isSplitPayment, orderPaymentSplits } from './types';

/** Cho moi anh trong vung bill tai xong (ca QR data URL) truoc khi chup. */
async function waitImagesReady(el: HTMLElement): Promise<void> {
  const imgs = Array.from(el.querySelectorAll('img'));
  await Promise.all(
    imgs.map(async (img) => {
      try {
        if (!img.complete) {
          await new Promise<void>((resolve) => {
            img.onload = () => resolve();
            img.onerror = () => resolve();
            setTimeout(resolve, 3000);
          });
        }
        if (typeof img.decode === 'function') await img.decode().catch(() => undefined);
      } catch {
        /* anh loi thi bo qua, chup phan con lai */
      }
    }),
  );
}

/**
 * Chụp vùng bill đang hiển thị (#bill-capture) thành ảnh PNG.
 * Thu lan luot scale 2 -> 1.5 -> 1: dien thoai yeu het bo nho canvas o
 * scale cao la nguyen nhan pho bien khien html2canvas that bai ma ban
 * desktop khong gap. Loi cuoi cung duoc nem ra nguyen van de man hinh
 * bao dung thong diep that (khong nuot loi nhu truoc v5.9).
 */
export async function captureBillImage(): Promise<Blob> {
  const el = document.getElementById('bill-capture');
  if (!el) throw new Error('Không tìm thấy hóa đơn để chụp.');
  const { default: html2canvas } = await import('html2canvas');
  await waitImagesReady(el);
  let lastError: unknown = null;
  for (const scale of [2, 1.5, 1]) {
    try {
      const canvas = await html2canvas(el, {
        backgroundColor: '#ffffff',
        scale,
        useCORS: true,
        logging: false,
      });
      const blob = await new Promise<Blob | null>((resolve) => {
        canvas.toBlob((b) => resolve(b), 'image/png');
      });
      if (blob) return blob;
      lastError = new Error('Trình duyệt không tạo được ảnh (có thể thiếu bộ nhớ).');
    } catch (e) {
      lastError = e;
    }
  }
  throw lastError instanceof Error ? lastError : new Error('Không tạo được ảnh hóa đơn.');
}

export function downloadImage(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

/** Lưu ảnh bill xuống máy (tên file bill-<mã đơn>.png). */
export async function saveBillImage(orderCode: string): Promise<void> {
  const blob = await captureBillImage();
  downloadImage(blob, `bill-${orderCode}.png`);
}

export type ShareBillResult = 'shared' | 'fallback';

/**
 * Gửi bill qua Zalo bằng hộp chia sẻ của hệ điều hành: chọn Zalo, chọn người
 * nhận là gửi kèm ảnh bill. Máy/trình duyệt không hỗ trợ chia sẻ file thì tải
 * ảnh xuống máy + chép nội dung bill dạng chữ để dán vào Zalo (trả 'fallback').
 */
export async function shareBillImage(orderCode: string, billText: string): Promise<ShareBillResult> {
  const blob = await captureBillImage();
  const file = new File([blob], `bill-${orderCode}.png`, { type: 'image/png' });
  const nav = navigator as Navigator & { canShare?: (data: ShareData) => boolean };
  if (nav.canShare && nav.canShare({ files: [file] })) {
    await nav.share({ files: [file], title: `Hóa đơn ${orderCode}`, text: billText });
    return 'shared';
  }
  downloadImage(blob, `bill-${orderCode}.png`);
  try {
    await navigator.clipboard.writeText(billText);
  } catch {
    /* clipboard không khả dụng thì bỏ qua */
  }
  return 'fallback';
}

/** Nội dung bill dạng chữ — đính kèm khi chia sẻ hoặc dán vào Zalo. */
export function buildBillText(order: Order, shopName: string): string {
  const lines: string[] = [];
  lines.push(shopName);
  lines.push(`Hóa đơn ${order.code}`);
  lines.push('------------------------------');
  for (const it of order.items) {
    lines.push(`${it.qty} x ${it.product_name}: ${formatVND(it.line_total)}`);
    if (it.discount) lines.push(`   Giảm: -${formatVND(it.discount)}`);
    for (const m of it.modifiers || []) {
      lines.push(`   + ${m.option}${m.price_delta ? ` (+${formatVND(m.price_delta)})` : ''}`);
    }
    if (it.note) lines.push(`   Ghi chú: ${it.note}`);
  }
  lines.push('------------------------------');
  if (order.discount > 0) lines.push(`Giảm giá: -${formatVND(order.discount)}`);
  lines.push(`Tổng cộng: ${formatVND(order.total)}`);
  if (isSplitPayment(order)) {
    for (const sp of orderPaymentSplits(order)) {
      lines.push(`${sp.method_name}: ${formatVND(sp.amount)}`);
    }
  } else {
    lines.push(`Thanh toán: ${order.payment_method_name ?? order.payment_method}`);
    if (order.payment_method === 'cash' && order.amount_received != null) {
      lines.push(`Khách đưa: ${formatVND(order.amount_received)} - Thối lại: ${formatVND(order.change_amount ?? 0)}`);
    }
  }
  if (order.note) lines.push(`Ghi chú: ${order.note}`);
  lines.push('Cảm ơn quý khách!');
  return lines.join('\n');
}

/** Chuẩn hóa SĐT VN sang dạng link Zalo (84...). */
export function zaloPhone(phone: string): string {
  let p = (phone || '').replace(/\D/g, '');
  if (p.startsWith('0')) p = '84' + p.slice(1);
  return p;
}
