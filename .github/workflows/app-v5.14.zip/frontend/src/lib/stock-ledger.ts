// Tong hop So kho (ton dau / nhap / xuat / ton cuoi) - ham thuan, tach rieng
// de kiem chung bang fixture (khong phu thuoc Firestore hay React).
//
// CO SO GIA TRI (v5.13): gia tri = so luong x gia von binh quan HIEN TAI cua
// nguyen lieu (cost_per_unit trong Ingredient). Ca 4 con so (dau ky, nhap,
// xuat, cuoi ky) dung CHUNG mot co so gia nay nen bat bien
//   closingValue = openingValue + importValue - exportValue
// luon dung dung. closingValue duoc SUY RA tu 3 con so kia (khong lam tron
// doc lap) de bat bien khong lech du 1 dong vi lam tron.

export interface LedgerItemInput {
  ingredient_id: string;
  ingredient_name: string;
  unit: string;
  /** Ton hien tai tai kho dang xem (= ton cuoi ky). */
  current_stock: number;
  /** Gia von binh quan hien tai / don vi (d). */
  cost_per_unit: number;
}

export interface LedgerLogInput {
  ingredient_id: string;
  ingredient_name: string;
  /** + nhap, - xuat. */
  change: number;
  balance_after: number;
}

export interface LedgerSummary {
  ingredient_id: string;
  ingredient_name: string;
  unit: string;
  cost_per_unit: number;
  opening: number;
  importQty: number;
  exportQty: number;
  closing: number;
  openingValue: number;
  importValue: number;
  exportValue: number;
  closingValue: number;
}

const roundQty = (v: number) => Math.round(v * 100) / 100;
const toMoney = (qty: number, cost: number) => Math.round(qty * cost);

/**
 * Gom log trong ky theo tung nguyen lieu (cung thuat toan voi LedgerTab cu):
 * ton cuoi ky = ton hien tai; ton dau ky = ton cuoi - nhap + xuat.
 * Chi tra ve nguyen lieu co bien dong trong ky.
 */
export function summarizeLedger(items: LedgerItemInput[], logsInRange: LedgerLogInput[]): LedgerSummary[] {
  const costById = new Map(items.map((i) => [i.ingredient_id, i.cost_per_unit]));
  const map = new Map<string, LedgerSummary>();
  for (const it of items) {
    map.set(it.ingredient_id, {
      ingredient_id: it.ingredient_id,
      ingredient_name: it.ingredient_name,
      unit: it.unit,
      cost_per_unit: it.cost_per_unit,
      opening: it.current_stock,
      importQty: 0,
      exportQty: 0,
      closing: it.current_stock,
      openingValue: 0,
      importValue: 0,
      exportValue: 0,
      closingValue: 0,
    });
  }
  for (const l of logsInRange) {
    let ps = map.get(l.ingredient_id);
    if (!ps) {
      ps = {
        ingredient_id: l.ingredient_id,
        ingredient_name: l.ingredient_name,
        unit: '',
        cost_per_unit: costById.get(l.ingredient_id) ?? 0,
        opening: l.balance_after,
        importQty: 0,
        exportQty: 0,
        closing: l.balance_after,
        openingValue: 0,
        importValue: 0,
        exportValue: 0,
        closingValue: 0,
      };
      map.set(l.ingredient_id, ps);
    }
    if (l.change > 0) ps.importQty += l.change;
    else ps.exportQty += Math.abs(l.change);
  }
  for (const ps of map.values()) {
    ps.opening = roundQty(ps.closing - ps.importQty + ps.exportQty);
    // Gia tri theo cung 1 co so gia von hien tai; cuoi ky suy ra de giu bat bien.
    ps.openingValue = toMoney(ps.opening, ps.cost_per_unit);
    ps.importValue = toMoney(ps.importQty, ps.cost_per_unit);
    ps.exportValue = toMoney(ps.exportQty, ps.cost_per_unit);
    ps.closingValue = ps.openingValue + ps.importValue - ps.exportValue;
  }
  return [...map.values()]
    .filter((ps) => ps.importQty > 0 || ps.exportQty > 0)
    .sort((a, b) => a.ingredient_name.localeCompare(b.ingredient_name, 'vi'));
}

/** Tong gia tri 4 cot tren tat ca nguyen lieu (tien cong duoc du khac don vi). */
export function ledgerValueTotals(summaries: LedgerSummary[]): {
  openingValue: number;
  importValue: number;
  exportValue: number;
  closingValue: number;
} {
  return summaries.reduce(
    (t, ps) => ({
      openingValue: t.openingValue + ps.openingValue,
      importValue: t.importValue + ps.importValue,
      exportValue: t.exportValue + ps.exportValue,
      closingValue: t.closingValue + ps.closingValue,
    }),
    { openingValue: 0, importValue: 0, exportValue: 0, closingValue: 0 },
  );
}

/** Gia tri ton kho hien tai = tong (ton x gia von hien tai) cua nguyen lieu dang dung. */
export function inventoryValueOf(items: { active: boolean; stock: number; cost_per_unit: number }[]): number {
  return items.reduce((s, i) => (i.active ? s + Math.round(i.stock * i.cost_per_unit) : s), 0);
}
