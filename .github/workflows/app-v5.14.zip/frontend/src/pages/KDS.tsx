import { useCallback, useEffect, useRef, useState } from 'react';
import {
  DbError,
  cancelOnlineOrder,
  confirmOnlineOrder,
  getAllowedWarehouses,
  listOrdersByDate,
  subscribePendingOnlineOrders,
  updateOrderStatus,
} from '../lib/db';
import { formatTime, todayVN } from '../lib/format';
import { playNewOrderSound, useKdsRealtime } from '../lib/realtime';
import {
  getNotifyPermission,
  isNotifyEnabled,
  isNotifySupported,
  requestNotifyPermission,
  setNotifyEnabled,
  showOrderNotification,
} from '../lib/notify';
import { useToast } from '../components/Toast';
import { PageHead } from '../components/PageHead';
import type { OnlineOrder, Order, OrderStatus } from '../lib/types';

const COLS: { status: OrderStatus; title: string; cls: string; btnCls: string; next: OrderStatus; nextLabel: string }[] = [
  { status: 'new', title: 'Mới', cls: 'col-new', btnCls: '', next: 'preparing', nextLabel: 'Bắt đầu pha' },
  { status: 'preparing', title: 'Đang pha', cls: 'col-prep', btnCls: '', next: 'ready', nextLabel: 'Xong — chờ lấy' },
  { status: 'ready', title: 'Sẵn sàng lấy', cls: 'col-ready', btnCls: 'btn-outline', next: 'done', nextLabel: 'Hoàn tất' },
];

const SOUND_KEY = 'beesy_kds_sound';

export function KDS() {
  const toast = useToast();
  const [orders, setOrders] = useState<Order[]>([]);
  const [soundOn, setSoundOn] = useState(() => localStorage.getItem(SOUND_KEY) !== 'off');
  const [notifyPerm, setNotifyPerm] = useState<NotificationPermission | 'unsupported'>(() => getNotifyPermission());
  const [notifyOn, setNotifyOn] = useState(() => isNotifyEnabled());
  const [busy, setBusy] = useState<string | null>(null);
  const soundRef = useRef(soundOn);
  soundRef.current = soundOn;

  const [scopeIds, setScopeIds] = useState<string[]>([]);
  const [onlineOrders, setOnlineOrders] = useState<OnlineOrder[]>([]);
  const [onlineBusy, setOnlineBusy] = useState<string | null>(null);
  const fetchOrders = useCallback(async () => {
    try {
      const allowed = await getAllowedWarehouses();
      const ids = allowed.isOwner ? [] : allowed.warehouses.map((w) => w.id);
      setScopeIds(ids);
      const data = await listOrdersByDate(todayVN(), 200, ids);
      setOrders(data.filter((o) => ['new', 'preparing', 'ready'].includes(o.status)));
    } catch {
      /* giữ danh sách cũ khi mất mạng */
    }
  }, []);

  useEffect(() => {
    void fetchOrders();
    const unsub = subscribePendingOnlineOrders(
      (items) => {
        setOnlineOrders((prev) => {
          if (items.length > prev.length) {
            const added = items.slice(0, items.length - prev.length);
            if (soundRef.current) {
              playNewOrderSound();
              setTimeout(playNewOrderSound, 900);
              setTimeout(playNewOrderSound, 1800);
            }
            const first = added[0];
            if (first) {
              showOrderNotification(
                `🔔 Đơn online mới (${items.length} chờ duyệt)`,
                `${first.customer_name} · ${first.customer_phone} — ${first.total.toLocaleString('vi-VN')}đ`,
              );
            }
          }
          return items;
        });
      },
      (e) => {
        // Hien thi ma loi cu the de de chan doan: thieu index hay chua deploy rules
        const code = (e as { code?: string })?.code ?? '';
        const msg = e instanceof DbError ? e.message : String(e);
        if (code === 'failed-precondition') {
          toast.show('⚠️ Đơn online: thiếu index Firestore — vào console tạo index cho online_orders (status + created_at)');
        } else if (code === 'permission-denied') {
          toast.show('⚠️ Đơn online: chưa dán rules mới — dán lại firestore.rules rồi thử lại');
        } else {
          toast.show(`⚠️ Đơn online lỗi (${code || 'unknown'}): ${msg}`);
        }
      },
    );
    return unsub;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fetchOrders]);

  useKdsRealtime(todayVN(), {
    onCreated: (order) => {
      setOrders((prev) => (prev.some((o) => o.id === order.id) ? prev : [order, ...prev]));
      if (soundRef.current) playNewOrderSound();
      toast.show(`🔔 Đơn mới ${order.code}!`);
    },
    onUpdated: (order) => {
      setOrders((prev) => {
        if (['done', 'cancelled'].includes(order.status)) return prev.filter((o) => o.id !== order.id);
        const i = prev.findIndex((o) => o.id === order.id);
        if (i >= 0) {
          const next = [...prev];
          next[i] = order;
          return next;
        }
        return ['new', 'preparing', 'ready'].includes(order.status) ? [order, ...prev] : prev;
      });
    },
  }), scopeIds;

  const advance = async (order: Order, next: OrderStatus) => {
    setBusy(order.id);
    try {
      const updated = await updateOrderStatus(order.id, next);
      setOrders((prev) =>
        next === 'done' ? prev.filter((o) => o.id !== order.id) : prev.map((o) => (o.id === order.id ? updated : o)),
      );
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Đổi trạng thái thất bại');
    } finally {
      setBusy(null);
    }
  };

  const approveOnline = async (oo: OnlineOrder) => {
    setOnlineBusy(oo.id);
    try {
      const order = await confirmOnlineOrder(oo.id);
      toast.show(`Đã duyệt → đơn ${order.code}`);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Duyệt đơn thất bại');
    } finally {
      setOnlineBusy(null);
    }
  };

  const rejectOnline = async (oo: OnlineOrder) => {
    if (!window.confirm(`Từ chối đơn online của ${oo.customer_name}?`)) return;
    setOnlineBusy(oo.id);
    try {
      await cancelOnlineOrder(oo.id);
      toast.show('Đã từ chối đơn online');
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Thất bại');
    } finally {
      setOnlineBusy(null);
    }
  };

  const byStatus = (s: OrderStatus) =>
    orders
      .filter((o) => o.status === s)
      .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());

  const toggleSound = () => {
    const v = !soundOn;
    setSoundOn(v);
    localStorage.setItem(SOUND_KEY, v ? 'on' : 'off');
    if (v) playNewOrderSound();
  };

  return (
    <div className="page">
      <PageHead
        title="Pha chế"
        back
        right={
          <>
          <button
            className="btn btn-ghost"
            style={{
              width: 44,
              height: 44,
              minHeight: 44,
              padding: 0,
              borderRadius: '50%',
              fontSize: 22,
            }}
            onClick={toggleSound}
            aria-label={soundOn ? 'Tắt âm báo' : 'Bật âm báo'}
            title={soundOn ? 'Tắt âm báo' : 'Bật âm báo'}
          >
            {soundOn ? '🔔' : '🔕'}
          </button>
          {isNotifySupported() && notifyPerm !== 'granted' && (
            <button
              className="btn btn-ghost"
              style={{
                height: 44,
                minHeight: 44,
                padding: '0 12px',
                borderRadius: 22,
                fontSize: 15,
                border: '2px solid var(--amber, #f59e0b)',
                marginLeft: 8,
              }}
              onClick={() => {
                void requestNotifyPermission().then((p) => {
                  setNotifyPerm(p);
                  if (p === 'granted') {
                    setNotifyOn(true);
                    setNotifyEnabled(true);
                    showOrderNotification('🔔 Đã bật thông báo', 'Có đơn online mới sẽ báo ngay trên máy này.');
                  }
                });
              }}
              title="Bật thông báo đơn online trên máy này"
            >
              📢 Bật thông báo
            </button>
          )}
          {isNotifySupported() && notifyPerm === 'granted' && (
            <button
              className="btn btn-ghost"
              style={{
                width: 44,
                height: 44,
                minHeight: 44,
                padding: 0,
                borderRadius: '50%',
                fontSize: 22,
                marginLeft: 8,
              }}
              onClick={() => {
                const v = !notifyOn;
                setNotifyOn(v);
                setNotifyEnabled(v);
              }}
              title={notifyOn ? 'Tắt thông báo hệ thống' : 'Bật thông báo hệ thống'}
            >
              {notifyOn ? '📢' : '📪'}
            </button>
          )}
          </>
        }
      />
      {onlineOrders.length > 0 && (
        <div className="card" style={{ marginBottom: 12, border: '2px solid var(--amber, #f59e0b)' }}>
          <h3 style={{ margin: '0 0 8px' }}>
            🌐 Đơn online chờ duyệt <span className="count">{onlineOrders.length}</span>
          </h3>
          {onlineOrders.map((oo) => (
            <div key={oo.id} className="sb-section" style={{ marginBottom: 8 }}>
              <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center' }}>
                <div style={{ fontWeight: 700 }}>
                  {oo.customer_name} · {oo.customer_phone}
                </div>
                <div className="money" style={{ color: 'var(--green)' }}>
                  {oo.total.toLocaleString('vi-VN')}đ
                </div>
              </div>
              <div className="small muted" style={{ margin: '4px 0' }}>
                {oo.items.map((it) => `${it.qty}× ${it.product_name}${it.modifiers.length ? ` (${it.modifiers.map((m) => m.option).join(', ')})` : ''}`).join(' · ')}
              </div>
              <div className="small muted">
                {oo.payment_kind === 'cash' ? '💵 Tiền mặt khi nhận' : '🏦 Chuyển khoản'} ·{' '}
                {new Date(oo.created_at).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}
                {oo.note ? ` · 📝 ${oo.note}` : ''}
              </div>
              <div className="row" style={{ gap: 8, marginTop: 8 }}>
                <button
                  className="btn btn-block"
                  disabled={onlineBusy === oo.id}
                  onClick={() => void approveOnline(oo)}
                >
                  {onlineBusy === oo.id ? 'Đang duyệt…' : '✅ Duyệt → tạo đơn'}
                </button>
                <button
                  className="btn btn-outline"
                  disabled={onlineBusy === oo.id}
                  onClick={() => void rejectOnline(oo)}
                >
                  Từ chối
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
      <div className="kds-cols">
        {COLS.map((c) => {
          const list = byStatus(c.status);
          return (
            <div className={`kds-col ${c.cls}`} key={c.status}>
              <h3>
                {c.title} <span className="count">{list.length}</span>
              </h3>
              {list.map((o) => (
                <div
                  className={`order-card${c.status === 'preparing' ? ' preparing' : c.status === 'ready' ? ' ready' : ''}`}
                  key={o.id}
                >
                  <div className="row">
                    <span className="ocode">{o.code}</span>
                    <span className="grow" />
                    <span className="otime">{formatTime(o.created_at)}</span>
                  </div>
                  <div className="oitems">
                    {o.items.map((it) => (
                      <div key={it.id} style={{ marginBottom: 4 }}>
                        <span className="qty">{it.qty}x</span> {it.product_name}
                        {(it.modifiers || []).length > 0 && (
                          <div className="omods">↳ {(it.modifiers || []).map((m) => m.option).join(' · ')}</div>
                        )}
                      </div>
                    ))}
                  </div>
                  {o.note && <div className="onote">{o.note}</div>}
                  <button
                    className={`btn btn-block ${c.btnCls}`}
                    style={{ marginTop: 10 }}
                    disabled={busy === o.id}
                    onClick={() => advance(o, c.next)}
                  >
                    {busy === o.id ? 'Đang xử lý…' : c.nextLabel}
                  </button>
                </div>
              ))}
              {list.length === 0 && <div className="sb-empty">Không có đơn nào</div>}
            </div>
          );
        })}
      </div>
    </div>
  );
}
