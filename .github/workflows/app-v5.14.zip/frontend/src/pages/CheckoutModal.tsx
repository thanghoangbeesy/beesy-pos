import { useEffect, useState } from 'react';
import { DbError, TIER_LABEL, calcDiscount, calcVoucherDiscount, createOrder, findActivePromotion, getLoyaltyConfig, getPromotions, getSettings, getVoucherByCode, listPaymentMethods, tierDiscount, toLocalDateTimeInput, validateVoucher, type LoyaltyConfig } from '../lib/db';
import type { CreateOrderInput } from '../lib/db';
import { formatVND, todayVN, uuid } from '../lib/format';
import { VietQRImg } from '../lib/vietqr';
import { queueOrder } from '../lib/offline';
import { useToast } from '../components/Toast';
import { CustomerPickSheet } from '../components/CustomerPickSheet';
import { LineDiscountSheet } from '../components/LineDiscountSheet';
import { BillPrint } from './BillPrint';
import { buildBillText, saveBillImage, shareBillImage, zaloPhone } from '../lib/bill-image';
import { BluetoothPrintButton } from '../components/BluetoothPrintButton';
import { loadBrand } from '../lib/brand';
import { TIcon } from '../components/TIcon';
import { discountAmountFor } from '../lib/types';
import type { CartLine, Customer, Order, PaymentMethodDef, PaymentSplit, Promotion, Voucher } from '../lib/types';

const QUICK_CASH = [20000, 50000, 100000, 200000, 500000];

export function CheckoutModal({
  lines,
  customer,
  total,
  warehouseId,
  onClose,
  onUpdateQty,
  onUpdateLineDiscount,
  onCustomerChange,
  onSaveDraft,
  onDone,
}: {
  lines: CartLine[];
  customer: Customer | null;
  total: number;
  warehouseId: string;
  onClose: () => void;
  onUpdateQty: (key: string, qty: number) => void;
  onUpdateLineDiscount: (key: string, type: 'percent' | 'amount' | null, value: number | null) => void;
  onCustomerChange: (c: Customer | null) => void;
  onSaveDraft?: () => void;
  onDone: (order: Order | null, queued: boolean) => void;
}) {
  const toast = useToast();
  const [methods, setMethods] = useState<PaymentMethodDef[]>([]);
  const [methodId, setMethodId] = useState('');
  const [received, setReceived] = useState('');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const [fallbackBank, setFallbackBank] = useState({ bin: '', account: '', name: '' });
  const [shopName, setShopName] = useState('Beesy Coffee & Tea');
  const [shopPhone, setShopPhone] = useState('');
  const [shopAddress, setShopAddress] = useState('');
  const [shopLogo, setShopLogo] = useState('');
  const [paidOrder, setPaidOrder] = useState<Order | null>(null);
  const [paidMethod, setPaidMethod] = useState<PaymentMethodDef | null>(null);
  const [queuedUuid, setQueuedUuid] = useState<string | null>(null);
  // 2 bước: xác nhận đơn → thanh toán
  const [step, setStep] = useState<'confirm' | 'pay'>('confirm');
  const [pickingCustomer, setPickingCustomer] = useState(false);
  // Dong mon dang sua giam gia rieng ngay trong man thanh toan (v5.12)
  const [discountKey, setDiscountKey] = useState<string | null>(null);
  // Tiền khách trả mặc định = tổng hóa đơn để khỏi nhập tay; chạm vào sửa là giữ nguyên giá trị đã nhập
  const [receivedTouched, setReceivedTouched] = useState(false);
  // Giảm giá: % hoặc tiền; promo giờ vàng tự áp dụng, nhân viên có thể sửa tay
  const [discountType, setDiscountType] = useState<'percent' | 'amount' | null>(null);
  const [discountValue, setDiscountValue] = useState('');
  const [orderTime, setOrderTime] = useState(() => toLocalDateTimeInput());
  const [promo, setPromo] = useState<Promotion | null>(null);
  const [voucherInput, setVoucherInput] = useState('');
  const [voucher, setVoucher] = useState<Voucher | null>(null);
  const [voucherBusy, setVoucherBusy] = useState(false);
  // Thanh toán hỗn hợp: nhiều phương thức trên 1 đơn
  const [splitMode, setSplitMode] = useState(false);
  const [splitAmounts, setSplitAmounts] = useState<Record<string, string>>({});
  const [paidSplits, setPaidSplits] = useState<PaymentSplit[] | null>(null);
  const [billBusy, setBillBusy] = useState(false);
  const [loyaltyCfg, setLoyaltyCfg] = useState<LoyaltyConfig | null>(null);
  const [tierApplied, setTierApplied] = useState(false);
  const goPay = () => {
    if (!receivedTouched) setReceived(String(finalTotal));
    setStep('pay');
  };

  useEffect(() => {
    listPaymentMethods(true)
      .then((ms) => {
        setMethods(ms);
        const def = ms.find((m) => m.id === 'cash') ?? ms[0] ?? null;
        if (def) setMethodId(def.id);
      })
      .catch(() => toast.show('Không tải được phương thức thanh toán'));
    getPromotions()
      .then((ps) => {
        const active = findActivePromotion(ps);
        if (active) {
          setPromo(active);
          setDiscountType(active.type);
          setDiscountValue(String(active.value));
        }
      })
      .catch(() => {});
    getLoyaltyConfig().then(setLoyaltyCfg).catch(() => {});
    loadBrand().then((b) => setShopLogo(b.logo || '')).catch(() => {});
    getSettings()
      .then((s) => {
        setShopName(s.shop_name || 'Beesy Coffee & Tea');
        setShopPhone(s.shop_phone || '');
        setShopAddress(s.shop_address || '');
        // Dự phòng cho dữ liệu cũ: cấu hình ngân hàng trong settings
        setFallbackBank({
          bin: s.bank_bin || '',
          account: s.bank_account || '',
          name: s.bank_account_name || '',
        });
      })
      .catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Tự áp ưu đãi hạng thành viên khi chọn khách (nếu chưa có giảm giá khác)
  useEffect(() => {
    if (!customer || !loyaltyCfg || voucher || promo) {
      if (!customer) setTierApplied(false);
      return;
    }
    const d = tierDiscount(customer.tier ?? 'member', loyaltyCfg);
    if (d > 0 && !discountType) {
      setDiscountType('percent');
      setDiscountValue(String(d));
      setTierApplied(true);
    } else if (d <= 0) {
      setTierApplied(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [customer?.id, loyaltyCfg]);

  const method = methods.find((m) => m.id === methodId) ?? null;
  const kind = method?.kind ?? 'cash';
  const bankBin = method?.bank_bin || fallbackBank.bin;
  const bankAccount = method?.bank_account || fallbackBank.account;
  const bankName = method?.bank_account_name || fallbackBank.name || shopName;
  const debtMethod = methods.find((m) => m.kind === 'debt');
  const cashMethod = methods.find((m) => m.kind === 'cash') ?? methods[0];

  const receivedNum = parseInt(received.replace(/\D/g, ''), 10) || 0;
  const discountNum = Math.max(0, parseInt(discountValue.replace(/\D/g, ''), 10) || 0);
  const voucherDiscount = voucher ? calcVoucherDiscount(total, voucher) : 0;
  const discountAmount = voucher ? voucherDiscount : calcDiscount(total, discountType, discountNum);
  const finalTotal = total - discountAmount;
  const tierDisc = customer && loyaltyCfg ? tierDiscount(customer.tier ?? 'member', loyaltyCfg) : 0;
  const discountLabel = voucher
    ? `Voucher ${voucher.code}`
    : tierApplied && tierDisc > 0
      ? `Hạng ${TIER_LABEL[customer?.tier ?? 'member']}`
      : promo && discountType === promo.type && discountNum === promo.value
        ? promo.name
        : null;

  const applyVoucher = async () => {
    const code = voucherInput.trim();
    if (!code) return;
    setVoucherBusy(true);
    try {
      const v = await getVoucherByCode(code);
      if (!v) {
        toast.show('Mã voucher không tồn tại');
        return;
      }
      const err = validateVoucher(v, total, orderTime ? orderTime.slice(0, 10) : todayVN());
      if (err) {
        toast.show(err);
        return;
      }
      setVoucher(v);
      toast.show(`Đã áp voucher ${v.code}`);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không kiểm tra được voucher');
    } finally {
      setVoucherBusy(false);
    }
  };
  const removeVoucher = () => {
    setVoucher(null);
    setVoucherInput('');
  };
  const change = receivedNum - finalTotal;

  const unitPrice = (l: CartLine) => l.product.base_price + l.modifiers.reduce((a, m) => a + m.price_delta, 0);
  const totalItems = lines.reduce((s, l) => s + l.qty, 0);

  const buildInput = (m: PaymentMethodDef, clientUuid: string): CreateOrderInput => ({
    clientUuid,
    customerId: customer?.id ?? null,
    items: lines.map((l) => ({
      productId: l.product.id,
      qty: l.qty,
      modifierOptionIds: l.modifiers.map((x) => x.option_id),
      note: l.note || undefined,
      comboId: l.comboId ?? null,
      discountType: l.discountType ?? null,
      discountValue: l.discountValue ?? null,
    })),
    paymentMethod: m.id,
    amountReceived: m.kind === 'cash' ? receivedNum : undefined,
    note: note.trim() || null,
    warehouseId: warehouseId || null,
    discountType: voucher ? null : discountType,
    discountValue: voucher ? null : discountType ? discountNum : null,
    discountLabel,
    voucherCode: voucher ? voucher.code : null,
    businessDate: orderTime ? orderTime.slice(0, 10) : null,
    createdAt: orderTime ? new Date(orderTime).toISOString() : null,
  });

  // ---- Thanh toán hỗn hợp ----
  const splitAllocated = methods.reduce(
    (sum, m) => sum + (parseInt((splitAmounts[m.id] || '').replace(/\D/g, ''), 10) || 0),
    0,
  );
  const splitRemaining = finalTotal - splitAllocated;
  const splitRows = methods
    .map((m) => ({ m, amount: parseInt((splitAmounts[m.id] || '').replace(/\D/g, ''), 10) || 0 }))
    .filter((r) => r.amount > 0);
  const splitDebtTotal = splitRows.filter((r) => r.m.kind === 'debt').reduce((a, r) => a + r.amount, 0);

  const splitEven = () => {
    // Chia đều tổng đơn cho các phương thức
    if (methods.length === 0) return;
    const n = methods.length;
    const each = Math.floor(finalTotal / n);
    const next: Record<string, string> = {};
    methods.forEach((m, i) => {
      next[m.id] = String(i === n - 1 ? finalTotal - each * (n - 1) : each);
    });
    setSplitAmounts(next);
  };
  const splitClear = () => setSplitAmounts({});
  const splitFillRest = (methodId: string) => {
    // Điền phần còn lại vào 1 phương thức
    const cur = parseInt((splitAmounts[methodId] || '').replace(/\D/g, ''), 10) || 0;
    const rest = finalTotal - (splitAllocated - cur);
    if (rest < 0) {
      toast.show('Đã vượt quá tổng đơn');
      return;
    }
    setSplitAmounts((prev) => ({ ...prev, [methodId]: String(rest) }));
  };

  const submitSplit = async () => {
    if (splitRows.length === 0) {
      toast.show('Nhập số tiền cho ít nhất 1 phương thức');
      return;
    }
    if (Math.abs(splitAllocated - finalTotal) > 1) {
      toast.show(
        splitAllocated < finalTotal
          ? `Còn thiếu ${formatVND(finalTotal - splitAllocated)}`
          : `Đã vượt ${formatVND(splitAllocated - finalTotal)} so với tổng đơn`,
      );
      return;
    }
    if (splitDebtTotal > 0 && !customer) {
      toast.show('Phần ghi nợ cần chọn khách hàng cho đơn này');
      return;
    }
    if (!warehouseId) {
      toast.show('Chưa có kho bán — vào Tồn kho để tạo kho trước');
      return;
    }
    setBusy(true);
    const clientUuid = uuid();
    const primary = splitRows[0].m;
    const base = buildInput(primary, clientUuid);
    const input: CreateOrderInput = {
      ...base,
      paymentMethod: primary.id,
      amountReceived: null,
      payments: splitRows.map((r) => ({ methodId: r.m.id, amount: r.amount })),
    };
    try {
      const order = await createOrder(input);
      setPaidMethod(primary);
      setPaidSplits(order.payments && order.payments.length > 0 ? order.payments : null);
      setPaidOrder(order);
    } catch (e) {
      if (e instanceof DbError && e.code === 'unavailable') {
        queueOrder({ clientUuid, createdAt: new Date().toISOString(), payload: input });
        setQueuedUuid(clientUuid);
      } else {
        toast.show(e instanceof DbError ? e.message : 'Tạo đơn thất bại');
      }
    } finally {
      setBusy(false);
    }
  };

  const submit = async (m: PaymentMethodDef) => {
    if (m.kind === 'cash' && receivedNum < finalTotal) {
      toast.show('Tiền khách đưa chưa đủ');
      return;
    }
    if (m.kind === 'debt' && !customer) {
      toast.show('Ghi nợ cần chọn khách hàng cho đơn này');
      return;
    }
    if (!warehouseId) {
      toast.show('Chưa có kho bán — vào Tồn kho để tạo kho trước');
      return;
    }
    setBusy(true);
    const clientUuid = uuid();
    const input = buildInput(m, clientUuid);
    try {
      const order = await createOrder(input);
      setPaidMethod(m);
      setPaidOrder(order);
    } catch (e) {
      if (e instanceof DbError && e.code === 'unavailable') {
        // Offline → lưu outbox, vẫn coi như bán xong
        queueOrder({ clientUuid, createdAt: new Date().toISOString(), payload: input });
        setQueuedUuid(clientUuid);
      } else {
        toast.show(e instanceof DbError ? e.message : 'Tạo đơn thất bại');
      }
    } finally {
      setBusy(false);
    }
  };

  const closeSheet = () => onClose();

  // ---- Lưu bill thành ảnh / gửi bill qua Zalo ----
  const handleSaveBillImage = async () => {
    if (!paidOrder || billBusy) return;
    setBillBusy(true);
    try {
      await saveBillImage(paidOrder.code);
      toast.show('Đã lưu ảnh hóa đơn');
    } catch (e) {
      // Hien nguyen van loi that de chup man hinh gui di la biet nguyen nhan
      console.error('saveBillImage failed', e);
      toast.show(`Không lưu được ảnh: ${e instanceof Error ? e.message : 'lỗi không rõ'}`);
    } finally {
      setBillBusy(false);
    }
  };

  const handleShareBillZalo = async () => {
    if (!paidOrder || billBusy) return;
    setBillBusy(true);
    try {
      const text = buildBillText(paidOrder, shopName);
      const res = await shareBillImage(paidOrder.code, text);
      if (res === 'fallback') {
        // Máy không hỗ trợ chia sẻ file: đã tải ảnh + chép nội dung bill.
        // Có SĐT khách thì mở luôn cuộc trò chuyện Zalo của khách để gửi.
        toast.show('Đã tải ảnh + chép nội dung bill. Mở Zalo để gửi cho khách.');
        if (customer?.phone) {
          window.open(`https://zalo.me/${zaloPhone(customer.phone)}`, '_blank');
        }
      }
    } catch (e) {
      // Người dùng tự đóng hộp chia sẻ thì không báo lỗi
      if (e instanceof DOMException && e.name === 'AbortError') return;
      console.error('shareBillImage failed', e);
      toast.show(`Không gửi được bill: ${e instanceof Error ? e.message : 'lỗi không rõ'}`);
    } finally {
      setBillBusy(false);
    }
  };

  // ---- Màn hình sau thanh toán: thành công + QR (chuyển khoản) + in bill ----
  if (paidOrder || queuedUuid) {
    // Đơn trả bằng 1 phương thức: createOrder không lưu mảng payments và submit()
    // không gán paidSplits → tự dựng 1 phần thanh toán từ phương thức vừa trả.
    // Thiếu bước này thì transferTotal luôn = 0 và mã VietQR không bao giờ hiện
    // (dù đã cấu hình đủ BIN + số tài khoản) — lỗi đã sửa ở v5.1.
    const effectiveSplits: PaymentSplit[] =
      paidSplits && paidSplits.length > 0
        ? paidSplits
        : paidOrder && paidMethod
          ? [{ method_id: paidMethod.id, method_name: paidMethod.name, kind: paidMethod.kind, amount: paidOrder.total }]
          : [];
    const transferSplits = effectiveSplits.filter((sp) => sp.kind === 'transfer');
    const transferMethod = transferSplits.length > 0 ? methods.find((m) => m.id === transferSplits[0].method_id) : null;
    const transferTotal = transferSplits.reduce((a, sp) => a + sp.amount, 0);
    const qrBin = transferMethod?.bank_bin || (paidMethod?.kind === 'transfer' ? bankBin : '');
    const qrAccount = transferMethod?.bank_account || (paidMethod?.kind === 'transfer' ? bankAccount : '');
    const qrName = transferMethod?.bank_account_name || bankName;
    const showQR = paidOrder && transferTotal > 0 && qrBin && qrAccount;
    return (
      <div className="fsheet-backdrop">
        <div className="fsheet" role="dialog" aria-modal="true">
          <div className="fsheet-body">
            <div className="sb-success">
              <div className="sico">✅</div>
              <h2>{paidOrder ? 'Thanh toán thành công!' : 'Đã lưu đơn chờ'}</h2>
              <div className="scode">
                {paidOrder
                  ? `Mã đơn: ${paidOrder.code}`
                  : 'Đang offline — đơn sẽ tự đồng bộ khi có mạng.'}
              </div>
            </div>
            {showQR && paidOrder && (
              <div className="qr-box">
                <VietQRImg
                  bankBin={qrBin}
                  account={qrAccount}
                  accountName={qrName}
                  amount={transferTotal}
                  addInfo={paidOrder.code}
                  alt={`Mã VietQR đơn ${paidOrder.code}`}
                />
                <p style={{ marginTop: 8 }}>
                  <b>{qrName}</b>
                  <br />
                  <span className="muted">
                    STK: {qrAccount} · Số tiền: <span className="money">{formatVND(transferTotal)}</span>
                    <br />
                    Nội dung: <b>{paidOrder.code}</b>
                  </span>
                </p>
                <p className="small" style={{ color: 'var(--orange)' }}>
                  Khách quét mã để chuyển khoản đúng số tiền &amp; nội dung. Nhân viên xác nhận đã nhận tiền rồi bấm “In bill”.
                </p>
              </div>
            )}
            {paidOrder && paidSplits && paidSplits.length > 1 && (
              <div className="card" style={{ marginBottom: 8 }}>
                <div className="small muted" style={{ fontWeight: 600, marginBottom: 6 }}>
                  💳 Thanh toán hỗn hợp
                </div>
                {paidSplits.map((sp) => (
                  <div className="row" key={sp.method_id} style={{ marginBottom: 4 }}>
                    <span>{sp.kind === 'cash' ? '💵' : sp.kind === 'transfer' ? '📱' : '📒'} {sp.method_name}</span>
                    <b className="money">{formatVND(sp.amount)}</b>
                  </div>
                ))}
              </div>
            )}
            {paidOrder && paidMethod?.kind === 'debt' && customer && !paidSplits && (
              <div className="card" style={{ marginBottom: 8 }}>
                📒 Đã ghi nợ <b className="money">{formatVND(paidOrder.total)}</b> cho <b>{customer.name}</b>.
              </div>
            )}
            {paidOrder && paidSplits && paidSplits.some((sp) => sp.kind === 'debt') && customer && (
              <div className="card" style={{ marginBottom: 8 }}>
                📒 Đã ghi nợ <b className="money">{formatVND(paidSplits.filter((sp) => sp.kind === 'debt').reduce((a, sp) => a + sp.amount, 0))}</b> cho <b>{customer.name}</b>.
              </div>
            )}
            {paidOrder ? (
              <BillPrint
                order={paidOrder}
                shopName={shopName}
                shopPhone={shopPhone}
                shopAddress={shopAddress}
                shopLogo={shopLogo}
                qrBin={showQR ? qrBin : null}
                qrName={showQR ? qrName : undefined}
                qrAccount={showQR ? qrAccount : undefined}
                qrAmount={showQR ? transferTotal : undefined}
              />
            ) : (
              <div className="card">
                <p>📶 Đang offline — đơn đã lưu vào hàng chờ và sẽ <b>tự đồng bộ</b> khi có mạng (mã đơn sẽ hiện sau khi đồng bộ).</p>
                <p className="muted small">Tổng: <span className="money">{formatVND(total)}</span> · {lines.length} dòng món</p>
              </div>
            )}
          </div>
          <div className="fsheet-foot">
            {paidOrder && (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 8, marginBottom: 8 }}>
                <button className="btn btn-outline btn-lg" style={{ width: '100%' }} disabled={billBusy} onClick={() => void handleSaveBillImage()}>
                  {billBusy ? 'Đang xử lý…' : '📷 Lưu ảnh bill'}
                </button>
                <button className="btn btn-outline btn-lg" style={{ width: '100%' }} disabled={billBusy} onClick={() => void handleShareBillZalo()}>
                  {billBusy ? 'Đang xử lý…' : '💬 Gửi Zalo'}
                </button>
              </div>
            )}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 8 }}>
              {paidOrder && <BluetoothPrintButton order={paidOrder} shopName={shopName} />}
              <button className="btn btn-lg" style={{ width: '100%' }} onClick={() => onDone(paidOrder, !!queuedUuid)}>
                Tạo đơn mới
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ---- Bước 1: Xác nhận đơn ----
  if (step === 'confirm') {
    return (
      <div
        className="fsheet-backdrop"
        onClick={(e) => {
          if (e.target === e.currentTarget) closeSheet();
        }}
      >
        <div className="fsheet" role="dialog" aria-modal="true">
          <div className="fsheet-head">
            <button className="fsheet-back" onClick={closeSheet} aria-label="Quay lại">‹</button>
            <div className="fsheet-title">Xác nhận</div>
            <span className="fsheet-side" />
          </div>
          <div className="fsheet-body">
            <button className="btn btn-outline btn-block" style={{ marginBottom: 12 }} onClick={closeSheet}>
              + Thêm sản phẩm
            </button>

            <div className="co-card">
              {lines.length === 0 ? (
                <div className="sb-empty">Chưa có món nào trong đơn.</div>
              ) : (
                lines.map((l) => (
                  <div className="co-line" key={l.key}>
                    <button className="co-remove" onClick={() => onUpdateQty(l.key, 0)} aria-label="Xóa món">
                      ×
                    </button>
                    <div className="cbody">
                      <div className="cname">{l.product.name}</div>
                      {l.modifiers.length > 0 && (
                        <div className="csub">{l.modifiers.map((m) => m.option).join(' · ')}</div>
                      )}
                      {l.note && <div className="csub">📝 {l.note}</div>}
                      {(() => {
                        const disc = discountAmountFor(unitPrice(l) * l.qty, l.discountType, l.discountValue);
                        return disc > 0 ? (
                          <div className="csub" style={{ color: 'var(--green)', fontWeight: 600 }}>
                            🏷️ Giảm {l.discountType === 'percent' ? `${l.discountValue}%` : ''} −{formatVND(disc)}
                          </div>
                        ) : null;
                      })()}
                      <div className="qty-ctl">
                        <button className="qty-btn" onClick={() => onUpdateQty(l.key, l.qty - 1)} aria-label="Giảm">−</button>
                        <span className="qty-num">{l.qty}</span>
                        <button className="qty-btn" onClick={() => onUpdateQty(l.key, l.qty + 1)} aria-label="Tăng">+</button>
                      </div>
                      <button
                        className="btn btn-ghost btn-sm"
                        style={{
                          padding: '0 2px',
                          fontSize: 12,
                          alignSelf: 'flex-start',
                          color:
                            discountAmountFor(unitPrice(l) * l.qty, l.discountType, l.discountValue) > 0
                              ? 'var(--green)'
                              : 'var(--muted)',
                        }}
                        onClick={() => setDiscountKey(l.key)}
                      >
                        🏷️ {discountAmountFor(unitPrice(l) * l.qty, l.discountType, l.discountValue) > 0 ? 'Sửa giảm giá' : 'Giảm giá'}
                      </button>
                    </div>
                    <div className="cprice">
                      {formatVND(unitPrice(l) * l.qty - discountAmountFor(unitPrice(l) * l.qty, l.discountType, l.discountValue))}
                    </div>
                  </div>
                ))
              )}
            </div>

            <button className="co-cust" onClick={() => setPickingCustomer(true)}>
              <span>👤</span>
              <span>
                {customer ? `${customer.name} · ${customer.phone}` : 'Chọn khách hàng'}
                {customer && customer.tier && customer.tier !== 'member' && (
                  <span className="sb-chip selected" style={{ marginLeft: 8, minHeight: 28, padding: '2px 8px' }}>
                    {TIER_LABEL[customer.tier]} · {customer.points ?? 0} điểm
                  </span>
                )}
              </span>
              <span className="chev">›</span>
            </button>
            {customer && (
              <button className="sb-link" style={{ marginBottom: 12 }} onClick={() => onCustomerChange(null)}>
                Bỏ chọn khách hàng
              </button>
            )}

            <div className="co-card">
              <div className="co-total-row">
                <span>Tiền hàng ({totalItems} món)</span>
                <span>{formatVND(total)}</span>
              </div>
              <div className="co-total-row" style={{ alignItems: 'center' }}>
                <span>🎁 Giảm giá{promo && discountType ? ` · ${promo.name}` : ''}</span>
                <span className="row" style={{ gap: 6 }}>
                  <button
                    type="button"
                    className={`sb-chip${discountType === 'percent' ? ' selected' : ''}`}
                    style={{ minHeight: 36, padding: '4px 10px' }}
                    onClick={() => setDiscountType(discountType === 'percent' ? null : 'percent')}
                  >
                    %
                  </button>
                  <button
                    type="button"
                    className={`sb-chip${discountType === 'amount' ? ' selected' : ''}`}
                    style={{ minHeight: 36, padding: '4px 10px' }}
                    onClick={() => setDiscountType(discountType === 'amount' ? null : 'amount')}
                  >
                    đ
                  </button>
                  <input
                    className="input"
                    style={{ width: 90, minHeight: 36 }}
                    inputMode="numeric"
                    placeholder="0"
                    disabled={!discountType}
                    value={discountValue}
                    onChange={(e) => setDiscountValue(e.target.value)}
                  />
                </span>
              </div>
              <div className="co-total-row" style={{ alignItems: 'center' }}>
                <span>🎟️ Voucher</span>
                {voucher ? (
                  <span className="row" style={{ gap: 6 }}>
                    <span className="sb-chip selected" style={{ minHeight: 36, padding: '4px 10px' }}>
                      {voucher.code} · -{formatVND(voucherDiscount)}
                    </span>
                    <button type="button" className="sb-chip" style={{ minHeight: 36, padding: '4px 10px' }} onClick={removeVoucher}>
                      Gỡ
                    </button>
                  </span>
                ) : (
                  <span className="row" style={{ gap: 6 }}>
                    <input
                      className="input"
                      style={{ width: 110, minHeight: 36, textTransform: 'uppercase' }}
                      placeholder="Mã voucher"
                      value={voucherInput}
                      onChange={(e) => setVoucherInput(e.target.value.toUpperCase())}
                      onKeyDown={(e) => e.key === 'Enter' && void applyVoucher()}
                    />
                    <button
                      type="button"
                      className="sb-chip"
                      style={{ minHeight: 36, padding: '4px 10px' }}
                      disabled={voucherBusy || !voucherInput.trim()}
                      onClick={() => void applyVoucher()}
                    >
                      {voucherBusy ? '…' : 'Áp dụng'}
                    </button>
                  </span>
                )}
              </div>
              {discountAmount > 0 && (
                <div className="co-total-row" style={{ color: 'var(--green)' }}>
                  <span>Đã giảm</span>
                  <span>-{formatVND(discountAmount)}</span>
                </div>
              )}
              <div className="co-total-row grand">
                <span>Tổng cộng</span>
                <span className="money">{formatVND(finalTotal)}</span>
              </div>
            </div>

            <div className="sb-note-row" style={{ alignItems: 'center' }}>
              <span style={{ fontSize: 13, color: 'var(--muted)', whiteSpace: 'nowrap' }}>🕐 Thời gian</span>
              <input
                className="input grow"
                type="datetime-local"
                value={orderTime}
                onChange={(e) => setOrderTime(e.target.value)}
              />
            </div>
            <div className="sb-note-row">
              <input
                className="input grow"
                placeholder="Nhập ghi chú đơn…"
                value={note}
                onChange={(e) => setNote(e.target.value)}
              />
            </div>
          </div>
          <div className="fsheet-foot">
            <div style={{ display: 'grid', gridTemplateColumns: onSaveDraft ? '1fr 2fr' : '1fr', gap: 8 }}>
              {onSaveDraft && (
                <button className="btn btn-outline btn-lg" style={{ width: '100%' }} disabled={lines.length === 0} onClick={onSaveDraft}>
                  <TIcon emoji="📋" size={14} /> Lưu tạm
                </button>
              )}
              <button className="btn btn-lg" style={{ width: '100%' }} disabled={lines.length === 0} onClick={goPay}>
                Tiếp tục thanh toán
              </button>
            </div>
          </div>
        </div>

        {pickingCustomer && (
          <CustomerPickSheet
            warehouseId={warehouseId || null}
            onClose={() => setPickingCustomer(false)}
            onPick={(c) => {
              onCustomerChange(c);
              setPickingCustomer(false);
              toast.show(`Đã chọn khách: ${c.name}`);
            }}
          />
        )}

        {discountKey && (() => {
          const line = lines.find((l) => l.key === discountKey);
          if (!line) return null;
          return (
            <LineDiscountSheet
              line={line}
              onClose={() => setDiscountKey(null)}
              onApply={(type, value) => {
                onUpdateLineDiscount(line.key, type, value);
                setDiscountKey(null);
              }}
            />
          );
        })()}
      </div>
    );
  }

  // ---- Bước 2: Thanh toán ----
  return (
    <div
      className="fsheet-backdrop"
      onClick={(e) => {
        if (e.target === e.currentTarget) closeSheet();
      }}
    >
      <div className="fsheet" role="dialog" aria-modal="true">
        <div className="fsheet-head">
          <button className="fsheet-back" onClick={() => setStep('confirm')} aria-label="Quay lại">‹</button>
          <div className="fsheet-title">Thanh toán: {formatVND(finalTotal)}</div>
          <span className="fsheet-side" />
        </div>
        <div className="fsheet-body">
          <div className="sb-toggle-row" style={{ marginBottom: 10 }}>
            <span className="grow">💳 Thanh toán hỗn hợp</span>
            <label className="switch">
              <input
                type="checkbox"
                checked={splitMode}
                onChange={(e) => setSplitMode(e.target.checked)}
              />
              <span className="track" />
            </label>
          </div>

          {splitMode ? (
            <>
              <div className="co-card" style={{ marginBottom: 10 }}>
                {methods.map((m) => (
                  <div className="row" key={m.id} style={{ gap: 8, marginBottom: 8, alignItems: 'center' }}>
                    <span className="grow">
                      <span style={{ marginRight: 6 }}>{m.icon}</span>
                      {m.name}
                    </span>
                    <input
                      className="input"
                      style={{ width: 130, minHeight: 44, textAlign: 'right' }}
                      inputMode="numeric"
                      placeholder="0"
                      value={splitAmounts[m.id] ?? ''}
                      onChange={(e) => setSplitAmounts((prev) => ({ ...prev, [m.id]: e.target.value }))}
                    />
                    <button
                      type="button"
                      className="sb-chip"
                      style={{ minHeight: 44, padding: '4px 10px', whiteSpace: 'nowrap' }}
                      onClick={() => splitFillRest(m.id)}
                    >
                      Còn lại
                    </button>
                  </div>
                ))}
                <div className="row" style={{ gap: 8, marginTop: 4 }}>
                  <button type="button" className="btn btn-outline grow" onClick={splitEven}>
                    Chia đều
                  </button>
                  <button type="button" className="btn btn-outline grow" onClick={splitClear}>
                    Xóa hết
                  </button>
                </div>
              </div>
              <div
                className="change-box"
                style={
                  splitRemaining !== 0
                    ? { background: 'var(--red-bg)', color: 'var(--red)' }
                    : undefined
                }
              >
                Đã nhập: <b>{formatVND(splitAllocated)}</b>
                {splitRemaining > 0 && <> · Còn thiếu: <b>{formatVND(splitRemaining)}</b></>}
                {splitRemaining < 0 && <> · Vượt: <b>{formatVND(-splitRemaining)}</b></>}
                {splitRemaining === 0 && splitAllocated > 0 && <> · ✓ Khớp tổng đơn</>}
              </div>
              {splitDebtTotal > 0 && (
                <div className="card" style={{ marginBottom: 8 }}>
                  {customer ? (
                    <p style={{ margin: 0 }}>
                      📒 Ghi nợ <b className="money">{formatVND(splitDebtTotal)}</b> cho <b>{customer.name}</b>.
                    </p>
                  ) : (
                    <p className="muted" style={{ margin: 0 }}>
                      ⚠️ Có phần ghi nợ — cần chọn khách hàng ở bước Xác nhận.
                    </p>
                  )}
                </div>
              )}
            </>
          ) : (
            <>
              <p className="muted" style={{ textAlign: 'center', margin: '2px 0 6px' }}>Khách trả</p>
              <input
                className="sb-money-input"
                inputMode="numeric"
                placeholder={formatVND(finalTotal)}
                value={kind === 'cash' ? received : formatVND(finalTotal)}
                disabled={kind !== 'cash'}
                onChange={(e) => { setReceived(e.target.value); setReceivedTouched(true); }}
              />
            </>
          )}

          {!splitMode && kind === 'cash' && (
            <>
              <div className="quick-cash">
                {QUICK_CASH.map((v) => (
                  <button key={v} className="btn btn-outline" style={{ minHeight: 48 }} onClick={() => { setReceived(String(v)); setReceivedTouched(true); }}>
                    {formatVND(v)}
                  </button>
                ))}
                <button className="btn btn-outline" style={{ minHeight: 48 }} onClick={() => { setReceived(String(finalTotal)); setReceivedTouched(true); }}>
                  Vừa đủ
                </button>
              </div>
              {receivedTouched && receivedNum > 0 && (
                <div className="change-box" style={change < 0 ? { background: 'var(--red-bg)', color: 'var(--red)' } : undefined}>
                  {change >= 0 ? `Thối lại: ${formatVND(change)}` : `Còn thiếu: ${formatVND(-change)}`}
                </div>
              )}
            </>
          )}

          {!splitMode && (
          <div className="sb-paygrid">
            {methods.map((m) => (
              <button
                key={m.id}
                className={`sb-paycard${m.id === methodId ? ' selected' : ''}`}
                onClick={() => setMethodId(m.id)}
              >
                <span className="pico"><TIcon emoji={m.icon || '💵'} size={20} /></span>
                <span>{m.name}</span>
              </button>
            ))}
          </div>
          )}

          {!splitMode && debtMethod && (
            <div className="sb-toggle-row">
              <span className="grow">Ghi nợ đơn</span>
              <label className="switch">
                <input
                  type="checkbox"
                  checked={kind === 'debt'}
                  onChange={(e) => {
                    if (e.target.checked) setMethodId(debtMethod.id);
                    else if (cashMethod) setMethodId(cashMethod.id);
                  }}
                />
                <span className="track" />
              </label>
            </div>
          )}

          {!splitMode && kind === 'transfer' && (
            <div className="card" style={{ marginBottom: 8 }}>
              {bankBin && bankAccount ? (
                <p style={{ margin: 0 }}>
                  📱 Bấm <b>“Xác nhận”</b> — hệ thống tạo đơn rồi hiện mã VietQR đúng số tiền &amp; nội dung để khách quét.
                  <br />
                  <span className="muted small">{bankName} · {bankAccount}</span>
                </p>
              ) : (
                <p className="muted" style={{ margin: 0 }}>Chưa cấu hình ngân hàng cho phương thức này — vào Cài đặt → Phương thức thanh toán để nhập BIN, số tài khoản.</p>
              )}
            </div>
          )}

          {!splitMode && kind === 'debt' && (
            <div className="card" style={{ marginBottom: 8 }}>
              {customer ? (
                <p style={{ margin: 0 }}>
                  📒 Ghi nợ <b className="money">{formatVND(finalTotal)}</b> cho <b>{customer.name}</b>.
                  <br />
                  <span className="muted small">
                    Công nợ hiện tại: <span className="money">{formatVND(customer.debt ?? 0)}</span>
                    {' '}→ sau đơn này: <span className="money">{formatVND((customer.debt ?? 0) + finalTotal)}</span>
                  </span>
                </p>
              ) : (
                <p className="muted" style={{ margin: 0 }}>⚠️ Ghi nợ cần chọn khách hàng — quay lại bước Xác nhận để chọn khách.</p>
              )}
            </div>
          )}

          <div className="sb-note-row">
            <input
              className="input grow"
              placeholder="Nhập ghi chú đơn…"
              value={note}
              onChange={(e) => setNote(e.target.value)}
            />
          </div>
        </div>
        <div className="fsheet-foot">
          {splitMode ? (
            <button
              className="btn btn-block btn-lg"
              disabled={
                busy ||
                splitRows.length === 0 ||
                Math.abs(splitAllocated - finalTotal) > 1 ||
                (splitDebtTotal > 0 && !customer)
              }
              onClick={() => void submitSplit()}
            >
              {busy ? 'Đang xử lý…' : `Xác nhận · ${formatVND(finalTotal)}`}
            </button>
          ) : (
            method && (
              <button
                className="btn btn-block btn-lg"
                disabled={
                  busy ||
                  (kind === 'cash' && receivedNum < finalTotal) ||
                  (kind === 'debt' && !customer) ||
                  (kind === 'transfer' && (!bankBin || !bankAccount))
                }
                onClick={() => submit(method)}
              >
                {busy ? 'Đang xử lý…' : 'Xác nhận'}
              </button>
            )
          )}
        </div>
      </div>
    </div>
  );
}

