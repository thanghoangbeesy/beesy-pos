import { useEffect, useState } from 'react';
import { formatDateTime, formatVND } from '../lib/format';
import { useVietQRImage } from '../lib/vietqr';
import type { Order } from '../lib/types';
import { isSplitPayment, orderPaymentSplits } from '../lib/types';

// Bill xem trước + vùng in khổ 80mm (render vào #print-root để CSS @media print bắt được)
export function BillPrint({
  order,
  shopName,
  shopPhone,
  shopAddress,
  shopLogo,
  qrBin,
  qrName,
  qrAccount,
  qrAmount,
}: {
  order: Order;
  shopName: string;
  shopPhone?: string;
  shopAddress?: string;
  shopLogo?: string;
  qrBin?: string | null;
  qrName?: string;
  qrAccount?: string;
  qrAmount?: number;
}) {
  const [now] = useState(() => new Date());
  // QR tu sinh dang PNG data URL (lib/vietqr) - anh vietqr.io dang SVG khien
  // anh bill chup ra bi trong cho QR. Ca bill hien thi lan ban in deu dung URL nay.
  const qrUrl = useVietQRImage(qrBin, qrAccount, qrName, qrAmount, order.code);

  useEffect(() => {
    let root = document.getElementById('print-root');
    if (!root) {
      root = document.createElement('div');
      root.id = 'print-root';
      document.body.appendChild(root);
    }
    return () => {
      const r = document.getElementById('print-root');
      if (r) r.innerHTML = '';
    };
  }, []);

  useEffect(() => {
    const root = document.getElementById('print-root');
    if (!root) return;
    const lines = order.items
      .map(
        (it) => `
        <div>
          <div class="row"><span>${it.qty} x ${escapeHtml(it.product_name)}</span><span>${formatVND(it.line_total)}</span></div>
          ${it.discount ? `<div class="small">  Giảm: -${formatVND(it.discount)}</div>` : ''}
          ${(it.modifiers || []).map((m) => `<div class="small">  + ${escapeHtml(m.option)}${m.price_delta ? ` (+${formatVND(m.price_delta)})` : ''}</div>`).join('')}
          ${it.note ? `<div class="small">  📝 ${escapeHtml(it.note)}</div>` : ''}
        </div>`,
      )
      .join('');
    const splits = orderPaymentSplits(order);
    const split = isSplitPayment(order);
    const payLabel = split
      ? 'Hỗn hợp'
      : order.payment_method_name
        || (order.payment_method === 'cash' ? 'Tiền mặt' : order.payment_method === 'transfer' ? 'Chuyển khoản' : 'Ghi nợ');
    const payRows = split
      ? splits.map((sp) => `<div class="row small"><span>&nbsp;&nbsp;${escapeHtml(sp.method_name)}</span><span>${formatVND(sp.amount)}</span></div>`).join('')
      : '';
    const logoHtml = shopLogo
      ? shopLogo.startsWith('data:image')
        ? `<div class="center" style="margin-bottom:6px"><img src="${shopLogo}" alt="Logo" style="max-width:120px;max-height:80px;" /></div>`
        : `<div class="center" style="font-size:36px;margin-bottom:4px">${escapeHtml(shopLogo)}</div>`
      : '';
    root.innerHTML = `
      <div id="print-area">
        ${logoHtml}
        <h2>${escapeHtml(shopName)}</h2>
        ${shopAddress ? `<div class="center small">${escapeHtml(shopAddress)}</div>` : ''}
        ${shopPhone ? `<div class="center small">ĐT: ${escapeHtml(shopPhone)}</div>` : ''}
        <div class="center">HÓA ĐƠN BÁN HÀNG</div>
        <div class="center">Mã đơn: <b>${escapeHtml(order.code)}</b></div>
        <div class="center small">${formatDateTime(order.created_at)}</div>
        <hr/>
        ${lines}
        <hr/>
        ${order.discount > 0 ? `<div class="row"><span>Giam gia${order.discount_label ? ` (${escapeHtml(order.discount_label)})` : ''}</span><span>-${formatVND(order.discount)}</span></div>` : ''}
        <div class="row"><span>Tổng cộng</span><span class="total">${formatVND(order.total)}</span></div>
        <div class="row"><span>Thanh toán</span><span>${escapeHtml(payLabel)}</span></div>
        ${payRows}
        ${
          order.payment_method === 'cash' && order.amount_received != null
            ? `<div class="row"><span>Khách đưa</span><span>${formatVND(order.amount_received)}</span></div>
               <div class="row"><span>Thối lại</span><span>${formatVND(order.change_amount ?? 0)}</span></div>`
            : ''
        }
        ${order.note ? `<div class="small">Ghi chú: ${escapeHtml(order.note)}</div>` : ''}
        ${qrUrl ? `
        <hr/>
        <div class="center">
          <div class="small" style="margin-bottom:4px"><b>Quét mã để chuyển tiền</b></div>
          <img src="${qrUrl}" alt="QR thanh toán" style="width:180px;height:180px;" />
          <div class="small">${escapeHtml(qrName || '')}</div>
          <div class="small">STK: ${escapeHtml(qrAccount || '')}</div>
          <div class="small">Số tiền: <b>${formatVND(qrAmount || 0)}</b> · Nội dung: <b>${escapeHtml(order.code)}</b></div>
        </div>` : ''}
        <hr/>
        <div class="center">Cảm ơn quý khách! Hẹn gặp lại ☕</div>
        <div class="center small">In lúc ${now.toLocaleTimeString('vi-VN')}</div>
      </div>`;
  }, [order, shopName, shopPhone, shopAddress, shopLogo, qrUrl, qrName, qrAccount, qrAmount, now]);

  return (
    <div id="bill-capture" className="card" style={{ marginTop: 12, fontFamily: '"Be Vietnam Pro", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif', fontSize: 14 }}>
      {shopLogo && (
        <div style={{ textAlign: 'center', marginBottom: 6 }}>
          {shopLogo.startsWith('data:image') ? (
            <img src={shopLogo} alt="Logo" style={{ maxWidth: 120, maxHeight: 80 }} />
          ) : (
            <span style={{ fontSize: 36 }}>{shopLogo}</span>
          )}
        </div>
      )}
      <h3 style={{ textAlign: 'center', margin: '0 0 4px' }}>{shopName}</h3>
      {shopAddress && <p style={{ textAlign: 'center', margin: '0 0 2px' }} className="muted small">{shopAddress}</p>}
      {shopPhone && <p style={{ textAlign: 'center', margin: '0 0 8px' }} className="muted small">ĐT: {shopPhone}</p>}
      <p style={{ textAlign: 'center', margin: '0 0 8px' }} className="muted small">
        HÓA ĐƠN · Mã <b>{order.code}</b> · {formatDateTime(order.created_at)}
      </p>
      {order.items.map((it) => (
        <div key={it.id} style={{ marginBottom: 6 }}>
          <div className="row">
            <span>{it.qty} x {it.product_name}</span>
            <span className="money">{formatVND(it.line_total)}</span>
          </div>
          {(it.modifiers || []).map((m, i) => (
            <div key={i} className="small muted">
              &nbsp;&nbsp;+ {m.option}{m.price_delta ? ` (+${formatVND(m.price_delta)})` : ''}
            </div>
          ))}
          {it.discount ? (
            <div className="small" style={{ color: 'var(--green)' }}>
              &nbsp;&nbsp;Giảm: −{formatVND(it.discount)}
            </div>
          ) : null}
        </div>
      ))}
      <hr style={{ border: 'none', borderTop: '1px dashed var(--line)' }} />
      {order.discount > 0 && (
        <div className="row small" style={{ color: 'var(--green)' }}>
          <span>Giảm giá{order.discount_label ? ` (${order.discount_label})` : ''}</span>
          <span>-{formatVND(order.discount)}</span>
        </div>
      )}
      <div className="row">
        <b>Tổng cộng</b>
        <b className="money" style={{ fontSize: 18 }}>{formatVND(order.total)}</b>
      </div>
      {isSplitPayment(order) ? (
        <div className="small muted" style={{ marginTop: 4 }}>
          <div className="row small"><span>💳 Thanh toán hỗn hợp</span></div>
          {orderPaymentSplits(order).map((sp) => (
            <div className="row small" key={sp.method_id}>
              <span style={{ paddingLeft: 8 }}>
                {sp.kind === 'cash' ? '💵' : sp.kind === 'transfer' ? '📱' : '📒'} {sp.method_name}
              </span>
              <span className="money">{formatVND(sp.amount)}</span>
            </div>
          ))}
        </div>
      ) : (
        <div className="row small muted">
          <span>{order.payment_method_name ?? (order.payment_method === 'cash' ? '💵 Tiền mặt' : order.payment_method === 'transfer' ? '📱 Chuyển khoản' : '📒 Ghi nợ')}</span>
          {order.payment_method === 'cash' && order.amount_received != null && (
            <span>Đưa {formatVND(order.amount_received)} · Thối {formatVND(order.change_amount ?? 0)}</span>
          )}
        </div>
      )}
      {qrUrl && (
        <div style={{ textAlign: 'center', marginTop: 12, paddingTop: 12, borderTop: '1px dashed var(--line)' }}>
          <div className="small" style={{ marginBottom: 6 }}><b>Quét mã để chuyển tiền</b></div>
          <img src={qrUrl} alt="QR thanh toán" style={{ width: 180, height: 180 }} />
          <div className="small muted" style={{ marginTop: 4 }}>
            {qrName && <div>{qrName}</div>}
            {qrAccount && <div>STK: {qrAccount}</div>}
            <div>Số tiền: <b className="money">{formatVND(qrAmount || 0)}</b> · Nội dung: <b>{order.code}</b></div>
          </div>
        </div>
      )}
    </div>
  );
}

function escapeHtml(s: string): string {
  return s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c] ?? c));
}
