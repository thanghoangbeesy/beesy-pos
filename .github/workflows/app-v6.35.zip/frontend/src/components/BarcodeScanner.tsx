import { useEffect, useId, useRef, useState } from 'react';
import { Html5Qrcode, Html5QrcodeSupportedFormats } from 'html5-qrcode';
import { Sheet } from './Sheet';

// Quet ma vach bang camera (dien thoai / may tinh co webcam).
// Chi nhan ma vach 1D (EAN/UPC/CODE...) — khong nhan QR de tranh quet nham
// QR quang cao hay QR thanh toan. Can quyen camera (trang live chay HTTPS
// nen xin duoc); khong mo duoc camera thi bao loi va nhap tay ma vach.
const FORMATS = [
  Html5QrcodeSupportedFormats.EAN_13,
  Html5QrcodeSupportedFormats.EAN_8,
  Html5QrcodeSupportedFormats.UPC_A,
  Html5QrcodeSupportedFormats.UPC_E,
  Html5QrcodeSupportedFormats.CODE_128,
  Html5QrcodeSupportedFormats.CODE_39,
  Html5QrcodeSupportedFormats.CODE_93,
  Html5QrcodeSupportedFormats.ITF,
  Html5QrcodeSupportedFormats.CODABAR,
];

export function BarcodeScanner({
  onScan,
  onClose,
}: {
  onScan: (code: string) => void;
  onClose: () => void;
}) {
  const id = useId().replace(/[^a-zA-Z0-9]/g, '');
  const elId = `barcode-reader-${id}`;
  const [error, setError] = useState('');
  const [scanning, setScanning] = useState(false);
  const doneRef = useRef(false);
  const onScanRef = useRef(onScan);
  onScanRef.current = onScan;

  useEffect(() => {
    let stopped = false;
    const scanner = new Html5Qrcode(elId, { formatsToSupport: FORMATS, verbose: false });
    scanner
      .start(
        { facingMode: 'environment' },
        { fps: 10, qrbox: { width: 240, height: 140 } },
        (decodedText) => {
          if (doneRef.current) return;
          doneRef.current = true;
          onScanRef.current(decodedText);
        },
        () => {
          // Loi doc khung hinh (khong thay ma) — bo qua, van quet tiep.
        },
      )
      .then(() => {
        if (!stopped) setScanning(true);
      })
      .catch(() => {
        if (!stopped)
          setError('Không mở được camera. Kiểm tra quyền camera của trình duyệt, hoặc nhập tay mã vạch.');
      });
    return () => {
      stopped = true;
      // stop() reject neu camera chua kip mo — bo qua, clear() giai phong the div.
      void scanner
        .stop()
        .catch(() => {})
        .finally(() => {
          try {
            scanner.clear();
          } catch {
            // Bo qua — the da duoc go.
          }
        });
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [elId]);

  return (
    <Sheet title="Quét mã vạch" onClose={onClose}>
      <div id={elId} className="barcode-reader" />
      {error ? (
        <p className="small" style={{ color: '#dc2626', marginTop: 10 }}>
          {error}
        </p>
      ) : (
        <p className="small muted" style={{ marginTop: 10, textAlign: 'center' }}>
          {scanning ? 'Đưa mã vạch vào khung hình…' : 'Đang mở camera…'}
        </p>
      )}
      <button
        type="button"
        className="btn btn-outline btn-block"
        style={{ marginTop: 12, minHeight: 44 }}
        onClick={onClose}
      >
        Đóng
      </button>
    </Sheet>
  );
}
