import { useCallback, useEffect, useRef, useState } from 'react';
import type { FormEvent } from 'react';
import {
  DbError,
  createCategory,
  createModifierOption,
  createProduct,
  createProductsBulk,
  deleteCategory,
  deleteModifierOption,
  deleteProduct,
  getAllowedWarehouses,
  getDefaultWarehouseId,
  getIngredientAvgCosts,
  listCategories,
  listIngredients,
  listModifierGroups,
  listProducts,
  updateCategory,
  updateModifierOption,
  updateProduct,
  setProductStockTracking,
} from '../lib/db';
import { canUsePro } from '../lib/license';
import { formatVND, unsignVietnamese } from '../lib/format';
import { PageHead } from '../components/PageHead';
import { LineIcon } from '../components/LineIcon';
import './pc-menu.css';
import { Sheet } from '../components/Sheet';
import { TIcon } from '../components/TIcon';
import { useToast } from '../components/Toast';
import { useAuth } from '../lib/auth';
import type { Category, Ingredient, ModifierGroup, Product, RecipeItem, Warehouse } from '../lib/types';
import { findBarcodeOwner, normalizeBarcode } from '../lib/barcode';

type Tab = 'products' | 'modifiers' | 'categories';

/** Hook phat hien man hinh PC (>= 1024px), theo mau pages/Reports.tsx. */
function useIsPC(): boolean {
  const [isPC, setIsPC] = useState(() => typeof window !== 'undefined' && window.innerWidth >= 1024);
  useEffect(() => {
    const onResize = () => setIsPC(window.innerWidth >= 1024);
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);
  return isPC;
}

export function Menu() {
  const toast = useToast();
  const { can } = useAuth();
  const isPC = useIsPC();
  const [tab, setTab] = useState<Tab>('products');
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [groups, setGroups] = useState<ModifierGroup[]>([]);
  const [loading, setLoading] = useState(true);

  const reload = useCallback(async () => {
    try {
      const [cats, prods, gs] = await Promise.all([
        listCategories(),
        listProducts(),
        listModifierGroups(),
      ]);
      setCategories(cats.sort((a, b) => a.sort_order - b.sort_order));
      setProducts(prods.sort((a, b) => a.sort_order - b.sort_order));
      setGroups(gs.sort((a, b) => a.sort_order - b.sort_order));
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tải được menu');
    } finally {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    void reload();
  }, [reload]);

  if (!can('menu')) {
    return (
      <div className="page">
        <div className="card">🔒 Chỉ Quản lý trở lên mới được quản lý menu.</div>
      </div>
    );
  }

  // Nhanh PC: dat sau early return phan quyen de ca 2 nhanh deu ton trong phan quyen.
  // JSX mobile ben duoi khong doi mot dong.
  if (isPC) {
    return (
      <div className="page pc-menu">
        <PageHead title="Menu" />
        <div className="pc-menu-head">
          <h1>Menu</h1>
          <p className="muted">Quản lý món, topping và danh mục của quán.</p>
        </div>
        <div className="pc-menu-tabs" role="tablist">
          <button className={`pc-menu-tab${tab === 'products' ? ' active' : ''}`} onClick={() => setTab('products')}>
            <LineIcon name="store" size={18} /> Món
          </button>
          <button className={`pc-menu-tab${tab === 'modifiers' ? ' active' : ''}`} onClick={() => setTab('modifiers')}>
            <LineIcon name="plus" size={18} /> Topping
          </button>
          <button className={`pc-menu-tab${tab === 'categories' ? ' active' : ''}`} onClick={() => setTab('categories')}>
            <LineIcon name="folder" size={18} /> Danh mục
          </button>
        </div>
        {loading ? (
          <div className="card">Đang tải…</div>
        ) : (
          <div className="pc-menu-layout">
            <section className="pc-menu-main">
              {tab === 'products' ? (
                <PcProductsTab products={products} categories={categories} reload={reload} />
              ) : tab === 'modifiers' ? (
                <div className="pc-menu-card">
                  <ModifiersTab groups={groups} reload={reload} />
                </div>
              ) : (
                <div className="pc-menu-card">
                  <CategoriesTab categories={categories} products={products} reload={reload} />
                </div>
              )}
            </section>
            <aside className="pc-menu-side">
              {tab !== 'categories' && (
                <PcCategoryCard categories={categories} products={products} reload={reload} onManage={() => setTab('categories')} />
              )}
              {tab !== 'modifiers' && (
                <PcToppingCard groups={groups} onManage={() => setTab('modifiers')} />
              )}
              {tab !== 'products' && (
                <PcSummaryCard products={products} categories={categories} groups={groups} />
              )}
            </aside>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="page">
      <PageHead title="Menu" />
      <div className="sb-tabs">
        <button className={`sb-tab${tab === 'products' ? ' active' : ''}`} onClick={() => setTab('products')}>Sản phẩm</button>
        <button className={`sb-tab${tab === 'modifiers' ? ' active' : ''}`} onClick={() => setTab('modifiers')}>Topping</button>
        <button className={`sb-tab${tab === 'categories' ? ' active' : ''}`} onClick={() => setTab('categories')}>Danh mục</button>
      </div>
      {loading ? (
        <div className="card">Đang tải…</div>
      ) : tab === 'products' ? (
        <ProductsTab products={products} categories={categories} reload={reload} />
      ) : tab === 'modifiers' ? (
        <ModifiersTab groups={groups} reload={reload} />
      ) : (
        <CategoriesTab categories={categories} products={products} reload={reload} />
      )}
    </div>
  );
}

/* ---------------- PC: tab Mon (bang nhieu cot) ---------------- */
/* Chi dung o nhanh PC. Dung chung loader Menu (products/categories) + form
   ProductForm / BulkAddSheet san co; chi khac JSX trinh bay so voi ProductsTab.
   Tim kiem dung unsignVietnamese o ca 2 phia nen go khong dau cung tim duoc
   (ban mobile cu giu nguyen logic includes thuong, khong dung toi). */
function PcProductsTab({ products, categories, reload }: { products: Product[]; categories: Category[]; reload: () => Promise<void> }) {
  const [editing, setEditing] = useState<Product | 'new' | null>(null);
  const [bulkOpen, setBulkOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [catFilter, setCatFilter] = useState<string>('all');
  const [whFilter, setWhFilter] = useState<string>('all');
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [ingredients, setIngredients] = useState<Ingredient[]>([]);
  const [modGroups, setModGroups] = useState<ModifierGroup[]>([]);

  useEffect(() => {
    listIngredients(true).then(setIngredients).catch(() => {});
    getAllowedWarehouses().then(({ warehouses: ws }) => setWarehouses(ws)).catch(() => {});
    listModifierGroups().then(setModGroups).catch(() => {});
  }, []);

  const catName = (id: string | null) => categories.find((c) => c.id === id)?.name ?? 'Chưa phân loại';
  const needle = unsignVietnamese(query.trim()).toLowerCase();

  const visible = products.filter((p) => {
    const okQ = !needle || unsignVietnamese(p.name).toLowerCase().includes(needle);
    const okC = catFilter === 'all' || p.category_id === catFilter;
    const okW = whFilter === 'all' || p.warehouse_ids.length === 0 || p.warehouse_ids.includes(whFilter);
    return okQ && okC && okW;
  });

  return (
    <>
      <div className="pc-menu-toolbar">
        <label className="pc-menu-search">
          <LineIcon name="search" size={18} />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Tìm món theo tên…"
            aria-label="Tìm món theo tên"
          />
        </label>
        <button className="btn" onClick={() => setEditing('new')}>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
            <LineIcon name="plus" size={18} /> Thêm món
          </span>
        </button>
        <button className="btn btn-outline" onClick={() => setBulkOpen(true)}>Thêm hàng loạt</button>
      </div>
      <p className="pc-menu-note">Gõ không dấu cũng tìm được.</p>
      <div className="pc-menu-chips">
        <button className={`sb-chip${catFilter === 'all' ? ' selected' : ''}`} onClick={() => setCatFilter('all')}>
          Tất cả
        </button>
        {categories.map((c) => (
          <button
            key={c.id}
            className={`sb-chip${catFilter === c.id ? ' selected' : ''}`}
            onClick={() => setCatFilter(c.id)}
            title={c.name}
          >
            <span className="pc-menu-ellipsis" style={{ maxWidth: 180 }}>{c.name}</span>
          </button>
        ))}
      </div>
      {warehouses.length > 1 && (
        <div className="pc-menu-chips">
          <button className={`sb-chip${whFilter === 'all' ? ' selected' : ''}`} onClick={() => setWhFilter('all')}>
            Mọi kho
          </button>
          {warehouses.map((w) => (
            <button key={w.id} className={`sb-chip${whFilter === w.id ? ' selected' : ''}`} onClick={() => setWhFilter(w.id)} title={w.name}>
              <span className="pc-menu-ellipsis" style={{ maxWidth: 180 }}>{w.name}</span>
            </button>
          ))}
        </div>
      )}
      <div className="pc-menu-card" style={{ padding: '8px 10px' }}>
        <div className="pc-menu-count" style={{ margin: '8px 8px 4px' }}>Số lượng: {visible.length}</div>
        {visible.length === 0 ? (
          <p className="pc-menu-empty" style={{ padding: '8px 8px 12px' }}>
            {products.length === 0 ? 'Chưa có món nào. Bấm nút Thêm món để thêm món mới.' : 'Không tìm thấy món nào khớp.'}
          </p>
        ) : (
          <div className="pc-menu-table-wrap">
            <table className="pc-menu-table">
              <thead>
                <tr>
                  <th className="pc-menu-col-dish">Món</th>
                  <th className="pc-menu-col-cat">Danh mục</th>
                  <th className="pc-menu-col-price pc-menu-num">Giá bán</th>
                  <th className="pc-menu-col-status">Trạng thái</th>
                  <th className="pc-menu-col-action">Thao tác</th>
                </tr>
              </thead>
              <tbody>
                {visible.map((p) => {
                  const sub = [
                    p.unit,
                    p.track_stock ? 'Theo dõi tồn' : p.recipe.length > 0 ? `${p.recipe.length} nguyên liệu` : '',
                    p.barcode ? `Mã vạch: ${p.barcode}` : '',
                    p.platform_price ? `Giá sàn: ${formatVND(p.platform_price)}` : '',
                  ].filter(Boolean).join(' · ');
                  return (
                    <tr key={p.id} className={p.active ? undefined : 'pc-menu-row-off'}>
                      <td>
                        <div className="pc-menu-dish">
                          <span className="pc-menu-thumb" aria-hidden>{p.name.trim().charAt(0).toUpperCase() || '?'}</span>
                          <span className="pc-menu-dish-text">
                            <span className="pc-menu-dish-name pc-menu-ellipsis" title={p.name}>{p.name}</span>
                            {sub && <span className="pc-menu-dish-sub pc-menu-ellipsis" title={sub}>{sub}</span>}
                          </span>
                        </div>
                      </td>
                      <td>
                        <span className="pc-menu-ellipsis" style={{ display: 'block' }} title={catName(p.category_id)}>{catName(p.category_id)}</span>
                      </td>
                      <td className="pc-menu-num">
                        <span className="pc-menu-price">{formatVND(p.base_price)}{p.unit ? `/${p.unit}` : ''}</span>
                      </td>
                      <td>
                        <span className={`pc-menu-pill${p.active ? '' : ' off'}`}>{p.active ? 'Đang bán' : 'Đang ẩn'}</span>
                      </td>
                      <td>
                        <button className="btn btn-ghost btn-sm" onClick={() => setEditing(p)} aria-label={`Sửa món ${p.name}`}>
                          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                            <LineIcon name="edit" size={16} /> Sửa
                          </span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
      {editing && (
        <ProductForm product={editing === 'new' ? null : editing} products={products} categories={categories} ingredients={ingredients} warehouses={warehouses} modGroups={modGroups} onClose={() => setEditing(null)} reload={reload} />
      )}
      {bulkOpen && (
        <BulkAddSheet categories={categories} onClose={() => setBulkOpen(false)} reload={reload} />
      )}
    </>
  );
}

/* ---------------- PC: card Danh muc (panel phai) ---------------- */
/* Sap xep dung dung thuat toan move() cua CategoriesTab: hoan doi tren danh
   sach day du roi gan lai sort_order 0,1,2... Nut sap xep AN khi dang tim
   (o day tim kiem la o tim rieng cua card), giong logic cu. */
function PcCategoryCard({ categories, products, reload, onManage }: { categories: Category[]; products: Product[]; reload: () => Promise<void>; onManage: () => void }) {
  const toast = useToast();
  const [query, setQuery] = useState('');
  const needle = unsignVietnamese(query.trim()).toLowerCase();
  const visible = needle ? categories.filter((c) => unsignVietnamese(c.name).toLowerCase().includes(needle)) : categories;
  const count = (id: string) => products.filter((p) => p.category_id === id).length;

  const move = async (c: Category, dir: -1 | 1) => {
    const idx = categories.findIndex((x) => x.id === c.id);
    const j = idx + dir;
    if (idx < 0 || j < 0 || j >= categories.length) return;
    const next = [...categories];
    [next[idx], next[j]] = [next[j], next[idx]];
    try {
      await Promise.all(
        next.map((cat, i) =>
          cat.sort_order !== i ? updateCategory(cat.id, { sort_order: i }) : Promise.resolve(),
        ),
      );
      await reload();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Đổi thứ tự thất bại');
    }
  };

  return (
    <div className="pc-menu-card">
      <div className="pc-menu-card-head">
        <LineIcon name="folder" size={20} />
        <h3>Danh mục</h3>
        <button className="btn btn-ghost btn-sm" onClick={onManage}>Quản lý</button>
      </div>
      <label className="pc-menu-search pc-menu-side-search">
        <LineIcon name="search" size={18} />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Tìm danh mục…"
          aria-label="Tìm danh mục"
        />
      </label>
      {categories.length === 0 ? (
        <p className="pc-menu-empty">Chưa có danh mục nào.</p>
      ) : visible.length === 0 ? (
        <p className="pc-menu-empty">Không tìm thấy danh mục phù hợp.</p>
      ) : (
        <div>
          {visible.map((c) => {
            const idx = categories.findIndex((x) => x.id === c.id);
            return (
              <div key={c.id} className="pc-menu-side-row" style={c.active ? undefined : { opacity: 0.55 }}>
                <span className="pc-menu-side-text">
                  <b className="pc-menu-ellipsis" title={c.name}>{c.name}</b>
                  <span>{count(c.id)} món{c.active ? '' : ' · Đang ẩn'}</span>
                </span>
                {!needle && (
                  <>
                    <button
                      className="pc-menu-chev up"
                      disabled={idx <= 0}
                      onClick={() => void move(c, -1)}
                      aria-label={`Đưa danh mục ${c.name} lên`}
                    >
                      <i />
                    </button>
                    <button
                      className="pc-menu-chev down"
                      disabled={idx < 0 || idx >= categories.length - 1}
                      onClick={() => void move(c, 1)}
                      aria-label={`Đưa danh mục ${c.name} xuống`}
                    >
                      <i />
                    </button>
                  </>
                )}
              </div>
            );
          })}
        </div>
      )}
      <p className="pc-menu-note-sm">Thứ tự danh mục ở đây cũng là thứ tự hiển thị ở màn Bán hàng. Dùng nút mũi tên lên/xuống ở mỗi dòng để sắp xếp lại.</p>
    </div>
  );
}

/* ---------------- PC: card Topping tom tat (panel phai, chi doc) ---------------- */
/* Chi hien thi, khong trung lap form sua: muon sua thi bam Quan ly sang tab Topping. */
function PcToppingCard({ groups, onManage }: { groups: ModifierGroup[]; onManage: () => void }) {
  return (
    <div className="pc-menu-card">
      <div className="pc-menu-card-head">
        <LineIcon name="plus" size={20} />
        <h3>Topping</h3>
        <button className="btn btn-ghost btn-sm" onClick={onManage}>Quản lý</button>
      </div>
      {groups.length === 0 ? (
        <p className="pc-menu-empty">Chưa có nhóm topping nào.</p>
      ) : (
        <div>
          {groups.map((g) => (
            <div key={g.id} className="pc-menu-top-group">
              <h4 className="pc-menu-ellipsis" title={g.name}>{g.name}</h4>
              <div className="pc-menu-top-sub">
                {g.selection_type === 'single' ? 'Chọn 1' : 'Chọn nhiều'}{g.required ? ' · Bắt buộc' : ''}
              </div>
              {[...(g.options ?? [])].sort((a, b) => a.sort_order - b.sort_order).map((o) => (
                <div key={o.id} className="pc-menu-opt" style={o.active ? undefined : { opacity: 0.55 }}>
                  <span className="pc-menu-opt-name pc-menu-ellipsis" title={o.name}>{o.name}{o.active ? '' : ' · Đang ẩn'}</span>
                  <span className="pc-menu-opt-delta">{o.price_delta > 0 ? `+${formatVND(o.price_delta)}` : 'Miễn phí'}</span>
                </div>
              ))}
            </div>
          ))}
        </div>
      )}
      <p className="pc-menu-note-sm">Nhóm topping và phụ thu được áp dụng khi khách chọn món ở màn Bán hàng.</p>
    </div>
  );
}

/* ---------------- PC: card tom tat menu (panel phai khi tab khong phai Mon) ---------------- */
function PcSummaryCard({ products, categories, groups }: { products: Product[]; categories: Category[]; groups: ModifierGroup[] }) {
  const selling = products.filter((p) => p.active).length;
  const optCount = groups.reduce((n, g) => n + (g.options ?? []).length, 0);
  const rows: [string, string][] = [
    ['Tổng số món', String(products.length)],
    ['Đang bán', String(selling)],
    ['Đang ẩn', String(products.length - selling)],
    ['Danh mục', String(categories.length)],
    ['Nhóm topping', String(groups.length)],
    ['Lựa chọn topping', String(optCount)],
  ];
  return (
    <div className="pc-menu-card">
      <div className="pc-menu-card-head">
        <LineIcon name="chart" size={20} />
        <h3>Tổng quan menu</h3>
      </div>
      <div>
        {rows.map(([label, value]) => (
          <div key={label} className="pc-menu-opt">
            <span className="pc-menu-opt-name">{label}</span>
            <span className="pc-menu-opt-delta" style={{ color: 'var(--ink)', fontWeight: 600 }}>{value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------------- Món ---------------- */
function ProductsTab({ products, categories, reload }: { products: Product[]; categories: Category[]; reload: () => Promise<void> }) {
  const [editing, setEditing] = useState<Product | 'new' | null>(null);
  const [bulkOpen, setBulkOpen] = useState(false);
  const [fabOpen, setFabOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [catFilter, setCatFilter] = useState<string>('all');
  const [whFilter, setWhFilter] = useState<string>('all');
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [ingredients, setIngredients] = useState<Ingredient[]>([]);
  const [modGroups, setModGroups] = useState<ModifierGroup[]>([]);

  useEffect(() => {
    listIngredients(true).then(setIngredients).catch(() => {});
    getAllowedWarehouses().then(({ warehouses: ws }) => setWarehouses(ws)).catch(() => {});
    listModifierGroups().then(setModGroups).catch(() => {});
  }, []);

  const catName = (id: string | null) => categories.find((c) => c.id === id)?.name ?? 'Chưa phân loại';

  const visible = products.filter((p) => {
    const q = query.trim().toLowerCase();
    const okQ = !q || p.name.toLowerCase().includes(q);
    const okC = catFilter === 'all' || p.category_id === catFilter;
    const okW = whFilter === 'all' || p.warehouse_ids.length === 0 || p.warehouse_ids.includes(whFilter);
    return okQ && okC && okW;
  });

  return (
    <>
      <div className="sb-search" style={{ marginBottom: 10 }}>
        <span className="sico" aria-hidden><TIcon emoji="🔍" size={18} /></span>
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Tìm tên món…"
          aria-label="Tìm món theo tên"
        />
      </div>
      <div className="chip-row">
        <button className={`sb-chip${catFilter === 'all' ? ' selected' : ''}`} onClick={() => setCatFilter('all')}>
          Tất cả
        </button>
        {categories.map((c) => (
          <button
            key={c.id}
            className={`sb-chip${catFilter === c.id ? ' selected' : ''}`}
            onClick={() => setCatFilter(c.id)}
          >
            {c.name}
          </button>
        ))}
      </div>
      {warehouses.length > 1 && (
        <div className="chip-row">
          <button className={`sb-chip${whFilter === 'all' ? ' selected' : ''}`} onClick={() => setWhFilter('all')}>
            Mọi kho
          </button>
          {warehouses.map((w) => (
            <button key={w.id} className={`sb-chip${whFilter === w.id ? ' selected' : ''}`} onClick={() => setWhFilter(w.id)}>
              {w.name}
            </button>
          ))}
        </div>
      )}
      <div className="muted small" style={{ marginBottom: 4 }}>Số lượng: {visible.length}</div>
      {visible.length === 0 ? (
        <div className="sb-empty">
          <div className="eico">🍹</div>
          <p>{products.length === 0 ? 'Chưa có món nào. Bấm nút + để thêm món mới.' : 'Không tìm thấy món nào khớp.'}</p>
        </div>
      ) : (
        <div>
          {visible.map((p) => (
            <button
              key={p.id}
              className="sb-row"
              style={p.active ? undefined : { opacity: 0.5 }}
              onClick={() => setEditing(p)}
            >
              <span className="sb-thumb" aria-hidden>{p.name.trim().charAt(0).toUpperCase() || '?'}</span>
              <span className="rbody">
                <span className="rtitle">{p.name}</span>
                <span className="rsub">{catName(p.category_id)} · {p.active ? 'Đang bán' : 'Đang ẩn'}{p.track_stock ? ' · 📦 theo dõi tồn' : p.recipe.length > 0 ? ` · ${p.recipe.length} nguyên liệu` : ''}{p.barcode ? ` · Mã vạch: ${p.barcode}` : ''}{p.platform_price ? ` · Giá sàn: ${formatVND(p.platform_price)}` : ''}</span>
              </span>
              <span className="ramount">{formatVND(p.base_price)}{p.unit ? `/${p.unit}` : ''}</span>
              <span style={{ color: 'var(--muted)', fontSize: 24, flexShrink: 0 }} aria-hidden>›</span>
            </button>
          ))}
        </div>
      )}
      {editing && (
        <ProductForm product={editing === 'new' ? null : editing} products={products} categories={categories} ingredients={ingredients} warehouses={warehouses} modGroups={modGroups} onClose={() => setEditing(null)} reload={reload} />
      )}
      {bulkOpen && (
        <BulkAddSheet categories={categories} onClose={() => setBulkOpen(false)} reload={reload} />
      )}
      <button className="fab" onClick={() => setFabOpen(true)} aria-label="Thêm món mới">
        +
      </button>
      {fabOpen && (
        <Sheet title="Thêm món" onClose={() => setFabOpen(false)}>
          <button
            className="sb-menu-row"
            style={{ background: 'var(--surface)', borderRadius: 999, color: 'var(--brand-dark)', border: 'none', boxShadow: 'var(--shadow)', padding: '14px 18px', marginBottom: 10, fontWeight: 600 }}
            onClick={() => {
              setFabOpen(false);
              setEditing('new');
            }}
          >
            <span style={{ fontSize: 20 }}>➕</span> Tạo món mới <span className="chev">›</span>
          </button>
          <button
            className="sb-menu-row"
            style={{ background: 'var(--surface)', borderRadius: 999, color: 'var(--brand-dark)', border: 'none', boxShadow: 'var(--shadow)', padding: '14px 18px', fontWeight: 600 }}
            onClick={() => {
              setFabOpen(false);
              setBulkOpen(true);
            }}
          >
            <span style={{ fontSize: 20 }}>📋</span> Thêm món hàng loạt <span className="chev">›</span>
          </button>
        </Sheet>
      )}
    </>
  );
}

// Thêm nhiều món cùng lúc: mỗi dòng "Tên món | giá | tên danh mục (tùy chọn)".
function BulkAddSheet({ categories, onClose, reload }: { categories: Category[]; onClose: () => void; reload: () => Promise<void> }) {
  const toast = useToast();
  const [text, setText] = useState('');
  const [defaultCat, setDefaultCat] = useState(categories[0]?.id ?? '');
  const [busy, setBusy] = useState(false);

  const catByName = (name: string) => {
    const n = name.trim().toLowerCase();
    return categories.find((c) => c.name.trim().toLowerCase() === n) ?? null;
  };

  const parsed = text
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      const parts = line.split('|').map((s) => s.trim());
      const name = parts[0] ?? '';
      const price = parseInt((parts[1] ?? '').replace(/\D/g, ''), 10);
      const cat = parts[2] ? catByName(parts[2]) : null;
      const ok = !!name && Number.isFinite(price) && price > 0 && (parts[2] ? !!cat : true);
      return { line, name, price, cat, ok, err: !name ? 'thiếu tên' : !Number.isFinite(price) || price <= 0 ? 'giá không hợp lệ' : parts[2] && !cat ? `không có danh mục “${parts[2]}”` : '' };
    });
  const okCount = parsed.filter((p) => p.ok).length;

  const submit = async () => {
    if (okCount === 0) {
      toast.show('Chưa có dòng nào hợp lệ');
      return;
    }
    setBusy(true);
    try {
      const { added } = await createProductsBulk(
        parsed
          .filter((p) => p.ok)
          .map((p) => ({ name: p.name, base_price: p.price, category_id: p.cat ? p.cat.id : defaultCat || null })),
      );
      toast.show(`Đã thêm ${added} món`);
      await reload();
      onClose();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Thêm thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet
      title="Thêm món hàng loạt"
      onClose={onClose}
      footer={
        <button className="btn btn-block btn-lg" onClick={submit} disabled={busy || okCount === 0}>
          {busy ? 'Đang thêm…' : `Thêm ${okCount} món`}
        </button>
      }
    >
      <p className="small muted" style={{ marginTop: 0 }}>
        Mỗi dòng một món theo mẫu: <b>Tên món | giá | tên danh mục</b> (danh mục bỏ trống sẽ dùng danh mục mặc định bên dưới).
      </p>
      <div className="sb-float">
        <select value={defaultCat} onChange={(e) => setDefaultCat(e.target.value)} aria-label="Danh mục mặc định">
          {categories.map((c) => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </select>
        <label>Danh mục mặc định</label>
      </div>
      <div className="sb-float">
        <textarea
          rows={8}
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder={'Trà Sữa Truyền Thống | 32000 | Trà sữa\nCà Phê Sữa Đá | 25000\nBạc Xỉu | 29000 | Cà phê'}
          style={{ fontFamily: 'inherit' }}
        />
        <label>Danh sách món</label>
      </div>
      {parsed.length > 0 && (
        <div style={{ marginBottom: 12 }}>
          <div className="small muted" style={{ marginBottom: 4 }}>Xem trước: {okCount}/{parsed.length} dòng hợp lệ</div>
          {parsed.map((p, i) => (
            <div key={i} className="sb-row" style={{ opacity: p.ok ? 1 : 0.55 }}>
              <span className="rbody">
                <span className="rtitle">{p.name || <i>(trống)</i>}</span>
                <span className="rsub" style={p.ok ? undefined : { color: 'var(--red)' }}>
                  {p.ok ? (p.cat ? p.cat.name : 'Danh mục mặc định') : p.err}
                </span>
              </span>
              <span className="ramount" style={p.ok ? undefined : { color: 'var(--red)' }}>
                {Number.isFinite(p.price) && p.price > 0 ? formatVND(p.price) : '—'}
              </span>
            </div>
          ))}
        </div>
      )}
    </Sheet>
  );
}

const UNIT_SUGGESTIONS = ['Ly', 'Cái', 'Hộp', 'Phần', 'Chai', 'Túi'];

function ProductForm({ product, products, categories, ingredients, warehouses, modGroups, onClose, reload }: { product: Product | null; products: Product[]; categories: Category[]; ingredients: Ingredient[]; warehouses: Warehouse[]; modGroups: ModifierGroup[]; onClose: () => void; reload: () => Promise<void> }) {
  const toast = useToast();
  const [name, setName] = useState(product?.name ?? '');
  const nameRef = useRef<HTMLInputElement>(null);
  const [price, setPrice] = useState(product?.base_price ? String(product.base_price) : '');
  const [cost, setCost] = useState(product?.cost_price ? String(product.cost_price) : '');
  const [unit, setUnit] = useState(product?.unit ?? '');
  const [barcode, setBarcode] = useState(product?.barcode ?? '');
  // Giá sàn riêng (v6.34): để trống = tự tính giá quán +25% làm tròn lên 1.000đ.
  const [platformPrice, setPlatformPrice] = useState(
    product?.platform_price ? String(product.platform_price) : '',
  );
  const [catId, setCatId] = useState(product?.category_id ?? categories[0]?.id ?? '');
  const [active, setActive] = useState(product?.active ?? true);
  const [trackStock, setTrackStock] = useState(product?.track_stock ?? false);
  const [trackBusy, setTrackBusy] = useState(false);
  // Kho được bán món này — rỗng = mọi kho
  const [whIds, setWhIds] = useState<string[]>(product?.warehouse_ids ?? []);
  const toggleTrackStock = async (v: boolean) => {
    if (!product) {
      // Món mới: chỉ lưu ý định, áp dụng sau khi tạo
      setTrackStock(v);
      return;
    }
    setTrackBusy(true);
    try {
      await setProductStockTracking(product.id, v);
      setTrackStock(v);
      toast.show(v ? 'Đã bật theo dõi tồn kho ✅' : 'Đã tắt theo dõi tồn kho');
      await reload();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Đổi trạng thái thất bại');
    } finally {
      setTrackBusy(false);
    }
  };

  const toggleWh = (id: string) =>
    setWhIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  const [recipeItems, setRecipeItems] = useState<{ ingredient_id: string; qty: string }[]>(() =>
    (product?.recipe ?? []).map((r) => ({ ingredient_id: r.ingredient_id, qty: String(r.qty) })),
  );
  const [addIngId, setAddIngId] = useState('');
  const [busy, setBusy] = useState(false);
  const [costBusy, setCostBusy] = useState(false);
  const [tab, setTab] = useState<'info' | 'recipe'>('info');
  const [proOk, setProOk] = useState<boolean | null>(null);
  const [variantRecipes, setVariantRecipes] = useState<Record<string, { ingredient_id: string; qty: string }[]>>(() => {
    const out: Record<string, { ingredient_id: string; qty: string }[]> = {};
    for (const [optId, items] of Object.entries(product?.variant_recipes ?? {})) {
      out[optId] = items.map((r) => ({ ingredient_id: r.ingredient_id, qty: String(r.qty) }));
    }
    return out;
  });
  const [variantAddId, setVariantAddId] = useState<Record<string, string>>({});
  const [openVariant, setOpenVariant] = useState<string | null>(null);

  useEffect(() => {
    canUsePro().then(setProOk).catch(() => setProOk(true));
  }, []);

  /** Tính giá vốn từ giá nhập bình quân trong kho theo định lượng đã khai. */
  const calcCostFromStock = async () => {
    const entries = recipeItems
      .map((it) => ({ ingredient_id: it.ingredient_id, qty: parseFloat(String(it.qty).replace(',', '.')) }))
      .filter((r) => Number.isFinite(r.qty) && r.qty > 0);
    if (entries.length === 0) {
      toast.show('Khai định lượng nguyên liệu trước');
      return;
    }
    setCostBusy(true);
    try {
      const wid = await getDefaultWarehouseId();
      if (!wid) {
        toast.show('Chưa có kho nào');
        return;
      }
      const costs = await getIngredientAvgCosts(wid);
      let total = 0;
      let missing = 0;
      for (const e of entries) {
        const c = costs.get(e.ingredient_id);
        if (c) total += e.qty * c;
        else missing += 1;
      }
      if (total <= 0) {
        toast.show('Chưa có giá nhập nào trong kho — nhập kho kèm giá trước');
        return;
      }
      setCost(String(Math.round(total)));
      toast.show(
        `Giá vốn ước tính ${formatVND(Math.round(total))}` +
          (missing > 0 ? ` (${missing} NL chưa có giá nhập)` : ''),
      );
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Tính giá vốn thất bại');
    } finally {
      setCostBusy(false);
    }
  };

  const save = async (resetAfter: boolean) => {
    const p = parseInt(price.replace(/\D/g, ''), 10);
    const c = cost.trim() === '' ? 0 : parseInt(cost.replace(/\D/g, ''), 10);
    if (!name.trim() || Number.isNaN(p) || p <= 0) {
      toast.show('Nhập tên và giá bán hợp lệ');
      return;
    }
    if (Number.isNaN(c) || c < 0) {
      toast.show('Giá vốn không hợp lệ');
      return;
    }
    const recipe = recipeItems
      .map((it) => ({ ingredient_id: it.ingredient_id, qty: parseFloat(String(it.qty).replace(',', '.')) }))
      .filter((r) => Number.isFinite(r.qty) && r.qty > 0);
    // Định lượng theo biến thể (chỉ khi Pro)
    const vr: Record<string, RecipeItem[]> = {};
    if (proOk) {
      for (const [optId, items] of Object.entries(variantRecipes)) {
        const clean = items
          .map((it) => ({ ingredient_id: it.ingredient_id, qty: parseFloat(String(it.qty).replace(',', '.')) }))
          .filter((r) => Number.isFinite(r.qty) && r.qty > 0);
        if (clean.length > 0) vr[optId] = clean;
      }
    }
    // Ma vach (v6.29): moi ma chi dung cho 1 mon — trung thi bao loi, khong luu.
    const bc = normalizeBarcode(barcode);
    if (bc) {
      const owner = findBarcodeOwner(products, bc, product?.id);
      if (owner) {
        toast.show(`Mã vạch này đã dùng cho món “${owner.name}”`);
        return;
      }
    }
    // Giá sàn riêng (v6.34): để trống/0 = chưa nhập, bán sàn tự tính +25%.
    const pp = parseInt(platformPrice.replace(/\D/g, ''), 10);
    if (platformPrice.trim() !== '' && (Number.isNaN(pp) || pp < 0)) {
      toast.show('Giá sàn không hợp lệ');
      return;
    }
    setBusy(true);
    try {
      const payload = {
        name: name.trim(),
        base_price: p,
        cost_price: c,
        unit: unit.trim(),
        barcode: bc,
        platform_price: pp > 0 ? pp : null,
        recipe,
        variant_recipes: vr,
        category_id: catId || null,
        warehouse_ids: whIds,
      };
      if (product) {
        await updateProduct(product.id, { ...payload, active });
      } else {
        const created = await createProduct(payload);
        if (trackStock) {
          try {
            await setProductStockTracking(created.id, true);
          } catch {
            // bỏ qua lỗi phụ
          }
        }
      }
      toast.show(product ? 'Đã cập nhật món' : 'Đã thêm món');
      await reload();
      if (resetAfter) {
        setName('');
        setPrice('');
        setCost('');
        setUnit('');
        setBarcode('');
        setPlatformPrice('');
        setRecipeItems([]);
        setCatId(categories[0]?.id ?? '');
      } else {
        onClose();
      }
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  const toggleActive = async () => {
    if (!product) return;
    try {
      await updateProduct(product.id, { active: !active });
      setActive(!active);
      toast.show(active ? `Đã ẩn “${product.name}”` : `Đã hiện “${product.name}”`);
      await reload();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Thất bại');
    }
  };

  const remove = async () => {
    if (!product) return;
    if (!window.confirm(`Xóa hẳn món “${product.name}” khỏi menu?\nĐơn hàng cũ không bị ảnh hưởng.`)) return;
    try {
      await deleteProduct(product.id);
      toast.show(`Đã xóa “${product.name}”`);
      await reload();
      onClose();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Xóa thất bại');
    }
  };

  return (
    <Sheet
      title={product ? 'Sửa món' : 'Thêm món'}
      onClose={onClose}
      footer={
        <div style={{ display: 'grid', gridTemplateColumns: product ? '1fr' : 'repeat(2, 1fr)', gap: 8 }}>
          {!product && (
            <button type="button" className="btn btn-outline btn-lg" style={{ width: '100%' }} disabled={busy} onClick={() => save(true)}>
              Lưu và thêm mới
            </button>
          )}
          <button type="submit" form="product-form" className="btn btn-lg" style={{ width: '100%' }} disabled={busy}>
            {busy ? 'Đang lưu…' : 'Lưu'}
          </button>
        </div>
      }
    >
      <form id="product-form" onSubmit={(e) => { e.preventDefault(); void save(false); }}>
        <div className="row" style={{ gap: 8, marginBottom: 12 }}>
          <button
            type="button"
            className={`sb-chip${tab === 'info' ? ' selected' : ''}`}
            onClick={() => setTab('info')}
          >
            📝 Thông tin món
          </button>
          <button
            type="button"
            className={`sb-chip${tab === 'recipe' ? ' selected' : ''}`}
            onClick={() => setTab('recipe')}
          >
            ⚖️ Định lượng
          </button>
        </div>
        {tab === 'info' && (
          <>
        <div className="sb-float">
          <input
            ref={nameRef}
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="VD: Trà Sữa Truyền Thống"
            autoFocus={!product}
          />
          <label>Tên món <span className="req">*</span></label>
        </div>
        <div className="sb-float">
          <input
            inputMode="numeric"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            placeholder="VD: 32000"
          />
          <label>Giá bán (VND) <span className="req">*</span></label>
        </div>
        <div className="sb-float">
          <input
            inputMode="numeric"
            value={cost}
            onChange={(e) => setCost(e.target.value)}
            placeholder="VD: 12000 (để trống = 0)"
          />
          <label>Giá vốn (VND)</label>
        </div>
        <button
          type="button"
          className="btn btn-outline btn-block"
          style={{ marginBottom: 12, minHeight: 44 }}
          disabled={costBusy}
          onClick={calcCostFromStock}
        >
          {costBusy ? 'Đang tính…' : '🔄 Tính giá vốn từ kho'}
        </button>
        <div className="field">
          <label>Đơn vị</label>
          <div className="row" style={{ flexWrap: 'wrap', gap: 8, marginBottom: 8 }}>
            {UNIT_SUGGESTIONS.map((u) => (
              <button
                key={u}
                type="button"
                className={`sb-chip${unit === u ? ' selected' : ''}`}
                onClick={() => setUnit(u)}
              >
                {u}
              </button>
            ))}
          </div>
          <input
            className="input"
            value={unit}
            onChange={(e) => setUnit(e.target.value)}
            maxLength={20}
            placeholder="Hoặc nhập đơn vị khác…"
          />
        </div>
        <div className="sb-float">
          <input
            value={barcode}
            onChange={(e) => setBarcode(e.target.value)}
            onKeyDown={(e) => {
              // v6.35: súng bắn mã vạch gõ mã rồi Enter — chặn Enter gửi form
              // (kẻo form lưu khi chưa nhập tên/giá), nhảy con trỏ về ô Tên món.
              if (e.key === 'Enter') {
                e.preventDefault();
                nameRef.current?.focus();
              }
            }}
            placeholder="Bắn mã bằng súng quét hoặc nhập tay (VD: 8936000000000)"
            autoComplete="off"
            autoCapitalize="off"
            autoCorrect="off"
            spellCheck={false}
          />
          <label>Mã vạch (nếu có)</label>
        </div>
        <div className="sb-float">
          <input
            value={platformPrice}
            onChange={(e) => setPlatformPrice(e.target.value)}
            placeholder="VD: 25000 (để trống = tự tính giá quán +25%)"
            inputMode="numeric"
            autoComplete="off"
          />
          <label>Giá bán trên sàn (nếu có)</label>
        </div>
        <div className="sb-float">
          <select value={catId} onChange={(e) => setCatId(e.target.value)} aria-label="Danh mục">
            {categories.map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
          <label>Danh mục</label>
        </div>
        {warehouses.length > 1 && (
          <div style={{ marginTop: 12 }}>
            <div className="small muted" style={{ fontWeight: 600, marginBottom: 6 }}>
              Bán tại kho <span style={{ fontWeight: 400 }}>(không chọn = mọi kho)</span>
            </div>
            <div className="row" style={{ flexWrap: 'wrap', gap: 8 }}>
              {warehouses.map((w) => (
                <button
                  key={w.id}
                  type="button"
                  className={`sb-chip${whIds.includes(w.id) ? ' selected' : ''}`}
                  onClick={() => toggleWh(w.id)}
                >
                  {whIds.includes(w.id) ? '✓ ' : ''}{w.name}
                </button>
              ))}
            </div>
          </div>
        )}
          </>
        )}
        {tab === 'recipe' && (
          <>
        {ingredients.length > 0 ? (
          <>
            <div className="small muted" style={{ fontWeight: 600, margin: '16px 0 4px' }}>
              Định lượng nguyên liệu{' '}
              <span style={{ fontWeight: 400 }}>(cho 1 {unit.trim() || 'đơn vị'} món)</span>
            </div>
            <p className="small muted" style={{ margin: '0 0 8px' }}>
              Bán 1 món sẽ tự trừ kho theo định lượng này. Chỉ thêm nguyên liệu món này dùng.
            </p>
            {recipeItems.map((it, i) => {
              const ing = ingredients.find((x) => x.id === it.ingredient_id);
              if (!ing) return null;
              return (
                <div
                  key={it.ingredient_id}
                  className="row"
                  style={{ justifyContent: 'space-between', alignItems: 'center', marginBottom: 8, gap: 8 }}
                >
                  <span style={{ fontSize: 15, flex: 1 }}>
                    {ing.name} <span className="muted small">({ing.unit})</span>
                  </span>
                  <input
                    className="input"
                    style={{ width: 110, textAlign: 'right' }}
                    inputMode="decimal"
                    placeholder="0"
                    value={it.qty}
                    onChange={(e) =>
                      setRecipeItems((prev) => prev.map((x, j) => (j === i ? { ...x, qty: e.target.value } : x)))
                    }
                    aria-label={`Định lượng ${ing.name} (${ing.unit})`}
                  />
                  <button
                    type="button"
                    className="btn btn-ghost"
                    style={{ minHeight: 40, padding: '0 10px' }}
                    onClick={() => setRecipeItems((prev) => prev.filter((_, j) => j !== i))}
                    aria-label={`Xóa ${ing.name}`}
                  >
                    ✕
                  </button>
                </div>
              );
            })}
            {(() => {
              const used = new Set(recipeItems.map((it) => it.ingredient_id));
              const avail = ingredients.filter((x) => !used.has(x.id));
              if (avail.length === 0) return null;
              return (
                <div className="row" style={{ gap: 8, marginTop: 4 }}>
                  <select
                    className="input"
                    style={{ flex: 1 }}
                    value={addIngId}
                    onChange={(e) => setAddIngId(e.target.value)}
                    aria-label="Chọn nguyên liệu để thêm"
                  >
                    <option value="">— Thêm nguyên liệu… —</option>
                    {avail.map((x) => (
                      <option key={x.id} value={x.id}>
                        {x.name} ({x.unit})
                      </option>
                    ))}
                  </select>
                  <button
                    type="button"
                    className="btn btn-outline"
                    disabled={!addIngId}
                    onClick={() => {
                      if (!addIngId) return;
                      setRecipeItems((prev) => [...prev, { ingredient_id: addIngId, qty: '' }]);
                      setAddIngId('');
                    }}
                  >
                    ＋ Thêm
                  </button>
                </div>
              );
            })()}
          </>
        ) : (
          <p className="small muted" style={{ margin: '16px 0 8px' }}>
            💡 Thêm nguyên liệu ở màn <b>Tồn kho</b> rồi quay lại đây để khai định lượng cho món.
          </p>
        )}
        {/* Định lượng theo biến thể (Pro) */}
        <div className="small muted" style={{ fontWeight: 600, margin: '20px 0 4px' }}>
          ⚖️ Định lượng theo biến thể{' '}
          <span className="sb-chip" style={{ minHeight: 24, fontSize: 11, marginLeft: 4 }}>PRO</span>
        </div>
        {proOk === false ? (
          <div className="card" style={{ textAlign: 'center', padding: '20px 12px', marginBottom: 8 }}>
            <div style={{ fontSize: 32 }}>🔒</div>
            <p className="small muted" style={{ margin: '8px 0 0' }}>
              Tính năng Pro — mở <b>Cài đặt → Giấy phép sử dụng</b> để kích hoạt.
            </p>
          </div>
        ) : (
          <>
            <p className="small muted" style={{ margin: '0 0 8px' }}>
              VD: size 360ml dùng ít nguyên liệu hơn size 500ml. Khi bán, kho trừ theo đúng biến thể khách chọn.
              Không đặt thì dùng định lượng mặc định ở trên.
            </p>
            {modGroups.filter((g) => g.active).map((g) => {
              const opts = (g.options ?? []).filter((o) => o.active !== false);
              if (opts.length === 0) return null;
              return (
                <div key={g.id} className="sb-section" style={{ marginBottom: 8 }}>
                  <div style={{ fontWeight: 600, marginBottom: 6 }}>📦 {g.name}</div>
                  {opts.map((o) => {
                    const items = variantRecipes[o.id] ?? [];
                    const hasCustom = items.length > 0;
                    const open = openVariant === o.id;
                    const usedIds = new Set(items.map((it) => it.ingredient_id));
                    const avail = ingredients.filter((x) => !usedIds.has(x.id));
                    return (
                      <div key={o.id} style={{ marginBottom: 6, borderTop: '1px solid var(--border)', paddingTop: 6 }}>
                        <button
                          type="button"
                          className="row"
                          style={{ width: '100%', justifyContent: 'space-between', background: 'none', border: 'none', padding: '4px 0', cursor: 'pointer' }}
                          onClick={() => setOpenVariant(open ? null : o.id)}
                        >
                          <span style={{ fontSize: 14 }}>
                            {o.name}
                            {hasCustom && <span className="small" style={{ color: 'var(--green)', marginLeft: 6 }}>✓ đã đặt riêng</span>}
                          </span>
                          <span className="muted">{open ? '▾' : '▸'}</span>
                        </button>
                        {open && (
                          <div style={{ padding: '4px 0 4px 12px' }}>
                            {items.map((it, ii) => {
                              const ing = ingredients.find((x) => x.id === it.ingredient_id);
                              if (!ing) return null;
                              return (
                                <div key={it.ingredient_id} className="row" style={{ justifyContent: 'space-between', alignItems: 'center', marginBottom: 6, gap: 8 }}>
                                  <span style={{ fontSize: 13, flex: 1 }}>
                                    {ing.name} <span className="muted small">({ing.unit})</span>
                                  </span>
                                  <input
                                    className="input"
                                    style={{ width: 90, textAlign: 'right' }}
                                    inputMode="decimal"
                                    placeholder="0"
                                    value={it.qty}
                                    onChange={(e) =>
                                      setVariantRecipes((prev) => ({
                                        ...prev,
                                        [o.id]: (prev[o.id] ?? []).map((x, j) => (j === ii ? { ...x, qty: e.target.value } : x)),
                                      }))
                                    }
                                    aria-label={`Định lượng ${ing.name} cho ${o.name}`}
                                  />
                                  <button
                                    type="button"
                                    className="btn btn-ghost"
                                    style={{ minHeight: 36, padding: '0 8px' }}
                                    onClick={() =>
                                      setVariantRecipes((prev) => ({
                                        ...prev,
                                        [o.id]: (prev[o.id] ?? []).filter((_, j) => j !== ii),
                                      }))
                                    }
                                    aria-label={`Xóa ${ing.name}`}
                                  >
                                    ✕
                                  </button>
                                </div>
                              );
                            })}
                            {avail.length > 0 && (
                              <div className="row" style={{ gap: 6, marginTop: 4 }}>
                                <select
                                  className="input"
                                  style={{ flex: 1, fontSize: 13 }}
                                  value={variantAddId[o.id] ?? ''}
                                  onChange={(e) => setVariantAddId((prev) => ({ ...prev, [o.id]: e.target.value }))}
                                  aria-label="Chọn nguyên liệu để thêm"
                                >
                                  <option value="">— Thêm nguyên liệu… —</option>
                                  {avail.map((x) => (
                                    <option key={x.id} value={x.id}>
                                      {x.name} ({x.unit})
                                    </option>
                                  ))}
                                </select>
                                <button
                                  type="button"
                                  className="btn btn-outline"
                                  style={{ minHeight: 36 }}
                                  disabled={!(variantAddId[o.id] ?? '')}
                                  onClick={() => {
                                    const nid = variantAddId[o.id] ?? '';
                                    if (!nid) return;
                                    setVariantRecipes((prev) => ({
                                      ...prev,
                                      [o.id]: [...(prev[o.id] ?? []), { ingredient_id: nid, qty: '' }],
                                    }));
                                    setVariantAddId((prev) => ({ ...prev, [o.id]: '' }));
                                  }}
                                >
                                  ＋
                                </button>
                              </div>
                            )}
                            {hasCustom && (
                              <button
                                type="button"
                                className="sb-chip"
                                style={{ minHeight: 32, marginTop: 6 }}
                                onClick={() =>
                                  setVariantRecipes((prev) => {
                                    const next = { ...prev };
                                    delete next[o.id];
                                    return next;
                                  })
                                }
                              >
                                <TIcon emoji="🗑️" size={14} /> Xóa định lượng riêng (dùng mặc định)
                              </button>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              );
            })}
          </>
        )}
          </>
        )}
        {product && (
          <>
            <div className="row" style={{ marginBottom: 16 }}>
              <span className="grow" style={{ fontWeight: 600, fontSize: 15 }}>Đang bán</span>
              <label className="switch" aria-label="Đang bán">
                <input type="checkbox" checked={active} onChange={(e) => setActive(e.target.checked)} />
                <span className="track" />
              </label>
            </div>
            <div className="row" style={{ marginBottom: 8 }}>
              <span className="grow" style={{ fontWeight: 600, fontSize: 15 }}>
                📦 Theo dõi tồn kho
                <span className="small muted" style={{ display: 'block', fontWeight: 400 }}>
                  Hàng nhập về bán trực tiếp (không qua sơ chế)
                </span>
              </span>
              <label className="switch" aria-label="Theo dõi tồn kho">
                <input
                  type="checkbox"
                  checked={trackStock}
                  disabled={trackBusy}
                  onChange={(e) => void toggleTrackStock(e.target.checked)}
                />
                <span className="track" />
              </label>
            </div>
            {trackStock && product?.stock_ingredient_id && (
              <p className="small muted" style={{ marginBottom: 16 }}>
                Món này đang trừ tồn kho trực tiếp khi bán. Nhập/xuất hàng trong mục Tồn kho như nguyên liệu.
              </p>
            )}
            <div className="row" style={{ marginBottom: 8 }}>
              <button type="button" className="btn btn-outline grow" onClick={toggleActive}>
                {active ? 'Ẩn món' : 'Hiện món'}
              </button>
              <button type="button" className="btn btn-ghost grow" style={{}} onClick={remove}>
                Xóa món
              </button>
            </div>
          </>
        )}
      </form>
    </Sheet>
  );
}

/* ---------------- Danh mục ---------------- */
function CategoriesTab({ categories, products, reload }: { categories: Category[]; products: Product[]; reload: () => Promise<void> }) {
  const toast = useToast();
  const [name, setName] = useState('');
  const [query, setQuery] = useState('');
  const [busy, setBusy] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');

  const count = (id: string) => products.filter((p) => p.category_id === id).length;
  const needle = unsignVietnamese(query.trim()).toLowerCase();
  const visible = needle ? categories.filter((c) => unsignVietnamese(c.name).toLowerCase().includes(needle)) : categories;

  const add = async (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    setBusy(true);
    try {
      await createCategory(name.trim());
      setName('');
      toast.show('Đã thêm danh mục');
      await reload();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Thêm thất bại');
    } finally {
      setBusy(false);
    }
  };

  const toggle = async (c: Category) => {
    try {
      await updateCategory(c.id, { active: !c.active });
      await reload();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Thất bại');
    }
  };

  const saveEdit = async (c: Category) => {
    if (!editName.trim()) {
      toast.show('Tên danh mục không được để trống');
      return;
    }
    try {
      await updateCategory(c.id, { name: editName.trim() });
      setEditingId(null);
      toast.show('Đã đổi tên danh mục');
      await reload();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Lưu thất bại');
    }
  };

  const remove = async (c: Category) => {
    if (!window.confirm(`Xóa danh mục “${c.name}”?\nCác món trong danh mục sẽ chuyển sang “chưa phân loại” (không bị mất).`)) return;
    try {
      const { moved } = await deleteCategory(c.id);
      toast.show(moved > 0 ? `Đã xóa danh mục, chuyển ${moved} món sang chưa phân loại` : 'Đã xóa danh mục');
      await reload();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Xóa thất bại');
    }
  };

  // Đổi thứ tự danh mục thủ công: hoán đổi vị trí rồi gán lại sort_order
  // 0,1,2... cho toàn bộ danh sách để thứ tự liền mạch, không trùng số cũ.
  const move = async (c: Category, dir: -1 | 1) => {
    const idx = categories.findIndex((x) => x.id === c.id);
    const j = idx + dir;
    if (idx < 0 || j < 0 || j >= categories.length) return;
    const next = [...categories];
    [next[idx], next[j]] = [next[j], next[idx]];
    try {
      await Promise.all(
        next.map((cat, i) =>
          cat.sort_order !== i ? updateCategory(cat.id, { sort_order: i }) : Promise.resolve(),
        ),
      );
      await reload();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Đổi thứ tự thất bại');
    }
  };

  return (
    <>
      <form onSubmit={add} className="row" style={{ marginBottom: 12 }}>
        <input className="input grow" placeholder="Tên danh mục mới…" value={name} onChange={(e) => setName(e.target.value)} />
        <button className="btn" disabled={busy}>Thêm</button>
      </form>
      <p className="small muted" style={{ marginTop: 0, marginBottom: 10 }}>
        Dùng nút mũi tên lên/xuống ở mỗi dòng để sắp xếp thứ tự danh mục — thứ tự này áp dụng ở màn Bán hàng.
      </p>
      <div className="sb-search" style={{ marginBottom: 10 }}>
        <span className="sico" aria-hidden><TIcon emoji="🔍" size={18} /></span>
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Tìm danh mục theo tên…"
          aria-label="Tìm danh mục theo tên"
        />
      </div>
      {categories.length === 0 ? (
        <div className="sb-empty">
          <div className="eico">📂</div>
          <p>Chưa có danh mục nào.</p>
        </div>
      ) : visible.length === 0 ? (
        <div className="sb-empty">
          <div className="eico">🔍</div>
          <p>Không tìm thấy danh mục phù hợp.</p>
        </div>
      ) : (
        <div>
          {visible.map((c, idx) => (
            <div key={c.id} className="sb-row" style={c.active ? undefined : { opacity: 0.5 }}>
              {editingId === c.id ? (
                <>
                  <span className="rbody">
                    <input
                      className="input"
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      autoFocus
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') void saveEdit(c);
                        if (e.key === 'Escape') setEditingId(null);
                      }}
                    />
                  </span>
                  <button className="btn" style={{ minHeight: 44, padding: '8px 16px' }} onClick={() => saveEdit(c)}>Lưu</button>
                  <button className="btn btn-ghost" style={{ minHeight: 44, padding: '8px 16px' }} onClick={() => setEditingId(null)}>Hủy</button>
                </>
              ) : (
                <>
                  <span className="rbody">
                    <span className="rtitle">{c.name}</span>
                    <span className="rsub">{count(c.id)} món{c.active ? '' : ' · Đang ẩn'}</span>
                  </span>
                  {!needle && (
                    <>
                      <button
                        className="btn btn-ghost"
                        style={{ minHeight: 44, padding: '8px 10px' }}
                        disabled={idx === 0}
                        onClick={() => void move(c, -1)}
                        aria-label={`Đưa danh mục ${c.name} lên`}
                      >
                        ▲
                      </button>
                      <button
                        className="btn btn-ghost"
                        style={{ minHeight: 44, padding: '8px 10px' }}
                        disabled={idx === categories.length - 1}
                        onClick={() => void move(c, 1)}
                        aria-label={`Đưa danh mục ${c.name} xuống`}
                      >
                        ▼
                      </button>
                    </>
                  )}
                  <button
                    className="btn btn-ghost"
                    style={{ minHeight: 44, padding: '8px 16px' }}
                    onClick={() => { setEditingId(c.id); setEditName(c.name); }}
                  >
                    Sửa
                  </button>
                  <button
                    className="btn btn-outline"
                    style={{ minHeight: 44, padding: '8px 16px' }}
                    onClick={() => toggle(c)}
                  >
                    {c.active ? 'Ẩn' : 'Hiện'}
                  </button>
                  <button
                    className="btn btn-ghost"
                    style={{ minHeight: 44, padding: '8px 16px' }}
                    onClick={() => remove(c)}
                    aria-label={`Xóa danh mục ${c.name}`}
                  >
                    🗑️
                  </button>
                </>
              )}
            </div>
          ))}
        </div>
      )}
    </>
  );
}

/* ---------------- Topping ---------------- */
function ModifiersTab({ groups, reload }: { groups: ModifierGroup[]; reload: () => Promise<void> }) {
  const toast = useToast();
  const [newOpt, setNewOpt] = useState<{ groupId: string; name: string; delta: string; platformDelta: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editDelta, setEditDelta] = useState('');
  // Phụ thu riêng khi bán trên sàn (v6.34): để trống = dùng phụ thu quán.
  const [editPlatformDelta, setEditPlatformDelta] = useState('');

  const toggleOpt = async (optId: string, active: boolean) => {
    try {
      await updateModifierOption(optId, { active: !active });
      await reload();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Thất bại');
    }
  };

  const addOpt = async (e: FormEvent) => {
    e.preventDefault();
    if (!newOpt || !newOpt.name.trim()) return;
    const delta = parseInt(newOpt.delta.replace(/\D/g, ''), 10) || 0;
    const pdelta = parseInt(newOpt.platformDelta.replace(/\D/g, ''), 10);
    setBusy(true);
    try {
      await createModifierOption(newOpt.groupId, {
        name: newOpt.name.trim(),
        price_delta: delta,
        platform_price_delta: Number.isFinite(pdelta) && pdelta > 0 ? pdelta : null,
      });
      toast.show('Đã thêm tùy chọn');
      setNewOpt(null);
      await reload();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Thêm thất bại');
    } finally {
      setBusy(false);
    }
  };

  const saveEdit = async (optId: string) => {
    const delta = parseInt(editDelta.replace(/\D/g, ''), 10);
    if (!editName.trim() || Number.isNaN(delta) || delta < 0) {
      toast.show('Nhập tên và phụ thu hợp lệ (≥ 0)');
      return;
    }
    const pdelta = parseInt(editPlatformDelta.replace(/\D/g, ''), 10);
    if (editPlatformDelta.trim() !== '' && (Number.isNaN(pdelta) || pdelta < 0)) {
      toast.show('Phụ thu sàn không hợp lệ');
      return;
    }
    try {
      await updateModifierOption(optId, {
        name: editName.trim(),
        price_delta: delta,
        platform_price_delta: Number.isFinite(pdelta) && pdelta > 0 ? pdelta : null,
      });
      setEditingId(null);
      toast.show('Đã lưu');
      await reload();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Lưu thất bại');
    }
  };

  const removeOpt = async (name: string, optId: string) => {
    if (!window.confirm(`Xóa hẳn “${name}”?\nĐơn hàng cũ không bị ảnh hưởng.`)) return;
    try {
      await deleteModifierOption(optId);
      toast.show(`Đã xóa “${name}”`);
      await reload();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Xóa thất bại');
    }
  };

  if (groups.length === 0) {
    return (
      <div className="sb-empty">
        <div className="eico">🧋</div>
        <p>Chưa có nhóm topping nào.</p>
      </div>
    );
  }

  return (
    <>
      {groups.map((g) => (
        <div className="sb-section" key={g.id}>
          <div className="row" style={{ marginBottom: 4 }}>
            <div className="grow">
              <b style={{ fontSize: 16 }}>{g.name}</b>
              <div className="small muted">
                {g.selection_type === 'single' ? 'Chọn 1' : 'Chọn nhiều'}{g.required ? ' · Bắt buộc' : ''}
              </div>
            </div>
            <button className="btn btn-ghost btn-sm" onClick={() => setNewOpt({ groupId: g.id, name: '', delta: '', platformDelta: '' })}>
              <TIcon emoji="➕" size={14} /> Thêm
            </button>
          </div>
          <div>
            {[...g.options].sort((a, b) => a.sort_order - b.sort_order).map((o) => (
              <div key={o.id} className="sb-row" style={{ opacity: o.active ? 1 : 0.5 }}>
                {editingId === o.id ? (
                  <>
                    <span className="rbody" style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                      <input
                        className="input"
                        style={{ minWidth: 0, flex: '1 1 120px' }}
                        value={editName}
                        onChange={(e) => setEditName(e.target.value)}
                        placeholder="Tên"
                        autoFocus
                      />
                      <input
                        className="input"
                        style={{ width: 110 }}
                        inputMode="numeric"
                        value={editDelta}
                        onChange={(e) => setEditDelta(e.target.value)}
                        placeholder="+giá"
                      />
                      <input
                        className="input"
                        style={{ width: 110 }}
                        inputMode="numeric"
                        value={editPlatformDelta}
                        onChange={(e) => setEditPlatformDelta(e.target.value)}
                        placeholder="+giá sàn"
                      />
                    </span>
                    <button className="btn btn-sm" onClick={() => saveEdit(o.id)}>Lưu</button>
                    <button className="btn btn-ghost btn-sm" onClick={() => setEditingId(null)}>Hủy</button>
                  </>
                ) : (
                  <>
                    <span className="rbody">
                      <span className="rtitle">{o.name}</span>
                      <span className="rsub">
                        {o.price_delta > 0 ? `+${formatVND(o.price_delta)}` : 'Miễn phí'}
                        {o.platform_price_delta != null && o.platform_price_delta > 0
                          ? ` · Sàn +${formatVND(o.platform_price_delta)}`
                          : ''}
                        {o.active ? '' : ' · Đang ẩn'}
                      </span>
                    </span>
                    <button className="btn btn-ghost btn-sm" onClick={() => { setEditingId(o.id); setEditName(o.name); setEditDelta(String(o.price_delta)); setEditPlatformDelta(o.platform_price_delta ? String(o.platform_price_delta) : ''); }}>
                      Sửa
                    </button>
                    <button className="btn btn-outline btn-sm" onClick={() => toggleOpt(o.id, o.active)}>
                      {o.active ? 'Ẩn' : 'Hiện'}
                    </button>
                    <button className="btn btn-ghost btn-sm" style={{}} onClick={() => removeOpt(o.name, o.id)} aria-label={`Xóa ${o.name}`}>
                      🗑️
                    </button>
                  </>
                )}
              </div>
            ))}
          </div>
          {newOpt?.groupId === g.id && (
            <form onSubmit={addOpt} style={{ marginTop: 12 }}>
              <div className="sb-float">
                <input
                  value={newOpt.name}
                  onChange={(e) => setNewOpt({ ...newOpt, name: e.target.value })}
                  placeholder="VD: Trân châu đen"
                  autoFocus
                />
                <label>Tên lựa chọn</label>
              </div>
              <div className="sb-float">
                <input
                  inputMode="numeric"
                  value={newOpt.delta}
                  onChange={(e) => setNewOpt({ ...newOpt, delta: e.target.value })}
                  placeholder="VD: 8000"
                />
                <label>Phụ thu (VND)</label>
              </div>
              <div className="sb-float">
                <input
                  inputMode="numeric"
                  value={newOpt.platformDelta}
                  onChange={(e) => setNewOpt({ ...newOpt, platformDelta: e.target.value })}
                  placeholder="VD: 10000 (để trống = dùng phụ thu quán)"
                />
                <label>Phụ thu trên sàn (VND)</label>
              </div>
              <div className="row">
                <button className="btn grow" disabled={busy}>Lưu</button>
                <button type="button" className="btn btn-ghost" onClick={() => setNewOpt(null)}>Hủy</button>
              </div>
            </form>
          )}
        </div>
      ))}
    </>
  );
}
