// Tồn kho multi-kho — quản lý nguyên liệu theo từng kho: nhập/xuất, chuyển kho,
// cảnh báo sắp hết, lịch sử. Bán 1 món tự trừ kho đang chọn ở POS.
import { useCallback, useEffect, useRef, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import {
  DbError,
  applyStockCheck,
  createIngredient,
  createWarehouse,
  deleteIngredient,
  deleteProductionOrder,
  ensureWarehousesSeeded,
  getDefaultWarehouseId,
  getMyProfile,
  listIngredients,
  listProductionOrders,
  listAllStockLogs,
  listWarehouseStock,
  listWarehouses,
  produceSemiFinished,
  setDefaultWarehouse,
  transferStock,
  updateIngredient,
  updateIngredientProductionRecipe,
  updateWarehouse,
} from '../lib/db';

import {
  addDaysVN,
  formatDMY,
  formatTime,
  formatVND,
  startOfMonthVN,
  startOfWeekVN,
  todayVN,
  unsignVietnamese,
} from '../lib/format';
import { ledgerValueTotals, summarizeLedger } from '../lib/stock-ledger';
import { PageHead } from '../components/PageHead';
import { LineIcon } from '../components/LineIcon';
import { Sheet } from '../components/Sheet';
import './pc-inventory.css';
import { TIcon } from '../components/TIcon';
import { useToast } from '../components/Toast';
import { useAuth } from '../lib/auth';
import type { Ingredient, IngredientWithStock, ProductionOrder, StockLog, Warehouse } from '../lib/types';
import { findBarcodeOwner, normalizeBarcode } from '../lib/barcode';

const UNIT_SUGGESTIONS = ['g', 'kg', 'ml', 'lít', 'cái', 'hộp', 'túi', 'gói'];
const LS_WID = 'beesy_warehouse_id';

/** Hiển thị số lượng gọn: bỏ số 0 thừa do float (VD 0.30000000004 → 0.3). */
function formatQty(v: number): string {
  const n = parseFloat(v.toFixed(3));
  return n.toLocaleString('vi-VN', { maximumFractionDigits: 3 });
}

/** Hook phát hiện màn hình PC (>= 1024px), theo mẫu Reports.tsx. */
function useIsPC(): boolean {
  const [isPC, setIsPC] = useState(() => typeof window !== 'undefined' && window.innerWidth >= 1024);
  useEffect(() => {
    const onResize = () => setIsPC(window.innerWidth >= 1024);
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);
  return isPC;
}

export function Inventory() {
  const toast = useToast();
  const { can } = useAuth();
  const canManage = can('inventory.manage');
  const isOwner = can('cashbook.settings');
  const [searchParams] = useSearchParams();
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [wid, setWid] = useState('');
  const [tab, setTab] = useState<'stock' | 'ledger' | 'check' | 'transfer' | 'production' | 'warehouses'>(() => {
    const t = searchParams.get('tab');
    return t === 'production' || t === 'ledger' || t === 'check' || t === 'transfer' || t === 'warehouses'
      ? t
      : 'stock';
  });
  const [items, setItems] = useState<IngredientWithStock[]>([]);
  const [query, setQuery] = useState('');
  const [busy, setBusy] = useState(true);
  const [noAccess, setNoAccess] = useState(false);
  const [formIng, setFormIng] = useState<Ingredient | 'new' | null>(null);
  const [produceIng, setProduceIng] = useState<IngredientWithStock | null>(null);
  // Nhanh PC: goi vo dieu kien o dau component, truoc moi early return.
  const isPC = useIsPC();
  const navigate = useNavigate();
  // PC: tab "Ban thanh pham" la bo loc tren cung bang ton kho (chi cac
  // nguyen lieu co production_recipe), khong phai tab rieng cua code cu.
  const [pcSemiOnly, setPcSemiOnly] = useState(false);

  const load = useCallback(
    async (focusWid?: string) => {
      setBusy(true);
      try {
        const me = await getMyProfile();
        const privileged = me.role === 'owner'; // CHỈ chủ quán thấy mọi kho
        let ws = await listWarehouses();
        if (privileged && ws.length === 0) {
          ws = await ensureWarehousesSeeded();
          toast.show('Đã tạo kho mặc định "Kho quầy"');
        }
        const allowed = privileged ? ws : ws.filter((w) => me.warehouse_ids.includes(w.id));
        setWarehouses(allowed);
        if (allowed.length === 0) {
          setNoAccess(true);
          setBusy(false);
          return;
        }
        setNoAccess(false);
        const saved = localStorage.getItem(LS_WID);
        const def = await getDefaultWarehouseId();
        const pick =
          focusWid && allowed.some((w) => w.id === focusWid)
            ? focusWid
            : saved && allowed.some((w) => w.id === saved)
              ? saved
              : def && allowed.some((w) => w.id === def)
                ? def
                : allowed[0].id;
        setWid(pick);
        localStorage.setItem(LS_WID, pick);
        // Tải tồn kho và lịch sử ĐỘC LẬP: lịch sử lỗi (VD: index đang build)
        // không được làm mất danh sách nguyên liệu.
        let stock: IngredientWithStock[] = [];
        try {
          stock = await listWarehouseStock(pick);
        } catch (e) {
          toast.show(e instanceof DbError ? e.message : 'Không tải được tồn kho');
        }
        setItems(stock);
      } catch (e) {
        toast.show(e instanceof DbError ? e.message : 'Không tải được tồn kho');
      } finally {
        setBusy(false);
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    },
    [],
  );

  useEffect(() => {
    void load();
  }, [load]);

  if (!busy && !noAccess && !can('inventory')) {
    return (
      <div className="page">
        <PageHead title="Tồn kho" />
        <div className="card">🔒 Chỉ Quản lý trở lên mới được quản lý tồn kho.</div>
      </div>
    );
  }

  if (noAccess && !busy) {
    return (
      <div className="page">
        <PageHead title="Tồn kho" />
        <div className="card">🔒 Tài khoản chưa được gán kho nào. Nhờ chủ quán vào Cài đặt → Nhân viên để gán kho.</div>
      </div>
    );
  }

  const lowCount = items.filter((i) => i.active && i.alert_enabled && i.stock <= i.min_stock).length;
  const needle = unsignVietnamese(query.trim()).toLowerCase();
  const visibleItems = needle ? items.filter((i) => unsignVietnamese(i.name).toLowerCase().includes(needle)) : items;
  const curWarehouse = warehouses.find((w) => w.id === wid);

  // ---------------- Nhanh PC (chi hien khi >= 1024px) ----------------
  // Dung chung state/loader/handler/pham vi kho cua code cu; chi khac JSX.
  // Dat sau early return phan quyen nen ca 2 nhanh deu ton trong phan quyen.
  const pcIsLow = (ing: IngredientWithStock) =>
    ing.active && ing.alert_enabled && ing.stock <= ing.min_stock;
  const pcIsUrgent = (ing: IngredientWithStock) =>
    pcIsLow(ing) && ing.min_stock > 0 && ing.stock < ing.min_stock * 0.5;
  const pcStatus = (ing: IngredientWithStock): { label: string; color: string } => {
    if (!ing.active) return { label: 'Đang ẩn', color: '#8A919C' };
    if (pcIsUrgent(ing)) return { label: 'Cần nhập gấp', color: '#DC2626' };
    if (pcIsLow(ing)) return { label: 'Sắp hết', color: '#D97706' };
    return { label: 'Đủ', color: '#16A34A' };
  };
  const pcSemis = items.filter((i) => i.production_recipe && i.production_recipe.length > 0);
  const pcBase = pcSemiOnly ? pcSemis : items;
  const pcActive = pcBase.filter((i) => i.active);
  const pcVisible = needle
    ? pcBase.filter((i) => unsignVietnamese(i.name).toLowerCase().includes(needle))
    : pcBase;
  const pcUrgent = pcActive.filter(pcIsUrgent);
  const pcLowOnly = pcActive.filter((i) => pcIsLow(i) && !pcIsUrgent(i));
  const pcOk = pcActive.filter((i) => !pcIsLow(i));
  const pcLowItems = pcActive
    .filter(pcIsLow)
    .sort((a, b) => {
      const ra = a.min_stock > 0 ? a.stock / a.min_stock : 1;
      const rb = b.min_stock > 0 ? b.stock / b.min_stock : 1;
      return ra - rb;
    });
  const pcGoTab = (t: typeof tab, semi: boolean) => {
    setTab(t);
    setPcSemiOnly(semi);
  };
  if (isPC) {
    return (
      <div className="page pc-inventory-page">
        <PageHead title="Tồn kho" />
        <p className="pc-inventory-sub">
          Theo dõi tồn kho nguyên liệu theo từng kho, cảnh báo khi sắp hết để kịp nhập hàng.
          {curWarehouse ? ` Kho đang xem: ${curWarehouse.name}.` : ''}
        </p>

        {warehouses.length > 1 && (
          <div className="pc-inventory-chips" role="group" aria-label="Chọn kho">
            {warehouses.map((w) => (
              <button
                key={w.id}
                type="button"
                className={`pc-inventory-chip${wid === w.id ? ' active' : ''}`}
                title={w.name}
                onClick={() => void load(w.id)}
              >
                {w.name}
                {w.is_default ? ' (mặc định)' : ''}
              </button>
            ))}
          </div>
        )}

        <div className="pc-inventory-tabs" role="tablist" aria-label="Tab tồn kho">
          <button type="button" className={`pc-inventory-tab${tab === 'stock' && !pcSemiOnly ? ' active' : ''}`} onClick={() => pcGoTab('stock', false)}>
            Nguyên liệu
          </button>
          <button type="button" className={`pc-inventory-tab${tab === 'stock' && pcSemiOnly ? ' active' : ''}`} onClick={() => pcGoTab('stock', true)}>
            Bán thành phẩm
          </button>
          <button type="button" className={`pc-inventory-tab${tab === 'ledger' ? ' active' : ''}`} onClick={() => pcGoTab('ledger', false)}>
            Sổ kho
          </button>
          <button type="button" className={`pc-inventory-tab${tab === 'check' ? ' active' : ''}`} onClick={() => pcGoTab('check', false)}>
            Kiểm kho
          </button>
          <button type="button" className={`pc-inventory-tab${tab === 'transfer' ? ' active' : ''}`} onClick={() => pcGoTab('transfer', false)}>
            Chuyển kho
          </button>
          {canManage && (
            <button type="button" className={`pc-inventory-tab${tab === 'production' ? ' active' : ''}`} onClick={() => pcGoTab('production', false)}>
              Sản xuất
            </button>
          )}
          {canManage && (
            <button type="button" className={`pc-inventory-tab${tab === 'warehouses' ? ' active' : ''}`} onClick={() => pcGoTab('warehouses', false)}>
              Kho
            </button>
          )}
        </div>

        {busy ? (
          <div className="card">Đang tải…</div>
        ) : tab === 'stock' ? (
          <>
            <div className="pc-inventory-stats">
              <div className="pc-inventory-stat">
                <div className="pc-inventory-stat-label">
                  {pcSemiOnly ? 'Bán thành phẩm' : 'Tổng nguyên liệu'}
                </div>
                <div className="pc-inventory-stat-value">{pcActive.length}</div>
                <div className="pc-inventory-stat-sub">
                  Đang theo dõi{curWarehouse ? ` tại ${curWarehouse.name}` : ''}
                </div>
              </div>
              <div className="pc-inventory-stat">
                <div className="pc-inventory-stat-label">Cần nhập gấp</div>
                <div className="pc-inventory-stat-value" style={{ color: pcUrgent.length > 0 ? '#DC2626' : undefined }}>
                  {pcUrgent.length}
                </div>
                <div className="pc-inventory-stat-sub">Dưới 50% mức tối thiểu</div>
              </div>
              <div className="pc-inventory-stat">
                <div className="pc-inventory-stat-label">Sắp hết</div>
                <div className="pc-inventory-stat-value" style={{ color: pcLowOnly.length > 0 ? '#B45309' : undefined }}>
                  {pcLowOnly.length}
                </div>
                <div className="pc-inventory-stat-sub">Dưới mức tối thiểu</div>
              </div>
              <div className="pc-inventory-stat">
                <div className="pc-inventory-stat-label">Đủ hàng</div>
                <div className="pc-inventory-stat-value" style={{ color: '#15803D' }}>{pcOk.length}</div>
                <div className="pc-inventory-stat-sub">Trên mức tối thiểu</div>
              </div>
            </div>

            <div className="pc-inventory-toolbar">
              <label className="pc-inventory-search">
                <LineIcon name="search" size={18} />
                <input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Tìm nguyên liệu theo tên…"
                  aria-label="Tìm nguyên liệu theo tên"
                />
              </label>
              {canManage && (
                <button className="btn" onClick={() => setFormIng('new')}>
                  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                    <LineIcon name="plus" size={18} /> Thêm nguyên liệu
                  </span>
                </button>
              )}
            </div>

            <div className="pc-inventory-layout">
              <section className="pc-inventory-table-card">
                {items.length === 0 ? (
                  <div className="pc-inventory-empty">
                    Chưa có nguyên liệu nào. Bấm “Thêm nguyên liệu” để thêm nguyên liệu đầu tiên.
                  </div>
                ) : pcVisible.length === 0 ? (
                  <div className="pc-inventory-empty">Không tìm thấy nguyên liệu phù hợp.</div>
                ) : (
                  <div className="pc-inventory-table-wrap">
                    <table className="pc-inventory-table">
                      <thead>
                        <tr>
                          <th>Nguyên liệu</th>
                          <th>Đơn vị</th>
                          <th className="num">Tồn kho</th>
                          <th className="num">Tối thiểu</th>
                          <th>Trạng thái</th>
                          <th>Kho</th>
                          <th>Thao tác</th>
                        </tr>
                      </thead>
                      <tbody>
                        {pcVisible.map((ing) => {
                          const st = pcStatus(ing);
                          const rowCls = pcIsUrgent(ing)
                            ? 'pc-inventory-row-urgent'
                            : pcIsLow(ing)
                              ? 'pc-inventory-row-low'
                              : '';
                          return (
                            <tr key={ing.id} className={rowCls} style={{ opacity: ing.active ? 1 : 0.55 }}>
                              <td>
                                <div className="pc-inventory-name" title={ing.name}>
                                  {ing.name}
                                  {ing.is_product_stock && <span className="pc-inventory-pill">Hàng hóa</span>}
                                  {ing.production_recipe && ing.production_recipe.length > 0 && (
                                    <span className="pc-inventory-pill">Bán thành phẩm</span>
                                  )}
                                  {!ing.active && <span className="pc-inventory-pill">Đang ẩn</span>}
                                </div>
                                <div className="pc-inventory-subline">
                                  {ing.cost_per_unit > 0
                                    ? `Giá vốn: ${formatVND(ing.cost_per_unit)}/${ing.unit}`
                                    : 'Chưa có giá vốn'}
                                </div>
                              </td>
                              <td>{ing.unit}</td>
                              <td className="num">
                                <b style={{ color: pcIsLow(ing) ? '#F97316' : '#15803D' }}>
                                  {formatQty(ing.stock)}
                                </b>
                              </td>
                              <td className="num">{formatQty(ing.min_stock)}</td>
                              <td>
                                <span className="pc-inventory-status">
                                  <span className="pc-inventory-dot" style={{ background: st.color }} />
                                  {st.label}
                                </span>
                              </td>
                              <td title={curWarehouse?.name ?? ''}>{curWarehouse?.name ?? '—'}</td>
                              <td>
                                <div className="pc-inventory-actions">
                                  {canManage && ing.production_recipe && ing.production_recipe.length > 0 && (
                                    <button type="button" className="btn btn-outline" onClick={() => setProduceIng(ing)}>
                                      SX
                                    </button>
                                  )}
                                  {canManage && (
                                    <button type="button" className="btn btn-ghost" onClick={() => setFormIng(ing)}>
                                      Sửa
                                    </button>
                                  )}
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
                <div className="pc-inventory-subline" style={{ marginTop: 12 }}>
                  Hiển thị {pcVisible.length} / {pcBase.length} {pcSemiOnly ? 'bán thành phẩm' : 'nguyên liệu'}
                  {curWarehouse ? ` tại ${curWarehouse.name}` : ''}
                </div>
              </section>

              <div className="pc-inventory-side">
                <section className="pc-inventory-panel">
                  <h3>
                    <span style={{ color: '#B45309', display: 'inline-flex' }}>
                      <LineIcon name="alert" size={20} />
                    </span>
                    Cảnh báo sắp hết
                  </h3>
                  {pcLowItems.length === 0 ? (
                    <p className="pc-inventory-subline" style={{ margin: 0 }}>
                      Không có nguyên liệu nào dưới ngưỡng.
                    </p>
                  ) : (
                    <>
                      {pcLowItems.map((ing) => (
                        <div key={ing.id} className="pc-inventory-warn-item">
                          <b title={ing.name}>{ing.name}</b>
                          <span>
                            Còn {formatQty(ing.stock)} {ing.unit} / tối thiểu {formatQty(ing.min_stock)} {ing.unit}
                            {curWarehouse ? ` - ${curWarehouse.name}` : ''}
                          </span>
                        </div>
                      ))}
                      <div style={{ marginTop: 14 }}>
                        <button className="btn btn-block" onClick={() => navigate('/nhap-hang')}>
                          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                            <LineIcon name="plus" size={18} /> Tạo phiếu nhập
                          </span>
                        </button>
                      </div>
                    </>
                  )}
                </section>

                <section className="pc-inventory-panel">
                  <h3>
                    <span style={{ display: 'inline-flex' }}>
                      <LineIcon name="archive" size={20} />
                    </span>
                    Theo kho
                  </h3>
                  {warehouses.map((w) => {
                    const isCur = w.id === wid;
                    return (
                      <div key={w.id} className="pc-inventory-kho-row">
                        <span title={w.name}>
                          {w.name}
                          {w.is_default ? ' (mặc định)' : ''}
                        </span>
                        {isCur ? (
                          <span>
                            <b>{pcActive.length}</b> <span className="muted">nguyên liệu</span>
                            {lowCount > 0 && (
                              <>
                                {' · '}
                                <b>{lowCount}</b> <span className="muted">cần kiểm tra lại</span>
                              </>
                            )}
                          </span>
                        ) : (
                          <button type="button" className="btn btn-ghost" onClick={() => void load(w.id)}>
                            Xem kho này
                          </button>
                        )}
                      </div>
                    );
                  })}
                  <p className="pc-inventory-subline" style={{ margin: '12px 0 0', lineHeight: 1.5 }}>
                    Tồn kho chỉ tải cho kho đang chọn, nên số liệu chi tiết hiện cho kho đó.
                    Bán 1 món ở POS sẽ tự trừ kho đang chọn. Nhập hàng xong, tồn kho và cảnh báo
                    cập nhật ngay.
                  </p>
                </section>
              </div>
            </div>
          </>
        ) : (
          <div className="pc-inventory-single">
            {tab === 'transfer' ? (
              <TransferForm warehouses={warehouses} fromWid={wid} items={items} onDone={() => void load()} />
            ) : tab === 'production' ? (
              <ProductionTab
                warehouseId={wid}
                warehouseName={curWarehouse?.name ?? ''}
                items={items}
                isOwner={isOwner}
                onDone={() => void load()}
              />
            ) : tab === 'ledger' ? (
              <LedgerTab warehouseId={wid} warehouseName={curWarehouse?.name ?? ''} items={items} />
            ) : tab === 'check' ? (
              <CheckTab warehouseId={wid} warehouseName={curWarehouse?.name ?? ''} items={items} onDone={() => void load()} />
            ) : (
              <WarehouseManager onChanged={() => void load()} />
            )}
          </div>
        )}

        {produceIng && (
          <ProduceSheet
            ingredient={produceIng}
            items={items}
            warehouseId={wid}
            warehouseName={curWarehouse?.name ?? ''}
            onClose={() => setProduceIng(null)}
            onDone={() => {
              setProduceIng(null);
              void load();
            }}
          />
        )}

        {formIng && (
          <IngredientForm
            ingredient={formIng === 'new' ? null : formIng}
            ingredients={items}
            warehouseId={wid}
            warehouseName={curWarehouse?.name ?? ''}
            onClose={() => setFormIng(null)}
            onDone={() => {
              setFormIng(null);
              void load();
            }}
          />
        )}
      </div>
    );
  }

  return (
    <div className="page">
      <PageHead title="Tồn kho" />

      {warehouses.length > 1 && (
        <div className="row" style={{ gap: 8, marginBottom: 12, flexWrap: 'wrap' }}>
          {warehouses.map((w) => (
            <button
              key={w.id}
              type="button"
              className={`sb-chip${wid === w.id ? ' selected' : ''}`}
              style={{ minHeight: 36, padding: '4px 12px', fontSize: 13 }}
              onClick={() => void load(w.id)}
            >
              🗃️ {w.name}
              {w.is_default ? ' ★' : ''}
            </button>
          ))}
        </div>
      )}

      <div className="sb-tabs">
        <button className={`sb-tab${tab === 'stock' ? ' active' : ''}`} onClick={() => setTab('stock')}>
          Nguyên liệu
        </button>
        <button className={`sb-tab${tab === 'ledger' ? ' active' : ''}`} onClick={() => setTab('ledger')}>
          Sổ kho
        </button>
        <button className={`sb-tab${tab === 'check' ? ' active' : ''}`} onClick={() => setTab('check')}>
          Kiểm kho
        </button>
        <button className={`sb-tab${tab === 'transfer' ? ' active' : ''}`} onClick={() => setTab('transfer')}>
          Chuyển kho
        </button>
        {canManage && (
          <button className={`sb-tab${tab === 'production' ? ' active' : ''}`} onClick={() => setTab('production')}>
            🧪 Sản xuất
          </button>
        )}
        {canManage && (
          <button className={`sb-tab${tab === 'warehouses' ? ' active' : ''}`} onClick={() => setTab('warehouses')}>
            Kho
          </button>
        )}
      </div>

      {busy ? (
        <div className="card">Đang tải…</div>
      ) : tab === 'stock' ? (
        <>
          <div className="row" style={{ gap: 12, marginBottom: 12 }}>
            <div className="card pastel-blue grow" style={{ boxShadow: 'none' }}>
              <div className="small muted">Nguyên liệu{curWarehouse ? ` · ${curWarehouse.name}` : ''}</div>
              <div className="money" style={{ fontSize: 22 }}>{items.filter((i) => i.active).length}</div>
            </div>
            <div className="card pastel-yellow grow" style={{ boxShadow: 'none' }}>
              <div className="small muted">Sắp hết / hết</div>
              <div className={`money ${lowCount > 0 ? 'text-orange' : ''}`} style={{ fontSize: 22 }}>
                {lowCount}
              </div>
            </div>
          </div>

          <div className="sb-search" style={{ marginBottom: 12 }}>
            <span className="sico" aria-hidden><TIcon emoji="🔍" size={18} /></span>
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Tìm nguyên liệu theo tên…"
              aria-label="Tìm nguyên liệu theo tên"
            />
          </div>

          {canManage && (
            <div className="row only-desktop" style={{ marginBottom: 12 }}>
              <button className="btn" onClick={() => setFormIng('new')}>
                ＋ Thêm nguyên liệu
              </button>
            </div>
          )}

          {items.length === 0 ? (
            <div className="sb-empty">
              <div className="eico">🗃️</div>
              <p>Chưa có nguyên liệu nào.<br />Bấm + để thêm nguyên liệu đầu tiên.</p>
            </div>
          ) : visibleItems.length === 0 ? (
            <div className="sb-empty">
              <div className="eico">🔍</div>
              <p>Không tìm thấy nguyên liệu phù hợp.</p>
            </div>
          ) : (
            <div className="sb-section" style={{ padding: '4px 16px' }}>
              {visibleItems.map((ing) => {
                const low = ing.alert_enabled && ing.stock <= ing.min_stock;
                return (
                  <div key={ing.id} className="sb-row" style={{ cursor: 'default', opacity: ing.active ? 1 : 0.55 }}>
                    <span className="rbody">
                      <span className="rtitle" style={{ fontWeight: 600 }}>
                        {ing.is_product_stock && <span style={{ marginRight: 4 }}>📦</span>}
                        {ing.name}
                        {ing.is_product_stock && (
                          <span className="sb-status-pill" style={{ marginLeft: 6, fontSize: 11 }}>Hàng hóa</span>
                        )}
                        {ing.production_recipe && ing.production_recipe.length > 0 && (
                          <span className="sb-status-pill" style={{ marginLeft: 6, fontSize: 11, background: 'var(--pastel-purple, #f0e6ff)' }}>🧪 Bán thành phẩm</span>
                        )}
                        {!ing.active && (
                          <span className="sb-status-pill" style={{ marginLeft: 6, fontSize: 11 }}>Đang ẩn</span>
                        )}
                      </span>
                      <span className="rsub">
                        Tối thiểu: {formatQty(ing.min_stock)} {ing.unit}
                        {ing.cost_per_unit > 0 && <> · {formatVND(ing.cost_per_unit)}/{ing.unit}</>}
                        {low && <span style={{ color: 'var(--orange)', fontWeight: 700 }}> · sắp hết!</span>}
                      </span>
                    </span>
                    <span className="row" style={{ gap: 6, alignItems: 'center', flex: '0 0 auto' }}>
                      <span className="rbody" style={{ alignItems: 'flex-end' }}>
                        <span className={`ramount ${low ? 'text-orange' : 'text-green'}`}>{formatQty(ing.stock)}</span>
                        <span className="rsub">{ing.unit}</span>
                      </span>
                      {canManage && ing.production_recipe && ing.production_recipe.length > 0 && (
                        <button
                          type="button"
                          className="sb-chip"
                          style={{ borderColor: 'var(--brand)', color: 'var(--brand-dark)' }}
                          onClick={() => setProduceIng(ing)}
                        >
                          🧪 SX
                        </button>
                      )}
                      {canManage && (
                        <button type="button" className="sb-chip" onClick={() => setFormIng(ing)}>
                          Sửa
                        </button>
                      )}
                    </span>
                  </div>
                );
              })}
            </div>
          )}

          {canManage && (
            <button className="fab" onClick={() => setFormIng('new')} aria-label="Thêm nguyên liệu">
              +
            </button>
          )}
        </>
      ) : tab === 'transfer' ? (
        <TransferForm
          warehouses={warehouses}
          fromWid={wid}
          items={items}
          onDone={() => void load()}
        />
      ) : tab === 'production' ? (
        <ProductionTab
          warehouseId={wid}
          warehouseName={curWarehouse?.name ?? ''}
          items={items}
          isOwner={isOwner}
          onDone={() => void load()}
        />
      ) : tab === 'ledger' ? (
        <LedgerTab warehouseId={wid} warehouseName={curWarehouse?.name ?? ''} items={items} />
      ) : tab === 'check' ? (
        <CheckTab warehouseId={wid} warehouseName={curWarehouse?.name ?? ''} items={items} onDone={() => void load()} />
      ) : (
        <WarehouseManager onChanged={() => void load()} />
      )}

      {produceIng && (
        <ProduceSheet
          ingredient={produceIng}
          items={items}
          warehouseId={wid}
          warehouseName={curWarehouse?.name ?? ''}
          onClose={() => setProduceIng(null)}
          onDone={() => {
            setProduceIng(null);
            void load();
          }}
        />
      )}

      {formIng && (
        <IngredientForm
          ingredient={formIng === 'new' ? null : formIng}
          ingredients={items}
          warehouseId={wid}
          warehouseName={curWarehouse?.name ?? ''}
          onClose={() => setFormIng(null)}
          onDone={() => {
            setFormIng(null);
            void load();
          }}
        />
      )}

    </div>
  );
}

type LedgerFilterKey = 'today' | 'yesterday' | 'week' | 'lastweek' | 'month' | 'lastmonth' | 'custom';
const LEDGER_FILTERS: { key: LedgerFilterKey; label: string }[] = [
  { key: 'today', label: 'Hôm nay' },
  { key: 'yesterday', label: 'Hôm qua' },
  { key: 'week', label: 'Tuần này' },
  { key: 'lastweek', label: 'Tuần trước' },
  { key: 'month', label: 'Tháng này' },
  { key: 'lastmonth', label: 'Tháng trước' },
  { key: 'custom', label: 'Tùy chọn' },
];

/** Sổ kho: tổng hợp tồn đầu/nhập/xuất/tồn cuối theo kỳ + lịch sử giao dịch. */
// ------------------------------------------------------------- sản xuất ---
/** Tab lịch sử phiếu sản xuất bán thành phẩm. */
function ProductionTab({
  warehouseId,
  warehouseName,
  items,
  isOwner,
  onDone,
}: {
  warehouseId: string;
  warehouseName: string;
  items: IngredientWithStock[];
  isOwner: boolean;
  onDone: () => void;
}) {
  const toast = useToast();
  const [orders, setOrders] = useState<ProductionOrder[]>([]);
  const [busy, setBusy] = useState(true);
  const [produceIng, setProduceIng] = useState<IngredientWithStock | null>(null);
  const [confirmDel, setConfirmDel] = useState<string | null>(null);

  const semis = items.filter((i) => i.active && i.production_recipe && i.production_recipe.length > 0);

  const load = useCallback(async () => {
    setBusy(true);
    try {
      setOrders(await listProductionOrders(100));
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tải được phiếu sản xuất');
    } finally {
      setBusy(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [warehouseId]);

  useEffect(() => {
    void load();
  }, [load]);

  const del = async (id: string) => {
    try {
      await deleteProductionOrder(id);
      toast.show('Đã xóa phiếu sản xuất (đã hoàn tác tồn kho)');
      setConfirmDel(null);
      void load();
      onDone();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Xóa thất bại');
    }
  };

  return (
    <>
      {semis.length > 0 ? (
        <div className="field">
          <label>Sản xuất bán thành phẩm tại {warehouseName || 'kho đang chọn'}</label>
          <div className="row" style={{ flexWrap: 'wrap', gap: 8 }}>
            {semis.map((sm) => (
              <button key={sm.id} type="button" className="sb-chip" onClick={() => setProduceIng(sm)}>
                🧪 {sm.name}
              </button>
            ))}
          </div>
        </div>
      ) : (
        <div className="card" style={{ marginBottom: 12 }}>
          <p className="small muted" style={{ margin: 0 }}>
            Chưa có bán thành phẩm nào. Vào tab <b>Nguyên liệu</b> → <b>Sửa</b> nguyên liệu → thêm
            <b> 🧪 Công thức sản xuất</b> để bắt đầu.
          </p>
        </div>
      )}

      <div className="small muted" style={{ marginBottom: 8, fontWeight: 700 }}>
        Lịch sử sản xuất ({orders.length})
      </div>
      {busy ? (
        <div className="card">Đang tải…</div>
      ) : orders.length === 0 ? (
        <div className="sb-empty">
          <div className="eico">🧪</div>
          <p>Chưa có phiếu sản xuất nào.</p>
        </div>
      ) : (
        <div className="sb-section" style={{ padding: '4px 16px' }}>
          {orders.map((o) => (
            <div key={o.id} className="sb-row" style={{ cursor: 'default', paddingRight: isOwner ? 42 : undefined, position: 'relative' }}>
              <span className="rbody">
                <span className="rtitle" style={{ fontWeight: 700 }}>
                  {o.code} <span className="rsub">· {o.business_date}</span>
                </span>
                <span className="rsub">
                  🧪 {formatQty(o.qty_produced)} {o.product_unit} {o.product_name} · {o.warehouse_name}
                </span>
                <span className="rsub">
                  Dùng: {o.ingredients_used.map((u) => `${u.ingredient_name} ${formatQty(u.qty)}${u.unit}`).join(' · ')}
                </span>
                {o.note && <span className="rsub">📝 {o.note}</span>}
              </span>
              {isOwner &&
                (confirmDel === o.id ? (
                  <span className="row" style={{ gap: 6, position: 'absolute', right: 8, top: 8 }}>
                    <button type="button" className="sb-chip" onClick={() => void del(o.id)}>
                      Xóa
                    </button>
                    <button type="button" className="sb-chip" onClick={() => setConfirmDel(null)}>
                      Hủy
                    </button>
                  </span>
                ) : (
                  <button
                    type="button"
                    className="sb-row-del"
                    aria-label={`Xóa ${o.code}`}
                    onClick={() => setConfirmDel(o.id)}
                  >
                    ×
                  </button>
                ))}
            </div>
          ))}
        </div>
      )}

      {produceIng && (
        <ProduceSheet
          ingredient={produceIng}
          items={items}
          warehouseId={warehouseId}
          warehouseName={warehouseName}
          onClose={() => setProduceIng(null)}
          onDone={() => {
            setProduceIng(null);
            void load();
            onDone();
          }}
        />
      )}
    </>
  );
}

/** Sheet sản xuất: nhập số lượng → xem nguyên liệu thô sẽ trừ → xác nhận. */
function ProduceSheet({
  ingredient,
  items,
  warehouseId,
  warehouseName,
  onClose,
  onDone,
}: {
  ingredient: IngredientWithStock;
  items: IngredientWithStock[];
  warehouseId: string;
  warehouseName: string;
  onClose: () => void;
  onDone: () => void;
}) {
  const toast = useToast();
  const [qty, setQty] = useState('');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);

  const num = (v: string) => parseFloat(String(v).replace(',', '.'));
  const q = num(qty);
  const recipe = ingredient.production_recipe ?? [];
  const batchQty = ingredient.production_batch_qty && ingredient.production_batch_qty > 0 ? ingredient.production_batch_qty : 1;

  const needs = recipe.map((r) => {
    const raw = items.find((i) => i.id === r.ingredient_id);
    const needQty = Number.isFinite(q) && q > 0 ? (r.qty * q) / batchQty : 0;
    return {
      ingredient_id: r.ingredient_id,
      name: raw?.name ?? 'Nguyên liệu?',
      unit: raw?.unit ?? '',
      perUnit: r.qty,
      needQty,
      stock: raw?.stock ?? 0,
      ok: (raw?.stock ?? 0) >= needQty,
    };
  });
  const allOk = Number.isFinite(q) && q > 0 && needs.every((n) => n.ok) && needs.length > 0;

  const confirm = async () => {
    if (!Number.isFinite(q) || q <= 0) {
      toast.show('Nhập số lượng cần sản xuất');
      return;
    }
    const lacking = needs.filter((n) => !n.ok);
    if (lacking.length > 0) {
      toast.show(`Không đủ: ${lacking.map((n) => n.name).join(', ')}`);
      return;
    }
    setBusy(true);
    try {
      const po = await produceSemiFinished({
        ingredientId: ingredient.id,
        qty: q,
        warehouseId,
        note: note.trim() || null,
      });
      toast.show(`Đã sản xuất ${formatQty(po.qty_produced)} ${po.product_unit} ${po.product_name} (${po.code})`);
      onDone();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Sản xuất thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet
      title={`🧪 Sản xuất ${ingredient.name}`}
      onClose={onClose}
      footer={
        <button className="btn btn-block btn-lg" disabled={busy || !allOk} onClick={confirm}>
          {busy ? 'Đang sản xuất…' : `Xác nhận sản xuất`}
        </button>
      }
    >
      <p className="small muted" style={{ marginTop: 0 }}>
        Kho: <b>{warehouseName}</b> · Tồn hiện tại: <b>{formatQty(ingredient.stock)} {ingredient.unit}</b>
      </p>
      <div className="field">
        <label>Số lượng cần làm ({ingredient.unit}) *</label>
        <input
          className="input"
          inputMode="decimal"
          value={qty}
          onChange={(e) => setQty(e.target.value)}
          placeholder={`VD: 1000`}
          autoFocus
        />
      </div>
      {needs.length > 0 && (
        <div className="field">
          <label>Nguyên liệu thô sẽ trừ</label>
          <div className="card" style={{ padding: '8px 12px' }}>
            {needs.map((n) => (
              <div key={n.ingredient_id} className="row" style={{ padding: '6px 0', borderBottom: '1px solid var(--line)' }}>
                <span className="grow">
                  {n.ok ? '✅' : '❌'} {n.name}
                  <span className="small muted">
                    {' '}({formatQty(n.perUnit)} {n.unit}/mẻ {formatQty(batchQty)} {ingredient.unit})
                  </span>
                </span>
                <span style={{ fontWeight: 700, color: n.ok ? undefined : 'var(--red)' }}>
                  {formatQty(n.needQty)} {n.unit}
                </span>
                <span className="small muted">/ còn {formatQty(n.stock)}</span>
              </div>
            ))}
          </div>
        </div>
      )}
      <div className="field">
        <label>Ghi chú</label>
        <input
          className="input"
          value={note}
          onChange={(e) => setNote(e.target.value)}
          maxLength={500}
          placeholder="VD: làm mẻ kem muối chiều"
        />
      </div>
    </Sheet>
  );
}

/** YYYY-MM-DD theo giờ VN từ chuỗi ISO — log lúc 02:00 giờ VN phải rơi vào đúng ngày VN đó, không phải ngày UTC. */
function vnDateKey(iso: string): string {
  try {
    return new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Ho_Chi_Minh',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    }).format(new Date(iso));
  } catch {
    return (iso || '').slice(0, 10);
  }
}

function LedgerTab({
  warehouseId,
  warehouseName,
  items,
}: {
  warehouseId: string;
  warehouseName: string;
  items: IngredientWithStock[];
}) {
  const toast = useToast();
  const [logs, setLogs] = useState<StockLog[]>([]);
  const [busy, setBusy] = useState(true);
  const [filter, setFilter] = useState<LedgerFilterKey>('month');
  const [customFrom, setCustomFrom] = useState(() => todayVN());
  const [customTo, setCustomTo] = useState(() => todayVN());

  const load = useCallback(async () => {
    if (!warehouseId) return;
    setBusy(true);
    try {
      // SUA 25/10/2026: tai TOAN BO log (phan trang) thay vi cat 500 roi
      // moi loc ky — So kho ky qua khu can ca log trong ky va sau ky.
      const lg = await listAllStockLogs(warehouseId);
      setLogs(lg);
    } catch (err) {
      toast.show(err instanceof DbError ? err.message : 'Không tải được sổ kho');
    } finally {
      setBusy(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [warehouseId]);

  useEffect(() => {
    void load();
  }, [load]);

  const t = todayVN();
  const [rangeFrom, rangeTo] = (() => {
    switch (filter) {
      case 'today':
        return [t, t];
      case 'yesterday': {
        const y = addDaysVN(t, -1);
        return [y, y];
      }
      case 'week':
        return [startOfWeekVN(t), t];
      case 'lastweek': {
        const mondayThis = startOfWeekVN(t);
        const mondayLast = addDaysVN(mondayThis, -7);
        return [mondayLast, addDaysVN(mondayLast, 6)];
      }
      case 'month':
        return [startOfMonthVN(t), t];
      case 'lastmonth': {
        const firstThis = startOfMonthVN(t);
        const lastPrev = addDaysVN(firstThis, -1);
        return [startOfMonthVN(lastPrev), lastPrev];
      }
      case 'custom':
        return [customFrom <= customTo ? customFrom : customTo, customFrom <= customTo ? customTo : customFrom];
    }
  })();

  // Log trong kỳ + log SAU kỳ (de tinh nguoc ton cuoi ky, sua 25/10/2026).
  // Ngay lay theo gio VN (vnDateKey), khong cat chuoi UTC nhu truoc.
  const inRange = logs.filter((l) => {
    const k = vnDateKey(l.created_at);
    return k >= rangeFrom && k <= rangeTo;
  });
  const afterRange = logs.filter((l) => vnDateKey(l.created_at) > rangeTo);

  // Nhóm log theo ngày
  const grouped = new Map<string, StockLog[]>();
  for (const l of inRange) {
    const k = vnDateKey(l.created_at);
    if (!grouped.has(k)) grouped.set(k, []);
    grouped.get(k)!.push(l);
  }
  const dates = [...grouped.keys()].sort().reverse();

  // Tổng hợp theo từng nguyên liệu: tồn đầu/nhập/xuất/tồn cuối (theo đơn vị
  // riêng) + giá trị theo giá vốn bình quân hiện tại — hàm thuần ở
  // lib/stock-ledger (đã kiểm chứng bằng fixture).
  const productSummaries = summarizeLedger(
    items.map((i) => ({
      ingredient_id: i.id,
      ingredient_name: i.name,
      unit: i.unit,
      current_stock: i.stock,
      cost_per_unit: i.cost_per_unit,
    })),
    inRange.map((l) => ({
      ingredient_id: l.ingredient_id,
      ingredient_name: l.ingredient_name,
      change: l.change,
      balance_after: l.balance_after,
      created_at: l.created_at,
    })),
    afterRange.map((l) => ({
      ingredient_id: l.ingredient_id,
      ingredient_name: l.ingredient_name,
      change: l.change,
      balance_after: l.balance_after,
      created_at: l.created_at,
    })),
  );
  const valueTotals = ledgerValueTotals(productSummaries);

  const dateLabel = (ymd: string) => {
    const d = new Date(ymd + 'T00:00:00');
    const wd = d.toLocaleDateString('vi-VN', { weekday: 'long' });
    const [, m, day] = ymd.split('-');
    return `${wd.charAt(0).toUpperCase() + wd.slice(1)}, ${day}/${m}`;
  };

  return (
    <>
      <div className="row" style={{ gap: 8, marginBottom: 12 }}>
        <select
          className="input"
          style={{ flex: 1, minWidth: 0 }}
          value={filter}
          onChange={(e) => setFilter(e.target.value as LedgerFilterKey)}
          aria-label="Lọc theo thời gian"
        >
          {LEDGER_FILTERS.map((f) => (
            <option key={f.key} value={f.key}>
              {f.label}
            </option>
          ))}
        </select>
      </div>
      {filter === 'custom' && (
        <div className="row" style={{ gap: 8, marginBottom: 12, alignItems: 'center' }}>
          <input type="date" className="input" style={{ flex: 1 }} value={customFrom} max={customTo} onChange={(e) => e.target.value && setCustomFrom(e.target.value)} aria-label="Từ ngày" />
          <span className="small muted">→</span>
          <input type="date" className="input" style={{ flex: 1 }} value={customTo} min={customFrom} onChange={(e) => e.target.value && setCustomTo(e.target.value)} aria-label="Đến ngày" />
        </div>
      )}

      <div className="sb-section" style={{ marginBottom: 12, padding: '12px 16px' }}>
        <div className="small muted" style={{ marginBottom: 8 }}>
          {warehouseName} · {formatDMY(rangeFrom)} → {formatDMY(rangeTo)}
        </div>
        <div className="small" style={{ fontWeight: 700, marginBottom: 4 }}>
          Tồn đầu → Nhập → Xuất → Tồn cuối (theo đơn vị từng món)
        </div>
        {productSummaries.length === 0 ? (
          <p className="small muted">Chưa có biến động nào trong kỳ.</p>
        ) : (
          <>
            {productSummaries.map((ps) => (
              <div key={ps.ingredient_id} className="row" style={{ justifyContent: 'space-between', padding: '6px 0', borderTop: '1px solid var(--line)' }}>
                <span>
                  <span style={{ fontWeight: 600 }}>{ps.ingredient_name}</span>
                  <span className="small muted" style={{ display: 'block' }}>
                    Đầu: {formatQty(ps.opening)} · Nhập: <span className="text-green">+{formatQty(ps.importQty)}</span> · Xuất:{' '}
                    <span className="text-orange">-{formatQty(ps.exportQty)}</span>
                  </span>
                  <span className="small muted" style={{ display: 'block' }}>
                    Giá trị — Đầu: {formatVND(ps.openingValue)} · Nhập: {formatVND(ps.importValue)} · Xuất: {formatVND(ps.exportValue)}
                  </span>
                </span>
                <span style={{ textAlign: 'right' }}>
                  <b className="money" style={{ fontSize: 16 }}>
                    {formatQty(ps.closing)}
                  </b>
                  <span className="small muted" style={{ display: 'block' }}>{ps.unit}</span>
                  <span className="small" style={{ display: 'block', fontWeight: 600 }}>{formatVND(ps.closingValue)}</span>
                </span>
              </div>
            ))}
            <div className="row" style={{ justifyContent: 'space-between', padding: '8px 0 2px', borderTop: '2px solid var(--line)', marginTop: 2 }}>
              <span style={{ fontWeight: 700 }}>Tổng giá trị</span>
              <span className="small" style={{ textAlign: 'right' }}>
                Đầu: <b>{formatVND(valueTotals.openingValue)}</b> · Nhập: <b>{formatVND(valueTotals.importValue)}</b> · Xuất:{' '}
                <b>{formatVND(valueTotals.exportValue)}</b> · Cuối: <b className="money">{formatVND(valueTotals.closingValue)}</b>
              </span>
            </div>
            <p className="small muted" style={{ margin: '6px 0 0' }}>
              Giá trị = số lượng × giá vốn bình quân hiện tại của từng nguyên liệu (cùng một cơ sở giá cho cả kỳ).
            </p>
          </>
        )}
      </div>

      {busy ? (
        <div className="card">Đang tải…</div>
      ) : dates.length === 0 ? (
        <div className="sb-empty">
          <div className="eico">📜</div>
          <p>Chưa có giao dịch nào trong kỳ.</p>
        </div>
      ) : (
        dates.map((d) => (
          <div key={d} style={{ marginBottom: 12 }}>
            <div className="small muted" style={{ padding: '6px 4px', fontWeight: 600 }}>
              {dateLabel(d)}
            </div>
            <div className="sb-section" style={{ padding: '4px 16px' }}>
              {grouped.get(d)!.map((l) => (
                <div key={l.id} className="sb-row" style={{ cursor: 'default' }}>
                  <span
                    className="avatar"
                    style={
                      l.change > 0
                        ? { background: 'var(--green-bg)', color: 'var(--brand-dark)' }
                        : { background: 'var(--orange-bg)', color: 'var(--orange)' }
                    }
                  >
                    {l.change > 0 ? '↓' : '↑'}
                  </span>
                  <span className="rbody">
                    <span className="rtitle" style={{ fontWeight: 600 }}>
                      {l.ingredient_name}
                    </span>
                    <span className="rsub">
                      {l.note ? `${l.note} · ` : ''}
                      {formatTime(l.created_at)}
                    </span>
                  </span>
                  <span style={{ textAlign: 'right' }}>
                    <span className={`ramount ${l.change > 0 ? 'text-green' : 'text-orange'}`}>
                      {l.change > 0 ? '+' : ''}
                      {formatQty(l.change)}
                    </span>
                    <span className="small muted" style={{ display: 'block' }}>
                      còn {formatQty(l.balance_after)}
                    </span>
                  </span>
                </div>
              ))}
            </div>
          </div>
        ))
      )}
    </>
  );
}

/** Kiểm kho: đếm thực tế, so với hệ thống, cân bằng chênh lệch. */
function CheckTab({
  warehouseId,
  warehouseName,
  items,
  onDone,
}: {
  warehouseId: string;
  warehouseName: string;
  items: IngredientWithStock[];
  onDone: () => void;
}) {
  const toast = useToast();
  const [q, setQ] = useState('');
  const [counts, setCounts] = useState<Record<string, string>>({});
  const [note, setNote] = useState('');
  const [saving, setSaving] = useState(false);

  const needle = q.trim().toLowerCase();
  const list = items.filter((it) => it.active && (!needle || it.name.toLowerCase().includes(needle)));

  const diffOf = (it: IngredientWithStock) => {
    const raw = counts[it.id];
    if (raw === undefined || raw === '') return null;
    const actual = parseFloat(raw);
    if (!Number.isFinite(actual)) return null;
    return Math.round((actual - it.stock) * 100) / 100;
  };

  const diffs = list
    .map((it) => ({ it, diff: diffOf(it) }))
    .filter((x) => x.diff !== null && x.diff !== 0) as { it: IngredientWithStock; diff: number }[];

  const setCount = (id: string, v: string) => setCounts((prev) => ({ ...prev, [id]: v }));

  const submit = async () => {
    if (diffs.length === 0) return toast.show('Chưa có chênh lệch nào cần cân bằng');
    if (!window.confirm(`Cân bằng ${diffs.length} nguyên liệu về số thực tế?`)) return;
    setSaving(true);
    try {
      const res = await applyStockCheck(
        warehouseId,
        diffs.map((d) => ({ ingredientId: d.it.id, actualQty: parseFloat(counts[d.it.id]) })),
        note.trim() || null,
      );
      toast.show(`Đã cân bằng ${res.adjusted} nguyên liệu ✅`);
      setCounts({});
      setNote('');
      onDone();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Cân bằng kho thất bại');
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <div className="small muted" style={{ marginBottom: 8 }}>
        {warehouseName} · Đếm thực tế rồi nhập vào, hệ thống sẽ tính chênh lệch.
      </div>
      <div className="field" style={{ marginBottom: 12 }}>
        <input
          className="input"
          placeholder="🔍 Tìm nguyên liệu…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          aria-label="Tìm nguyên liệu"
        />
      </div>
      {list.length === 0 ? (
        <div className="sb-empty">
          <div className="eico">📦</div>
          <p>Không tìm thấy nguyên liệu.</p>
        </div>
      ) : (
        <div className="sb-section" style={{ padding: '4px 16px', marginBottom: 12 }}>
          {list.map((it) => {
            const diff = diffOf(it);
            return (
              <div key={it.id} className="sb-row" style={{ cursor: 'default', alignItems: 'center' }}>
                <span className="rbody">
                  <span className="rtitle" style={{ fontWeight: 600 }}>
                    {it.name}
                  </span>
                  <span className="rsub">
                    Hệ thống: {formatQty(it.stock)} {it.unit}
                    {diff !== null && diff !== 0 && (
                      <span style={{ color: diff > 0 ? 'var(--brand-dark)' : 'var(--orange)', fontWeight: 700 }}>
                        {' '}· Lệch {diff > 0 ? '+' : ''}
                        {formatQty(diff)}
                      </span>
                    )}
                  </span>
                </span>
                <span className="row" style={{ gap: 4, flex: '0 0 auto', alignItems: 'center' }}>
                  <button
                    type="button"
                    className="btn btn-outline"
                    style={{ minWidth: 36, minHeight: 36, padding: '4px 8px' }}
                    onClick={() => {
                      const cur = parseFloat(counts[it.id] ?? String(it.stock)) || 0;
                      setCount(it.id, String(Math.max(0, Math.round((cur - 1) * 100) / 100)));
                    }}
                    aria-label="Giảm"
                  >
                    −
                  </button>
                  <input
                    className="input"
                    inputMode="decimal"
                    style={{ width: 76, textAlign: 'center' }}
                    placeholder={String(it.stock)}
                    value={counts[it.id] ?? ''}
                    onChange={(e) => setCount(it.id, e.target.value.replace(/[^\d.]/g, ''))}
                    aria-label={`Số thực tế ${it.name}`}
                  />
                  <button
                    type="button"
                    className="btn btn-outline"
                    style={{ minWidth: 36, minHeight: 36, padding: '4px 8px' }}
                    onClick={() => {
                      const cur = parseFloat(counts[it.id] ?? String(it.stock)) || 0;
                      setCount(it.id, String(Math.round((cur + 1) * 100) / 100));
                    }}
                    aria-label="Tăng"
                  >
                    +
                  </button>
                </span>
              </div>
            );
          })}
        </div>
      )}
      {diffs.length > 0 && (
        <div className="sb-section" style={{ marginBottom: 12, padding: '12px 16px' }}>
          <div className="row" style={{ justifyContent: 'space-between', padding: '4px 0' }}>
            <span className="muted">Số dòng lệch</span>
            <b>{diffs.length}</b>
          </div>
          <div className="field" style={{ marginTop: 8 }}>
            <label>Ghi chú kiểm kho</label>
            <input
              className="input"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="VD: kiểm cuối ngày…"
            />
          </div>
          <button className="btn btn-block btn-lg" disabled={saving} onClick={() => void submit()} style={{ marginTop: 8 }}>
            {saving ? 'Đang lưu…' : `⚖️ Cân bằng kho (${diffs.length})`}
          </button>
        </div>
      )}
    </>
  );
}

function IngredientForm({
  ingredient,
  ingredients,
  warehouseId,
  warehouseName,
  onClose,
  onDone,
}: {
  ingredient: Ingredient | null;
  ingredients: Ingredient[];
  warehouseId: string;
  warehouseName: string;
  onClose: () => void;
  onDone: () => void;
}) {
  const toast = useToast();
  const [name, setName] = useState(ingredient?.name ?? '');
  const nameRef = useRef<HTMLInputElement>(null);
  const [unit, setUnit] = useState(ingredient?.unit ?? 'g');
  const [stock, setStock] = useState('');
  const [minStock, setMinStock] = useState(ingredient?.min_stock ? String(ingredient.min_stock) : '');
  const [barcode, setBarcode] = useState(ingredient?.barcode ?? '');
  const [alertEnabled, setAlertEnabled] = useState(ingredient?.alert_enabled ?? true);
  const [cost, setCost] = useState(ingredient?.cost_per_unit ? String(ingredient.cost_per_unit) : '');
  const [active, setActive] = useState(ingredient?.active ?? true);
  const [busy, setBusy] = useState(false);
  const [confirmDel, setConfirmDel] = useState(false);
  // Công thức sản xuất bán thành phẩm (định lượng theo mẻ)
  const [showRecipe, setShowRecipe] = useState(
    !!ingredient?.production_recipe && ingredient.production_recipe.length > 0,
  );
  const [batchQty, setBatchQty] = useState(
    ingredient?.production_batch_qty ? String(ingredient.production_batch_qty) : '',
  );
  const [recipeRows, setRecipeRows] = useState<Array<{ ingredient_id: string; qty: string }>>(
    ingredient?.production_recipe?.map((r) => ({ ingredient_id: r.ingredient_id, qty: String(r.qty) })) ?? [],
  );
  const [allIngs, setAllIngs] = useState<Ingredient[]>([]);
  const [ingsLoaded, setIngsLoaded] = useState(false);

  const num = (v: string) => parseFloat(String(v).replace(',', '.'));

  const loadAllIngs = async () => {
    try {
      const list = await listIngredients();
      setAllIngs(list.filter((i) => i.active && (!ingredient || i.id !== ingredient.id)));
    } catch {
      /* bỏ qua */
    } finally {
      setIngsLoaded(true);
    }
  };

  // Form mở sẵn công thức (đã lưu trước) → tải danh sách nguyên liệu ngay
  useEffect(() => {
    if (showRecipe && !ingsLoaded) {
      void loadAllIngs();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const openRecipe = async () => {
    const next = !showRecipe;
    setShowRecipe(next);
    if (next && !ingsLoaded) {
      await loadAllIngs();
    }
  };

  const save = async () => {
    if (!name.trim()) {
      toast.show('Nhập tên nguyên liệu');
      return;
    }
    // Ma vach (v6.29): moi ma chi dung cho 1 nguyen lieu — trung thi bao loi, khong luu.
    const bc = normalizeBarcode(barcode);
    if (bc) {
      const owner = findBarcodeOwner(ingredients, bc, ingredient?.id);
      if (owner) {
        toast.show(`Mã vạch này đã dùng cho nguyên liệu “${owner.name}”`);
        return;
      }
    }
    setBusy(true);
    try {
      if (ingredient) {
        await updateIngredient(ingredient.id, {
          name: name.trim(),
          unit: unit.trim() || 'đơn vị',
          min_stock: Number.isFinite(num(minStock)) ? Math.max(0, num(minStock)) : 0,
          alert_enabled: alertEnabled,
          cost_per_unit: Number.isFinite(num(cost)) ? Math.max(0, Math.round(num(cost))) : 0,
          barcode: bc,
          active,
        });
        // Lưu công thức sản xuất (nếu có thay đổi ở section)
        if (showRecipe || (ingredient.production_recipe?.length ?? 0) > 0) {
          const recipe = recipeRows
            .map((r) => ({ ingredient_id: r.ingredient_id, qty: num(r.qty) }))
            .filter((r) => r.ingredient_id && Number.isFinite(r.qty) && r.qty > 0);
          const bq = num(batchQty);
          await updateIngredientProductionRecipe(ingredient.id, recipe, Number.isFinite(bq) && bq > 0 ? bq : null);
        }
        toast.show('Đã cập nhật nguyên liệu');
      } else {
        const s = stock.trim() === '' ? 0 : num(stock);
        if (!Number.isFinite(s)) {
          toast.show('Tồn đầu không hợp lệ');
          setBusy(false);
          return;
        }
        const created = await createIngredient(
          {
            name: name.trim(),
            unit: unit.trim() || 'đơn vị',
            stock: s,
            min_stock: Number.isFinite(num(minStock)) ? Math.max(0, num(minStock)) : 0,
            alert_enabled: alertEnabled,
            cost_per_unit: Number.isFinite(num(cost)) ? Math.max(0, Math.round(num(cost))) : 0,
            barcode: bc,
          },
          warehouseId,
        );
        if (showRecipe) {
          const recipe = recipeRows
            .map((r) => ({ ingredient_id: r.ingredient_id, qty: num(r.qty) }))
            .filter((r) => r.ingredient_id && Number.isFinite(r.qty) && r.qty > 0);
          if (recipe.length > 0) await updateIngredientProductionRecipe(created.id, recipe);
        }
        toast.show('Đã thêm nguyên liệu');
      }
      onDone();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    if (!ingredient) return;
    setBusy(true);
    try {
      await deleteIngredient(ingredient.id);
      toast.show('Đã xóa nguyên liệu');
      onDone();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Xóa thất bại');
    } finally {
      setBusy(false);
      setConfirmDel(false);
    }
  };

  return (
    <Sheet
      title={ingredient ? 'Sửa nguyên liệu' : 'Thêm nguyên liệu'}
      onClose={onClose}
      footer={
        <button className="btn btn-block btn-lg" disabled={busy} onClick={save}>
          {busy ? 'Đang lưu…' : 'Lưu'}
        </button>
      }
    >
      <div className="field">
        <label>Tên nguyên liệu *</label>
        <input
          ref={nameRef}
          className="input"
          value={name}
          onChange={(e) => setName(e.target.value)}
          maxLength={60}
          placeholder="VD: Cà phê bột"
          autoFocus={!ingredient}
        />
      </div>
      <div className="field">
        <label>Đơn vị</label>
        <div className="row" style={{ flexWrap: 'wrap', gap: 8, marginBottom: 8 }}>
          {UNIT_SUGGESTIONS.map((u) => (
            <button
              key={u}
              type="button"
              className={`sb-chip${unit === u ? ' selected' : ''}`}
              onClick={() => setUnit(u)}
            >
              {u}
            </button>
          ))}
        </div>
        <input
          className="input"
          value={unit}
          onChange={(e) => setUnit(e.target.value)}
          maxLength={20}
          placeholder="Hoặc nhập đơn vị khác…"
        />
      </div>
      <div className="field">
        <label>Mã vạch (nếu có)</label>
        <input
          className="input"
          value={barcode}
          onChange={(e) => setBarcode(e.target.value)}
          onKeyDown={(e) => {
            // v6.35: súng bắn mã vạch gõ mã rồi Enter — chặn Enter gửi form,
            // nhảy con trỏ về ô Tên nguyên liệu (như form món).
            if (e.key === 'Enter') {
              e.preventDefault();
              nameRef.current?.focus();
            }
          }}
          maxLength={64}
          placeholder="Bắn mã bằng súng quét hoặc nhập tay (VD: 8936000000000)"
          autoComplete="off"
          autoCapitalize="off"
          autoCorrect="off"
          spellCheck={false}
        />
      </div>
      {!ingredient && (
        <div className="field">
          <label>Tồn đầu tại {warehouseName || 'kho đang chọn'}</label>
          <input
            className="input"
            inputMode="decimal"
            value={stock}
            onChange={(e) => setStock(e.target.value)}
            placeholder="0"
          />
        </div>
      )}
      <div className="field">
        <label>Tồn tối thiểu (cảnh báo sắp hết)</label>
        <input
          className="input"
          inputMode="decimal"
          value={minStock}
          onChange={(e) => setMinStock(e.target.value)}
          placeholder="0"
        />
      </div>
      <label className="row" style={{ gap: 8, alignItems: 'center', marginBottom: 16, cursor: 'pointer' }}>
        <input
          type="checkbox"
          checked={alertEnabled}
          onChange={(e) => setAlertEnabled(e.target.checked)}
          style={{ width: 18, height: 18 }}
        />
        <span>🔔 Bật cảnh báo sắp hết hàng cho nguyên liệu này</span>
      </label>
      <div className="field">
        <label>Giá vốn / đơn vị (VND, tham khảo)</label>
        <input
          className="input"
          inputMode="numeric"
          value={cost}
          onChange={(e) => setCost(e.target.value)}
          placeholder="0"
        />
      </div>
      <div className="card" style={{ marginBottom: 16, background: 'var(--pastel-purple, #f7f2ff)' }}>
        <button
          type="button"
          className="btn btn-block btn-outline"
          onClick={openRecipe}
          style={{ borderStyle: 'dashed' }}
        >
          🧪 {showRecipe ? 'Ẩn công thức sản xuất' : 'Thêm công thức sản xuất (bán thành phẩm)'}
        </button>
        {showRecipe && (
          <div style={{ marginTop: 12 }}>
            <div className="row" style={{ gap: 8, marginBottom: 8, alignItems: 'center' }}>
              <span className="small" style={{ whiteSpace: 'nowrap' }}>1 mẻ làm ra</span>
              <input
                className="input"
                style={{ width: 100 }}
                type="number"
                min="0"
                step="any"
                placeholder="VD: 1000"
                value={batchQty}
                onChange={(e) => setBatchQty(e.target.value)}
              />
              <span className="small muted">{unit.trim() || 'đơn vị'}</span>
            </div>
            <p className="small muted" style={{ marginBottom: 8 }}>
              Nguyên liệu thô cần cho <b>1 mẻ</b> ({batchQty || '?'} {unit.trim() || 'đơn vị'} “{name.trim() || 'thành phẩm'}”).
              <br />
              VD: 1 mẻ 1000 ml kem muối cần 800 ml kem béo + 50 g muối hồng + 150 ml sữa đặc.
            </p>
            {recipeRows.map((row, idx) => {
              const picked = allIngs.find((i) => i.id === row.ingredient_id);
              return (
                <div key={idx} className="row" style={{ gap: 8, marginBottom: 8 }}>
                  <select
                    className="input grow"
                    value={row.ingredient_id}
                    onChange={(e) => {
                      const next = [...recipeRows];
                      next[idx] = { ...next[idx], ingredient_id: e.target.value };
                      setRecipeRows(next);
                    }}
                  >
                    <option value="">— Chọn nguyên liệu thô —</option>
                    {allIngs.map((i) => (
                      <option key={i.id} value={i.id}>
                        {i.name} ({i.unit})
                      </option>
                    ))}
                  </select>
                  <input
                    className="input"
                    style={{ width: 110 }}
                    inputMode="decimal"
                    placeholder="SL"
                    value={row.qty}
                    onChange={(e) => {
                      const next = [...recipeRows];
                      next[idx] = { ...next[idx], qty: e.target.value };
                      setRecipeRows(next);
                    }}
                  />
                  <span className="small muted" style={{ alignSelf: 'center', minWidth: 32 }}>
                    {picked ? `/${picked.unit}` : ''}
                  </span>
                  <button
                    type="button"
                    className="sb-chip"
                    onClick={() => setRecipeRows(recipeRows.filter((_, i) => i !== idx))}
                    aria-label="Xóa dòng"
                  >
                    ×
                  </button>
                </div>
              );
            })}
            <button
              type="button"
              className="btn btn-outline btn-block"
              onClick={() => setRecipeRows([...recipeRows, { ingredient_id: '', qty: '' }])}
            >
              ＋ Thêm nguyên liệu thô
            </button>
            {recipeRows.length === 0 && (
              <p className="small muted" style={{ marginTop: 8 }}>
                Để trống và lưu = xóa công thức (trở thành nguyên liệu thường).
              </p>
            )}
          </div>
        )}
      </div>
      {ingredient && (
        <div className="row" style={{ marginBottom: 16 }}>
          <span className="grow" style={{ fontWeight: 600, fontSize: 15 }}>Đang dùng</span>
          <label className="switch" aria-label="Đang dùng">
            <input type="checkbox" checked={active} onChange={(e) => setActive(e.target.checked)} />
            <span className="track" />
          </label>
        </div>
      )}
      {ingredient &&
        (confirmDel ? (
          <div className="row" style={{ gap: 8 }}>
            <button type="button" className="btn grow" style={{}} disabled={busy} onClick={remove}>
              Chắc chắn xóa
            </button>
            <button type="button" className="btn btn-outline grow" onClick={() => setConfirmDel(false)}>
              Hủy
            </button>
          </div>
        ) : (
          <button
            type="button"
            className="btn btn-ghost btn-block"
            onClick={() => setConfirmDel(true)}
          >
            Xóa nguyên liệu
          </button>
        ))}
    </Sheet>
  );
}

function TransferForm({
  warehouses,
  fromWid,
  items,
  onDone,
}: {
  warehouses: Warehouse[];
  fromWid: string;
  items: IngredientWithStock[];
  onDone: () => void;
}) {
  const toast = useToast();
  const [ingId, setIngId] = useState('');
  const [from, setFrom] = useState(fromWid);
  const [to, setTo] = useState('');
  const [qty, setQty] = useState('');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    setFrom(fromWid);
  }, [fromWid]);
  useEffect(() => {
    if (!to) {
      const other = warehouses.find((w) => w.id !== from);
      if (other) setTo(other.id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [warehouses, from]);

  const ing = items.find((i) => i.id === ingId);

  const submit = async () => {
    if (!ing) {
      toast.show('Chọn nguyên liệu cần chuyển');
      return;
    }
    const v = parseFloat(String(qty).replace(',', '.'));
    if (!Number.isFinite(v) || v <= 0) {
      toast.show('Nhập số lượng hợp lệ');
      return;
    }
    if (!from || !to || from === to) {
      toast.show('Chọn kho nguồn và kho đích khác nhau');
      return;
    }
    setBusy(true);
    try {
      await transferStock(from, to, ing.id, v, note.trim() || null);
      const fromName = warehouses.find((w) => w.id === from)?.name ?? '';
      const toName = warehouses.find((w) => w.id === to)?.name ?? '';
      toast.show(`Đã chuyển ${formatQty(v)} ${ing.unit} ${ing.name}: ${fromName} → ${toName}`);
      setQty('');
      setNote('');
      onDone();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Chuyển kho thất bại');
    } finally {
      setBusy(false);
    }
  };

  if (warehouses.length < 2) {
    return <div className="card">Cần ít nhất 2 kho đang dùng mới chuyển kho được. Chủ quán tạo thêm kho ở tab "Kho".</div>;
  }

  return (
    <div className="sb-section">
      <div className="field">
        <label>Nguyên liệu</label>
        <select className="input" value={ingId} onChange={(e) => setIngId(e.target.value)}>
          <option value="">— Chọn nguyên liệu —</option>
          {items
            .filter((i) => i.active)
            .map((i) => (
              <option key={i.id} value={i.id}>
                {i.name} ({formatQty(i.stock)} {i.unit})
              </option>
            ))}
        </select>
      </div>
      <div className="row" style={{ gap: 8 }}>
        <div className="field grow">
          <label>Từ kho</label>
          <select className="input" value={from} onChange={(e) => setFrom(e.target.value)}>
            {warehouses.map((w) => (
              <option key={w.id} value={w.id}>
                {w.name}
              </option>
            ))}
          </select>
        </div>
        <div className="field grow">
          <label>Đến kho</label>
          <select className="input" value={to} onChange={(e) => setTo(e.target.value)}>
            {warehouses.map((w) => (
              <option key={w.id} value={w.id}>
                {w.name}
              </option>
            ))}
          </select>
        </div>
      </div>
      <div className="field">
        <label>Số lượng{ing ? ` (${ing.unit})` : ''}</label>
        <input
          className="sb-money-input"
          inputMode="decimal"
          placeholder="0"
          value={qty}
          onChange={(e) => setQty(e.target.value)}
        />
      </div>
      <div className="field">
        <label>Ghi chú (không bắt buộc)</label>
        <input
          className="input"
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="VD: bổ sung kho quầy…"
        />
      </div>
      <button className="btn btn-block btn-lg" disabled={busy} onClick={submit}>
        {busy ? 'Đang chuyển…' : 'Chuyển kho'}
      </button>
    </div>
  );
}

function WarehouseManager({ onChanged }: { onChanged: () => void }) {
  const toast = useToast();
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [busy, setBusy] = useState(true);
  const [editing, setEditing] = useState<Warehouse | 'new' | null>(null);

  const load = useCallback(async () => {
    setBusy(true);
    try {
      setWarehouses(await listWarehouses(false));
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tải được danh sách kho');
    } finally {
      setBusy(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const setDefault = async (w: Warehouse) => {
    try {
      await setDefaultWarehouse(w.id);
      toast.show(`"${w.name}" là kho bán hàng mặc định`);
      await load();
      onChanged();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Thao tác thất bại');
    }
  };

  const toggleActive = async (w: Warehouse) => {
    if (!w.active) {
      // bật lại
      try {
        await updateWarehouse(w.id, { active: true });
        await load();
        onChanged();
      } catch (e) {
        toast.show(e instanceof DbError ? e.message : 'Thao tác thất bại');
      }
      return;
    }
    const actives = warehouses.filter((x) => x.active);
    if (actives.length <= 1) {
      toast.show('Phải giữ ít nhất 1 kho đang dùng');
      return;
    }
    if (w.is_default) {
      toast.show('Kho mặc định không ẩn được — hãy đặt kho khác làm mặc định trước');
      return;
    }
    try {
      await updateWarehouse(w.id, { active: false });
      toast.show(`Đã ẩn kho "${w.name}"`);
      await load();
      onChanged();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Thao tác thất bại');
    }
  };

  if (busy) return <div className="card">Đang tải…</div>;

  return (
    <>
      <div className="row only-desktop" style={{ marginBottom: 12 }}>
        <button className="btn" onClick={() => setEditing('new')}>
          ＋ Thêm kho
        </button>
      </div>
      {warehouses.map((w) => (
        <div className="sb-section" key={w.id} style={{ marginBottom: 10, opacity: w.active ? 1 : 0.55 }}>
          <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <div style={{ fontWeight: 600, fontSize: 16 }}>
                🗃️ {w.name}
                {w.is_default && (
                  <span className="sb-status-pill" style={{ marginLeft: 6, fontSize: 11 }}>Mặc định ★</span>
                )}
                {!w.active && (
                  <span className="sb-status-pill" style={{ marginLeft: 6, fontSize: 11 }}>Đang ẩn</span>
                )}
              </div>
              {w.note && <div className="small muted">{w.note}</div>}
            </div>
          </div>
          <div className="row" style={{ gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
            {!w.is_default && w.active && (
              <button className="btn btn-outline grow" onClick={() => void setDefault(w)}>
                Đặt làm mặc định
              </button>
            )}
            <button className="btn btn-ghost grow" onClick={() => setEditing(w)}>
              Sửa
            </button>
            <button className="btn btn-ghost grow" onClick={() => void toggleActive(w)}>
              {w.active ? 'Ẩn' : 'Hiện'}
            </button>
          </div>
        </div>
      ))}
      <button className="fab" onClick={() => setEditing('new')} aria-label="Thêm kho">
        +
      </button>
      {editing && (
        <WarehouseForm
          warehouse={editing === 'new' ? null : editing}
          onClose={() => setEditing(null)}
          onDone={() => {
            setEditing(null);
            void load();
            onChanged();
          }}
        />
      )}
    </>
  );
}

function WarehouseForm({
  warehouse,
  onClose,
  onDone,
}: {
  warehouse: Warehouse | null;
  onClose: () => void;
  onDone: () => void;
}) {
  const toast = useToast();
  const [name, setName] = useState(warehouse?.name ?? '');
  const [note, setNote] = useState(warehouse?.note ?? '');
  const [busy, setBusy] = useState(false);

  const save = async () => {
    if (!name.trim()) {
      toast.show('Nhập tên kho');
      return;
    }
    setBusy(true);
    try {
      if (warehouse) {
        await updateWarehouse(warehouse.id, { name: name.trim(), note: note.trim() || null });
        toast.show('Đã cập nhật kho');
      } else {
        await createWarehouse(name.trim(), note.trim() || null);
        toast.show(`Đã thêm kho "${name.trim()}"`);
      }
      onDone();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet
      title={warehouse ? 'Sửa kho' : 'Thêm kho'}
      onClose={onClose}
      footer={
        <button className="btn btn-block btn-lg" disabled={busy} onClick={save}>
          {busy ? 'Đang lưu…' : 'Lưu'}
        </button>
      }
    >
      <div className="field">
        <label>Tên kho *</label>
        <input
          className="input"
          value={name}
          onChange={(e) => setName(e.target.value)}
          maxLength={60}
          placeholder="VD: Kho quầy, Kho tổng…"
          autoFocus={!warehouse}
        />
      </div>
      <div className="field">
        <label>Ghi chú (không bắt buộc)</label>
        <input
          className="input"
          value={note}
          onChange={(e) => setNote(e.target.value)}
          maxLength={500}
          placeholder="VD: kho ở quầy pha chế…"
        />
      </div>
    </Sheet>
  );
}
