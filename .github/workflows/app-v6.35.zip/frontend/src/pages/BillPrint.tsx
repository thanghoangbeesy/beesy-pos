import { useEffect } from 'react';
import { formatTime, formatVND } from '../lib/format';
import { useVietQRImage } from '../lib/vietqr';
import { useAuth } from '../lib/auth';
import type { Order } from '../lib/types';

// Bill xem trước + vùng in khổ 80mm (render vào #print-root để CSS @media print bắt được)
// Mẫu v6.32 (Hoàng duyệt demo 26/11/2026): HÓA ĐƠN THANH TOÁN, bảng món
// Tên món | SL | Đơn giá | Thành tiền, Tạm tính / Giảm giá / VAT / TỔNG,
// QR chuyển khoản, Wifi, cảm ơn. Một mẫu dùng chung cho xem trước, bản in
// và ảnh PNG gửi Zalo (bill-image.ts chụp #bill-capture).

/** Nhãn nguồn đơn in trên bill (quán không chia bàn nên dùng nguồn thay cho Bàn). */
const SOURCE_LABELS: Record<string, string> = {
  pos: 'Tại quán',
  takeaway: 'Mang đi',
  delivery: 'Ship',
  online: 'Đặt online',
  grabfood: 'GrabFood',
  shopeefood: 'ShopeeFood',
};

/** Số tiền không kèm "đ" (dùng trong bảng món và các dòng tạm tính). */
function fmt(n: number | null | undefined): string {
  if (n === null || n === undefined) return '0';
  return `${Math.round(n).toLocaleString('vi-VN')}`;
}

/** Ngày dạng 26/11/2026 theo giờ máy (máy quán ở VN) — cùng cách formatTime dùng. */
function dateVN(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit', year: 'numeric' });
}

const DASHED_HR = { border: 'none', borderTop: '1px dashed var(--line)' } as const;

export function BillPrint({
  order,
  shopName,
  shopPhone,
  shopAddress,
  shopLogo,
  shopTaxId,
  wifiName,
  wifiPassword,
  qrBin,
  qrName,
  qrAccount,
  qrAmount,
}: {
  order: Order;
  shopName: string;
  shopPhone?: string;
  shopAddress?: string;
  shopLogo?: string;
  shopTaxId?: string;
  wifiName?: string;
  wifiPassword?: string;
  qrBin?: string | null;
  qrName?: string;
  qrAccount?: string;
  qrAmount?: number;
}) {
  // Thu ngân = tài khoản đang đăng nhập (quán một người vận hành nên luôn là người tạo đơn).
  const { user } = useAuth();
  const cashier = user?.full_name || user?.email || 'Chủ quán';
  // QR tu sinh dang PNG data URL (lib/vietqr) - anh vietqr.io dang SVG khien
  // anh bill chup ra bi trong cho QR. Ca bill hien thi lan ban in deu dung URL nay.
  const qrUrl = useVietQRImage(qrBin, qrAccount, qrName, qrAmount, order.code);
  const dateStr = dateVN(order.created_at);
  const timeStr = formatTime(order.created_at);
  const sourceLabel = order.source_label ?? SOURCE_LABELS[order.source] ?? order.source;
  const discountLabel = order.discount_label || order.voucher_code || '';
  const contactParts: string[] = [];
  if (shopPhone) contactParts.push(`SĐT: ${shopPhone}`);
  if (shopTaxId) contactParts.push(`MST: ${shopTaxId}`);

  useEffect(() => {
    let root = document.getElementById('print-root');
    if (!root) {
      root = document.createElement('div');
      root.id = 'print-root';
      document.body.appendChild(root);
    }
    return () => {
      const r = document.getElementById('print-root');
      if (r) r.innerHTML = '';
    };
  }, []);

  useEffect(() => {
    const root = document.getElementById('print-root');
    if (!root) return;
    const contactHtmlParts: string[] = [];
    if (shopPhone) contactHtmlParts.push(`SĐT: ${escapeHtml(shopPhone)}`);
    if (shopTaxId) contactHtmlParts.push(`MST: ${escapeHtml(shopTaxId)}`);
    const itemRows = order.items
      .map(
        (it) => `
        <tr>
          <td>${escapeHtml(it.product_name)}
            ${(it.modifiers || []).map((m) => `<div class="sub">+ ${escapeHtml(m.option)}${m.price_delta ? ` (+${fmt(m.price_delta)})` : ''}</div>`).join('')}
            ${it.discount ? `<div class="sub">Giảm: -${fmt(it.discount)}</div>` : ''}
            ${it.note ? `<div class="sub">Ghi chú: ${escapeHtml(it.note)}</div>` : ''}
          </td>
          <td>${it.qty}</td>
          <td>${fmt(it.unit_price)}</td>
          <td>${fmt(it.line_total)}</td>
        </tr>`,
      )
      .join('');
    const logoHtml = shopLogo
      ? shopLogo.startsWith('data:image')
        ? `<div class="center" style="margin-bottom:6px"><img src="${shopLogo}" alt="Logo" style="max-width:120px;max-height:80px;" /></div>`
        : `<div class="center" style="font-size:36px;margin-bottom:4px">${escapeHtml(shopLogo)}</div>`
      : '';
    root.innerHTML = `
      <div id="print-area">
        ${logoHtml}
        <h2>${escapeHtml(shopName)}</h2>
        ${shopAddress ? `<div class="center small">${escapeHtml(shopAddress)}</div>` : ''}
        ${contactHtmlParts.length ? `<div class="center small">${contactHtmlParts.join(' | ')}</div>` : ''}
        <hr/>
        <div class="center bill-title">HÓA ĐƠN THANH TOÁN</div>
        <div class="row"><span>Số bill: <b>#${escapeHtml(order.code)}</b></span><span>Nguồn: ${escapeHtml(sourceLabel)}</span></div>
        <div class="row"><span>Ngày: ${dateStr}</span><span>Giờ: ${timeStr}</span></div>
        <div class="row"><span>Thu ngân: ${escapeHtml(cashier)}</span></div>
        <hr/>
        <table class="bill-table">
          <tr><th>Tên món</th><th>SL</th><th>Đơn giá</th><th>Thành tiền</th></tr>
          ${itemRows}
        </table>
        <hr/>
        <div class="row"><span>Tạm tính</span><span>${fmt(order.subtotal)}</span></div>
        <div class="row"><span>Giảm giá / Voucher${discountLabel ? ` (${escapeHtml(discountLabel)})` : ''}</span><span>${order.discount > 0 ? `-${fmt(order.discount)}` : '0'}</span></div>
        ${order.shipping_fee > 0 ? `<div class="row"><span>Phí ship</span><span>+${fmt(order.shipping_fee)}</span></div>` : ''}
        <div class="row"><span>VAT (nếu áp dụng)</span><span>0</span></div>
        <div class="row"><span><b>TỔNG THANH TOÁN</b></span><span class="total">${formatVND(order.total)}</span></div>
        <hr/>
        ${qrUrl ? `
        <div class="center">
          <div class="small" style="margin-bottom:4px"><b>Quét mã để chuyển tiền</b></div>
          <img src="${qrUrl}" alt="QR thanh toán" style="width:180px;height:180px;" />
          ${qrName ? `<div class="small">${escapeHtml(qrName)}</div>` : ''}
          <div class="small">STK: ${escapeHtml(qrAccount || '')} · Số tiền: <b>${formatVND(qrAmount || 0)}</b> · Nội dung: <b>${escapeHtml(order.code)}</b></div>
        </div>
        <hr/>` : ''}
        ${wifiName ? `<div class="center small">Wifi: ${escapeHtml(wifiName)}${wifiPassword ? ` | Pass: ${escapeHtml(wifiPassword)}` : ''}</div>` : ''}
        <div class="center" style="margin-top:8px">Cảm ơn quý khách và hẹn gặp lại!</div>
      </div>`;
  }, [order, shopName, shopPhone, shopAddress, shopLogo, shopTaxId, wifiName, wifiPassword, qrUrl, qrName, qrAccount, qrAmount, cashier, dateStr, timeStr, sourceLabel, discountLabel]);

  return (
    <div id="bill-capture" className="card" style={{ marginTop: 12, maxWidth: 340, marginLeft: 'auto', marginRight: 'auto', fontFamily: '"Be Vietnam Pro", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif', fontSize: 14 }}>
      {shopLogo && (
        <div style={{ textAlign: 'center', marginBottom: 6 }}>
          {shopLogo.startsWith('data:image') ? (
            <img src={shopLogo} alt="Logo" style={{ maxWidth: 120, maxHeight: 80 }} />
          ) : (
            <span style={{ fontSize: 36 }}>{shopLogo}</span>
          )}
        </div>
      )}
      <h3 style={{ textAlign: 'center', margin: '0 0 4px' }}>{shopName}</h3>
      {shopAddress && <p style={{ textAlign: 'center', margin: '0 0 2px' }} className="muted small">{shopAddress}</p>}
      {contactParts.length > 0 && <p style={{ textAlign: 'center', margin: '0 0 8px' }} className="muted small">{contactParts.join(' | ')}</p>}
      <hr style={DASHED_HR} />
      <p style={{ textAlign: 'center', margin: '0 0 8px', fontSize: 16, fontWeight: 800, letterSpacing: 1 }}>HÓA ĐƠN THANH TOÁN</p>
      <div className="row small">
        <span>Số bill: <b>#{order.code}</b></span>
        <span>Nguồn: {sourceLabel}</span>
      </div>
      <div className="row small">
        <span>Ngày: {dateStr}</span>
        <span>Giờ: {timeStr}</span>
      </div>
      <div className="row small" style={{ marginBottom: 2 }}>
        <span>Thu ngân: {cashier}</span>
      </div>
      <hr style={DASHED_HR} />
      <table className="bill-table">
        <thead>
          <tr><th>Tên món</th><th>SL</th><th>Đơn giá</th><th>Thành tiền</th></tr>
        </thead>
        <tbody>
          {order.items.map((it) => (
            <tr key={it.id}>
              <td>
                {it.product_name}
                {(it.modifiers || []).map((m, i) => (
                  <div key={i} className="sub">
                    + {m.option}{m.price_delta ? ` (+${fmt(m.price_delta)})` : ''}
                  </div>
                ))}
                {it.discount ? <div className="sub">Giảm: −{fmt(it.discount)}</div> : null}
                {it.note ? <div className="sub">Ghi chú: {it.note}</div> : null}
              </td>
              <td>{it.qty}</td>
              <td>{fmt(it.unit_price)}</td>
              <td>{fmt(it.line_total)}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <hr style={DASHED_HR} />
      <div className="row">
        <span>Tạm tính</span>
        <span>{fmt(order.subtotal)}</span>
      </div>
      <div className="row">
        <span>Giảm giá / Voucher{discountLabel ? ` (${discountLabel})` : ''}</span>
        <span>{order.discount > 0 ? `-${fmt(order.discount)}` : '0'}</span>
      </div>
      {order.shipping_fee > 0 && (
        <div className="row">
          <span>Phí ship</span>
          <span>+{fmt(order.shipping_fee)}</span>
        </div>
      )}
      <div className="row">
        <span>VAT (nếu áp dụng)</span>
        <span>0</span>
      </div>
      <div className="row">
        <b>TỔNG THANH TOÁN</b>
        <b className="money" style={{ fontSize: 18 }}>{formatVND(order.total)}</b>
      </div>
      <hr style={DASHED_HR} />
      {qrUrl && (
        <div style={{ textAlign: 'center', paddingBottom: 4 }}>
          <div className="small" style={{ marginBottom: 6 }}><b>Quét mã để chuyển tiền</b></div>
          <img src={qrUrl} alt="QR thanh toán" style={{ width: 180, height: 180 }} />
          <div className="small muted" style={{ marginTop: 4 }}>
            {qrName && <div>{qrName}</div>}
            {qrAccount && <div>STK: {qrAccount} · Số tiền: <b className="money">{formatVND(qrAmount || 0)}</b> · Nội dung: <b>{order.code}</b></div>}
          </div>
        </div>
      )}
      {qrUrl && <hr style={DASHED_HR} />}
      {wifiName && (
        <p style={{ textAlign: 'center', margin: '0 0 8px' }} className="small">
          Wifi: {wifiName}{wifiPassword ? ` | Pass: ${wifiPassword}` : ''}
        </p>
      )}
      <p style={{ textAlign: 'center', margin: 0 }}>Cảm ơn quý khách và hẹn gặp lại!</p>
    </div>
  );
}

function escapeHtml(s: string): string {
  return s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c] ?? c));
}
