// Tien ich ma vach dung chung cho ban hang (mon) va nhap/xuat kho (nguyen lieu).
// Ma vach tren bao bi thuong la EAN-13/UPC (chi so) hoac CODE-128 (co the co chu).
// Chuan hoa: bo khoang trang, viet hoa — de quet camera, go tay hay may USB
// (may USB go nhu ban phim) deu khop cung mot ma.

export function normalizeBarcode(code: string): string {
  return String(code ?? '')
    .replace(/\s+/g, '')
    .toUpperCase();
}

/** Tim mon/nguyen lieu theo ma vach trong danh sach da tai san. */
export function findByBarcode<T extends { barcode?: string }>(
  items: readonly T[],
  code: string,
): T | undefined {
  const needle = normalizeBarcode(code);
  if (!needle) return undefined;
  return items.find((it) => it.barcode != null && normalizeBarcode(it.barcode) === needle);
}

/**
 * Tim mon/nguyen lieu khac dang dung ma vach nay (de canh bao trung khi luu).
 * excludeId: id cua ban ghi dang sua (duoc phep giu nguyen ma cua chinh no).
 */
export function findBarcodeOwner<T extends { id: string; barcode?: string; name: string }>(
  items: readonly T[],
  code: string,
  excludeId?: string,
): T | undefined {
  const needle = normalizeBarcode(code);
  if (!needle) return undefined;
  return items.find(
    (it) => it.id !== excludeId && it.barcode != null && normalizeBarcode(it.barcode) === needle,
  );
}
