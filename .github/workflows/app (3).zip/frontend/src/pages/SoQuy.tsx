// Sổ quỹ — sổ tiền của quán.
// Gồm khoản THỦ CÔNG (nhập tay) và khoản TỰ ĐỘNG:
//  - đơn đã thu tiền (tiền mặt/chuyển khoản) → "Doanh thu bán hàng" (ghi trong transaction tạo đơn)
//  - thu nợ ở Sổ nợ → "Thu nợ — tên khách"
// Đơn ghi nợ lúc bán chưa thu tiền nên không ghi vào quỹ.
// Đơn cũ trước tính năng tự động không backfill.
import { useNavigate } from 'react-router-dom';
import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  DbError,
  LOCKED_THU_CATS,
  addCashbookEntry,
  deleteCashbookEntry,
  getFundCategories,
  getFunds,
  listCashbookEntries,
  getAllowedWarehouses,
  normalizeFundId,
  saveFundOpening,
  setFundCategories,
  toLocalDateTimeInput,
} from '../lib/db';
import { formatDMY, formatTime, formatVND, todayVN, unsignVietnamese, addDaysVN, startOfMonthVN, startOfWeekVN } from '../lib/format';
import { Sheet } from '../components/Sheet';
import { PageHead } from '../components/PageHead';
import { useToast } from '../components/Toast';
import { useAuth } from '../lib/auth';
import type { CashbookEntry, CashbookType, Fund, FundCategories, Warehouse } from '../lib/types';

type FilterKey = 'today' | 'yesterday' | 'week' | 'lastweek' | 'month' | 'lastmonth' | 'custom';
const FILTERS: { key: FilterKey; label: string }[] = [
  { key: 'today', label: 'Hôm nay' },
  { key: 'yesterday', label: 'Hôm qua' },
  { key: 'week', label: 'Tuần này' },
  { key: 'lastweek', label: 'Tuần trước' },
  { key: 'month', label: 'Tháng này' },
  { key: 'lastmonth', label: 'Tháng trước' },
  { key: 'custom', label: 'Tùy chọn' },
];

/** YYYY-MM-DD theo giờ VN từ chuỗi ISO. */
function vnDateKey(iso: string): string {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Ho_Chi_Minh',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date(iso));
}

/** Nhãn ngày kiểu "Thứ Bảy, 10/10" theo giờ VN. */
function vnDayLabel(iso: string): string {
  return new Date(iso).toLocaleDateString('vi-VN', {
    weekday: 'long',
    day: '2-digit',
    month: '2-digit',
    timeZone: 'Asia/Ho_Chi_Minh',
  });
}

export function SoQuy() {
  const toast = useToast();
  const navigate = useNavigate();
  const { can } = useAuth();
  const canSettings = can('cashbook.settings');
  const [entries, setEntries] = useState<CashbookEntry[]>([]);
  const [funds, setFunds] = useState<Fund[]>([]);
  const [cats, setCats] = useState<FundCategories>({ thu: ['Bán hàng', 'Thu nợ', 'Khác'], chi: ['Nguyên liệu', 'Mặt bằng', 'Lương', 'Khác'] });
  const [filter, setFilter] = useState<FilterKey>('month');
  const [customFrom, setCustomFrom] = useState(() => todayVN());
  const [customTo, setCustomTo] = useState(() => todayVN());
  const [fundFilter, setFundFilter] = useState<string>('all'); // 'all' hoặc fund.id
  const [q, setQ] = useState('');
  const [busy, setBusy] = useState(true);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [whFilter, setWhFilter] = useState('all'); // 'all' hoặc warehouse.id
  const [sheet, setSheet] = useState<CashbookType | null>(null);
  const [fundSheet, setFundSheet] = useState<Fund | null>(null); // sửa số dư đầu kỳ của quỹ
  const [catSheet, setCatSheet] = useState(false);

  const load = useCallback(async () => {
    setBusy(true);
    try {
      const [list, fl, c, allowed] = await Promise.all([
        listCashbookEntries(500),
        getFunds(),
        getFundCategories(),
        getAllowedWarehouses(),
      ]);
      const ws = allowed.warehouses;
      setEntries(list);
      setFunds(fl);
      setCats(c);
      setWarehouses(ws);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tải được sổ quỹ');
    } finally {
      setBusy(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const t = todayVN();
  const needle = unsignVietnamese(q.trim()).toLowerCase();
  const fundIds = useMemo(() => new Set(funds.map((f) => f.id)), [funds]);
  const activeFunds = useMemo(() => funds.filter((f) => f.active), [funds]);

  // Chuẩn hóa fund_id khoản cũ: 'bank' (bản trước) → id phương thức; id lạ → 'cash'
  const normalized = useMemo(
    () => entries.map((e) => ({ ...e, fund_id: normalizeFundId(e.fund_id, fundIds) })),
    [entries, fundIds],
  );

  // Phạm vi kho được xem: 'all' = mọi kho ĐÃ GÁN (không phải mọi kho hệ thống)
  const scopeIds = useMemo(
    () => (whFilter === 'all' ? warehouses.map((w) => w.id) : [whFilter]),
    [whFilter, warehouses],
  );
  const inScope = useMemo(
    () => (e: { warehouse_id?: string | null }) =>
      scopeIds.length === 0 || !e.warehouse_id || scopeIds.includes(e.warehouse_id),
    [scopeIds],
  );

  // Khoảng ngày theo bộ lọc (YYYY-MM-DD)
  const [rangeFrom, rangeTo] = useMemo(() => {
    switch (filter) {
      case 'today':
        return [t, t];
      case 'yesterday': {
        const y = addDaysVN(t, -1);
        return [y, y];
      }
      case 'week':
        return [startOfWeekVN(t), t];
      case 'lastweek': {
        const mondayThis = startOfWeekVN(t);
        const mondayLast = addDaysVN(mondayThis, -7);
        return [mondayLast, addDaysVN(mondayLast, 6)];
      }
      case 'month':
        return [startOfMonthVN(t), t];
      case 'lastmonth': {
        const firstThis = startOfMonthVN(t);
        const lastPrev = addDaysVN(firstThis, -1);
        return [startOfMonthVN(lastPrev), lastPrev];
      }
      case 'custom':
        return [customFrom <= customTo ? customFrom : customTo, customFrom <= customTo ? customTo : customFrom];
    }
  }, [filter, t, customFrom, customTo]);

  const filtered = useMemo(
    () =>
      normalized.filter((e) => {
        if (fundFilter !== 'all' && e.fund_id !== fundFilter) return false;
        if (!inScope(e)) return false;
        const k = vnDateKey(e.created_at);
        if (k < rangeFrom || k > rangeTo) return false;
        if (needle) {
          const hay = unsignVietnamese(
            `${e.category} ${e.note ?? ''} ${e.amount} ${formatTime(e.created_at)}`,
          ).toLowerCase();
          if (!hay.includes(needle)) return false;
        }
        return true;
      }),
    [normalized, fundFilter, rangeFrom, rangeTo, needle, inScope],
  );

  // Số dư từng quỹ = số dư đầu kỳ + Σ thu − Σ chi của quỹ đó
  // (tính trên 500 khoản mới nhất — đủ cho quán nhỏ)
  const whEntries = useMemo(() => normalized.filter(inScope), [normalized, inScope]);
  // Số dư đầu kỳ hiển thị = tổng số dư đầu kỳ các kho trong phạm vi
  const openingDisplay = (f: Fund) =>
    scopeIds.length === 0
      ? f.opening_balance
      : scopeIds.reduce((sum, wid) => sum + (f.opening_by_warehouse?.[wid]?.opening_balance ?? 0), 0);
  // Đầu kỳ / Cuối kỳ theo khoảng ngày đang lọc (không bị ảnh hưởng bởi ô tìm kiếm):
  // Đầu kỳ = số dư đầu kỳ cài đặt + Σ khoản trước rangeFrom
  // Cuối kỳ = Đầu kỳ + Σ thu/chi trong [rangeFrom, rangeTo]
  const periodStats = useMemo(() => {
    let opening = 0;
    let thu = 0;
    let chi = 0;
    const perFund = new Map<string, { opening: number; closing: number }>();
    const fundsInScope =
      fundFilter === 'all' ? activeFunds : activeFunds.filter((f) => f.id === fundFilter);
    for (const f of fundsInScope) {
      const o = openingDisplay(f);
      opening += o;
      perFund.set(f.id, { opening: o, closing: o });
    }
    for (const e of whEntries) {
      if (fundFilter !== 'all' && e.fund_id !== fundFilter) continue;
      const k = vnDateKey(e.created_at);
      const net = e.type === 'thu' ? e.amount : -e.amount;
      if (k < rangeFrom) {
        opening += net;
        const pf = perFund.get(e.fund_id);
        if (pf) {
          pf.opening += net;
          pf.closing += net;
        }
      } else if (k <= rangeTo) {
        if (e.type === 'thu') thu += e.amount;
        else chi += e.amount;
        const pf = perFund.get(e.fund_id);
        if (pf) pf.closing += net;
      }
    }
    return { opening, thu, chi, closing: opening + thu - chi, perFund };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeFunds, fundFilter, whEntries, rangeFrom, rangeTo]);

  const delEntry = async (e: CashbookEntry) => {
    if (!window.confirm(`Xóa khoản ${e.type === 'thu' ? 'thu' : 'chi'} ${formatVND(e.amount)}${e.note ? ` — ${e.note}` : ''}?`))
      return;
    try {
      await deleteCashbookEntry(e.id);
      toast.show('Đã xóa khoản');
      void load();
    } catch (err) {
      toast.show(err instanceof DbError ? err.message : 'Xóa thất bại');
    }
  };

  const groups = useMemo(() => {
    const m = new Map<string, CashbookEntry[]>();
    for (const e of filtered) {
      const k = vnDateKey(e.created_at);
      if (!m.has(k)) m.set(k, []);
      m.get(k)!.push(e);
    }
    return [...m.entries()].sort((a, b) => (a[0] < b[0] ? 1 : -1));
  }, [filtered]);

  return (
    <div className="page with-dual-actions">
      <PageHead title="Sổ quỹ" back />

      <div className="sb-search" style={{ marginBottom: 12 }}>
        <span className="sico">🔍</span>
        <input
          placeholder="Tìm ghi chú, số tiền…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          aria-label="Tìm khoản thu chi"
        />
      </div>

      <div className="row" style={{ gap: 8, marginBottom: 12, flexWrap: 'wrap' }}>
        <select
          className="input"
          style={{ flex: '1 1 130px', minWidth: 0 }}
          value={filter}
          onChange={(e) => setFilter(e.target.value as FilterKey)}
          aria-label="Lọc theo thời gian"
        >
          {FILTERS.map((f) => (
            <option key={f.key} value={f.key}>
              {f.label}
            </option>
          ))}
        </select>
        {activeFunds.length > 1 && (
          <select
            className="input"
            style={{ flex: '1 1 130px', minWidth: 0 }}
            value={fundFilter}
            onChange={(e) => setFundFilter(e.target.value)}
            aria-label="Lọc theo quỹ"
          >
            <option value="all">Tất cả quỹ</option>
            {activeFunds.map((f) => (
              <option key={f.id} value={f.id}>
                {f.name}
              </option>
            ))}
          </select>
        )}
        {warehouses.length > 1 && (
          <select
            className="input"
            style={{ flex: '1 1 130px', minWidth: 0 }}
            value={whFilter}
            onChange={(e) => setWhFilter(e.target.value)}
            aria-label="Lọc theo kho"
          >
            <option value="all">Mọi kho</option>
            {warehouses.map((w) => (
              <option key={w.id} value={w.id}>
                {w.name}
              </option>
            ))}
          </select>
        )}
        {canSettings && (
          <button className="btn" style={{ flex: '0 0 auto' }} onClick={() => setCatSheet(true)} aria-label="Quản lý danh mục thu chi">
            ⚙ Danh mục
          </button>
        )}
      </div>
      {filter === 'custom' && (
        <div className="row" style={{ gap: 8, marginBottom: 12, alignItems: 'center', flexWrap: 'wrap' }}>
          <span className="small muted">Từ ngày</span>
          <input
            type="date"
            className="input"
            style={{ width: 'auto' }}
            value={customFrom}
            max={customTo}
            onChange={(e) => e.target.value && setCustomFrom(e.target.value)}
            aria-label="Từ ngày"
          />
          <span className="small muted">đến</span>
          <input
            type="date"
            className="input"
            style={{ width: 'auto' }}
            value={customTo}
            min={customFrom}
            onChange={(e) => e.target.value && setCustomTo(e.target.value)}
            aria-label="Đến ngày"
          />
        </div>
      )}

      {/* Số dư quỹ */}
      <div className="sb-section" style={{ marginBottom: 12 }}>
        <div style={{ textAlign: 'center' }}>
          <div className="small muted">
            {fundFilter === 'all'
              ? 'Sổ quỹ'
              : (activeFunds.find((f) => f.id === fundFilter)?.name ?? 'Quỹ')}
            {' · '}
            {formatDMY(rangeFrom)} → {formatDMY(rangeTo)}
          </div>
          <div className="row" style={{ gap: 12, marginTop: 8 }}>
            <div className="grow">
              <div className="small muted">Đầu kỳ</div>
              <div className="money" style={{ fontSize: 24, margin: '4px 0' }}>
                {formatVND(periodStats.opening)}
              </div>
            </div>
            <div className="grow">
              <div className="small muted">Cuối kỳ</div>
              <div className="money text-green" style={{ fontSize: 24, margin: '4px 0' }}>
                {formatVND(periodStats.closing)}
              </div>
            </div>
          </div>
        </div>
        <div style={{ marginTop: 4 }}>
          {activeFunds.map((f) => (
            <div
              key={f.id}
              className="row"
              style={{
                justifyContent: 'space-between',
                alignItems: 'center',
                padding: '10px 0',
                borderTop: '1px solid var(--line)',
              }}
            >
              <div>
                <div style={{ fontWeight: 600 }}>{f.name}</div>
                <button
                  type="button"
                  className="small"
                  style={{
                    color: 'var(--brand-dark)',
                    fontWeight: 600,
                    background: 'none',
                    border: 'none',
                    padding: '4px 0',
                    minHeight: 28,
                  }}
                  onClick={() => {
                    if (!canSettings) {
                      toast.show('Chỉ chủ quán mới được sửa số dư đầu kỳ');
                      return;
                    }
                    setFundSheet(f);
                  }}
                >
                  Số dư đầu kỳ: {formatVND(openingDisplay(f))}
                  {canSettings ? ' · Sửa ›' : ''}
                </button>
              </div>
              <b className="money" style={{ fontSize: 18 }}>
                {formatVND(periodStats.perFund.get(f.id)?.closing ?? 0)}
              </b>
            </div>
          ))}
        </div>
        <p className="small muted" style={{ textAlign: 'center', marginTop: 8 }}>
          Mỗi phương thức thanh toán (trừ Ghi nợ) là một quỹ — thêm/sửa phương thức ở Cài đặt.
        </p>
      </div>

      <div className="sb-section" style={{ marginBottom: 12 }}>
        <div className="row" style={{ justifyContent: 'space-between', marginBottom: 10 }}>
          <span className="muted">Chênh lệch (kỳ lọc)</span>
          <b className="money" style={{ fontSize: 22 }}>
            {formatVND(periodStats.thu - periodStats.chi)}
          </b>
        </div>
        <div className="row" style={{ gap: 12 }}>
          <div className="card pastel-green grow" style={{ boxShadow: 'none' }}>
            <div className="small muted">Tổng thu</div>
            <div className="money text-green" style={{ fontSize: 20 }}>
              {formatVND(periodStats.thu)}
            </div>
          </div>
          <div className="card pastel-yellow grow" style={{ boxShadow: 'none' }}>
            <div className="small muted">Tổng chi</div>
            <div className="money text-orange" style={{ fontSize: 20 }}>
              {formatVND(periodStats.chi)}
            </div>
          </div>
        </div>
      </div>

      {busy ? (
        <div className="sb-section muted" style={{ textAlign: 'center' }}>
          Đang tải…
        </div>
      ) : groups.length === 0 ? (
        <div className="sb-section">
          <div className="sb-empty">
            <div className="eico">💸</div>
            <p>
              Chưa có khoản thu chi nào.
              <br />
              Đơn đã thu tiền và thu nợ sẽ tự ghi vào đây.
            </p>
          </div>
        </div>
      ) : (
        groups.map(([day, list]) => (
          <div className="sb-day-group" key={day}>
            <div className="sb-day-label">{vnDayLabel(list[0].created_at)}</div>
            <div className="sb-section" style={{ padding: '4px 16px' }}>
              {list.map((e) => {
                // Khoản từ đơn bán → bấm để mở chi tiết đơn đó ở màn Đơn hàng
                const openOrder = e.ref_type === 'order' && !!e.ref_id;
                const inner = (
                  <>
                    <span
                      className="avatar"
                      style={
                        e.type === 'thu'
                          ? { background: 'var(--green-bg)', color: 'var(--brand-dark)' }
                          : { background: 'var(--orange-bg)', color: 'var(--orange)' }
                      }
                    >
                      {e.type === 'thu' ? '↓' : '↑'}
                    </span>
                    <span className="rbody">
                      <span className="rtitle">
                        {e.note || e.category}
                        {e.ref_type !== 'manual' && (
                          <span className="sb-status-pill" style={{ marginLeft: 6, fontSize: 11 }}>
                            Tự động
                          </span>
                        )}
                      </span>
                      <span className="rsub">
                        {e.ref_type === 'order' && e.ref_code ? `Đơn ${e.ref_code} · ` : ''}
                        {fundFilter === 'all' && activeFunds.length > 1
                          ? `${funds.find((f) => f.id === e.fund_id)?.name ?? ''} · `
                          : ''}
                        {whFilter === 'all' && warehouses.length > 1 && e.warehouse_id
                          ? `${warehouses.find((w) => w.id === e.warehouse_id)?.name ?? ''} · `
                          : ''}
                        {e.note ? `${e.category} · ` : ''}
                        {formatTime(e.created_at)}
                      </span>
                    </span>
                    <span className={`ramount ${e.type === 'thu' ? 'text-green' : 'text-orange'}`}>
                      {e.type === 'thu' ? '+' : '−'}
                      {formatVND(e.amount)}
                    </span>
                    {openOrder && (
                      <span className="chev muted" style={{ fontSize: 22 }}>
                        ›
                      </span>
                    )}
                  </>
                );
                const delBtn = canSettings ? (
                  <button
                    type="button"
                    className="sb-row-del"
                    aria-label="Xóa khoản này"
                    onClick={(ev) => {
                      ev.stopPropagation();
                      void delEntry(e);
                    }}
                  >
                    ×
                  </button>
                ) : null;
                const rowPad = canSettings ? { paddingRight: 42 } : undefined;
                const row = openOrder ? (
                  <button className="sb-row" style={rowPad} onClick={() => navigate(`/orders?open=${e.ref_id}`)}>
                    {inner}
                  </button>
                ) : (
                  <div className="sb-row" style={{ cursor: 'default', ...rowPad }}>
                    {inner}
                  </div>
                );
                return (
                  <div key={e.id} style={{ position: 'relative' }}>
                    {row}
                    {delBtn}
                  </div>
                );
              })}
            </div>
          </div>
        ))
      )}

      <div className="sb-dual-actions">
        <div className="inner">
          <button className="btn btn btn-block btn-lg" onClick={() => setSheet('chi')}>
            Khoản chi
          </button>
          <button className="btn btn-block btn-lg" onClick={() => setSheet('thu')}>
            Khoản thu
          </button>
        </div>
      </div>

      {sheet && (
        <FundEntrySheet
          type={sheet}
          cats={sheet === 'thu' ? cats.thu : cats.chi}
          funds={activeFunds}
          warehouses={warehouses}
          defaultFundId={fundFilter !== 'all' ? fundFilter : undefined}
          defaultWarehouseId={whFilter}
          canManageCats={canSettings}
          onManageCats={() => {
            setSheet(null);
            setCatSheet(true);
          }}
          onClose={() => setSheet(null)}
          onDone={() => {
            setSheet(null);
            void load();
          }}
        />
      )}

      {catSheet && (
        <FundCategorySheet
          cats={cats}
          onClose={() => setCatSheet(false)}
          onDone={(c) => {
            setCats(c);
            setCatSheet(false);
          }}
        />
      )}

      {fundSheet && (
        <FundSheet
          fund={fundSheet}
          warehouses={warehouses}
          defaultWarehouseId={whFilter}
          onClose={() => setFundSheet(null)}
          onDone={(fl) => {
            setFunds(fl);
            setFundSheet(null);
          }}
        />
      )}
    </div>
  );
}

function FundSheet({
  fund,
  warehouses,
  defaultWarehouseId,
  onClose,
  onDone,
}: {
  fund: Fund;
  warehouses: Warehouse[];
  defaultWarehouseId?: string;
  onClose: () => void;
  onDone: (fl: Fund[]) => void;
}) {
  const toast = useToast();
  const [whId, setWhId] = useState(
    defaultWarehouseId && defaultWarehouseId !== 'all'
      ? defaultWarehouseId
      : Object.keys(fund.opening_by_warehouse)[0] ?? warehouses.find((w) => w.is_default)?.id ?? warehouses[0]?.id ?? '',
  );
  const opening = whId ? fund.opening_by_warehouse?.[whId] : undefined;
  const [balance, setBalance] = useState(String(opening?.opening_balance ?? fund.opening_balance));
  const [date, setDate] = useState(opening?.opening_date ?? fund.opening_date);
  const [busy, setBusy] = useState(false);

  const pickWarehouse = (id: string) => {
    setWhId(id);
    const o = fund.opening_by_warehouse?.[id];
    setBalance(String(o?.opening_balance ?? 0));
    setDate(o?.opening_date ?? todayVN());
  };

  const submit = async () => {
    const v = parseInt(balance.replace(/\D/g, ''), 10);
    if (!Number.isFinite(v) || v < 0) {
      toast.show('Nhập số dư hợp lệ');
      return;
    }
    setBusy(true);
    try {
      const fl = await saveFundOpening(fund.id, v, date, whId);
      toast.show(`Đã cập nhật số dư đầu kỳ quỹ ${fund.name}`);
      onDone(fl);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet
      title={`Số dư đầu kỳ — ${fund.name}`}
      onClose={onClose}

      footer={
        <button className="btn btn-block btn-lg" disabled={busy} onClick={submit}>
          {busy ? 'Đang lưu…' : 'Lưu'}
        </button>
      }
    >
      {warehouses.length > 1 && (
        <div className="field">
          <label>Kho</label>
          <div className="row" style={{ flexWrap: 'wrap', gap: 8 }}>
            {warehouses.map((w) => (
              <button
                key={w.id}
                type="button"
                className={`sb-chip${whId === w.id ? ' selected' : ''}`}
                onClick={() => pickWarehouse(w.id)}
              >
                {w.name}
              </button>
            ))}
          </div>
        </div>
      )}
      <div className="field">
        <label>Số dư đầu kỳ{warehouses.length > 1 && whId ? ` — ${warehouses.find((w) => w.id === whId)?.name ?? ''}` : ''}</label>
        <input
          className="sb-money-input"
          inputMode="numeric"
          value={balance}
          onChange={(e) => setBalance(e.target.value)}
          placeholder="0"
        />
      </div>
      <div className="field">
        <label>Tính từ ngày</label>
        <input
          type="date"
          className="input"
          value={date}
          max={todayVN()}
          onChange={(e) => setDate(e.target.value)}
        />
      </div>
      <p className="small muted">
        Số dư quỹ = số dư đầu kỳ + tổng thu − tổng chi của quỹ đó. Đơn {fund.name} tự động ghi
        vào quỹ này.
      </p>
    </Sheet>
  );
}

function FundEntrySheet({
  type,
  cats,
  funds,
  warehouses,
  defaultFundId,
  defaultWarehouseId,
  canManageCats,
  onManageCats,
  onClose,
  onDone,
}: {
  type: CashbookType;
  cats: string[];
  funds: Fund[];
  warehouses: Warehouse[];
  defaultFundId?: string;
  defaultWarehouseId?: string;
  canManageCats: boolean;
  onManageCats: () => void;
  onClose: () => void;
  onDone: () => void;
}) {
  const toast = useToast();
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [category, setCategory] = useState(cats[0] ?? 'Khác');
  const [fundId, setFundId] = useState(
    funds.some((f) => f.id === defaultFundId) ? (defaultFundId as string) : (funds[0]?.id ?? 'cash'),
  );
  const [whId, setWhId] = useState(
    defaultWarehouseId && defaultWarehouseId !== 'all'
      ? defaultWarehouseId
      : warehouses.find((w) => w.is_default)?.id ?? warehouses[0]?.id ?? '',
  );
  const [occurredAt, setOccurredAt] = useState(() => toLocalDateTimeInput());
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    const v = parseInt(amount.replace(/\D/g, ''), 10);
    if (!v || v <= 0) {
      toast.show('Nhập số tiền hợp lệ');
      return;
    }
    setBusy(true);
    try {
      await addCashbookEntry(type, v, note.trim() || null, category, {
        fundId,
        method: funds.find((f) => f.id === fundId)?.kind === 'transfer' ? 'transfer' : 'cash',
        warehouseId: whId || null,
        occurredAt: occurredAt ? new Date(occurredAt).toISOString() : null,
      });
      toast.show(
        type === 'thu' ? `Đã ghi khoản thu ${formatVND(v)}` : `Đã ghi khoản chi ${formatVND(v)}`,
      );
      onDone();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet
      title={type === 'thu' ? 'Khoản thu' : 'Khoản chi'}
      onClose={onClose}
      footer={
        <button
          className={`btn btn-block btn-lg${type === 'chi' ? ' btn' : ''}`}
          disabled={busy}
          onClick={submit}
        >
          {busy ? 'Đang lưu…' : 'Lưu'}
        </button>
      }
    >
      <div className="field">
        <label>Số tiền</label>
        <input
          className="sb-money-input"
          inputMode="numeric"
          placeholder="0"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          autoFocus
        />
      </div>
      <div className="field">
        <label>Quỹ</label>
        <div className="row" style={{ flexWrap: 'wrap', gap: 8 }}>
          {funds.map((f) => (
            <button
              key={f.id}
              type="button"
              className={`sb-chip${fundId === f.id ? ' selected' : ''}`}
              onClick={() => setFundId(f.id)}
            >
              {f.name}
            </button>
          ))}
        </div>
      </div>
      <div className="field">
        <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center' }}>
          <label style={{ margin: 0 }}>Danh mục</label>
          {canManageCats && (
            <button
              type="button"
              className="small"
              style={{ color: 'var(--brand-dark)', fontWeight: 600, background: 'none', border: 'none', padding: 4, minHeight: 32 }}
              onClick={onManageCats}
            >
              Quản lý ›
            </button>
          )}
        </div>
        <div className="row" style={{ flexWrap: 'wrap', gap: 8 }}>
          {cats.map((c) => (
            <button
              key={c}
              type="button"
              className={`sb-chip${category === c ? ' selected' : ''}`}
              onClick={() => setCategory(c)}
            >
              {c}
            </button>
          ))}
        </div>
      </div>
      <div className="field">
        <label>🕐 Thời gian</label>
        <input
          type="datetime-local"
          className="input"
          value={occurredAt}
          onChange={(e) => setOccurredAt(e.target.value)}
        />
      </div>
      {warehouses.length > 1 && (
        <div className="field">
          <label>Kho</label>
          <div className="row" style={{ flexWrap: 'wrap', gap: 8 }}>
            {warehouses.map((w) => (
              <button
                key={w.id}
                type="button"
                className={`sb-chip${whId === w.id ? ' selected' : ''}`}
                onClick={() => setWhId(w.id)}
              >
                {w.name}
              </button>
            ))}
          </div>
        </div>
      )}
      <div className="field">
        <label>Ghi chú (không bắt buộc)</label>
        <input
          className="input"
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="VD: nhập sữa tươi…"
        />
      </div>
    </Sheet>
  );
}

function FundCategorySheet({
  cats,
  onClose,
  onDone,
}: {
  cats: FundCategories;
  onClose: () => void;
  onDone: (c: FundCategories) => void;
}) {
  const toast = useToast();
  const [thu, setThu] = useState<string[]>(cats.thu);
  const [chi, setChi] = useState<string[]>(cats.chi);
  const [newThu, setNewThu] = useState('');
  const [newChi, setNewChi] = useState('');
  const [editing, setEditing] = useState<{ list: 'thu' | 'chi'; idx: number } | null>(null);
  const [editVal, setEditVal] = useState('');
  const [confirmDel, setConfirmDel] = useState<{ list: 'thu' | 'chi'; idx: number } | null>(null);
  const [busy, setBusy] = useState(false);

  const isLocked = (list: 'thu' | 'chi', name: string) =>
    list === 'thu' && LOCKED_THU_CATS.includes(name);
  const getList = (list: 'thu' | 'chi') => (list === 'thu' ? thu : chi);
  const setList = (list: 'thu' | 'chi', v: string[]) =>
    list === 'thu' ? setThu(v) : setChi(v);

  const addItem = (list: 'thu' | 'chi') => {
    const raw = (list === 'thu' ? newThu : newChi).trim().slice(0, 30);
    if (!raw) {
      toast.show('Nhập tên danh mục');
      return;
    }
    const cur = getList(list);
    if (cur.some((c) => c.toLowerCase() === raw.toLowerCase())) {
      toast.show('Danh mục này đã có');
      return;
    }
    if (cur.length >= 30) {
      toast.show('Tối đa 30 danh mục');
      return;
    }
    setList(list, [...cur, raw]);
    if (list === 'thu') setNewThu('');
    else setNewChi('');
  };

  const saveEdit = () => {
    if (!editing) return;
    const raw = editVal.trim().slice(0, 30);
    if (!raw) {
      toast.show('Tên danh mục không được trống');
      return;
    }
    const cur = getList(editing.list);
    if (cur.some((c, i) => i !== editing.idx && c.toLowerCase() === raw.toLowerCase())) {
      toast.show('Danh mục này đã có');
      return;
    }
    const next = [...cur];
    next[editing.idx] = raw;
    setList(editing.list, next);
    setEditing(null);
  };

  const delItem = (list: 'thu' | 'chi', idx: number) => {
    const cur = getList(list);
    if (cur.length <= 1) {
      toast.show('Phải giữ lại ít nhất 1 danh mục');
      return;
    }
    setList(
      list,
      cur.filter((_, i) => i !== idx),
    );
    setConfirmDel(null);
  };

  const save = async () => {
    setBusy(true);
    try {
      const c = await setFundCategories({ thu, chi });
      toast.show('Đã lưu danh mục');
      onDone(c);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  const renderSection = (list: 'thu' | 'chi', title: string) => {
    const cur = getList(list);
    const newVal = list === 'thu' ? newThu : newChi;
    const setNewVal = list === 'thu' ? setNewThu : setNewChi;
    return (
      <div style={{ marginBottom: 20 }}>
        <div style={{ fontWeight: 700, marginBottom: 8 }}>{title}</div>
        {cur.map((c, idx) => {
          const locked = isLocked(list, c);
          const isEditing = editing?.list === list && editing?.idx === idx;
          const isConfirm = confirmDel?.list === list && confirmDel?.idx === idx;
          return (
            <div
              key={`${c}-${idx}`}
              className="row"
              style={{
                justifyContent: 'space-between',
                alignItems: 'center',
                padding: '8px 0',
                borderBottom: '1px solid var(--line)',
              }}
            >
              {isEditing ? (
                <>
                  <input
                    className="input"
                    style={{ flex: 1, marginRight: 8 }}
                    value={editVal}
                    maxLength={30}
                    onChange={(e) => setEditVal(e.target.value)}
                    autoFocus
                  />
                  <div className="row" style={{ gap: 8 }}>
                    <button type="button" className="sb-chip selected" onClick={saveEdit}>
                      Lưu
                    </button>
                    <button type="button" className="sb-chip" onClick={() => setEditing(null)}>
                      Hủy
                    </button>
                  </div>
                </>
              ) : (
                <>
                  <div style={{ fontWeight: 600 }}>
                    {c}
                    {locked && (
                      <span className="sb-status-pill" style={{ marginLeft: 6, fontSize: 11 }}>
                        Mặc định
                      </span>
                    )}
                  </div>
                  {!locked && (
                    <div className="row" style={{ gap: 8 }}>
                      {isConfirm ? (
                        <>
                          <button
                            type="button"
                            className="sb-chip selected"
                            onClick={() => delItem(list, idx)}
                          >
                            Chắc chắn xóa
                          </button>
                          <button
                            type="button"
                            className="sb-chip"
                            onClick={() => setConfirmDel(null)}
                          >
                            Hủy
                          </button>
                        </>
                      ) : (
                        <>
                          <button
                            type="button"
                            className="sb-chip"
                            onClick={() => {
                              setEditing({ list, idx });
                              setEditVal(c);
                              setConfirmDel(null);
                            }}
                          >
                            Sửa
                          </button>
                          <button
                            type="button"
                            className="sb-chip"
                            onClick={() => {
                              setConfirmDel({ list, idx });
                              setEditing(null);
                            }}
                          >
                            Xóa
                          </button>
                        </>
                      )}
                    </div>
                  )}
                </>
              )}
            </div>
          );
        })}
        <div className="row" style={{ gap: 8, marginTop: 10 }}>
          <input
            className="input"
            style={{ flex: 1 }}
            value={newVal}
            maxLength={30}
            onChange={(e) => setNewVal(e.target.value)}
            placeholder="Tên danh mục mới…"
            onKeyDown={(e) => {
              if (e.key === 'Enter') addItem(list);
            }}
          />
          <button type="button" className="sb-chip selected" onClick={() => addItem(list)}>
            + Thêm
          </button>
        </div>
      </div>
    );
  };

  return (
    <Sheet
      title="Danh mục thu chi"
      onClose={onClose}
      footer={
        <button className="btn btn-block btn-lg" disabled={busy} onClick={save}>
          {busy ? 'Đang lưu…' : 'Lưu'}
        </button>
      }
    >
      {renderSection('thu', 'Danh mục khoản thu')}
      {renderSection('chi', 'Danh mục khoản chi')}
      <p className="small muted">
        "Bán hàng" và "Thu nợ" là danh mục mặc định của khoản tự động nên không thể sửa/xóa.
        Xóa danh mục không ảnh hưởng các khoản đã ghi trước đó.
      </p>
    </Sheet>
  );
}
