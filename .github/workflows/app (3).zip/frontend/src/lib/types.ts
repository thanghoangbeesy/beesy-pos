// Kiểu dữ liệu dùng chung — khớp CONTRACT mục 4 & 5

export interface User {
  id: string;
  email: string;
  full_name: string;
  role: 'owner' | 'staff';
}

export interface Category {
  id: string;
  name: string;
  sort_order: number;
  active: boolean;
}

export interface ModifierOption {
  id: string;
  group_id: string;
  name: string;
  price_delta: number;
  sort_order: number;
  active: boolean;
}

export interface ModifierGroup {
  id: string;
  name: string;
  selection_type: 'single' | 'multi';
  required: boolean;
  sort_order: number;
  active: boolean;
  options: ModifierOption[];
}

export interface Product {
  id: string;
  name: string;
  category_id: string | null;
  base_price: number;
  image_url: string | null;
  active: boolean;
  sort_order: number;
}

// Option đã chọn khi bỏ món vào giỏ (snapshot để gửi lên server)
export interface SelectedModifier {
  option_id: string;
  group: string;
  option: string;
  price_delta: number;
}

export interface CartLine {
  key: string;
  product: Product;
  qty: number;
  modifiers: SelectedModifier[];
  note: string;
}

export interface OrderItem {
  id: string;
  order_id: string;
  product_id: string;
  product_name: string;
  qty: number;
  unit_price: number;
  modifiers: SelectedModifier[];
  line_total: number;
  note?: string;
}

export type OrderStatus = 'new' | 'preparing' | 'ready' | 'done' | 'cancelled';

// id của phương thức thanh toán (collection payment_methods).
// Các id hệ thống: 'cash' (tiền mặt), 'transfer' (chuyển khoản), 'debt' (ghi nợ).
export type PaymentMethod = string;
export type PaymentMethodKind = 'cash' | 'transfer' | 'debt';

export interface PaymentMethodDef {
  id: string;
  name: string;
  kind: PaymentMethodKind;
  icon: string;
  bank_bin: string | null;
  bank_account: string | null;
  bank_account_name: string | null;
  active: boolean;
  sort_order: number;
}

export interface Order {
  id: string;
  client_uuid: string;
  code: string;
  business_date: string;
  customer_id: string | null;
  status: OrderStatus;
  payment_method: PaymentMethod;
  payment_method_name: string | null;
  subtotal: number;
  discount: number;
  total: number;
  amount_received: number | null;
  change_amount: number | null;
  note: string | null;
  created_by: string | null;
  created_at: string;
  items: OrderItem[];
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  birthday: string | null;
  address: string | null;
  stamps: number;
  reward_available: boolean;
  debt: number;
  note: string | null;
  created_at: string;
  recent_orders?: Order[];
}

export interface DebtLog {
  id: string;
  amount: number; // dương = ghi nợ thêm, âm = thu nợ
  balance_after: number;
  note: string | null;
  created_by: string | null;
  created_at: string;
}

// Khoản thu/chi của quán: gồm khoản THỦ CÔNG (nhập hàng, mặt bằng, lương...)
// và khoản TỰ ĐỘNG (doanh thu đơn đã thu tiền, thu nợ) — xem ref_type.
export type CashbookType = 'thu' | 'chi';

// Nguồn gốc của khoản thu/chi trong sổ quỹ
export type FundRefType = 'manual' | 'order' | 'debt_pay';

export interface CashbookEntry {
  id: string;
  type: CashbookType;
  amount: number; // > 0
  note: string | null;
  category: string;
  fund_id: string; // quỹ, mặc định 'cash' (Quỹ quán)
  ref_type: FundRefType; // 'manual' = nhập tay; 'order' = từ đơn bán; 'debt_pay' = thu nợ
  ref_id: string | null; // orderId (order) | customerId (debt_pay) | null (manual)
  ref_code: string | null; // mã đơn (A001) cho ref_type='order' — hiện ở Sổ quỹ, bấm để xem đơn
  method: 'cash' | 'transfer' | null; // phương thức của khoản tự động
  created_by: string | null;
  created_at: string; // ISO
}

// Danh mục thu/chi của Sổ quỹ (lưu ở settings/fund_categories)
export interface FundCategories {
  thu: string[];
  chi: string[];
}

// Quỹ tiền (lưu ở settings/funds — mảng). Mỗi quỹ có số dư đầu kỳ riêng.
// fund_id trên CashbookEntry trỏ tới Fund.id ('cash' | 'bank' | id tự sinh).
export interface Fund {
  id: string;
  name: string;
  opening_balance: number;
  opening_date: string; // YYYY-MM-DD
  active: boolean;
  system: boolean; // true = quỹ hệ thống (Tiền mặt/Chuyển khoản): không cho ẩn/xóa
  sort_order: number;
}

// Cài đặt quỹ (lưu ở settings/fund)
export interface FundSettings {
  fund_name: string;
  opening_balance: number;
  opening_date: string; // YYYY-MM-DD
}

export interface DailyReport {
  date: string;
  revenue: number;
  order_count: number;
  by_payment: Record<string, { name: string; count: number; revenue: number }>;
  top_products: { product_id: string; name: string; qty: number; revenue: number }[];
  by_hour: { hour: number; count: number; revenue: number }[];
}

export interface ApiErrorBody {
  error: { code: string; message: string };
}
