import React, { useState, useMemo, useCallback } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TextInput,
  Pressable,
  Image,
  Dimensions,
  Platform,
  Modal,
  ScrollView,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { FlashList } from '@shopify/flash-list';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
} from 'react-native-reanimated';
import * as Haptics from 'expo-haptics';
import { Ionicons } from '@expo/vector-icons';
import { BlurView } from 'expo-blur';

// --- THEME & CONSTANTS (Apple HIG Colors & 8pt Grid) ---
const THEME = {
  primary: '#10B981', // Brand Green Beesy
  background: '#F2F2F7', // iOS System Grouped Background
  cardBackground: '#FFFFFF',
  textPrimary: '#000000',
  textSecondary: '#8E8E93',
  border: 'rgba(60, 60, 67, 0.12)',
  destructive: '#FF3B30',
  separator: '#E5E5EA',
};

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const GRID_SPACING = 12;
const CARD_WIDTH = (SCREEN_WIDTH - 32 - GRID_SPACING) / 2;

export interface ProductItem {
  id: string;
  name: string;
  category: string;
  price: number;
  imageUrl: string;
  isAvailable: boolean;
}

export interface SelectedModifiers {
  size: 'M' | 'L';
  sugar: '0%' | '30%' | '50%' | '70%' | '100%';
  ice: '0%' | '50%' | '100%';
  toppings: string[];
}

export interface CartItem {
  id: string;
  product: ProductItem;
  quantity: number;
  modifiers: SelectedModifiers;
  unitPrice: number;
}

const MODIFIER_OPTIONS = {
  sizes: [
    { label: 'Size Vừa (M)', value: 'M', extraPrice: 0 },
    { label: 'Size Lớn (L)', value: 'L', extraPrice: 6000 },
  ],
  sugarLevels: ['100%', '70%', '50%', '30%', '0%'] as const,
  iceLevels: ['100%', '50%', '0%'] as const,
  toppings: [
    { id: 't1', name: 'Trân châu trắng', price: 6000 },
    { id: 't2', name: 'Thạch nha đam', price: 6000 },
    { id: 't3', name: 'Kem Cheese', price: 10000 },
    { id: 't4', name: 'Đào miếng', price: 8000 },
  ],
};

const CATEGORIES = [
  'Tất cả',
  'Cà phê',
  'Trà trái cây',
  'Nước ép',
  'Trà sữa',
  'Sữa chua',
];

const MOCK_PRODUCTS: ProductItem[] = [
  {
    id: 'p1',
    name: 'Trà Tắc',
    category: 'Trà trái cây',
    price: 15000,
    imageUrl: 'https://images.unsplash.com/photo-1556679343-c7306c1976bc?w=400&q=80',
    isAvailable: true,
  },
  {
    id: 'p2',
    name: 'Nước Ép Lựu',
    category: 'Nước ép',
    price: 30000,
    imageUrl: 'https://images.unsplash.com/photo-1621506289937-a8e4df240d0b?w=400&q=80',
    isAvailable: true,
  },
  {
    id: 'p3',
    name: 'Cafe Sữa',
    category: 'Cà phê',
    price: 20000,
    imageUrl: 'https://images.unsplash.com/photo-1517701604599-bb29b565090c?w=400&q=80',
    isAvailable: true,
  },
  {
    id: 'p4',
    name: 'Nước Cam Ép',
    category: 'Nước ép',
    price: 25000,
    imageUrl: 'https://images.unsplash.com/photo-1613478223719-2ab802602423?w=400&q=80',
    isAvailable: true,
  },
  {
    id: 'p5',
    name: 'Nước Chanh Leo',
    category: 'Nước ép',
    price: 20000,
    imageUrl: 'https://images.unsplash.com/photo-1534353436294-0dbd4bdac845?w=400&q=80',
    isAvailable: false,
  },
  {
    id: 'p6',
    name: 'Trà Ổi Hồng',
    category: 'Trà trái cây',
    price: 25000,
    imageUrl: 'https://images.unsplash.com/photo-1595981267035-7b04ca84a82d?w=400&q=80',
    isAvailable: true,
  },
  {
    id: 'p7',
    name: 'Cafe Muối',
    category: 'Cà phê',
    price: 25000,
    imageUrl: 'https://images.unsplash.com/photo-1541167760496-1628856ab772?w=400&q=80',
    isAvailable: true,
  },
  {
    id: 'p8',
    name: 'Matcha Latte',
    category: 'Trà sữa',
    price: 25000,
    imageUrl: 'https://images.unsplash.com/photo-1536256263959-770b48d82b0a?w=400&q=80',
    isAvailable: true,
  },
];

const formatVND = (amount: number) => {
  return new Intl.NumberFormat('vi-VN', {
    style: 'currency',
    currency: 'VND',
  }).format(amount);
};

interface ModifierModalProps {
  visible: boolean;
  product: ProductItem | null;
  onClose: () => void;
  onConfirm: (product: ProductItem, modifiers: SelectedModifiers, unitPrice: number) => void;
}

const ModifierModal: React.FC<ModifierModalProps> = ({
  visible,
  product,
  onClose,
  onConfirm,
}) => {
  const insets = useSafeAreaInsets();
  const [size, setSize] = useState<'M' | 'L'>('M');
  const [sugar, setSugar] = useState<'0%' | '30%' | '50%' | '70%' | '100%'>('100%');
  const [ice, setIce] = useState<'0%' | '50%' | '100%'>('100%');
  const [selectedToppings, setSelectedToppings] = useState<string[]>([]);

  React.useEffect(() => {
    if (visible) {
      setSize('M');
      setSugar('100%');
      setIce('100%');
      setSelectedToppings([]);
    }
  }, [visible, product]);

  const unitPrice = useMemo(() => {
    if (!product) return 0;
    let total = product.price;
    const sizeConfig = MODIFIER_OPTIONS.sizes.find((s) => s.value === size);
    if (sizeConfig) total += sizeConfig.extraPrice;

    selectedToppings.forEach((topName) => {
      const topConfig = MODIFIER_OPTIONS.toppings.find((t) => t.name === topName);
      if (topConfig) total += topConfig.price;
    });

    return total;
  }, [product, size, selectedToppings]);

  if (!product) return null;

  const toggleTopping = (toppingName: string) => {
    Haptics.selectionAsync();
    setSelectedToppings((prev) =>
      prev.includes(toppingName)
        ? prev.filter((item) => item !== toppingName)
        : [...prev, toppingName]
    );
  };

  const handleConfirm = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    onConfirm(
      product,
      { size, sugar, ice, toppings: selectedToppings },
      unitPrice
    );
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <Pressable style={styles.modalBackdrop} onPress={onClose} />
        <View style={[styles.modalSheet, { paddingBottom: Math.max(insets.bottom, 16) }]}>
          <View style={styles.grabberHandle} />

          <View style={styles.modalHeader}>
            <View style={{ flex: 1 }}>
              <Text style={styles.modalTitle}>{product.name}</Text>
              <Text style={styles.modalPrice}>{formatVND(unitPrice)}</Text>
            </View>
            <Pressable
              onPress={onClose}
              hitSlop={12}
              style={({ pressed }) => [styles.closeIconBtn, pressed && { opacity: 0.6 }]}
            >
              <Ionicons name="close-circle" size={28} color="#C7C7CC" />
            </Pressable>
          </View>

          <ScrollView style={styles.modalScroll} showsVerticalScrollIndicator={false}>
            <Text style={styles.sectionHeader}>CHỌN SIZE</Text>
            <View style={styles.optionGroup}>
              {MODIFIER_OPTIONS.sizes.map((s) => {
                const isSelected = size === s.value;
                return (
                  <Pressable
                    key={s.value}
                    onPress={() => {
                      Haptics.selectionAsync();
                      setSize(s.value as 'M' | 'L');
                    }}
                    style={[styles.rowItem, isSelected && styles.rowItemSelected]}
                  >
                    <View style={styles.radioOuter}>
                      {isSelected && <View style={styles.radioInner} />}
                    </View>
                    <Text style={styles.rowLabel}>{s.label}</Text>
                    {s.extraPrice > 0 && (
                      <Text style={styles.extraPriceText}>+{formatVND(s.extraPrice)}</Text>
                    )}
                  </Pressable>
                );
              })}
            </View>

            <Text style={styles.sectionHeader}>LƯỢNG ĐƯỜNG</Text>
            <View style={styles.segmentContainer}>
              {MODIFIER_OPTIONS.sugarLevels.map((lvl) => {
                const isSelected = sugar === lvl;
                return (
                  <Pressable
                    key={lvl}
                    onPress={() => {
                      Haptics.selectionAsync();
                      setSugar(lvl);
                    }}
                    style={[styles.segmentButton, isSelected && styles.segmentButtonActive]}
                  >
                    <Text
                      style={[styles.segmentLabel, isSelected && styles.segmentLabelActive]}
                    >
                      {lvl}
                    </Text>
                  </Pressable>
                );
              })}
            </View>

            <Text style={styles.sectionHeader}>LƯỢNG ĐÁ</Text>
            <View style={styles.segmentContainer}>
              {MODIFIER_OPTIONS.iceLevels.map((lvl) => {
                const isSelected = ice === lvl;
                return (
                  <Pressable
                    key={lvl}
                    onPress={() => {
                      Haptics.selectionAsync();
                      setIce(lvl);
                    }}
                    style={[styles.segmentButton, isSelected && styles.segmentButtonActive]}
                  >
                    <Text
                      style={[styles.segmentLabel, isSelected && styles.segmentLabelActive]}
                    >
                      {lvl}
                    </Text>
                  </Pressable>
                );
              })}
            </View>

            <Text style={styles.sectionHeader}>TOPPING THÊM</Text>
            <View style={styles.optionGroup}>
              {MODIFIER_OPTIONS.toppings.map((top) => {
                const isChecked = selectedToppings.includes(top.name);
                return (
                  <Pressable
                    key={top.id}
                    onPress={() => toggleTopping(top.name)}
                    style={[styles.rowItem, isChecked && styles.rowItemSelected]}
                  >
                    <View style={[styles.checkboxOuter, isChecked && styles.checkboxOuterActive]}>
                      {isChecked && <Ionicons name="checkmark" size={14} color="#FFFFFF" />}
                    </View>
                    <Text style={styles.rowLabel}>{top.name}</Text>
                    <Text style={styles.extraPriceText}>+{formatVND(top.price)}</Text>
                  </Pressable>
                );
              })}
            </View>
          </ScrollView>

          <View style={styles.modalFooter}>
            <Pressable
              onPress={handleConfirm}
              style={({ pressed }) => [
                styles.confirmButton,
                pressed && { opacity: 0.85, transform: [{ scale: 0.98 }] },
              ]}
            >
              <Text style={styles.confirmButtonText}>
                Thêm vào đơn • {formatVND(unitPrice)}
              </Text>
            </Pressable>
          </View>
        </View>
      </View>
    </Modal>
  );
};

interface ProductCardProps {
  item: ProductItem;
  quantityInCart: number;
  onSelect: (item: ProductItem) => void;
  onQuickAdd: (item: ProductItem) => void;
}

const ProductCard: React.FC<ProductCardProps> = React.memo(
  ({ item, quantityInCart, onSelect, onQuickAdd }) => {
    const scale = useSharedValue(1);

    const animatedStyle = useAnimatedStyle(() => ({
      transform: [{ scale: scale.value }],
    }));

    const handlePressIn = () => {
      if (!item.isAvailable) return;
      scale.value = withSpring(0.96, { damping: 15, stiffness: 300 });
    };

    const handlePressOut = () => {
      if (!item.isAvailable) return;
      scale.value = withSpring(1, { damping: 15, stiffness: 300 });
    };

    const handleCardPress = () => {
      if (!item.isAvailable) return;
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      onSelect(item);
    };

    const handleQuickAddPress = () => {
      if (!item.isAvailable) return;
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      onQuickAdd(item);
    };

    return (
      <Animated.View style={[styles.cardWrapper, animatedStyle]}>
        <Pressable
          onPress={handleCardPress}
          onPressIn={handlePressIn}
          onPressOut={handlePressOut}
          disabled={!item.isAvailable}
          style={[styles.cardContainer, !item.isAvailable && styles.cardDisabled]}
        >
          <View style={styles.imageWrapper}>
            <Image
              source={{ uri: item.imageUrl }}
              style={styles.cardImage}
              resizeMode="cover"
            />
            {quantityInCart > 0 && (
              <View style={styles.cartBadge}>
                <Text style={styles.cartBadgeText}>{quantityInCart}</Text>
              </View>
            )}

            {!item.isAvailable && (
              <View style={styles.outOfStockOverlay}>
                <View style={styles.outOfStockBadge}>
                  <Text style={styles.outOfStockText}>HẾT HÀNG</Text>
                </View>
              </View>
            )}
          </View>

          <View style={styles.cardBody}>
            <Text
              style={styles.productName}
              numberOfLines={2}
              ellipsizeMode="tail"
            >
              {item.name}
            </Text>

            <View style={styles.cardFooter}>
              <Text style={styles.productPrice}>{formatVND(item.price)}</Text>

              <Pressable
                onPress={handleQuickAddPress}
                disabled={!item.isAvailable}
                hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                style={({ pressed }) => [
                  styles.quickAddButton,
                  pressed && { opacity: 0.7 },
                ]}
              >
                <Ionicons name="add" size={20} color="#FFFFFF" />
              </Pressable>
            </View>
          </View>
        </Pressable>
      </Animated.View>
    );
  }
);

export default function OrderMenuScreen() {
  const insets = useSafeAreaInsets();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Tất cả');
  const [cart, setCart] = useState<{ [cartKey: string]: CartItem }>({});
  const [orderType, setOrderType] = useState<'dine-in' | 'takeaway'>('dine-in');
  const [activeModalProduct, setActiveModalProduct] = useState<ProductItem | null>(null);

  const filteredProducts = useMemo(() => {
    return MOCK_PRODUCTS.filter((p) => {
      const matchCat =
        selectedCategory === 'Tất cả' || p.category === selectedCategory;
      const matchSearch = p.name
        .toLowerCase()
        .includes(searchQuery.trim().toLowerCase());
      return matchCat && matchSearch;
    });
  }, [searchQuery, selectedCategory]);

  const handleQuickAdd = useCallback((product: ProductItem) => {
    const defaultModifiers: SelectedModifiers = {
      size: 'M',
      sugar: '100%',
      ice: '100%',
      toppings: [],
    };
    const key = `${product.id}_M_100_100`;

    setCart((prev) => {
      const current = prev[key];
      return {
        ...prev,
        [key]: {
          id: key,
          product,
          quantity: (current?.quantity || 0) + 1,
          modifiers: defaultModifiers,
          unitPrice: product.price,
        },
      };
    });
  }, []);

  const handleConfirmCustomized = useCallback(
    (product: ProductItem, modifiers: SelectedModifiers, unitPrice: number) => {
      const key = `${product.id}_${modifiers.size}_${modifiers.sugar}_${modifiers.ice}_${modifiers.toppings.sort().join('-')}`;

      setCart((prev) => {
        const current = prev[key];
        return {
          ...prev,
          [key]: {
            id: key,
            product,
            quantity: (current?.quantity || 0) + 1,
            modifiers,
            unitPrice,
          },
        };
      });
      setActiveModalProduct(null);
    },
    []
  );

  const productQuantities = useMemo(() => {
    const counts: { [productId: string]: number } = {};
    Object.values(cart).forEach((item) => {
      counts[item.product.id] = (counts[item.product.id] || 0) + item.quantity;
    });
    return counts;
  }, [cart]);

  const { totalQuantity, totalPrice } = useMemo(() => {
    let qty = 0;
    let price = 0;
    Object.values(cart).forEach((item) => {
      qty += item.quantity;
      price += item.quantity * item.unitPrice;
    });
    return { totalQuantity: qty, totalPrice: price };
  }, [cart]);

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <View style={styles.topHeader}>
        <View style={styles.headerLeft}>
          <Text style={styles.headerTitle}>Beesy POS</Text>
          <Text style={styles.headerSubtitle}>Bàn số 04 • Mang đi</Text>
        </View>

        <View style={styles.headerRight}>
          <Pressable
            style={styles.segmentedToggle}
            onPress={() => {
              Haptics.selectionAsync();
              setOrderType(orderType === 'dine-in' ? 'takeaway' : 'dine-in');
            }}
          >
            <Ionicons
              name={orderType === 'dine-in' ? 'restaurant-outline' : 'bag-handle-outline'}
              size={18}
              color={THEME.textPrimary}
            />
            <Text style={styles.segmentedText}>
              {orderType === 'dine-in' ? 'Tại quầy' : 'Mang về'}
            </Text>
          </Pressable>
        </View>
      </View>

      <View style={styles.searchContainer}>
        <View style={styles.searchField}>
          <Ionicons name="search" size={18} color={THEME.textSecondary} />
          <TextInput
            placeholder="Tìm kiếm đồ uống, bánh mì..."
            placeholderTextColor={THEME.textSecondary}
            value={searchQuery}
            onChangeText={setSearchQuery}
            clearButtonMode="while-editing"
            style={styles.searchInput}
          />
        </View>
      </View>

      <View style={styles.categoriesWrapper}>
        <FlashList
          horizontal
          showsHorizontalScrollIndicator={false}
          data={CATEGORIES}
          estimatedItemSize={90}
          contentContainerStyle={styles.categoriesList}
          renderItem={({ item }) => {
            const isSelected = selectedCategory === item;
            return (
              <Pressable
                onPress={() => {
                  Haptics.selectionAsync();
                  setSelectedCategory(item);
                }}
                style={[
                  styles.categoryPill,
                  isSelected && styles.categoryPillActive,
                ]}
              >
                <Text
                  style={[
                    styles.categoryText,
                    isSelected && styles.categoryTextActive,
                  ]}
                >
                  {item}
                </Text>
              </Pressable>
            );
          }}
        />
      </View>

      <View style={styles.gridContainer}>
        <FlashList
          data={filteredProducts}
          numColumns={2}
          estimatedItemSize={230}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[
            styles.productListContent,
            { paddingBottom: totalQuantity > 0 ? 120 : insets.bottom + 20 },
          ]}
          renderItem={({ item }) => (
            <ProductCard
              item={item}
              quantityInCart={productQuantities[item.id] || 0}
              onSelect={(p) => setActiveModalProduct(p)}
              onQuickAdd={handleQuickAdd}
            />
          )}
          keyExtractor={(item) => item.id}
        />
      </View>

      {totalQuantity > 0 && (
        <View
          style={[
            styles.floatingCartContainer,
            { bottom: Math.max(insets.bottom, 16) },
          ]}
        >
          <BlurView
            intensity={Platform.OS === 'ios' ? 70 : 100}
            tint="dark"
            style={styles.floatingCartBlur}
          >
            <Pressable
              style={styles.floatingCartInner}
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
              }}
            >
              <View style={styles.cartInfoSection}>
                <View style={styles.cartCountBadge}>
                  <Text style={styles.cartCountText}>{totalQuantity}</Text>
                </View>
                <View>
                  <Text style={styles.cartTitle}>Giỏ hàng</Text>
                  <Text style={styles.cartSubTitle}>Nhấn để xác nhận</Text>
                </View>
              </View>

              <View style={styles.cartActionSection}>
                <Text style={styles.cartTotalPrice}>
                  {formatVND(totalPrice)}
                </Text>
                <View style={styles.arrowIcon}>
                  <Ionicons name="arrow-forward" size={18} color="#FFFFFF" />
                </View>
              </View>
            </Pressable>
          </BlurView>
        </View>
      )}

      <ModifierModal
        visible={!!activeModalProduct}
        product={activeModalProduct}
        onClose={() => setActiveModalProduct(null)}
        onConfirm={handleConfirmCustomized}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: THEME.background,
  },
  topHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingTop: 8,
    paddingBottom: 10,
  },
  headerLeft: {
    flex: 1,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: THEME.textPrimary,
    letterSpacing: -0.4,
  },
  headerSubtitle: {
    fontSize: 13,
    color: THEME.textSecondary,
    marginTop: 2,
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  segmentedToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#E5E5EA',
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 20,
    gap: 6,
    minHeight: 44,
  },
  segmentedText: {
    fontSize: 13,
    fontWeight: '600',
    color: THEME.textPrimary,
  },
  searchContainer: {
    paddingHorizontal: 16,
    paddingBottom: 8,
  },
  searchField: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#E3E3E8',
    borderRadius: 10,
    paddingHorizontal: 10,
    height: 38,
  },
  searchInput: {
    flex: 1,
    marginLeft: 8,
    fontSize: 15,
    color: THEME.textPrimary,
  },
  categoriesWrapper: {
    height: 48,
    marginBottom: 4,
  },
  categoriesList: {
    paddingHorizontal: 16,
    alignItems: 'center',
  },
  categoryPill: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: THEME.cardBackground,
    marginRight: 8,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: THEME.border,
    minHeight: 36,
    justifyContent: 'center',
  },
  categoryPillActive: {
    backgroundColor: THEME.textPrimary,
    borderColor: THEME.textPrimary,
  },
  categoryText: {
    fontSize: 14,
    fontWeight: '500',
    color: THEME.textPrimary,
  },
  categoryTextActive: {
    color: '#FFFFFF',
    fontWeight: '600',
  },
  gridContainer: {
    flex: 1,
  },
  productListContent: {
    paddingHorizontal: 16,
    paddingTop: 8,
  },
  cardWrapper: {
    width: CARD_WIDTH,
    marginBottom: GRID_SPACING,
    marginRight: GRID_SPACING,
  },
  cardContainer: {
    backgroundColor: THEME.cardBackground,
    borderRadius: 16,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: THEME.border,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 2,
  },
  cardDisabled: {
    opacity: 0.65,
  },
  imageWrapper: {
    width: '100%',
    height: CARD_WIDTH * 0.85,
    backgroundColor: '#F2F2F7',
    position: 'relative',
  },
  cardImage: {
    width: '100%',
    height: '100%',
  },
  cartBadge: {
    position: 'absolute',
    top: 8,
    left: 8,
    backgroundColor: THEME.primary,
    borderRadius: 12,
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  cartBadgeText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '700',
  },
  outOfStockOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(255, 255, 255, 0.6)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  outOfStockBadge: {
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 6,
  },
  outOfStockText: {
    color: '#FFFFFF',
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
  cardBody: {
    padding: 12,
  },
  productName: {
    fontSize: 15,
    fontWeight: '600',
    color: THEME.textPrimary,
    lineHeight: 20,
    minHeight: 40,
  },
  cardFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 8,
  },
  productPrice: {
    fontSize: 15,
    fontWeight: '700',
    color: THEME.primary,
  },
  quickAddButton: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: THEME.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  floatingCartContainer: {
    position: 'absolute',
    left: 16,
    right: 16,
    borderRadius: 24,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.15,
    shadowRadius: 16,
    elevation: 8,
  },
  floatingCartBlur: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: Platform.OS === 'android' ? 'rgba(28, 28, 30, 0.95)' : 'transparent',
  },
  floatingCartInner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    minHeight: 44,
  },
  cartInfoSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  cartCountBadge: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: THEME.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cartCountText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '700',
  },
  cartTitle: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  cartSubTitle: {
    color: 'rgba(255, 255, 255, 0.6)',
    fontSize: 12,
  },
  cartActionSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  cartTotalPrice: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '700',
  },
  arrowIcon: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalOverlay: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
  },
  modalBackdrop: {
    ...StyleSheet.absoluteFillObject,
  },
  modalSheet: {
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    maxHeight: '85%',
    paddingTop: 8,
  },
  grabberHandle: {
    width: 36,
    height: 5,
    borderRadius: 2.5,
    backgroundColor: '#D1D1D6',
    alignSelf: 'center',
    marginBottom: 8,
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderColor: THEME.separator,
  },
  modalTitle: {
    fontSize: 19,
    fontWeight: '700',
    color: THEME.textPrimary,
  },
  modalPrice: {
    fontSize: 16,
    fontWeight: '600',
    color: THEME.primary,
    marginTop: 2,
  },
  closeIconBtn: {
    padding: 4,
  },
  modalScroll: {
    paddingHorizontal: 20,
  },
  sectionHeader: {
    fontSize: 12,
    fontWeight: '600',
    color: THEME.textSecondary,
    letterSpacing: 0.6,
    marginTop: 18,
    marginBottom: 8,
  },
  optionGroup: {
    backgroundColor: '#F8F9FA',
    borderRadius: 14,
    overflow: 'hidden',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: THEME.border,
  },
  rowItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingVertical: 14,
    minHeight: 48,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderColor: THEME.border,
  },
  rowItemSelected: {
    backgroundColor: '#F0FDF4',
  },
  rowLabel: {
    flex: 1,
    fontSize: 15,
    fontWeight: '500',
    color: THEME.textPrimary,
    marginLeft: 12,
  },
  extraPriceText: {
    fontSize: 14,
    fontWeight: '600',
    color: THEME.textSecondary,
  },
  radioOuter: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: THEME.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  radioInner: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: THEME.primary,
  },
  checkboxOuter: {
    width: 20,
    height: 20,
    borderRadius: 6,
    borderWidth: 1.5,
    borderColor: '#C7C7CC',
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkboxOuterActive: {
    backgroundColor: THEME.primary,
    borderColor: THEME.primary,
  },
  segmentContainer: {
    flexDirection: 'row',
    backgroundColor: '#E5E5EA',
    borderRadius: 10,
    padding: 3,
  },
  segmentButton: {
    flex: 1,
    paddingVertical: 8,
    alignItems: 'center',
    borderRadius: 8,
  },
  segmentButtonActive: {
    backgroundColor: '#FFFFFF',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  segmentLabel: {
    fontSize: 13,
    fontWeight: '500',
    color: THEME.textSecondary,
  },
  segmentLabelActive: {
    color: THEME.textPrimary,
    fontWeight: '700',
  },
  modalFooter: {
    paddingHorizontal: 20,
    paddingTop: 12,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderColor: THEME.separator,
  },
  confirmButton: {
    backgroundColor: THEME.primary,
    borderRadius: 16,
    height: 52,
    alignItems: 'center',
    justifyContent: 'center',
  },
  confirmButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
});
