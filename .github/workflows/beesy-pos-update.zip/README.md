# Beesy POS - Mobile Order Screen (Apple HIG)

Giao diện bán hàng tại quầy chuẩn Apple HIG dành cho Beesy Coffee & Tea viết bằng Expo Router.

### Cài đặt và chạy:
1. `npm install`
2. `npx expo start`
