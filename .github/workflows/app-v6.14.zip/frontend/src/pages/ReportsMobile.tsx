import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { DbError, applyGoodsCosts, applyGoodsCostsToPoint, getAllowedWarehouses, getDailyBreakdown, getDailyExpenses, getDailyPurchaseCosts, getHourlyBreakdown, getRangeReport } from '../lib/db';
import {
  addDaysVN,
  endOfMonthVN,
  formatDMY,
  formatVND,
  startOfMonthVN,
  startOfWeekVN,
  todayVN,
} from '../lib/format';
import { useToast } from '../components/Toast';
import { LowStockPanel, useStockOverview } from '../components/StockOverview';
import { useAuth } from '../lib/auth';
import { TIcon } from '../components/TIcon';
import type { DailyReport, Warehouse } from '../lib/types';

type PresetKey = 'today' | 'yesterday' | 'thisWeek' | 'lastWeek' | 'thisMonth' | 'lastMonth';

const PRESETS: { key: PresetKey; label: string }[] = [
  { key: 'today', label: 'Hôm nay' },
  { key: 'yesterday', label: 'Hôm qua' },
  { key: 'thisWeek', label: 'Tuần này' },
  { key: 'lastWeek', label: 'Tuần trước' },
  { key: 'thisMonth', label: 'Tháng này' },
  { key: 'lastMonth', label: 'Tháng trước' },
];

function presetRange(key: PresetKey): [string, string] {
  const t = todayVN();
  switch (key) {
    case 'today': return [t, t];
    case 'yesterday': { const y = addDaysVN(t, -1); return [y, y]; }
    case 'thisWeek': return [startOfWeekVN(t), t];
    case 'lastWeek': {
      const mondayThis = startOfWeekVN(t);
      const mondayLast = addDaysVN(mondayThis, -7);
      return [mondayLast, addDaysVN(mondayLast, 6)];
    }
    case 'thisMonth': return [startOfMonthVN(t), t];
    case 'lastMonth': {
      const firstThisMonth = startOfMonthVN(t);
      const lastDayPrev = addDaysVN(firstThisMonth, -1);
      return [startOfMonthVN(lastDayPrev), lastDayPrev];
    }
  }
}

/** Kỳ trước tương ứng để so sánh. */
function prevRange(key: PresetKey): [string, string] {
  const t = todayVN();
  switch (key) {
    case 'today': { const y = addDaysVN(t, -1); return [y, y]; }
    case 'yesterday': { const y = addDaysVN(t, -2); return [y, y]; }
    case 'thisWeek': {
      const mondayThis = startOfWeekVN(t);
      const mondayLast = addDaysVN(mondayThis, -7);
      return [mondayLast, addDaysVN(mondayLast, 6)];
    }
    case 'lastWeek': {
      const mondayThis = startOfWeekVN(t);
      const mondayLast2 = addDaysVN(mondayThis, -14);
      return [mondayLast2, addDaysVN(mondayLast2, 6)];
    }
    case 'thisMonth': {
      const firstThisMonth = startOfMonthVN(t);
      const lastDayPrev = addDaysVN(firstThisMonth, -1);
      return [startOfMonthVN(lastDayPrev), lastDayPrev];
    }
    case 'lastMonth': {
      const firstThisMonth = startOfMonthVN(t);
      const lastDayPrev = addDaysVN(firstThisMonth, -1);
      const firstPrev = startOfMonthVN(lastDayPrev);
      const lastDayPrev2 = addDaysVN(firstPrev, -1);
      return [startOfMonthVN(lastDayPrev2), lastDayPrev2];
    }
  }
}

/** Nhãn kỳ này / kỳ trước cho tiêu đề biểu đồ so sánh (kỳ trước viết thường
 *  để ghép câu "Kỳ này so với kỳ trước", ví dụ "Hôm nay so với hôm qua"). */
function chartLabels(key: PresetKey): { cur: string; prev: string } {
  switch (key) {
    case 'today': return { cur: 'Hôm nay', prev: 'hôm qua' };
    case 'yesterday': return { cur: 'Hôm qua', prev: 'hôm kia' };
    case 'thisWeek': return { cur: 'Tuần này', prev: 'tuần trước' };
    case 'lastWeek': return { cur: 'Tuần trước', prev: 'tuần trước nữa' };
    case 'thisMonth': return { cur: 'Tháng này', prev: 'tháng trước' };
    case 'lastMonth': return { cur: 'Tháng trước', prev: 'tháng trước nữa' };
  }
}

function cap(s: string): string {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

type ChartMetric = 'revenue' | 'profit' | 'expense';

/** Muc cua bieu do cot: mau cot ky nay dam, cot ky truoc nhat cung mau. */
const METRICS: { key: ChartMetric; label: string; curColor: string; prevColor: string }[] = [
  { key: 'revenue', label: 'Doanh thu', curColor: '#00B14F', prevColor: '#86EFAC' },
  { key: 'profit', label: 'Lợi nhuận', curColor: '#2563EB', prevColor: '#93C5FD' },
  { key: 'expense', label: 'Chi phí', curColor: '#DC2626', prevColor: '#FCA5A5' },
];

/** 1 điểm trên biểu đồ so sánh: nhãn trục + chi tiết tooltip + 2 cặp số.
 *  Chi phí mặc định = chi phí vận hành (tách riêng, không phải giá vốn);
 *  bật công tắc "tính chi phí nhập hàng + nguyên liệu" thì cộng thêm
 *  purchase (tiền nhập hàng) + cost (giá vốn) vào chi phí, lợi nhuận trừ thêm purchase. */
interface ChartPoint {
  key: string;
  label: string;
  detail: string;
  thisRevenue: number;
  thisProfit: number;
  thisExpense: number;
  thisPurchase: number;
  thisCost: number;
  lastRevenue: number;
  lastProfit: number;
  lastExpense: number;
  lastPurchase: number;
  lastCost: number;
}

type ChartMode = 'hour' | 'week' | 'month';

function pctChange(cur: number, prev: number): number | null {
  if (prev === 0) return cur > 0 ? 100 : null;
  return ((cur - prev) / prev) * 100;
}

export function ReportsMobile() {
  const toast = useToast();
  const { can } = useAuth();
  const navigate = useNavigate();
  const [preset, setPreset] = useState<PresetKey>('today');
  const [report, setReport] = useState<DailyReport | null>(null);
  const [prevReport, setPrevReport] = useState<DailyReport | null>(null);
  const [chartData, setChartData] = useState<ChartPoint[]>([]);
  const [chartMeta, setChartMeta] = useState<{ mode: ChartMode; cur: string; prev: string }>({ mode: 'hour', cur: 'Hôm nay', prev: 'hôm qua' });
  const [chartMetric, setChartMetric] = useState<ChartMetric>('revenue');
  const [includeGoods, setIncludeGoods] = useState(false);
  const [selectedIdx, setSelectedIdx] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [isOwner, setIsOwner] = useState(false);
  const { low } = useStockOverview(warehouses);
  const [topSort, setTopSort] = useState<'qty' | 'revenue' | 'profit'>('qty');
  const [topDir, setTopDir] = useState<'desc' | 'asc'>('desc');

  const load = useCallback(async (key: PresetKey, ids?: string[]) => {
    setBusy(true);
    try {
      const [s, e] = presetRange(key);
      const [ps, pe] = prevRange(key);
      const t = todayVN();
      const [cur, prev] = await Promise.all([
        getRangeReport(s, e, ids),
        getRangeReport(ps, pe, ids),
      ]);
      setReport(cur);
      setPrevReport(prev);
      // Biểu đồ so sánh chạy theo kỳ đã chọn (v6.4): kỳ 1 ngày -> theo giờ
      // (24 giờ, kỳ trước là ngày liền trước); kỳ nhiều ngày -> theo ngày
      // (tuần: T2-CN, kỳ trước là tuần liền trước; tháng: ngày 1-31, kỳ trước
      // là tháng liền trước, ngày không có trong tháng trước tính 0).
      const meta = chartLabels(key);
      if (key === 'today' || key === 'yesterday') {
        const [day] = presetRange(key);
        const [prevDay] = prevRange(key);
        const hours = await getHourlyBreakdown(day, prevDay, ids);
        setChartData(hours.map((h) => ({
          key: String(h.hour),
          label: String(h.hour),
          detail: `${h.hour}h`,
          thisRevenue: h.curRevenue,
          thisProfit: h.curProfit,
          thisExpense: h.curExpense,
          thisPurchase: h.curPurchase,
          thisCost: h.curCost,
          lastRevenue: h.prevRevenue,
          lastProfit: h.prevProfit,
          lastExpense: h.prevExpense,
          lastPurchase: h.prevPurchase,
          lastCost: h.prevCost,
        })));
        setChartMeta({ mode: 'hour', ...meta });
      } else if (key === 'thisWeek' || key === 'lastWeek') {
        const mondayThis = startOfWeekVN(t);
        const curMon = key === 'thisWeek' ? mondayThis : addDaysVN(mondayThis, -7);
        const prevMon = addDaysVN(curMon, -7);
        const dayLabels = ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'];
        const [curDays, prevDays, curExp, prevExp, curPur, prevPur] = await Promise.all([
          getDailyBreakdown(curMon, addDaysVN(curMon, 6), ids),
          getDailyBreakdown(prevMon, addDaysVN(prevMon, 6), ids),
          getDailyExpenses(curMon, addDaysVN(curMon, 6), ids),
          getDailyExpenses(prevMon, addDaysVN(prevMon, 6), ids),
          getDailyPurchaseCosts(curMon, addDaysVN(curMon, 6), ids),
          getDailyPurchaseCosts(prevMon, addDaysVN(prevMon, 6), ids),
        ]);
        setChartData(dayLabels.map((dayLabel, i) => ({
          key: addDaysVN(curMon, i),
          label: dayLabel,
          detail: `${dayLabel} ${formatDMY(addDaysVN(curMon, i))}`,
          thisRevenue: curDays[i]?.revenue ?? 0,
          thisProfit: curDays[i]?.profit ?? 0,
          thisExpense: curExp[i]?.expense ?? 0,
          thisPurchase: curPur[i]?.purchase ?? 0,
          thisCost: curDays[i]?.cost ?? 0,
          lastRevenue: prevDays[i]?.revenue ?? 0,
          lastProfit: prevDays[i]?.profit ?? 0,
          lastExpense: prevExp[i]?.expense ?? 0,
          lastPurchase: prevPur[i]?.purchase ?? 0,
          lastCost: prevDays[i]?.cost ?? 0,
        })));
        setChartMeta({ mode: 'week', ...meta });
      } else {
        const firstThisMonth = startOfMonthVN(t);
        const curFirst = key === 'thisMonth' ? firstThisMonth : startOfMonthVN(addDaysVN(firstThisMonth, -1));
        const curLast = endOfMonthVN(curFirst);
        const prevFirst = startOfMonthVN(addDaysVN(curFirst, -1));
        const prevLast = addDaysVN(curFirst, -1);
        const [curDays, prevDays, curExp, prevExp, curPur, prevPur] = await Promise.all([
          getDailyBreakdown(curFirst, curLast, ids),
          getDailyBreakdown(prevFirst, prevLast, ids),
          getDailyExpenses(curFirst, curLast, ids),
          getDailyExpenses(prevFirst, prevLast, ids),
          getDailyPurchaseCosts(curFirst, curLast, ids),
          getDailyPurchaseCosts(prevFirst, prevLast, ids),
        ]);
        setChartData(curDays.map((d, i) => ({
          key: d.date,
          label: String(i + 1),
          detail: formatDMY(d.date),
          thisRevenue: d.revenue,
          thisProfit: d.profit,
          thisExpense: curExp[i]?.expense ?? 0,
          thisPurchase: curPur[i]?.purchase ?? 0,
          thisCost: d.cost,
          lastRevenue: prevDays[i]?.revenue ?? 0,
          lastProfit: prevDays[i]?.profit ?? 0,
          lastExpense: prevExp[i]?.expense ?? 0,
          lastPurchase: prevPur[i]?.purchase ?? 0,
          lastCost: prevDays[i]?.cost ?? 0,
        })));
        setChartMeta({ mode: 'month', ...meta });
      }
    } catch (err) {
      toast.show(err instanceof DbError ? err.message : 'Không tải được báo cáo');
    } finally {
      setBusy(false);
    }
  }, [toast]);

  useEffect(() => {
    getAllowedWarehouses()
      .then(({ warehouses: ws, isOwner: ow }) => {
        setWarehouses(ws);
        setIsOwner(ow);
        const ids = ow ? undefined : ws.map((w) => w.id);
        void load('today', ids);
      })
      .catch(() => { void load('today'); });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const pickPreset = (key: PresetKey) => {
    setPreset(key);
    setSelectedIdx(null);
    const ids = isOwner ? undefined : warehouses.map((w) => w.id);
    void load(key, ids);
  };


  const kpis = useMemo(() => {
    if (!report) return [];
    const p = prevReport;
    const dispCur = applyGoodsCosts(report, includeGoods);
    const dispPrev = p ? applyGoodsCosts(p, includeGoods) : null;
    return [
      {
        label: 'Doanh thu',
        value: formatVND(report.revenue),
        icon: '💰',
        change: p ? pctChange(report.revenue, p.revenue) : null,
        changeLabel: 'so với kỳ trước',
      },
      {
        label: 'Lợi nhuận',
        value: formatVND(dispCur.profit),
        icon: '📈',
        change: dispPrev ? pctChange(dispCur.profit, dispPrev.profit) : null,
        changeLabel: 'so với kỳ trước',
      },
      {
        label: 'Số đơn',
        value: String(report.order_count),
        icon: '🧾',
        change: p ? pctChange(report.order_count, p.order_count) : null,
        changeLabel: 'so với kỳ trước',
      },
      {
        label: 'TB/đơn',
        value: formatVND(Math.round(report.avg_order)),
        icon: '🧮',
        change: p ? pctChange(report.avg_order, p.avg_order) : null,
        changeLabel: 'so với kỳ trước',
      },
    ];
  }, [report, prevReport, includeGoods]);


  // Thang do bieu do cot: tinh theo MUC DANG CHON, ca 2 ky. Doanh thu /
  // chi phi chi co gia tri duong (truc 0 o day); loi nhuan co the am nen
  // thang gom ca phan am, cot am ve xuong duoi truc 0.
  const metricValues = (d: ChartPoint): [number, number] => {
    if (chartMetric === 'revenue') return [d.thisRevenue, d.lastRevenue];
    const cur = applyGoodsCostsToPoint({ profit: d.thisProfit, expense: d.thisExpense, purchase: d.thisPurchase, cost: d.thisCost }, includeGoods);
    const prev = applyGoodsCostsToPoint({ profit: d.lastProfit, expense: d.lastExpense, purchase: d.lastPurchase, cost: d.lastCost }, includeGoods);
    return chartMetric === 'profit' ? [cur.profit, prev.profit] : [cur.expense, prev.expense];
  };
  const metricVals = chartData.flatMap((d) => metricValues(d));
  const maxPos = Math.max(1, ...metricVals.filter((v) => v > 0));
  const maxNeg = Math.max(0, ...metricVals.filter((v) => v < 0).map((v) => -v));

  // Hinh hoc bieu do cot: thang tuyen tinh theo muc dang chon, truc 0 dam;
  // cot duong ve len tu truc 0, cot am (chi loi nhuan am) ve xuong duoi
  // truc 0. Thang khong doi khi an/hien vi khong con legend an duong.
  const svgW = 360;
  const svgH = 220;
  const svgPadT = 14;
  const svgPadB = 20;
  const svgPadX = 8;
  const svgPlotH = svgH - svgPadT - svgPadB;
  // Hinh hoc cot nhom: moi moc la 1 nhom 2 cot sat nhau (ky nay ben trai,
  // ky truoc ben phai). Cot rong toi da 22px de che do tuan khong bi be.
  const svgSlot = chartData.length > 0 ? (svgW - 2 * svgPadX) / chartData.length : svgW - 2 * svgPadX;
  const barW = Math.max(2, Math.min(svgSlot * 0.34, 22));
  const barGap = Math.max(1, svgSlot * 0.08);
  const svgX = (i: number) => svgPadX + svgSlot * (i + 0.5);
  const svgY = (v: number) => svgPadT + ((maxPos - v) / (maxPos + maxNeg)) * svgPlotH;
  const svgZeroY = svgY(0);
  const barRect = (v: number, x: number) => ({ x, y: Math.min(svgY(v), svgZeroY), height: Math.abs(svgY(v) - svgZeroY) });
  const showXLabel = (d: ChartPoint, i: number): boolean => {
    if (chartMeta.mode === 'week') return true;
    if (chartMeta.mode === 'hour') return Number(d.label) % 6 === 0;
    const day = i + 1;
    return day === 1 || day % 5 === 0;
  };
  const xLabelText = (d: ChartPoint) => chartMeta.mode === 'hour' ? `${d.label}h` : d.label;
  const sel = selectedIdx !== null ? chartData[selectedIdx] : undefined;
  const selMetricCur = sel ? metricValues(sel)[0] : 0;
  const selMetricPrev = sel ? metricValues(sel)[1] : 0;
  const selMetricDiff = selMetricCur - selMetricPrev;
  const selMetricPct = sel ? pctChange(selMetricCur, selMetricPrev) : null;
  // Bieu do cot (ve lai phuong an ban dau): 1 SVG duy nhat, moi moc 1 nhom
  // 2 cot (ky nay dam ben trai, ky truoc nhat ben phai), chi ve muc dang
  // chon. Thang do tinh theo muc dang chon nen chuyen muc khong bep hinh.
  const metricMeta = METRICS.find((m) => m.key === chartMetric) ?? METRICS[0];
  const chartBars = (
    <svg width="100%" viewBox={`0 0 ${svgW} ${svgH}`} role="img" aria-label={`Biểu đồ cột ${metricMeta.label}`}>
      {chartData.map((d, idx) => showXLabel(d, idx) && (
        <line key={`g${d.key}`} x1={svgX(idx)} y1={svgPadT} x2={svgX(idx)} y2={svgH - svgPadB} stroke="#E2E8F0" strokeWidth={1} />
      ))}
      <line x1={svgPadX} y1={svgZeroY} x2={svgW - svgPadX} y2={svgZeroY} stroke="#64748B" strokeWidth={2} />
      <text x={svgPadX} y={svgPadT + 10} fontSize={9} fill="#94A3B8">{formatVND(maxPos)}</text>
      {maxNeg > 0 && (
        <text x={svgPadX} y={svgH - 4} fontSize={9} fill="#94A3B8">{`-${formatVND(maxNeg)}`}</text>
      )}
      {chartData.map((d, idx) => {
        const [curV, prevV] = metricValues(d);
        const cx = svgX(idx);
        const curR = barRect(curV, cx - barGap / 2 - barW);
        const prevR = barRect(prevV, cx + barGap / 2);
        return (
          <g key={d.key}>
            {curV !== 0 && <rect x={curR.x} y={curR.y} width={barW} height={Math.max(curR.height, 1)} fill={metricMeta.curColor} rx={1} />}
            {prevV !== 0 && <rect x={prevR.x} y={prevR.y} width={barW} height={Math.max(prevR.height, 1)} fill={metricMeta.prevColor} rx={1} />}
          </g>
        );
      })}
      {chartData.map((d, idx) => (
        <rect key={`h${d.key}`} x={svgPadX + svgSlot * idx} y={svgPadT} width={svgSlot} height={svgPlotH} fill="transparent" pointerEvents="all" style={{ cursor: 'pointer' }} onClick={() => setSelectedIdx(idx)} />
      ))}
      {sel && selectedIdx !== null && (
        <line x1={svgX(selectedIdx)} y1={svgPadT} x2={svgX(selectedIdx)} y2={svgH - svgPadB} stroke="#64748B" strokeWidth={1} strokeDasharray="3 3" />
      )}
      {chartData.map((d, idx) => showXLabel(d, idx) && (
        <text key={`x${d.key}`} x={svgX(idx)} y={svgH - 6} fontSize={10} fill="#64748B" textAnchor="middle">{xLabelText(d)}</text>
      ))}
    </svg>
  );
  const topProducts = useMemo(() => {
    const arr = [...(report?.top_products ?? [])];
    arr.sort((a, b) => {
      const d = a[topSort] - b[topSort];
      return topDir === 'desc' ? -d : d;
    });
    return arr.slice(0, 5);
  }, [report, topSort, topDir]);

  if (!can('reports')) {
    return (
      <div className="page">
        <div className="card">🔒 Chỉ Quản lý trở lên mới được xem báo cáo.</div>
      </div>
    );
  }

  return (
    <div className="page ov-page">
      {/* Header xanh theo mẫu */}
      <div className="ov-header">
        <div className="ov-header-top">
          <h1 className="ov-title">Tổng quan</h1>
          <div className="ov-header-actions">
            <select
              className="ov-preset"
              value={preset}
              onChange={(e) => pickPreset(e.target.value as PresetKey)}
              aria-label="Chọn kỳ báo cáo"
            >
              {PRESETS.map((p) => (
                <option key={p.key} value={p.key}>{p.label}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      <label className="row" style={{ gap: 8, alignItems: 'center', marginBottom: 12 }}>
        <input type="checkbox" checked={includeGoods} onChange={(e) => setIncludeGoods(e.target.checked)} />
        <span>Tính chi phí nhập hàng + nguyên liệu vào chi phí tổng</span>
      </label>
      {includeGoods && report && (
        <p className="small muted" style={{ marginTop: -8, marginBottom: 12 }}>
          Chi phí tổng kỳ này: Vận hành {formatVND(report.expenses)} + Nhập hàng {formatVND(report.purchase_costs ?? 0)} + Nguyên liệu {formatVND(report.cost)} = {formatVND(applyGoodsCosts(report, true).expense)}
        </p>
      )}

      {/* 4 thẻ KPI */}
      <div className="ov-kpis">
        {kpis.map((k) => (
          <div className="ov-kpi" key={k.label}>
            <div className="ov-kpi-top">
              <span className="ov-kpi-icon"><TIcon emoji={k.icon} size={20} /></span>
              <span className="ov-kpi-label">{k.label}</span>
            </div>
            <div className="ov-kpi-value">{busy && !report ? '…' : k.value}</div>
            {k.change !== null && k.change !== undefined && (
              <div className={`ov-kpi-change ${k.change >= 0 ? 'up' : 'down'}`}>
                {k.change >= 0 ? '↑' : '↓'} {Math.abs(Math.round(k.change))}% {k.changeLabel}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Biểu đồ so sánh theo kỳ đã chọn */}
      <div className="ov-card">
        <div className="ov-card-head">
          <h3>{chartMeta.cur} so với {chartMeta.prev}</h3>
        </div>
        <div style={{ padding: '0 20px', display: 'flex', flexDirection: 'column', gap: 8 }}>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px 8px', alignItems: 'center' }}>
            {METRICS.map((m) => {
              const active = chartMetric === m.key;
              return (
                <button key={m.key} onClick={() => setChartMetric(m.key)} style={{ background: active ? '#F8FAFC' : 'none', border: `1px solid ${active ? m.curColor : '#E2E8F0'}`, borderRadius: 999, padding: '4px 10px', fontSize: 12, fontWeight: active ? 700 : 400, cursor: 'pointer' }}>{m.label}</button>
              );
            })}
            <span style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 12, color: '#475569' }}>
              <span style={{ width: 12, height: 12, background: metricMeta.curColor, borderRadius: 2 }} /> {chartMeta.cur}
              <span style={{ width: 12, height: 12, background: metricMeta.prevColor, borderRadius: 2, marginLeft: 8 }} /> {cap(chartMeta.prev)}
            </span>
          </div>
        </div>                <div style={{ padding: '0 12px 4px' }}>
          {chartBars}
          {sel ? (
            <div style={{ fontSize: 13, display: 'flex', flexDirection: 'column', gap: 2, padding: '6px 8px', background: '#F8FAFC', borderRadius: 8 }}>
              <div><b>{sel.detail}</b></div>
              <div>{metricMeta.label}: {chartMeta.cur} {formatVND(selMetricCur)} · {cap(chartMeta.prev)} {formatVND(selMetricPrev)}</div>
              <div>Chênh lệch: {selMetricDiff >= 0 ? '↑' : '↓'} {formatVND(Math.abs(selMetricDiff))}{selMetricPct === null ? '' : ` (${selMetricPct >= 0 ? '+' : ''}${Math.round(selMetricPct)}%)`}</div>
            </div>
          ) : (
            <div style={{ fontSize: 12, color: '#64748B', padding: '6px 8px' }}>Chạm vào 1 nhóm cột để xem {metricMeta.label} tại mốc đó.</div>
          )}
        </div>
      </div>

      {/* Món bán chạy */}
      <div className="ov-card">
        <div className="ov-card-head">
          <h3>Món bán chạy</h3>
        </div>
        <div className="ov-filter-row">
          <select
            className="ov-filter-select"
            value={topSort}
            onChange={(e) => setTopSort(e.target.value as 'qty' | 'revenue' | 'profit')}
            aria-label="Sắp xếp theo"
          >
            <option value="qty">Số lượng</option>
            <option value="revenue">Doanh thu</option>
            <option value="profit">Lợi nhuận gộp</option>
          </select>
          <button
            className="ov-filter-dir"
            onClick={() => setTopDir((d) => (d === 'desc' ? 'asc' : 'desc'))}
            aria-label="Đổi thứ tự"
          >
            {topDir === 'desc' ? '↓ Giảm dần' : '↑ Tăng dần'}
          </button>
        </div>
        {topProducts.length === 0 ? (
          <p className="muted small">Chưa có dữ liệu</p>
        ) : (
          topProducts.map((p, i) => (
            <div className="ov-row" key={p.product_id}>
              <span className="ov-rank">{i + 1}</span>
              <div className="ov-row-body">
                <span className="ov-row-title">{p.name}</span>
                <span className="ov-row-sub">{p.qty} món · lãi gộp {formatVND(p.profit)}</span>
              </div>
              <span className="ov-row-amount">{formatVND(p.revenue)}</span>
            </div>
          ))
        )}
      </div>

      {/* Thao tác nhanh */}
      <div className="ov-card">
        <div className="ov-card-head"><h3>Thao tác nhanh</h3></div>
        <div className="ov-actions">
          <button onClick={() => navigate('/menu')}><TIcon emoji="📋" size={20} /><span>Menu</span></button>
          <button onClick={() => navigate('/customers')}><TIcon emoji="👥" size={20} /><span>Khách hàng</span></button>
          <button onClick={() => navigate('/inventory')}><TIcon emoji="🗃️" size={20} /><span>Tồn kho</span></button>
          <button onClick={() => navigate('/so-quy')}><TIcon emoji="💰" size={20} /><span>Sổ quỹ</span></button>
        </div>
      </div>

      {/* Cảnh báo tồn kho — chuyển xuống cuối trang (Hoàng yêu cầu v5.14) */}
      <LowStockPanel low={low} multiWarehouse={warehouses.length > 1} variant="mobile" />
    </div>
  );
}
