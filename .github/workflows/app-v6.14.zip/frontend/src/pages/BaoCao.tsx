import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { DbError, applyGoodsCosts, downloadFile, exportOrdersCsv, getAllowedWarehouses, getRangeReport, listAllCashbookEntries, listAllStockLogs, listLowStock, listWarehouseStock } from '../lib/db';
import { inventoryValueOf, ledgerValueTotals, summarizeLedger } from '../lib/stock-ledger';
import {
  addDaysVN,
  formatVND,
  startOfMonthVN,
  startOfWeekVN,
  todayVN,
} from '../lib/format';
import { useToast } from '../components/Toast';
import { useAuth } from '../lib/auth';
import { TIcon } from '../components/TIcon';
import type { CashbookEntry, DailyReport, IngredientWithStock, Warehouse } from '../lib/types';

type PresetKey = 'today' | 'yesterday' | 'thisWeek' | 'lastWeek' | 'thisMonth' | 'lastMonth' | 'custom';
type TabKey = 'products' | 'hours' | 'promo' | 'cashflow' | 'profit' | 'stock';

const PRESETS: { key: PresetKey; label: string }[] = [
  { key: 'today', label: 'Hôm nay' },
  { key: 'yesterday', label: 'Hôm qua' },
  { key: 'thisWeek', label: 'Tuần này' },
  { key: 'lastWeek', label: 'Tuần trước' },
  { key: 'thisMonth', label: 'Tháng này' },
  { key: 'lastMonth', label: 'Tháng trước' },
  { key: 'custom', label: 'Tùy chọn' },
];

/** YYYY-MM-DD theo giờ VN từ chuỗi ISO — cùng cách Sổ Quỹ xếp ngày khoản quỹ. */
function vnDateKey(iso: string): string {
  try {
    return new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Ho_Chi_Minh',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    }).format(new Date(iso));
  } catch {
    return (iso || '').slice(0, 10);
  }
}

function presetRange(key: PresetKey, cs: string, ce: string): [string, string] {
  const t = todayVN();
  switch (key) {
    case 'today': return [t, t];
    case 'yesterday': { const y = addDaysVN(t, -1); return [y, y]; }
    case 'thisWeek': return [startOfWeekVN(t), t];
    case 'lastWeek': {
      const m = startOfWeekVN(t);
      const ml = addDaysVN(m, -7);
      return [ml, addDaysVN(ml, 6)];
    }
    case 'thisMonth': return [startOfMonthVN(t), t];
    case 'lastMonth': {
      const f = startOfMonthVN(t);
      const l = addDaysVN(f, -1);
      return [startOfMonthVN(l), l];
    }
    case 'custom': return [cs, ce];
  }
}

const TABS: { key: TabKey; label: string; icon: string }[] = [
  { key: 'products', label: 'Món bán', icon: '🧾' },
  { key: 'hours', label: 'Theo giờ', icon: '🕐' },
  { key: 'promo', label: 'Khuyến mại', icon: '🎁' },
  { key: 'cashflow', label: 'Dòng tiền', icon: '💸' },
  { key: 'profit', label: 'Lợi nhuận', icon: '📈' },
  { key: 'stock', label: 'Tồn kho', icon: '🗃️' },
];

export function BaoCao() {
  const toast = useToast();
  const { can } = useAuth();
  const [tab, setTab] = useState<TabKey>('products');
  const [preset, setPreset] = useState<PresetKey>('today');
  const [customStart, setCustomStart] = useState(todayVN());
  const [customEnd, setCustomEnd] = useState(todayVN());
  const [report, setReport] = useState<DailyReport | null>(null);
  const [cashflow, setCashflow] = useState<CashbookEntry[]>([]);
  const [busy, setBusy] = useState(false);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [isOwner, setIsOwner] = useState(false);
  const [whFilter, setWhFilter] = useState('all');
  const [sortKey, setSortKey] = useState<'qty' | 'revenue' | 'profit'>('revenue');
  const [sortDir, setSortDir] = useState<'desc' | 'asc'>('desc');
  const [includeGoods, setIncludeGoods] = useState(false);
  const [exportBusy, setExportBusy] = useState(false);

  const scopeIds = whFilter === 'all' ? (isOwner ? undefined : warehouses.map((w) => w.id)) : [whFilter];

  const load = useCallback(async (key: PresetKey, cs: string, ce: string, ids?: string[]) => {
    const [s, e] = presetRange(key, cs, ce);
    if (!s || !e || s > e) { toast.show('Khoảng ngày không hợp lệ'); return; }
    setBusy(true);
    try {
      const [data, entries] = await Promise.all([
        getRangeReport(s, e, ids),
        listAllCashbookEntries(),
      ]);
      setReport(data);
      // Lọc khoản quỹ trong kỳ: ngày theo GIỜ VN (khớp Sổ Quỹ — trước đây cắt
      // chuỗi UTC nên khoản 00:00-06:59 bị tính sang ngày trước) và lọc theo kho
      // như các tab khác (trước đây tab Dòng tiền hiện mọi kho).
      setCashflow(entries.filter((en) => {
        const d = vnDateKey(en.created_at || '');
        if (d < s || d > e) return false;
        if (ids && ids.length > 0) return !!en.warehouse_id && ids.includes(en.warehouse_id);
        return true;
      }));
    } catch (err) {
      toast.show(err instanceof DbError ? err.message : 'Không tải được báo cáo');
    } finally {
      setBusy(false);
    }
  }, [toast]);

  useEffect(() => {
    getAllowedWarehouses()
      .then(({ warehouses: ws, isOwner: ow }) => {
        setWarehouses(ws);
        setIsOwner(ow);
        const ids = ow ? undefined : ws.map((w) => w.id);
        void load('today', todayVN(), todayVN(), ids);
      })
      .catch(() => { void load('today', todayVN(), todayVN()); });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const pickPreset = (key: PresetKey) => {
    setPreset(key);
    void load(key, customStart, customEnd, scopeIds);
  };

  const changeWh = (id: string) => {
    setWhFilter(id);
    const ids = id === 'all' ? (isOwner ? undefined : warehouses.map((w) => w.id)) : [id];
    void load(preset, customStart, customEnd, ids);
  };

  const sortedProducts = useMemo(() => {
    const arr = [...(report?.top_products ?? [])];
    arr.sort((a, b) => {
      const d = a[sortKey] - b[sortKey];
      return sortDir === 'desc' ? -d : d;
    });
    return arr;
  }, [report, sortKey, sortDir]);

  const maxHour = Math.max(1, ...(report?.by_hour.map((h) => h.revenue) ?? [1]));
  const bestHour = useMemo(() => {
    if (!report) return null;
    return [...report.by_hour].sort((a, b) => b.revenue - a.revenue)[0];
  }, [report]);

  // Dòng tiền: tổng thu/chi
  const cashStats = useMemo(() => {
    let thu = 0, chi = 0;
    const byCat: Record<string, { name: string; thu: number; chi: number }> = {};
    for (const en of cashflow) {
      // Chuyển quỹ nội bộ không phải thu/chi thực — loại khỏi tổng như Sổ Quỹ
      // khi xem tất cả quỹ (trước đây cộng cả 2 vế nên Tổng thu/chi phồng lên)
      if (en.ref_type === 'transfer') continue;
      const amt = en.amount || 0;
      if (en.type === 'thu') thu += amt;
      else chi += amt;
      const cat = en.category || 'Khác';
      const slot = byCat[cat] ?? { name: cat, thu: 0, chi: 0 };
      if (en.type === 'thu') slot.thu += amt;
      else slot.chi += amt;
      byCat[cat] = slot;
    }
    return { thu, chi, net: thu - chi, byCat: Object.values(byCat).sort((a, b) => (b.thu + b.chi) - (a.thu + a.chi)) };
  }, [cashflow]);

  const doExport = async () => {
    setExportBusy(true);
    try {
      const [s, e] = presetRange(preset, customStart, customEnd);
      const csv = await exportOrdersCsv(s, e, scopeIds);
      const tabName = TABS.find((t) => t.key === tab)?.label ?? 'bao-cao';
      downloadFile(`beesy-${tabName}_${s}_${e}.csv`, csv, 'text/csv');
      toast.show('Đã xuất file Excel');
    } catch (err) {
      toast.show(err instanceof DbError ? err.message : 'Xuất file thất bại');
    } finally {
      setExportBusy(false);
    }
  };

  if (!can('reports')) {
    return <div className="page"><div className="card">🔒 Chỉ Quản lý trở lên mới được xem báo cáo.</div></div>;
  }

  const rangeLabel = (() => {
    const [s, e] = presetRange(preset, customStart, customEnd);
    return s === e ? s : `${s} → ${e}`;
  })();

  return (
    <div className="page bc-page">
      <div className="bc-header">
        <h1>Báo cáo chi tiết</h1>
        <select value={preset} onChange={(e) => pickPreset(e.target.value as PresetKey)} className="input" aria-label="Chọn kỳ">
          {PRESETS.map((p) => <option key={p.key} value={p.key}>{p.label}</option>)}
        </select>
      </div>

      {preset === 'custom' && (
        <div className="row" style={{ gap: 8, marginBottom: 12, alignItems: 'center' }}>
          <input type="date" className="input" value={customStart} max={todayVN()} onChange={(e) => setCustomStart(e.target.value)} />
          <span>→</span>
          <input type="date" className="input" value={customEnd} max={todayVN()} onChange={(e) => setCustomEnd(e.target.value)} />
          <button className="btn btn-sm" onClick={() => pickPreset('custom')}>Xem</button>
        </div>
      )}

      {warehouses.length > 1 && (
        <div className="row" style={{ gap: 8, marginBottom: 12, flexWrap: 'wrap' }}>
          <button className={`sb-chip${whFilter === 'all' ? ' selected' : ''}`} onClick={() => changeWh('all')}>Mọi kho</button>
          {warehouses.map((w) => (
            <button key={w.id} className={`sb-chip${whFilter === w.id ? ' selected' : ''}`} onClick={() => changeWh(w.id)}>{w.name}</button>
          ))}
        </div>
      )}

      {/* Tabs — 6 tab, chữ hiện đầy đủ */}
      <div className="bc-tabs bc-tabs-6">
        {TABS.map((t) => (
          <button key={t.key} className={`bc-tab${tab === t.key ? ' active' : ''}`} onClick={() => setTab(t.key)}>
            <TIcon emoji={t.icon} size={20} />
            <span>{t.label}</span>
          </button>
        ))}
      </div>

      {tab === 'stock' ? (
        <StockReportTab
          warehouseIds={whFilter === 'all' ? warehouses.map((w) => w.id) : [whFilter]}
          warehouseNameOf={(id) => warehouses.find((w) => w.id === id)?.name ?? ''}
          range={presetRange(preset, customStart, customEnd)}
        />
      ) : busy && !report ? (
        <p className="muted">Đang tải…</p>
      ) : !report ? (
        <p className="muted">Không có dữ liệu</p>
      ) : (
        <>
          <label className="row" style={{ gap: 8, alignItems: 'center', marginBottom: 12 }}>
            <input type="checkbox" checked={includeGoods} onChange={(e) => setIncludeGoods(e.target.checked)} />
            <span>Tính chi phí nhập hàng + nguyên liệu vào chi phí tổng</span>
          </label>
          {includeGoods && (
            <p className="small muted" style={{ marginTop: -8, marginBottom: 12 }}>
              Chi phí tổng kỳ này: Vận hành {formatVND(report.expenses)} + Nhập hàng {formatVND(report.purchase_costs ?? 0)} + Nguyên liệu {formatVND(report.cost)} = {formatVND(applyGoodsCosts(report, true).expense)}
            </p>
          )}
          <div className="bc-summary">
            <div><span>Doanh thu</span><b>{formatVND(report.revenue)}</b></div>
            <div><span>Phí ship thu hộ</span><b>{formatVND(report.shipping_total ?? 0)}</b></div>
            <div><span>Giá vốn</span><b>{formatVND(report.cost)}</b></div>
            <div><span>Lợi nhuận ròng</span><b className="text-green">{formatVND(applyGoodsCosts(report, includeGoods).profit)}</b></div>
            <div><span>Đơn bán</span><b>{report.order_count}</b></div>
            <div><span>Đơn hủy</span><b>{report.cancelled_count}</b></div>
            <div><span>TB/đơn</span><b>{formatVND(Math.round(report.avg_order))}</b></div>
          </div>
          <p className="small muted" style={{ margin: '-6px 0 12px' }}>
            Doanh thu gồm cả đơn ghi nợ nhưng KHÔNG gồm phí ship (phí ship chỉ thu hộ rồi trả cho đơn vị vận chuyển, không tính vào doanh thu hay lợi nhuận). {includeGoods ? 'Lợi nhuận ròng = Doanh thu − Chi phí tổng (Vận hành + Nhập hàng + Nguyên liệu)' : 'Lợi nhuận ròng = Doanh thu − Giá vốn − Chi phí vận hành'}
            (không gồm tiền nhập hàng, trả nợ NCC và chuyển quỹ nội bộ).
          </p>

          {/* Nút xuất file trong từng tab */}
          <div className="row" style={{ justifyContent: 'flex-end', marginBottom: 10 }}>
            <button className="btn btn-outline btn-sm" disabled={exportBusy} onClick={doExport}>
              {exportBusy ? 'Đang xuất…' : <><TIcon emoji="⬇" size={13} /> Xuất {TABS.find((t) => t.key === tab)?.label}</>}
            </button>
          </div>
          <p className="small muted" style={{ margin: '-4px 0 10px', textAlign: 'right' }}>Kỳ: {rangeLabel}</p>

          {tab === 'products' && (
            <div className="card">
              <div className="row" style={{ gap: 8, marginBottom: 10, flexWrap: 'wrap' }}>
                {([['qty', 'Số lượng'], ['revenue', 'Doanh thu'], ['profit', 'Lợi nhuận gộp']] as const).map(([k, label]) => (
                  <button key={k} className={`sb-chip${sortKey === k ? ' selected' : ''}`} onClick={() => setSortKey(k)}>{label}</button>
                ))}
                <button className="sb-chip" onClick={() => setSortDir((d) => d === 'desc' ? 'asc' : 'desc')}>
                  {sortDir === 'desc' ? '↓ Giảm dần' : '↑ Tăng dần'}
                </button>
              </div>
              <div className="bc-table-wrap">
                <table className="pc-table">
                  <thead>
                    <tr><th>#</th><th>Món</th><th className="r">SL</th><th className="r">Doanh thu</th><th className="r">Giá vốn</th><th className="r">Lợi nhuận gộp</th></tr>
                  </thead>
                  <tbody>
                    {sortedProducts.map((p, i) => (
                      <tr key={p.product_id}>
                        <td>{i + 1}</td>
                        <td><b>{p.name}</b></td>
                        <td className="r">{p.qty}</td>
                        <td className="r">{formatVND(p.revenue)}</td>
                        <td className="r">{formatVND(p.cost)}</td>
                        <td className="r" style={{ color: '#16A34A', fontWeight: 600 }}>{formatVND(p.profit)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {sortedProducts.length === 0 && <p className="muted small">Chưa có dữ liệu</p>}
            </div>
          )}

          {tab === 'hours' && (
            <div className="card">
              <h3 style={{ margin: '0 0 12px' }}>Doanh thu theo giờ</h3>
              {bestHour && bestHour.revenue > 0 && (
                <p className="small" style={{ marginBottom: 12 }}>
                  Giờ bán tốt nhất: <b>{bestHour.hour}h</b> — {formatVND(bestHour.revenue)} ({bestHour.count} đơn)
                </p>
              )}
              <div className="hour-chart">
                {report.by_hour.map((h) => (
                  <div className="hour-bar" key={h.hour} title={`${h.hour}h: ${formatVND(h.revenue)} (${h.count} đơn)`}>
                    <div className="bar" style={{ height: `${Math.round((h.revenue / maxHour) * 120)}px` }} />
                    <div className="h">{h.hour}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {tab === 'promo' && (
            <div className="card">
              <h3 style={{ margin: '0 0 12px' }}>Khuyến mại</h3>
              <div className="bc-summary" style={{ marginBottom: 0 }}>
                <div><span>Đơn KM</span><b>{report.promo_count}</b></div>
                <div><span>Tiền giảm</span><b>{formatVND(report.promo_discount)}</b></div>
                <div><span>Tỉ lệ</span><b>{report.order_count > 0 ? Math.round((report.promo_count / report.order_count) * 100) : 0}%</b></div>
              </div>
            </div>
          )}

          {tab === 'cashflow' && (
            <div className="card">
              <h3 style={{ margin: '0 0 4px' }}>Dòng tiền</h3>
              <p className="small muted" style={{ margin: '0 0 12px' }}>
                Tiền thực vào/ra quỹ trong kỳ (gồm thu nợ khách, tiền nhập hàng; đã loại chuyển quỹ
                nội bộ) — khác Doanh thu bán hàng ở tab Lợi nhuận.
              </p>
              <div className="bc-summary" style={{ marginBottom: 12 }}>
                <div><span>Tổng thu</span><b className="text-green">{formatVND(cashStats.thu)}</b></div>
                <div><span>Tổng chi</span><b style={{ color: '#DC2626' }}>{formatVND(cashStats.chi)}</b></div>
                <div><span>Chênh lệch</span><b>{formatVND(cashStats.net)}</b></div>
              </div>
              <h4 style={{ margin: '0 0 8px', fontSize: 14 }}>Theo danh mục</h4>
              {cashStats.byCat.length === 0 ? (
                <p className="muted small">Chưa có dữ liệu</p>
              ) : (
                cashStats.byCat.map((c) => (
                  <div className="ov-row" key={c.name}>
                    <div className="ov-row-body">
                      <span className="ov-row-title">{c.name}</span>
                      <span className="ov-row-sub">Thu {formatVND(c.thu)} · Chi {formatVND(c.chi)}</span>
                    </div>
                    <span className="ov-row-amount">{formatVND(c.thu - c.chi)}</span>
                  </div>
                ))
              )}
            </div>
          )}

          {tab === 'profit' && (
            <div className="card">
              <h3 style={{ margin: '0 0 12px' }}>Lợi nhuận</h3>
              <div className="bc-summary" style={{ marginBottom: 12 }}>
                <div><span>Doanh thu</span><b>{formatVND(report.revenue)}</b></div>
                <div><span>Phí ship thu hộ</span><b>{formatVND(report.shipping_total ?? 0)}</b></div>
                <div><span>Giá vốn</span><b>{formatVND(report.cost)}</b></div>
                <div><span>Chi phí</span><b>{formatVND(applyGoodsCosts(report, includeGoods).expense)}</b></div>
                {includeGoods && (
                  <div><span>— gồm Vận hành + Nhập hàng + Nguyên liệu</span><b>{formatVND(report.expenses)} + {formatVND(report.purchase_costs ?? 0)} + {formatVND(report.cost)}</b></div>
                )}
                <div><span>Lợi nhuận ròng</span><b className="text-green">{formatVND(applyGoodsCosts(report, includeGoods).profit)}</b></div>
                <div><span>Biên LN</span><b>{report.revenue > 0 ? ((applyGoodsCosts(report, includeGoods).profit / report.revenue) * 100).toFixed(1) : 0}%</b></div>
                <div><span>Giảm giá KM</span><b>{formatVND(report.promo_discount)}</b></div>
                <div><span>Số món</span><b>{report.top_products.length}</b></div>
              </div>
              <h4 style={{ margin: '0 0 8px', fontSize: 14 }}>Top món lợi nhuận gộp cao</h4>
              {[...report.top_products].sort((a, b) => b.profit - a.profit).slice(0, 10).map((p, i) => (
                <div className="ov-row" key={p.product_id}>
                  <span className="ov-rank">{i + 1}</span>
                  <div className="ov-row-body">
                    <span className="ov-row-title">{p.name}</span>
                    <span className="ov-row-sub">{p.qty} món · vốn {formatVND(p.cost)}</span>
                  </div>
                  <span className="ov-row-amount" style={{ color: '#16A34A' }}>{formatVND(p.profit)}</span>
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}

// ---------- Tab Báo cáo tồn kho (v5.14) ----------
// Phát triển từ KPI "Giá trị tồn kho hiện tại" đã bỏ khỏi trang Tổng quan:
// giá trị tồn hiện tại theo từng nguyên liệu/kho + biến động giá trị trong
// kỳ (đầu/nhập/xuất/cuối, cùng cơ sở giá vốn hiện tại như Sổ kho) + danh
// sách sắp hết (tôn trọng công tắc cảnh báo riêng từng nguyên liệu).

interface StockRow extends IngredientWithStock {
  warehouse_id: string;
  warehouse_name: string;
}

type StockLowRow = Awaited<ReturnType<typeof listLowStock>>[number];

function csvCellStock(v: unknown): string {
  const s = String(v ?? '');
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

function fmtQtyStock(v: number): string {
  const n = parseFloat(v.toFixed(3));
  return n.toLocaleString('vi-VN', { maximumFractionDigits: 3 });
}

function StockReportTab({
  warehouseIds,
  warehouseNameOf,
  range,
}: {
  warehouseIds: string[];
  warehouseNameOf: (id: string) => string;
  range: [string, string];
}) {
  const toast = useToast();
  const navigate = useNavigate();
  const [busy, setBusy] = useState(true);
  const [exportBusy, setExportBusy] = useState(false);
  const [rows, setRows] = useState<StockRow[]>([]);
  const [totals, setTotals] = useState<{ openingValue: number; importValue: number; exportValue: number; closingValue: number } | null>(null);
  const [low, setLow] = useState<StockLowRow[]>([]);
  const [query, setQuery] = useState('');

  const scopeKey = warehouseIds.join(',');
  const [rs, re] = range;

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setBusy(true);
      try {
        const ids = scopeKey ? scopeKey.split(',') : [];
        const perWh = await Promise.all(
          ids.map(async (id) => {
            // SUA 25/10/2026: tai toan bo log de So kho ky qua khu tinh dung.
            const [items, logs] = await Promise.all([listWarehouseStock(id), listAllStockLogs(id)]);
            return { id, items, logs };
          }),
        );
        if (cancelled) return;
        setRows(
          perWh.flatMap(({ id, items }) =>
            items
              .filter((i) => i.active)
              .map((i) => ({ ...i, warehouse_id: id, warehouse_name: warehouseNameOf(id) })),
          ),
        );
        const summaries = perWh.flatMap(({ items, logs }) =>
          summarizeLedger(
            items.map((i) => ({
              ingredient_id: i.id,
              ingredient_name: i.name,
              unit: i.unit,
              current_stock: i.stock,
              cost_per_unit: i.cost_per_unit,
            })),
            logs
              .filter((l) => {
                const k = vnDateKey(l.created_at);
                return k >= rs && k <= re;
              })
              .map((l) => ({
                ingredient_id: l.ingredient_id,
                ingredient_name: l.ingredient_name,
                change: l.change,
                balance_after: l.balance_after,
                created_at: l.created_at,
              })),
            logs
              .filter((l) => vnDateKey(l.created_at) > re)
              .map((l) => ({
                ingredient_id: l.ingredient_id,
                ingredient_name: l.ingredient_name,
                change: l.change,
                balance_after: l.balance_after,
                created_at: l.created_at,
              })),
          ),
        );
        setTotals(ledgerValueTotals(summaries));
        const lowRows = await listLowStock(ids);
        if (!cancelled) setLow(lowRows);
      } catch (err) {
        if (!cancelled) toast.show(err instanceof DbError ? err.message : 'Không tải được báo cáo tồn kho');
      } finally {
        if (!cancelled) setBusy(false);
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [scopeKey, rs, re]);

  const totalValue = useMemo(() => inventoryValueOf(rows), [rows]);
  const stockedCount = useMemo(() => rows.filter((r) => r.stock > 0).length, [rows]);
  const multiWh = warehouseIds.length > 1;

  const sortedRows = useMemo(() => {
    const q = query.trim().toLowerCase();
    return rows
      .filter((r) => r.stock !== 0)
      .filter((r) => !q || r.name.toLowerCase().includes(q))
      .sort((a, b) => Math.abs(b.stock * b.cost_per_unit) - Math.abs(a.stock * a.cost_per_unit));
  }, [rows, query]);

  const doExportStock = () => {
    setExportBusy(true);
    try {
      const all = rows
        .filter((r) => r.stock !== 0)
        .sort((a, b) => Math.abs(b.stock * b.cost_per_unit) - Math.abs(a.stock * a.cost_per_unit));
      const lines: string[] = [
        ['Nguyên liệu', 'Kho', 'ĐVT', 'Tồn', 'Giá vốn BQ (đ)', 'Giá trị (đ)'].map(csvCellStock).join(','),
        ...all.map((r) =>
          [r.name, r.warehouse_name, r.unit, r.stock, r.cost_per_unit, Math.round(r.stock * r.cost_per_unit)]
            .map(csvCellStock)
            .join(','),
        ),
        ['TỔNG GIÁ TRỊ TỒN', '', '', '', '', totalValue].map(csvCellStock).join(','),
        '',
        [`Biến động giá trị trong kỳ ${rs} - ${re} (theo giá vốn hiện tại, chỉ hàng có nhập/xuất)`].map(csvCellStock).join(','),
        ['Đầu kỳ', totals?.openingValue ?? 0].map(csvCellStock).join(','),
        ['Nhập trong kỳ', totals?.importValue ?? 0].map(csvCellStock).join(','),
        ['Xuất trong kỳ', totals?.exportValue ?? 0].map(csvCellStock).join(','),
        ['Cuối kỳ', totals?.closingValue ?? 0].map(csvCellStock).join(','),
      ];
      downloadFile(`beesy-TonKho_${rs}_${re}.csv`, '﻿' + lines.join('\r\n'), 'text/csv');
      toast.show('Đã xuất file Excel');
    } catch {
      toast.show('Xuất file thất bại');
    } finally {
      setExportBusy(false);
    }
  };

  const rangeLabel = rs === re ? rs : `${rs} → ${re}`;

  return (
    <>
      <div className="row" style={{ justifyContent: 'flex-end', marginBottom: 10 }}>
        <button className="btn btn-outline btn-sm" disabled={exportBusy || busy} onClick={doExportStock}>
          {exportBusy ? 'Đang xuất…' : <><TIcon emoji="⬇" size={13} /> Xuất Tồn kho</>}
        </button>
      </div>
      <p className="small muted" style={{ margin: '-4px 0 10px', textAlign: 'right' }}>Kỳ: {rangeLabel}</p>

      {busy ? (
        <p className="muted">Đang tải…</p>
      ) : (
        <>
          <div className="bc-summary">
            <div><span>Giá trị tồn hiện tại</span><b>{formatVND(totalValue)}</b></div>
            <div><span>Mặt hàng có tồn</span><b>{stockedCount}</b></div>
            <div><span>Cảnh báo sắp hết</span><b>{low.length}</b></div>
            <div><span>Kho đang xem</span><b>{warehouseIds.length}</b></div>
          </div>

          <p className="small" style={{ fontWeight: 700, margin: '2px 0 8px' }}>
            Biến động giá trị trong kỳ (theo giá vốn bình quân hiện tại)
          </p>
          <div className="bc-summary">
            <div><span>Đầu kỳ</span><b>{formatVND(totals?.openingValue ?? 0)}</b></div>
            <div><span>Nhập trong kỳ</span><b>{formatVND(totals?.importValue ?? 0)}</b></div>
            <div><span>Xuất trong kỳ</span><b>{formatVND(totals?.exportValue ?? 0)}</b></div>
            <div><span>Cuối kỳ</span><b>{formatVND(totals?.closingValue ?? 0)}</b></div>
          </div>
          <p className="small muted" style={{ margin: '-6px 0 12px' }}>
            Biến động chỉ tính các mặt hàng có nhập/xuất trong kỳ — cùng cách tính với Sổ kho ở trang Tồn kho.
          </p>

          <div className="card" style={{ marginBottom: 12 }}>
            <div className="row" style={{ gap: 8, marginBottom: 10, alignItems: 'center' }}>
              <b>Giá trị theo nguyên liệu</b>
              <input
                className="input grow"
                placeholder="Tìm nguyên liệu…"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
            </div>
            <div className="bc-table-wrap">
              <table className="pc-table">
                <thead>
                  <tr>
                    <th>Nguyên liệu</th>
                    {multiWh && <th>Kho</th>}
                    <th className="r">Tồn</th>
                    <th className="r">Giá vốn BQ</th>
                    <th className="r">Giá trị</th>
                  </tr>
                </thead>
                <tbody>
                  {sortedRows.map((r) => (
                    <tr key={`${r.warehouse_id}-${r.id}`}>
                      <td><b>{r.name}</b> <span className="muted small">({r.unit})</span></td>
                      {multiWh && <td>{r.warehouse_name}</td>}
                      <td className="r" style={r.stock < 0 ? { color: 'var(--red, #dc2626)', fontWeight: 600 } : undefined}>
                        {fmtQtyStock(r.stock)}
                      </td>
                      <td className="r">{formatVND(r.cost_per_unit)}</td>
                      <td className="r" style={{ fontWeight: 600 }}>{formatVND(Math.round(r.stock * r.cost_per_unit))}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr>
                    <td colSpan={multiWh ? 4 : 3} style={{ fontWeight: 700 }}>Tổng giá trị tồn</td>
                    <td className="r" style={{ fontWeight: 700 }}>{formatVND(totalValue)}</td>
                  </tr>
                </tfoot>
              </table>
            </div>
            {sortedRows.length === 0 && <p className="muted small">Không có nguyên liệu nào còn tồn.</p>}
          </div>

          {low.length > 0 && (
            <div className="card">
              <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
                <b>🔔 Sắp hết / hết hàng ({low.length})</b>
                <button className="btn btn-ghost btn-sm" onClick={() => navigate('/inventory')}>Mở trang Tồn kho →</button>
              </div>
              {low.slice(0, 8).map((r) => (
                <div
                  key={`${r.warehouse_id}-${r.ingredient_id}`}
                  className="row"
                  style={{ justifyContent: 'space-between', padding: '6px 0', borderTop: '1px solid var(--line)' }}
                >
                  <span>{r.name}{multiWh ? <span className="muted small"> · {r.warehouse_name}</span> : null}</span>
                  <span className="small" style={r.stock <= 0 ? { color: 'var(--red, #dc2626)', fontWeight: 700 } : undefined}>
                    Còn {fmtQtyStock(r.stock)} / tối thiểu {fmtQtyStock(r.min_stock)} {r.unit}
                  </span>
                </div>
              ))}
              {low.length > 8 && <p className="small muted" style={{ margin: '6px 0 0' }}>… và {low.length - 8} mặt hàng nữa</p>}
            </div>
          )}
        </>
      )}
    </>
  );
}
