import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { DbError, getAllowedWarehouses, getRangeReport } from '../lib/db';
import {
  addDaysVN,
  formatDMY,
  formatVND,
  startOfMonthVN,
  startOfWeekVN,
  todayVN,
} from '../lib/format';
import { useToast } from '../components/Toast';
import { DayCloseSheet } from './DayCloseSheet';
import { useAuth } from '../lib/auth';
import { TIcon } from '../components/TIcon';
import type { DailyReport, Warehouse } from '../lib/types';

type PresetKey = 'today' | 'yesterday' | 'thisWeek' | 'lastWeek' | 'thisMonth' | 'lastMonth';

const PRESETS: { key: PresetKey; label: string }[] = [
  { key: 'today', label: 'Hôm nay' },
  { key: 'yesterday', label: 'Hôm qua' },
  { key: 'thisWeek', label: 'Tuần này' },
  { key: 'lastWeek', label: 'Tuần trước' },
  { key: 'thisMonth', label: 'Tháng này' },
  { key: 'lastMonth', label: 'Tháng trước' },
];

function presetRange(key: PresetKey): [string, string] {
  const t = todayVN();
  switch (key) {
    case 'today': return [t, t];
    case 'yesterday': { const y = addDaysVN(t, -1); return [y, y]; }
    case 'thisWeek': return [startOfWeekVN(t), t];
    case 'lastWeek': {
      const mondayThis = startOfWeekVN(t);
      const mondayLast = addDaysVN(mondayThis, -7);
      return [mondayLast, addDaysVN(mondayLast, 6)];
    }
    case 'thisMonth': return [startOfMonthVN(t), t];
    case 'lastMonth': {
      const firstThisMonth = startOfMonthVN(t);
      const lastDayPrev = addDaysVN(firstThisMonth, -1);
      return [startOfMonthVN(lastDayPrev), lastDayPrev];
    }
  }
}

function prevRange(key: PresetKey): [string, string] {
  const t = todayVN();
  switch (key) {
    case 'today': { const y = addDaysVN(t, -1); return [y, y]; }
    case 'yesterday': { const y = addDaysVN(t, -2); return [y, y]; }
    case 'thisWeek': {
      const mondayThis = startOfWeekVN(t);
      const mondayLast = addDaysVN(mondayThis, -7);
      return [mondayLast, addDaysVN(mondayLast, 6)];
    }
    case 'lastWeek': {
      const mondayThis = startOfWeekVN(t);
      const mondayLast2 = addDaysVN(mondayThis, -14);
      return [mondayLast2, addDaysVN(mondayLast2, 6)];
    }
    case 'thisMonth': {
      const firstThisMonth = startOfMonthVN(t);
      const lastDayPrev = addDaysVN(firstThisMonth, -1);
      return [startOfMonthVN(lastDayPrev), lastDayPrev];
    }
    case 'lastMonth': {
      const firstThisMonth = startOfMonthVN(t);
      const lastDayPrev = addDaysVN(firstThisMonth, -1);
      const firstPrev = startOfMonthVN(lastDayPrev);
      const lastDayPrev2 = addDaysVN(firstPrev, -1);
      return [startOfMonthVN(lastDayPrev2), lastDayPrev2];
    }
  }
}

function pctChange(cur: number, prev: number): number | null {
  if (prev === 0) return cur > 0 ? 100 : null;
  return ((cur - prev) / prev) * 100;
}

export function ReportsPC() {
  const toast = useToast();
  const { can, user } = useAuth();
  const navigate = useNavigate();
  const [preset, setPreset] = useState<PresetKey>('today');
  const [report, setReport] = useState<DailyReport | null>(null);
  const [prevReport, setPrevReport] = useState<DailyReport | null>(null);
  const [weekData, setWeekData] = useState<{ date: string; revenue: number }[]>([]);
  const [busy, setBusy] = useState(false);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [isOwner, setIsOwner] = useState(false);
  const [dayCloseOpen, setDayCloseOpen] = useState(false);

  const load = useCallback(async (key: PresetKey, ids?: string[]) => {
    setBusy(true);
    try {
      const [s, e] = presetRange(key);
      const [ps, pe] = prevRange(key);
      const t = todayVN();
      const [cur, prev] = await Promise.all([
        getRangeReport(s, e, ids),
        getRangeReport(ps, pe, ids),
      ]);
      setReport(cur);
      setPrevReport(prev);
      const dayPromises: Promise<DailyReport>[] = [];
      for (let i = 6; i >= 0; i--) {
        const d = addDaysVN(t, -i);
        dayPromises.push(getRangeReport(d, d, ids));
      }
      const days = await Promise.all(dayPromises);
      setWeekData(days.map((d, i) => ({ date: addDaysVN(t, -(6 - i)), revenue: d.revenue })));
    } catch (err) {
      toast.show(err instanceof DbError ? err.message : 'Không tải được báo cáo');
    } finally {
      setBusy(false);
    }
  }, [toast]);

  useEffect(() => {
    getAllowedWarehouses()
      .then(({ warehouses: ws, isOwner: ow }) => {
        setWarehouses(ws);
        setIsOwner(ow);
        const ids = ow ? undefined : ws.map((w) => w.id);
        void load('today', ids);
      })
      .catch(() => { void load('today'); });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const pickPreset = (key: PresetKey) => {
    setPreset(key);
    const ids = isOwner ? undefined : warehouses.map((w) => w.id);
    void load(key, ids);
  };

  const kpis = useMemo(() => {
    if (!report) return [];
    const p = prevReport;
    return [
      { label: 'Doanh thu', value: formatVND(report.revenue), icon: '💰', bg: '#EFF4FF', change: p ? pctChange(report.revenue, p.revenue) : null },
      { label: 'Lợi nhuận', value: formatVND(report.profit), icon: '📈', bg: '#ECFDF5', change: p ? pctChange(report.profit, p.profit) : null },
      { label: 'Số đơn', value: String(report.order_count), icon: '🧾', bg: '#F5F0FF', change: p ? pctChange(report.order_count, p.order_count) : null },
      { label: 'TB/đơn', value: formatVND(Math.round(report.avg_order)), icon: '🧮', bg: '#FFFBEB', change: p ? pctChange(report.avg_order, p.avg_order) : null },
    ];
  }, [report, prevReport]);

  const maxWeekRevenue = Math.max(1, ...weekData.map((d) => d.revenue));
  const topProducts = useMemo(() => (report?.top_products ?? []).slice(0, 8), [report]);

  // Doanh thu theo danh mục (từ top products — cần category; tạm dùng top products)
  const catData = useMemo(() => {
    const total = topProducts.reduce((s, p) => s + p.revenue, 0) || 1;
    return topProducts.slice(0, 5).map((p, i) => ({
      name: p.name,
      value: p.revenue,
      pct: (p.revenue / total) * 100,
      color: ['#00B14F', '#00D15F', '#10B981', '#F59E0B', '#9CA3AF'][i % 5],
    }));
  }, [topProducts]);

  if (!can('reports')) {
    return <div className="page"><div className="card">🔒 Chỉ Quản lý trở lên mới được xem báo cáo.</div></div>;
  }

  return (
    <div className="pc-ov">
      {/* Top bar PC */}
      <div className="pc-ov-topbar">
        <h1>Tổng quan</h1>
        <div className="pc-ov-topbar-right">
          <select value={preset} onChange={(e) => pickPreset(e.target.value as PresetKey)} className="pc-select" aria-label="Chọn kỳ">
            {PRESETS.map((p) => <option key={p.key} value={p.key}>{p.label}</option>)}
          </select>
          <button className="pc-btn-primary" onClick={() => setDayCloseOpen(true)}>
            <TIcon emoji="💰" size={16} /> Chốt két
          </button>
          <span className="pc-user">{user?.full_name || user?.email}</span>
        </div>
      </div>

      {/* 4 KPI cards */}
      <div className="pc-kpis">
        {kpis.map((k) => (
          <div className="pc-kpi" key={k.label}>
            <div className="pc-kpi-icon" style={{ background: k.bg }}><TIcon emoji={k.icon} size={24} /></div>
            <div className="pc-kpi-info">
              <div className="pc-kpi-label">{k.label}</div>
              <div className="pc-kpi-value">{busy && !report ? '…' : k.value}</div>
              {k.change !== null && k.change !== undefined && (
                <div className={`pc-kpi-change ${k.change >= 0 ? 'up' : 'down'}`}>
                  {k.change >= 0 ? '↑' : '↓'} {Math.abs(Math.round(k.change))}% so với kỳ trước
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Chart + Donut */}
      <div className="pc-ov-grid2">
        <div className="pc-card">
          <div className="pc-card-head">
            <h3>Biểu đồ doanh thu</h3>
            <span className="pc-muted">7 ngày qua</span>
          </div>
          <div className="pc-chart">
            {weekData.map((d) => (
              <div className="pc-bar-col" key={d.date} title={`${formatDMY(d.date)}: ${formatVND(d.revenue)}`}>
                <div className="pc-bar-track">
                  <div className="pc-bar" style={{ height: `${Math.max(3, Math.round((d.revenue / maxWeekRevenue) * 100))}%` }} />
                </div>
                <div className="pc-bar-label">{formatDMY(d.date).slice(0, 5)}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="pc-card">
          <div className="pc-card-head"><h3>Top món theo doanh thu</h3></div>
          <div className="pc-donut-wrap">
            <div className="pc-cat-list">
              {catData.map((c) => (
                <div className="pc-cat-row" key={c.name}>
                  <span className="pc-dot" style={{ background: c.color }} />
                  <span className="pc-cat-name">{c.name}</span>
                  <span className="pc-cat-val">{formatVND(c.value)}</span>
                  <span className="pc-cat-pct">{c.pct.toFixed(1)}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Bảng món bán chạy */}
      <div className="pc-card">
        <div className="pc-card-head">
          <h3>Món bán chạy</h3>
          <button className="pc-link" onClick={() => navigate('/pos')}>Bán hàng →</button>
        </div>
        <table className="pc-table">
          <thead>
            <tr>
              <th>#</th>
              <th>Món</th>
              <th className="r">Số lượng</th>
              <th className="r">Doanh thu</th>
              <th className="r">Giá vốn</th>
              <th className="r">Lợi nhuận</th>
            </tr>
          </thead>
          <tbody>
            {topProducts.map((p, i) => (
              <tr key={p.product_id}>
                <td>{i + 1}</td>
                <td><b>{p.name}</b></td>
                <td className="r">{p.qty}</td>
                <td className="r">{formatVND(p.revenue)}</td>
                <td className="r">{formatVND(p.cost)}</td>
                <td className="r" style={{ color: '#16A34A', fontWeight: 600 }}>{formatVND(p.profit)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {topProducts.length === 0 && <p className="muted small" style={{ padding: 12 }}>Chưa có dữ liệu</p>}
      </div>

      {dayCloseOpen && <DayCloseSheet onClose={() => setDayCloseOpen(false)} />}
    </div>
  );
}
