// Nhật ký thao tác — báo cáo riêng: lọc theo khoảng ngày, người dùng, loại thao tác.
import { useEffect, useMemo, useState } from 'react';
import { AUDIT_LABELS, DbError, listAuditLogs } from '../lib/db';
import { formatDMY, todayVN } from '../lib/format';
import type { AuditLog } from '../lib/types';
import { useToast } from '../components/Toast';

function shiftDate(ymd: string, days: number): string {
  const [y, m, d] = ymd.split('-').map(Number);
  const dt = new Date(y, m - 1, d);
  dt.setDate(dt.getDate() + days);
  const mm = String(dt.getMonth() + 1).padStart(2, '0');
  const dd = String(dt.getDate()).padStart(2, '0');
  return `${dt.getFullYear()}-${mm}-${dd}`;
}

function fmtTime(iso: string): string {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleString('vi-VN', {
      timeZone: 'Asia/Ho_Chi_Minh',
      day: '2-digit',
      month: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return iso;
  }
}

export function AuditLogPage() {
  const toast = useToast();
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [busy, setBusy] = useState(true);
  const [fromDate, setFromDate] = useState(() => shiftDate(todayVN(), -6));
  const [toDate, setToDate] = useState(() => todayVN());
  const [userFilter, setUserFilter] = useState('all');
  const [actionFilter, setActionFilter] = useState('all');

  useEffect(() => {
    (async () => {
      setBusy(true);
      try {
        setLogs(await listAuditLogs(500));
      } catch (e) {
        toast.show(e instanceof DbError ? e.message : 'Không tải được nhật ký');
      } finally {
        setBusy(false);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const users = useMemo(() => {
    const set = new Map<string, string>();
    for (const l of logs) {
      const key = l.actor_id ?? `name:${l.actor_name ?? '—'}`;
      if (!set.has(key)) set.set(key, l.actor_name ?? '—');
    }
    return [...set.entries()].sort((a, b) => a[1].localeCompare(b[1], 'vi'));
  }, [logs]);

  const actions = useMemo(() => {
    const set = new Set(logs.map((l) => l.action));
    return [...set].sort();
  }, [logs]);

  const filtered = useMemo(() => {
    return logs.filter((l) => {
      const day = l.created_at.slice(0, 10);
      if (day < fromDate || day > toDate) return false;
      if (userFilter !== 'all') {
        const key = l.actor_id ?? `name:${l.actor_name ?? '—'}`;
        if (key !== userFilter) return false;
      }
      if (actionFilter !== 'all' && l.action !== actionFilter) return false;
      return true;
    });
  }, [logs, fromDate, toDate, userFilter, actionFilter]);

  return (
    <div className="page">
      <h1 className="page-title">📜 Nhật ký thao tác</h1>

      <div className="card" style={{ marginBottom: 12 }}>
        <div className="row" style={{ gap: 8, flexWrap: 'wrap' }}>
          <div className="field" style={{ flex: '1 1 140px', margin: 0 }}>
            <label>Từ ngày</label>
            <input
              className="input"
              type="date"
              max={toDate}
              value={fromDate}
              onChange={(e) => e.target.value && setFromDate(e.target.value)}
            />
          </div>
          <div className="field" style={{ flex: '1 1 140px', margin: 0 }}>
            <label>Đến ngày</label>
            <input
              className="input"
              type="date"
              min={fromDate}
              max={todayVN()}
              value={toDate}
              onChange={(e) => e.target.value && setToDate(e.target.value)}
            />
          </div>
        </div>
        <div className="row" style={{ gap: 8, flexWrap: 'wrap', marginTop: 8 }}>
          <div className="field" style={{ flex: '1 1 140px', margin: 0 }}>
            <label>Người dùng</label>
            <select className="input" value={userFilter} onChange={(e) => setUserFilter(e.target.value)}>
              <option value="all">Tất cả</option>
              {users.map(([key, name]) => (
                <option key={key} value={key}>
                  {name}
                </option>
              ))}
            </select>
          </div>
          <div className="field" style={{ flex: '1 1 140px', margin: 0 }}>
            <label>Loại thao tác</label>
            <select className="input" value={actionFilter} onChange={(e) => setActionFilter(e.target.value)}>
              <option value="all">Tất cả</option>
              {actions.map((a) => (
                <option key={a} value={a}>
                  {(AUDIT_LABELS[a] ?? a).replace(/^[^\s]+\s/, '')}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {busy ? (
        <p className="muted" style={{ textAlign: 'center' }}>
          Đang tải…
        </p>
      ) : filtered.length === 0 ? (
        <div className="sb-empty">
          <div className="eico">📜</div>
          <p>Không có thao tác nào trong khoảng này.</p>
        </div>
      ) : (
        <>
          <p className="small muted" style={{ margin: '0 0 8px 4px' }}>
            {filtered.length} thao tác · {formatDMY(fromDate)} → {formatDMY(toDate)}
          </p>
          <div className="sb-section" style={{ padding: '4px 16px' }}>
            {filtered.map((a) => (
              <div key={a.id} className="sb-row" style={{ cursor: 'default' }}>
                <span className="rbody">
                  <span className="rtitle" style={{ fontSize: 15, fontWeight: 600 }}>
                    {AUDIT_LABELS[a.action] ?? a.action}
                  </span>
                  {a.detail && (
                    <span className="rsub" style={{ marginTop: 2 }}>
                      {a.detail}
                    </span>
                  )}
                  <span className="rsub" style={{ marginTop: 2 }}>
                    👤 {a.actor_name ?? '—'} · 🕐 {fmtTime(a.created_at)}
                  </span>
                </span>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
