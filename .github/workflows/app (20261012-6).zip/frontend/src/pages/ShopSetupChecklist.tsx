// Checklist setup quán mới — dành cho Hoàng khi triển khai cho khách.
// Lưu tiến độ vào localStorage (theo trình duyệt).
import { useState } from 'react';
import { Navigate } from 'react-router-dom';
import { PageHead } from '../components/PageHead';
import { useAuth } from '../lib/auth';
import { PHASES } from '../lib/setup-steps';

/** Chỉ email này mới thấy checklist (chủ Beesy đi setup cho quán khác). */
export const SUPER_ADMIN_EMAIL = 'thanghoang.beesy@gmail.com';

export function isSuperAdmin(email?: string | null): boolean {
  return !!email && email.toLowerCase() === SUPER_ADMIN_EMAIL;
}

const LS_KEY = 'beesy_shop_setup_checklist';

function loadChecked(): Record<string, boolean> {
  try {
    return JSON.parse(localStorage.getItem(LS_KEY) ?? '{}');
  } catch {
    return {};
  }
}

export function ShopSetupChecklist() {
  const { user } = useAuth();
  const [checked, setChecked] = useState<Record<string, boolean>>(loadChecked);
  const [openPhase, setOpenPhase] = useState<number>(0);

  const toggle = (id: string) => {
    setChecked((prev) => {
      const next = { ...prev, [id]: !prev[id] };
      try {
        localStorage.setItem(LS_KEY, JSON.stringify(next));
      } catch {
        /* bo qua */
      }
      return next;
    });
  };

  const total = PHASES.reduce((s, p) => s + p.steps.length, 0);
  const done = Object.values(checked).filter(Boolean).length;
  const pct = Math.round((done / total) * 100);

  if (user && !isSuperAdmin(user.email)) return <Navigate to="/" replace />;

  const reset = () => {
    if (!window.confirm('Xóa hết tiến độ checklist?')) return;
    setChecked({});
    try {
      localStorage.removeItem(LS_KEY);
    } catch {
      /* bo qua */
    }
  };

  return (
    <div className="page">
      <PageHead title="Checklist setup quán mới" back />
      <div className="card" style={{ marginBottom: 12 }}>
        <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
          <div style={{ fontWeight: 700 }}>
            Tiến độ: {done}/{total} ({pct}%)
          </div>
          <button type="button" className="sb-chip" style={{ minHeight: 36 }} onClick={reset}>
            🔄 Làm lại
          </button>
        </div>
        <div style={{ height: 10, borderRadius: 5, background: 'var(--border)', overflow: 'hidden' }}>
          <div
            style={{
              height: '100%',
              width: `${pct}%`,
              background: 'var(--brand)',
              borderRadius: 5,
              transition: 'width 0.3s',
            }}
          />
        </div>
        <p className="small muted" style={{ margin: '8px 0 0' }}>
          Dành cho chủ Beesy khi triển khai quán mới. Tick từng bước khi xong — tiến độ lưu trên máy này.
        </p>
      </div>

      {PHASES.map((phase, pi) => {
        const phaseDone = phase.steps.filter((st) => checked[st.id]).length;
        const open = openPhase === pi;
        return (
          <div className="card" key={phase.title} style={{ marginBottom: 10 }}>
            <button
              type="button"
              className="sb-menu-row"
              style={{ width: '100%', textAlign: 'left' }}
              onClick={() => setOpenPhase(open ? -1 : pi)}
            >
              <span style={{ fontSize: 22 }}>{phase.icon}</span>
              <span style={{ fontWeight: 700, flex: 1 }}>
                {phase.title}{' '}
                <span className="small muted">
                  ({phaseDone}/{phase.steps.length})
                </span>
              </span>
              <span>{open ? '▾' : '▸'}</span>
            </button>
            {open && (
              <div style={{ paddingTop: 8 }}>
                {phase.steps.map((st, si) => (
                  <label
                    key={st.id}
                    style={{
                      display: 'flex',
                      gap: 10,
                      padding: '10px 4px',
                      borderTop: si > 0 ? '1px solid var(--border)' : undefined,
                      cursor: 'pointer',
                      opacity: checked[st.id] ? 0.6 : 1,
                    }}
                  >
                    <input
                      type="checkbox"
                      checked={!!checked[st.id]}
                      onChange={() => toggle(st.id)}
                      style={{ width: 22, height: 22, marginTop: 2, flexShrink: 0 }}
                    />
                    <div style={{ flex: 1 }}>
                      <div
                        style={{
                          fontWeight: 600,
                          textDecoration: checked[st.id] ? 'line-through' : undefined,
                        }}
                      >
                        {si + 1}. {st.title}
                      </div>
                      {st.detail && (
                        <p className="small muted" style={{ margin: '4px 0 0' }}>
                          {st.detail}
                        </p>
                      )}
                      {st.link && (
                        <a
                          href={st.link}
                          target="_blank"
                          rel="noreferrer"
                          className="small"
                          onClick={(e) => e.stopPropagation()}
                        >
                          Mở link ↗
                        </a>
                      )}
                    </div>
                  </label>
                ))}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
