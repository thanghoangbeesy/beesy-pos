// CRM: quản lý các quán (khách hàng thương mại của chủ Beesy).
// Chỉ super admin thấy. Mỗi quán: thông tin quán + chủ quán + tiến độ setup + ghi chú.
import { useEffect, useState } from 'react';
import { Navigate } from 'react-router-dom';
import { PageHead } from '../components/PageHead';
import { Sheet } from '../components/Sheet';
import { useToast } from '../components/Toast';
import { useAuth } from '../lib/auth';
import { DbError } from '../lib/db';
import { PHASES, getDoneSteps, getTotalSteps } from '../lib/setup-steps';
import {
  MANAGED_STATUS_LABEL,
  deleteManagedShop,
  listManagedShops,
  saveManagedShop,
  updateShopChecklist,
  type ManagedShop,
  type ManagedShopStatus,
} from '../lib/managed-shops';
import { isSuperAdmin } from './ShopSetupChecklist';

const TOTAL = getTotalSteps();

function StatusBadge({ status }: { status: ManagedShopStatus }) {
  const colors: Record<ManagedShopStatus, string> = {
    lead: 'var(--blue-bg)',
    setting_up: 'var(--amber-bg, #FEF3C7)',
    live: 'var(--green-bg)',
    paused: '#F3F4F6',
    cancelled: 'var(--red-bg)',
  };
  return (
    <span
      className="sb-chip"
      style={{ minHeight: 28, fontSize: 12, background: colors[status] }}
    >
      {MANAGED_STATUS_LABEL[status]}
    </span>
  );
}

function ShopForm({
  initial,
  onClose,
  onSaved,
}: {
  initial: ManagedShop | null;
  onClose: () => void;
  onSaved: (s: ManagedShop) => void;
}) {
  const toast = useToast();
  const [shopName, setShopName] = useState(initial?.shop_name ?? '');
  const [ownerName, setOwnerName] = useState(initial?.owner_name ?? '');
  const [ownerPhone, setOwnerPhone] = useState(initial?.owner_phone ?? '');
  const [ownerEmail, setOwnerEmail] = useState(initial?.owner_email ?? '');
  const [address, setAddress] = useState(initial?.address ?? '');
  const [status, setStatus] = useState<ManagedShopStatus>(initial?.status ?? 'lead');
  const [fbProject, setFbProject] = useState(initial?.firebase_project ?? '');
  const [hostingUrl, setHostingUrl] = useState(initial?.hosting_url ?? '');
  const [licensePlan, setLicensePlan] = useState(initial?.license_plan ?? '');
  const [licenseExpiry, setLicenseExpiry] = useState(initial?.license_expiry ?? '');
  const [notes, setNotes] = useState(initial?.notes ?? '');
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (!shopName.trim() || !ownerName.trim()) {
      toast.show('Nhập tên quán và tên chủ quán');
      return;
    }
    setBusy(true);
    try {
      const saved = await saveManagedShop(initial?.id ?? null, {
        shop_name: shopName,
        owner_name: ownerName,
        owner_phone: ownerPhone,
        owner_email: ownerEmail || null,
        address: address || null,
        status,
        firebase_project: fbProject || null,
        hosting_url: hostingUrl || null,
        license_plan: licensePlan || null,
        license_expiry: licenseExpiry || null,
        notes: notes || null,
      });
      onSaved(saved);
      onClose();
      toast.show(initial ? 'Đã cập nhật' : 'Đã thêm quán');
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet title={initial ? 'Sửa thông tin quán' : 'Thêm quán mới'} onClose={onClose}>
      <div className="field">
        <label>Tên quán *</label>
        <input className="input" value={shopName} onChange={(e) => setShopName(e.target.value)} placeholder="VD: Cafe Sân Vườn" />
      </div>
      <div className="row" style={{ gap: 8 }}>
        <div className="field" style={{ flex: 1 }}>
          <label>Chủ quán *</label>
          <input className="input" value={ownerName} onChange={(e) => setOwnerName(e.target.value)} placeholder="Tên chủ quán" />
        </div>
        <div className="field" style={{ flex: 1 }}>
          <label>SĐT chủ quán</label>
          <input className="input" value={ownerPhone} onChange={(e) => setOwnerPhone(e.target.value)} placeholder="09xx..." />
        </div>
      </div>
      <div className="field">
        <label>Email chủ quán</label>
        <input className="input" value={ownerEmail} onChange={(e) => setOwnerEmail(e.target.value)} placeholder="Email đăng nhập" />
      </div>
      <div className="field">
        <label>Địa chỉ quán</label>
        <input className="input" value={address} onChange={(e) => setAddress(e.target.value)} placeholder="Địa chỉ" />
      </div>
      <div className="field">
        <label>Trạng thái</label>
        <select className="input" value={status} onChange={(e) => setStatus(e.target.value as ManagedShopStatus)}>
          {(Object.keys(MANAGED_STATUS_LABEL) as ManagedShopStatus[]).map((k) => (
            <option key={k} value={k}>
              {MANAGED_STATUS_LABEL[k]}
            </option>
          ))}
        </select>
      </div>
      <div className="row" style={{ gap: 8 }}>
        <div className="field" style={{ flex: 1 }}>
          <label>Firebase project</label>
          <input className="input" value={fbProject} onChange={(e) => setFbProject(e.target.value)} placeholder="beesy-quan-a" />
        </div>
        <div className="field" style={{ flex: 1 }}>
          <label>Link web</label>
          <input className="input" value={hostingUrl} onChange={(e) => setHostingUrl(e.target.value)} placeholder="https://..." />
        </div>
      </div>
      <div className="row" style={{ gap: 8 }}>
        <div className="field" style={{ flex: 1 }}>
          <label>Gói license</label>
          <input className="input" value={licensePlan} onChange={(e) => setLicensePlan(e.target.value)} placeholder="trial/basic/pro" />
        </div>
        <div className="field" style={{ flex: 1 }}>
          <label>Hết hạn license</label>
          <input className="input" type="date" value={licenseExpiry} onChange={(e) => setLicenseExpiry(e.target.value)} />
        </div>
      </div>
      <div className="field">
        <label>Ghi chú</label>
        <textarea
          className="input"
          rows={3}
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="VD: quán báo lỗi in hóa đơn ngày 12/10..."
        />
      </div>
      <button className="btn btn-block btn-lg" disabled={busy} onClick={() => void submit()}>
        {busy ? 'Đang lưu…' : initial ? 'Lưu' : 'Thêm quán'}
      </button>
    </Sheet>
  );
}

export function ManagedShops() {
  const { user } = useAuth();
  const toast = useToast();
  const [shops, setShops] = useState<ManagedShop[]>([]);
  const [busy, setBusy] = useState(true);
  const [form, setForm] = useState<ManagedShop | 'new' | null>(null);
  const [selected, setSelected] = useState<ManagedShop | null>(null);
  const [filter, setFilter] = useState<'all' | ManagedShopStatus>('all');
  const [openPhase, setOpenPhase] = useState<number>(0);

  useEffect(() => {
    (async () => {
      try {
        setShops(await listManagedShops());
      } catch (e) {
        toast.show(e instanceof DbError ? e.message : 'Không tải được danh sách');
      } finally {
        setBusy(false);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (user && !isSuperAdmin(user.email)) return <Navigate to="/" replace />;

  const filtered = filter === 'all' ? shops : shops.filter((s) => s.status === filter);

  const toggleStep = async (shop: ManagedShop, stepId: string) => {
    const next = { ...shop.checklist, [stepId]: !shop.checklist[stepId] };
    // Cập nhật UI ngay
    setShops((prev) => prev.map((s) => (s.id === shop.id ? { ...s, checklist: next } : s)));
    if (selected?.id === shop.id) setSelected({ ...selected, checklist: next });
    try {
      await updateShopChecklist(shop.id, next);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu tiến độ thất bại');
    }
  };

  const remove = async (shop: ManagedShop) => {
    if (!window.confirm(`Xóa quán "${shop.shop_name}"?`)) return;
    try {
      await deleteManagedShop(shop.id);
      setShops((prev) => prev.filter((s) => s.id !== shop.id));
      if (selected?.id === shop.id) setSelected(null);
      toast.show('Đã xóa');
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Xóa thất bại');
    }
  };

  return (
    <div className="page">
      <PageHead
        title="Quản lý các quán"
        back
        right={
          <button className="btn btn-add-customer" onClick={() => setForm('new')}>
            <span aria-hidden>＋</span> Thêm quán
          </button>
        }
      />

      <div className="chip-row" style={{ marginBottom: 12 }}>
        <button
          className={`sb-chip${filter === 'all' ? ' selected' : ''}`}
          onClick={() => setFilter('all')}
        >
          Tất cả ({shops.length})
        </button>
        {(Object.keys(MANAGED_STATUS_LABEL) as ManagedShopStatus[]).map((k) => {
          const n = shops.filter((s) => s.status === k).length;
          if (n === 0 && filter !== k) return null;
          return (
            <button
              key={k}
              className={`sb-chip${filter === k ? ' selected' : ''}`}
              onClick={() => setFilter(k)}
            >
              {MANAGED_STATUS_LABEL[k]} ({n})
            </button>
          );
        })}
      </div>

      {busy ? (
        <div className="card">Đang tải…</div>
      ) : filtered.length === 0 ? (
        <div className="card" style={{ textAlign: 'center', padding: '32px 16px' }}>
          <div style={{ fontSize: 44 }}>🏪</div>
          <p className="muted">Chưa có quán nào. Bấm "＋ Thêm quán" để bắt đầu theo dõi.</p>
        </div>
      ) : (
        filtered.map((shop) => {
          const done = getDoneSteps(shop.checklist);
          const pct = Math.round((done / TOTAL) * 100);
          return (
            <div
              key={shop.id}
              className="card"
              style={{ marginBottom: 10, cursor: 'pointer' }}
              onClick={() => setSelected(shop)}
            >
              <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
                <div style={{ fontWeight: 700, fontSize: 16 }}>🏪 {shop.shop_name}</div>
                <StatusBadge status={shop.status} />
              </div>
              <div className="small muted" style={{ marginBottom: 8 }}>
                👤 {shop.owner_name} · 📞 {shop.owner_phone || '—'}
                {shop.license_plan && ` · 🔑 ${shop.license_plan}`}
                {shop.license_expiry && ` (hết hạn ${shop.license_expiry})`}
              </div>
              <div className="row" style={{ gap: 8, alignItems: 'center' }}>
                <div style={{ flex: 1, height: 8, borderRadius: 4, background: 'var(--border)', overflow: 'hidden' }}>
                  <div style={{ height: '100%', width: `${pct}%`, background: 'var(--brand)', borderRadius: 4 }} />
                </div>
                <span className="small muted" style={{ minWidth: 44, textAlign: 'right' }}>
                  {done}/{TOTAL}
                </span>
              </div>
            </div>
          );
        })
      )}

      {form && (
        <ShopForm
          initial={form === 'new' ? null : form}
          onClose={() => setForm(null)}
          onSaved={(s) => {
            setShops((prev) => {
              const next = prev.filter((x) => x.id !== s.id);
              return [s, ...next];
            });
            if (selected?.id === s.id) setSelected(s);
          }}
        />
      )}

      {selected && (
        <Sheet title={selected.shop_name} onClose={() => setSelected(null)}>
          <div className="row" style={{ gap: 8, marginBottom: 12 }}>
            <StatusBadge status={selected.status} />
            <span className="small muted">
              👤 {selected.owner_name} · 📞 {selected.owner_phone}
            </span>
          </div>
          {selected.owner_email && <p className="small muted">✉️ {selected.owner_email}</p>}
          {selected.address && <p className="small muted">📍 {selected.address}</p>}
          {selected.hosting_url && (
            <p className="small">
              🌐{' '}
              <a href={selected.hosting_url} target="_blank" rel="noreferrer">
                {selected.hosting_url}
              </a>
            </p>
          )}
          {selected.firebase_project && <p className="small muted">🔥 {selected.firebase_project}</p>}
          {selected.license_plan && (
            <p className="small muted">
              🔑 Gói {selected.license_plan}
              {selected.license_expiry && ` · hết hạn ${selected.license_expiry}`}
            </p>
          )}
          {selected.notes && (
            <div className="card" style={{ margin: '12px 0', background: 'var(--amber-bg, #FEF3C7)' }}>
              <div style={{ fontWeight: 700, marginBottom: 4 }}>📝 Ghi chú</div>
              <p className="small" style={{ margin: 0, whiteSpace: 'pre-wrap' }}>
                {selected.notes}
              </p>
            </div>
          )}

          <div style={{ fontWeight: 700, margin: '16px 0 8px' }}>
            📋 Tiến độ setup ({getDoneSteps(selected.checklist)}/{TOTAL})
          </div>
          {PHASES.map((phase, pi) => {
            const pdone = phase.steps.filter((st) => selected.checklist[st.id]).length;
            const open = openPhase === pi;
            return (
              <div key={phase.title} style={{ marginBottom: 8 }}>
                <button
                  type="button"
                  className="sb-menu-row"
                  style={{ width: '100%', textAlign: 'left' }}
                  onClick={() => setOpenPhase(open ? -1 : pi)}
                >
                  <span style={{ fontSize: 18 }}>{phase.icon}</span>
                  <span style={{ fontWeight: 600, flex: 1, fontSize: 14 }}>
                    {phase.title} ({pdone}/{phase.steps.length})
                  </span>
                  <span>{open ? '▾' : '▸'}</span>
                </button>
                {open &&
                  phase.steps.map((st) => (
                    <label
                      key={st.id}
                      style={{
                        display: 'flex',
                        gap: 10,
                        padding: '8px 4px 8px 28px',
                        cursor: 'pointer',
                        opacity: selected.checklist[st.id] ? 0.6 : 1,
                      }}
                    >
                      <input
                        type="checkbox"
                        checked={!!selected.checklist[st.id]}
                        onChange={() => void toggleStep(selected, st.id)}
                        style={{ width: 20, height: 20, flexShrink: 0 }}
                      />
                      <span
                        style={{
                          fontSize: 14,
                          textDecoration: selected.checklist[st.id] ? 'line-through' : undefined,
                        }}
                      >
                        {st.title}
                      </span>
                    </label>
                  ))}
              </div>
            );
          })}

          <div className="row" style={{ gap: 8, marginTop: 16 }}>
            <button className="btn btn-outline" style={{ flex: 1 }} onClick={() => setForm(selected)}>
              ✏️ Sửa
            </button>
            <button className="btn btn-outline" style={{ flex: 1 }} onClick={() => void remove(selected)}>
              🗑️ Xóa
            </button>
          </div>
        </Sheet>
      )}
    </div>
  );
}
