import { useState } from 'react';
import type { FormEvent } from 'react';
import { EmailAuthProvider, reauthenticateWithCredential, updatePassword } from 'firebase/auth';
import { auth } from '../lib/firebase';
import { useToast } from '../components/Toast';
import { PageHead } from '../components/PageHead';

function viErr(code: string): string {
  switch (code) {
    case 'auth/wrong-password':
    case 'auth/invalid-credential':
      return 'Mật khẩu hiện tại không đúng.';
    case 'auth/weak-password':
      return 'Mật khẩu mới phải có ít nhất 6 ký tự.';
    case 'auth/requires-recent-login':
      return 'Phiên đăng nhập đã cũ. Hãy đăng xuất rồi đăng nhập lại, sau đó đổi mật khẩu.';
    case 'auth/too-many-requests':
      return 'Thử quá nhiều lần. Nghỉ vài phút rồi thử lại.';
    case 'auth/network-request-failed':
      return 'Mất kết nối mạng. Kiểm tra internet rồi thử lại.';
    default:
      return 'Đổi mật khẩu thất bại. Thử lại sau.';
  }
}

export function ChangePassword() {
  const toast = useToast();
  const [current, setCurrent] = useState('');
  const [next, setNext] = useState('');
  const [confirm, setConfirm] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const fbUser = auth.currentUser;
    if (!fbUser?.email) {
      setErr('Không xác định được tài khoản đăng nhập.');
      return;
    }
    if (!current || !next || !confirm) {
      setErr('Vui lòng nhập đầy đủ 3 ô.');
      return;
    }
    if (next !== confirm) {
      setErr('Mật khẩu mới nhập lại chưa khớp.');
      return;
    }
    if (next.length < 6) {
      setErr('Mật khẩu mới phải có ít nhất 6 ký tự.');
      return;
    }
    setBusy(true);
    setErr('');
    try {
      const cred = EmailAuthProvider.credential(fbUser.email, current);
      await reauthenticateWithCredential(fbUser, cred);
      await updatePassword(fbUser, next);
      toast.show('✅ Đã đổi mật khẩu thành công.');
      setCurrent('');
      setNext('');
      setConfirm('');
    } catch (ex) {
      const code = (ex as { code?: string } | null)?.code ?? '';
      setErr(viErr(code));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="page">
      <PageHead title="Đổi mật khẩu" back />
      <div className="card" style={{ maxWidth: 480 }}>
        <p className="muted small" style={{ marginTop: 0 }}>
          Đổi mật khẩu cho tài khoản đang đăng nhập: <b>{auth.currentUser?.email ?? ''}</b>
        </p>
        {err && <div className="err">{err}</div>}
        <form onSubmit={submit}>
          <div className="sb-float">
            <label htmlFor="pw-cur">Mật khẩu hiện tại</label>
            <input
              id="pw-cur"
              type="password"
              autoComplete="current-password"
              value={current}
              onChange={(e) => setCurrent(e.target.value)}
              placeholder="••••••"
            />
          </div>
          <div className="sb-float">
            <label htmlFor="pw-new">Mật khẩu mới</label>
            <input
              id="pw-new"
              type="password"
              autoComplete="new-password"
              value={next}
              onChange={(e) => setNext(e.target.value)}
              placeholder="Ít nhất 6 ký tự"
            />
          </div>
          <div className="sb-float">
            <label htmlFor="pw-confirm">Nhập lại mật khẩu mới</label>
            <input
              id="pw-confirm"
              type="password"
              autoComplete="new-password"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              placeholder="••••••"
            />
          </div>
          <button type="submit" className="btn btn-block btn-lg" disabled={busy}>
            {busy ? 'Đang đổi…' : 'Đổi mật khẩu'}
          </button>
        </form>
      </div>
    </div>
  );
}
