// Trang đặt hàng công khai — khách quét QR / mở link, tự chọn món, đặt mang về.
// Không cần đăng nhập. Đơn vào online_orders chờ nhân viên duyệt 1 chạm.
import { useEffect, useMemo, useState } from 'react';
import {
  DbError,
  calcVoucherDiscount,
  getDefaultWarehouseId,
  getPublicSettings,
  getVoucherByCode,
  listCategories,
  listModifierGroups,
  listPaymentMethodsPublic,
  listProducts,
  placeOnlineOrder,
  getOnlineOrder,
  validateVoucher,
  type PlaceOnlineOrderInput,
} from '../lib/db';
import { buildVietQRUrl, formatVND, todayVN } from '../lib/format';
import type { Category, ModifierGroup, OnlineOrder, PaymentMethodDef, Product, SelectedModifier, Voucher } from '../lib/types';
import { ModifierModal } from './ModifierModal';
import { applyBrandColor, loadBrand } from '../lib/brand';
import { canUsePro } from '../lib/license';
import { useToast } from '../components/Toast';

interface CartLine {
  key: string;
  product: Product;
  qty: number;
  modifiers: SelectedModifier[];
  note: string;
}

const lineTotal = (l: CartLine) =>
  (l.product.base_price + l.modifiers.reduce((s, m) => s + m.price_delta, 0)) * l.qty;

export function OnlineOrderPage() {
  const toast = useToast();
  const [busy, setBusy] = useState(true);
  const [shopName, setShopName] = useState('Beesy');
  const [brandLogo, setBrandLogo] = useState('');
  const [proOk, setProOk] = useState<boolean | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [groups, setGroups] = useState<ModifierGroup[]>([]);
  const [methods, setMethods] = useState<PaymentMethodDef[]>([]);
  const [catId, setCatId] = useState<string>('all');
  const [q, setQ] = useState('');
  const [modProduct, setModProduct] = useState<Product | null>(null);
  const [cart, setCart] = useState<CartLine[]>([]);
  const [step, setStep] = useState<'menu' | 'checkout' | 'done'>('menu');
  // checkout
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [note, setNote] = useState('');
  const [methodId, setMethodId] = useState('');
  const [voucherInput, setVoucherInput] = useState('');
  const [voucher, setVoucher] = useState<Voucher | null>(null);
  const [placing, setPlacing] = useState(false);
  const [placed, setPlaced] = useState<OnlineOrder | null>(null);

  useEffect(() => {
    (async () => {
      setBusy(true);
      try {
        const [ps, cs, gs, ms, pub, defWid] = await Promise.all([
          listProducts(),
          listCategories(),
          listModifierGroups(),
          listPaymentMethodsPublic(),
          getPublicSettings(),
          getDefaultWarehouseId().catch(() => null),
        ]);
        const visible = ps.filter(
          (p) => p.active && (!defWid || p.warehouse_ids.length === 0 || p.warehouse_ids.includes(defWid)),
        );
        setProducts(visible);
        setCategories(cs);
        setGroups(gs.filter((g) => g.active));
        const payable = ms.filter((m) => m.kind === 'cash' || m.kind === 'transfer');
        setMethods(payable);
        setMethodId(payable.find((m) => m.kind === 'cash')?.id ?? payable[0]?.id ?? '');
        if (pub.shop_name) setShopName(pub.shop_name);
        loadBrand().then((b) => {
          if (b.shop_name) setShopName(b.shop_name);
          if (b.logo) setBrandLogo(b.logo);
          applyBrandColor(b.color);
        }).catch(() => {});
        canUsePro().then(setProOk).catch(() => setProOk(true));
      } catch (e) {
        toast.show(e instanceof DbError ? e.message : 'Không tải được menu');
      } finally {
        setBusy(false);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const filtered = useMemo(() => {
    const nq = q.trim().toLowerCase();
    return products.filter((p) => {
      if (catId !== 'all' && p.category_id !== catId) return false;
      if (nq && !p.name.toLowerCase().includes(nq)) return false;
      return true;
    });
  }, [products, catId, q]);

  const addToCart = (mods: SelectedModifier[], note: string, qty: number) => {
    if (!modProduct) return;
    const key = `${modProduct.id}|${mods.map((m) => m.option_id).sort().join(',')}|${note}`;
    setCart((prev) => {
      const ex = prev.find((l) => l.key === key);
      if (ex) return prev.map((l) => (l.key === key ? { ...l, qty: l.qty + qty } : l));
      return [...prev, { key, product: modProduct, qty, modifiers: mods, note }];
    });
    setModProduct(null);
    toast.show('Đã thêm vào giỏ');
  };

  const cartCount = cart.reduce((s, l) => s + l.qty, 0);
  const subtotal = cart.reduce((s, l) => s + lineTotal(l), 0);
  const voucherDiscount = voucher ? calcVoucherDiscount(subtotal, voucher) : 0;
  const total = subtotal - voucherDiscount;

  const applyVoucher = async () => {
    const code = voucherInput.trim();
    if (!code) return;
    try {
      const v = await getVoucherByCode(code);
      if (!v) return toast.show('Mã voucher không tồn tại');
      const err = validateVoucher(v, subtotal, todayVN());
      if (err) return toast.show(err);
      setVoucher(v);
      toast.show(`Đã áp voucher ${v.code}`);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không kiểm tra được voucher');
    }
  };

  const submit = async () => {
    if (cart.length === 0) return;
    setPlacing(true);
    try {
      const input: PlaceOnlineOrderInput = {
        items: cart.map((l) => ({
          productId: l.product.id,
          qty: l.qty,
          modifierOptionIds: l.modifiers.map((m) => m.option_id),
          note: l.note || undefined,
        })),
        customerName: name,
        customerPhone: phone,
        note: note.trim() || null,
        paymentMethodId: methodId,
        voucherCode: voucher?.code ?? null,
      };
      const { id } = await placeOnlineOrder(input);
      const oo = await getOnlineOrder(id);
      setPlaced(oo);
      setStep('done');
      setCart([]);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Đặt hàng thất bại, thử lại nhé');
    } finally {
      setPlacing(false);
    }
  };

  // Theo dõi trạng thái đơn sau khi đặt
  useEffect(() => {
    if (step !== 'done' || !placed || placed.status !== 'pending') return;
    const t = setInterval(async () => {
      try {
        const oo = await getOnlineOrder(placed.id);
        if (oo && oo.status !== 'pending') {
          setPlaced(oo);
          clearInterval(t);
        }
      } catch {
        /* bỏ qua */
      }
    }, 8000);
    return () => clearInterval(t);
  }, [step, placed]);

  if (busy || proOk === null) {
    return (
      <div className="page" style={{ textAlign: 'center', paddingTop: 60 }}>
        <div style={{ fontSize: 40 }}>🧋</div>
        <p className="muted">Đang tải menu…</p>
      </div>
    );
  }

  if (!proOk) {
    return (
      <div className="page" style={{ maxWidth: 560, margin: '0 auto', textAlign: 'center', paddingTop: 60 }}>
        <div style={{ fontSize: 52 }}>🔒</div>
        <h2>{shopName}</h2>
        <p className="muted">Quán hiện chưa bật đặt hàng online.<br />Vui lòng gọi trực tiếp cho quán nhé!</p>
      </div>
    );
  }

  if (step === 'done' && placed) {
    const transferMethod = methods.find((m) => m.id === placed.payment_method_id && m.kind === 'transfer');
    return (
      <div className="page" style={{ maxWidth: 560, margin: '0 auto' }}>
        <div className="card" style={{ textAlign: 'center', padding: '32px 20px' }}>
          <div style={{ fontSize: 52 }}>✅</div>
          <h2 style={{ margin: '12px 0 4px' }}>Đặt hàng thành công!</h2>
          <p className="muted" style={{ marginTop: 0 }}>
            Quán đang chuẩn bị món cho bạn ({placed.customer_name})
          </p>
          <div className="co-total-row grand" style={{ marginTop: 12 }}>
            <span>Tổng cộng</span>
            <span className="money">{formatVND(placed.total)}</span>
          </div>
          {placed.status === 'pending' && (
            <p className="small" style={{ color: 'var(--amber, #b45309)' }}>
              ⏳ Quán xác nhận đơn trong giây lát…
            </p>
          )}
          {placed.status === 'confirmed' && (
            <p className="small" style={{ color: 'var(--green)', fontWeight: 700 }}>
              🎉 Quán đã nhận đơn, bạn ghé lấy nhé!
            </p>
          )}
          {transferMethod && transferMethod.bank_bin && transferMethod.bank_account && (
            <div style={{ marginTop: 16 }}>
              <p className="small muted">Quét mã để chuyển khoản trước:</p>
              <img
                src={buildVietQRUrl(
                  transferMethod.bank_bin,
                  transferMethod.bank_account,
                  transferMethod.bank_account_name || shopName,
                  placed.total,
                  `DH ${placed.id.slice(0, 6).toUpperCase()}`,
                )}
                alt="VietQR thanh toán"
                style={{ width: 220, height: 220, borderRadius: 12 }}
              />
              <p className="small muted">
                {transferMethod.bank_account} · {transferMethod.bank_account_name}
              </p>
            </div>
          )}
          {placed.payment_kind === 'cash' && (
            <p className="small muted" style={{ marginTop: 12 }}>
              💵 Thanh toán tiền mặt khi nhận hàng
            </p>
          )}
          <button className="btn btn-outline btn-block" style={{ marginTop: 16 }} onClick={() => setStep('menu')}>
            Đặt thêm món
          </button>
        </div>
      </div>
    );
  }

  if (step === 'checkout') {
    return (
      <div className="page" style={{ maxWidth: 560, margin: '0 auto' }}>
        <h1 className="page-title">🧾 Xác nhận đặt hàng</h1>
        <div className="card" style={{ marginBottom: 12 }}>
          {cart.map((l) => (
            <div className="co-total-row" key={l.key}>
              <span>
                {l.qty}× {l.product.name}
                {l.modifiers.length > 0 && (
                  <span className="rsub" style={{ display: 'block' }}>
                    {l.modifiers.map((m) => m.option).join(', ')}
                  </span>
                )}
              </span>
              <span>{formatVND(lineTotal(l))}</span>
            </div>
          ))}
          <div className="co-total-row">
            <span>Tiền hàng</span>
            <span>{formatVND(subtotal)}</span>
          </div>
          <div className="co-total-row" style={{ alignItems: 'center' }}>
            <span>🎟️ Voucher</span>
            {voucher ? (
              <span className="row" style={{ gap: 6 }}>
                <span className="sb-chip selected">{voucher.code}</span>
                <button type="button" className="sb-chip" onClick={() => { setVoucher(null); setVoucherInput(''); }}>
                  Gỡ
                </button>
              </span>
            ) : (
              <span className="row" style={{ gap: 6 }}>
                <input
                  className="input"
                  style={{ width: 100, textTransform: 'uppercase' }}
                  placeholder="Mã"
                  value={voucherInput}
                  onChange={(e) => setVoucherInput(e.target.value.toUpperCase())}
                />
                <button type="button" className="sb-chip" onClick={() => void applyVoucher()}>
                  Áp
                </button>
              </span>
            )}
          </div>
          {voucherDiscount > 0 && (
            <div className="co-total-row" style={{ color: 'var(--green)' }}>
              <span>Voucher {voucher?.code}</span>
              <span>-{formatVND(voucherDiscount)}</span>
            </div>
          )}
          <div className="co-total-row grand">
            <span>Tổng cộng</span>
            <span className="money">{formatVND(total)}</span>
          </div>
        </div>
        <div className="field">
          <label>Tên người nhận *</label>
          <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="VD: Anh Hoàng" />
        </div>
        <div className="field">
          <label>Số điện thoại *</label>
          <input
            className="input"
            inputMode="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value.replace(/[^\d+]/g, ''))}
            placeholder="VD: 0901234567"
          />
        </div>
        <div className="field">
          <label>Thanh toán</label>
          <div className="row" style={{ gap: 8 }}>
            {methods.map((m) => (
              <button
                key={m.id}
                type="button"
                className={`sb-chip${methodId === m.id ? ' selected' : ''}`}
                style={{ minHeight: 44, padding: '6px 14px' }}
                onClick={() => setMethodId(m.id)}
              >
                {m.kind === 'cash' ? '💵' : '🏦'} {m.name}
              </button>
            ))}
          </div>
        </div>
        <div className="field">
          <label>Ghi chú</label>
          <input className="input" value={note} onChange={(e) => setNote(e.target.value)} placeholder="VD: ít đá, mang về…" />
        </div>
        <div className="row" style={{ gap: 8 }}>
          <button className="btn btn-outline btn-block btn-lg" onClick={() => setStep('menu')}>
            Quay lại
          </button>
          <button className="btn btn-block btn-lg" disabled={placing} onClick={() => void submit()}>
            {placing ? 'Đang đặt…' : `Đặt hàng · ${formatVND(total)}`}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="page" style={{ maxWidth: 720, margin: '0 auto', paddingBottom: 90 }}>
      <div style={{ textAlign: 'center', padding: '16px 0 8px' }}>
        {brandLogo ? (
          brandLogo.startsWith('data:image') ? (
            <img src={brandLogo} alt="" style={{ width: 64, height: 64, borderRadius: 16, objectFit: 'cover' }} />
          ) : (
            <div style={{ fontSize: 44 }}>{brandLogo}</div>
          )
        ) : (
          <div style={{ fontSize: 44 }}>🧋</div>
        )}
        <h1 style={{ margin: '4px 0', fontSize: 22 }}>{shopName}</h1>
        <p className="muted small" style={{ margin: 0 }}>
          Đặt món mang về 🥡
        </p>
      </div>
      <div className="row" style={{ gap: 8, margin: '12px 0' }}>
        <input
          className="input"
          style={{ flex: 1 }}
          placeholder="🔍 Tìm món…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
      </div>
      <div className="chip-row">
        <button
          type="button"
          className={`sb-chip${catId === 'all' ? ' selected' : ''}`}
          onClick={() => setCatId('all')}
        >
          Tất cả
        </button>
        {categories.map((c) => (
          <button
            key={c.id}
            type="button"
            className={`sb-chip${catId === c.id ? ' selected' : ''}`}
            onClick={() => setCatId(c.id)}
          >
            {c.name}
          </button>
        ))}
      </div>
      {filtered.length === 0 ? (
        <p className="muted" style={{ textAlign: 'center', marginTop: 32 }}>
          Không có món nào.
        </p>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          {filtered.map((p) => (
            <button key={p.id} type="button" className="card" style={{ textAlign: 'left', padding: 12 }} onClick={() => setModProduct(p)}>
              <div style={{ fontWeight: 700, fontSize: 15 }}>{p.name}</div>
              <div className="small muted">{p.unit}</div>
              <div className="money" style={{ marginTop: 6, color: 'var(--green)' }}>
                {formatVND(p.base_price)}
              </div>
            </button>
          ))}
        </div>
      )}
      {modProduct && (
        <ModifierModal
          product={modProduct}
          groups={groups}
          onAdd={addToCart}
          onClose={() => setModProduct(null)}
        />
      )}
      {cartCount > 0 && (
        <button
          type="button"
          className="btn btn-block btn-lg"
          style={{ position: 'fixed', left: 16, right: 16, bottom: 'calc(16px + env(safe-area-inset-bottom))', zIndex: 50 }}
          onClick={() => setStep('checkout')}
        >
          🛒 Giỏ hàng ({cartCount}) · {formatVND(total)}
        </button>
      )}
    </div>
  );
}
