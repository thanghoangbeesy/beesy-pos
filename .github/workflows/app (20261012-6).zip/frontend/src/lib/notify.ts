// Thông báo đơn online trên điện thoại + máy tính.
//
// Cách hoạt động: khi trình duyệt đang mở app (kể cả tab chạy nền),
// có đơn online mới → hiện thông báo hệ thống + rung + chuông.
// LƯU Ý: trình duyệt phải đang mở thì mới báo được. Muốn báo cả khi
// tắt trình duyệt thì cần server gửi push (làm sau).
//
const LS_KEY = 'beesy_notify_enabled';

export function isNotifySupported(): boolean {
  return typeof window !== 'undefined' && 'Notification' in window;
}

export function getNotifyPermission(): NotificationPermission | 'unsupported' {
  if (!isNotifySupported()) return 'unsupported';
  return Notification.permission;
}

export function isNotifyEnabled(): boolean {
  return localStorage.getItem(LS_KEY) !== 'off';
}

export function setNotifyEnabled(v: boolean): void {
  localStorage.setItem(LS_KEY, v ? 'on' : 'off');
}

export async function requestNotifyPermission(): Promise<NotificationPermission | 'unsupported'> {
  if (!isNotifySupported()) return 'unsupported';
  if (Notification.permission === 'granted') return 'granted';
  try {
    const p = await Notification.requestPermission();
    return p;
  } catch {
    return Notification.permission;
  }
}

/** Hiện thông báo hệ thống + rung (nếu cho phép). */
export function showOrderNotification(title: string, body: string): void {
  if (!isNotifyEnabled()) return;
  // Rung trên điện thoại
  try {
    if (navigator.vibrate) navigator.vibrate([300, 100, 300, 100, 300]);
  } catch {
    /* bo qua */
  }
  // Thông báo hệ thống (cần quyền)
  if (isNotifySupported() && Notification.permission === 'granted') {
    try {
      const n = new Notification(title, {
        body,
        tag: 'beesy-online-order',
      });
      // Tự đóng sau 10s
      setTimeout(() => n.close(), 10000);
    } catch {
      /* bo qua */
    }
  }
}
