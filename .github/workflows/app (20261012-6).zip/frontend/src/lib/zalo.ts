// Gửi tin Zalo tự động qua Zalo OA.
//
// Vì Zalo chặn gọi API trực tiếp từ trình duyệt (CORS), app gọi qua một
// Cloudflare Worker trung gian (free tier). Token OA nằm ở Worker, KHÔNG
// nằm trong app → an toàn.
//
// Worker nhận: POST {worker_url}/send  body { user_id, text }
// Worker gọi:  POST https://openapi.zalo.me/v3.0/oa/message
//
// Lưu ý: Zalo chỉ cho gửi tới người đã follow OA (cần zalo_user_id, không
// gửi được bằng số điện thoại).
import { doc, getDoc } from 'firebase/firestore';
import { db } from './firebase';
import { setSetting } from './db';

export interface ZaloConfig {
  worker_url: string; // VD: https://beesy-zalo.ten.workers.dev
  oa_id: string;
  configured: boolean;
}

export async function getZaloConfig(): Promise<ZaloConfig> {
  try {
    const [w, o] = await Promise.all([
      getDoc(doc(db, 'settings', 'zalo_worker_url')),
      getDoc(doc(db, 'settings', 'zalo_oa_id')),
    ]);
    const worker_url = w.exists() ? String((w.data() as Record<string, unknown>).value ?? '').trim().replace(/\/$/, '') : '';
    const oa_id = o.exists() ? String((o.data() as Record<string, unknown>).value ?? '').trim() : '';
    return { worker_url, oa_id, configured: !!worker_url };
  } catch {
    return { worker_url: '', oa_id: '', configured: false };
  }
}

export async function saveZaloConfig(worker_url: string, oa_id: string): Promise<void> {
  await setSetting('zalo_worker_url', worker_url.trim().replace(/\/$/, ''));
  await setSetting('zalo_oa_id', oa_id.trim());
}

export interface ZaloSendResult {
  ok: boolean;
  error?: string;
}

/** Gửi 1 tin qua Worker → Zalo OA. */
export async function sendZaloMessage(userId: string, text: string): Promise<ZaloSendResult> {
  const cfg = await getZaloConfig();
  if (!cfg.configured) return { ok: false, error: 'Chưa cấu hình Zalo OA.' };
  if (!userId) return { ok: false, error: 'Khách chưa liên kết Zalo.' };
  try {
    const r = await fetch(`${cfg.worker_url}/send`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ user_id: userId, text: text.slice(0, 2000) }),
    });
    const data = (await r.json()) as Record<string, unknown>;
    // Zalo trả { error: 0, message: "Success", ... } khi thành công
    if (data.error === 0) return { ok: true };
    return { ok: false, error: String(data.message ?? data.error ?? 'Gửi thất bại') };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : 'Không gọi được Worker' };
  }
}

/** Gửi hàng loạt (tuần tự, cách nhau 1.2s để tránh rate-limit). */
export async function sendZaloBulk(
  recipients: { user_id: string; name: string }[],
  text: string,
  onProgress?: (done: number, total: number, name: string, ok: boolean) => void,
): Promise<{ sent: number; failed: { name: string; error: string }[] }> {
  const failed: { name: string; error: string }[] = [];
  let sent = 0;
  for (let i = 0; i < recipients.length; i++) {
    const r = recipients[i];
    const res = await sendZaloMessage(r.user_id, text);
    if (res.ok) sent++;
    else failed.push({ name: r.name, error: res.error ?? 'Lỗi' });
    onProgress?.(i + 1, recipients.length, r.name, res.ok);
    if (i < recipients.length - 1) await new Promise((res2) => setTimeout(res2, 1200));
  }
  return { sent, failed };
}
