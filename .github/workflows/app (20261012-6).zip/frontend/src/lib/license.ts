// Giấy phép / gói cước cho thương mại hoá (mỗi quán 1 bản deploy).
// Key format: BEESY-<PLAN>-<YYYYMMDD>-<CHECKSUM>
// CHECKSUM = djb2(PLAN.EXPIRY.SALT) base36 — chống nhập bừa, KHÔNG phải bảo mật tuyệt đối
// (muốn chống giả mạo thật cần server ký; ở quy mô hiện tại cơ chế này đủ dùng).
import { doc, getDoc } from 'firebase/firestore';
import { db } from './firebase';
import { setSetting } from './db';

const SALT = 'beesy-pos-license-v1';
export type LicensePlan = 'trial' | 'basic' | 'pro';

export interface License {
  plan: LicensePlan;
  expires: string; // YYYY-MM-DD
  valid: boolean;
  daysLeft: number;
}

export const PLAN_LABEL: Record<LicensePlan, string> = {
  trial: 'Dùng thử',
  basic: 'Cơ bản',
  pro: 'Nâng cao (Pro)',
};

/** Tính năng Pro: đặt online, nhập hàng/NCC, voucher, đa kho. */
export function isProFeature(feature: 'online' | 'purchase' | 'voucher' | 'multiwarehouse'): boolean {
  return ['online', 'purchase', 'voucher', 'multiwarehouse'].includes(feature);
}

function checksum(plan: string, expiry: string): string {
  const s = `${plan}.${expiry}.${SALT}`;
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) >>> 0;
  return h.toString(36).toUpperCase().padStart(7, '0');
}

/** Tạo key bản quyền (chủ Beesy dùng để cấp cho quán mua). */
export function generateLicenseKey(plan: LicensePlan, expiryYMD: string): string {
  const exp = expiryYMD.replace(/-/g, '');
  return `BEESY-${plan.toUpperCase()}-${exp}-${checksum(plan.toUpperCase(), exp)}`;
}

/** Kiểm tra key có hợp lệ không. Trả về {plan, expires} hoặc null. */
export function parseLicenseKey(key: string): { plan: LicensePlan; expires: string } | null {
  const m = /^BEESY-(TRIAL|BASIC|PRO)-(\d{8})-([0-9A-Z]{7})$/.exec(key.trim().toUpperCase());
  if (!m) return null;
  const plan = m[1].toLowerCase() as LicensePlan;
  const exp = m[2];
  if (checksum(m[1], exp) !== m[3]) return null;
  const ymd = `${exp.slice(0, 4)}-${exp.slice(4, 6)}-${exp.slice(6, 8)}`;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(ymd)) return null;
  return { plan, expires: ymd };
}

function daysLeft(expires: string): number {
  const [y, m, d] = expires.split('-').map(Number);
  const end = new Date(y, m - 1, d);
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  return Math.round((end.getTime() - today.getTime()) / 86400000);
}

/** Đọc giấy phép hiện tại. Chưa kích hoạt = trial 30 ngày từ lần đầu chạy. */
export async function getLicense(): Promise<License> {
  try {
    const [p, e, first] = await Promise.all([
      getDoc(doc(db, 'settings', 'license_plan')),
      getDoc(doc(db, 'settings', 'license_expires')),
      getDoc(doc(db, 'settings', 'license_first_run')),
    ]);
    let plan = (p.exists() ? String((p.data() as Record<string, unknown>).value ?? '') : '') as LicensePlan;
    let expires = e.exists() ? String((e.data() as Record<string, unknown>).value ?? '') : '';
    if (!['trial', 'basic', 'pro'].includes(plan)) plan = 'trial';
    if (!/^\d{4}-\d{2}-\d{2}$/.test(expires)) {
      // Chưa có hạn: trial 30 ngày kể từ lần đầu
      let firstRun = first.exists() ? String((first.data() as Record<string, unknown>).value ?? '') : '';
      if (!/^\d{4}-\d{2}-\d{2}$/.test(firstRun)) {
        const now = new Date();
        firstRun = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
        await setSetting('license_first_run', firstRun).catch(() => {});
      }
      const [y, m, d] = firstRun.split('-').map(Number);
      const dt = new Date(y, m - 1, d);
      dt.setDate(dt.getDate() + 30);
      expires = `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}-${String(dt.getDate()).padStart(2, '0')}`;
    }
    const left = daysLeft(expires);
    return { plan, expires, valid: left >= 0, daysLeft: left };
  } catch {
    return { plan: 'trial', expires: '', valid: true, daysLeft: 30 };
  }
}

/** Kích hoạt key bản quyền. */
export async function activateLicense(key: string): Promise<License> {
  const parsed = parseLicenseKey(key);
  if (!parsed) throw new Error('Mã bản quyền không hợp lệ.');
  await setSetting('license_plan', parsed.plan);
  await setSetting('license_expires', parsed.expires);
  return getLicense();
}

/** true nếu được dùng tính năng Pro (gói pro/trial còn hạn). */
export async function canUsePro(): Promise<boolean> {
  const lic = await getLicense().catch(() => null);
  if (!lic) return true;
  return lic.valid && (lic.plan === 'pro' || lic.plan === 'trial');
}
