// White-label: logo + màu thương hiệu của quán.
import { doc, getDoc } from 'firebase/firestore';
import { db } from './firebase';

export interface Brand {
  shop_name: string;
  logo: string; // emoji hoặc data URL ảnh
  color: string; // hex, VD: #00B14F
}

const DEFAULT_COLOR = '#00B14F';

/** Nén ảnh logo về tối đa 256px, trả về data URL (lưu thẳng vào settings, không cần Storage). */
export function compressLogoToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      try {
        const max = 256;
        const scale = Math.min(1, max / Math.max(img.width, img.height));
        const w = Math.max(1, Math.round(img.width * scale));
        const h = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (!ctx) throw new Error('no ctx');
        ctx.drawImage(img, 0, 0, w, h);
        URL.revokeObjectURL(url);
        const isPng = file.type === 'image/png';
        resolve(canvas.toDataURL(isPng ? 'image/png' : 'image/jpeg', 0.85));
      } catch (e) {
        URL.revokeObjectURL(url);
        reject(e);
      }
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('Không đọc được ảnh'));
    };
    img.src = url;
  });
}

export function isValidHexColor(v: string): boolean {
  return /^#[0-9a-fA-F]{6}$/.test(v);
}

/** Đọc brand từ settings (dùng được cả khi chưa đăng nhập nếu rules cho phép). */
export async function loadBrand(): Promise<Brand> {
  try {
    const [sn, lg, cl] = await Promise.all([
      getDoc(doc(db, 'settings', 'shop_name')),
      getDoc(doc(db, 'settings', 'brand_logo')),
      getDoc(doc(db, 'settings', 'brand_color')),
    ]);
    const color = cl.exists() ? String((cl.data() as Record<string, unknown>).value ?? '') : '';
    return {
      shop_name: sn.exists() ? String((sn.data() as Record<string, unknown>).value ?? '') : '',
      logo: lg.exists() ? String((lg.data() as Record<string, unknown>).value ?? '') : '',
      color: isValidHexColor(color) ? color : DEFAULT_COLOR,
    };
  } catch {
    return { shop_name: '', logo: '', color: DEFAULT_COLOR };
  }
}

/** Áp màu thương hiệu lên CSS variables. */
export function applyBrandColor(color: string): void {
  if (!isValidHexColor(color)) color = DEFAULT_COLOR;
  const root = document.documentElement;
  root.style.setProperty('--brand', color);
  // Tính màu đậm/nhạt đơn giản từ màu chính
  try {
    const r = parseInt(color.slice(1, 3), 16);
    const g = parseInt(color.slice(3, 5), 16);
    const b = parseInt(color.slice(5, 7), 16);
    const dark = (f: number) =>
      '#' + [r, g, b].map((v) => Math.round(v * f).toString(16).padStart(2, '0')).join('');
    const light = '#' + [r, g, b].map((v) => Math.round(v + (255 - v) * 0.88).toString(16).padStart(2, '0')).join('');
    root.style.setProperty('--brand-dark', dark(0.82));
    root.style.setProperty('--brand-darker', dark(0.65));
    root.style.setProperty('--brand-light', light);
  } catch {
    /* bỏ qua */
  }
}
