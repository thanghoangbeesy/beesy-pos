// Quản lý các quán (CRM cho chủ Beesy) — collection managed_shops.
// Chỉ chủ Beesy (super admin) dùng, lưu trong project của quán Beesy.
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  limit,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
} from 'firebase/firestore';
import { db } from './firebase';
import { DbError, toDbError } from './db';

export type ManagedShopStatus = 'lead' | 'setting_up' | 'live' | 'paused' | 'cancelled';

export const MANAGED_STATUS_LABEL: Record<ManagedShopStatus, string> = {
  lead: '🆕 Tiềm năng',
  setting_up: '🔧 Đang setup',
  live: '✅ Đang hoạt động',
  paused: '⏸️ Tạm dừng',
  cancelled: '❌ Hủy',
};

export interface ManagedShop {
  id: string;
  shop_name: string;
  owner_name: string;
  owner_phone: string;
  owner_email: string | null;
  address: string | null;
  status: ManagedShopStatus;
  firebase_project: string | null;
  hosting_url: string | null;
  license_plan: string | null;
  license_expiry: string | null; // YYYY-MM-DD
  checklist: Record<string, boolean>;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

function fromDoc(id: string, d: Record<string, unknown>): ManagedShop {
  const ts = (v: unknown): string => {
    if (!v) return '';
    if (typeof (v as { toDate?: unknown }).toDate === 'function')
      return ((v as { toDate: () => Date }).toDate()).toISOString();
    return String(v);
  };
  const st = String(d.status ?? 'lead');
  return {
    id,
    shop_name: String(d.shop_name ?? ''),
    owner_name: String(d.owner_name ?? ''),
    owner_phone: String(d.owner_phone ?? ''),
    owner_email: (d.owner_email as string | null) ?? null,
    address: (d.address as string | null) ?? null,
    status: (['lead', 'setting_up', 'live', 'paused', 'cancelled'] as string[]).includes(st)
      ? (st as ManagedShopStatus)
      : 'lead',
    firebase_project: (d.firebase_project as string | null) ?? null,
    hosting_url: (d.hosting_url as string | null) ?? null,
    license_plan: (d.license_plan as string | null) ?? null,
    license_expiry: (d.license_expiry as string | null) ?? null,
    checklist: (d.checklist as Record<string, boolean>) ?? {},
    notes: (d.notes as string | null) ?? null,
    created_at: ts(d.created_at),
    updated_at: ts(d.updated_at),
  };
}

export async function listManagedShops(): Promise<ManagedShop[]> {
  try {
    const snap = await getDocs(query(collection(db, 'managed_shops'), orderBy('updated_at', 'desc'), limit(200)));
    return snap.docs.map((d) => fromDoc(d.id, d.data() as Record<string, unknown>));
  } catch (e) {
    throw toDbError(e);
  }
}

export interface ManagedShopInput {
  shop_name: string;
  owner_name: string;
  owner_phone: string;
  owner_email?: string | null;
  address?: string | null;
  status?: ManagedShopStatus;
  firebase_project?: string | null;
  hosting_url?: string | null;
  license_plan?: string | null;
  license_expiry?: string | null;
  notes?: string | null;
}

export async function saveManagedShop(id: string | null, input: ManagedShopInput): Promise<ManagedShop> {
  if (!input.shop_name.trim()) throw new DbError('invalid-argument', 'Thiếu tên quán.');
  if (!input.owner_name.trim()) throw new DbError('invalid-argument', 'Thiếu tên chủ quán.');
  try {
    const ref = id ? doc(db, 'managed_shops', id) : doc(collection(db, 'managed_shops'));
    const ex = id ? await getDoc(ref) : null;
    const prev = ex?.exists() ? (ex.data() as Record<string, unknown>) : {};
    await setDoc(
      ref,
      {
        id: ref.id,
        shop_name: input.shop_name.trim(),
        owner_name: input.owner_name.trim(),
        owner_phone: input.owner_phone.trim(),
        owner_email: input.owner_email?.trim() || null,
        address: input.address?.trim() || null,
        status: input.status ?? (prev.status as string) ?? 'lead',
        firebase_project: input.firebase_project?.trim() || null,
        hosting_url: input.hosting_url?.trim() || null,
        license_plan: input.license_plan?.trim() || null,
        license_expiry: input.license_expiry?.trim() || null,
        checklist: (prev.checklist as Record<string, boolean>) ?? {},
        notes: input.notes?.trim() || null,
        created_at: prev.created_at ?? serverTimestamp(),
        updated_at: serverTimestamp(),
      },
      { merge: true },
    );
    const snap = await getDoc(ref);
    if (!snap.exists()) throw new DbError('unknown', 'Không đọc được quán vừa lưu.');
    return fromDoc(snap.id, snap.data() as Record<string, unknown>);
  } catch (e) {
    throw toDbError(e);
  }
}

export async function updateShopChecklist(id: string, checklist: Record<string, boolean>): Promise<void> {
  try {
    await setDoc(doc(db, 'managed_shops', id), { checklist, updated_at: serverTimestamp() }, { merge: true });
  } catch (e) {
    throw toDbError(e);
  }
}

export async function deleteManagedShop(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'managed_shops', id));
  } catch (e) {
    throw toDbError(e);
  }
}
