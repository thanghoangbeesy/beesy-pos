// Cac buoc setup quan moi — dung chung cho trang checklist va quan ly quan.
export interface SetupStep {
  id: string;
  title: string;
  detail?: string;
  link?: string;
}

export interface SetupPhase {
  title: string;
  icon: string;
  steps: SetupStep[];
}

export const PHASES: SetupPhase[] = [
  {
    title: 'Firebase project mới',
    icon: '🔥',
    steps: [
      {
        id: 'fb-project',
        title: 'Tạo project mới',
        detail: 'console.firebase.google.com → Add project → đặt tên (VD: beesy-quan-a) → TẮT Google Analytics.',
        link: 'https://console.firebase.google.com',
      },
      {
        id: 'fb-auth',
        title: 'Bật Authentication',
        detail: 'Build → Authentication → Sign-in method → bật Email/Password.',
      },
      {
        id: 'fb-firestore',
        title: 'Tạo Firestore Database',
        detail: 'Build → Firestore Database → Create database → region asia-southeast1 → Start in production mode.',
      },
      {
        id: 'fb-hosting',
        title: 'Tạo Hosting site',
        detail: 'Build → Hosting → Get started → tạo site (VD: beesy-quan-a).',
      },
      {
        id: 'fb-rules',
        title: 'Dán Firestore rules',
        detail: 'Firestore → Rules → xóa hết → dán toàn bộ file firestore.rules (trong app.zip) → Publish.',
      },
      {
        id: 'fb-indexes',
        title: 'Tạo indexes',
        detail: 'Firestore → Indexes → Add index: collection online_orders, fields status (ASC) + created_at (DESC). Hoặc deploy từ file firestore.indexes.json.',
      },
    ],
  },
  {
    title: 'GitHub + Deploy',
    icon: '🐙',
    steps: [
      {
        id: 'gh-repo',
        title: 'Tạo repo mới',
        detail: 'github.com → New repository (VD: beesy-quan-a) → tạo file .github/workflows/deploy.yml (copy từ source).',
        link: 'https://github.com/new',
      },
      {
        id: 'gh-zip',
        title: 'Upload app.zip',
        detail: 'Trong repo: Add file → Upload files → chọn app.zip bản mới nhất → Commit.',
      },
      {
        id: 'gh-secrets',
        title: 'Thêm secrets',
        detail: 'Settings → Secrets → Actions → thêm: FIREBASE_SERVICE_ACCOUNT (JSON key từ Project settings → Service accounts), FIREBASE_PROJECT_ID, và 6 giá trị VITE_FIREBASE_* (từ Project settings → Your apps → Web app).',
      },
      {
        id: 'gh-deploy',
        title: 'Chạy workflow Deploy',
        detail: 'Tab Actions → Deploy to Firebase → Run workflow → đợi xanh.',
      },
    ],
  },
  {
    title: 'Cấu hình quán',
    icon: '⚙️',
    steps: [
      {
        id: 'cfg-owner',
        title: 'Tạo chủ quán',
        detail: 'Mở https://<site>.web.app/setup → tạo tài khoản chủ quán.',
      },
      {
        id: 'cfg-menu',
        title: 'Nạp menu mẫu',
        detail: 'Ở /setup: chọn ngành nghề (trà sữa/cà phê, ăn vặt, cơm/bún/phở) → nạp menu mẫu.',
      },
      {
        id: 'cfg-brand',
        title: 'Đổi tên/logo/màu',
        detail: 'Cài đặt → Thông tin quán (tên, link đặt hàng) + Thương hiệu (logo, màu).',
      },
      {
        id: 'cfg-license',
        title: 'Tạo license key',
        detail: 'Cài đặt → Giấy phép sử dụng → tạo mã theo gói đã bán → gửi cho chủ quán nhập để kích hoạt.',
      },
      {
        id: 'cfg-qr',
        title: 'In QR đặt hàng',
        detail: 'Cài đặt → Thông tin quán → copy link + QR /dat-hang → in dán tại quầy.',
      },
    ],
  },
  {
    title: 'Kiểm tra + Bàn giao',
    icon: '✅',
    steps: [
      {
        id: 'test-pos',
        title: 'Test bán 1 đơn',
        detail: 'Bán thử 1 đơn ở POS → KDS hiện → báo cáo đúng số.',
      },
      {
        id: 'test-online',
        title: 'Test đặt online',
        detail: 'Mở /dat-hang trên điện thoại khác (không đăng nhập) → đặt thử → duyệt ở KDS.',
      },
      {
        id: 'test-notify',
        title: 'Test thông báo',
        detail: 'Ở màn Pha chế: bấm "📢 Bật thông báo" → đặt đơn test → kiểm tra chuông + thông báo hiện.',
      },
      {
        id: 'handover',
        title: 'Bàn giao',
        detail: 'Giao tài khoản chủ quán + hướng dẫn cơ bản. Nhắc bật Sao lưu định kỳ (Cài đặt).',
      },
    ],
  },
];


export function getTotalSteps(): number {
  return PHASES.reduce((s, p) => s + p.steps.length, 0);
}

export function getDoneSteps(checklist: Record<string, boolean>): number {
  return PHASES.reduce((s, p) => s + p.steps.filter((st) => checklist[st.id]).length, 0);
}
