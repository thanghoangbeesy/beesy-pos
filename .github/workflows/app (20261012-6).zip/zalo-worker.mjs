// Cloudflare Worker — cầu nối Beesy POS → Zalo OA API.
// Deploy 1 lần duy nhất (free tier), dùng cho mọi tin nhắn.
//
// Cách deploy (trên điện thoại):
// 1. Tạo tài khoản Cloudflare (miễn phí) → Workers & Pages → Create Worker.
// 2. Dán toàn bộ file này vào → Deploy.
// 3. Workers → Settings → Variables → thêm 2 biến:
//      ZALO_ACCESS_TOKEN = token OA (lấy ở Zalo OA Dashboard → Cài đặt)
//      ZALO_OA_ID        = ID của OA (không bắt buộc, để kiểm tra)
// 4. Copy URL của Worker (vd: https://beesy-zalo.ten.workers.dev)
//    → nhập vào app: Cài đặt → Zalo OA → Worker URL.
//
// Bảo mật: token nằm ở Worker, không nằm trong app.

export default {
  async fetch(request, env) {
    const cors = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    };
    if (request.method === 'OPTIONS') {
      return new Response(null, { headers: cors });
    }
    const url = new URL(request.url);

    // Kiểm tra worker sống không
    if (url.pathname === '/ping') {
      return Response.json({ ok: true }, { headers: cors });
    }

    if (url.pathname === '/send' && request.method === 'POST') {
      const token = env.ZALO_ACCESS_TOKEN;
      if (!token) {
        return Response.json({ error: -1, message: 'Worker chưa cấu hình ZALO_ACCESS_TOKEN' }, { headers: cors });
      }
      let body;
      try {
        body = await request.json();
      } catch {
        return Response.json({ error: -1, message: 'Body không phải JSON' }, { headers: cors });
      }
      const user_id = String(body.user_id || '').trim();
      const text = String(body.text || '').trim().slice(0, 2000);
      if (!user_id || !text) {
        return Response.json({ error: -1, message: 'Thiếu user_id hoặc text' }, { headers: cors });
      }
      try {
        const r = await fetch('https://openapi.zalo.me/v3.0/oa/message', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', access_token: token },
          body: JSON.stringify({ recipient: { user_id }, message: { text } }),
        });
        const data = await r.json();
        return Response.json(data, { headers: cors });
      } catch (e) {
        return Response.json({ error: -1, message: 'Không gọi được Zalo API: ' + String(e) }, { headers: cors });
      }
    }

    return new Response('Not found', { status: 404, headers: cors });
  },
};
