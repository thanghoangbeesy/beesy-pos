# Hướng dẫn bán Beesy POS cho quán khác

Tài liệu này dành cho Hoàng — quy trình triển khai 1 quán mới **100% bằng điện thoại**, không cần máy tính.

## Mô hình

- Mỗi quán = **1 Firebase project riêng** + **1 bản deploy riêng** (multi-tenant kiểu "mỗi quán 1 nhà").
- Quán dùng gói **Spark miễn phí** của Firebase (50k đọc / 20k ghi / ngày — dư cho quán nhỏ).
- Hoàng thu tiền **bản quyền theo năm** qua mã license (tạo trong app: Cài đặt → Giấy phép sử dụng → "Tạo mã cho khách").

## Gói cước gợi ý

| Gói | Giá gợi ý | Tính năng |
|-----|-----------|-----------|
| Dùng thử | Miễn phí 30 ngày | Full Pro |
| Cơ bản | ~1.5tr/năm | Bán hàng, menu, khách hàng, sổ quỹ, báo cáo, kho đơn |
| Nâng cao (Pro) | ~3tr/năm | Thêm: đặt hàng online, nhập hàng/NCC, voucher, đa kho |

## Triển khai quán mới (khoảng 30 phút, làm trên điện thoại)

### Bước 1: Tạo Firebase project mới
1. Mở [console.firebase.google.com](https://console.firebase.google.com) → **Add project** → đặt tên VD `beesy-quan-a` → tắt Google Analytics (không cần).
2. **Build** → **Authentication** → **Sign-in method** → bật **Email/Password**.
3. **Build** → **Firestore Database** → **Create database** → chọn region `asia-southeast1` → **Start in production mode**.
4. **Build** → **Hosting** → **Get started** → tạo site (VD `beesy-quan-a`).

### Bước 2: Nạp rules + indexes
1. Trong Firestore → **Rules** → dán toàn bộ nội dung file `firestore.rules` trong source → **Publish**.
2. **Indexes** → **Add index** theo file `firestore.indexes.json` (hoặc để app báo thiếu rồi bấm tạo tự động).

### Bước 3: Deploy app
1. Tạo repo GitHub mới (VD `beesy-quan-a`), upload `app.zip` bản mới nhất, chạy workflow **Deploy**.
2. Workflow cần 2 secrets: `FIREBASE_SERVICE_ACCOUNT` (lấy từ Project settings → Service accounts → Generate new private key) và `FIREBASE_PROJECT_ID`.
3. Mở link `https://<site>.web.app/setup` → tạo tài khoản chủ quán → chọn ngành nghề → nạp menu mẫu.

### Bước 4: Bàn giao
1. Đổi tên quán, logo, màu thương hiệu: Cài đặt → Thông tin quán + Thương hiệu.
2. Tạo mã license: Cài đặt → Giấy phép sử dụng → chọn gói + hạn → **Tạo mã** → gửi cho chủ quán → họ nhập mã để kích hoạt.
3. Hướng dẫn chủ quán: in QR đặt hàng (Cài đặt → Thông tin quán → Link đặt hàng online), dán tại quầy.

## Checklist trước khi bàn giao

- [ ] Rules đã dán bản mới nhất (có `vouchers`, `online_orders`, `suppliers`, `purchase_orders`)
- [ ] Đăng nhập được bằng tài khoản chủ quán
- [ ] Bán thử 1 đơn → KDS hiện → báo cáo đúng
- [ ] Thử đặt online từ điện thoại khác → duyệt ở KDS
- [ ] License đã kích hoạt đúng gói/hạn
- [ ] Tên + logo + màu quán đã đổi

## Lưu ý

- **Không dùng chung project** giữa các quán — dữ liệu lẫn lộn, khó tính phí.
- Key license chỉ chống nhập bừa, không chống được người cố tình bẻ khoá. Muốn bảo mật thật cần server ký — để giai đoạn sau.
- Backup: nhắc quán bật Sao lưu & khôi phục (Cài đặt) định kỳ.
