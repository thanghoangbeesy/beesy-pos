import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { DbError, applyGoodsCosts, applyGoodsCostsToPoint, getAllowedWarehouses, getDailyBreakdown, getDailyExpenses, getDailyPurchaseCosts, getFundCurrentBalances, getHourlyBreakdown, getRangeReport, getSettings, getTotalCustomerDebt, listOrders, searchCustomers, type FundBalance } from '../lib/db';
import {
  addDaysVN,
  endOfMonthVN,
  formatDMY,
  formatVND,
  startOfMonthVN,
  startOfWeekVN,
  todayVN,
} from '../lib/format';
import { useToast } from '../components/Toast';
import { LowStockPanel, useStockOverview } from '../components/StockOverview';
import { useAuth } from '../lib/auth';
import { LineIcon } from '../components/LineIcon';
import type { Customer, DailyReport, Order, Warehouse } from '../lib/types';

type PresetKey = 'today' | 'yesterday' | 'thisWeek' | 'lastWeek' | 'thisMonth' | 'lastMonth';

const PRESETS: { key: PresetKey; label: string }[] = [
  { key: 'today', label: 'Hôm nay' },
  { key: 'yesterday', label: 'Hôm qua' },
  { key: 'thisWeek', label: 'Tuần này' },
  { key: 'lastWeek', label: 'Tuần trước' },
  { key: 'thisMonth', label: 'Tháng này' },
  { key: 'lastMonth', label: 'Tháng trước' },
];

function presetRange(key: PresetKey): [string, string] {
  const t = todayVN();
  switch (key) {
    case 'today': return [t, t];
    case 'yesterday': { const y = addDaysVN(t, -1); return [y, y]; }
    case 'thisWeek': return [startOfWeekVN(t), t];
    case 'lastWeek': {
      const mondayThis = startOfWeekVN(t);
      const mondayLast = addDaysVN(mondayThis, -7);
      return [mondayLast, addDaysVN(mondayLast, 6)];
    }
    case 'thisMonth': return [startOfMonthVN(t), t];
    case 'lastMonth': {
      const firstThisMonth = startOfMonthVN(t);
      const lastDayPrev = addDaysVN(firstThisMonth, -1);
      return [startOfMonthVN(lastDayPrev), lastDayPrev];
    }
  }
}

function prevRange(key: PresetKey): [string, string] {
  const t = todayVN();
  switch (key) {
    case 'today': { const y = addDaysVN(t, -1); return [y, y]; }
    case 'yesterday': { const y = addDaysVN(t, -2); return [y, y]; }
    case 'thisWeek': {
      const mondayThis = startOfWeekVN(t);
      const mondayLast = addDaysVN(mondayThis, -7);
      return [mondayLast, addDaysVN(mondayLast, 6)];
    }
    case 'lastWeek': {
      const mondayThis = startOfWeekVN(t);
      const mondayLast2 = addDaysVN(mondayThis, -14);
      return [mondayLast2, addDaysVN(mondayLast2, 6)];
    }
    case 'thisMonth': {
      const firstThisMonth = startOfMonthVN(t);
      const lastDayPrev = addDaysVN(firstThisMonth, -1);
      return [startOfMonthVN(lastDayPrev), lastDayPrev];
    }
    case 'lastMonth': {
      const firstThisMonth = startOfMonthVN(t);
      const lastDayPrev = addDaysVN(firstThisMonth, -1);
      const firstPrev = startOfMonthVN(lastDayPrev);
      const lastDayPrev2 = addDaysVN(firstPrev, -1);
      return [startOfMonthVN(lastDayPrev2), lastDayPrev2];
    }
  }
}

/** Nhãn kỳ này / kỳ trước cho tiêu đề biểu đồ so sánh (kỳ trước viết thường
 *  để ghép câu "Kỳ này so với kỳ trước", ví dụ "Hôm nay so với hôm qua"). */
function chartLabels(key: PresetKey): { cur: string; prev: string } {
  switch (key) {
    case 'today': return { cur: 'Hôm nay', prev: 'hôm qua' };
    case 'yesterday': return { cur: 'Hôm qua', prev: 'hôm kia' };
    case 'thisWeek': return { cur: 'Tuần này', prev: 'tuần trước' };
    case 'lastWeek': return { cur: 'Tuần trước', prev: 'tuần trước nữa' };
    case 'thisMonth': return { cur: 'Tháng này', prev: 'tháng trước' };
    case 'lastMonth': return { cur: 'Tháng trước', prev: 'tháng trước nữa' };
  }
}

function cap(s: string): string {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

/** Giờ VN (HH:mm) từ ISO, dùng cho widget đơn gần đây. */
function timeOf(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  return d.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Ho_Chi_Minh' });
}

type ChartMetric = 'revenue' | 'profit' | 'expense';

/** Muc cua bieu do cot: mau cot ky nay dam, cot ky truoc nhat cung mau. */
const METRICS: { key: ChartMetric; label: string; curColor: string; prevColor: string }[] = [
  { key: 'revenue', label: 'Doanh thu', curColor: '#00B14F', prevColor: '#86EFAC' },
  { key: 'profit', label: 'Lợi nhuận', curColor: '#2563EB', prevColor: '#93C5FD' },
  { key: 'expense', label: 'Chi phí', curColor: '#DC2626', prevColor: '#FCA5A5' },
];

/** 1 điểm trên biểu đồ so sánh: nhãn trục + chi tiết tooltip + 2 cặp số.
 *  Chi phí mặc định = chi phí vận hành (tách riêng, không phải giá vốn);
 *  bật công tắc "tính chi phí nhập hàng + nguyên liệu" thì cộng thêm
 *  purchase (tiền nhập hàng) + cost (giá vốn) vào chi phí, lợi nhuận trừ thêm purchase. */
interface ChartPoint {
  key: string;
  label: string;
  detail: string;
  thisRevenue: number;
  thisProfit: number;
  thisExpense: number;
  thisPurchase: number;
  thisCost: number;
  lastRevenue: number;
  lastProfit: number;
  lastExpense: number;
  lastPurchase: number;
  lastCost: number;
}

type ChartMode = 'hour' | 'week' | 'month';

function pctChange(cur: number, prev: number): number | null {
  if (prev === 0) return cur > 0 ? 100 : null;
  return ((cur - prev) / prev) * 100;
}

const PAY_COLORS = ['#00B14F', '#2563EB', '#9333EA', '#F59E0B', '#9CA3AF'];

export function ReportsPC() {
  const toast = useToast();
  const { can, user } = useAuth();
  const navigate = useNavigate();
  const [preset, setPreset] = useState<PresetKey>('today');
  const [report, setReport] = useState<DailyReport | null>(null);
  const [prevReport, setPrevReport] = useState<DailyReport | null>(null);
  const [debtTotal, setDebtTotal] = useState<number | null>(null);
  const [chartData, setChartData] = useState<ChartPoint[]>([]);
  const [chartMeta, setChartMeta] = useState<{ mode: ChartMode; cur: string; prev: string }>({ mode: 'hour', cur: 'Hôm nay', prev: 'hôm qua' });
  const [chartMetric, setChartMetric] = useState<ChartMetric>('revenue');
  const [includeGoods, setIncludeGoods] = useState(false);
  const [selectedIdx, setSelectedIdx] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [isOwner, setIsOwner] = useState(false);
  const { low } = useStockOverview(warehouses);
  // Widget phụ (trạng thái hiện tại, không theo kỳ): số dư quỹ, khách nợ, đơn mới nhất.
  const [funds, setFunds] = useState<FundBalance[]>([]);
  const [debtors, setDebtors] = useState<Customer[]>([]);
  const [recentOrders, setRecentOrders] = useState<Order[]>([]);
  // Sắp xếp món bán chạy (mặc định: số lượng, giảm dần — như bản demo đã duyệt).
  const [topSortKey, setTopSortKey] = useState<'qty' | 'revenue' | 'profit'>('qty');
  const [topSortDir, setTopSortDir] = useState<'desc' | 'asc'>('desc');

  const load = useCallback(async (key: PresetKey, ids?: string[]) => {
    setBusy(true);
    try {
      const [s, e] = presetRange(key);
      const [ps, pe] = prevRange(key);
      const t = todayVN();
      const [cur, prev, st, debt] = await Promise.all([
        getRangeReport(s, e, ids),
        getRangeReport(ps, pe, ids),
        getSettings(),
        getTotalCustomerDebt(ids),
      ]);
      setReport(cur);
      setPrevReport(prev);
      setIncludeGoods(st['include_goods_costs'] === '1');
      setDebtTotal(debt);
      // Biểu đồ so sánh chạy theo kỳ đã chọn (v6.4): kỳ 1 ngày -> theo giờ
      // (24 giờ, kỳ trước là ngày liền trước); kỳ nhiều ngày -> theo ngày
      // (tuần: T2-CN, kỳ trước là tuần liền trước; tháng: ngày 1-31, kỳ trước
      // là tháng liền trước, ngày không có trong tháng trước tính 0).
      const meta = chartLabels(key);
      if (key === 'today' || key === 'yesterday') {
        const [day] = presetRange(key);
        const [prevDay] = prevRange(key);
        const hours = await getHourlyBreakdown(day, prevDay, ids);
        setChartData(hours.map((h) => ({
          key: String(h.hour),
          label: String(h.hour),
          detail: `${h.hour}h`,
          thisRevenue: h.curRevenue,
          thisProfit: h.curProfit,
          thisExpense: h.curExpense,
          thisPurchase: h.curPurchase,
          thisCost: h.curCost,
          lastRevenue: h.prevRevenue,
          lastProfit: h.prevProfit,
          lastExpense: h.prevExpense,
          lastPurchase: h.prevPurchase,
          lastCost: h.prevCost,
        })));
        setChartMeta({ mode: 'hour', ...meta });
      } else if (key === 'thisWeek' || key === 'lastWeek') {
        const mondayThis = startOfWeekVN(t);
        const curMon = key === 'thisWeek' ? mondayThis : addDaysVN(mondayThis, -7);
        const prevMon = addDaysVN(curMon, -7);
        const dayLabels = ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'];
        const [curDays, prevDays, curExp, prevExp, curPur, prevPur] = await Promise.all([
          getDailyBreakdown(curMon, addDaysVN(curMon, 6), ids),
          getDailyBreakdown(prevMon, addDaysVN(prevMon, 6), ids),
          getDailyExpenses(curMon, addDaysVN(curMon, 6), ids),
          getDailyExpenses(prevMon, addDaysVN(prevMon, 6), ids),
          getDailyPurchaseCosts(curMon, addDaysVN(curMon, 6), ids),
          getDailyPurchaseCosts(prevMon, addDaysVN(prevMon, 6), ids),
        ]);
        setChartData(dayLabels.map((dayLabel, i) => ({
          key: addDaysVN(curMon, i),
          label: dayLabel,
          detail: `${dayLabel} ${formatDMY(addDaysVN(curMon, i))}`,
          thisRevenue: curDays[i]?.revenue ?? 0,
          thisProfit: curDays[i]?.profit ?? 0,
          thisExpense: curExp[i]?.expense ?? 0,
          thisPurchase: curPur[i]?.purchase ?? 0,
          thisCost: curDays[i]?.cost ?? 0,
          lastRevenue: prevDays[i]?.revenue ?? 0,
          lastProfit: prevDays[i]?.profit ?? 0,
          lastExpense: prevExp[i]?.expense ?? 0,
          lastPurchase: prevPur[i]?.purchase ?? 0,
          lastCost: prevDays[i]?.cost ?? 0,
        })));
        setChartMeta({ mode: 'week', ...meta });
      } else {
        const firstThisMonth = startOfMonthVN(t);
        const curFirst = key === 'thisMonth' ? firstThisMonth : startOfMonthVN(addDaysVN(firstThisMonth, -1));
        const curLast = endOfMonthVN(curFirst);
        const prevFirst = startOfMonthVN(addDaysVN(curFirst, -1));
        const prevLast = addDaysVN(curFirst, -1);
        const [curDays, prevDays, curExp, prevExp, curPur, prevPur] = await Promise.all([
          getDailyBreakdown(curFirst, curLast, ids),
          getDailyBreakdown(prevFirst, prevLast, ids),
          getDailyExpenses(curFirst, curLast, ids),
          getDailyExpenses(prevFirst, prevLast, ids),
          getDailyPurchaseCosts(curFirst, curLast, ids),
          getDailyPurchaseCosts(prevFirst, prevLast, ids),
        ]);
        setChartData(curDays.map((d, i) => ({
          key: d.date,
          label: String(i + 1),
          detail: formatDMY(d.date),
          thisRevenue: d.revenue,
          thisProfit: d.profit,
          thisExpense: curExp[i]?.expense ?? 0,
          thisPurchase: curPur[i]?.purchase ?? 0,
          thisCost: d.cost,
          lastRevenue: prevDays[i]?.revenue ?? 0,
          lastProfit: prevDays[i]?.profit ?? 0,
          lastExpense: prevExp[i]?.expense ?? 0,
          lastPurchase: prevPur[i]?.purchase ?? 0,
          lastCost: prevDays[i]?.cost ?? 0,
        })));
        setChartMeta({ mode: 'month', ...meta });
      }
    } catch (err) {
      toast.show(err instanceof DbError ? err.message : 'Không tải được báo cáo');
    } finally {
      setBusy(false);
    }
  }, [toast]);

  // Widget phụ chỉ tải 1 lần (số dư quỹ + khách nợ + đơn mới nhất là trạng thái
  // hiện tại, không đổi theo kỳ). Lỗi ở đây không chặn trang chính nên không toast.
  const loadWidgets = useCallback(async (ids?: string[]) => {
    try {
      const t = todayVN();
      const [fb, customers, orders] = await Promise.all([
        getFundCurrentBalances(ids ?? []),
        searchCustomers(''),
        listOrders({ from: addDaysVN(t, -30), to: t, limitN: 20, warehouseIds: ids }),
      ]);
      setFunds(fb);
      const scoped = ids ? customers.filter((c) => !c.warehouse_id || ids.includes(c.warehouse_id)) : customers;
      setDebtors(scoped.filter((c) => c.debt > 0).sort((a, b) => b.debt - a.debt));
      setRecentOrders(orders.slice(0, 5));
    } catch {
      // Giữ widget trống, trang chính vẫn hiện đủ số liệu kỳ đang xem.
    }
  }, []);

  useEffect(() => {
    getAllowedWarehouses()
      .then(({ warehouses: ws, isOwner: ow }) => {
        setWarehouses(ws);
        setIsOwner(ow);
        const ids = ow ? undefined : ws.map((w) => w.id);
        void load('today', ids);
        void loadWidgets(ids);
      })
      .catch(() => { void load('today'); void loadWidgets(); });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const pickPreset = (key: PresetKey) => {
    setPreset(key);
    setSelectedIdx(null);
    const ids = isOwner ? undefined : warehouses.map((w) => w.id);
    void load(key, ids);
  };


  // Kỳ đang xem (để thẻ Doanh thu/Tổng chi phí bấm sang trang chi tiết đúng kỳ)
  const [rs, re] = presetRange(preset);
  const labels = chartLabels(preset);
  const kpis: { label: string; value: string; icon: string; iconColor: string; bg: string; change: number | null; to?: string; hint?: string }[] = useMemo(() => {
    if (!report) return [];
    const p = prevReport;
    const dispCur = applyGoodsCosts(report, includeGoods);
    const dispPrev = p ? applyGoodsCosts(p, includeGoods) : null;
    return [
      { label: 'Doanh thu', value: formatVND(report.revenue), icon: 'wallet', iconColor: '#2563EB', bg: '#EFF4FF', change: p ? pctChange(report.revenue, p.revenue) : null, to: `/orders?from=${rs}&to=${re}`, hint: 'Bấm để xem các khoản thu' },
      { label: 'Lợi nhuận', value: formatVND(dispCur.profit), icon: 'chart', iconColor: '#15803D', bg: '#ECFDF5', change: dispPrev ? pctChange(dispCur.profit, dispPrev.profit) : null },
      { label: 'Số đơn', value: String(report.order_count), icon: 'receipt', iconColor: '#7C3AED', bg: '#F5F0FF', change: p ? pctChange(report.order_count, p.order_count) : null },
      { label: 'TB/đơn', value: formatVND(Math.round(report.avg_order)), icon: 'tag', iconColor: '#B45309', bg: '#FFFBEB', change: p ? pctChange(report.avg_order, p.avg_order) : null },
      { label: 'Tổng chi phí', value: formatVND(report.all_chi ?? 0), icon: 'ledger', iconColor: '#DC2626', bg: '#FEF2F2', change: p ? pctChange(report.all_chi ?? 0, p.all_chi ?? 0) : null, to: `/so-quy?from=${rs}&to=${re}&type=chi`, hint: 'Bấm để xem các khoản chi' },
      ...(can('debt') ? [{ label: 'Tổng công nợ', value: formatVND(debtTotal ?? 0), icon: 'users', iconColor: '#7C3AED', bg: '#F5F0FF', change: null, to: '/debt', hint: 'Bấm để xem Sổ nợ' }] : []),
    ];
  }, [report, prevReport, includeGoods, debtTotal, rs, re]);


  // Thang do bieu do cot: tinh theo MUC DANG CHON, ca 2 ky. Doanh thu /
  // chi phi chi co gia tri duong (truc 0 o day); loi nhuan co the am nen
  // thang gom ca phan am, cot am ve xuong duoi truc 0.
  const metricValues = (d: ChartPoint): [number, number] => {
    if (chartMetric === 'revenue') return [d.thisRevenue, d.lastRevenue];
    const cur = applyGoodsCostsToPoint({ profit: d.thisProfit, expense: d.thisExpense, purchase: d.thisPurchase, cost: d.thisCost }, includeGoods);
    const prev = applyGoodsCostsToPoint({ profit: d.lastProfit, expense: d.lastExpense, purchase: d.lastPurchase, cost: d.lastCost }, includeGoods);
    return chartMetric === 'profit' ? [cur.profit, prev.profit] : [cur.expense, prev.expense];
  };
  const metricVals = chartData.flatMap((d) => metricValues(d));
  const maxPos = Math.max(1, ...metricVals.filter((v) => v > 0));
  const maxNeg = Math.max(0, ...metricVals.filter((v) => v < 0).map((v) => -v));

  // Hinh hoc bieu do cot: thang tuyen tinh theo muc dang chon, truc 0 dam;
  // cot duong ve len tu truc 0, cot am (chi loi nhuan am) ve xuong duoi
  // truc 0. Thang khong doi khi an/hien vi khong con legend an duong.
  const svgW = 640;
  const svgH = 260;
  const svgPadT = 16;
  const svgPadB = 24;
  const svgPadX = 10;
  const svgPlotH = svgH - svgPadT - svgPadB;
  // Hinh hoc cot nhom: moi moc la 1 nhom 2 cot sat nhau (ky nay ben trai,
  // ky truoc ben phai). Cot rong toi da 22px de che do tuan khong bi be.
  const svgSlot = chartData.length > 0 ? (svgW - 2 * svgPadX) / chartData.length : svgW - 2 * svgPadX;
  const barW = Math.max(2, Math.min(svgSlot * 0.34, 22));
  const barGap = Math.max(1, svgSlot * 0.08);
  const svgX = (i: number) => svgPadX + svgSlot * (i + 0.5);
  const svgY = (v: number) => svgPadT + ((maxPos - v) / (maxPos + maxNeg)) * svgPlotH;
  const svgZeroY = svgY(0);
  const barRect = (v: number, x: number) => ({ x, y: Math.min(svgY(v), svgZeroY), height: Math.abs(svgY(v) - svgZeroY) });
  const showXLabel = (d: ChartPoint, i: number): boolean => {
    if (chartMeta.mode === 'week') return true;
    if (chartMeta.mode === 'hour') return Number(d.label) % 6 === 0;
    const day = i + 1;
    return day === 1 || day % 5 === 0;
  };
  const xLabelText = (d: ChartPoint) => chartMeta.mode === 'hour' ? `${d.label}h` : d.label;
  const sel = selectedIdx !== null ? chartData[selectedIdx] : undefined;
  const selMetricCur = sel ? metricValues(sel)[0] : 0;
  const selMetricPrev = sel ? metricValues(sel)[1] : 0;
  const selMetricDiff = selMetricCur - selMetricPrev;
  const selMetricPct = sel ? pctChange(selMetricCur, selMetricPrev) : null;
  // Bieu do cot (ve lai phuong an ban dau): 1 SVG duy nhat, moi moc 1 nhom
  // 2 cot (ky nay dam ben trai, ky truoc nhat ben phai), chi ve muc dang
  // chon. Thang do tinh theo muc dang chon nen chuyen muc khong bep hinh.
  // Cột đang chọn có viền đậm (theo bản demo đã duyệt).
  const metricMeta = METRICS.find((m) => m.key === chartMetric) ?? METRICS[0];
  const chartBars = (
    <svg width="100%" viewBox={`0 0 ${svgW} ${svgH}`} role="img" aria-label={`Biểu đồ cột ${metricMeta.label}`}>
      {chartData.map((d, idx) => showXLabel(d, idx) && (
        <line key={`g${d.key}`} x1={svgX(idx)} y1={svgPadT} x2={svgX(idx)} y2={svgH - svgPadB} stroke="#E2E8F0" strokeWidth={1} />
      ))}
      <line x1={svgPadX} y1={svgZeroY} x2={svgW - svgPadX} y2={svgZeroY} stroke="#64748B" strokeWidth={2} />
      <text x={svgPadX} y={svgPadT + 10} fontSize={10} fill="#94A3B8">{formatVND(maxPos)}</text>
      {maxNeg > 0 && (
        <text x={svgPadX} y={svgH - 4} fontSize={10} fill="#94A3B8">{`-${formatVND(maxNeg)}`}</text>
      )}
      {chartData.map((d, idx) => {
        const [curV, prevV] = metricValues(d);
        const cx = svgX(idx);
        const curR = barRect(curV, cx - barGap / 2 - barW);
        const prevR = barRect(prevV, cx + barGap / 2);
        const isSel = idx === selectedIdx;
        return (
          <g key={d.key}>
            {curV !== 0 && <rect x={curR.x} y={curR.y} width={barW} height={Math.max(curR.height, 1)} fill={metricMeta.curColor} rx={1} stroke={isSel ? '#0F172A' : undefined} strokeWidth={isSel ? 1.5 : undefined} />}
            {prevV !== 0 && <rect x={prevR.x} y={prevR.y} width={barW} height={Math.max(prevR.height, 1)} fill={metricMeta.prevColor} rx={1} />}
          </g>
        );
      })}
      {chartData.map((d, idx) => (
        <rect key={`h${d.key}`} x={svgPadX + svgSlot * idx} y={svgPadT} width={svgSlot} height={svgPlotH} fill="transparent" pointerEvents="all" style={{ cursor: 'pointer' }} onClick={() => setSelectedIdx(idx)} />
      ))}
      {sel && selectedIdx !== null && (
        <line x1={svgX(selectedIdx)} y1={svgPadT} x2={svgX(selectedIdx)} y2={svgH - svgPadB} stroke="#64748B" strokeWidth={1} strokeDasharray="3 3" />
      )}
      {chartData.map((d, idx) => showXLabel(d, idx) && (
        <text key={`x${d.key}`} x={svgX(idx)} y={svgH - 6} fontSize={11} fill="#64748B" textAnchor="middle">{xLabelText(d)}</text>
      ))}
    </svg>
  );

  // Cơ cấu thanh toán kỳ đang xem (từ by_payment của báo cáo kỳ, không cần
  // truy vấn thêm): xếp theo doanh thu giảm dần, tỉ lệ trên tổng doanh thu
  // theo phương thức.
  const payData = useMemo(() => {
    const entries = Object.values(report?.by_payment ?? {}).sort((a, b) => b.revenue - a.revenue);
    const total = entries.reduce((s, e) => s + e.revenue, 0) || 1;
    return entries.map((e, i) => ({ ...e, pct: (e.revenue / total) * 100, color: PAY_COLORS[i % PAY_COLORS.length] }));
  }, [report]);

  // Món bán chạy top 5, sắp xếp theo lựa chọn (mặc định: số lượng, giảm dần).
  const top5 = useMemo(() => {
    const dir = topSortDir === 'desc' ? -1 : 1;
    return [...(report?.top_products ?? [])]
      .sort((a, b) => dir * (a[topSortKey] - b[topSortKey]))
      .slice(0, 5);
  }, [report, topSortKey, topSortDir]);

  const fundsTotal = funds.reduce((s, f) => s + f.balance, 0);
  const debtTop = debtors.slice(0, 4);
  const debtRest = debtors.slice(4);
  const debtRestSum = debtRest.reduce((s, c) => s + c.debt, 0);
  const showDebt = can('debt');

  if (!can('reports')) {
    return <div className="page"><div className="card">🔒 Chỉ Quản lý trở lên mới được xem báo cáo.</div></div>;
  }

  return (
    <div className="pc-ov">
      {/* Top bar PC */}
      <div className="pc-ov-topbar">
        <h1>Tổng quan</h1>
        <div className="pc-ov-topbar-right">
          <span className="pc-user">{user?.full_name || user?.email}</span>
        </div>
      </div>

      {/* Chip chọn kỳ (thay cho select cũ, theo bản demo đã duyệt) */}
      <div className="pc-chips">
        {PRESETS.map((p) => (
          <button key={p.key} className={`pc-chip${preset === p.key ? ' active' : ''}`} onClick={() => pickPreset(p.key)}>
            {p.label}
          </button>
        ))}
      </div>
      <p className="small muted" style={{ marginTop: 0, marginBottom: 14 }}>
        {formatDMY(rs)} – {formatDMY(re)} · Đang so sánh với {labels.prev}. Bấm vào thẻ Doanh thu / Tổng chi phí / Tổng công nợ để xem chi tiết.
      </p>

      {/* 6 thẻ KPI (1 hàng, icon lineal, hiện dần nối tiếp; đổi kỳ thì chạy lại) */}
      <div className="pc-kpis" key={preset} style={{ gridTemplateColumns: `repeat(${kpis.length || 6}, 1fr)` }}>
        {kpis.map((k) => (
          <div className="pc-kpi" key={k.label} onClick={k.to ? () => navigate(k.to as string) : undefined} style={k.to ? { cursor: 'pointer' } : undefined}>
            <div className="pc-kpi-icon" style={{ background: k.bg, color: k.iconColor }}><LineIcon name={k.icon} size={24} /></div>
            <div className="pc-kpi-info">
              <div className="pc-kpi-label">{k.label}</div>
              <div className="pc-kpi-value">{busy && !report ? '…' : k.value}</div>
              {k.hint && <div className="small muted">{k.hint}</div>}
              {k.change !== null && k.change !== undefined && (
                <div className={`pc-kpi-change ${k.change >= 0 ? 'up' : 'down'}`}>
                  {k.change >= 0 ? '↑' : '↓'} {Math.abs(Math.round(k.change))}% so với kỳ trước
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Hàng 1: biểu đồ (2 cột) + cơ cấu thanh toán */}
      <div className="pc-dash-main">
        <div className="pc-card">
          <div className="pc-card-head">
            <h3>{chartMeta.cur} so với {chartMeta.prev}</h3>
          </div>
          <div style={{ padding: '0 20px', display: 'flex', flexDirection: 'column', gap: 8 }}>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px 8px', alignItems: 'center' }}>
              {METRICS.map((m) => {
                const active = chartMetric === m.key;
                return (
                  <button key={m.key} onClick={() => setChartMetric(m.key)} style={{ background: active ? '#F8FAFC' : 'none', border: `1px solid ${active ? m.curColor : '#E2E8F0'}`, borderRadius: 999, padding: '4px 10px', fontSize: 12, fontWeight: active ? 700 : 400, cursor: 'pointer' }}>{m.label}</button>
                );
              })}
              <span style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 12, color: '#475569' }}>
                <span style={{ width: 12, height: 12, background: metricMeta.curColor, borderRadius: 2 }} /> {chartMeta.cur}
                <span style={{ width: 12, height: 12, background: metricMeta.prevColor, borderRadius: 2, marginLeft: 8 }} /> {cap(chartMeta.prev)}
              </span>
            </div>
            {includeGoods && report && (
              <p className="small muted" style={{ margin: 0 }}>
                Chi phí tổng kỳ này: Vận hành {formatVND(report.expenses)} + Nhập hàng {formatVND(report.purchase_costs ?? 0)} + Nguyên liệu {formatVND(report.cost)} = {formatVND(applyGoodsCosts(report, true).expense)} (Bật/tắt trong Cài đặt → Thông tin quán → Báo cáo)
              </p>
            )}
          </div>
          <div style={{ padding: '0 12px 4px' }}>
            <div key={`${preset}-${chartMetric}`} className="pc-chart-fade">
              {chartBars}
            </div>
            {sel ? (
              <div key={selectedIdx} className="pc-detail-slide" style={{ fontSize: 13, display: 'flex', flexDirection: 'column', gap: 2, padding: '6px 8px', background: '#F8FAFC', borderRadius: 8 }}>
                <div><b>{sel.detail}</b></div>
                <div>{metricMeta.label}: {chartMeta.cur} {formatVND(selMetricCur)} · {cap(chartMeta.prev)} {formatVND(selMetricPrev)}</div>
                <div>Chênh lệch: {selMetricDiff >= 0 ? '↑' : '↓'} {formatVND(Math.abs(selMetricDiff))}{selMetricPct === null ? '' : ` (${selMetricPct >= 0 ? '+' : ''}${Math.round(selMetricPct)}%)`}</div>
              </div>
            ) : (
              <div style={{ fontSize: 12, color: '#64748B', padding: '6px 8px' }}>Chạm vào 1 nhóm cột để xem {metricMeta.label} tại mốc đó.</div>
            )}
          </div>
        </div>
        <div className="pc-card">
          <div className="pc-card-head">
            <h3>Cơ cấu thanh toán</h3>
            <span className="pc-muted">{PRESETS.find((p) => p.key === preset)?.label}</span>
          </div>
          {payData.length === 0 ? (
            <p className="muted small">Chưa có doanh thu trong kỳ.</p>
          ) : (
            <>
              <div style={{ display: 'flex', height: 12, borderRadius: 6, overflow: 'hidden', marginBottom: 12 }}>
                {payData.map((e) => (
                  <div key={e.name} style={{ width: `${e.pct}%`, background: e.color }} />
                ))}
              </div>
              {payData.map((e) => (
                <div className="pc-rowline" key={e.name}>
                  <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span style={{ width: 10, height: 10, borderRadius: 2, background: e.color, flexShrink: 0 }} />
                    <span>{e.name}{e.count > 0 && <span className="muted small"> · {e.count} đơn</span>}</span>
                  </span>
                  <span style={{ textAlign: 'right' }}>
                    <b>{formatVND(e.revenue)}</b>
                    <span className="muted small"> · {e.pct.toFixed(1)}%</span>
                  </span>
                </div>
              ))}
            </>
          )}
        </div>
      </div>

      {/* Hàng 2: món bán chạy + số dư quỹ + công nợ */}
      <div className="pc-dash-row3" style={{ gridTemplateColumns: showDebt ? '1fr 1fr 1fr' : '1.5fr 1fr' }}>
        <div className="pc-card">
          <div className="pc-card-head">
            <h3>Món bán chạy — Top 5</h3>
            <span className="pc-muted">{PRESETS.find((p) => p.key === preset)?.label}</span>
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 8 }}>
            {([
              { key: 'qty', label: 'Số lượng' },
              { key: 'revenue', label: 'Doanh thu' },
              { key: 'profit', label: 'Lợi nhuận' },
            ] as const).map((o) => (
              <button key={o.key} className={`pc-pill${topSortKey === o.key ? ' active' : ''}`} onClick={() => setTopSortKey(o.key)}>
                {o.label}
              </button>
            ))}
            <button className="pc-pill active" onClick={() => setTopSortDir((d) => (d === 'desc' ? 'asc' : 'desc'))}>
              {topSortDir === 'desc' ? '↓ Giảm dần' : '↑ Tăng dần'}
            </button>
          </div>
          {top5.length === 0 ? (
            <p className="muted small">Chưa có dữ liệu</p>
          ) : (
            top5.map((p, i) => (
              <div className="pc-rowline" key={p.product_id}>
                <span style={{ display: 'flex', alignItems: 'center', gap: 10, minWidth: 0 }}>
                  <span style={{ width: 22, height: 22, borderRadius: '50%', background: '#F1F5F9', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700, flexShrink: 0 }}>{i + 1}</span>
                  <span style={{ minWidth: 0 }}>
                    <b style={{ display: 'block', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{p.name}</b>
                    <span className="muted small">{p.qty} ly</span>
                  </span>
                </span>
                <span style={{ textAlign: 'right', flexShrink: 0 }}>
                  <b style={{ display: 'block' }}>{formatVND(p.revenue)}</b>
                  <span className="small" style={{ color: '#16A34A', fontWeight: 600 }}>LN {formatVND(p.profit)}</span>
                </span>
              </div>
            ))
          )}
        </div>
        <div className="pc-card">
          <div className="pc-card-head">
            <h3>Số dư các quỹ</h3>
          </div>
          {funds.length === 0 ? (
            <p className="muted small">Không tải được số dư quỹ.</p>
          ) : (
            <>
              {funds.map((f) => (
                <div className="pc-rowline" key={f.fund.id}>
                  <span>{f.fund.name}</span>
                  <b>{formatVND(f.balance)}</b>
                </div>
              ))}
              <div className="pc-rowline">
                <b>Tổng số dư</b>
                <b>{formatVND(fundsTotal)}</b>
              </div>
            </>
          )}
          <button className="btn btn-outline btn-block" style={{ marginTop: 12 }} onClick={() => navigate('/so-quy')}>
            Mở Sổ quỹ
          </button>
        </div>
        {showDebt && (
          <div className="pc-card">
            <div className="pc-card-head">
              <h3>Công nợ khách hàng</h3>
              <span className="pc-muted">{debtors.length} khách đang nợ</span>
            </div>
            {debtors.length === 0 ? (
              <p className="muted small">Không có khách nợ.</p>
            ) : (
              <>
                {debtTop.map((c) => (
                  <div className="pc-rowline" key={c.id}>
                    <span>{c.name}</span>
                    <b>{formatVND(c.debt)}</b>
                  </div>
                ))}
                {debtRest.length > 0 && (
                  <div className="pc-rowline">
                    <span>Khách khác ({debtRest.length} khách)</span>
                    <b>{formatVND(debtRestSum)}</b>
                  </div>
                )}
                <div className="pc-rowline">
                  <b>Tổng công nợ</b>
                  <b>{formatVND(debtTotal ?? 0)}</b>
                </div>
              </>
            )}
            <button className="btn btn-outline btn-block" style={{ marginTop: 12 }} onClick={() => navigate('/debt')}>
              Xem Sổ nợ
            </button>
          </div>
        )}
      </div>

      {/* Hàng 3: nguyên liệu sắp hết (2 cột) + đơn gần đây */}
      <div className="pc-dash-row4">
        <div style={{ gridColumn: 'span 2', minWidth: 0 }}>
          <LowStockPanel low={low} multiWarehouse={warehouses.length > 1} variant="pc" />
        </div>
        <div className="pc-card">
          <div className="pc-card-head">
            <h3>Đơn gần đây</h3>
            <span className="pc-muted">Mới nhất</span>
          </div>
          {recentOrders.length === 0 ? (
            <p className="muted small">Chưa có đơn nào.</p>
          ) : (
            recentOrders.map((o) => {
              const itemsText = o.items.slice(0, 2).map((it) => `${it.qty} ${it.product_name}`).join(', ');
              return (
                <div className="pc-rowline" key={o.id}>
                  <span style={{ minWidth: 0 }}>
                    <b style={{ display: 'block' }}>{o.code} · {timeOf(o.created_at)}</b>
                    <span className="muted small" style={{ display: 'block', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                      {itemsText}{o.items.length > 2 ? ` +${o.items.length - 2} món` : ''}
                    </span>
                  </span>
                  <span style={{ textAlign: 'right', flexShrink: 0 }}>
                    <b style={{ display: 'block' }}>{formatVND(o.total)}</b>
                    <span className="muted small">{o.payment_method_name ?? ''}</span>
                  </span>
                </div>
              );
            })
          )}
          <button className="btn btn-outline btn-block" style={{ marginTop: 12 }} onClick={() => navigate('/orders')}>
            Xem tất cả đơn hàng
          </button>
        </div>
      </div>
    </div>
  );
}
