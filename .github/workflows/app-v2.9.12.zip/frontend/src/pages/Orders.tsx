// Đơn hàng — xem / sửa / xóa các đơn đã bán.
// Sửa nhanh: ghi chú + khách hàng (quản lý trở lên).
// Sửa toàn bộ: món, số lượng, giảm giá, voucher, phương thức thanh toán (chỉ chủ quán;
//   tồn kho, sổ quỹ, công nợ, tem/điểm được tính lại theo).
// Xóa: chỉ chủ quán; đơn ghi nợ được hoàn công nợ, khoản quỹ tự động của đơn bị xóa theo.
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  DbError,
  deleteOrder,
  getAllowedWarehouses,
  getOrder,
  listOrders,
  listPaymentMethods,
  searchCustomers,
  updateOrderMeta,
} from '../lib/db';
import {
  addDaysVN,
  formatDMY,
  formatTime,
  formatVND,
  startOfMonthVN,
  startOfWeekVN,
  todayVN,
  unsignVietnamese,
} from '../lib/format';
import { Sheet } from '../components/Sheet';
import { BluetoothPrintButton } from '../components/BluetoothPrintButton';
import { PageHead } from '../components/PageHead';
import { CustomerPickSheet } from '../components/CustomerPickSheet';
import { OrderEditForm } from './OrderEditForm';
import { useToast } from '../components/Toast';
import { useAuth } from '../lib/auth';
import type { Customer, Order, Warehouse } from '../lib/types';
import { isSplitPayment, orderPaymentSplits } from '../lib/types';

type FilterKey = 'today' | 'yesterday' | 'week' | 'lastweek' | 'month' | 'lastmonth' | 'custom';
const FILTERS: { key: FilterKey; label: string }[] = [
  { key: 'today', label: 'Hôm nay' },
  { key: 'yesterday', label: 'Hôm qua' },
  { key: 'week', label: 'Tuần này' },
  { key: 'lastweek', label: 'Tuần trước' },
  { key: 'month', label: 'Tháng này' },
  { key: 'lastmonth', label: 'Tháng trước' },
  { key: 'custom', label: 'Tùy chọn' },
];

const STATUS_LABEL: Record<string, string> = {
  new: 'Mới',
  preparing: 'Đang pha',
  ready: 'Sẵn sàng',
  done: 'Hoàn tất',
  cancelled: 'Đã hủy',
};

function rangeOf(key: FilterKey, customFrom?: string, customTo?: string): [string, string] {
  const t = todayVN();
  switch (key) {
    case 'today':
      return [t, t];
    case 'yesterday': {
      const y = addDaysVN(t, -1);
      return [y, y];
    }
    case 'week':
      return [startOfWeekVN(t), t];
    case 'lastweek': {
      const ws = startOfWeekVN(t);
      const we = addDaysVN(ws, -1);
      return [addDaysVN(ws, -7), we];
    }
    case 'month':
      return [startOfMonthVN(t), t];
    case 'lastmonth': {
      const ms = startOfMonthVN(t);
      const me = addDaysVN(ms, -1);
      return [startOfMonthVN(me), me];
    }
    case 'custom':
      return [customFrom || t, customTo || t];
  }
}

export function Orders() {
  const toast = useToast();
  const { can } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [custMap, setCustMap] = useState<Map<string, Customer>>(new Map());
  const [kindMap, setKindMap] = useState<Map<string, string>>(new Map());
  const [q, setQ] = useState('');
  const [filter, setFilter] = useState<FilterKey>('today');
  const [customFrom, setCustomFrom] = useState(todayVN());
  const [customTo, setCustomTo] = useState(todayVN());
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [whFilter, setWhFilter] = useState('all');
  const [busy, setBusy] = useState(true);
  const [detailId, setDetailId] = useState<string | null>(null);
  // Đơn được mở qua deep-link (?open=orderId) từ Sổ quỹ — có thể nằm ngoài khoảng lọc hiện tại
  const [deepOrder, setDeepOrder] = useState<Order | null>(null);
  const [searchParams, setSearchParams] = useSearchParams();

  const load = useCallback(
    async (fk: FilterKey, whId: string = 'all', cFrom?: string, cTo?: string) => {
      setBusy(true);
      try {
        const [from, to] = rangeOf(fk, cFrom ?? customFrom, cTo ?? customTo);
        const allowed = await getAllowedWarehouses();
        setWarehouses(allowed.warehouses);
        const ids =
          whId === 'all'
            ? allowed.isOwner
              ? undefined
              : allowed.warehouses.map((w) => w.id)
            : [whId];
        const [list, customers, methods] = await Promise.all([
          listOrders({ from, to, warehouseIds: ids }),
          searchCustomers(''),
          listPaymentMethods(false),
        ]);
        setOrders(list);
        setCustMap(new Map(customers.map((c) => [c.id, c])));
        setKindMap(new Map(methods.map((m) => [m.id, m.kind])));
      } catch (e) {
        toast.show(e instanceof DbError ? e.message : 'Không tải được đơn hàng');
      } finally {
        setBusy(false);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [],
  );

  useEffect(() => {
    void load(filter, whFilter);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filter, whFilter]);

  const changeWh = (id: string) => setWhFilter(id);

  // Deep-link từ Sổ quỹ: /orders?open=<orderId> → mở ngay chi tiết đơn
  useEffect(() => {
    const openId = searchParams.get('open');
    if (!openId) return;
    setSearchParams({}, { replace: true });
    getOrder(openId)
      .then((o) => {
        if (!o) {
          toast.show('Không tìm thấy đơn hàng');
          return;
        }
        setDeepOrder(o);
        setDetailId(o.id);
      })
      .catch(() => toast.show('Không mở được đơn hàng'));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const needle = unsignVietnamese(q.trim()).toLowerCase();
  const canDeleteRow = can('orders.delete');
  const quickDelete = async (o: { id: string; code: string; total: number }) => {
    if (!window.confirm(`Xóa đơn ${o.code} (${formatVND(o.total)})? Khoản quỹ và công nợ liên quan sẽ được hoàn/xóa theo.`))
      return;
    try {
      await deleteOrder(o.id);
      toast.show(`Đã xóa đơn ${o.code}`);
      void load(filter, whFilter);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Xóa thất bại');
    }
  };
  const filtered = useMemo(
    () =>
      orders.filter((o) => {
        if (!needle) return true;
        const c = o.customer_id ? custMap.get(o.customer_id) : undefined;
        const hay = unsignVietnamese(
          `${o.code} ${o.note ?? ''} ${c ? `${c.name} ${c.phone}` : 'khách lẻ'}`,
        ).toLowerCase();
        return hay.includes(needle);
      }),
    [orders, custMap, needle],
  );

  const detail =
    detailId
      ? deepOrder && deepOrder.id === detailId
        ? deepOrder
        : (orders.find((o) => o.id === detailId) ?? null)
      : null;
  const closeDetail = () => {
    setDetailId(null);
    setDeepOrder(null);
  };

  const payPill = (o: Order) => {
    if (isSplitPayment(o)) {
      return <span className="sb-status-pill info">💳 Hỗn hợp</span>;
    }
    const kind = kindMap.get(o.payment_method) ?? '';
    const label = o.payment_method_name ?? (kind === 'cash' ? 'Tiền mặt' : kind === 'transfer' ? 'Chuyển khoản' : kind === 'debt' ? 'Ghi nợ' : o.payment_method);
    const cls = kind === 'debt' ? 'sb-status-pill warn' : kind === 'transfer' ? 'sb-status-pill info' : 'sb-status-pill';
    return <span className={cls}>{label}</span>;
  };

  const orderGroups = useMemo(() => {
    const groups = new Map<string, typeof filtered>();
    for (const o of filtered) {
      const k = o.business_date;
      const arr = groups.get(k);
      if (arr) arr.push(o);
      else groups.set(k, [o]);
    }
    return [...groups.entries()]
      .sort((a, b) => b[0].localeCompare(a[0]))
      .map(([date, list]) => ({ date, list, revenue: list.reduce((s, o) => s + o.total, 0) }));
  }, [filtered]);

  return (
    <div className="page">
      <PageHead title="Đơn hàng" back />

      <div className="sb-search" style={{ marginBottom: 12 }}>
        <span className="sico">🔍</span>
        <input
          placeholder="Tìm mã đơn, tên, SĐT khách…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          aria-label="Tìm đơn hàng"
        />
      </div>

      {warehouses.length > 1 && (
        <div className="row" style={{ gap: 8, marginBottom: 12, flexWrap: 'wrap' }}>
          <button className={`sb-chip${whFilter === 'all' ? ' selected' : ''}`} onClick={() => changeWh('all')}>
            Mọi kho
          </button>
          {warehouses.map((w) => (
            <button key={w.id} className={`sb-chip${whFilter === w.id ? ' selected' : ''}`} onClick={() => changeWh(w.id)}>
              {w.name}
            </button>
          ))}
        </div>
      )}

      <div className="row" style={{ gap: 8, marginBottom: 12, flexWrap: 'wrap' }}>
        <select
          className="input"
          style={{ flex: '1 1 130px', minWidth: 0 }}
          value={filter}
          onChange={(e) => {
            const fk = e.target.value as FilterKey;
            setFilter(fk);
            void load(fk, whFilter);
          }}
          aria-label="Lọc theo thời gian"
        >
          {FILTERS.map((f) => (
            <option key={f.key} value={f.key}>
              {f.label}
            </option>
          ))}
        </select>
      </div>
      {filter === 'custom' && (
        <div className="row" style={{ gap: 8, marginBottom: 12 }}>
          <input
            className="input"
            type="date"
            value={customFrom}
            max={todayVN()}
            onChange={(e) => {
              const v = e.target.value;
              if (v) {
                setCustomFrom(v);
                if (v > customTo) setCustomTo(v);
              }
            }}
            aria-label="Từ ngày"
            style={{ flex: 1 }}
          />
          <input
            className="input"
            type="date"
            value={customTo}
            max={todayVN()}
            min={customFrom}
            onChange={(e) => {
              const v = e.target.value;
              if (v) setCustomTo(v);
            }}
            aria-label="Đến ngày"
            style={{ flex: 1 }}
          />
          <button
            className="btn btn-outline"
            style={{ minHeight: 44 }}
            onClick={() => void load('custom', whFilter, customFrom, customTo)}
          >
            Lọc
          </button>
        </div>
      )}

      <div className="sb-section" style={{ padding: '4px 16px' }}>
        {busy ? (
          <p className="muted" style={{ textAlign: 'center' }}>
            Đang tải…
          </p>
        ) : filtered.length === 0 ? (
          <div className="sb-empty">
            <div className="eico">🧾</div>
            <p>Chưa có đơn hàng nào trong khoảng này.</p>
          </div>
        ) : (
          orderGroups.map((g) => (
            <div key={g.date} style={{ marginBottom: 16 }}>
              <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center', marginBottom: 8, padding: '0 4px' }}>
                <b style={{ fontSize: 15 }}>📅 {formatDMY(g.date)}</b>
                <span className="money text-green" style={{ fontSize: 15 }}>
                  {formatVND(g.revenue)} <span className="small muted">({g.list.length} đơn)</span>
                </span>
              </div>
              {g.list.map((o) => {
                const c = o.customer_id ? custMap.get(o.customer_id) : undefined;
                return (
              <div key={o.id} style={{ position: 'relative' }}>
                <button
                  className="sb-row"
                  style={canDeleteRow ? { paddingRight: 42 } : undefined}
                  onClick={() => setDetailId(o.id)}
                >
                  <span className="rbody">
                    <span className="rtitle" style={{ fontSize: 16, fontWeight: 600 }}>
                      {o.code}
                      <span className="rsub" style={{ marginLeft: 8, fontWeight: 400 }}>
                        {formatTime(o.created_at)} · {formatDMY(o.business_date)}
                      </span>
                    </span>
                    <span className="rsub">
                      {c ? c.name : 'Khách lẻ'} · {STATUS_LABEL[o.status] ?? o.status}
                    </span>
                    {o.items.length > 0 && (
                      <span className="rsub" style={{ color: 'var(--ink)', fontSize: 12, marginTop: 1, lineHeight: 1.4 }}>
                        {o.items.map((it) => {
                          const mods = (it.modifiers ?? []).map((m) => m.option).filter(Boolean).join(', ');
                          return `${it.qty}× ${it.product_name}${mods ? ` (${mods})` : ''}`;
                        }).join(' · ')}
                      </span>
                    )}
                  </span>
                  <span className="rbody" style={{ alignItems: 'flex-end', flex: '0 0 auto' }}>
                    <span className="ramount text-green">{formatVND(o.total)}</span>
                    {payPill(o)}
                  </span>
                  <span className="chev muted" style={{ fontSize: 22 }}>
                    ›
                  </span>
                </button>
                {canDeleteRow && (
                  <button
                    type="button"
                    className="sb-row-del"
                    aria-label={`Xóa đơn ${o.code}`}
                    onClick={(ev) => {
                      ev.stopPropagation();
                      void quickDelete(o);
                    }}
                  >
                    ×
                  </button>
                )}
              </div>
            );
          })}
            </div>
          ))
        )}
      </div>

      {detail && (
        <OrderDetail
          order={detail}
          customer={detail.customer_id ? custMap.get(detail.customer_id) ?? null : null}
          canEdit={can('orders.edit')}
          canDelete={can('orders.delete')}
          onClose={closeDetail}
          onChanged={() => {
            closeDetail();
            void load(filter);
          }}
        />
      )}
    </div>
  );
}

function OrderDetail({
  order,
  customer,
  canEdit,
  canDelete,
  onClose,
  onChanged,
}: {
  order: Order;
  customer: Customer | null;
  canEdit: boolean;
  canDelete: boolean;
  onClose: () => void;
  onChanged: () => void;
}) {
  const toast = useToast();
  const [mode, setMode] = useState<'view' | 'edit' | 'confirmDelete'>('view');
  const [editFull, setEditFull] = useState(false);
  const [note, setNote] = useState(order.note ?? '');
  const [cust, setCust] = useState<Customer | null>(customer);
  const [pickOpen, setPickOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const canFullEdit = canDelete && order.status !== 'cancelled';

  const doSave = async () => {
    setBusy(true);
    try {
      await updateOrderMeta(order.id, { note: note.trim() || null, customerId: cust ? cust.id : null });
      toast.show(`Đã lưu thay đổi đơn ${order.code}`);
      onChanged();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  const doDelete = async () => {
    setBusy(true);
    try {
      await deleteOrder(order.id);
      toast.show(`Đã xóa đơn ${order.code}`);
      onChanged();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Xóa thất bại');
    } finally {
      setBusy(false);
    }
  };

  if (editFull) {
    return (
      <OrderEditForm
        order={order}
        customer={cust ?? customer}
        onClose={() => setEditFull(false)}
        onSaved={onChanged}
      />
    );
  }

  return (
    <Sheet
      title={mode === 'confirmDelete' ? 'Xóa đơn hàng' : `Đơn ${order.code}`}
      onClose={onClose}
      footer={
        mode === 'view' ? (
          <div className="row" style={{ gap: 8 }}>
            <BluetoothPrintButton order={order} />
            {canFullEdit && (
              <button className="btn btn-outline btn-block btn-lg" onClick={() => setEditFull(true)}>
                ✏️ Sửa đơn
              </button>
            )}
            {canEdit && (
              <button className="btn btn-outline btn-block btn-lg" onClick={() => setMode('edit')}>
                Sửa ghi chú
              </button>
            )}
            {canDelete && (
              <button
                className="btn btn-block btn-lg"
                style={{}}
                onClick={() => setMode('confirmDelete')}
              >
                Xóa đơn
              </button>
            )}
          </div>
        ) : mode === 'edit' ? (
          <div className="row" style={{ gap: 8 }}>
            <button className="btn btn-outline btn-block btn-lg" disabled={busy} onClick={() => setMode('view')}>
              Hủy
            </button>
            <button className="btn btn-block btn-lg" disabled={busy} onClick={doSave}>
              {busy ? 'Đang lưu…' : 'Lưu'}
            </button>
          </div>
        ) : (
          <div className="row" style={{ gap: 8 }}>
            <button className="btn btn-outline btn-block btn-lg" disabled={busy} onClick={() => setMode('view')}>
              Giữ lại
            </button>
            <button
              className="btn btn-block btn-lg"
              style={{}}
              disabled={busy}
              onClick={doDelete}
            >
              {busy ? 'Đang xóa…' : 'Xóa đơn'}
            </button>
          </div>
        )
      }
    >
      {mode === 'confirmDelete' ? (
        <p style={{ margin: '4px 0 8px', lineHeight: 1.6 }}>
          Xóa đơn <b>{order.code}</b> ({formatVND(order.total)})? Doanh thu và công nợ liên quan sẽ
          được hoàn lại. Thao tác này không thể hoàn tác.
        </p>
      ) : mode === 'edit' ? (
        <>
          <div className="field">
            <label>Khách hàng</label>
            <button className="sb-row" type="button" onClick={() => setPickOpen(true)}>
              <span className="avatar">{cust ? cust.name.charAt(0).toUpperCase() : '👤'}</span>
              <span className="rbody">
                <span className="rtitle">{cust ? cust.name : 'Khách lẻ'}</span>
                <span className="rsub">{cust ? cust.phone : 'Bấm để chọn khách'}</span>
              </span>
              <span className="text-green" style={{ fontWeight: 600 }}>
                Đổi ›
              </span>
            </button>
            {cust && (
              <button
                type="button"
                className="btn btn-ghost btn-sm"
                style={{ marginTop: 6 }}
                onClick={() => setCust(null)}
              >
                Bỏ chọn (về khách lẻ)
              </button>
            )}
          </div>
          <div className="field">
            <label>Ghi chú đơn</label>
            <input
              className="input"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Ghi chú…"
              maxLength={1000}
            />
          </div>
          <p className="small muted">Sửa nhanh ghi chú và khách hàng. Muốn sửa món/giá/voucher/thanh toán thì dùng “✏️ Sửa đơn” (chỉ chủ quán).</p>
        </>
      ) : (
        <>
          <div className="sb-section" style={{ marginBottom: 12 }}>
            <div className="row" style={{ justifyContent: 'space-between', marginBottom: 6 }}>
              <span className="muted">Thời gian</span>
              <b>
                {formatTime(order.created_at)} · {formatDMY(order.business_date)}
              </b>
            </div>
            <div className="row" style={{ justifyContent: 'space-between', marginBottom: 6 }}>
              <span className="muted">Khách hàng</span>
              <b>{customer ? `${customer.name} · ${customer.phone}` : 'Khách lẻ'}</b>
            </div>
            <div className="row" style={{ justifyContent: 'space-between', marginBottom: 6 }}>
              <span className="muted">Thanh toán</span>
              <b>{isSplitPayment(order) ? '💳 Hỗn hợp' : (order.payment_method_name ?? order.payment_method)}</b>
            </div>
            {isSplitPayment(order) &&
              orderPaymentSplits(order).map((sp) => (
                <div className="row" key={sp.method_id} style={{ justifyContent: 'space-between', marginBottom: 4 }}>
                  <span className="muted small" style={{ paddingLeft: 12 }}>
                    {sp.kind === 'cash' ? '💵' : sp.kind === 'transfer' ? '📱' : '📒'} {sp.method_name}
                  </span>
                  <b className="money">{formatVND(sp.amount)}</b>
                </div>
              ))}
            {order.warehouse_name && (
              <div className="row" style={{ justifyContent: 'space-between', marginBottom: 6 }}>
                <span className="muted">Kho trừ tồn</span>
                <b>🗃️ {order.warehouse_name}</b>
              </div>
            )}
            {order.note && (
              <div className="row" style={{ justifyContent: 'space-between' }}>
                <span className="muted">Ghi chú</span>
                <b style={{ textAlign: 'right', maxWidth: '60%' }}>{order.note}</b>
              </div>
            )}
          </div>

          <div className="sb-section" style={{ marginBottom: 12, padding: '4px 16px' }}>
            <div className="small muted" style={{ fontWeight: 600, padding: '10px 0 2px' }}>
              Món đã bán ({order.items.length})
            </div>
            {order.items.map((it) => (
              <div key={it.id} className="sb-row" style={{ cursor: 'default' }}>
                <span className="rbody">
                  <span className="rtitle">
                    {it.product_name} <span className="muted">× {it.qty}</span>
                  </span>
                  {it.modifiers.length > 0 && (
                    <span className="rsub">
                      {it.modifiers.map((m) => `${m.group}: ${m.option}`).join(' · ')}
                    </span>
                  )}
                  {it.note && <span className="rsub">“{it.note}”</span>}
                </span>
                <span className="ramount">{formatVND(it.line_total)}</span>
              </div>
            ))}
          </div>

          <div className="sb-section">
            {order.discount > 0 && (
              <>
                <div className="row" style={{ justifyContent: 'space-between' }}>
                  <span className="muted">Tạm tính</span>
                  <span>{formatVND(order.subtotal)}</span>
                </div>
                <div className="row" style={{ justifyContent: 'space-between', color: 'var(--green)' }}>
                  <span>
                    Giảm giá{order.discount_label ? ` (${order.discount_label})` : ''}
                  </span>
                  <span>-{formatVND(order.discount)}</span>
                </div>
              </>
            )}
            <div className="row" style={{ justifyContent: 'space-between' }}>
              <b style={{ fontSize: 17 }}>Tổng cộng</b>
              <b className="money text-orange" style={{ fontSize: 24 }}>
                {formatVND(order.total)}
              </b>
            </div>
          </div>
        </>
      )}

      {pickOpen && (
        <CustomerPickSheet
          onClose={() => setPickOpen(false)}
          onPick={(c) => {
            setCust(c);
            setPickOpen(false);
          }}
        />
      )}
    </Sheet>
  );
}
