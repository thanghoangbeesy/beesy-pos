# TEST.md — Kiểm thử hạ tầng + lớp dữ liệu (team hạ tầng)

Ngày: 2026-10-09 (bổ sung vòng rà soát chất lượng cùng ngày).
Người thực hiện: team hạ tầng (Muse subagent).

> ⚠️ Builder **không deploy** vì cần đăng nhập tài khoản Google của chủ quán
> (Firebase console + `firebase login`). Mọi kiểm thử dưới đây đều làm **offline**,
> không chạm vào project Firebase thật.

## 0. ⚠️ GIỚI HẠN QUAN TRỌNG CỦA BẢN TEST (đọc trước khi dùng thật)

**Giá đơn, mã đơn, tích tem đều do CODE TRÊN TRÌNH DUYỆT tính** (file `lib/db.ts`),
không phải server. Điều này đúng với yêu cầu "chỉ dùng gói Spark miễn phí, không
Cloud Functions", nhưng có nghĩa:

- Người dùng am hiểu kỹ thuật **có thể** mở DevTools và tự sửa giá/tích tem
  trước khi đơn được ghi — `firestore.rules` chỉ chặn được những gì kiểm tra
  được bằng rule (mã đơn đúng dạng `A001`, `total > 0`, chỉ đổi field `status`...),
  **không chặn được** việc bịa giá (ví dụ total=1000đ cho đơn 100.000đ).
- Với quán của Hoàng (tự vận hành, không thuê nhân viên) rủi ro này **chấp nhận được
  ở giai đoạn test**.
- **Khi thương mại hoá / có nhân viên**: BẮT BUỘC nâng lên gói Blaze và viết lại
  `createOrder` bằng **Cloud Functions** (tính giá server-side như bản self-hosted
  cũ) — lúc đó chỉ cần sửa `lib/db.ts::createOrder` gọi function, UI không đổi.

## 1. Những gì builder ĐÃ tự kiểm

Mỗi dòng ghi rõ phương pháp: **[tool]** = chạy công cụ thật, **[review]** = đọc
code đối chiếu kỹ (không chạy được vì chưa có Firestore thật).

### 1.1. Đối chiếu contract `lib/db.ts` — từng hàm, từng signature [review + tool]

| Hàm (contract) | Trạng thái |
|---|---|
| `DbError` (class, field `code`) | ✅ đủ |
| `CreateOrderItemInput` / `CreateOrderInput` | ✅ đủ, khớp `buildInput` của UI [tool: grep] |
| `listCategories`, `createCategory(name)`, `updateCategory(id, patch)` | ✅ đủ, không placeholder |
| `listProducts`, `createProduct(d)`, `updateProduct(id, patch)` | ✅ đủ |
| `listModifierGroups` (join `options[]`, sort `sort_order`) | ✅ đủ |
| `createModifierOption(groupId, d)`, `updateModifierOption(id, patch)` | ✅ đủ |
| `createOrder(input)`, `getOrder(id)`, `listOrdersByDate(date, limit?)`, `updateOrderStatus(id, status)` | ✅ đủ |
| `searchCustomers(q)`, `getCustomer(id)`, `createCustomer(d)`, `updateCustomer(id, patch)`, `redeemReward(customerId)` | ✅ đủ |
| `getSettings()`, `setSetting(key, value)` | ✅ đủ |
| `getDailyReport(date)` | ✅ đủ, mirror `reports.js` |
| `exportAllJson()`, `exportTableCsv(table)`, `downloadFile(filename, content, mime)` | ✅ đủ |
| `orderFromDoc` (export phụ thêm, dùng cho `realtime.ts`) | ✅ không phá contract |

Đối chiếu với team UI [tool: grep toàn bộ `import ... from '../lib/db'` trong
`src/pages`]: UI dùng đúng 21 exports — **khớp 100% tên + signature**, không thiếu,
không thừa.

### 1.2. `createOrder` — tính giá client-side [review]

Đối chiếu **từng nhánh** với `~/workspace/beesy-pos/backend/src/lib/pricing.js`:

| Logic bản gốc | Bản Firebase |
|---|---|
| items rỗng / > 100 dòng | ✅ rỗng → lỗi; giới hạn **50** dòng để khớp `firestore.rules` (`items.size() <= 50`) |
| product không tồn tại / `active=false` | ✅ cùng message `'Món thứ N: ...'` (bản Firebase: `"..." hiện không bán` theo contract) |
| qty nguyên 1–99 | ✅ |
| option không tồn tại / `active=false` | ✅ |
| group không tồn tại / `active=false` | ✅ |
| group `single` chọn > 1 option | ✅ |
| group `required` (Size) chưa chọn | ✅ → `'Món thứ N: Vui lòng chọn Size.'` (Size required + single ⇒ đúng 1 option) |
| `unit_price = base_price + Σ price_delta`, `line_total = unit_price × qty` | ✅ |
| cash: `amount_received` nguyên > 0, `>= total`, `change = received - total` | ✅ |
| transfer: `null` / `null` | ✅ |
| idempotent theo `clientUuid` (đọc trước + `tx.get` trong transaction chống đua) | ✅ |
| mã đơn `A + padStart(3)` từ `counters/{YYYYMMDD}` trong **cùng transaction** | ✅ |
| tích tem: `stamps + 1`, đủ `stamps_target` → `stamps = 0, reward_available = true` | ✅ (đọc `settings/stamps_target` trong transaction, mặc định 9) |
| `customerId` không tồn tại → lỗi | ✅ (trong transaction) |

**Atomic 2 máy cùng tạo đơn** [review]: mọi `tx.get` đứng trước mọi `tx.set`/`tx.update`
(đúng thứ tự Firestore yêu cầu); 2 transaction cùng lúc → Firestore serialize, bên
thua retry và đọc lại counter → mã `A001`, `A002` không trùng. Rules `counters`
khóa thêm: create chỉ `last == 1`, update chỉ `last == resource.data.last + 1`.

### 1.3. `updateOrderStatus` [review]

`new → preparing → ready → done`; `* → cancelled` (trừ `done`/`cancelled`);
bấm lại trạng thái cũ = no-op (giống backend). Sai luồng → `DbError`
`'Không thể chuyển đơn từ trạng thái "X" sang "Y".'` Trạng thái lạ → lỗi
`'Trạng thái "Z" không hợp lệ.'`

### 1.4. Auth — lỗi tiếng Việt, không crash [review]

| Tình huống | Hành vi |
|---|---|
| Sai mật khẩu / email chưa đăng ký | `DbError('Email hoặc mật khẩu không đúng.')` — Login page hiển thị, không crash |
| Email sai định dạng | `'Email không hợp lệ.'` |
| Đăng nhập sai quá nhiều lần | `'Đăng nhập sai quá nhiều lần. Thử lại sau ít phút.'` |
| Mất mạng lúc đăng nhập | `'Mất kết nối mạng...'` (map từ `FirestoreError`) |
| Auth OK nhưng **chưa có** `users/{uid}` (chưa phân quyền) | `login()` kiểm tra ngay sau sign-in → sign-out + ném `'Tài khoản chưa được phân quyền. Liên hệ chủ quán để cấp quyền truy cập.'` — **không** sign-out im lặng |
| `users/{uid}.role` lạ | ép về `'staff'` (fail-safe, không crash) |

### 1.5. Timestamp → ISO string [review]

`tsToIso()` dùng ở mọi chỗ: `orderFromDoc().created_at`, `toCustomer().created_at`,
`exportAllJson` (đệ quy `plainValue`), `exportTableCsv` cột `created_at`.
Khi `serverTimestamp()` **chưa resolve** (đọc lại ngay sau ghi): fallback
`new Date().toISOString()` — không bao giờ trả `null`/crash. CSV: bảng không có
`created_at` (products/categories seed) → ô trống thay vì ngày hiện tại.

### 1.6. `searchCustomers` lọc không dấu [tool]

Chạy thật `unsignVietnamese` qua esbuild+node: `"Nguyễn Văn An" → "NGUYEN VAN AN"`,
`"Trà Ổi Hồng" → "TRA OI HONG"`, SĐT giữ nguyên; mô phỏng đúng logic filter trong
`searchCustomers`: gõ `"nguyen van"` tìm thấy `"Nguyễn Văn An"`, gõ `"0903123"`
tìm theo SĐT — **PASS**.

### 1.7. `firestore.rules` — đọc lại từng dòng [review]

- `rules_version = '2'` (bắt buộc cho `diff()`/`hasOnly()`). ✅
- Mọi read/write yêu cầu `request.auth != null`; không collection nào public. ✅
- `isOwner()` đọc role qua `get(users/{uid})` — doc không tồn tại → rule **deny**
  (fail closed). Không đệ quy vô hạn (nhánh `request.auth.uid == uid` short-circuit). ✅
- `users`: get = chính mình/owner; còn lại = owner. ✅
- catalog: read = signed-in, write = owner. ✅
- `customers`: read/create/update = signed-in, delete = owner. ✅
- `settings`: read = signed-in, write = owner. ✅
- `counters`: create ⇔ `request.resource.data.last == 1`; update ⇔
  `request.resource.data.last == resource.data.last + 1`; delete = false — khớp
  chính xác 2 nhánh `tx.set`/`tx.update` trong `createOrder`. ✅
- `orders` create: `status == 'new'`, `items is list` 1–50 phần tử, `total > 0`,
  `code.matches('^A[0-9]{3,}$')`, `payment_method in ['cash','transfer']`. ✅
- `orders` update: `request.resource.data.diff(resource.data).affectedKeys().hasOnly(['status'])`
  + status mới ∈ `[preparing, ready, done, cancelled]` — `updateOrderStatus` chỉ
  update đúng 1 field `status`. ✅
- `orders` delete = false. ✅

### 1.8. `firestore.indexes.json` ↔ truy vấn [review + tool]

JSON hợp lệ [tool]. 3 composite index trên collection `orders` phủ đúng 3 truy vấn:
KDS (`business_date` + `status in` + `orderBy created_at`), báo cáo/danh sách theo
ngày (`business_date` + `orderBy created_at`), đơn gần nhất của khách
(`customer_id` + `orderBy created_at`).

### 1.9. `scripts/seed.mjs` — idempotent [review + tool]

- `node --check` PASS; `node seed.mjs --serviceAccount=<sai>` → thoát 1 kèm hướng
  dẫn tiếng Việt lấy key [tool].
- Auth user: `createUser` → bắt `auth/email-already-exists` → `getUserByEmail` →
  **bỏ qua, giữ nguyên mật khẩu cũ** [review].
- Firestore: `batch.set(..., { merge: true })` với **UUID cố định** (copy từ
  `db/seed.sql` bản self-hosted) → chạy lần 2 không tạo doc trùng [review].
- `customers.created_at`: chỉ set khi doc **chưa tồn tại** → chạy lại không đổi
  ngày tạo [review].

### 1.10. Type-check [tool]

`npx tsc --noEmit` (isolated, đúng options `tsconfig.app.json` gồm
`noUnusedLocals`, `erasableSyntaxOnly`, `verbatimModuleSyntax`) cho 9 file hạ tầng
+ components: **0 errors**. (Config check tạm đã xóa sau khi chạy.)

### 1.11. Chính tả tiếng Việt [review]

Rà toàn bộ message lỗi user nhìn thấy trong `db.ts`/`auth.tsx`: dấu đúng
(`Vui lòng`, `không tồn tại`, `đã ngừng dùng`, `Tiền khách đưa...`, `liên hệ`...),
không còn message tiếng Anh nào lọt ra UI (trừ `code` kỹ thuật như
`'unavailable'`, `'permission-denied'` mà UI chỉ dùng để rẽ nhánh).

## 2. Những gì user BẮT BUỘC kiểm lại sau deploy

| # | Việc kiểm | Cách làm | Vì sao builder không làm được |
|---|---|---|---|
| 1 | **Tạo 2 đơn cùng lúc trên 2 máy** → mã `A001`, `A002` không trùng, không nhảy số | Mở POS trên điện thoại + tablet, bấm thanh toán cùng lúc | Cần Firestore thật |
| 2 | **Tạo đơn khi mất mạng** → đơn vào outbox, có mạng tự đẩy, mã đơn vẫn đúng thứ tự | Bật chế độ máy bay → bán 1 đơn → tắt máy bay | Cần Firestore thật |
| 3 | **KDS realtime**: máy bếp thấy đơn mới trong vài giây + nghe tiếng "ting" | Mở `/kds` trên tablet, tạo đơn ở quầy | Cần 2 thiết bị + Firestore thật |
| 4 | **Phân quyền**: tài khoản `staff` KHÔNG sửa được menu/settings (báo "không có quyền") | Đăng nhập `nv01@beesy.local`, thử sửa giá món | Cần Auth + rules đã deploy |
| 5 | **Báo cáo ngày**: tạo vài đơn (cash + transfer + 1 đơn hủy) → số liệu khớp | So với tính tay | Cần dữ liệu thật |
| 6 | **Tích tem**: tạo 9 đơn cho cùng 1 khách → đơn thứ 9 báo đủ thưởng, `stamps` reset 0 | Dùng khách mẫu, tạo đơn nhanh | Cần Firestore thật |
| 7 | **Đổi thưởng**: khách đủ tem → bấm đổi thưởng → cờ tắt, không đổi được lần 2 | Thao tác trên màn hình Khách hàng | Cần Firestore thật |
| 8 | **Sao lưu**: tải JSON + CSV từng bảng, mở bằng Excel kiểm tra tiếng Việt | Màn hình Cài đặt | Cần dữ liệu thật |
| 9 | **Đăng nhập sai mật khẩu / tài khoản chưa phân quyền** → báo lỗi tiếng Việt rõ ràng | Thử các trường hợp ở §1.4 | Cần Auth thật |
| 10 | **Build full + deploy**: `npm run build` (sau khi team UI xong) → `firebase deploy` → mở link test full luồng | Theo README bước 7–11 | Cần login Google của chủ quán |
| 11 | **Xóa `scripts/serviceAccountKey.json`** khỏi máy sau khi seed (đã có trong `.gitignore`) | Xóa file | Việc của user |

## 3. Điểm khác bản self-hosted (cố ý, đã chốt)

1. Giá/tích tem/mã đơn do **client tính** (xem §0) — chấp nhận ở bản test.
2. `updateOrderStatus` cho phép `* → cancelled` (trừ `done`/`cancelled`); bản cũ chỉ
   cho `new/preparing → cancelled`.
3. `createOrder` giới hạn **50 dòng món** (khớp rules) thay vì 100.
4. Snapshot modifier có thêm `option_id` (theo schema Firebase).
5. `redeemReward(customerId)` không cần `order_id` như API cũ.
6. Đăng nhập bằng **email** (Firebase Auth) thay vì username; phiên tự lưu,
   không còn JWT trong localStorage.
7. Mã đơn đếm bằng `counters/{YYYYMMDD}` + transaction (thay `daily_counters` + UPSERT).

## 4. Google Drive backup (mới 2026-10-09 — team tích hợp Drive)

File mới: `frontend/src/lib/drive.ts`. Sửa: `pages/Settings.tsx` (thêm card
"☁️ Sao lưu Google Drive"), `pages/Menu.tsx` (nút "📷 Tải ảnh lên" trong
ProductForm), `pages/POS.tsx` (hiện ảnh món nếu có `image_url`),
`lib/db.ts` (cho phép `updateProduct` nhận thêm field `image_url` — chỉ thêm
field, không đổi logic cũ), `index.css` (class `.pimg`), `.env.example`
(thêm `VITE_GOOGLE_CLIENT_ID`), `README.md` (hướng dẫn bật Drive backup).

### 4.1. Những gì builder ĐÃ tự kiểm

| Hạng mục | Phương pháp | Kết quả |
|---|---|---|
| Type-check + build full (`npm run build` = `tsc -b && vite build`) | [tool] | ✅ PASS — xem §4.3 |
| `ensureDriveToken`: đọc `VITE_GOOGLE_CLIENT_ID`, chưa cấu hình → ném lỗi tiếng Việt có hướng dẫn; token còn hạn → dùng lại, không mở popup | [review] | ✅ logic đúng |
| Token lưu memory + localStorage kèm expiry, trừ hao 60s; 401 → xóa token, lần gọi sau mở lại popup | [review] | ✅ |
| `ensureBackupFolder`: tìm folder trước (tránh tạo trùng), chưa có → tạo, cache folderId vào localStorage | [review] | ✅ |
| `backupToDrive`: gọi `exportAllJson()` từ `db.ts` (không sửa), tên file `beesy-backup-YYYYMMDD-HHmm.json` giờ VN (`Asia/Ho_Chi_Minh`), upload multipart lên đúng folder, trả `{fileName, size}` | [review] | ✅ |
| `listBackupFiles`: query `'folderId' in parents and trashed = false`, `orderBy=createdTime desc` | [review] | ✅ |
| `downloadBackupFile`: tải `alt=media`, `JSON.parse` trong try/catch, validate có ít nhất 1 bảng trong danh sách khôi phục | [review] | ✅ |
| `restoreFromData`: chia batch 500 ops (`writeBatch`), `setDoc(..., {merge: true})` (không xóa collection), giữ doc id trong data, orders ưu tiên `client_uuid`, đủ 8 collections theo yêu cầu | [review] | ✅ |
| Mọi lỗi ném `Error` message tiếng Việt ("Chưa đăng nhập Google", "Chưa bật Drive API", "Token hết hạn"...) | [review] | ✅ |
| `Settings.tsx`: chưa cấu hình Client ID → hiện gợi ý README, **không crash**; Sheet liệt kê file → dialog NGUY HIỂM bắt gõ đúng `KHOI PHUC` mới cho khôi phục; toast báo tên file + dung lượng / số collections-docs | [review] | ✅ |
| Ảnh món: upload vào folder "Beesy POS Images" (tự tạo), `permissions.create` (`type: anyone, role: reader`), lưu thumbnail `https://drive.google.com/thumbnail?id={fileId}&sz=w400` vào `product.image_url`; POS dùng `<img>` + `onError` fallback emoji | [review] | ✅ |
| Không sửa logic hiện có: `exportAllJson`, `createProduct`, flow POS/KDS/nguyên trạng; `updateProduct` chỉ mở rộng patch type | [review] | ✅ |

### 4.2. Checklist user BẮT BUỘC làm tay (cần Google + Firestore thật)

| # | Việc kiểm | Cách làm | Đạt khi |
|---|---|---|---|
| D1 | Bật Drive API + tạo OAuth Client ID | Theo README mục "Bật Google Drive backup" (bước A→D) | Có Client ID, đã điền `.env`, build + deploy lại |
| D2 | Sao lưu lên Drive | Cài đặt → ☁️ → "⬆️ Sao lưu lên Google Drive" → cho phép truy cập khi Google hỏi | Toast "Đã sao lưu beesy-backup-....json (X.X MB) lên Google Drive"; mở drive.google.com thấy folder "Beesy POS Backup" + file |
| D3 | Tên file đúng giờ VN | So tên file với giờ hiện tại | `beesy-backup-YYYYMMDD-HHmm.json` khớp giờ VN |
| D4 | Liệt kê file khôi phục | Bấm "⬇️ Khôi phục từ Drive" | Sheet hiện danh sách file, mới nhất trước, đúng ngày giờ + dung lượng |
| D5 | Khôi phục thử | Chọn 1 file → gõ sai chữ → nút xác nhận **không bấm được**; gõ đúng `KHOI PHUC` → xác nhận | Gõ sai bị chặn; gõ đúng → toast "Đã khôi phục N bản ghi (M bảng)"; dữ liệu Firestore khớp file backup |
| D6 | Token hết hạn | Đăng nhập Google → vào tài khoản Google thu hồi quyền app → bấm sao lưu lại | Báo "Token hết hạn..." rõ ràng, lần sau mở lại popup đăng nhập |
| D7 | Tải ảnh món | Menu → Sửa món → "📷 Tải ảnh lên Google Drive" → chọn ảnh | Toast thành công; mở POS thấy ảnh món thay emoji; mở ảnh lỗi (xóa file trên Drive) → hiện lại emoji |
| D8 | Ảnh hiển thị cho máy khác | Mở POS trên tablet/điện thoại khác | Thấy ảnh món (quyền anyone-with-link đã mở) |

### 4.3. Build [tool]

`cd frontend && npm run build` (`tsc -b && vite build`): **PASS, 0 error**.

## 5. Lưu ý về Drive backup & gói Google (ghi rõ theo yêu cầu)

- **(a) Backup TỰ ĐỘNG theo lịch chưa có.** Cần Cloud Scheduler + Cloud Functions
  → bắt buộc nâng Firebase lên gói **Blaze trả phí**. Để dành **giai đoạn thương
  mại hoá**; hiện tại sao lưu thủ công 1 nút bấm là đủ cho 1 quán tự vận hành.
- **(b) 5TB Drive là quá đủ.** File backup chỉ vài trăm KB–vài MB, ảnh món vài
  trăm KB/cái → backup hằng ngày trong nhiều năm + hàng trăm ảnh món vẫn thoải mái.
- **(c) Gói Google AI Pro KHÔNG tăng quota miễn phí Firestore/Auth/Hosting.**
  AI Pro chỉ cộng dung lượng Drive/Photos/Gmail và tính năng AI — giới hạn
  đọc/ghi gói Spark giữ nguyên. Backup Drive client-side không tốn thêm quota
  Firestore nào ngoài lần đọc lúc xuất dữ liệu.

## Bổ sung 2026-10-09 (theo yêu cầu chủ quán)
- Trang Báo cáo: thay bộ lọc ngày đơn lẻ bằng các mốc nhanh — Hôm nay, Hôm qua, 7 ngày qua, Tuần này, Tuần trước, Tháng này, Tháng trước, Tùy chọn (chọn khoảng ngày tay). Bỏ mốc "30 ngày".
- Thêm `getRangeReport(start, end)` trong `lib/db.ts` (truy vấn range trên `business_date`, không cần composite index mới); thêm helper ngày `addDaysVN`, `startOfWeekVN` (tuần bắt đầu Thứ Hai), `startOfMonthVN`, `endOfMonthVN`, `formatDMY` trong `lib/format.ts`.
- Kiểm thử: `npm run build` (tsc + vite) pass, không lỗi. Cần kiểm tay sau deploy: bấm từng mốc lọc và đối chiếu tổng doanh thu/số đơn với thực tế.
