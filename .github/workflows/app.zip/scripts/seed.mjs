// Seed dữ liệu mẫu cho Beesy POS (Firebase) bằng firebase-admin.
// Chạy lại an toàn: mọi ghi đều dùng set(..., { merge: true }) với id cố định,
// user Auth đã tồn tại (theo email) sẽ được bỏ qua.
//
// Cách lấy serviceAccountKey.json:
//   Firebase console → Project settings (⚙️) → Service accounts
//   → "Generate new private key" → lưu file thành scripts/serviceAccountKey.json
//   (file này đã có trong .gitignore — KHÔNG commit, KHÔNG gửi cho ai)
//
// Cài đặt:  cd scripts && npm install
// Chạy:      node seed.mjs --serviceAccount=./serviceAccountKey.json
//            [--admin-email=admin@beesy.local --admin-pass=admin123
//             --staff-email=nv01@beesy.local --staff-pass=123456]

import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import admin from 'firebase-admin';

function arg(name, fallback) {
  const hit = process.argv.find((a) => a.startsWith(`--${name}=`));
  return hit ? hit.slice(name.length + 3) : fallback;
}

const serviceAccountPath = resolve(arg('serviceAccount', './serviceAccountKey.json'));
const adminEmail = arg('admin-email', 'admin@beesy.local');
const adminPass = arg('admin-pass', 'admin123');
const staffEmail = arg('staff-email', 'nv01@beesy.local');
const staffPass = arg('staff-pass', '123456');

let serviceAccount;
try {
  serviceAccount = JSON.parse(readFileSync(serviceAccountPath, 'utf8'));
} catch {
  console.error(`Không đọc được service account key: ${serviceAccountPath}`);
  console.error('Lấy file ở: Firebase console → Project settings → Service accounts → Generate new private key');
  process.exit(1);
}

admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });
const db = admin.firestore();
const ts = () => admin.firestore.FieldValue.serverTimestamp();

// ---------------------------------------------------------------- dữ liệu ---
// UUID cố định (copy từ db/seed.sql của bản self-hosted) để idempotent giữa các lần chạy.
const SETTINGS = {
  shop_name: 'Beesy Coffee & Tea',
  bank_bin: '970422',
  bank_account: '0901234567',
  bank_account_name: 'BEESY COFFEE',
  stamps_target: '9',
};

const CATEGORIES = [
  { id: 'f19ec631-0a5b-59b9-ab4d-e137ee0dfedd', name: 'Cà phê', sort_order: 1 },
  { id: 'deb7193f-c2e5-5da0-a8b2-4472e22d915b', name: 'Trà', sort_order: 2 },
  { id: 'f825e293-9dc7-5970-ad43-5381612fe0fb', name: 'Trà sữa', sort_order: 3 },
  { id: 'ee9c3633-f3d3-5c8e-ab87-2fa00afd6c6d', name: 'Đá xay/Sữa chua', sort_order: 4 },
];

const G_SIZE = '51be2d1e-71d4-5211-94a9-c72f0d098199';
const G_SWEET = '8c190c16-4ad8-5238-a95f-08bda9d3a477';
const G_ICE = '6d73afba-f575-5edb-9dfa-f6d7542b26a6';
const G_TOPPING = '1c388c27-1448-592c-a8e1-54465516ca99';

const MODIFIER_GROUPS = [
  { id: G_SIZE, name: 'Size', selection_type: 'single', required: true, sort_order: 1 },
  { id: G_SWEET, name: 'Độ ngọt', selection_type: 'single', required: false, sort_order: 2 },
  { id: G_ICE, name: 'Đá', selection_type: 'single', required: false, sort_order: 3 },
  { id: G_TOPPING, name: 'Topping', selection_type: 'multi', required: false, sort_order: 4 },
];

const MODIFIER_OPTIONS = [
  // Size
  { id: 'f022532d-e0b7-5dd7-ae73-6d7777705d83', group_id: G_SIZE, name: 'S', price_delta: 0, sort_order: 1 },
  { id: '143aa50b-24dd-52f5-98fe-383879276f3a', group_id: G_SIZE, name: 'M', price_delta: 5000, sort_order: 2 },
  { id: 'eceac302-dcf5-5bd6-ae21-d82c7e31b6a2', group_id: G_SIZE, name: 'L', price_delta: 10000, sort_order: 3 },
  // Độ ngọt
  { id: 'fb590559-a1ad-5880-83e9-c64ad4ef378f', group_id: G_SWEET, name: '100%', price_delta: 0, sort_order: 1 },
  { id: 'a2d1fbf2-6209-5c99-b195-5d11434d5f6f', group_id: G_SWEET, name: '70%', price_delta: 0, sort_order: 2 },
  { id: '3d09bee1-6863-5c7b-95eb-0c92b713cd8b', group_id: G_SWEET, name: '50%', price_delta: 0, sort_order: 3 },
  { id: 'f093f99e-064d-5fd8-9b66-7f69fa8ccc32', group_id: G_SWEET, name: '30%', price_delta: 0, sort_order: 4 },
  { id: 'dde42d0f-0b1d-59aa-8fa0-f877a3820d2f', group_id: G_SWEET, name: '0%', price_delta: 0, sort_order: 5 },
  // Đá
  { id: 'ef2e2f25-68b1-51ba-9f42-837e522a14ba', group_id: G_ICE, name: '100%', price_delta: 0, sort_order: 1 },
  { id: '62ac9da1-dc9f-5c88-9996-d5df7b4e64b2', group_id: G_ICE, name: '70%', price_delta: 0, sort_order: 2 },
  { id: '43b0b264-d957-5348-9817-9424bbf525b8', group_id: G_ICE, name: '30%', price_delta: 0, sort_order: 3 },
  { id: '2959f202-80b2-5816-b7e4-28374fc8faea', group_id: G_ICE, name: '0%', price_delta: 0, sort_order: 4 },
  // Topping
  { id: 'c1609357-942c-5e38-9037-a3a24fdd52ae', group_id: G_TOPPING, name: 'Trân châu đen', price_delta: 8000, sort_order: 1 },
  { id: 'ee07e2ac-11c7-5872-9862-bcf58b540fef', group_id: G_TOPPING, name: 'Trân châu trắng', price_delta: 8000, sort_order: 2 },
  { id: '48e0f854-7a5f-5c23-a960-a6a3e9022c79', group_id: G_TOPPING, name: 'Thạch dừa', price_delta: 7000, sort_order: 3 },
  { id: '9a4fff40-042c-5f62-8804-0c2a916ee242', group_id: G_TOPPING, name: 'Pudding trứng', price_delta: 10000, sort_order: 4 },
  { id: '666f82c2-111c-5dfa-90a9-97a2d28be5da', group_id: G_TOPPING, name: 'Kem cheese', price_delta: 12000, sort_order: 5 },
  { id: '56f512c6-a669-52d9-adda-c4dd6d500c65', group_id: G_TOPPING, name: 'Hạt lựu', price_delta: 10000, sort_order: 6 },
];

const C_CAFE = 'f19ec631-0a5b-59b9-ab4d-e137ee0dfedd';
const C_TEA = 'deb7193f-c2e5-5da0-a8b2-4472e22d915b';
const C_MILKTEA = 'f825e293-9dc7-5970-ad43-5381612fe0fb';
const C_BLEND = 'ee9c3633-f3d3-5c8e-ab87-2fa00afd6c6d';

const PRODUCTS = [
  { id: '2537017c-ef8b-5e57-9041-7d968fd827db', name: 'Cà Phê Sữa Đá', category_id: C_CAFE, base_price: 25000, sort_order: 1 },
  { id: 'b2118c27-ca8f-5dc9-8131-68b8f72b846a', name: 'Bạc Xỉu', category_id: C_CAFE, base_price: 29000, sort_order: 2 },
  { id: '8095cc88-81a9-5c23-9ca3-57f8f2e804f9', name: 'Cà Phê Đen Đá', category_id: C_CAFE, base_price: 22000, sort_order: 3 },
  { id: '0270e90e-13f6-5293-a5e3-81d1c1f17143', name: 'Trà Đào Cam Sả', category_id: C_TEA, base_price: 32000, sort_order: 1 },
  { id: '6ce9e39a-04e7-5bf8-9eee-7fdff35c54b5', name: 'Trà Tắc', category_id: C_TEA, base_price: 25000, sort_order: 2 },
  { id: 'ba80f251-a38c-520e-8ba5-5727c68ebe9b', name: 'Trà Ổi Hồng', category_id: C_TEA, base_price: 30000, sort_order: 3 },
  { id: 'cc52f9e2-2775-58c8-8f12-2bb8658f7215', name: 'Trà Sữa Truyền Thống', category_id: C_MILKTEA, base_price: 32000, sort_order: 1 },
  { id: 'd3bdfd86-2130-58a4-9c19-156b941992c5', name: 'Trà Sữa Thái Xanh', category_id: C_MILKTEA, base_price: 35000, sort_order: 2 },
  { id: '0961cd03-8d7b-5012-a96b-d71adc4b1133', name: 'Sữa Tươi Trân Châu Đường Đen', category_id: C_MILKTEA, base_price: 38000, sort_order: 3 },
  { id: '10b14e60-37ee-54ca-8c2f-5fea207907dc', name: 'Nước Ép Lựu', category_id: C_BLEND, base_price: 35000, sort_order: 1 },
  { id: '58ba3bd6-19dc-57cd-8ba5-07908e63267a', name: 'Matcha Latte', category_id: C_BLEND, base_price: 38000, sort_order: 2 },
  { id: '4da0178d-7ab4-585e-831b-1c86bf507c9f', name: 'Sữa Chua Đá Xay', category_id: C_BLEND, base_price: 35000, sort_order: 3 },
];

const CUSTOMERS = [
  { id: 'dcb31a5e-67cb-57bf-8b0e-212d3ebf8f1a', name: 'Nguyễn Văn An', phone: '0903123456', stamps: 3, note: 'Khách mẫu demo' },
  { id: '1e02d0a5-aa2c-5bf7-acd7-26700b02bffe', name: 'Trần Thị Bình', phone: '0903654321', stamps: 3, note: 'Khách mẫu demo' },
];

// ------------------------------------------------------------------ chạy ---
async function ensureUser(email, password, fullName, role) {
  let user;
  try {
    user = await admin.auth().createUser({ email, password, displayName: fullName });
    console.log(`  + Auth user mới: ${email}`);
  } catch (e) {
    if (e.code === 'auth/email-already-exists') {
      user = await admin.auth().getUserByEmail(email);
      console.log(`  = Auth user đã tồn tại: ${email} (giữ nguyên mật khẩu cũ)`);
    } else throw e;
  }
  await db.doc(`users/${user.uid}`).set(
    { id: user.uid, email, full_name: fullName, role },
    { merge: true },
  );
  console.log(`  + users/${user.uid} → { email, full_name: "${fullName}", role: "${role}" }`);
}

async function main() {
  console.log('1) Tạo tài khoản đăng nhập...');
  await ensureUser(adminEmail, adminPass, 'Chủ quán', 'owner');
  await ensureUser(staffEmail, staffPass, 'Nhân viên', 'staff');

  console.log('2) Seed dữ liệu mẫu (idempotent)...');
  const batch = db.batch();
  const put = (col, id, data) => batch.set(db.doc(`${col}/${id}`), { id, ...data }, { merge: true });

  for (const [key, value] of Object.entries(SETTINGS)) put('settings', key, { key, value });
  for (const c of CATEGORIES) put('categories', c.id, { ...c, active: true });
  for (const g of MODIFIER_GROUPS) put('modifierGroups', g.id, { ...g, active: true });
  for (const o of MODIFIER_OPTIONS) put('modifierOptions', o.id, { ...o, active: true });
  for (const p of PRODUCTS) put('products', p.id, { ...p, image_url: null, active: true });
  for (const c of CUSTOMERS) {
    const ref = db.doc(`customers/${c.id}`);
    const snap = await ref.get(); // chỉ set created_at khi doc chưa có → chạy lại không đổi ngày tạo
    const data = { ...c, birthday: null, address: null, reward_available: false };
    if (!snap.exists) data.created_at = ts();
    put('customers', c.id, data);
  }
  await batch.commit();

  console.log(`  + settings: ${Object.keys(SETTINGS).length} key`);
  console.log(`  + categories: ${CATEGORIES.length}, modifierGroups: ${MODIFIER_GROUPS.length}, modifierOptions: ${MODIFIER_OPTIONS.length}`);
  console.log(`  + products: ${PRODUCTS.length}, customers: ${CUSTOMERS.length}`);
  console.log('\nXong! Đăng nhập bằng:');
  console.log(`  Chủ quán : ${adminEmail} / ${adminPass === 'admin123' ? 'admin123' : '(mật khẩu bạn đặt)'}`);
  console.log(`  Nhân viên: ${staffEmail} / ${staffPass === '123456' ? '123456' : '(mật khẩu bạn đặt)'}`);
  console.log('Nhớ đổi mật khẩu trong Firebase console → Authentication sau lần đăng nhập đầu.');
}

main().catch((e) => {
  console.error('Seed thất bại:', e.message || e);
  process.exit(1);
});
