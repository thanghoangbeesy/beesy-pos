# Beesy POS — bản Firebase (gói miễn phí Spark)

Phần mềm bán hàng cho **Beesy Coffee & Tea**: POS tại quầy, màn hình bếp (KDS),
quản lý menu, khách hàng tích tem, báo cáo doanh thu, sao lưu dữ liệu.

- **Hạ tầng:** Firebase gói **Spark miễn phí** — Firestore (database), Authentication
  (đăng nhập), Hosting (chạy web). **Không dùng Cloud Functions.**
- **Chạy được trên:** máy tính, tablet, điện thoại — chỉ cần mở đường link web,
  không cài đặt gì thêm.

> Tài liệu này viết cho người không rành kỹ thuật. Làm đúng từng bước theo thứ tự.
> Các bước có 🔑 cần **tài khoản Google của chủ quán**.

---

## 📱 Cách 1 — Triển khai 100% trên điện thoại (không cần máy tính) ✅ khuyên dùng

> Toàn bộ các bước dưới đây làm được trên trình duyệt điện thoại (Chrome/Safari).
> Không cần cài đặt gì lên máy tính.

### Giai đoạn 1 — Tạo project Firebase (trên điện thoại) 🔑

1. Mở **console.firebase.google.com** → đăng nhập tài khoản Google của quán → **Add project**
   (Thêm dự án) → đặt tên `beesy-pos` → tắt Google Analytics → **Create project**.
2. Vào **Build → Authentication → Sign-in method** → bật **Email/Password** → Save.
3. Vào **Build → Firestore Database → Create database** → chọn **asia-southeast1**
   (Singapore) → **Start in production mode**.
4. Vào **⚙️ Project settings → Your apps** → **Add app → Web** (biểu tượng `</>`) →
   đặt nickname `beesy-pos` → **Register app**. Copy giữ lại 6 giá trị trong mục
   **firebaseConfig**: `apiKey`, `authDomain`, `projectId`, `storageBucket`,
   `messagingSenderId`, `appId` (chụp màn hình hoặc ghi vào Ghi chú điện thoại).
5. Vẫn ở **Project settings → Service accounts** → bấm **Generate new private key** →
   **Generate key**. File JSON sẽ tải về điện thoại — **giữ cẩn thận, đừng gửi cho ai**.

### Giai đoạn 2 — Đưa code lên GitHub & tự động deploy (trên điện thoại) 🔑

6. Mở **github.com** → đăng nhập (chưa có thì đăng ký miễn phí) → **New repository** →
   đặt tên `beesy-pos` → chọn **Public** → **Create repository**.
7. Trong repo vừa tạo: **Add file → Create new file** → ô tên file gõ đúng:
   `.github/workflows/deploy.yml` → mở file `deploy.yml` đã tải về ở cuối tài liệu này
   bằng app đọc văn bản → **chọn tất cả → copy** → dán vào khung soạn thảo GitHub →
   **Commit changes**.
8. Trong repo: **Add file → Upload files** → chọn file **`app.zip`** (tải ở cuối tài liệu) →
   **Commit changes**. (Chỉ upload đúng 1 file zip này, giữ nguyên tên `app.zip`.)
9. Trong repo: **Settings → Secrets and variables → Actions → New repository secret**,
   thêm lần lượt các secret sau (tên viết HOA đúng từng chữ):
   - `FIREBASE_SERVICE_ACCOUNT` — dán **toàn bộ nội dung** file JSON ở bước 5
     (mở file JSON bằng app đọc văn bản → chọn tất cả → copy → dán)
   - `FIREBASE_PROJECT_ID` — ID project ở bước 4 (VD: `beesy-pos-a1b2c`)
   - `VITE_FIREBASE_API_KEY`, `VITE_FIREBASE_AUTH_DOMAIN`, `VITE_FIREBASE_PROJECT_ID`,
     `VITE_FIREBASE_STORAGE_BUCKET`, `VITE_FIREBASE_MESSAGING_SENDER_ID`, `VITE_FIREBASE_APP_ID`
     — 6 giá trị đã copy ở bước 4
   - `VITE_GOOGLE_CLIENT_ID` — (tùy chọn, để sau) Client ID cho sao lưu Google Drive
10. Trong repo: vào tab **Actions** → nếu GitHub hỏi thì bấm **"I understand my workflows,
    go ahead and enable them"** → chọn **Deploy to Firebase** → **Run workflow** →
    **Run workflow**. Chờ khoảng 3–5 phút cho đến khi vòng tròn chuyển xanh (✅).
    Nếu đỏ (❌): bấm vào xem dòng lỗi rồi làm lại bước 9 (thường do secret sai/thiếu).
11. Lấy đường link web: Firebase console → **Build → Hosting** → copy đường link
    (dạng `https://beesy-pos-a1b2c.web.app`). Mở link này trên điện thoại.

### Giai đoạn 3 — Thiết lập quán ngay trong app (trên điện thoại)

12. Mở đường link web → bấm **"Thiết lập lần đầu →"** (hoặc mở `đường-link/setup`):
    - **Bước 1:** nhập tên chủ quán + email + mật khẩu → **Tạo tài khoản chủ quán**
    - **Bước 2:** bấm **Nhận quyền chủ quán** (chỉ người đầu tiên mới nhận được)
    - **Bước 3:** bấm **Nạp menu mẫu** (12 món + size/topping mẫu, sửa lại sau trong mục Menu)
13. Xong! Bấm **Vào màn hình bán hàng** và dùng như bình thường. 🎉
14. Việc nên làm tiếp trong app (mục **Cài đặt**): điền số tài khoản ngân hàng để hiện
    mã VietQR khi thu tiền, và bật **Sao lưu Google Drive**.
15. Muốn thêm nhân viên: vào **Cài đặt → Thêm tài khoản nhân viên** (không cần máy tính).

> 📦 **File cần tải về điện thoại:**
> - `app.zip` — toàn bộ code (upload lên GitHub ở bước 8)
> - `deploy.yml` — nội dung để dán vào `.github/workflows/deploy.yml` (bước 7)
>
> Từ lần sau muốn cập nhật phần mềm: chỉ cần tải `app.zip` bản mới → upload đè lên
> repo → chạy lại workflow ở tab Actions.

---

## 💻 Cách 2 — Triển khai bằng máy tính (cho người rành kỹ thuật)

> Nếu anh/chị quen dùng máy tính, làm theo các bước dưới đây. Kết quả cuối cùng
> giống hệt Cách 1.

### Chuẩn bị (làm 1 lần duy nhất, trên máy tính)

### Bước 1 — Tạo project Firebase 🔑

1. Mở [console.firebase.google.com](https://console.firebase.google.com) → đăng nhập
   tài khoản Google của chủ quán.
2. Bấm **Add project** (Thêm dự án) → đặt tên `beesy-pos-test` → **Continue**.
3. Khi hỏi Google Analytics: **tắt** (gạt nút sang OFF) → **Create project**.
4. Đợi tạo xong → bấm **Continue**.

### Bước 2 — Bật đăng nhập bằng Email/Mật khẩu 🔑

1. Trong menu trái: **Build → Authentication** → bấm **Get started**.
2. Tab **Sign-in method** → bấm **Email/Password** → gạt **Enable** → **Save**.

### Bước 3 — Tạo database Firestore 🔑

1. Menu trái: **Build → Firestore Database** → bấm **Create database**.
2. Chọn **Start in production mode** → **Next**.
3. Chọn region **asia-southeast1 (Singapore)** (gần VN nhất, nhanh nhất) → **Enable**.
4. Đợi vài phút cho database sẵn sàng.

### Bước 4 — Cài công cụ trên máy tính

1. Cài **Node.js LTS**: mở [nodejs.org](https://nodejs.org) → tải bản **LTS**
   (số chẵn, ví dụ 22.x) → cài đặt bình thường → khởi động lại máy nếu được yêu cầu.
2. Mở **Terminal** (Mac) hoặc **PowerShell** (Windows), gõ lần lượt:
   ```
   node -v
   npm i -g firebase-tools
   firebase login
   ```
   Lệnh cuối mở trình duyệt → đăng nhập tài khoản Google của chủ quán → bấm **Allow**.

### Bước 5 — Điền project id vào `.firebaserc` 🔑

Mở file `.firebaserc` trong thư mục project, sửa `beesy-pos-test` thành **Project ID**
thật của bạn (xem ở Firebase console → Project settings ⚙️ → General → Project ID).

```json
{ "projects": { "default": "project-id-cua-ban" } }
```

### Bước 6 — Tạo Web app & file `.env` 🔑

1. Firebase console → **Project settings** (bánh răng ⚙️ góc trái) → mục **Your apps**
   → bấm biểu tượng **`</>`** (Web) → đặt nickname `beesy-pos` → **Register app**
   (KHÔNG tick Firebase Hosting ở bước này).
2. Copy khối **config** hiện ra, ví dụ:
   ```
   apiKey: "AIza...",
   authDomain: "xxx.firebaseapp.com",
   projectId: "xxx",
   storageBucket: "xxx.appspot.com",
   messagingSenderId: "123...",
   appId: "1:123...:web:abc..."
   ```
3. Trong thư mục `frontend/`: copy file **`.env.example`** thành **`.env`**,
   điền 6 giá trị vừa copy vào (giữ nguyên tên biến `VITE_...`).

> ⚠️ Các key trong `.env` là **public** (ai mở web cũng thấy) — điều này bình thường.
> Bảo mật thật nằm ở file `firestore.rules` (chỉ tài khoản đăng nhập mới đọc/ghi được).

### Bước 7 — Build web

Trong Terminal, đứng ở thư mục `frontend/`:

```
cd frontend
npm install
npm run build
```

Lần đầu `npm install` mất vài phút. Nếu báo lỗi, chụp màn hình gửi cho người hỗ trợ.

### Bước 8 — Deploy rules + indexes + hosting

Đứng ở **thư mục gốc** của project (nơi có file `firebase.json`):

```
firebase deploy --only firestore:rules,firestore:indexes,hosting
```

Xong sẽ hiện **Hosting URL** dạng `https://beesy-pos-test.web.app` — đây là link
dùng cho quán (lưu lại, gửi cho tablet/điện thoại).

> ⏳ Sau khi deploy indexes, Firestore cần **vài phút** để build xong 3 composite index.
> Nếu web báo lỗi thiếu index lúc đầu, đợi 5–10 phút rồi tải lại trang.

### Bước 9 — Tạo tài khoản & nạp dữ liệu mẫu 🔑

> 💡 Nếu đã làm theo **Cách 1 (điện thoại)**: bỏ qua bước này — tài khoản chủ quán và
> menu mẫu đã được tạo ngay trong app ở màn hình **/setup** (Giai đoạn 3).

1. Firebase console → **Project settings** → tab **Service accounts**
   → bấm **Generate new private key** → file JSON tải về.
2. Đổi tên file thành `serviceAccountKey.json`, đặt vào thư mục **`scripts/`**.
   (File này như chìa khóa két — **không gửi cho ai, không đưa lên mạng**.)
3. Trong Terminal:
   ```
   cd scripts
   npm install
   node seed.mjs --serviceAccount=./serviceAccountKey.json
   ```
   Đổi mật khẩu mặc định nếu muốn:
   ```
   node seed.mjs --serviceAccount=./serviceAccountKey.json --admin-pass=MatKhauMoi123
   ```
4. Xong sẽ có sẵn: 2 tài khoản, 4 danh mục, 18 tùy chọn (Size/Ngọt/Đá/Topping),
   12 món, 2 khách mẫu, cài đặt quán.

### Bước 10 — Đăng nhập & đổi mật khẩu 🔑

1. Mở Hosting URL → đăng nhập:
   - Chủ quán: `admin@beesy.local` / `admin123`
   - Nhân viên: `nv01@beesy.local` / `123456`
2. **Đổi mật khẩu ngay:** Firebase console → **Authentication** → bấm vào user
   → dấu `⋮` → **Reset password** (hoặc đổi trong code ở lần nâng cấp sau).

### Bước 11 — Dùng trên tablet / điện thoại

Mở **Hosting URL** trên trình duyệt của tablet/điện thoại → đăng nhập là dùng.
Mẹo: bấm "Thêm vào màn hình chính" để dùng như app (PWA đã bật sẵn).

---

## ☁️ Bật Google Drive backup (tùy chọn, nên làm) 🔑

Tính năng này cho phép bấm **1 nút trong Cài đặt** để sao lưu toàn bộ dữ liệu
lên Google Drive của quán, và khôi phục lại khi cần. Mọi thứ chạy **trên trình
duyệt** (không cần server, không tốn Cloud Functions) nên vẫn giữ được gói
Firebase **Spark miễn phí**.

### Bước A — Bật Google Drive API

1. Mở [console.cloud.google.com](https://console.cloud.google.com) → đăng nhập
   tài khoản Google của chủ quán → chọn đúng project (có thể **dùng chung
   project Firebase** đã tạo ở Bước 1).
2. Menu trái: **APIs & Services → Library**.
3. Gõ tìm **"Google Drive API"** → bấm vào → bấm **Enable** (Bật).

### Bước B — Cấu hình OAuth consent screen

1. Menu trái: **APIs & Services → OAuth consent screen**.
2. User type: chọn **External** → **Create**.
3. Điền tên app (VD: `Beesy POS`), email hỗ trợ = email chủ quán → **Save and Continue**.
4. Mục **Scopes**: bấm **Add or Remove Scopes** → tick scope
   `.../auth/drive.file` (ghi chú: chỉ cho app truy cập file do chính app tạo)
   → **Update** → **Save and Continue**.
5. Mục **Test users**: bấm **Add Users** → thêm **email của chủ quán**
   (tài khoản sẽ đăng nhập Google trong app) → **Save and Continue** → **Back to Dashboard**.

### Bước C — Tạo OAuth Client ID

1. Menu trái: **APIs & Services → Credentials** → bấm **+ Create Credentials
   → OAuth client ID**.
2. Application type: **Web application**, đặt tên `Beesy POS Web`.
3. Mục **Authorized JavaScript origins** → bấm **Add URI** và thêm từng dòng:
   - Hosting URL của quán, VD: `https://beesy-pos-test.web.app`
     (thêm cả `https://beesy-pos-test.firebaseapp.com` cho chắc)
   - `http://localhost:5173` (để chạy thử trên máy tính)
4. Bấm **Create** → copy chuỗi **Client ID** hiện ra (dạng
   `xxx.apps.googleusercontent.com`).

### Bước D — Điền Client ID vào app & deploy lại

1. Trong thư mục `frontend/`: mở file **`.env`**, thêm dòng:
   ```
   VITE_GOOGLE_CLIENT_ID=<Client ID vừa copy>
   ```
   (File `.env.example` đã có sẵn dòng này để tham khảo.)
2. Build + deploy lại:
   ```
   cd frontend
   npm run build
   cd ..
   firebase deploy --only hosting
   ```
3. Mở web → **Cài đặt → ☁️ Sao lưu Google Drive** → bấm
   **⬆️ Sao lưu lên Google Drive** → lần đầu Google sẽ hỏi cho phép truy cập
   Drive → nếu hiện cảnh báo "Google hasn't verified this app", bấm
   **Advanced → Go to Beesy POS (unsafe)** — bình thường với app nội bộ chưa
   qua kiểm duyệt của Google.

> Sau khi sao lưu xong, mở [drive.google.com](https://drive.google.com) sẽ thấy
> thư mục **"Beesy POS Backup"** chứa file `beesy-backup-YYYYMMDD-HHmm.json`.

---

## Vận hành hằng ngày

| Việc | Cách làm |
|---|---|
| Bán hàng | Mở link → POS → chọn món → thanh toán |
| Màn hình bếp | Mở link `/kds` trên tablet/máy bếp |
| Thêm/sửa món | Menu (chỉ chủ quán) |
| Xem doanh thu | Báo cáo → chọn ngày |
| Sao lưu dữ liệu | Cài đặt → Tải file JSON/CSV về máy |
| Mất mạng | Đơn tự lưu chờ, có mạng tự đẩy lên (góc màn hình hiện số đơn chờ) |

## Cấu trúc thư mục

```
beesy-pos-firebase/
├── firebase.json            # cấu hình deploy (firestore + hosting)
├── .firebaserc              # project id Firebase (điền ở bước 5)
├── firestore.rules          # luật bảo mật database (deploy ở bước 8)
├── firestore.indexes.json   # index cho truy vấn báo cáo/KDS
├── scripts/
│   ├── seed.mjs             # tạo tài khoản + nạp dữ liệu mẫu (bước 9)
│   └── serviceAccountKey.json  # ← bạn tự tạo, KHÔNG commit
└── frontend/
    ├── .env                 # ← bạn tự tạo từ .env.example (bước 6)
    └── src/
        ├── lib/
        │   ├── firebase.ts  # khởi tạo Firebase + cache offline
        │   ├── auth.tsx     # đăng nhập/đăng xuất, phân quyền chủ quán
        │   ├── db.ts        # LỚP DỮ LIỆU — mọi đọc/ghi Firestore qua đây
        │   ├── drive.ts     # backup/khôi phục + ảnh món qua Google Drive (client-side)
        │   ├── realtime.ts  # realtime KDS + âm báo đơn mới
        │   └── offline.ts   # cache menu + hàng chờ đơn khi mất mạng
        └── pages/           # các màn hình (team UI)
```

## Lưu ý quan trọng

- **Gói Spark miễn phí** có giới hạn đọc/ghi mỗi ngày — với 1 quán là đủ dùng.
  Nếu sau này vượt, Firebase sẽ báo nâng cấp (không tự trừ tiền).
- **Không xóa** tài khoản `admin@beesy.local` khi chưa tạo tài khoản chủ quán khác.
- Sao lưu: vào **Cài đặt → ☁️ Sao lưu Google Drive** bấm nút sao lưu **mỗi tuần
  1 lần** (hoặc sau ngày bán đông). Vẫn giữ được nút "Tải toàn bộ dữ liệu (JSON)"
  về máy như trước.

### Về backup & gói Google của quán

- **(a) Backup TỰ ĐỘNG theo lịch** (VD: 2h sáng mỗi ngày tự chạy) hiện **chưa
  có** — cần Cloud Scheduler + Cloud Functions, tức phải nâng Firebase lên gói
  **Blaze trả phí**. Để dành cho **giai đoạn thương mại hoá**; hiện tại sao lưu
  thủ công 1 nút bấm là đủ.
- **(b) 5TB Google Drive** của quán là quá đủ: mỗi file backup chỉ vài trăm KB
  đến vài MB, ảnh món mỗi cái vài trăm KB — lưu backup hằng ngày trong nhiều
  năm cũng không hết.
- **(c) Gói Google AI Pro KHÔNG tăng quota miễn phí** của Firestore/Auth/Hosting
  — AI Pro chỉ cộng dung lượng Drive/Photos/Gmail và tính năng AI. Giới hạn đọc
  ghi Firestore gói Spark vẫn giữ nguyên.
