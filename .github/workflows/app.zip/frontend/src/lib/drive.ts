// Google Drive backup — 100% client-side (giữ gói Firebase Spark miễn phí,
// KHÔNG dùng Cloud Functions).
// Dùng Google Identity Services (Token Client) + Drive API v3 với scope
// drive.file (app chỉ thấy/sửa file & folder do chính app tạo).
import { doc, writeBatch } from 'firebase/firestore';
import { db } from './firebase';
import { exportAllJson } from './db';

// ------------------------------------------------------------------ config ---
const GSI_SCRIPT_URL = 'https://accounts.google.com/gsi/client';
const DRIVE_SCOPE = 'https://www.googleapis.com/auth/drive.file';
const BACKUP_FOLDER_NAME = 'Beesy POS Backup';
const IMAGES_FOLDER_NAME = 'Beesy POS Images';
const FOLDER_MIME = 'application/vnd.google-apps.folder';

const TOKEN_STORE_KEY = 'beesy.drive.token'; // { token, expiresAt }
const BACKUP_FOLDER_KEY = 'beesy.drive.backupFolderId';
const IMAGES_FOLDER_KEY = 'beesy.drive.imagesFolderId';

// Các bảng được hỗ trợ khi khôi phục
const RESTORE_COLLECTIONS = [
  'settings',
  'categories',
  'products',
  'modifierGroups',
  'modifierOptions',
  'customers',
  'orders',
  'counters',
] as const;

// ------------------------------------------------------------------- types ---
export interface DriveFileInfo {
  id: string;
  name: string;
  size: string;
  createdTime: string;
}

interface GisTokenResponse {
  access_token?: string;
  expires_in?: number;
  error?: string;
}

interface GisTokenClient {
  requestAccessToken: (options?: { prompt?: string }) => void;
}

interface GoogleOauth2 {
  initTokenClient: (config: {
    client_id: string;
    scope: string;
    callback: (resp: GisTokenResponse) => void;
    error_callback?: () => void;
  }) => GisTokenClient;
}

function getOauth2(): GoogleOauth2 | null {
  const w = window as unknown as { google?: { accounts?: { oauth2?: GoogleOauth2 } } };
  return w.google?.accounts?.oauth2 ?? null;
}

export function isDriveConfigured(): boolean {
  return Boolean((import.meta.env.VITE_GOOGLE_CLIENT_ID as string | undefined)?.trim());
}

function requireClientId(): string {
  const id = (import.meta.env.VITE_GOOGLE_CLIENT_ID as string | undefined)?.trim();
  if (!id) {
    throw new Error(
      'Chưa cấu hình VITE_GOOGLE_CLIENT_ID. Xem README mục "Bật Google Drive backup" để lấy Client ID.',
    );
  }
  return id;
}

// ------------------------------------------------------------- token store ---
let memToken = '';
let memExpiresAt = 0;

function readStoredToken(): { token: string; expiresAt: number } | null {
  try {
    const raw = localStorage.getItem(TOKEN_STORE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as { token?: unknown; expiresAt?: unknown };
    if (typeof parsed.token === 'string' && typeof parsed.expiresAt === 'number') {
      return { token: parsed.token, expiresAt: parsed.expiresAt };
    }
    return null;
  } catch {
    return null;
  }
}

function saveToken(token: string, expiresInSec: number): void {
  memToken = token;
  // Trừ hao 60 giây để không dùng token sắp hết hạn
  memExpiresAt = Date.now() + Math.max(0, expiresInSec - 60) * 1000;
  try {
    localStorage.setItem(TOKEN_STORE_KEY, JSON.stringify({ token, expiresAt: memExpiresAt }));
  } catch {
    /* bộ nhớ trình duyệt đầy — bỏ qua, token vẫn dùng được trong phiên này */
  }
}

function clearToken(): void {
  memToken = '';
  memExpiresAt = 0;
  try {
    localStorage.removeItem(TOKEN_STORE_KEY);
  } catch {
    /* ignore */
  }
}

/** true nếu đang có token còn hạn (không mở popup đăng nhập). */
export function isDriveSignedIn(): boolean {
  if (memToken && Date.now() < memExpiresAt) return true;
  const saved = readStoredToken();
  return Boolean(saved && saved.token && Date.now() < saved.expiresAt);
}

// ------------------------------------------------------------ GIS loading ---
// Nạp Google Identity Services động — trang web vẫn chạy bình thường nếu
// chưa cấu hình Client ID hoặc không có mạng tới accounts.google.com.
let gisPromise: Promise<void> | null = null;

function loadGis(): Promise<void> {
  if (getOauth2()) return Promise.resolve();
  if (gisPromise) return gisPromise;
  gisPromise = new Promise<void>((resolve, reject) => {
    const script = document.createElement('script');
    script.src = GSI_SCRIPT_URL;
    script.async = true;
    script.defer = true;
    script.onload = () => {
      if (getOauth2()) resolve();
      else reject(new Error('Không khởi tạo được thư viện đăng nhập Google. Tải lại trang rồi thử lại.'));
    };
    script.onerror = () => {
      gisPromise = null;
      reject(new Error('Không tải được thư viện đăng nhập Google. Kiểm tra mạng rồi thử lại.'));
    };
    document.head.appendChild(script);
  });
  return gisPromise;
}

// -------------------------------------------------------------- auth token ---
/**
 * Trả về access token còn hạn. Hết hạn (hoặc chưa đăng nhập) → mở popup
 * đăng nhập Google của Google Identity Services.
 */
export async function ensureDriveToken(): Promise<string> {
  const clientId = requireClientId();
  if (memToken && Date.now() < memExpiresAt) return memToken;
  const saved = readStoredToken();
  if (saved && Date.now() < saved.expiresAt) {
    memToken = saved.token;
    memExpiresAt = saved.expiresAt;
    return memToken;
  }
  await loadGis();
  const oauth2 = getOauth2();
  if (!oauth2) throw new Error('Thư viện Google chưa sẵn sàng. Tải lại trang rồi thử lại.');

  const token = await new Promise<string>((resolve, reject) => {
    let settled = false;
    const client = oauth2.initTokenClient({
      client_id: clientId,
      scope: DRIVE_SCOPE,
      callback: (resp) => {
        if (settled) return;
        settled = true;
        if (resp.error || !resp.access_token) {
          reject(
            new Error(
              resp.error === 'popup_closed_by_user'
                ? 'Bạn đã đóng cửa sổ đăng nhập Google.'
                : 'Đăng nhập Google thất bại. Thử lại.',
            ),
          );
          return;
        }
        resolve(resp.access_token);
      },
      error_callback: () => {
        if (settled) return;
        settled = true;
        reject(new Error('Đăng nhập Google bị hủy hoặc thất bại. Thử lại.'));
      },
    });
    try {
      client.requestAccessToken();
    } catch {
      if (!settled) {
        settled = true;
        reject(new Error('Không mở được cửa sổ đăng nhập Google (trình duyệt chặn popup?).'));
      }
    }
  });

  saveToken(token, 3600);
  return token;
}

// ------------------------------------------------------------- Drive API ---
function driveErrorMessage(status: number, detail: string): string {
  if (status === 401) return 'Token hết hạn. Vui lòng đăng nhập Google lại.';
  if (status === 403) {
    if (/driveApiNotEnabled|has not been used|not enabled|disabled/i.test(detail)) {
      return 'Chưa bật Drive API. Mở Google Cloud Console → APIs & Services → Library → tìm "Google Drive API" → bấm Enable.';
    }
    return 'Google từ chối truy cập (403). Kiểm tra OAuth consent screen đã thêm email của bạn vào danh sách test user chưa.';
  }
  if (status === 404) return 'Không tìm thấy file/folder trên Google Drive.';
  return `Lỗi Google Drive (${status}).${detail ? ' ' + detail : ''}`;
}

/** fetch có gắn Bearer token, tự xóa token khi gặp 401. */
async function driveFetch(url: string, init: RequestInit = {}): Promise<Response> {
  const token = await ensureDriveToken();
  const headers = new Headers(init.headers);
  headers.set('Authorization', `Bearer ${token}`);
  const res = await fetch(url, { ...init, headers });
  if (res.status === 401) {
    clearToken();
    throw new Error('Token hết hạn hoặc bị thu hồi. Vui lòng đăng nhập Google lại.');
  }
  return res;
}

async function throwDriveError(res: Response): Promise<never> {
  let detail = '';
  try {
    const body = (await res.json()) as { error?: { message?: string } };
    detail = body?.error?.message ?? '';
  } catch {
    /* body không phải JSON */
  }
  throw new Error(driveErrorMessage(res.status, detail));
}

/** Gọi Drive API v3, trả JSON. `path` có thể là đường dẫn tương đối hoặc URL đầy đủ. */
async function driveJson(pathOrUrl: string, init: RequestInit = {}): Promise<Record<string, unknown>> {
  const url = pathOrUrl.startsWith('http') ? pathOrUrl : `https://www.googleapis.com${pathOrUrl}`;
  const res = await driveFetch(url, init);
  if (!res.ok) await throwDriveError(res);
  if (res.status === 204) return {};
  return (await res.json()) as Record<string, unknown>;
}

// ---------------------------------------------------------------- folders ---
async function ensureFolder(name: string, storeKey: string): Promise<string> {
  try {
    const cached = localStorage.getItem(storeKey);
    if (cached) return cached;
  } catch {
    /* ignore */
  }
  // Tìm folder do app tạo trước (tránh tạo trùng)
  const q = encodeURIComponent(
    `name = '${name.replace(/'/g, "\\'")}' and mimeType = '${FOLDER_MIME}' and trashed = false`,
  );
  const found = await driveJson(`/drive/v3/files?q=${q}&fields=files(id)&pageSize=5&spaces=drive`);
  const files = (found.files as { id?: string }[] | undefined) ?? [];
  if (files[0]?.id) {
    try {
      localStorage.setItem(storeKey, files[0].id);
    } catch {
      /* ignore */
    }
    return files[0].id;
  }
  // Chưa có → tạo mới
  const created = await driveJson('/drive/v3/files', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, mimeType: FOLDER_MIME }),
  });
  const id = created.id as string | undefined;
  if (!id) throw new Error('Không tạo được thư mục trên Google Drive.');
  try {
    localStorage.setItem(storeKey, id);
  } catch {
    /* ignore */
  }
  return id;
}

/** Tìm/tạo thư mục "Beesy POS Backup", trả folderId (cache vào localStorage). */
export function ensureBackupFolder(): Promise<string> {
  return ensureFolder(BACKUP_FOLDER_NAME, BACKUP_FOLDER_KEY);
}

function ensureImagesFolder(): Promise<string> {
  return ensureFolder(IMAGES_FOLDER_NAME, IMAGES_FOLDER_KEY);
}

// ---------------------------------------------------------------- helpers ---
/** Chuỗi giờ VN dạng YYYYMMDD-HHmm cho tên file backup. */
function vnStamp(): string {
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Asia/Ho_Chi_Minh',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(new Date());
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? '00';
  return `${get('year')}${get('month')}${get('day')}-${get('hour')}${get('minute')}`;
}

// ----------------------------------------------------------------- backup ---
/**
 * Xuất toàn bộ dữ liệu Firestore (exportAllJson) rồi upload lên folder
 * "Beesy POS Backup" trên Google Drive. Trả về tên file + dung lượng (bytes).
 */
export async function backupToDrive(): Promise<{ fileName: string; size: number }> {
  const folderId = await ensureBackupFolder();
  const data = await exportAllJson();
  const json = JSON.stringify(data);
  const size = new TextEncoder().encode(json).length;
  const fileName = `beesy-backup-${vnStamp()}.json`;

  const form = new FormData();
  form.append(
    'metadata',
    new Blob(
      [JSON.stringify({ name: fileName, parents: [folderId], mimeType: 'application/json' })],
      { type: 'application/json' },
    ),
  );
  form.append('file', new Blob([json], { type: 'application/json' }), fileName);

  const res = await driveFetch(
    'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,size',
    { method: 'POST', body: form },
  );
  if (!res.ok) await throwDriveError(res);
  return { fileName, size };
}

/** Liệt kê file sao lưu trong folder backup, file mới nhất trước. */
export async function listBackupFiles(): Promise<DriveFileInfo[]> {
  const folderId = await ensureBackupFolder();
  const q = encodeURIComponent(`'${folderId}' in parents and trashed = false`);
  const body = await driveJson(
    `/drive/v3/files?q=${q}&orderBy=createdTime desc&fields=files(id,name,size,createdTime)&pageSize=50&spaces=drive`,
  );
  const files =
    (body.files as { id?: string; name?: string; size?: string; createdTime?: string }[] | undefined) ??
    [];
  return files
    .filter((f) => f.id && f.name)
    .map((f) => ({
      id: f.id as string,
      name: f.name as string,
      size: f.size ?? '0',
      createdTime: f.createdTime ?? '',
    }));
}

/** Tải 1 file backup từ Drive về + JSON.parse + validate cấu trúc cơ bản. */
export async function downloadBackupFile(fileId: string): Promise<Record<string, unknown[]>> {
  if (!fileId) throw new Error('Thiếu mã file sao lưu.');
  const res = await driveFetch(
    `https://www.googleapis.com/drive/v3/files/${encodeURIComponent(fileId)}?alt=media`,
  );
  if (!res.ok) await throwDriveError(res);
  const text = await res.text();
  let parsed: unknown;
  try {
    parsed = JSON.parse(text);
  } catch {
    throw new Error('File sao lưu không đúng định dạng JSON — có thể file đã bị hỏng.');
  }
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
    throw new Error('File sao lưu không đúng cấu trúc dữ liệu.');
  }
  const data = parsed as Record<string, unknown>;
  const hasTable = RESTORE_COLLECTIONS.some((c) => Array.isArray(data[c]));
  if (!hasTable) throw new Error('File sao lưu không chứa bảng dữ liệu nào hợp lệ.');
  return data as Record<string, unknown[]>;
}

// ---------------------------------------------------------------- restore ---
interface RestoreOp {
  col: string;
  id: string;
  data: Record<string, unknown>;
}

/**
 * Ghi dữ liệu backup vào Firestore bằng writeBatch (tối đa 500 ops/batch,
 * tự chia nhiều batch). Ghi đè bằng setDoc + merge (an toàn, KHÔNG xóa
 * collection). Giữ nguyên doc id trong data (orders dùng client_uuid).
 */
export async function restoreFromData(
  data: Record<string, unknown[]>,
): Promise<{ collections: number; docs: number }> {
  const ops: RestoreOp[] = [];
  for (const col of RESTORE_COLLECTIONS) {
    const rows = data[col];
    if (!Array.isArray(rows)) continue;
    for (const row of rows) {
      if (!row || typeof row !== 'object' || Array.isArray(row)) continue;
      const rec = row as Record<string, unknown>;
      let id = typeof rec.id === 'string' ? rec.id : '';
      // orders trong exportAllJson lưu id = doc id (chính là client_uuid)
      if (col === 'orders' && typeof rec.client_uuid === 'string' && rec.client_uuid) {
        id = rec.client_uuid;
      }
      if (!id) continue;
      ops.push({ col, id, data: rec });
    }
  }
  if (ops.length === 0) throw new Error('File sao lưu không có dữ liệu nào để khôi phục.');

  const touched = new Set<string>();
  let docs = 0;
  for (let i = 0; i < ops.length; i += 500) {
    const batch = writeBatch(db);
    for (const op of ops.slice(i, i + 500)) {
      batch.set(doc(db, op.col, op.id), op.data, { merge: true });
      touched.add(op.col);
    }
    await batch.commit();
    docs += Math.min(500, ops.length - i);
  }
  return { collections: touched.size, docs };
}

// ----------------------------------------------------------------- images ---
/**
 * Tải ảnh món lên folder "Beesy POS Images" (tự tạo), mở quyền
 * "ai có link đều xem", trả về URL thumbnail để lưu vào product.image_url.
 */
export async function uploadProductImage(file: File): Promise<string> {
  if (!file || !file.type.startsWith('image/')) {
    throw new Error('Vui lòng chọn file ảnh.');
  }
  const folderId = await ensureImagesFolder();

  const form = new FormData();
  form.append(
    'metadata',
    new Blob(
      [JSON.stringify({ name: file.name, parents: [folderId], mimeType: file.type || 'image/jpeg' })],
      { type: 'application/json' },
    ),
  );
  form.append('file', file, file.name);

  const res = await driveFetch(
    'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id',
    { method: 'POST', body: form },
  );
  if (!res.ok) await throwDriveError(res);
  const body = (await res.json()) as { id?: string };
  if (!body.id) throw new Error('Tải ảnh lên thất bại (không nhận được mã file từ Google).');

  // Mở quyền anyone-with-link (reader) để ảnh hiển thị được trên POS
  await driveJson(`/drive/v3/files/${encodeURIComponent(body.id)}/permissions`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ type: 'anyone', role: 'reader', allowFileDiscovery: false }),
  });

  return `https://drive.google.com/thumbnail?id=${body.id}&sz=w400`;
}
