// Offline-first: cache menu + outbox đơn chờ đồng bộ
// (bản Firebase — outbox đẩy lại qua createOrder của lib/db.ts)
import { useCallback, useEffect, useState } from 'react';
import { createOrder, DbError, type CreateOrderInput } from './db';
import type { Category, ModifierGroup, Product } from './types';

export const MENU_CACHE_KEY = 'beesy_menu_cache';
export const OUTBOX_KEY = 'beesy_outbox';

export interface MenuCache {
  savedAt: string;
  categories: Category[];
  products: Product[];
  modifierGroups: ModifierGroup[];
}

export interface OutboxOrder {
  clientUuid: string;
  createdAt: string;
  payload: CreateOrderInput;
}

function readJSON<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function loadMenuCache(): MenuCache | null {
  return readJSON<MenuCache | null>(MENU_CACHE_KEY, null);
}

export function saveMenuCache(data: Omit<MenuCache, 'savedAt'>): void {
  const cache: MenuCache = { ...data, savedAt: new Date().toISOString() };
  localStorage.setItem(MENU_CACHE_KEY, JSON.stringify(cache));
}

export function loadOutbox(): OutboxOrder[] {
  return readJSON<OutboxOrder[]>(OUTBOX_KEY, []);
}

export function saveOutbox(list: OutboxOrder[]): void {
  localStorage.setItem(OUTBOX_KEY, JSON.stringify(list));
}

export function queueOrder(o: OutboxOrder): OutboxOrder[] {
  const list = loadOutbox();
  list.push(o);
  saveOutbox(list);
  return list;
}

// Đẩy lại outbox khi có mạng; createOrder idempotent theo clientUuid (đơn trùng → trả về đơn cũ)
export async function syncOutbox(): Promise<{ ok: number; fail: number }> {
  let ok = 0;
  let fail = 0;
  const remaining: OutboxOrder[] = [];
  for (const o of loadOutbox()) {
    try {
      await createOrder(o.payload);
      ok += 1;
    } catch (e) {
      fail += 1;
      if (e instanceof DbError && e.code === 'unavailable') {
        remaining.push(o); // vẫn offline → giữ lại
      }
      // Lỗi khác (dữ liệu không hợp lệ, hết quyền…): không đẩy lại nữa, bỏ khỏi hàng đợi
    }
  }
  saveOutbox(remaining);
  return { ok, fail };
}

// Hook theo dõi trạng thái mạng + tự đẩy outbox khi online trở lại
export function useOnlineStatus(onSynced?: (r: { ok: number; fail: number }) => void) {
  const [online, setOnline] = useState(() => navigator.onLine);
  const [pending, setPending] = useState(() => loadOutbox().length);

  const doSync = useCallback(async () => {
    const list = loadOutbox();
    if (list.length === 0) {
      setPending(0);
      return;
    }
    const r = await syncOutbox();
    setPending(loadOutbox().length);
    onSynced?.(r);
  }, [onSynced]);

  useEffect(() => {
    const up = () => {
      setOnline(true);
      void doSync();
    };
    const down = () => setOnline(false);
    window.addEventListener('online', up);
    window.addEventListener('offline', down);
    setPending(loadOutbox().length);
    return () => {
      window.removeEventListener('online', up);
      window.removeEventListener('offline', down);
    };
  }, [doSync]);

  const refreshPending = useCallback(() => setPending(loadOutbox().length), []);

  return { online, pending, doSync, refreshPending };
}
