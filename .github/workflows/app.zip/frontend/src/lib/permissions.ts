// Phân quyền chi tiết theo nhóm nhân viên.
// Cấp độ: owner (4) > manager/Quản lý (3) > cashier/Thu ngân (2) > seller/Bán hàng (1).
// Mỗi chức năng khai báo cấp tối thiểu — client (UI/menu) và firestore.rules
// dùng chung ma trận này (rules tự kiểm tra lại, không tin client).

import type { RoleKey } from './types';

export const ROLE_LABELS: Record<RoleKey, string> = {
  owner: 'Chủ quán',
  manager: 'Quản lý',
  cashier: 'Thu ngân',
  seller: 'Bán hàng',
};

/** Các vai trò gán được cho nhân viên (chủ quán chỉ có 1, tạo ở /setup). */
export const STAFF_ROLES: RoleKey[] = ['manager', 'cashier', 'seller'];

const ROLE_LEVEL: Record<RoleKey, number> = {
  owner: 4,
  manager: 3,
  cashier: 2,
  seller: 1,
};

/** Chuẩn hóa vai trò — dữ liệu cũ 'staff' thành 'seller'. */
export function normalizeRole(r: unknown): RoleKey {
  if (r === 'owner' || r === 'manager' || r === 'cashier' || r === 'seller') return r;
  return 'seller';
}

export function roleLevel(role: unknown): number {
  return ROLE_LEVEL[normalizeRole(role)] ?? 0;
}

export type ActionKey =
  | 'pos'
  | 'kds'
  | 'orders.view'
  | 'orders.edit' // sửa ghi chú/khách của đơn đã bán
  | 'orders.delete' // xóa đơn (hoàn nợ, hoàn kho, xóa khoản quỹ)
  | 'menu' // quản lý món/danh mục/topping (kèm định lượng)
  | 'inventory' // nhập/xuất/chuyển kho
  | 'inventory.manage' // quản lý kho + thêm/sửa/xóa nguyên liệu
  | 'customers'
  | 'debt' // sổ nợ: xem + thu nợ (ghi nợ ở POS thuộc 'pos')
  | 'cashbook' // sổ quỹ: xem + nhập khoản tay
  | 'cashbook.settings' // số dư đầu kỳ, danh mục thu/chi
  | 'reports'
  | 'settings' // cài đặt quán, thanh toán, sao lưu
  | 'staff.manage'; // thêm/sửa vai trò, gán kho cho nhân viên

const ACTION_MIN_LEVEL: Record<ActionKey, number> = {
  pos: 1,
  kds: 1,
  'orders.view': 1,
  'orders.edit': 3,
  'orders.delete': 4,
  menu: 3,
  inventory: 3,
  'inventory.manage': 3,
  customers: 1,
  debt: 2,
  cashbook: 3,
  'cashbook.settings': 4,
  reports: 3,
  settings: 4,
  'staff.manage': 4,
};

/** Tài khoản có được làm hành động này không? */
export function can(role: RoleKey | null | undefined, action: ActionKey): boolean {
  if (!role) return false;
  return roleLevel(role) >= ACTION_MIN_LEVEL[action];
}
