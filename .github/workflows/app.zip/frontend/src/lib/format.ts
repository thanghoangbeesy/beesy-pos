// Định dạng tiếng Việt

export function formatVND(n: number | null | undefined): string {
  // Dùng "đ" thay cho ký hiệu "₫" (U+20AB) vì một số font/máy in nhiệt
  // không có glyph ₫ nên hiện ô vuông vỡ chữ; "đ" luôn hiển thị đúng.
  if (n === null || n === undefined) return '0đ';
  return `${Math.round(n).toLocaleString('vi-VN')}đ`;
}

export function formatTime(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' });
}

export function formatDateTime(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleString('vi-VN', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function todayVN(): string {
  // YYYY-MM-DD theo Asia/Ho_Chi_Minh
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Ho_Chi_Minh',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date());
}

// ---- Tiện ích tính khoảng ngày cho bộ lọc báo cáo (tất cả YYYY-MM-DD) ----
function toUTCDate(s: string): Date {
  const [y, m, d] = s.split('-').map(Number);
  return new Date(Date.UTC(y, m - 1, d));
}

function toISODate(d: Date): string {
  return d.toISOString().slice(0, 10);
}

/** Cộng/trừ N ngày vào một chuỗi ngày YYYY-MM-DD. */
export function addDaysVN(dateStr: string, days: number): string {
  const d = toUTCDate(dateStr);
  d.setUTCDate(d.getUTCDate() + days);
  return toISODate(d);
}

/** Thứ Hai của tuần chứa ngày cho trước (tuần VN bắt đầu từ Thứ Hai). */
export function startOfWeekVN(ref?: string): string {
  const d = toUTCDate(ref ?? todayVN());
  const diff = (d.getUTCDay() + 6) % 7; // số ngày kể từ Thứ Hai
  d.setUTCDate(d.getUTCDate() - diff);
  return toISODate(d);
}

/** Ngày mùng 1 của tháng chứa ngày cho trước. */
export function startOfMonthVN(ref?: string): string {
  const d = toUTCDate(ref ?? todayVN());
  return toISODate(new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1)));
}

/** Ngày cuối cùng của tháng chứa ngày cho trước. */
export function endOfMonthVN(ref?: string): string {
  const d = toUTCDate(ref ?? todayVN());
  return toISODate(new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0)));
}

/** Định dạng YYYY-MM-DD → DD/MM/YYYY để hiển thị. */
export function formatDMY(dateStr: string): string {
  const [y, m, d] = dateStr.split('-');
  return `${d}/${m}/${y}`;
}

// Bỏ dấu tiếng Việt cho accountName của VietQR (theo CONTRACT mục 6)
export function unsignVietnamese(s: string): string {
  return s
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/đ/g, 'd')
    .replace(/Đ/g, 'D')
    .replace(/[^a-zA-Z0-9 ]/g, '')
    .trim()
    .toUpperCase();
}

export function buildVietQRUrl(
  bankBin: string,
  account: string,
  accountName: string,
  amount: number,
  addInfo: string,
): string {
  const name = encodeURIComponent(unsignVietnamese(accountName));
  const info = encodeURIComponent(addInfo);
  return `https://img.vietqr.io/image/${bankBin}-${account}-compact2.png?amount=${amount}&addInfo=${info}&accountName=${name}`;
}

export function uuid(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID();
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}
