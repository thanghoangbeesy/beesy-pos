// Khởi tạo Firebase (dùng gói miễn phí Spark: Firestore + Auth + Hosting)
import { initializeApp, getApps, type FirebaseApp } from 'firebase/app';
import { getAuth, type Auth } from 'firebase/auth';
import {
  initializeFirestore,
  getFirestore,
  persistentLocalCache,
  persistentMultipleTabManager,
  type Firestore,
} from 'firebase/firestore';

function env(name: string): string {
  const v = import.meta.env[name] as string | undefined;
  if (!v) {
    throw new Error(
      `Thiếu biến môi trường ${name}. Copy frontend/.env.example thành frontend/.env rồi điền config của Web app (Firebase console → Project settings).`,
    );
  }
  return v;
}

let app: FirebaseApp;
// Export config để khởi tạo Firebase app phụ (dùng khi chủ quán thêm tài khoản nhân viên
// mà không bị đăng xuất khỏi phiên hiện tại).
export const firebaseConfig = {
  apiKey: env('VITE_FIREBASE_API_KEY'),
  authDomain: env('VITE_FIREBASE_AUTH_DOMAIN'),
  projectId: env('VITE_FIREBASE_PROJECT_ID'),
  storageBucket: env('VITE_FIREBASE_STORAGE_BUCKET'),
  messagingSenderId: env('VITE_FIREBASE_MESSAGING_SENDER_ID'),
  appId: env('VITE_FIREBASE_APP_ID'),
};
if (getApps().length > 0) {
  app = getApps()[0]!;
} else {
  app = initializeApp(firebaseConfig);
}

// Auth: Firebase tự lưu phiên đăng nhập (không cần localStorage thủ công)
export const auth: Auth = getAuth(app);

// Firestore + cache offline bền vững (gói Spark cho phép).
// persistentMultipleTabManager: mở POS + KDS trên nhiều tab vẫn đồng bộ cache.
let firestore: Firestore;
try {
  firestore = initializeFirestore(app, {
    localCache: persistentLocalCache({
      tabManager: persistentMultipleTabManager(),
    }),
  });
} catch {
  // VD: HMR khởi tạo 2 lần, hoặc trình duyệt không hỗ trợ IndexedDB
  firestore = getFirestore(app);
}
export const db: Firestore = firestore;
