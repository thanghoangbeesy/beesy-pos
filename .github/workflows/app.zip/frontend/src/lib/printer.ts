// In hóa đơn qua máy in nhiệt Bluetooth (XPrinter và các máy chuẩn ESC/POS).
// Dùng Web Bluetooth — cần HTTPS (web.app OK) + thao tác của người dùng (bấm nút).
// Tiếng Việt: máy in nhiệt thường không có codepage tiếng Việt nên bill in
// không dấu (đã có sẵn unsignVietnamese). Đây là chuẩn chung của bill nhiệt VN.

import { unsignVietnamese } from './format';

const ESC = 0x1b;
const GS = 0x1d;

export interface ReceiptData {
  shopName: string;
  orderCode: string;
  createdAt: string; // ISO
  cashierName: string;
  customerName?: string | null;
  warehouseName?: string | null;
  items: { name: string; qty: number; unitPrice: number; lineTotal: number; note?: string }[];
  subtotal: number;
  discount: number;
  discountLabel?: string | null;
  total: number;
  paymentMethodName: string;
  amountReceived?: number | null;
  changeAmount?: number | null;
}

type WebBluetooth = {
  requestDevice: (opts: Record<string, unknown>) => Promise<BluetoothDeviceLike>;
};
type BluetoothDeviceLike = {
  name?: string;
  gatt?: {
    connect: () => Promise<BluetoothServerLike>;
  };
};
type BluetoothServerLike = {
  getPrimaryServices: () => Promise<BluetoothServiceLike[]>;
};
type BluetoothServiceLike = {
  getCharacteristics: () => Promise<BluetoothCharLike[]>;
};
type BluetoothCharLike = {
  properties: { write?: boolean; writeWithoutResponse?: boolean };
  writeValueWithResponse?: (v: BufferSource) => Promise<void>;
  writeValueWithoutResponse?: (v: BufferSource) => Promise<void>;
};

let deviceName: string | null = null;
let writeChar: BluetoothCharLike | null = null;

/** Trình duyệt có hỗ trợ Web Bluetooth không? */
export function isBluetoothSupported(): boolean {
  return typeof navigator !== 'undefined' && !!(navigator as unknown as { bluetooth?: unknown }).bluetooth;
}

function getBT(): WebBluetooth {
  const bt = (navigator as unknown as { bluetooth?: WebBluetooth }).bluetooth;
  if (!bt) throw new Error('Trình duyệt không hỗ trợ Bluetooth. Dùng Chrome trên Android/PC.');
  return bt;
}

// Các service BLE phổ biến của máy in nhiệt (XPrinter dùng 0xFFE0/0xFFE1 kiểu HM-10,
// một số dùng 0xFF00 hoặc Microchip 49535343-...).
const PRINTER_SERVICES = [
  0xffe0,
  0xff00,
  '49535343-fe7d-4ae6-8fa9-370793520401',
  '0000ff00-0000-1000-8000-00805f9b34fb',
];

/** Kết nối máy in (hiện popup chọn thiết bị của trình duyệt). */
export async function connectPrinter(): Promise<string> {
  const bt = getBT();
  const device = await bt.requestDevice({
    acceptAllDevices: true,
    optionalServices: PRINTER_SERVICES as unknown as string[],
  });
  const server = await device.gatt?.connect();
  if (!server) throw new Error('Không kết nối được tới máy in.');
  const services = await server.getPrimaryServices();
  for (const svc of services) {
    const chars = await svc.getCharacteristics();
    const writable = chars.find((c) => c.properties.writeWithoutResponse || c.properties.write);
    if (writable) {
      writeChar = writable;
      deviceName = device.name ?? 'Máy in';
      return deviceName;
    }
  }
  throw new Error('Thiết bị này không có cổng ghi ESC/POS. Kiểm tra lại máy in.');
}

export function getPrinterName(): string | null {
  return deviceName;
}

export function isPrinterConnected(): boolean {
  return !!writeChar;
}

export function disconnectPrinter(): void {
  writeChar = null;
  deviceName = null;
}

// ---------- Dựng lệnh ESC/POS ----------

function ascii(s: string): number[] {
  // Bill không dấu để tương thích mọi máy in nhiệt
  const clean = unsignVietnamese(s).replace(/[^\x20-\x7E\n]/g, '');
  return [...clean].map((c) => c.charCodeAt(0));
}

function line(s = ''): number[] {
  return [...ascii(s), 0x0a];
}

function money(n: number): string {
  return Math.round(n).toLocaleString('vi-VN') + 'd';
}

function center(s: string): number[] {
  return [ESC, 0x61, 0x01, ...line(s), ESC, 0x61, 0x00];
}

function big(s: string): number[] {
  return [GS, 0x21, 0x11, ...center(s), GS, 0x21, 0x00];
}

function twoCol(left: string, right: string, width = 32): number[] {
  const l = unsignVietnamese(left).replace(/[^\x20-\x7E]/g, '');
  const r = unsignVietnamese(right).replace(/[^\x20-\x7E]/g, '');
  const spaces = Math.max(1, width - l.length - r.length);
  return line(l + ' '.repeat(spaces) + r);
}

const DIV = '--------------------------------';

export function buildReceipt(data: ReceiptData): Uint8Array {
  const b: number[] = [];
  b.push(ESC, 0x40); // init
  b.push(...big(data.shopName.toUpperCase()));
  b.push(...center('CAM ON QUY KHACH'));
  b.push(...line(DIV));
  b.push(...twoCol('Ma don:', data.orderCode));
  const d = new Date(data.createdAt);
  const dt = `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  b.push(...twoCol('Thoi gian:', dt));
  if (data.cashierName) b.push(...twoCol('Thu ngan:', data.cashierName));
  if (data.customerName) b.push(...twoCol('Khach:', data.customerName));
  if (data.warehouseName) b.push(...twoCol('Kho:', data.warehouseName));
  b.push(...line(DIV));
  for (const it of data.items) {
    b.push(...line(it.name));
    b.push(...twoCol(`  ${it.qty} x ${money(it.unitPrice)}`, money(it.lineTotal)));
    if (it.note) b.push(...line(`  (${it.note})`));
  }
  b.push(...line(DIV));
  b.push(...twoCol('Tam tinh:', money(data.subtotal)));
  if (data.discount > 0) {
    b.push(...twoCol(`Giam gia${data.discountLabel ? ` (${data.discountLabel})` : ''}:`, '-' + money(data.discount)));
  }
  b.push(ESC, 0x45, 0x01, ...ascii('TONG CONG: ' + money(data.total)), ESC, 0x45, 0x00, 0x0a);
  b.push(...twoCol('Thanh toan:', data.paymentMethodName));
  if (data.amountReceived != null) {
    b.push(...twoCol('Khach dua:', money(data.amountReceived)));
    b.push(...twoCol('Thoi lai:', money(data.changeAmount ?? 0)));
  }
  b.push(...line(DIV));
  b.push(...center('Hen gap lai!'));
  b.push(0x0a, 0x0a, 0x0a);
  b.push(GS, 0x56, 0x00); // cắt giấy
  return new Uint8Array(b);
}

async function writeChunks(data: Uint8Array): Promise<void> {
  const char = writeChar;
  if (!char) throw new Error('Chưa kết nối máy in.');
  const CHUNK = 100;
  for (let i = 0; i < data.length; i += CHUNK) {
    const chunk = data.slice(i, i + CHUNK);
    if (char.properties.writeWithoutResponse && char.writeValueWithoutResponse) {
      await char.writeValueWithoutResponse(chunk);
    } else if (char.writeValueWithResponse) {
      await char.writeValueWithResponse(chunk);
    } else {
      throw new Error('Máy in không hỗ trợ ghi dữ liệu.');
    }
    await new Promise((r) => setTimeout(r, 30));
  }
}

/** In hóa đơn — tự throw lỗi tiếng Việt thân thiện khi thất bại. */
export async function printReceipt(data: ReceiptData): Promise<void> {
  try {
    await writeChunks(buildReceipt(data));
  } catch (e) {
    writeChar = null;
    deviceName = null;
    throw new Error(
      e instanceof Error && e.message.startsWith('Chưa kết nối')
        ? 'Chưa kết nối máy in. Bấm "Kết nối máy in" trước.'
        : 'In thất bại — kiểm tra máy in đã bật và ở gần điện thoại.',
    );
  }
}
