// Realtime cho màn hình KDS qua Firestore onSnapshot (thay Socket.IO của bản self-hosted)
import { useEffect, useRef } from 'react';
import { collection, query, where, orderBy, limit, onSnapshot } from 'firebase/firestore';
import { db } from './firebase';
import { orderFromDoc } from './db';
import type { Order } from './types';

// Âm báo đơn mới bằng Web Audio (không cần file âm thanh ngoài)
let audioCtx: AudioContext | null = null;
export function playNewOrderSound(): void {
  try {
    if (!audioCtx)
      audioCtx = new (window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    if (audioCtx.state === 'suspended') void audioCtx.resume();
    const t0 = audioCtx.currentTime;
    [880, 1174.66, 880].forEach((freq, i) => {
      const osc = audioCtx!.createOscillator();
      const gain = audioCtx!.createGain();
      osc.type = 'sine';
      osc.frequency.value = freq;
      const start = t0 + i * 0.22;
      gain.gain.setValueAtTime(0.0001, start);
      gain.gain.exponentialRampToValueAtTime(0.5, start + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.2);
      osc.connect(gain).connect(audioCtx!.destination);
      osc.start(start);
      osc.stop(start + 0.22);
    });
  } catch {
    /* bỏ qua nếu trình duyệt chặn audio */
  }
}

// Đăng ký nhận các đơn đang hoạt động của 1 ngày bán; trả hàm hủy đăng ký
export function subscribeKdsOrders(date: string, cb: (orders: Order[]) => void, warehouseIds?: string[] | null): () => void {
  const q = query(
    collection(db, 'orders'),
    where('business_date', '==', date),
    where('status', 'in', ['new', 'preparing', 'ready']),
    orderBy('created_at', 'desc'),
    limit(200),
  );
  return onSnapshot(
    q,
    (snap) => {
      const orders = snap.docs
        .map((d) => orderFromDoc(d))
        .filter((o): o is Order => o !== null)
        .filter((o) => !warehouseIds || warehouseIds.length === 0 || (!!o.warehouse_id && warehouseIds.includes(o.warehouse_id)));
      cb(orders);
    },
    (err) => {
      console.error('KDS realtime lỗi:', err);
    },
  );
}

interface KdsHandlers {
  onCreated?: (order: Order) => void;
  onUpdated?: (order: Order) => void;
}

// Hook realtime KDS: BỎ QUA snapshot đầu tiên (chỉ nạp map),
// các lần sau diff theo id: mới → onCreated, đổi field → onUpdated, biến mất → xóa khỏi map.
export function useKdsRealtime(
  date: string,
  handlers: KdsHandlers,
  warehouseIds?: string[] | null,
): void {
  const hRef = useRef(handlers);
  hRef.current = handlers;
  const scopeKey = JSON.stringify(warehouseIds ?? []);

  useEffect(() => {
    const seen = new Map<string, string>(); // id → chữ ký JSON của đơn
    let first = true;
    const unsub = subscribeKdsOrders(
      date,
      (orders) => {
        if (first) {
          first = false;
          for (const o of orders) seen.set(o.id, JSON.stringify(o));
          return;
        }
        const nextIds = new Set(orders.map((o) => o.id));
        for (const o of orders) {
          const sig = JSON.stringify(o);
          const prev = seen.get(o.id);
          if (prev === undefined) {
            hRef.current.onCreated?.(o);
          } else if (prev !== sig) {
            hRef.current.onUpdated?.(o);
          }
          seen.set(o.id, sig);
        }
        for (const id of [...seen.keys()]) {
          if (!nextIds.has(id)) seen.delete(id);
        }
      },
      warehouseIds,
    );
    return unsub;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [date, scopeKey]);
}
