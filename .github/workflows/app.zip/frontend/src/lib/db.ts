// Lớp dữ liệu Firestore cho Beesy POS (gói miễn phí Spark — không dùng Cloud Functions).
// Mọi tính toán giá/tích tem thực hiện client-side, mirror logic backend self-hosted
// (backend/src/routes/orders.js + lib/pricing.js), với validation thêm ở firestore.rules.
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  writeBatch,
  query,
  where,
  orderBy,
  limit,
  runTransaction,
  serverTimestamp,
  Timestamp,
  FirestoreError,
  type DocumentSnapshot,
  type QueryDocumentSnapshot,
  type Transaction,
} from 'firebase/firestore';
import { auth, db } from './firebase';
import { todayVN, unsignVietnamese, uuid } from './format';
import { normalizeRole, roleLevel } from './permissions';
import type {
  CashbookEntry,
  CashbookType,
  Category,
  Customer,
  DailyReport,
  DebtLog,
  DraftOrder,
  DraftOrderItem,
  FundRefType,
  FundCategories,
  FundSettings,
  Fund,
  Ingredient,
  IngredientWithStock,
  StockLog,
  RecipeItem,
  ModifierGroup,
  ModifierOption,
  Order,
  OrderItem,
  OrderStatus,
  PaymentMethod,
  PaymentMethodDef,
  PaymentMethodKind,
  Product,
  SelectedModifier,
  User,
  Warehouse,
  RoleKey,
} from './types';

// ---------------------------------------------------------------- DbError ---
export class DbError extends Error {
  code: string;
  constructor(code: string, message: string) {
    super(message);
    this.name = 'DbError';
    this.code = code;
  }
}

const FIRESTORE_CODE_MAP: Record<string, string> = {
  'deadline-exceeded': 'unavailable',
  unavailable: 'unavailable',
  'permission-denied': 'permission-denied',
  'not-found': 'not-found',
  'invalid-argument': 'invalid-argument',
};

export function toDbError(e: unknown): DbError {
  if (e instanceof DbError) return e;
  if (e instanceof FirestoreError) {
    const code = FIRESTORE_CODE_MAP[e.code] ?? 'unknown';
    const message =
      code === 'unavailable'
        ? 'Mất kết nối mạng. Vui lòng kiểm tra internet rồi thử lại.'
        : code === 'permission-denied'
          ? 'Bạn không có quyền thực hiện thao tác này.'
          : e.message;
    return new DbError(code, message);
  }
  return new DbError('unknown', e instanceof Error ? e.message : 'Lỗi không xác định.');
}

// ------------------------------------------------------------- converters ---
function tsToIso(v: unknown): string {
  if (v instanceof Timestamp) return v.toDate().toISOString();
  if (typeof v === 'string' && v) return v;
  return new Date().toISOString();
}

function activeOf(d: Record<string, unknown>): boolean {
  return d.active !== false;
}

function toCategory(id: string, d: Record<string, unknown>): Category {
  return {
    id,
    name: String(d.name ?? ''),
    sort_order: Number(d.sort_order ?? 0),
    active: activeOf(d),
  };
}

function toProduct(id: string, d: Record<string, unknown>): Product {
  const recipeRaw = Array.isArray(d.recipe) ? d.recipe : [];
  const recipe: RecipeItem[] = [];
  for (const r of recipeRaw) {
    const o = r as Record<string, unknown>;
    const q = Number(o.qty ?? 0);
    if (typeof o.ingredient_id === 'string' && o.ingredient_id && q > 0) {
      recipe.push({ ingredient_id: o.ingredient_id, qty: q });
    }
  }
  return {
    id,
    name: String(d.name ?? ''),
    category_id: (d.category_id as string | null) ?? null,
    base_price: Number(d.base_price ?? 0),
    cost_price: Math.max(0, Math.round(Number(d.cost_price ?? 0)) || 0),
    unit: String(d.unit ?? '').trim().slice(0, 20),
    recipe,
    image_url: (d.image_url as string | null) ?? null,
    active: activeOf(d),
    sort_order: Number(d.sort_order ?? 0),
  };
}

function toModifierOption(id: string, d: Record<string, unknown>): ModifierOption {
  return {
    id,
    group_id: String(d.group_id ?? ''),
    name: String(d.name ?? ''),
    price_delta: Number(d.price_delta ?? 0),
    sort_order: Number(d.sort_order ?? 0),
    active: activeOf(d),
  };
}

function toModifierGroup(
  id: string,
  d: Record<string, unknown>,
  options: ModifierOption[],
): ModifierGroup {
  return {
    id,
    name: String(d.name ?? ''),
    selection_type: d.selection_type === 'multi' ? 'multi' : 'single',
    required: d.required === true,
    sort_order: Number(d.sort_order ?? 0),
    active: activeOf(d),
    options,
  };
}

function toCustomer(id: string, d: Record<string, unknown>): Customer {
  return {
    id,
    name: String(d.name ?? ''),
    phone: String(d.phone ?? ''),
    birthday: (d.birthday as string | null) ?? null,
    address: (d.address as string | null) ?? null,
    stamps: Number(d.stamps ?? 0),
    reward_available: d.reward_available === true,
    debt: Number(d.debt ?? 0),
    note: (d.note as string | null) ?? null,
    created_at: tsToIso(d.created_at),
  };
}

function toPaymentMethod(id: string, d: Record<string, unknown>): PaymentMethodDef {
  const kind = d.kind as string;
  return {
    id,
    name: String(d.name ?? ''),
    kind: kind === 'transfer' || kind === 'debt' ? kind : 'cash',
    icon: String(d.icon ?? ''),
    bank_bin: (d.bank_bin as string | null) ?? null,
    bank_account: (d.bank_account as string | null) ?? null,
    bank_account_name: (d.bank_account_name as string | null) ?? null,
    active: activeOf(d),
    sort_order: Number(d.sort_order ?? 0),
  };
}

function toDebtLog(id: string, d: Record<string, unknown>): DebtLog {
  return {
    id,
    amount: Number(d.amount ?? 0),
    balance_after: Number(d.balance_after ?? 0),
    note: (d.note as string | null) ?? null,
    created_by: (d.created_by as string | null) ?? null,
    created_at: tsToIso(d.created_at),
  };
}

// Convert 1 document orders → Order (dùng chung cho db.ts và realtime.ts)
export function orderFromDoc(
  snap: DocumentSnapshot | QueryDocumentSnapshot,
): Order | null {
  if (!snap.exists()) return null;
  const d = snap.data() as Record<string, unknown>;
  const rawItems = Array.isArray(d.items) ? d.items : [];
  const items: OrderItem[] = rawItems.map((it: Record<string, unknown>, i: number) => ({
    id: String(it.id ?? `${snap.id}-item-${i}`),
    order_id: String(it.order_id ?? snap.id),
    product_id: String(it.product_id ?? ''),
    product_name: String(it.product_name ?? ''),
    qty: Number(it.qty ?? 0),
    unit_price: Number(it.unit_price ?? 0),
    cost_price: Math.max(0, Math.round(Number(it.cost_price ?? 0)) || 0),
    recipe: sanitizeRecipe(it.recipe),
    modifiers: (Array.isArray(it.modifiers) ? it.modifiers : []).map(
      (m: Record<string, unknown>): SelectedModifier => ({
        option_id: String(m.option_id ?? ''),
        group: String(m.group ?? ''),
        option: String(m.option ?? ''),
        price_delta: Number(m.price_delta ?? 0),
      }),
    ),
    line_total: Number(it.line_total ?? 0),
    ...(typeof it.note === 'string' && it.note ? { note: it.note } : {}),
  }));
  return {
    id: snap.id,
    client_uuid: String(d.client_uuid ?? snap.id),
    code: String(d.code ?? ''),
    business_date: String(d.business_date ?? ''),
    customer_id: (d.customer_id as string | null) ?? null,
    status: d.status as OrderStatus,
    payment_method: String(d.payment_method ?? ''),
    payment_method_name: (d.payment_method_name as string | null) ?? null,
    warehouse_id: (d.warehouse_id as string | null) ?? null,
    warehouse_name: (d.warehouse_name as string | null) ?? null,
    subtotal: Number(d.subtotal ?? 0),
    discount: Number(d.discount ?? 0),
    total: Number(d.total ?? 0),
    amount_received: d.amount_received == null ? null : Number(d.amount_received),
    change_amount: d.change_amount == null ? null : Number(d.change_amount),
    note: (d.note as string | null) ?? null,
    created_by: (d.created_by as string | null) ?? null,
    created_at: tsToIso(d.created_at),
    items,
  };
}

// Giờ VN (0-23) từ chuỗi ISO — mirror backend lib/dates.js#vnHour
function vnHour(iso: string): number {
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Asia/Ho_Chi_Minh',
    hour: 'numeric',
    hourCycle: 'h23',
  }).formatToParts(new Date(iso));
  return Number(parts.find((p) => p.type === 'hour')?.value ?? 0);
}

// ------------------------------------------------------------- categories ---
export async function listCategories(): Promise<Category[]> {
  try {
    const snap = await getDocs(query(collection(db, 'categories'), orderBy('sort_order', 'asc')));
    return snap.docs.map((d) => toCategory(d.id, d.data()));
  } catch (e) {
    throw toDbError(e);
  }
}

export async function createCategory(name: string): Promise<Category> {
  const trimmed = String(name ?? '').trim();
  if (!trimmed) throw new DbError('invalid-argument', 'Vui lòng nhập tên danh mục.');
  try {
    const existing = await listCategories();
    const maxSort = existing.reduce((m, c) => Math.max(m, c.sort_order), 0);
    const id = uuid();
    const data = { id, name: trimmed, sort_order: maxSort + 1, active: true };
    await setDoc(doc(db, 'categories', id), data);
    return toCategory(id, data);
  } catch (e) {
    throw toDbError(e);
  }
}

export async function updateCategory(
  id: string,
  patch: { name?: string; active?: boolean; sort_order?: number },
): Promise<void> {
  const data: Record<string, unknown> = {};
  if (patch.name !== undefined) {
    const trimmed = String(patch.name).trim();
    if (!trimmed) throw new DbError('invalid-argument', 'Tên danh mục không được để trống.');
    data.name = trimmed;
  }
  if (patch.active !== undefined) data.active = patch.active;
  if (patch.sort_order !== undefined) data.sort_order = patch.sort_order;
  if (Object.keys(data).length === 0) return;
  try {
    await updateDoc(doc(db, 'categories', id), data);
  } catch (e) {
    throw toDbError(e);
  }
}

// Xóa danh mục. Các món đang thuộc danh mục này được chuyển sang "chưa phân loại"
// (giữ lại món để vẫn bán được). Trả về số món đã chuyển.
export async function deleteCategory(id: string): Promise<{ moved: number }> {
  try {
    const products = await listProducts();
    const affected = products.filter((p) => p.category_id === id);
    const batch = writeBatch(db);
    for (const p of affected) {
      batch.update(doc(db, 'products', p.id), { category_id: null });
    }
    batch.delete(doc(db, 'categories', id));
    await batch.commit();
    return { moved: affected.length };
  } catch (e) {
    throw toDbError(e);
  }
}

// -------------------------------------------------------------- products ---
export async function listProducts(): Promise<Product[]> {
  try {
    const snap = await getDocs(query(collection(db, 'products'), orderBy('sort_order', 'asc')));
    return snap.docs.map((d) => toProduct(d.id, d.data()));
  } catch (e) {
    throw toDbError(e);
  }
}

export async function createProduct(d: {
  name: string;
  base_price: number;
  category_id: string | null;
  cost_price?: number;
  unit?: string;
  recipe?: RecipeItem[];
}): Promise<Product> {
  const name = String(d.name ?? '').trim();
  if (!name) throw new DbError('invalid-argument', 'Vui lòng nhập tên món.');
  const price = Math.round(Number(d.base_price));
  if (!Number.isFinite(price) || price <= 0) {
    throw new DbError('invalid-argument', 'Giá bán phải là số dương.');
  }
  const cost = Math.max(0, Math.round(Number(d.cost_price ?? 0)) || 0);
  const unit = String(d.unit ?? '').trim().slice(0, 20);
  const recipe = sanitizeRecipe(d.recipe);
  try {
    if (d.category_id) {
      const cat = await getDoc(doc(db, 'categories', d.category_id));
      if (!cat.exists()) throw new DbError('invalid-argument', 'Danh mục không tồn tại.');
    }
    const existing = await listProducts();
    const maxSort = existing.reduce((m, p) => Math.max(m, p.sort_order), 0);
    const id = uuid();
    const data = {
      id,
      name,
      category_id: d.category_id ?? null,
      base_price: price,
      cost_price: cost,
      unit,
      recipe,
      image_url: null,
      active: true,
      sort_order: maxSort + 1,
    };
    await setDoc(doc(db, 'products', id), data);
    return toProduct(id, data);
  } catch (e) {
    throw toDbError(e);
  }
}

/** Chuẩn hóa định lượng: bỏ dòng rỗng, gộp trùng nguyên liệu. */
function sanitizeRecipe(input: unknown): RecipeItem[] {
  if (!Array.isArray(input)) return [];
  const map = new Map<string, number>();
  for (const r of input) {
    const o = r as Record<string, unknown>;
    const q = Number(o.qty ?? 0);
    if (typeof o.ingredient_id === 'string' && o.ingredient_id && q > 0 && Number.isFinite(q)) {
      map.set(o.ingredient_id, (map.get(o.ingredient_id) ?? 0) + q);
    }
  }
  return [...map.entries()].map(([ingredient_id, qty]) => ({ ingredient_id, qty }));
}

export async function updateProduct(
  id: string,
  patch: Partial<Pick<Product, 'name' | 'base_price' | 'cost_price' | 'unit' | 'recipe' | 'category_id' | 'active' | 'sort_order' | 'image_url'>>,
): Promise<void> {
  const data: Record<string, unknown> = {};
  if (patch.name !== undefined) {
    const trimmed = String(patch.name).trim();
    if (!trimmed) throw new DbError('invalid-argument', 'Tên món không được để trống.');
    data.name = trimmed;
  }
  if (patch.base_price !== undefined) {
    const price = Math.round(Number(patch.base_price));
    if (!Number.isFinite(price) || price <= 0) {
      throw new DbError('invalid-argument', 'Giá bán phải là số dương.');
    }
    data.base_price = price;
  }
  if (patch.cost_price !== undefined) {
    const cost = Math.round(Number(patch.cost_price));
    if (!Number.isFinite(cost) || cost < 0) {
      throw new DbError('invalid-argument', 'Giá vốn không hợp lệ.');
    }
    data.cost_price = cost;
  }
  if (patch.unit !== undefined) {
    data.unit = String(patch.unit ?? '').trim().slice(0, 20);
  }
  if (patch.recipe !== undefined) {
    data.recipe = sanitizeRecipe(patch.recipe);
  }
  if (patch.category_id !== undefined) {
    if (patch.category_id) {
      try {
        const cat = await getDoc(doc(db, 'categories', patch.category_id));
        if (!cat.exists()) throw new DbError('invalid-argument', 'Danh mục không tồn tại.');
      } catch (e) {
        throw toDbError(e);
      }
    }
    data.category_id = patch.category_id;
  }
  if (patch.active !== undefined) data.active = patch.active;
  if (patch.sort_order !== undefined) data.sort_order = patch.sort_order;
  if (patch.image_url !== undefined) data.image_url = patch.image_url;
  if (Object.keys(data).length === 0) return;
  try {
    await updateDoc(doc(db, 'products', id), data);
  } catch (e) {
    throw toDbError(e);
  }
}

// Xóa hẳn một món khỏi menu. Đơn hàng cũ không bị ảnh hưởng vì đã lưu tên/giá riêng.
export async function deleteProduct(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'products', id));
  } catch (e) {
    throw toDbError(e);
  }
}

// Thêm nhiều món cùng lúc (từ màn hình "Thêm hàng loạt").
// Mỗi phần tử: { name, base_price, category_id }. Bỏ qua các dòng lỗi, trả về số món đã thêm.
export async function createProductsBulk(
  items: { name: string; base_price: number; category_id: string | null }[],
): Promise<{ added: number }> {
  const valid = items.filter(
    (it) =>
      String(it.name ?? '').trim() &&
      Number.isFinite(Math.round(Number(it.base_price))) &&
      Math.round(Number(it.base_price)) > 0,
  );
  if (valid.length === 0) throw new DbError('invalid-argument', 'Không có món hợp lệ để thêm.');
  try {
    const existing = await listProducts();
    let sort = existing.reduce((m, p) => Math.max(m, p.sort_order), 0);
    const batch = writeBatch(db);
    for (const it of valid) {
      const id = uuid();
      sort += 1;
      batch.set(doc(db, 'products', id), {
        id,
        name: String(it.name).trim(),
        category_id: it.category_id ?? null,
        base_price: Math.round(Number(it.base_price)),
        image_url: null,
        active: true,
        sort_order: sort,
      });
    }
    await batch.commit();
    return { added: valid.length };
  } catch (e) {
    throw toDbError(e);
  }
}

// -------------------------------------------------------- modifier groups ---
export async function listModifierGroups(): Promise<ModifierGroup[]> {
  try {
    const [gSnap, oSnap] = await Promise.all([
      getDocs(query(collection(db, 'modifierGroups'), orderBy('sort_order', 'asc'))),
      getDocs(query(collection(db, 'modifierOptions'), orderBy('sort_order', 'asc'))),
    ]);
    const byGroup = new Map<string, ModifierOption[]>();
    for (const d of oSnap.docs) {
      const opt = toModifierOption(d.id, d.data());
      const arr = byGroup.get(opt.group_id) ?? [];
      arr.push(opt);
      byGroup.set(opt.group_id, arr);
    }
    return gSnap.docs.map((d) => toModifierGroup(d.id, d.data(), byGroup.get(d.id) ?? []));
  } catch (e) {
    throw toDbError(e);
  }
}

export async function createModifierOption(
  groupId: string,
  d: { name: string; price_delta: number },
): Promise<ModifierOption> {
  const name = String(d.name ?? '').trim();
  if (!name) throw new DbError('invalid-argument', 'Vui lòng nhập tên tùy chọn.');
  const delta = Math.round(Number(d.price_delta));
  if (!Number.isFinite(delta) || delta < 0) {
    throw new DbError('invalid-argument', 'Phụ thu phải là số không âm.');
  }
  try {
    const groupSnap = await getDoc(doc(db, 'modifierGroups', groupId));
    if (!groupSnap.exists()) throw new DbError('not-found', 'Nhóm tùy chọn không tồn tại.');
    const oSnap = await getDocs(
      query(collection(db, 'modifierOptions'), where('group_id', '==', groupId)),
    );
    const maxSort = oSnap.docs.reduce(
      (m, x) => Math.max(m, Number(x.data().sort_order ?? 0)),
      0,
    );
    const id = uuid();
    const data = {
      id,
      group_id: groupId,
      name,
      price_delta: delta,
      sort_order: maxSort + 1,
      active: true,
    };
    await setDoc(doc(db, 'modifierOptions', id), data);
    return toModifierOption(id, data);
  } catch (e) {
    throw toDbError(e);
  }
}

export async function updateModifierOption(
  id: string,
  patch: { name?: string; price_delta?: number; active?: boolean },
): Promise<void> {
  const data: Record<string, unknown> = {};
  if (patch.name !== undefined) {
    const trimmed = String(patch.name).trim();
    if (!trimmed) throw new DbError('invalid-argument', 'Tên tùy chọn không được để trống.');
    data.name = trimmed;
  }
  if (patch.price_delta !== undefined) {
    const delta = Math.round(Number(patch.price_delta));
    if (!Number.isFinite(delta) || delta < 0) {
      throw new DbError('invalid-argument', 'Phụ thu phải là số không âm.');
    }
    data.price_delta = delta;
  }
  if (patch.active !== undefined) data.active = patch.active;
  if (Object.keys(data).length === 0) return;
  try {
    await updateDoc(doc(db, 'modifierOptions', id), data);
  } catch (e) {
    throw toDbError(e);
  }
}

// Xóa hẳn một lựa chọn (VD: topping). Đơn hàng cũ không bị ảnh hưởng vì đã lưu tên/giá riêng.
export async function deleteModifierOption(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'modifierOptions', id));
  } catch (e) {
    throw toDbError(e);
  }
}

// -------------------------------------------------------- payment methods ---
const SYSTEM_METHOD_IDS = ['cash', 'transfer', 'debt'];

const KIND_LABEL: Record<PaymentMethodKind, string> = {
  cash: 'Tiền mặt',
  transfer: 'Chuyển khoản',
  debt: 'Ghi nợ',
};

export function paymentKindLabel(kind: PaymentMethodKind): string {
  return KIND_LABEL[kind] ?? kind;
}

// Tạo 3 phương thức mặc định nếu collection còn trống.
// Đồng thời chuyển cấu hình ngân hàng cũ (settings bank_*) sang phương thức chuyển khoản.
export async function ensurePaymentMethodsSeeded(): Promise<void> {
  try {
    const snap = await getDocs(query(collection(db, 'payment_methods'), limit(1)));
    if (!snap.empty) return;
    const settings = await getSettings();
    const batch = writeBatch(db);
    const defaults: Array<Omit<PaymentMethodDef, 'active'>> = [
      {
        id: 'cash', name: 'Tiền mặt', kind: 'cash', icon: '💵',
        bank_bin: null, bank_account: null, bank_account_name: null, sort_order: 1,
      },
      {
        id: 'transfer', name: 'Chuyển khoản', kind: 'transfer', icon: '📱',
        bank_bin: settings.bank_bin || null,
        bank_account: settings.bank_account || null,
        bank_account_name: settings.bank_account_name || null,
        sort_order: 2,
      },
      {
        id: 'debt', name: 'Ghi nợ', kind: 'debt', icon: '📒',
        bank_bin: null, bank_account: null, bank_account_name: null, sort_order: 3,
      },
    ];
    for (const m of defaults) {
      batch.set(doc(db, 'payment_methods', m.id), { ...m, active: true });
    }
    await batch.commit();
  } catch (e) {
    throw toDbError(e);
  }
}

export async function listPaymentMethods(activeOnly = true): Promise<PaymentMethodDef[]> {
  try {
    await ensurePaymentMethodsSeeded();
    const snap = await getDocs(collection(db, 'payment_methods'));
    const all = snap.docs.map((d) => toPaymentMethod(d.id, d.data()));
    const filtered = activeOnly ? all.filter((m) => m.active) : all;
    filtered.sort((a, b) => a.sort_order - b.sort_order || a.name.localeCompare(b.name, 'vi'));
    return filtered;
  } catch (e) {
    throw toDbError(e);
  }
}

export async function createPaymentMethod(d: {
  name: string;
  kind: PaymentMethodKind;
  icon?: string;
  bank_bin?: string | null;
  bank_account?: string | null;
  bank_account_name?: string | null;
}): Promise<PaymentMethodDef> {
  const name = String(d.name ?? '').trim();
  if (!name) throw new DbError('invalid-argument', 'Vui lòng nhập tên phương thức.');
  if (d.kind !== 'cash' && d.kind !== 'transfer' && d.kind !== 'debt') {
    throw new DbError('invalid-argument', 'Loại phương thức không hợp lệ.');
  }
  try {
    const snap = await getDocs(collection(db, 'payment_methods'));
    const sort_order = snap.docs.reduce((mx, x) => Math.max(mx, Number(x.data().sort_order ?? 0)), 0) + 1;
    const id = uuid();
    const data = {
      id,
      name,
      kind: d.kind,
      icon: String(d.icon ?? '').trim() || '💳',
      bank_bin: d.bank_bin?.trim() || null,
      bank_account: d.bank_account?.trim() || null,
      bank_account_name: d.bank_account_name?.trim() || null,
      active: true,
      sort_order,
    };
    await setDoc(doc(db, 'payment_methods', id), data);
    return { ...data };
  } catch (e) {
    throw toDbError(e);
  }
}

export async function updatePaymentMethod(
  id: string,
  patch: Partial<Pick<PaymentMethodDef, 'name' | 'kind' | 'icon' | 'bank_bin' | 'bank_account' | 'bank_account_name' | 'active' | 'sort_order'>>,
): Promise<void> {
  const data: Record<string, unknown> = {};
  if (patch.name !== undefined) {
    const name = String(patch.name).trim();
    if (!name) throw new DbError('invalid-argument', 'Tên phương thức không được để trống.');
    data.name = name;
  }
  if (patch.kind !== undefined) {
    if (patch.kind !== 'cash' && patch.kind !== 'transfer' && patch.kind !== 'debt') {
      throw new DbError('invalid-argument', 'Loại phương thức không hợp lệ.');
    }
    data.kind = patch.kind;
  }
  if (patch.icon !== undefined) data.icon = String(patch.icon).trim() || '💳';
  if (patch.bank_bin !== undefined) data.bank_bin = patch.bank_bin?.trim() || null;
  if (patch.bank_account !== undefined) data.bank_account = patch.bank_account?.trim() || null;
  if (patch.bank_account_name !== undefined) data.bank_account_name = patch.bank_account_name?.trim() || null;
  if (patch.active !== undefined) data.active = patch.active === true;
  if (patch.sort_order !== undefined) data.sort_order = Number(patch.sort_order) || 0;
  if (Object.keys(data).length === 0) return;
  try {
    await updateDoc(doc(db, 'payment_methods', id), data);
  } catch (e) {
    throw toDbError(e);
  }
}

// Phương thức hệ thống (cash/transfer/debt) chỉ được ẩn, không được xóa hẳn.
export async function deletePaymentMethod(id: string): Promise<void> {
  if (SYSTEM_METHOD_IDS.includes(id)) {
    throw new DbError('invalid-argument', 'Phương thức mặc định chỉ có thể Ẩn, không xóa được.');
  }
  try {
    await deleteDoc(doc(db, 'payment_methods', id));
  } catch (e) {
    throw toDbError(e);
  }
}

export function isSystemPaymentMethod(id: string): boolean {
  return SYSTEM_METHOD_IDS.includes(id);
}

// ------------------------------------------------------------------ orders ---
export interface CreateOrderItemInput {
  productId: string;
  qty: number;
  modifierOptionIds: string[];
  note?: string;
}

export interface CreateOrderInput {
  clientUuid: string;
  customerId: string | null;
  items: CreateOrderItemInput[];
  paymentMethod: PaymentMethod;
  amountReceived?: number | null;
  note?: string | null;
  warehouseId?: string | null; // kho trừ tồn khi bán (multi-kho); null = kho mặc định
}

/**
 * Chọn kho để trừ tồn khi bán: ưu tiên kho POS đang chọn, kiểm tra quyền,
 * rớt về kho mặc định. Chủ quán chưa có kho nào → tự tạo kho mặc định.
 */
async function resolveSaleWarehouse(
  requestedId: string | null,
): Promise<{ warehouseId: string; warehouseName: string }> {
  const me = await getMyProfile();
  const privileged = roleLevel(me.role) >= 3; // Chủ quán + Quản lý dùng mọi kho
  let ws = await listWarehouses();
  if (privileged && ws.length === 0) ws = await ensureWarehousesSeeded();
  const allowed = privileged ? ws : ws.filter((w) => me.warehouse_ids.includes(w.id));
  if (allowed.length === 0) {
    throw new DbError(
      'permission-denied',
      'Tài khoản chưa được gán kho nào. Nhờ chủ quán vào Cài đặt → Nhân viên để gán kho.',
    );
  }
  const pick =
    (requestedId ? allowed.find((w) => w.id === requestedId) : undefined) ??
    allowed.find((w) => w.is_default) ??
    allowed[0];
  return { warehouseId: pick.id, warehouseName: pick.name };
}

interface CatalogMaps {
  products: Map<string, Record<string, unknown>>;
  groups: Map<string, Record<string, unknown>>;
  options: Map<string, Record<string, unknown>>;
}

async function loadCatalog(): Promise<CatalogMaps> {
  const [pSnap, gSnap, oSnap] = await Promise.all([
    getDocs(collection(db, 'products')),
    getDocs(collection(db, 'modifierGroups')),
    getDocs(collection(db, 'modifierOptions')),
  ]);
  return {
    products: new Map(pSnap.docs.map((d) => [d.id, d.data()])),
    groups: new Map(gSnap.docs.map((d) => [d.id, d.data()])),
    options: new Map(oSnap.docs.map((d) => [d.id, d.data()])),
  };
}

// Tính giá client-side — mirror backend lib/pricing.js#calculateOrderPricing.
// Snapshot mỗi dòng gồm option_id (theo schema orders.items của bản Firebase).
function priceOrderLines(items: CreateOrderItemInput[], catalog: CatalogMaps) {
  const lines = items.map((item, idx) => {
    const n = idx + 1;
    const product = catalog.products.get(item.productId);
    if (!product) throw new DbError('invalid-argument', `Món thứ ${n}: sản phẩm không tồn tại.`);
    if (product.active === false) {
      throw new DbError('invalid-argument', `Món thứ ${n}: "${String(product.name)}" hiện không bán.`);
    }
    const qty = Number(item.qty);
    if (!Number.isInteger(qty) || qty < 1 || qty > 99) {
      throw new DbError('invalid-argument', `Món thứ ${n}: số lượng phải là số nguyên từ 1 đến 99.`);
    }
    const optionIds = Array.isArray(item.modifierOptionIds) ? item.modifierOptionIds : [];
    const byGroup = new Map<string, { group: Record<string, unknown>; opts: Record<string, unknown>[] }>();
    for (const optId of optionIds) {
      const opt = catalog.options.get(optId) as (Record<string, unknown> & { id?: string }) | undefined;
      if (!opt) throw new DbError('invalid-argument', `Món thứ ${n}: tùy chọn không tồn tại.`);
      if (opt.active === false) {
        throw new DbError('invalid-argument', `Món thứ ${n}: tùy chọn "${String(opt.name)}" đã ngừng dùng.`);
      }
      const group = catalog.groups.get(String(opt.group_id));
      if (!group) throw new DbError('invalid-argument', `Món thứ ${n}: nhóm tùy chọn không tồn tại.`);
      if (group.active === false) {
        throw new DbError('invalid-argument', `Món thứ ${n}: nhóm "${String(group.name)}" đã ngừng dùng.`);
      }
      const gid = String(opt.group_id);
      const entry = byGroup.get(gid) ?? { group, opts: [] };
      entry.opts.push({ ...opt, id: optId });
      byGroup.set(gid, entry);
    }
    const modifiers: SelectedModifier[] = [];
    for (const { group, opts } of byGroup.values()) {
      if (group.selection_type === 'single' && opts.length > 1) {
        throw new DbError(
          'invalid-argument',
          `Món thứ ${n}: nhóm "${String(group.name)}" chỉ được chọn 1 tùy chọn.`,
        );
      }
      for (const opt of opts) {
        modifiers.push({
          option_id: String(opt.id ?? ''),
          group: String(group.name),
          option: String(opt.name),
          price_delta: Number(opt.price_delta) || 0,
        });
      }
    }
    // Nhóm bắt buộc (VD: Size) phải được chọn — riêng group Size phải chọn đúng 1 option
    for (const [gid, group] of catalog.groups) {
      if (group.required === true && group.active !== false && !byGroup.has(gid)) {
        throw new DbError('invalid-argument', `Món thứ ${n}: Vui lòng chọn ${String(group.name)}.`);
      }
    }
    const unit_price =
      Number(product.base_price) + modifiers.reduce((s, m) => s + m.price_delta, 0);
    const line_total = unit_price * qty;
    return {
      id: uuid(),
      product_id: String(product.id ?? item.productId),
      product_name: String(product.name),
      qty,
      unit_price,
      cost_price: Math.max(0, Math.round(Number(product.cost_price) || 0)),
      recipe: sanitizeRecipe(product.recipe),
      modifiers,
      line_total,
      note: typeof item.note === 'string' && item.note ? item.note.slice(0, 500) : undefined,
    };
  });
  const subtotal = lines.reduce((s, l) => s + l.line_total, 0);
  return { lines, subtotal, discount: 0, total: subtotal };
}

// Kiểm tra tiền mặt — mirror backend lib/pricing.js#calculateChange
function checkCash(kind: PaymentMethodKind, total: number, amountReceived?: number | null) {
  if (kind === 'cash') {
    const got = Number(amountReceived);
    if (!Number.isInteger(got) || got <= 0) {
      throw new DbError('invalid-argument', 'Tiền mặt: vui lòng nhập số tiền khách đưa.');
    }
    if (got < total) {
      throw new DbError(
        'invalid-argument',
        `Tiền khách đưa (${got}) nhỏ hơn tổng tiền (${total}).`,
      );
    }
    return { amount_received: got, change_amount: got - total };
  }
  return { amount_received: null, change_amount: null };
}

export async function createOrder(input: CreateOrderInput): Promise<Order> {
  const clientUuid = String(input.clientUuid ?? '').trim();
  if (!clientUuid) throw new DbError('invalid-argument', 'Thiếu clientUuid (mã chống trùng đơn).');
  if (clientUuid.length > 100) throw new DbError('invalid-argument', 'clientUuid quá dài.');
  if (!Array.isArray(input.items) || input.items.length === 0) {
    throw new DbError('invalid-argument', 'Đơn hàng phải có ít nhất một món.');
  }
  if (input.items.length > 50) {
    throw new DbError('invalid-argument', 'Đơn hàng vượt quá 50 dòng món.');
  }
  const methodId = String(input.paymentMethod ?? '').trim();
  if (!methodId) throw new DbError('invalid-argument', 'Thiếu phương thức thanh toán.');

  try {
    // 1. Idempotent: đơn đã tồn tại → trả về luôn
    const orderRef = doc(db, 'orders', clientUuid);
    const existing = await getDoc(orderRef);
    if (existing.exists()) {
      const o = orderFromDoc(existing);
      if (o) return o;
    }

    // 2. Tính giá client-side từ catalog (không tin giá client gửi) + kiểm tra phương thức
    const [catalog, methods] = await Promise.all([loadCatalog(), listPaymentMethods(true)]);
    const method = methods.find((m) => m.id === methodId);
    if (!method) throw new DbError('invalid-argument', 'Phương thức thanh toán không hợp lệ hoặc đã bị ẩn.');
    const kind = method.kind;
    const pricing = priceOrderLines(input.items, catalog);
    const cash = checkCash(kind, pricing.total, input.amountReceived);
    const business_date = todayVN();
    const createdBy = auth.currentUser?.uid ?? null;
    const note = typeof input.note === 'string' && input.note ? input.note.slice(0, 1000) : null;
    const customerId = input.customerId ?? null;
    if (kind === 'debt' && !customerId) {
      throw new DbError('invalid-argument', 'Ghi nợ cần chọn khách hàng cho đơn này.');
    }

    // Kho bán: trừ tồn ở kho POS đang chọn (kiểm tra quyền, rớt về kho mặc định)
    const { warehouseId, warehouseName } = await resolveSaleWarehouse(
      typeof input.warehouseId === 'string' ? input.warehouseId : null,
    );

    // 3. Transaction: mã đơn A001 + ghi đơn + tích tem + cộng công nợ + trừ kho
    // NGUYÊN TẮC Firestore: mọi tx.get() phải xong trước mọi tx.set()/update()/delete().
    await runTransaction(db, async (tx) => {
      // ---- PHASE 1: đọc ----
      // Đua idempotency trong transaction: đơn đã có → bỏ qua ghi
      const oSnap = await tx.get(orderRef);
      if (oSnap.exists()) return;

      const counterRef = doc(db, 'counters', business_date);
      const cSnap = await tx.get(counterRef);
      const next = cSnap.exists() ? Number((cSnap.data() as Record<string, unknown>).last ?? 0) + 1 : 1;
      const code = 'A' + String(next).padStart(3, '0');

      let stampUpdate: { stamps: number; reward_available?: boolean } | null = null;
      let debtAfter = -1;
      if (customerId) {
        const custRef = doc(db, 'customers', customerId);
        const custSnap = await tx.get(custRef);
        if (!custSnap.exists()) throw new DbError('invalid-argument', 'Khách hàng không tồn tại.');
        const setSnap = await tx.get(doc(db, 'settings', 'stamps_target'));
        const target = Number(setSnap.exists() ? (setSnap.data() as Record<string, unknown>).value : 9) || 9;
        const stamps = Number((custSnap.data() as Record<string, unknown>).stamps ?? 0) + 1;
        stampUpdate = stamps >= target ? { stamps: 0, reward_available: true } : { stamps };
        if (kind === 'debt') debtAfter = Number((custSnap.data() as Record<string, unknown>).debt ?? 0) + pricing.total;
      }

      // Tồn kho: đọc trước toàn bộ mức tồn tại kho bán
      const needs = calcNeeds(pricing.lines);
      const stockState = new Map<string, StockState>();
      if (needs.size > 0) {
        const ids = [...needs.keys()];
        const [lSnaps, iSnaps] = await Promise.all([
          Promise.all(ids.map((ingId) => tx.get(doc(db, 'stock_levels', stockLevelId(warehouseId, ingId))))),
          Promise.all(ids.map((ingId) => tx.get(doc(db, 'ingredients', ingId)))),
        ]);
        ids.forEach((ingId, i) => {
          const lSnap = lSnaps[i];
          const iSnap = iSnaps[i];
          if (!iSnap.exists()) return; // nguyên liệu đã bị xóa → bỏ qua
          const lData = (lSnap.exists() ? lSnap.data() : {}) as Record<string, unknown>;
          stockState.set(ingId, {
            stock: Number(lData.stock ?? 0),
            name:
              String(lData.ingredient_name ?? '') ||
              String((iSnap.data() as Record<string, unknown>).name ?? ''),
          });
        });
      }

      // ---- PHASE 2: ghi ----
      if (cSnap.exists()) tx.update(counterRef, { last: next });
      else tx.set(counterRef, { last: 1 });

      tx.set(orderRef, {
        id: clientUuid,
        client_uuid: clientUuid,
        code,
        business_date,
        customer_id: customerId,
        status: 'new',
        payment_method: method.id,
        payment_method_name: method.name,
        warehouse_id: warehouseId,
        warehouse_name: warehouseName,
        subtotal: pricing.subtotal,
        discount: pricing.discount,
        total: pricing.total,
        amount_received: cash.amount_received,
        change_amount: cash.change_amount,
        note,
        created_by: createdBy,
        created_at: serverTimestamp(),
        items: pricing.lines.map((l) => ({
          id: l.id,
          order_id: clientUuid,
          product_id: l.product_id,
          product_name: l.product_name,
          qty: l.qty,
          unit_price: l.unit_price,
          cost_price: l.cost_price,
          recipe: l.recipe,
          modifiers: l.modifiers,
          line_total: l.line_total,
          ...(l.note ? { note: l.note } : {}),
        })),
      });

      // Trừ tồn kho nguyên liệu theo định lượng món tại kho bán
      // (cho phép tồn âm → cảnh báo ở màn Tồn kho)
      writeStockMoves(tx, {
        warehouseId,
        warehouseName,
        needs,
        state: stockState,
        sign: -1,
        note: `Bán đơn ${code}`,
        ref_type: 'order',
        ref_id: clientUuid,
        createdBy,
      });

      if (customerId) {
        const custUpdate: Record<string, unknown> = {};
        if (stampUpdate) Object.assign(custUpdate, stampUpdate);
        if (debtAfter >= 0) {
          custUpdate.debt = debtAfter;
          const logRef = doc(collection(db, 'customers', customerId, 'debt_logs'));
          tx.set(logRef, {
            id: logRef.id,
            amount: pricing.total,
            balance_after: debtAfter,
            note: `Ghi nợ đơn ${code}`,
            created_by: createdBy,
            created_at: serverTimestamp(),
          });
        }
        if (Object.keys(custUpdate).length > 0) {
          tx.update(doc(db, 'customers', customerId), custUpdate);
        }
      }

      // Sổ quỹ: đơn đã thu tiền (tiền mặt/chuyển khoản) → tự ghi khoản thu "Doanh thu bán hàng".
      // Đơn ghi nợ chưa thu tiền nên KHÔNG ghi. Id doc fund cố định theo đơn để idempotent.
      // Đơn cũ trước tính năng này không backfill.
      if (kind === 'cash' || kind === 'transfer') {
        const fundRef = doc(db, 'cashbook_entries', `fund_${clientUuid}`);
        tx.set(fundRef, {
          id: fundRef.id,
          type: 'thu',
          amount: pricing.total,
          note: 'Doanh thu bán hàng',
          category: 'Bán hàng',
          fund_id: method.id, // mỗi phương thức thanh toán (trừ ghi nợ) là một quỹ
          ref_type: 'order',
          ref_id: clientUuid,
          ref_code: code,
          method: kind,
          created_by: createdBy,
          created_at: serverTimestamp(),
        });
      }
    });

    // 4. Đọc lại → Timestamp → ISO string
    const after = await getDoc(orderRef);
    const order = orderFromDoc(after);
    if (!order) throw new DbError('unknown', 'Không đọc được đơn vừa tạo.');
    return order;
  } catch (e) {
    throw toDbError(e);
  }
}

export async function getOrder(id: string): Promise<Order | null> {
  try {
    return orderFromDoc(await getDoc(doc(db, 'orders', id)));
  } catch (e) {
    throw toDbError(e);
  }
}

export async function listOrdersByDate(date: string, limitN?: number): Promise<Order[]> {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    throw new DbError('invalid-argument', 'Tham số date phải có dạng YYYY-MM-DD.');
  }
  const n = Math.min(Math.max(limitN ?? 100, 1), 500);
  try {
    const snap = await getDocs(
      query(
        collection(db, 'orders'),
        where('business_date', '==', date),
        orderBy('created_at', 'desc'),
        limit(n),
      ),
    );
    return snap.docs
      .map((d) => orderFromDoc(d))
      .filter((o): o is Order => o !== null);
  } catch (e) {
    throw toDbError(e);
  }
}

// new → preparing → ready → done; bất kỳ trạng thái nào (trừ done/cancelled) → cancelled
const ORDER_FLOW: Record<OrderStatus, OrderStatus[]> = {
  new: ['preparing'],
  preparing: ['ready'],
  ready: ['done'],
  done: [],
  cancelled: [],
};

export async function updateOrderStatus(id: string, status: OrderStatus): Promise<Order> {
  const valid: OrderStatus[] = ['new', 'preparing', 'ready', 'done', 'cancelled'];
  if (!valid.includes(status)) {
    throw new DbError('invalid-argument', `Trạng thái "${status}" không hợp lệ.`);
  }
  try {
    const ref = doc(db, 'orders', id);
    const snap = await getDoc(ref);
    const current = orderFromDoc(snap);
    if (!current) throw new DbError('not-found', 'Đơn hàng không tồn tại.');
    const from = current.status;
    if (from !== status) {
      const forwardOk = (ORDER_FLOW[from] ?? []).includes(status);
      const cancelOk = status === 'cancelled' && from !== 'done' && from !== 'cancelled';
      if (!forwardOk && !cancelOk) {
        throw new DbError(
          'invalid-argument',
          `Không thể chuyển đơn từ trạng thái "${from}" sang "${status}".`,
        );
      }
      if (status === 'cancelled') {
        // Hủy đơn → hoàn lại tồn kho đã trừ lúc bán, về đúng kho của đơn.
        // Đơn cũ chưa có kho → hoàn về kho mặc định hiện tại.
        const wid = current?.warehouse_id ?? (await getDefaultWarehouseId());
        const wName = current?.warehouse_name ?? null;
        await runTransaction(db, async (tx) => {
          // PHASE 1: đọc
          const s = await tx.get(ref);
          const o = orderFromDoc(s);
          if (!o) throw new DbError('not-found', 'Không tìm thấy đơn hàng.');
          if (o.status === 'cancelled') return;
          const restoreWid = o.warehouse_id ?? wid;
          const { needs, state } = restoreWid
            ? await readStockState(tx, o, restoreWid)
            : { needs: new Map<string, number>(), state: new Map<string, StockState>() };
          // PHASE 2: ghi
          tx.update(ref, { status });
          if (restoreWid) {
            writeStockMoves(tx, {
              warehouseId: restoreWid,
              warehouseName: o.warehouse_name ?? wName,
              needs,
              state,
              sign: 1,
              note: `Hủy đơn ${o.code}`,
              ref_type: 'order',
              ref_id: o.id,
              createdBy: auth.currentUser?.uid ?? null,
            });
          }
        });
      } else {
        await updateDoc(ref, { status });
      }
    }
    const after = orderFromDoc(await getDoc(ref));
    if (!after) throw new DbError('not-found', 'Đơn hàng không tồn tại.');
    return after;
  } catch (e) {
    throw toDbError(e);
  }
}

// --------------------------------------------------------------- đơn hàng ---
export interface ListOrdersOpts {
  from: string; // YYYY-MM-DD
  to: string; // YYYY-MM-DD
  limitN?: number;
}

/** Liệt kê đơn theo khoảng ngày (mới nhất trước). Lọc theo mã đơn/khách làm ở client. */
export async function listOrders(opts: ListOrdersOpts): Promise<Order[]> {
  const { from, to } = opts;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(from) || !/^\d{4}-\d{2}-\d{2}$/.test(to)) {
    throw new DbError('invalid-argument', 'Khoảng ngày không hợp lệ.');
  }
  const n = Math.min(Math.max(opts.limitN ?? 300, 1), 1000);
  try {
    const snap = await getDocs(
      query(
        collection(db, 'orders'),
        where('business_date', '>=', from),
        where('business_date', '<=', to),
        orderBy('business_date', 'desc'),
        limit(n),
      ),
    );
    const list = snap.docs
      .map((d) => orderFromDoc(d))
      .filter((o): o is Order => o !== null);
    list.sort((a, b) => (a.created_at < b.created_at ? 1 : -1));
    return list;
  } catch (e) {
    throw toDbError(e);
  }
}

/**
 * Sửa đơn đã bán — CHỈ cho sửa ghi chú + khách hàng (không sửa món/giá để báo cáo không sai).
 * Rules phía server cũng chỉ cho phép 3 field: status, note, customer_id.
 */
export async function updateOrderMeta(
  id: string,
  patch: { note?: string | null; customerId?: string | null },
): Promise<Order> {
  const data: Record<string, unknown> = {};
  if (patch.note !== undefined) {
    const n = typeof patch.note === 'string' ? patch.note.trim() : '';
    data.note = n ? n.slice(0, 1000) : null;
  }
  if (patch.customerId !== undefined) {
    const cid = patch.customerId ? String(patch.customerId) : null;
    if (cid) {
      const cSnap = await getDoc(doc(db, 'customers', cid));
      if (!cSnap.exists()) throw new DbError('not-found', 'Khách hàng không tồn tại.');
    }
    data.customer_id = cid;
  }
  if (Object.keys(data).length === 0) {
    const cur = await getOrder(id);
    if (!cur) throw new DbError('not-found', 'Đơn hàng không tồn tại.');
    return cur;
  }
  try {
    await updateDoc(doc(db, 'orders', id), data);
    const after = await getOrder(id);
    if (!after) throw new DbError('not-found', 'Đơn hàng không tồn tại.');
    return after;
  } catch (e) {
    throw toDbError(e);
  }
}

/**
 * Xóa đơn đã bán — chỉ chủ quán (rules + UI đều chặn nhân viên).
 * - Đơn ghi nợ → hoàn công nợ tương ứng (ghi log "Hoàn nợ do xóa đơn A001").
 * - Xóa luôn khoản quỹ tự động của đơn (cashbook_entries/fund_<orderId>).
 * - Tem tích điểm KHÔNG hoàn (không có đường hoàn sạch khi đã đổi thưởng/reset tem).
 */
export async function deleteOrder(id: string): Promise<void> {
  // Đơn cũ chưa có kho → hoàn về kho mặc định hiện tại (đọc trước transaction)
  const fallbackWid = await getDefaultWarehouseId();
  try {
    await runTransaction(db, async (tx) => {
      // ---- PHASE 1: đọc ----
      const orderRef = doc(db, 'orders', id);
      const oSnap = await tx.get(orderRef);
      const order = oSnap.exists() ? orderFromDoc(oSnap) : null;
      if (!order) throw new DbError('not-found', 'Đơn hàng không tồn tại.');

      // Hoàn công nợ nếu đơn ghi nợ
      const methodSnap = await tx.get(doc(db, 'payment_methods', order.payment_method));
      const kind = methodSnap.exists() ? String((methodSnap.data() as Record<string, unknown>).kind ?? '') : '';
      let custRef: ReturnType<typeof doc> | null = null;
      let cSnap: Awaited<ReturnType<typeof tx.get>> | null = null;
      if (kind === 'debt' && order.customer_id) {
        custRef = doc(db, 'customers', order.customer_id);
        cSnap = await tx.get(custRef);
      }

      // Tồn kho cần hoàn (đọc trước)
      const restoreWid = order.warehouse_id ?? fallbackWid;
      const { needs, state } = restoreWid
        ? await readStockState(tx, order, restoreWid)
        : { needs: new Map<string, number>(), state: new Map<string, StockState>() };

      // ---- PHASE 2: ghi ----
      if (custRef && cSnap && cSnap.exists()) {
        const curDebt = Number((cSnap.data() as Record<string, unknown>).debt ?? 0);
        const reverse = Math.min(order.total, Math.max(curDebt, 0));
        if (reverse > 0) {
          const next = curDebt - reverse;
          tx.update(custRef, { debt: next });
          const logRef = doc(collection(db, 'customers', order.customer_id as string, 'debt_logs'));
          tx.set(logRef, {
            id: logRef.id,
            amount: -reverse,
            balance_after: next,
            note: `Hoàn nợ do xóa đơn ${order.code}`,
            created_by: auth.currentUser?.uid ?? null,
            created_at: serverTimestamp(),
          });
        }
      }

      // Xóa khoản quỹ tự động của đơn (nếu có)
      tx.delete(doc(db, 'cashbook_entries', `fund_${order.id}`));

      // Hoàn lại tồn kho đã trừ lúc bán, về đúng kho của đơn
      if (restoreWid) {
        writeStockMoves(tx, {
          warehouseId: restoreWid,
          warehouseName: order.warehouse_name,
          needs,
          state,
          sign: 1,
          note: `Xóa đơn ${order.code}`,
          ref_type: 'order',
          ref_id: order.id,
          createdBy: auth.currentUser?.uid ?? null,
        });
      }

      tx.delete(orderRef);
    });
  } catch (e) {
    throw toDbError(e);
  }
}

// ------------------------------------------------------------- warehouses ---
// Multi-kho: mỗi nguyên liệu có tồn kho RIÊNG theo từng kho (collection stock_levels).
// - warehouses: danh sách kho (chỉ chủ quán quản lý).
// - stock_levels/{warehouseId_ingredientId}: tồn của 1 nguyên liệu tại 1 kho.
//   Nhân viên được đọc/ghi tồn ở các kho mình được gán (users/{uid}.warehouse_ids).
// - Bán hàng trừ kho đang chọn ở POS; hủy/xóa đơn hoàn về đúng kho của đơn đó.

function toWarehouse(id: string, d: Record<string, unknown>): Warehouse {
  return {
    id,
    name: String(d.name ?? 'Kho'),
    note: (d.note as string | null) ?? null,
    is_default: d.is_default === true,
    active: activeOf(d),
    sort_order: Number(d.sort_order ?? 0),
    created_at: tsToIso(d.created_at),
  };
}

/** Id cố định của doc tồn kho: `${warehouseId}_${ingredientId}` — tiện đọc trong transaction. */
export function stockLevelId(warehouseId: string, ingredientId: string): string {
  return `${warehouseId}_${ingredientId}`;
}

/** Danh sách kho (mặc định chỉ kho đang dùng). */
export async function listWarehouses(activeOnly = true): Promise<Warehouse[]> {
  try {
    const snap = await getDocs(
      query(collection(db, 'warehouses'), orderBy('sort_order', 'asc'), limit(100)),
    );
    const all = snap.docs.map((d) => toWarehouse(d.id, d.data() as Record<string, unknown>));
    return activeOnly ? all.filter((w) => w.active) : all;
  } catch (e) {
    throw toDbError(e);
  }
}

/** Tạo kho mới — chỉ chủ quán (rules). */
export async function createWarehouse(name: string, note?: string | null): Promise<Warehouse> {
  const n = String(name ?? '').trim().slice(0, 60);
  if (!n) throw new DbError('invalid-argument', 'Vui lòng nhập tên kho.');
  try {
    const existing = await listWarehouses(false);
    const maxSort = existing.reduce((m, w) => Math.max(m, w.sort_order), 0);
    const id = uuid();
    const data = {
      id,
      name: n,
      note: typeof note === 'string' && note.trim() ? note.trim().slice(0, 500) : null,
      is_default: existing.length === 0, // kho đầu tiên làm mặc định
      active: true,
      sort_order: maxSort + 1,
      created_at: serverTimestamp(),
    };
    await setDoc(doc(db, 'warehouses', id), data);
    return toWarehouse(id, { ...data, created_at: new Date().toISOString() });
  } catch (e) {
    throw toDbError(e);
  }
}

/** Sửa kho (tên, ghi chú, ẩn/hiện) — chỉ chủ quán (rules). */
export async function updateWarehouse(
  id: string,
  patch: Partial<Pick<Warehouse, 'name' | 'note' | 'active'>>,
): Promise<void> {
  const data: Record<string, unknown> = {};
  if (patch.name !== undefined) {
    const n = String(patch.name ?? '').trim().slice(0, 60);
    if (!n) throw new DbError('invalid-argument', 'Tên kho không được để trống.');
    data.name = n;
  }
  if (patch.note !== undefined) {
    data.note = typeof patch.note === 'string' && patch.note.trim() ? patch.note.trim().slice(0, 500) : null;
  }
  if (patch.active !== undefined) data.active = patch.active;
  if (Object.keys(data).length === 0) return;
  try {
    await updateDoc(doc(db, 'warehouses', id), data);
  } catch (e) {
    throw toDbError(e);
  }
}

/** Đặt kho bán hàng mặc định (trừ kho này khi bán ở POS) — chỉ chủ quán. */
export async function setDefaultWarehouse(id: string): Promise<void> {
  try {
    const ws = await listWarehouses(false);
    const target = ws.find((w) => w.id === id && w.active);
    if (!target) throw new DbError('invalid-argument', 'Kho không tồn tại hoặc đang ẩn.');
    const batch = writeBatch(db);
    for (const w of ws) {
      if ((w.is_default && w.id !== id) || (!w.is_default && w.id === id)) {
        batch.update(doc(db, 'warehouses', w.id), { is_default: w.id === id });
      }
    }
    await batch.commit();
    await setSetting('default_warehouse', id);
  } catch (e) {
    throw toDbError(e);
  }
}

/** Kho mặc định để trừ tồn khi bán: settings → cờ is_default → kho đầu tiên. */
export async function getDefaultWarehouseId(): Promise<string | null> {
  try {
    const [s, ws] = await Promise.all([getSettings(), listWarehouses(false)]);
    const active = ws.filter((w) => w.active);
    const fromSettings = (s.default_warehouse || '').trim();
    if (fromSettings && active.some((w) => w.id === fromSettings)) return fromSettings;
    return active.find((w) => w.is_default)?.id ?? active[0]?.id ?? null;
  } catch {
    return null;
  }
}

/**
 * Khởi tạo kho lần đầu — chỉ chủ quán gọi.
 * Tạo "Kho quầy" làm mặc định và chuyển tồn kho chung cũ của từng
 * nguyên liệu vào kho này (giữ nguyên số liệu, không mất dữ liệu).
 */
export async function ensureWarehousesSeeded(): Promise<Warehouse[]> {
  try {
    const existing = await listWarehouses(false);
    if (existing.length > 0) return existing;
    const ings = await listIngredients(false);
    const wid = uuid();
    const writes: Array<{ ref: ReturnType<typeof doc>; data: Record<string, unknown> }> = [
      {
        ref: doc(db, 'warehouses', wid),
        data: {
          id: wid,
          name: 'Kho quầy',
          note: 'Kho mặc định',
          is_default: true,
          active: true,
          sort_order: 1,
          created_at: serverTimestamp(),
        },
      },
    ];
    for (const ing of ings) {
      writes.push({
        ref: doc(db, 'stock_levels', stockLevelId(wid, ing.id)),
        data: {
          warehouse_id: wid,
          ingredient_id: ing.id,
          ingredient_name: ing.name,
          stock: ing.stock,
        },
      });
    }
    for (let i = 0; i < writes.length; i += 400) {
      const batch = writeBatch(db);
      for (const w of writes.slice(i, i + 400)) batch.set(w.ref, w.data);
      await batch.commit();
    }
    await setSetting('default_warehouse', wid);
    return listWarehouses(false);
  } catch (e) {
    throw toDbError(e);
  }
}

// ------------------------------------------------------- phân quyền kho ---
export interface MyProfile {
  role: RoleKey;
  warehouse_ids: string[];
}

/** Hồ sơ quyền của tài khoản đang đăng nhập (vai trò + các kho được gán). */
export async function getMyProfile(): Promise<MyProfile> {
  const uid = auth.currentUser?.uid;
  if (!uid) throw new DbError('unauthenticated', 'Chưa đăng nhập.');
  try {
    const snap = await getDoc(doc(db, 'users', uid));
    const d = (snap.data() ?? {}) as Record<string, unknown>;
    return {
      role: normalizeRole(d.role),
      warehouse_ids: Array.isArray(d.warehouse_ids) ? d.warehouse_ids.map((x) => String(x)) : [],
    };
  } catch (e) {
    throw toDbError(e);
  }
}

function toUser(id: string, d: Record<string, unknown>): User {
  return {
    id,
    email: String(d.email ?? ''),
    full_name: String(d.full_name ?? ''),
    role: normalizeRole(d.role),
    warehouse_ids: Array.isArray(d.warehouse_ids) ? d.warehouse_ids.map((x) => String(x)) : [],
  };
}

/** Danh sách tài khoản — chỉ chủ quán (rules). */
export async function listUsers(): Promise<User[]> {
  try {
    const snap = await getDocs(query(collection(db, 'users'), limit(200)));
    const all = snap.docs.map((d) => toUser(d.id, d.data() as Record<string, unknown>));
    all.sort((a, b) => a.full_name.localeCompare(b.full_name, 'vi'));
    return all;
  } catch (e) {
    throw toDbError(e);
  }
}

/** Đổi vai trò nhân viên (Quản lý/Thu ngân/Bán hàng) — chỉ chủ quán (rules). */
export async function updateUserRole(uid: string, role: RoleKey): Promise<void> {
  const r = normalizeRole(role);
  if (r === 'owner') throw new DbError('invalid-argument', 'Không thể gán vai trò chủ quán ở đây.');
  try {
    await updateDoc(doc(db, 'users', uid), { role: r });
  } catch (e) {
    throw toDbError(e);
  }
}

/** Gán các kho cho tài khoản nhân viên — chỉ chủ quán (rules). */
export async function updateUserWarehouses(uid: string, warehouseIds: string[]): Promise<void> {
  try {
    const ws = await listWarehouses(false);
    const valid = new Set(ws.map((w) => w.id));
    const clean = [...new Set(warehouseIds.map(String))].filter((id) => valid.has(id));
    await updateDoc(doc(db, 'users', uid), { warehouse_ids: clean });
  } catch (e) {
    throw toDbError(e);
  }
}

// ------------------------------------------------------------- ingredients ---
function toIngredient(id: string, d: Record<string, unknown>): Ingredient {
  return {
    id,
    name: String(d.name ?? ''),
    unit: String(d.unit ?? '').trim().slice(0, 20),
    stock: Number(d.stock ?? 0), // tồn chung cũ — chỉ dùng khi migrate sang multi-kho
    min_stock: Math.max(0, Number(d.min_stock ?? 0) || 0),
    cost_per_unit: Math.max(0, Math.round(Number(d.cost_per_unit ?? 0)) || 0),
    active: activeOf(d),
    sort_order: Number(d.sort_order ?? 0),
  };
}

function toStockLog(id: string, d: Record<string, unknown>): StockLog {
  const rt = d.ref_type;
  return {
    id,
    warehouse_id: (d.warehouse_id as string | null) ?? null,
    warehouse_name: (d.warehouse_name as string | null) ?? null,
    ingredient_id: String(d.ingredient_id ?? ''),
    ingredient_name: String(d.ingredient_name ?? ''),
    change: Number(d.change ?? 0),
    balance_after: Number(d.balance_after ?? 0),
    note: (d.note as string | null) ?? null,
    ref_type: rt === 'order' || rt === 'transfer' ? rt : 'manual',
    ref_id: (d.ref_id as string | null) ?? null,
    created_by: (d.created_by as string | null) ?? null,
    created_at: tsToIso(d.created_at),
  };
}

/** Danh mục nguyên liệu (thông tin chung, không gồm tồn kho từng kho). */
export async function listIngredients(activeOnly = false): Promise<Ingredient[]> {
  try {
    const snap = await getDocs(
      query(collection(db, 'ingredients'), orderBy('sort_order', 'asc'), limit(500)),
    );
    const all = snap.docs.map((d) => toIngredient(d.id, d.data() as Record<string, unknown>));
    return activeOnly ? all.filter((i) => i.active) : all;
  } catch (e) {
    throw toDbError(e);
  }
}

/** Nguyên liệu kèm tồn kho tại 1 kho cụ thể (dùng cho màn Tồn kho). */
export async function listWarehouseStock(warehouseId: string): Promise<IngredientWithStock[]> {
  try {
    const [ings, snap] = await Promise.all([
      listIngredients(false),
      getDocs(
        query(collection(db, 'stock_levels'), where('warehouse_id', '==', warehouseId), limit(1000)),
      ),
    ]);
    const lv = new Map<string, number>();
    for (const d of snap.docs) {
      const data = d.data() as Record<string, unknown>;
      lv.set(String(data.ingredient_id ?? ''), Number(data.stock ?? 0));
    }
    return ings.map((i) => ({ ...i, stock: lv.get(i.id) ?? 0 }));
  } catch (e) {
    throw toDbError(e);
  }
}

/** Thêm nguyên liệu — chỉ chủ quán (rules). Tồn đầu ghi vào kho chỉ định. */
export async function createIngredient(
  d: {
    name: string;
    unit: string;
    stock?: number;
    min_stock?: number;
    cost_per_unit?: number;
  },
  warehouseId?: string | null,
): Promise<Ingredient> {
  const name = String(d.name ?? '').trim().slice(0, 60);
  if (!name) throw new DbError('invalid-argument', 'Vui lòng nhập tên nguyên liệu.');
  const unit = String(d.unit ?? '').trim().slice(0, 20) || 'đơn vị';
  const stock = Number(d.stock ?? 0);
  if (!Number.isFinite(stock)) throw new DbError('invalid-argument', 'Tồn kho không hợp lệ.');
  try {
    const existing = await listIngredients();
    const maxSort = existing.reduce((m, i) => Math.max(m, i.sort_order), 0);
    const id = uuid();
    const data = {
      id,
      name,
      unit,
      stock: 0, // tồn chung cũ không dùng nữa — tồn thật nằm ở stock_levels
      min_stock: Math.max(0, Number(d.min_stock ?? 0) || 0),
      cost_per_unit: Math.max(0, Math.round(Number(d.cost_per_unit ?? 0)) || 0),
      active: true,
      sort_order: maxSort + 1,
      created_at: serverTimestamp(),
    };
    const wid = warehouseId ?? (await getDefaultWarehouseId());
    const batch = writeBatch(db);
    batch.set(doc(db, 'ingredients', id), data);
    if (wid && stock !== 0) {
      const wSnap = await getDoc(doc(db, 'warehouses', wid));
      const wName = wSnap.exists() ? String((wSnap.data() as Record<string, unknown>).name ?? '') : '';
      batch.set(doc(db, 'stock_levels', stockLevelId(wid, id)), {
        warehouse_id: wid,
        ingredient_id: id,
        ingredient_name: name,
        stock,
      });
      const logRef = doc(collection(db, 'stock_logs'));
      batch.set(logRef, {
        id: logRef.id,
        warehouse_id: wid,
        warehouse_name: wName || null,
        ingredient_id: id,
        ingredient_name: name,
        change: stock,
        balance_after: stock,
        note: 'Tồn đầu kỳ',
        ref_type: 'manual',
        ref_id: null,
        created_by: auth.currentUser?.uid ?? null,
        created_at: serverTimestamp(),
      });
    }
    await batch.commit();
    return toIngredient(id, { ...data, stock });
  } catch (e) {
    throw toDbError(e);
  }
}

/** Sửa nguyên liệu — chỉ chủ quán (rules). Đổi tên thì đồng bộ tên ở các kho. */
export async function updateIngredient(
  id: string,
  patch: Partial<Pick<Ingredient, 'name' | 'unit' | 'min_stock' | 'cost_per_unit' | 'active' | 'sort_order'>>,
): Promise<void> {
  const data: Record<string, unknown> = {};
  if (patch.name !== undefined) {
    const name = String(patch.name ?? '').trim().slice(0, 60);
    if (!name) throw new DbError('invalid-argument', 'Tên nguyên liệu không được để trống.');
    data.name = name;
  }
  if (patch.unit !== undefined) {
    data.unit = String(patch.unit ?? '').trim().slice(0, 20) || 'đơn vị';
  }
  if (patch.min_stock !== undefined) {
    const v = Number(patch.min_stock);
    if (!Number.isFinite(v) || v < 0) throw new DbError('invalid-argument', 'Ngưỡng cảnh báo không hợp lệ.');
    data.min_stock = v;
  }
  if (patch.cost_per_unit !== undefined) {
    const v = Math.round(Number(patch.cost_per_unit));
    if (!Number.isFinite(v) || v < 0) throw new DbError('invalid-argument', 'Giá vốn không hợp lệ.');
    data.cost_per_unit = v;
  }
  if (patch.active !== undefined) data.active = patch.active;
  if (patch.sort_order !== undefined) data.sort_order = patch.sort_order;
  if (Object.keys(data).length === 0) return;
  try {
    await updateDoc(doc(db, 'ingredients', id), data);
    if (typeof data.name === 'string') {
      // Đồng bộ tên nguyên liệu ở các doc tồn kho (best-effort)
      const snap = await getDocs(
        query(collection(db, 'stock_levels'), where('ingredient_id', '==', id), limit(50)),
      );
      if (!snap.empty) {
        const batch = writeBatch(db);
        for (const d of snap.docs) batch.update(d.ref, { ingredient_name: data.name });
        await batch.commit();
      }
    }
  } catch (e) {
    throw toDbError(e);
  }
}

/**
 * Nhập/xuất kho thủ công tại 1 kho (change > 0: nhập; < 0: xuất/điều chỉnh giảm).
 * Ghi log kèm tồn sau điều chỉnh. Cho phép tồn âm (sẽ cảnh báo đỏ ở màn Tồn kho).
 * Trả về tồn sau điều chỉnh.
 */
export async function adjustStock(
  warehouseId: string,
  ingredientId: string,
  change: number,
  note?: string | null,
): Promise<number> {
  const delta = Number(change);
  if (!Number.isFinite(delta) || delta === 0) {
    throw new DbError('invalid-argument', 'Số lượng điều chỉnh phải khác 0.');
  }
  if (!warehouseId) throw new DbError('invalid-argument', 'Thiếu kho.');
  try {
    let balanceAfter = 0;
    await runTransaction(db, async (tx) => {
      // Đọc trước — ghi sau (Firestore bắt buộc thứ tự này trong transaction)
      const wRef = doc(db, 'warehouses', warehouseId);
      const iRef = doc(db, 'ingredients', ingredientId);
      const lRef = doc(db, 'stock_levels', stockLevelId(warehouseId, ingredientId));
      const [wSnap, iSnap, lSnap] = await Promise.all([tx.get(wRef), tx.get(iRef), tx.get(lRef)]);
      if (!wSnap.exists() || (wSnap.data() as Record<string, unknown>).active === false) {
        throw new DbError('invalid-argument', 'Kho không tồn tại hoặc đang ẩn.');
      }
      if (!iSnap.exists()) throw new DbError('not-found', 'Không tìm thấy nguyên liệu.');
      const ingName = String((iSnap.data() as Record<string, unknown>).name ?? '');
      const wName = String((wSnap.data() as Record<string, unknown>).name ?? '');
      const cur = lSnap.exists() ? Number((lSnap.data() as Record<string, unknown>).stock ?? 0) : 0;
      balanceAfter = cur + delta;

      tx.set(
        lRef,
        { warehouse_id: warehouseId, ingredient_id: ingredientId, ingredient_name: ingName, stock: balanceAfter },
        { merge: true },
      );
      const logRef = doc(collection(db, 'stock_logs'));
      tx.set(logRef, {
        id: logRef.id,
        warehouse_id: warehouseId,
        warehouse_name: wName || null,
        ingredient_id: ingredientId,
        ingredient_name: ingName,
        change: delta,
        balance_after: balanceAfter,
        note: typeof note === 'string' && note.trim() ? note.trim().slice(0, 500) : null,
        ref_type: 'manual',
        ref_id: null,
        created_by: auth.currentUser?.uid ?? null,
        created_at: serverTimestamp(),
      });
    });
    return balanceAfter;
  } catch (e) {
    throw toDbError(e);
  }
}

/**
 * Chuyển kho: giảm tồn ở kho nguồn, tăng ở kho đích, ghi log cả 2 đầu.
 * Người gọi phải có quyền cả 2 kho (rules kiểm tra).
 */
export async function transferStock(
  fromWarehouseId: string,
  toWarehouseId: string,
  ingredientId: string,
  qty: number,
  note?: string | null,
): Promise<void> {
  const q = Number(qty);
  if (!Number.isFinite(q) || q <= 0) throw new DbError('invalid-argument', 'Số lượng chuyển phải lớn hơn 0.');
  if (!fromWarehouseId || !toWarehouseId) throw new DbError('invalid-argument', 'Thiếu kho nguồn/kho đích.');
  if (fromWarehouseId === toWarehouseId) throw new DbError('invalid-argument', 'Kho nguồn và kho đích trùng nhau.');
  try {
    await runTransaction(db, async (tx) => {
      const fromWRef = doc(db, 'warehouses', fromWarehouseId);
      const toWRef = doc(db, 'warehouses', toWarehouseId);
      const iRef = doc(db, 'ingredients', ingredientId);
      const fromLRef = doc(db, 'stock_levels', stockLevelId(fromWarehouseId, ingredientId));
      const toLRef = doc(db, 'stock_levels', stockLevelId(toWarehouseId, ingredientId));
      const [fromWSnap, toWSnap, iSnap, fromLSnap, toLSnap] = await Promise.all([
        tx.get(fromWRef),
        tx.get(toWRef),
        tx.get(iRef),
        tx.get(fromLRef),
        tx.get(toLRef),
      ]);
      if (!fromWSnap.exists() || !toWSnap.exists()) throw new DbError('invalid-argument', 'Kho không tồn tại.');
      if (!iSnap.exists()) throw new DbError('not-found', 'Không tìm thấy nguyên liệu.');
      const ingName = String((iSnap.data() as Record<string, unknown>).name ?? '');
      const fromWName = String((fromWSnap.data() as Record<string, unknown>).name ?? '');
      const toWName = String((toWSnap.data() as Record<string, unknown>).name ?? '');
      const fromCur = fromLSnap.exists() ? Number((fromLSnap.data() as Record<string, unknown>).stock ?? 0) : 0;
      const toCur = toLSnap.exists() ? Number((toLSnap.data() as Record<string, unknown>).stock ?? 0) : 0;
      const fromAfter = fromCur - q;
      const toAfter = toCur + q;
      const createdBy = auth.currentUser?.uid ?? null;
      const cleanNote = typeof note === 'string' && note.trim() ? note.trim().slice(0, 500) : null;

      tx.set(fromLRef, { warehouse_id: fromWarehouseId, ingredient_id: ingredientId, ingredient_name: ingName, stock: fromAfter }, { merge: true });
      tx.set(toLRef, { warehouse_id: toWarehouseId, ingredient_id: ingredientId, ingredient_name: ingName, stock: toAfter }, { merge: true });
      const outRef = doc(collection(db, 'stock_logs'));
      tx.set(outRef, {
        id: outRef.id,
        warehouse_id: fromWarehouseId,
        warehouse_name: fromWName || null,
        ingredient_id: ingredientId,
        ingredient_name: ingName,
        change: -q,
        balance_after: fromAfter,
        note: `Chuyển sang ${toWName}${cleanNote ? ` · ${cleanNote}` : ''}`,
        ref_type: 'transfer',
        ref_id: null,
        created_by: createdBy,
        created_at: serverTimestamp(),
      });
      const inRef = doc(collection(db, 'stock_logs'));
      tx.set(inRef, {
        id: inRef.id,
        warehouse_id: toWarehouseId,
        warehouse_name: toWName || null,
        ingredient_id: ingredientId,
        ingredient_name: ingName,
        change: q,
        balance_after: toAfter,
        note: `Nhận từ ${fromWName}${cleanNote ? ` · ${cleanNote}` : ''}`,
        ref_type: 'transfer',
        ref_id: null,
        created_by: createdBy,
        created_at: serverTimestamp(),
      });
    });
  } catch (e) {
    throw toDbError(e);
  }
}

/**
 * Lịch sử nhập/xuất kho của 1 kho, mới nhất trước.
 * Luôn lọc theo warehouse_id trong query để khớp với rule phân quyền theo kho.
 */
export async function listStockLogs(warehouseId: string, limitN = 100): Promise<StockLog[]> {
  try {
    const snap = await getDocs(
      query(
        collection(db, 'stock_logs'),
        where('warehouse_id', '==', warehouseId),
        orderBy('created_at', 'desc'),
        limit(Math.min(Math.max(limitN, 1), 500)),
      ),
    );
    return snap.docs.map((d) => toStockLog(d.id, d.data() as Record<string, unknown>));
  } catch (e) {
    throw toDbError(e);
  }
}

/**
 * Xóa nguyên liệu — chỉ khi không còn món nào dùng trong định lượng.
 * Xóa luôn các doc tồn kho của nguyên liệu này ở mọi kho.
 */
export async function deleteIngredient(id: string): Promise<void> {
  try {
    const prods = await listProducts();
    const usedBy = prods
      .filter((p) => p.recipe.some((r) => r.ingredient_id === id))
      .map((p) => p.name);
    if (usedBy.length > 0) {
      throw new DbError(
        'invalid-argument',
        `Nguyên liệu đang dùng trong định lượng: ${usedBy.slice(0, 3).join(', ')}${usedBy.length > 3 ? '…' : ''}. Hãy xóa khỏi định lượng các món trước.`,
      );
    }
    const batch = writeBatch(db);
    batch.delete(doc(db, 'ingredients', id));
    const lvSnap = await getDocs(
      query(collection(db, 'stock_levels'), where('ingredient_id', '==', id), limit(50)),
    );
    for (const d of lvSnap.docs) batch.delete(d.ref);
    await batch.commit();
  } catch (e) {
    throw toDbError(e);
  }
}

// ------------------------------------------------- stock helpers (transaction) ---
// Các helper này dùng CHUNG cho tạo đơn / hủy đơn / xóa đơn.
// NGUYÊN TẮC: mọi tx.get() phải xong trước mọi tx.set()/update()/delete().

/** Tổng nguyên liệu cần trừ/cộng từ các dòng đơn (dương = số lượng cần). */
function calcNeeds(lines: Array<{ qty: number; recipe?: RecipeItem[] }>): Map<string, number> {
  const needs = new Map<string, number>();
  for (const l of lines) {
    for (const r of l.recipe ?? []) {
      const q = Number(r.qty ?? 0) * l.qty;
      if (r.ingredient_id && q > 0 && Number.isFinite(q)) {
        needs.set(r.ingredient_id, (needs.get(r.ingredient_id) ?? 0) + q);
      }
    }
  }
  return needs;
}

interface StockState {
  stock: number;
  name: string;
}

/**
 * Đọc tồn hiện tại + tên nguyên liệu tại 1 kho (PHASE ĐỌC trong transaction).
 * Đơn cũ không có snapshot recipe thì đọc định lượng hiện tại của món.
 */
async function readStockState(
  tx: Transaction,
  order: Order,
  warehouseId: string,
): Promise<{ needs: Map<string, number>; state: Map<string, StockState> }> {
  const needs = calcNeeds(order.items);
  // Đơn cũ chưa có snapshot định lượng → dùng định lượng hiện tại của món
  const noSnapshot = order.items.filter((it) => !(it.recipe && it.recipe.length > 0));
  if (noSnapshot.length > 0) {
    const prodIds = [...new Set(noSnapshot.map((it) => it.product_id).filter(Boolean))];
    const pSnaps = await Promise.all(prodIds.map((pid) => tx.get(doc(db, 'products', pid))));
    for (const pSnap of pSnaps) {
      if (!pSnap.exists()) continue;
      const p = toProduct(pSnap.id, pSnap.data() as Record<string, unknown>);
      for (const it of noSnapshot.filter((m) => m.product_id === p.id)) {
        for (const r of p.recipe) {
          const q = Number(r.qty ?? 0) * it.qty;
          if (r.ingredient_id && q > 0 && Number.isFinite(q)) {
            needs.set(r.ingredient_id, (needs.get(r.ingredient_id) ?? 0) + q);
          }
        }
      }
    }
  }
  const state = new Map<string, StockState>();
  if (needs.size > 0) {
    const ids = [...needs.keys()];
    const [lSnaps, iSnaps] = await Promise.all([
      Promise.all(ids.map((ingId) => tx.get(doc(db, 'stock_levels', stockLevelId(warehouseId, ingId))))),
      Promise.all(ids.map((ingId) => tx.get(doc(db, 'ingredients', ingId)))),
    ]);
    ids.forEach((ingId, i) => {
      const lSnap = lSnaps[i];
      const iSnap = iSnaps[i];
      if (!iSnap.exists()) return; // nguyên liệu đã bị xóa → bỏ qua
      const lData = (lSnap.exists() ? lSnap.data() : {}) as Record<string, unknown>;
      state.set(ingId, {
        stock: Number(lData.stock ?? 0),
        name:
          String(lData.ingredient_name ?? '') ||
          String((iSnap.data() as Record<string, unknown>).name ?? ''),
      });
    });
  }
  return { needs, state };
}

export type StockRefType = 'order' | 'transfer' | 'manual';

/**
 * Ghi biến động tồn kho (PHASE GHI trong transaction — không đọc gì thêm).
 * delta > 0: cộng tồn (hoàn kho / nhập); delta < 0: trừ tồn (bán / xuất).
 */
function writeStockMoves(
  tx: Transaction,
  args: {
    warehouseId: string;
    warehouseName: string | null;
    needs: Map<string, number>;
    state: Map<string, StockState>;
    sign: 1 | -1; // 1 = cộng tồn, -1 = trừ tồn
    note: string;
    ref_type: StockRefType;
    ref_id: string | null;
    createdBy: string | null;
  },
): void {
  const { warehouseId, warehouseName, needs, state, sign, note, ref_type, ref_id, createdBy } = args;
  for (const [ingId, qty] of needs) {
    const st = state.get(ingId);
    if (!st) continue;
    const balance_after = st.stock + sign * qty;
    tx.set(
      doc(db, 'stock_levels', stockLevelId(warehouseId, ingId)),
      {
        warehouse_id: warehouseId,
        ingredient_id: ingId,
        ingredient_name: st.name,
        stock: balance_after,
      },
      { merge: true },
    );
    const logRef = doc(collection(db, 'stock_logs'));
    tx.set(logRef, {
      id: logRef.id,
      warehouse_id: warehouseId,
      warehouse_name: warehouseName,
      ingredient_id: ingId,
      ingredient_name: st.name,
      change: sign * qty,
      balance_after,
      note,
      ref_type,
      ref_id,
      created_by: createdBy,
      created_at: serverTimestamp(),
    });
  }
}
// --------------------------------------------------------------- customers ---
export async function searchCustomers(q: string): Promise<Customer[]> {
  try {
    const snap = await getDocs(collection(db, 'customers'));
    const all = snap.docs.map((d) => toCustomer(d.id, d.data()));
    const needle = unsignVietnamese(String(q ?? '')).toLowerCase();
    const filtered = needle
      ? all.filter((c) => {
          const hay = unsignVietnamese(`${c.name} ${c.phone}`).toLowerCase();
          return hay.includes(needle);
        })
      : all;
    filtered.sort((a, b) => a.name.localeCompare(b.name, 'vi'));
    return filtered;
  } catch (e) {
    throw toDbError(e);
  }
}

export async function getCustomer(
  id: string,
): Promise<(Customer & { recent_orders: Order[] }) | null> {
  try {
    const snap = await getDoc(doc(db, 'customers', id));
    if (!snap.exists()) return null;
    const customer = toCustomer(snap.id, snap.data());
    const oSnap = await getDocs(
      query(
        collection(db, 'orders'),
        where('customer_id', '==', id),
        orderBy('created_at', 'desc'),
        limit(20),
      ),
    );
    const recent_orders = oSnap.docs
      .map((d) => orderFromDoc(d))
      .filter((o): o is Order => o !== null);
    return { ...customer, recent_orders };
  } catch (e) {
    throw toDbError(e);
  }
}

export async function createCustomer(d: {
  name: string;
  phone: string;
  birthday?: string | null;
  address?: string | null;
  note?: string | null;
}): Promise<Customer> {
  const name = String(d.name ?? '').trim();
  const phone = String(d.phone ?? '').trim();
  if (!name) throw new DbError('invalid-argument', 'Vui lòng nhập tên khách hàng.');
  if (!phone) throw new DbError('invalid-argument', 'Vui lòng nhập số điện thoại.');
  try {
    const dup = await getDocs(query(collection(db, 'customers'), where('phone', '==', phone), limit(1)));
    if (!dup.empty) {
      throw new DbError('invalid-argument', `Số điện thoại ${phone} đã được đăng ký cho khách khác.`);
    }
    const id = uuid();
    const data = {
      id,
      name,
      phone,
      birthday: d.birthday ?? null,
      address: typeof d.address === 'string' && d.address ? d.address.slice(0, 500) : null,
      stamps: 0,
      reward_available: false,
      debt: 0,
      note: typeof d.note === 'string' && d.note ? d.note.slice(0, 1000) : null,
      created_at: serverTimestamp(),
    };
    await setDoc(doc(db, 'customers', id), data);
    const snap = await getDoc(doc(db, 'customers', id));
    const c = snap.exists() ? toCustomer(snap.id, snap.data()) : null;
    if (!c) throw new DbError('unknown', 'Không đọc được khách hàng vừa tạo.');
    return c;
  } catch (e) {
    throw toDbError(e);
  }
}

export async function updateCustomer(
  id: string,
  patch: Partial<Pick<Customer, 'name' | 'phone' | 'birthday' | 'address' | 'note'>>,
): Promise<void> {
  const data: Record<string, unknown> = {};
  if (patch.name !== undefined) {
    const trimmed = String(patch.name).trim();
    if (!trimmed) throw new DbError('invalid-argument', 'Tên khách hàng không được để trống.');
    data.name = trimmed;
  }
  if (patch.phone !== undefined) {
    const trimmed = String(patch.phone).trim();
    if (!trimmed) throw new DbError('invalid-argument', 'Số điện thoại không được để trống.');
    data.phone = trimmed;
  }
  if (patch.birthday !== undefined) data.birthday = patch.birthday;
  if (patch.address !== undefined) data.address = patch.address;
  if (patch.note !== undefined) data.note = patch.note;
  if (Object.keys(data).length === 0) return;
  try {
    if (data.phone !== undefined) {
      const dup = await getDocs(
        query(collection(db, 'customers'), where('phone', '==', data.phone), limit(2)),
      );
      if (dup.docs.some((x) => x.id !== id)) {
        throw new DbError(
          'invalid-argument',
          `Số điện thoại ${data.phone} đã được đăng ký cho khách khác.`,
        );
      }
    }
    await updateDoc(doc(db, 'customers', id), data);
  } catch (e) {
    throw toDbError(e);
  }
}

// --------------------------------------------------------------- công nợ ---
// Điều chỉnh công nợ khách hàng: amount > 0 = ghi nợ thêm, amount < 0 = thu nợ.
// Ghi lịch sử vào subcollection debt_logs để đối chiếu.
export async function adjustDebt(
  customerId: string,
  amount: number,
  note?: string | null,
): Promise<number> {
  const delta = Number(amount);
  if (!Number.isFinite(delta) || delta === 0) {
    throw new DbError('invalid-argument', 'Số tiền điều chỉnh công nợ không hợp lệ.');
  }
  try {
    const balanceAfter = await runTransaction(db, async (tx) => {
      const ref = doc(db, 'customers', customerId);
      const snap = await tx.get(ref);
      if (!snap.exists()) throw new DbError('not-found', 'Khách hàng không tồn tại.');
      const cur = Number(snap.data().debt ?? 0);
      const next = cur + delta;
      if (next < 0) throw new DbError('invalid-argument', `Số tiền thu (${formatVNDLocal(-delta)}) lớn hơn công nợ hiện tại (${formatVNDLocal(cur)}).`);
      tx.update(ref, { debt: next });
      const logRef = doc(collection(db, 'customers', customerId, 'debt_logs'));
      tx.set(logRef, {
        id: logRef.id,
        amount: delta,
        balance_after: next,
        note: typeof note === 'string' && note ? note.slice(0, 500) : null,
        created_by: auth.currentUser?.uid ?? null,
        created_at: serverTimestamp(),
      });
      return next;
    });
    return balanceAfter;
  } catch (e) {
    throw toDbError(e);
  }
}

function formatVNDLocal(n: number): string {
  return new Intl.NumberFormat('vi-VN').format(Math.round(n)) + 'đ';
}

export async function listDebtLogs(customerId: string, limitN = 20): Promise<DebtLog[]> {
  try {
    const snap = await getDocs(
      query(
        collection(db, 'customers', customerId, 'debt_logs'),
        orderBy('created_at', 'desc'),
        limit(limitN),
      ),
    );
    return snap.docs.map((d) => toDebtLog(d.id, d.data()));
  } catch (e) {
    throw toDbError(e);
  }
}

// ------------------------------------------------------------ sổ thu chi ---
// Thu/chi THỦ CÔNG của quán (nhập hàng, mặt bằng, lương...).
// LƯU Ý: đơn bán KHÔNG tự log vào đây — chỉ ghi tay qua màn hình Thu chi.
function toCashbookEntry(id: string, d: Record<string, unknown>): CashbookEntry {
  const rt = d.ref_type;
  return {
    id,
    type: d.type === 'chi' ? 'chi' : 'thu',
    amount: Number(d.amount ?? 0),
    note: (d.note as string | null) ?? null,
    category: String(d.category ?? 'Khác'),
    fund_id: String(d.fund_id ?? 'cash'),
    ref_type: rt === 'order' || rt === 'debt_pay' ? (rt as FundRefType) : 'manual',
    ref_id: (d.ref_id as string | null) ?? null,
    ref_code: (d.ref_code as string | null) ?? null,
    method: d.method === 'cash' || d.method === 'transfer' ? d.method : null,
    created_by: (d.created_by as string | null) ?? null,
    created_at: tsToIso(d.created_at),
  };
}

export interface AddCashbookOpts {
  refType?: FundRefType;
  refId?: string | null;
  method?: 'cash' | 'transfer' | null;
  fundId?: string | null; // quỹ nhận khoản này, mặc định 'cash'
}

export async function addCashbookEntry(
  type: CashbookType,
  amount: number,
  note?: string | null,
  category?: string | null,
  opts?: AddCashbookOpts,
): Promise<CashbookEntry> {
  const v = Math.round(Number(amount));
  if (!Number.isFinite(v) || v <= 0) {
    throw new DbError('invalid-argument', 'Số tiền phải lớn hơn 0.');
  }
  const id = uuid();
  const data = {
    id,
    type,
    amount: v,
    note: typeof note === 'string' && note.trim() ? note.trim().slice(0, 500) : null,
    category: typeof category === 'string' && category.trim() ? category.trim().slice(0, 50) : 'Khác',
    fund_id:
      typeof opts?.fundId === 'string' && opts.fundId.trim() ? opts.fundId.trim().slice(0, 60) : 'cash',
    ref_type: opts?.refType ?? 'manual',
    ref_id: opts?.refId ?? null,
    method: opts?.method ?? null,
    created_by: auth.currentUser?.uid ?? null,
    created_at: serverTimestamp(),
  };
  try {
    await setDoc(doc(db, 'cashbook_entries', id), data);
    const snap = await getDoc(doc(db, 'cashbook_entries', id));
    const e = snap.exists() ? toCashbookEntry(snap.id, snap.data() as Record<string, unknown>) : null;
    if (!e) throw new DbError('unknown', 'Không đọc được khoản vừa tạo.');
    return e;
  } catch (e) {
    throw toDbError(e);
  }
}

export async function listCashbookEntries(limitN = 500): Promise<CashbookEntry[]> {
  try {
    const snap = await getDocs(
      query(collection(db, 'cashbook_entries'), orderBy('created_at', 'desc'), limit(limitN)),
    );
    return snap.docs.map((d) => toCashbookEntry(d.id, d.data() as Record<string, unknown>));
  } catch (e) {
    throw toDbError(e);
  }
}

// ------------------------------------------------------- hóa đơn tạm ---
function toDraftOrder(id: string, d: Record<string, unknown>): DraftOrder | null {
  const items = Array.isArray(d.items) ? d.items : [];
  if (items.length === 0) return null;
  return {
    id,
    items: items as DraftOrderItem[],
    customer_id: typeof d.customer_id === 'string' ? d.customer_id : null,
    customer_name: typeof d.customer_name === 'string' ? d.customer_name : null,
    created_by: typeof d.created_by === 'string' ? d.created_by : null,
    created_at: tsToIso(d.created_at),
  };
}

/** Lưu tạm giỏ hàng thành hóa đơn tạm. */
export async function saveDraftOrder(input: {
  items: DraftOrderItem[];
  customer_id: string | null;
  customer_name: string | null;
}): Promise<DraftOrder> {
  const items = input.items.filter((i) => i.qty > 0 && i.product);
  if (items.length === 0) throw new DbError('invalid-argument', 'Giỏ hàng đang trống.');
  if (items.length > 50) throw new DbError('invalid-argument', 'Hóa đơn tạm tối đa 50 dòng.');
  const id = uuid();
  try {
    await setDoc(doc(db, 'draft_orders', id), {
      id,
      items: items.map((i) => ({
        product: { ...i.product },
        qty: i.qty,
        modifiers: i.modifiers ?? [],
        note: i.note ?? '',
      })),
      customer_id: input.customer_id,
      customer_name: input.customer_name,
      created_by: auth.currentUser?.uid ?? null,
      created_at: serverTimestamp(),
    });
    const snap = await getDoc(doc(db, 'draft_orders', id));
    const draft = snap.exists() ? toDraftOrder(snap.id, snap.data() as Record<string, unknown>) : null;
    if (!draft) throw new DbError('unknown', 'Không đọc được hóa đơn tạm vừa lưu.');
    return draft;
  } catch (e) {
    throw toDbError(e);
  }
}

/** Danh sách hóa đơn tạm, mới nhất trước. */
export async function listDraftOrders(): Promise<DraftOrder[]> {
  try {
    const snap = await getDocs(
      query(collection(db, 'draft_orders'), orderBy('created_at', 'desc'), limit(50)),
    );
    const out: DraftOrder[] = [];
    for (const d of snap.docs) {
      const draft = toDraftOrder(d.id, d.data() as Record<string, unknown>);
      if (draft) out.push(draft);
    }
    return out;
  } catch (e) {
    throw toDbError(e);
  }
}

/** Xóa hóa đơn tạm (sau khi mở lại hoặc hủy). */
export async function deleteDraftOrder(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'draft_orders', id));
  } catch (e) {
    throw toDbError(e);
  }
}

// ------------------------------------------------------------- sổ quỹ ---
const DEFAULT_FUND: FundSettings = {
  fund_name: 'Tiền mặt tại quầy',
  opening_balance: 0,
  opening_date: todayVN(),
};

/** Đọc cài đặt quỹ ở settings/fund (chưa có → dùng mặc định). */
export async function getFundSettings(): Promise<FundSettings> {
  try {
    const snap = await getDoc(doc(db, 'settings', 'fund'));
    if (!snap.exists()) return { ...DEFAULT_FUND };
    const d = snap.data();
    return {
      fund_name: typeof d.fund_name === 'string' && d.fund_name ? d.fund_name : DEFAULT_FUND.fund_name,
      opening_balance: Number.isFinite(Number(d.opening_balance)) ? Math.round(Number(d.opening_balance)) : 0,
      opening_date: /^\d{4}-\d{2}-\d{2}$/.test(String(d.opening_date)) ? String(d.opening_date) : todayVN(),
    };
  } catch (e) {
    throw toDbError(e);
  }
}

/** Lưu cài đặt quỹ — chỉ chủ quán (rules settings/{key} chỉ cho owner ghi). */
export async function setFundSettings(patch: Partial<FundSettings>): Promise<FundSettings> {
  const data: Record<string, unknown> = {};
  if (patch.fund_name !== undefined) {
    const n = String(patch.fund_name ?? '').trim().slice(0, 100);
    if (!n) throw new DbError('invalid-argument', 'Tên quỹ không được để trống.');
    data.fund_name = n;
  }
  if (patch.opening_balance !== undefined) {
    const v = Math.round(Number(patch.opening_balance));
    if (!Number.isFinite(v)) throw new DbError('invalid-argument', 'Số dư đầu kỳ không hợp lệ.');
    data.opening_balance = v;
  }
  if (patch.opening_date !== undefined) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(patch.opening_date))) {
      throw new DbError('invalid-argument', 'Ngày không hợp lệ.');
    }
    data.opening_date = String(patch.opening_date);
  }
  if (Object.keys(data).length === 0) return getFundSettings();
  try {
    await setDoc(doc(db, 'settings', 'fund'), data, { merge: true });
    return getFundSettings();
  } catch (e) {
    throw toDbError(e);
  }
}

// ------------------------------------------------- danh mục thu/chi ---
// Danh mục hệ thống của khoản TỰ ĐỘNG — luôn tồn tại, không cho xóa/sửa.
export const LOCKED_THU_CATS = ['Bán hàng', 'Thu nợ'];
const DEFAULT_FUND_CATEGORIES: FundCategories = {
  thu: ['Bán hàng', 'Thu nợ', 'Khác'],
  chi: ['Nguyên liệu', 'Mặt bằng', 'Lương', 'Khác'],
};

/** Chuẩn hóa danh sách danh mục: trim, ≤30 ký tự, không trùng, giữ locked lên đầu. */
function sanitizeCatList(input: unknown, locked: string[]): string[] {
  const arr = Array.isArray(input) ? input : [];
  const seen = new Set<string>();
  const out: string[] = [];
  for (const s of [...locked, ...arr]) {
    const t = String(s ?? '').trim().slice(0, 30);
    if (!t || seen.has(t.toLowerCase())) continue;
    seen.add(t.toLowerCase());
    out.push(t);
  }
  return out.slice(0, 30);
}

/** Đọc danh mục thu/chi ở settings/fund_categories (chưa có → dùng mặc định). */
export async function getFundCategories(): Promise<FundCategories> {
  try {
    const snap = await getDoc(doc(db, 'settings', 'fund_categories'));
    if (!snap.exists()) {
      return { thu: [...DEFAULT_FUND_CATEGORIES.thu], chi: [...DEFAULT_FUND_CATEGORIES.chi] };
    }
    const d = snap.data();
    const thu = sanitizeCatList(d.thu, LOCKED_THU_CATS);
    const chi = sanitizeCatList(d.chi, []);
    return { thu, chi: chi.length > 0 ? chi : ['Khác'] };
  } catch (e) {
    throw toDbError(e);
  }
}

/** Lưu danh mục thu/chi — chỉ chủ quán (rules settings/{key} chỉ cho owner ghi). */
export async function setFundCategories(cats: FundCategories): Promise<FundCategories> {
  const clean: FundCategories = {
    thu: sanitizeCatList(cats.thu, LOCKED_THU_CATS),
    chi: sanitizeCatList(cats.chi, []),
  };
  if (clean.chi.length === 0) clean.chi.push('Khác');
  try {
    await setDoc(
      doc(db, 'settings', 'fund_categories'),
      { ...clean, updated_at: serverTimestamp() },
      { merge: true },
    );
    return clean;
  } catch (e) {
    throw toDbError(e);
  }
}

// ------------------------------------------------------------- quỹ ---
// Mỗi phương thức thanh toán (trừ Ghi nợ) là một quỹ.
// Danh sách quỹ đồng bộ từ payment_methods: thêm/sửa/ẩn phương thức ở Cài đặt
// thì quỹ tự theo. Số dư đầu kỳ của từng quỹ lưu ở settings/funds.

/** Đọc số dư đầu kỳ đã lưu ở settings/funds (key theo id phương thức). */
async function getFundOpenings(): Promise<
  Record<string, { opening_balance: number; opening_date: string }>
> {
  try {
    const snap = await getDoc(doc(db, 'settings', 'funds'));
    if (!snap.exists()) return {};
    const arr = (snap.data() as Record<string, unknown>).funds;
    const out: Record<string, { opening_balance: number; opening_date: string }> = {};
    if (Array.isArray(arr)) {
      for (const r of arr) {
        const o = r as Record<string, unknown>;
        const id = String(o.id ?? '');
        if (!id) continue;
        out[id] = {
          opening_balance: Math.round(Number(o.opening_balance ?? 0)) || 0,
          opening_date:
            typeof o.opening_date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(o.opening_date)
              ? o.opening_date
              : todayVN(),
        };
      }
    }
    return out;
  } catch {
    return {};
  }
}

/**
 * Danh sách quỹ = các phương thức thanh toán (trừ Ghi nợ).
 * Tên + trạng thái theo phương thức; số dư đầu kỳ sửa riêng ở Sổ quỹ.
 */
export async function getFunds(): Promise<Fund[]> {
  try {
    const [methods, openings] = await Promise.all([
      listPaymentMethods(false),
      getFundOpenings(),
    ]);
    const list: Fund[] = methods
      .filter((m) => m.kind !== 'debt')
      .map((m) => ({
        id: m.id,
        payment_method_id: m.id,
        kind: m.kind as 'cash' | 'transfer',
        name: m.name,
        opening_balance: openings[m.id]?.opening_balance ?? 0,
        opening_date: openings[m.id]?.opening_date ?? todayVN(),
        active: m.active,
        sort_order: m.sort_order,
      }));
    list.sort((a, b) => a.sort_order - b.sort_order || a.name.localeCompare(b.name, 'vi'));
    return list;
  } catch (e) {
    throw toDbError(e);
  }
}

/** Cập nhật số dư đầu kỳ của một quỹ — chỉ chủ quán (rules settings/{key} chỉ cho owner ghi). */
export async function saveFundOpening(
  id: string,
  opening_balance: number,
  opening_date: string,
): Promise<Fund[]> {
  const v = Math.round(Number(opening_balance));
  if (!Number.isFinite(v) || v < 0) {
    throw new DbError('invalid-argument', 'Số dư đầu kỳ không hợp lệ.');
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(opening_date))) {
    throw new DbError('invalid-argument', 'Ngày không hợp lệ.');
  }
  try {
    const funds = await getFunds();
    if (!funds.some((f) => f.id === id)) throw new DbError('not-found', 'Không tìm thấy quỹ.');
    await setDoc(
      doc(db, 'settings', 'funds'),
      {
        funds: funds.map((f) =>
          f.id === id
            ? { id: f.id, name: f.name, opening_balance: v, opening_date }
            : {
                id: f.id,
                name: f.name,
                opening_balance: f.opening_balance,
                opening_date: f.opening_date,
              },
        ),
        updated_at: serverTimestamp(),
      },
      { merge: true },
    );
    return getFunds();
  } catch (e) {
    throw toDbError(e);
  }
}

/**
 * Chuẩn hóa fund_id của khoản cũ:
 * - 'bank' là id quỹ chuyển khoản của bản trước → nay là id phương thức ('transfer')
 * - id lạ (phương thức đã xóa) → 'cash'
 */
export function normalizeFundId(fundId: string, validIds: Set<string>): string {
  if (fundId === 'bank') return 'transfer';
  return validIds.has(fundId) ? fundId : 'cash';
}

/** Số dư từng quỹ = số dư đầu kỳ + Σ thu − Σ chi của quỹ đó. */
export function fundBalance(fund: Fund, entries: CashbookEntry[]): number {
  let b = fund.opening_balance;
  for (const e of entries) {
    if (e.fund_id !== fund.id) continue;
    b += e.type === 'thu' ? e.amount : -e.amount;
  }
  return b;
}

// Đổi thưởng mua-N-tặng-1: chỉ reset cờ reward_available (đơn thưởng do POS tạo riêng)
export async function redeemReward(customerId: string): Promise<void> {
  try {
    const ref = doc(db, 'customers', customerId);
    const snap = await getDoc(ref);
    if (!snap.exists()) throw new DbError('not-found', 'Khách hàng không tồn tại.');
    if (snap.data().reward_available !== true) {
      throw new DbError('invalid-argument', 'Khách hàng chưa có lượt đổi thưởng nào.');
    }
    await updateDoc(ref, { reward_available: false });
  } catch (e) {
    throw toDbError(e);
  }
}

// ---------------------------------------------------------------- settings ---
export async function getSettings(): Promise<Record<string, string>> {
  try {
    const snap = await getDocs(collection(db, 'settings'));
    const out: Record<string, string> = {};
    for (const d of snap.docs) out[d.id] = String(d.data().value ?? '');
    return out;
  } catch (e) {
    throw toDbError(e);
  }
}

export async function setSetting(key: string, value: string): Promise<void> {
  if (!String(key ?? '').trim()) throw new DbError('invalid-argument', 'Thiếu key cài đặt.');
  try {
    await setDoc(doc(db, 'settings', key), { key, value: String(value ?? '') }, { merge: true });
  } catch (e) {
    throw toDbError(e);
  }
}

// ----------------------------------------------------------------- reports ---
// Mirror backend GET /api/v1/reports/daily — aggregate client-side.
// Đơn cancelled không tính vào doanh thu.

/** Giá vốn hiện tại của món — dùng cho đơn cũ chưa có snapshot cost_price. */
async function loadCostMap(): Promise<Map<string, number>> {
  try {
    const pSnap = await getDocs(query(collection(db, 'products'), limit(2000)));
    const m = new Map<string, number>();
    for (const d of pSnap.docs) {
      m.set(d.id, toProduct(d.id, d.data() as Record<string, unknown>).cost_price);
    }
    return m;
  } catch {
    return new Map();
  }
}

function buildDailyReport(orders: Order[], date: string, costNow: Map<string, number>): DailyReport {
  const itemCost = (it: { product_id: string; cost_price: number }) =>
    it.cost_price > 0 ? it.cost_price : (costNow.get(it.product_id) ?? 0);

  const revenue = orders.reduce((s, o) => s + o.total, 0);
  const by_payment: DailyReport['by_payment'] = {};
  for (const o of orders) {
    const key = o.payment_method || 'unknown';
    const slot = by_payment[key] ?? { name: o.payment_method_name || key, count: 0, revenue: 0 };
    slot.count += 1;
    slot.revenue += o.total;
    if (o.payment_method_name) slot.name = o.payment_method_name;
    by_payment[key] = slot;
  }

  const topMap = new Map<
    string,
    { product_id: string; name: string; qty: number; revenue: number; profit: number }
  >();
  let profit = 0;
  for (const o of orders) {
    for (const it of o.items) {
      const lineProfit = it.line_total - itemCost(it) * it.qty;
      profit += lineProfit;
      const cur = topMap.get(it.product_id) ?? {
        product_id: it.product_id,
        name: it.product_name,
        qty: 0,
        revenue: 0,
        profit: 0,
      };
      cur.qty += it.qty;
      cur.revenue += it.line_total;
      cur.profit += lineProfit;
      topMap.set(it.product_id, cur);
    }
  }
  // Trả TOÀN BỘ món (sắp xếp mặc định theo số lượng); màn Báo cáo sẽ sắp xếp lại
  // theo tiêu chí (số lượng/doanh thu/lợi nhuận) rồi mới cắt top 10 — để top
  // doanh thu/lợi nhuận chính xác kể cả khi món nằm ngoài top 10 số lượng.
  const top_products = [...topMap.values()].sort((a, b) => b.qty - a.qty || b.revenue - a.revenue);

  const by_hour = Array.from({ length: 24 }, (_, hour) => ({ hour, count: 0, revenue: 0 }));
  for (const o of orders) {
    const h = vnHour(o.created_at);
    if (h >= 0 && h < 24) {
      by_hour[h].count += 1;
      by_hour[h].revenue += o.total;
    }
  }

  return { date, revenue, profit, order_count: orders.length, by_payment, top_products, by_hour };
}

export async function getDailyReport(date: string): Promise<DailyReport> {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    throw new DbError('invalid-argument', 'Tham số date phải có dạng YYYY-MM-DD.');
  }
  try {
    const [snap, costNow] = await Promise.all([
      getDocs(
        query(
          collection(db, 'orders'),
          where('business_date', '==', date),
          orderBy('created_at', 'desc'),
          limit(2000),
        ),
      ),
      loadCostMap(),
    ]);
    const orders = snap.docs
      .map((d) => orderFromDoc(d))
      .filter((o): o is Order => o !== null && o.status !== 'cancelled');
    return buildDailyReport(orders, date, costNow);
  } catch (e) {
    throw toDbError(e);
  }
}

// Báo cáo theo khoảng ngày (dùng cho các mốc lọc: hôm qua, tuần này/tháng này...).
// Truy vấn range trên business_date + orderBy cùng field nên không cần composite index mới.
export async function getRangeReport(start: string, end: string): Promise<DailyReport> {
  const valid = /^\d{4}-\d{2}-\d{2}$/;
  if (!valid.test(start) || !valid.test(end) || start > end) {
    throw new DbError('invalid-argument', 'Khoảng ngày không hợp lệ.');
  }
  try {
    const [snap, costNow] = await Promise.all([
      getDocs(
        query(
          collection(db, 'orders'),
          where('business_date', '>=', start),
          where('business_date', '<=', end),
          orderBy('business_date', 'desc'),
          limit(5000),
        ),
      ),
      loadCostMap(),
    ]);
    const orders = snap.docs
      .map((d) => orderFromDoc(d))
      .filter((o): o is Order => o !== null && o.status !== 'cancelled');
    return buildDailyReport(orders, `${start}→${end}`, costNow);
  } catch (e) {
    throw toDbError(e);
  }
}

// ------------------------------------------------------------------ backup ---
const EXPORT_TABLES = [
  'categories',
  'products',
  'modifierGroups',
  'modifierOptions',
  'customers',
  'orders',
  'settings',
  'counters',
  'payment_methods',
  'ingredients',
  'stock_logs',
  'warehouses',
  'stock_levels',
  'users', // {id, email, full_name, role} — không chứa mật khẩu
] as const;

function plainValue(v: unknown): unknown {
  if (v instanceof Timestamp) return v.toDate().toISOString();
  if (Array.isArray(v)) return v.map(plainValue);
  if (v && typeof v === 'object') {
    const out: Record<string, unknown> = {};
    for (const [k, val] of Object.entries(v)) out[k] = plainValue(val);
    return out;
  }
  return v;
}

export async function exportAllJson(): Promise<Record<string, unknown[]>> {
  try {
    const out: Record<string, unknown[]> = {};
    for (const t of EXPORT_TABLES) {
      const snap = await getDocs(query(collection(db, t), limit(5000)));
      out[t] = snap.docs.map((d) => plainValue({ id: d.id, ...d.data() }) as unknown);
    }
    return out;
  } catch (e) {
    throw toDbError(e);
  }
}

// Header CSV tiếng Việt — mirror backend routes/backup.js#CSV_HEADERS
const CSV_HEADERS: Record<'orders' | 'products' | 'customers' | 'categories' | 'payment_methods', [string, string][]> = {
  orders: [
    ['id', 'Mã nội bộ'], ['client_uuid', 'Mã chống trùng'], ['code', 'Mã đơn'],
    ['business_date', 'Ngày bán'], ['customer_id', 'Mã KH'], ['status', 'Trạng thái'],
    ['payment_method', 'Mã thanh toán'], ['payment_method_name', 'Thanh toán'], ['subtotal', 'Tạm tính (VND)'],
    ['discount', 'Giảm giá (VND)'], ['total', 'Tổng tiền (VND)'],
    ['amount_received', 'Tiền nhận (VND)'], ['change_amount', 'Tiền thừa (VND)'],
    ['note', 'Ghi chú'], ['created_by', 'Người tạo'], ['created_at', 'Thời gian tạo'],
  ],
  products: [
    ['id', 'Mã nội bộ'], ['name', 'Tên món'], ['category_id', 'Mã danh mục'],
    ['base_price', 'Giá bán (VND)'], ['cost_price', 'Giá vốn (VND)'], ['unit', 'Đơn vị'],
    ['image_url', 'Ảnh'],
    ['active', 'Đang bán'], ['sort_order', 'Thứ tự'], ['created_at', 'Ngày tạo'],
  ],
  customers: [
    ['id', 'Mã nội bộ'], ['name', 'Tên khách'], ['phone', 'Số điện thoại'],
    ['birthday', 'Ngày sinh'], ['address', 'Địa chỉ'], ['stamps', 'Số tem'],
    ['reward_available', 'Có thưởng'], ['debt', 'Công nợ (VND)'], ['note', 'Ghi chú'], ['created_at', 'Ngày tạo'],
  ],
  categories: [
    ['id', 'Mã nội bộ'], ['name', 'Tên danh mục'],
    ['sort_order', 'Thứ tự'], ['active', 'Đang dùng'],
  ],
  payment_methods: [
    ['id', 'Mã nội bộ'], ['name', 'Tên phương thức'], ['kind', 'Loại'],
    ['icon', 'Biểu tượng'], ['bank_bin', 'Mã BIN'], ['bank_account', 'Số tài khoản'],
    ['bank_account_name', 'Chủ tài khoản'], ['active', 'Đang dùng'], ['sort_order', 'Thứ tự'],
  ],
};

function csvCell(v: unknown): string {
  if (v === null || v === undefined) return '';
  const s = typeof v === 'object' ? JSON.stringify(v) : String(v);
  if (/[",\n\r]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

export async function exportTableCsv(
  table: 'orders' | 'products' | 'customers' | 'categories' | 'payment_methods',
): Promise<string> {
  const header = CSV_HEADERS[table];
  if (!header) throw new DbError('invalid-argument', `Bảng không hỗ trợ: ${table}.`);
  try {
    const snap = await getDocs(query(collection(db, table), limit(5000)));
    const lines = [header.map(([, label]) => csvCell(label)).join(',')];
    for (const d of snap.docs) {
      const data = d.data() as Record<string, unknown>;
      lines.push(
        header
          .map(([col]) => {
            if (col === 'id') return csvCell(d.id);
            if (col === 'created_at') {
              // products/categories seed không có created_at → để trống thay vì ngày hiện tại
              return data[col] == null ? '' : csvCell(tsToIso(data[col]));
            }
            return csvCell(data[col]);
          })
          .join(','),
      );
    }
    return '﻿' + lines.join('\r\n'); // BOM để Excel mở đúng tiếng Việt
  } catch (e) {
    throw toDbError(e);
  }
}

export function downloadFile(filename: string, content: string, mime: string): void {
  const blob = new Blob([content], { type: `${mime};charset=utf-8` });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}
