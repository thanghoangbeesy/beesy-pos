// Kiểu dữ liệu dùng chung — khớp CONTRACT mục 4 & 5

export interface User {
  id: string;
  email: string;
  full_name: string;
  role: 'owner' | 'staff';
}

export interface Category {
  id: string;
  name: string;
  sort_order: number;
  active: boolean;
}

export interface ModifierOption {
  id: string;
  group_id: string;
  name: string;
  price_delta: number;
  sort_order: number;
  active: boolean;
}

export interface ModifierGroup {
  id: string;
  name: string;
  selection_type: 'single' | 'multi';
  required: boolean;
  sort_order: number;
  active: boolean;
  options: ModifierOption[];
}

export interface Product {
  id: string;
  name: string;
  category_id: string | null;
  base_price: number;
  cost_price: number; // giá vốn / đơn vị (để tính lợi nhuận)
  unit: string; // đơn vị: Ly, Cái, Hộp...
  recipe: RecipeItem[]; // định lượng nguyên liệu cho 1 đơn vị món
  image_url: string | null;
  active: boolean;
  sort_order: number;
}

// Định lượng: lượng nguyên liệu cho 1 đơn vị món
export interface RecipeItem {
  ingredient_id: string;
  qty: number;
}

// Nguyên liệu tồn kho
export interface Ingredient {
  id: string;
  name: string;
  unit: string; // g, ml, cái, hộp...
  stock: number; // tồn kho hiện tại
  min_stock: number; // ngưỡng cảnh báo sắp hết
  cost_per_unit: number; // giá vốn / đơn vị nguyên liệu (tham khảo)
  active: boolean;
  sort_order: number;
}

// Lịch sử nhập/xuất kho
export interface StockLog {
  id: string;
  ingredient_id: string;
  ingredient_name: string;
  change: number; // + nhập, - xuất
  balance_after: number;
  note: string | null;
  ref_type: 'manual' | 'order';
  ref_id: string | null;
  created_by: string | null;
  created_at: string; // ISO
}

// Option đã chọn khi bỏ món vào giỏ (snapshot để gửi lên server)
export interface SelectedModifier {
  option_id: string;
  group: string;
  option: string;
  price_delta: number;
}

export interface CartLine {
  key: string;
  product: Product;
  qty: number;
  modifiers: SelectedModifier[];
  note: string;
}

// Hóa đơn tạm — lưu tạm giỏ hàng để bán tiếp sau (collection draft_orders)
export interface DraftOrderItem {
  product: Product; // snapshot món lúc lưu tạm (giữ giá lúc đó)
  qty: number;
  modifiers: SelectedModifier[];
  note: string;
}

export interface DraftOrder {
  id: string;
  items: DraftOrderItem[];
  customer_id: string | null;
  customer_name: string | null;
  created_by: string | null;
  created_at: string; // ISO
}

export interface OrderItem {
  id: string;
  order_id: string;
  product_id: string;
  product_name: string;
  qty: number;
  unit_price: number;
  cost_price: number; // giá vốn lúc bán (snapshot để tính lợi nhuận)
  recipe?: RecipeItem[]; // snapshot định lượng lúc bán (để hoàn kho khi hủy/xóa đơn)
  modifiers: SelectedModifier[];
  line_total: number;
  note?: string;
}

export type OrderStatus = 'new' | 'preparing' | 'ready' | 'done' | 'cancelled';

// id của phương thức thanh toán (collection payment_methods).
// Các id hệ thống: 'cash' (tiền mặt), 'transfer' (chuyển khoản), 'debt' (ghi nợ).
export type PaymentMethod = string;
export type PaymentMethodKind = 'cash' | 'transfer' | 'debt';

export interface PaymentMethodDef {
  id: string;
  name: string;
  kind: PaymentMethodKind;
  icon: string;
  bank_bin: string | null;
  bank_account: string | null;
  bank_account_name: string | null;
  active: boolean;
  sort_order: number;
}

export interface Order {
  id: string;
  client_uuid: string;
  code: string;
  business_date: string;
  customer_id: string | null;
  status: OrderStatus;
  payment_method: PaymentMethod;
  payment_method_name: string | null;
  subtotal: number;
  discount: number;
  total: number;
  amount_received: number | null;
  change_amount: number | null;
  note: string | null;
  created_by: string | null;
  created_at: string;
  items: OrderItem[];
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  birthday: string | null;
  address: string | null;
  stamps: number;
  reward_available: boolean;
  debt: number;
  note: string | null;
  created_at: string;
  recent_orders?: Order[];
}

export interface DebtLog {
  id: string;
  amount: number; // dương = ghi nợ thêm, âm = thu nợ
  balance_after: number;
  note: string | null;
  created_by: string | null;
  created_at: string;
}

// Khoản thu/chi của quán: gồm khoản THỦ CÔNG (nhập hàng, mặt bằng, lương...)
// và khoản TỰ ĐỘNG (doanh thu đơn đã thu tiền, thu nợ) — xem ref_type.
export type CashbookType = 'thu' | 'chi';

// Nguồn gốc của khoản thu/chi trong sổ quỹ
export type FundRefType = 'manual' | 'order' | 'debt_pay';

export interface CashbookEntry {
  id: string;
  type: CashbookType;
  amount: number; // > 0
  note: string | null;
  category: string;
  fund_id: string; // quỹ, mặc định 'cash' (Quỹ quán)
  ref_type: FundRefType; // 'manual' = nhập tay; 'order' = từ đơn bán; 'debt_pay' = thu nợ
  ref_id: string | null; // orderId (order) | customerId (debt_pay) | null (manual)
  ref_code: string | null; // mã đơn (A001) cho ref_type='order' — hiện ở Sổ quỹ, bấm để xem đơn
  method: 'cash' | 'transfer' | null; // phương thức của khoản tự động
  created_by: string | null;
  created_at: string; // ISO
}

// Danh mục thu/chi của Sổ quỹ (lưu ở settings/fund_categories)
export interface FundCategories {
  thu: string[];
  chi: string[];
}

// Quỹ tiền — MỖI PHƯƠNG THỨC THANH TOÁN (trừ Ghi nợ) LÀ MỘT QUỸ.
// Danh sách quỹ được đồng bộ từ payment_methods: thêm/sửa/ẩn phương thức
// ở Cài đặt thì quỹ tự theo. Số dư đầu kỳ lưu ở settings/funds.
// fund_id trên CashbookEntry = id phương thức thanh toán.
export interface Fund {
  id: string; // = id phương thức thanh toán
  payment_method_id: string;
  kind: 'cash' | 'transfer'; // loại phương thức (không bao gồm ghi nợ)
  name: string; // theo tên phương thức thanh toán
  opening_balance: number;
  opening_date: string; // YYYY-MM-DD
  active: boolean; // theo trạng thái phương thức thanh toán
  sort_order: number;
}

// Cài đặt quỹ (lưu ở settings/fund)
export interface FundSettings {
  fund_name: string;
  opening_balance: number;
  opening_date: string; // YYYY-MM-DD
}

export interface DailyReport {
  date: string;
  revenue: number;
  profit: number; // lợi nhuận = doanh thu − giá vốn
  order_count: number;
  by_payment: Record<string, { name: string; count: number; revenue: number }>;
  top_products: { product_id: string; name: string; qty: number; revenue: number; profit: number }[];
  by_hour: { hour: number; count: number; revenue: number }[];
}

export interface ApiErrorBody {
  error: { code: string; message: string };
}
