// Auth qua Firebase Authentication (Email/Password) — gói Spark miễn phí.
// Hồ sơ user (full_name, role) đọc từ Firestore users/{uid}.
import { createContext, useCallback, useContext, useEffect, useState } from 'react';
import type { ReactNode } from 'react';
import { onAuthStateChanged, signInWithEmailAndPassword, signOut } from 'firebase/auth';
import { doc, getDoc, FirestoreError } from 'firebase/firestore';
import { auth, db } from './firebase';
import { DbError, toDbError } from './db';
import type { User } from './types';

interface AuthCtx {
  user: User | null;
  /** UID đã đăng nhập Auth nhưng chưa có hồ sơ trong Firestore (đang ở màn hình /setup). */
  pendingUid: string | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  /** Đọc lại hồ sơ Firestore cho user hiện tại (dùng sau khi hoàn tất setup). */
  refresh: () => Promise<void>;
  isOwner: boolean;
  ready: boolean;
}

const Ctx = createContext<AuthCtx | null>(null);

function authErrorToDbError(e: unknown): DbError {
  if (e instanceof FirestoreError) return toDbError(e);
  const code = (e as { code?: string } | null)?.code ?? '';
  switch (code) {
    case 'auth/invalid-credential':
    case 'auth/user-not-found':
    case 'auth/wrong-password':
      return new DbError('auth/invalid-credential', 'Email hoặc mật khẩu không đúng.');
    case 'auth/invalid-email':
      return new DbError('auth/invalid-email', 'Email không hợp lệ.');
    case 'auth/too-many-requests':
      return new DbError('auth/too-many-requests', 'Đăng nhập sai quá nhiều lần. Thử lại sau ít phút.');
    case 'auth/network-request-failed':
      return new DbError('unavailable', 'Mất kết nối mạng. Vui lòng kiểm tra internet rồi thử lại.');
    default:
      return new DbError('unknown', e instanceof Error ? e.message : 'Đăng nhập thất bại.');
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [pendingUid, setPendingUid] = useState<string | null>(null);
  const [ready, setReady] = useState(false);

  const loadProfile = useCallback(async (uid: string, email: string | null): Promise<boolean> => {
    const snap = await getDoc(doc(db, 'users', uid));
    if (!snap.exists()) return false;
    const d = snap.data();
    setUser({
      id: uid,
      email: email ?? String(d.email ?? ''),
      full_name: String(d.full_name ?? ''),
      role: d.role === 'owner' ? 'owner' : 'staff',
    });
    setPendingUid(null);
    return true;
  }, []);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (fbUser) => {
      try {
        if (!fbUser) {
          setUser(null);
          setPendingUid(null);
          return;
        }
        // Tài khoản Auth tồn tại nhưng chưa có hồ sơ Firestore → giữ đăng nhập,
        // chuyển sang màn hình /setup để hoàn tất (không tự đăng xuất nữa).
        const ok = await loadProfile(fbUser.uid, fbUser.email);
        if (!ok) setPendingUid(fbUser.uid);
      } catch {
        setUser(null);
        setPendingUid(null);
      } finally {
        setReady(true);
      }
    });
    return unsub;
  }, [loadProfile]);

  const login = useCallback(
    async (email: string, password: string) => {
      try {
        await signInWithEmailAndPassword(auth, email.trim(), password);
        // Hồ sơ sẽ được nạp qua onAuthStateChanged (hoặc chuyển sang /setup nếu chưa có).
      } catch (e) {
        throw authErrorToDbError(e);
      }
    },
    [],
  );

  const refresh = useCallback(async () => {
    const fbUser = auth.currentUser;
    if (!fbUser) return;
    await loadProfile(fbUser.uid, fbUser.email);
  }, [loadProfile]);

  const logout = useCallback(() => {
    void signOut(auth);
    setUser(null);
    setPendingUid(null);
  }, []);

  return (
    <Ctx.Provider value={{ user, pendingUid, login, logout, refresh, isOwner: user?.role === 'owner', ready }}>
      {children}
    </Ctx.Provider>
  );
}

export function useAuth(): AuthCtx {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error('useAuth phải dùng trong AuthProvider');
  return ctx;
}
