import { useState } from 'react';

// Icon 3D vẽ riêng cho Beesy POS — file webp nằm ở public/icons/.
// Dùng: <AppIcon name="receipt" size={22} fallback="🧾" />
const FILES: Record<string, string> = {
  chart: 'chart.webp',
  receipt: 'receipt.webp',
  package: 'package.webp',
  chef: 'chef.webp',
  ledger: 'ledger.webp',
  moneybag: 'moneybag.webp',
  clipboard: 'clipboard.webp',
  archive: 'archive.webp',
  users: 'users.webp',
  gear: 'gear.webp',
  gift: 'gift.webp',
  scroll: 'scroll.webp',
  cloud: 'cloud.webp',
  card: 'card.webp',
};

export type AppIconName = keyof typeof FILES;

export default function AppIcon({
  name,
  size = 22,
  fallback,
  style,
}: {
  name: AppIconName | string;
  size?: number;
  fallback?: string;
  style?: React.CSSProperties;
}) {
  const [err, setErr] = useState(false);
  const file = FILES[name];
  if (!file || err) {
    return (
      <span style={{ fontSize: size, lineHeight: 1, ...style }} aria-hidden>
        {fallback ?? '▦'}
      </span>
    );
  }
  return (
    <img
      src={`/icons/${file}`}
      alt=""
      width={size}
      height={size}
      draggable={false}
      onError={() => setErr(true)}
      style={{ width: size, height: size, objectFit: 'contain', display: 'block', ...style }}
    />
  );
}
