import { useState } from 'react';
import type { FormEvent } from 'react';
import { DbError, createCustomer, searchCustomers } from '../lib/db';
import { useToast } from './Toast';
import { Sheet } from './Sheet';
import type { Customer } from '../lib/types';

// Sheet chọn khách hàng cho đơn: tìm theo tên/SĐT + thêm nhanh khách mới.
export function CustomerPickSheet({ onClose, onPick, warehouseId }: { onClose: () => void; onPick: (c: Customer) => void; warehouseId?: string | null }) {
  const toast = useToast();
  const [q, setQ] = useState('');
  const [list, setList] = useState<Customer[]>([]);
  const [busy, setBusy] = useState(false);
  const [searched, setSearched] = useState(false);
  // Form thêm nhanh khách mới
  const [adding, setAdding] = useState(false);
  const [newName, setNewName] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [saving, setSaving] = useState(false);

  const search = async () => {
    setBusy(true);
    try {
      const data = await searchCustomers(q.trim());
      setList(
        data.filter((c) => !warehouseId || !c.warehouse_id || c.warehouse_id === warehouseId),
      );
      setSearched(true);
      if (data.length === 0) toast.show('Không tìm thấy khách hàng');
    } catch {
      toast.show('Không tìm được, kiểm tra mạng');
    } finally {
      setBusy(false);
    }
  };

  const openQuickAdd = () => {
    // Đoán: nhập toàn số → SĐT, ngược lại → tên
    const digits = q.replace(/\D/g, '');
    if (digits.length >= 8 && digits.length === q.replace(/\s/g, '').length) {
      setNewPhone(digits);
      setNewName('');
    } else {
      setNewName(q.trim());
      setNewPhone('');
    }
    setAdding(true);
  };

  const quickAdd = async (e: FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newPhone.trim()) {
      toast.show('Nhập tên và số điện thoại của khách');
      return;
    }
    setSaving(true);
    try {
      const created = await createCustomer({ name: newName.trim(), phone: newPhone.trim(), warehouse_id: warehouseId || null });
      toast.show(`Đã thêm khách: ${created.name}`);
      onPick(created);
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Thêm khách thất bại');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Sheet title="👤 Chọn khách hàng" onClose={onClose}>
      {adding ? (
        <form onSubmit={quickAdd}>
          <p className="small muted" style={{ marginTop: 0 }}>
            Thêm nhanh khách mới — xong sẽ tự chọn luôn để tích tem cho đơn này.
          </p>
          <div className="field">
            <label>Tên khách hàng</label>
            <input className="input" value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="VD: Lan" autoFocus />
          </div>
          <div className="field">
            <label>Số điện thoại</label>
            <input className="input" inputMode="tel" value={newPhone} onChange={(e) => setNewPhone(e.target.value)} placeholder="VD: 0901234567" />
          </div>
          <div className="row" style={{ gap: 8 }}>
            <button type="submit" className="btn grow" disabled={saving}>
              {saving ? 'Đang lưu…' : '✅ Lưu & chọn khách này'}
            </button>
            <button type="button" className="btn btn-ghost" onClick={() => setAdding(false)}>
              Quay lại
            </button>
          </div>
          <p className="small muted">Muốn nhập thêm ngày sinh, địa chỉ: vào mục Khách hàng sau.</p>
        </form>
      ) : (
        <>
          <div className="row" style={{ marginBottom: 12 }}>
            <input
              className="input grow"
              placeholder="Nhập tên hoặc SĐT…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && search()}
            />
            <button className="btn" onClick={search} disabled={busy}>
              Tìm
            </button>
          </div>
          {list.map((c) => (
            <button
              key={c.id}
              className="btn btn-outline btn-block"
              style={{ marginBottom: 8, justifyContent: 'flex-start' }}
              onClick={() => onPick(c)}
            >
              <span className="grow" style={{ textAlign: 'left' }}>
                <b>{c.name}</b> · {c.phone}
                <br />
                <span className="small muted">🎟️ {c.stamps} tem{c.reward_available ? ' · có quà tặng!' : ''}</span>
              </span>
            </button>
          ))}
          {searched && (
            <button className="btn btn-block btn-outline" style={{ marginTop: 4 }} onClick={openQuickAdd}>
              ➕ Thêm khách hàng mới
            </button>
          )}
        </>
      )}
    </Sheet>
  );
}
