import { useState } from 'react';
import { useToast } from './Toast';
import type { Order } from '../lib/types';
import {
  connectPrinter,
  getPrinterName,
  isBluetoothSupported,
  isPrinterConnected,
  printReceipt,
} from '../lib/printer';

/** Nút in bill qua máy in nhiệt Bluetooth (XPrinter/ESC-POS). */
export function BluetoothPrintButton({
  order,
  shopName = 'Beesy Coffee & Tea',
}: {
  order: Order;
  shopName?: string;
}) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const [printer, setPrinter] = useState<string | null>(() => getPrinterName());
  const supported = isBluetoothSupported();

  const doPrint = async () => {
    if (!supported) {
      window.print();
      return;
    }
    setBusy(true);
    try {
      if (!isPrinterConnected()) {
        const name = await connectPrinter();
        setPrinter(name);
        toast.show(`Đã kết nối ${name}`);
      }
      await printReceipt({
        shopName,
        orderCode: order.code,
        createdAt: order.created_at,
        cashierName: '',
        customerName: null,
        warehouseName: order.warehouse_name,
        items: order.items.map((it) => ({
          name: it.product_name,
          qty: it.qty,
          unitPrice: it.unit_price,
          lineTotal: it.line_total,
          note: it.modifiers.length > 0 ? it.modifiers.map((m) => m.option).join(', ') : undefined,
        })),
        subtotal: order.subtotal,
        discount: order.discount,
        discountLabel: order.discount_label,
        total: order.total,
        paymentMethodName: order.payment_method_name ?? '',
        amountReceived: order.amount_received,
        changeAmount: order.change_amount,
      });
      toast.show('Đã gửi lệnh in');
    } catch (e) {
      setPrinter(null);
      toast.show(e instanceof Error ? e.message : 'In thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <button className="btn btn-outline grow" disabled={busy} onClick={doPrint}>
      {busy ? 'Đang in…' : printer ? `🖨️ In bill (${printer})` : '🖨️ In bill'}
    </button>
  );
}
