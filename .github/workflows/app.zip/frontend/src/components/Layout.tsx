import { useCallback, useEffect, useState } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../lib/auth';
import type { ActionKey } from '../lib/permissions';
import { ROLE_LABELS } from '../lib/permissions';
import { getSettings } from '../lib/db';
import { useOnlineStatus } from '../lib/offline';
import { useToast } from './Toast';
import { Sheet } from './Sheet';
import AppIcon, { type AppIconName } from './AppIcon';
import type { ReactNode } from 'react';

// Sidebar bản web: nhóm điều hướng theo phong cách Sổ Bán Hàng
interface NavItem { to: string; icon: AppIconName; fb: string; label: string; action: ActionKey }
interface NavGroup { title: string; items: NavItem[] }

const NAV_GROUPS: NavGroup[] = [
  {
    title: 'TỔNG QUAN',
    items: [{ to: '/reports', icon: 'chart', fb: '📊', label: 'Tổng quan', action: 'reports' }],
  },
  {
    title: 'BÁN HÀNG',
    items: [
      { to: '/pos', icon: 'receipt', fb: '🧾', label: 'Bán hàng', action: 'pos' },
      { to: '/orders', icon: 'package', fb: '📦', label: 'Đơn hàng', action: 'orders.view' },
      { to: '/kds', icon: 'chef', fb: '👨‍🍳', label: 'Pha chế', action: 'kds' },
    ],
  },
  {
    title: 'SỔ SÁCH',
    items: [
      { to: '/debt', icon: 'ledger', fb: '📒', label: 'Sổ nợ', action: 'debt' },
      { to: '/so-quy', icon: 'moneybag', fb: '💰', label: 'Sổ quỹ', action: 'cashbook' },
    ],
  },
  {
    title: 'HÀNG HÓA',
    items: [
      { to: '/menu', icon: 'clipboard', fb: '📋', label: 'Menu', action: 'menu' },
      { to: '/inventory', icon: 'archive', fb: '🗃️', label: 'Tồn kho', action: 'inventory' },
    ],
  },
  { title: 'KHÁCH HÀNG', items: [{ to: '/customers', icon: 'users', fb: '👥', label: 'Khách hàng', action: 'customers' }] },
  { title: 'HỆ THỐNG', items: [{ to: '/settings', icon: 'gear', fb: '⚙️', label: 'Cài đặt', action: 'settings' }] },
];

// Bottom tab bar bản mobile: 5 mục chính (lọc theo quyền)
const MOBILE_TABS: NavItem[] = [
  { to: '/reports', icon: 'chart', fb: '📊', label: 'Tổng quan', action: 'reports' },
  { to: '/pos', icon: 'receipt', fb: '🧾', label: 'Bán hàng', action: 'pos' },
  { to: '/customers', icon: 'users', fb: '👥', label: 'Khách', action: 'customers' },
  { to: '/menu', icon: 'clipboard', fb: '📋', label: 'Menu', action: 'menu' },
  { to: '/settings', icon: 'gear', fb: '⚙️', label: 'Cài đặt', action: 'settings' },
];

// Các mục còn lại trên mobile nằm trong menu "Thêm"
const MORE_LINKS: NavItem[] = [
  { to: '/orders', icon: 'package', fb: '📦', label: 'Đơn hàng', action: 'orders.view' },
  { to: '/debt', icon: 'ledger', fb: '📒', label: 'Sổ nợ', action: 'debt' },
  { to: '/so-quy', icon: 'moneybag', fb: '💰', label: 'Sổ quỹ', action: 'cashbook' },
  { to: '/kds', icon: 'chef', fb: '👨‍🍳', label: 'Pha chế', action: 'kds' },
  { to: '/inventory', icon: 'archive', fb: '🗃️', label: 'Tồn kho', action: 'inventory' },
];

function SideNav() {
  const { can } = useAuth();
  const groups = NAV_GROUPS.map((g) => ({ ...g, items: g.items.filter((n) => can(n.action)) })).filter(
    (g) => g.items.length > 0,
  );
  return (
    <>
      {groups.map((g) => (
        <div className="nav-group" key={g.title}>
          <div className="nav-group-title">{g.title}</div>
          {g.items.map((n) => (
            <NavLink key={n.to} to={n.to} className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}>
              <span className="ico"><AppIcon name={n.icon} fallback={n.fb} size={22} /></span>
              <span>{n.label}</span>
            </NavLink>
          ))}
        </div>
      ))}
    </>
  );
}

export function Layout({ children }: { children?: ReactNode }) {
  const { user, logout, can } = useAuth();
  const mobileTabs = MOBILE_TABS.filter((n) => can(n.action));
  const moreLinks = MORE_LINKS.filter((l) => can(l.action));
  const navigate = useNavigate();
  const toast = useToast();
  const [shopName, setShopName] = useState('Beesy POS');
  const [moreOpen, setMoreOpen] = useState(false);
  const onSynced = useCallback(
    (r: { ok: number; fail: number }) => {
      if (r.ok > 0) toast.show(`Đã đồng bộ ${r.ok} đơn chờ lên server`);
    },
    [toast],
  );
  const { online, pending } = useOnlineStatus(onSynced);

  useEffect(() => {
    getSettings()
      .then((s) => {
        if (s.shop_name) setShopName(s.shop_name);
      })
      .catch(() => {});
  }, []);

  const doLogout = async () => {
    setMoreOpen(false);
    await logout();
    navigate('/login');
  };

  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="nav-logo">
          <img src="/coffee-cup.svg" alt="Beesy" />
          <span>Beesy POS</span>
        </div>
        <SideNav />
      </aside>
      <div className="main">
        {!online && (
          <div className="offline-banner">
            ⚠️ Đang offline{pending > 0 ? ` — ${pending} đơn chờ đồng bộ` : ' — vẫn bán được, đơn sẽ tự đồng bộ khi có mạng'}
          </div>
        )}
        {online && pending > 0 && <div className="offline-banner online">⏳ Đang đồng bộ {pending} đơn chờ…</div>}
        <header className="topbar">
          <span className="shop-name">{shopName}</span>
          <span className="spacer" />
          <span className="user-chip">
            {user ? `${user.full_name || user.email} · ${ROLE_LABELS[user.role] ?? user.role}` : ''}
          </span>
          <button className="btn btn-ghost logout-btn" style={{ minHeight: 44, padding: '6px 14px' }} onClick={doLogout}>
            Đăng xuất
          </button>
          <button className="more-btn" onClick={() => setMoreOpen(true)} aria-label="Thêm">
            ☰
          </button>
        </header>
        <main style={{ flex: 1 }}>{children ?? <Outlet />}</main>
      </div>
      <nav className="mobile-nav">
        {mobileTabs.map((n) => (
          <NavLink key={n.to} to={n.to} className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}>
            <span className="ico"><AppIcon name={n.icon} fallback={n.fb} size={22} /></span>
            <span>{n.label}</span>
          </NavLink>
        ))}
      </nav>
      {moreOpen && (
        <Sheet title="☰ Thêm" onClose={() => setMoreOpen(false)}>
          {moreLinks.map((l) => (
            <NavLink key={l.to} to={l.to} className="more-link" onClick={() => setMoreOpen(false)}>
              <span className="ico"><AppIcon name={l.icon} fallback={l.fb} size={22} /></span>
              <span>{l.label}</span>
              <span className="chev">›</span>
            </NavLink>
          ))}
          <button className="btn btn-ghost btn-block" style={{ marginTop: 12 }} onClick={doLogout}>
            Đăng xuất
          </button>
        </Sheet>
      )}
    </div>
  );
}
