import { useCallback, useEffect, useState } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../lib/auth';
import { getSettings } from '../lib/db';
import { useOnlineStatus } from '../lib/offline';
import { useToast } from './Toast';
import type { ReactNode } from 'react';

const NAV = [
  { to: '/pos', ico: '🧾', label: 'Bán hàng' },
  { to: '/kds', ico: '👨‍🍳', label: 'Pha chế' },
  { to: '/menu', ico: '📋', label: 'Menu' },
  { to: '/customers', ico: '👥', label: 'Khách' },
  { to: '/reports', ico: '📊', label: 'Báo cáo' },
  { to: '/settings', ico: '⚙️', label: 'Cài đặt' },
];

function NavLinks() {
  return (
    <>
      {NAV.map((n) => (
        <NavLink key={n.to} to={n.to} className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}>
          <span className="ico">{n.ico}</span>
          <span>{n.label}</span>
        </NavLink>
      ))}
    </>
  );
}

export function Layout({ children }: { children?: ReactNode }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const toast = useToast();
  const [shopName, setShopName] = useState('Beesy POS');
  const onSynced = useCallback(
    (r: { ok: number; fail: number }) => {
      if (r.ok > 0) toast.show(`Đã đồng bộ ${r.ok} đơn chờ lên server`);
    },
    [toast],
  );
  const { online, pending } = useOnlineStatus(onSynced);

  useEffect(() => {
    getSettings()
      .then((s) => {
        if (s.shop_name) setShopName(s.shop_name);
      })
      .catch(() => {});
  }, []);

  const doLogout = async () => {
    await logout();
    navigate('/login');
  };

  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="nav-logo">
          <img src="/coffee-cup.svg" alt="Beesy" />
        </div>
        <NavLinks />
      </aside>
      <div className="main">
        {!online && (
          <div className="offline-banner">
            ⚠️ Đang offline{pending > 0 ? ` — ${pending} đơn chờ đồng bộ` : ' — vẫn bán được, đơn sẽ tự đồng bộ khi có mạng'}
          </div>
        )}
        {online && pending > 0 && <div className="offline-banner online">⏳ Đang đồng bộ {pending} đơn chờ…</div>}
        <header className="topbar">
          <span className="shop-name">{shopName}</span>
          <span className="spacer" />
          <span className="user-chip">
            {user ? `${user.full_name || user.email} · ${user.role === 'owner' ? 'Chủ quán' : 'Nhân viên'}` : ''}
          </span>
          <button className="btn btn-ghost" style={{ minHeight: 44, padding: '6px 14px' }} onClick={doLogout}>
            Đăng xuất
          </button>
        </header>
        <main style={{ flex: 1 }}>{children ?? <Outlet />}</main>
      </div>
      <nav className="mobile-nav">
        <NavLinks />
      </nav>
    </div>
  );
}
