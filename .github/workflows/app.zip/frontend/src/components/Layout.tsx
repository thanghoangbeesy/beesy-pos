import { useCallback, useEffect, useState } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../lib/auth';
import { getSettings } from '../lib/db';
import { useOnlineStatus } from '../lib/offline';
import { useToast } from './Toast';
import { Sheet } from './Sheet';
import type { ReactNode } from 'react';

// Sidebar bản web: nhóm điều hướng theo phong cách Sổ Bán Hàng
const NAV_GROUPS = [
  {
    title: 'BÁN HÀNG',
    items: [
      { to: '/pos', ico: '🧾', label: 'Bán hàng' },
      { to: '/kds', ico: '👨‍🍳', label: 'Pha chế' },
    ],
  },
  { title: 'HÀNG HÓA', items: [{ to: '/menu', ico: '📋', label: 'Menu' }] },
  { title: 'KHÁCH HÀNG', items: [{ to: '/customers', ico: '👥', label: 'Khách' }] },
  { title: 'TÀI CHÍNH', items: [{ to: '/reports', ico: '📊', label: 'Báo cáo' }] },
  { title: 'HỆ THỐNG', items: [{ to: '/settings', ico: '⚙️', label: 'Cài đặt' }] },
];

// Bottom tab bar bản mobile: đúng 4 mục
const MOBILE_TABS = [
  { to: '/pos', ico: '🧾', label: 'Bán hàng' },
  { to: '/menu', ico: '📋', label: 'Menu & kho' },
  { to: '/reports', ico: '📊', label: 'Báo cáo' },
  { to: '/settings', ico: '⚙️', label: 'Cài đặt' },
];

// Các mục còn lại trên mobile nằm trong menu "Thêm"
const MORE_LINKS = [
  { to: '/kds', ico: '👨‍🍳', label: 'Pha chế' },
  { to: '/customers', ico: '👥', label: 'Khách hàng' },
];

function SideNav() {
  return (
    <>
      {NAV_GROUPS.map((g) => (
        <div className="nav-group" key={g.title}>
          <div className="nav-group-title">{g.title}</div>
          {g.items.map((n) => (
            <NavLink key={n.to} to={n.to} className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}>
              <span className="ico">{n.ico}</span>
              <span>{n.label}</span>
            </NavLink>
          ))}
        </div>
      ))}
    </>
  );
}

export function Layout({ children }: { children?: ReactNode }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const toast = useToast();
  const [shopName, setShopName] = useState('Beesy POS');
  const [moreOpen, setMoreOpen] = useState(false);
  const onSynced = useCallback(
    (r: { ok: number; fail: number }) => {
      if (r.ok > 0) toast.show(`Đã đồng bộ ${r.ok} đơn chờ lên server`);
    },
    [toast],
  );
  const { online, pending } = useOnlineStatus(onSynced);

  useEffect(() => {
    getSettings()
      .then((s) => {
        if (s.shop_name) setShopName(s.shop_name);
      })
      .catch(() => {});
  }, []);

  const doLogout = async () => {
    setMoreOpen(false);
    await logout();
    navigate('/login');
  };

  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="nav-logo">
          <img src="/coffee-cup.svg" alt="Beesy" />
          <span>Beesy POS</span>
        </div>
        <SideNav />
      </aside>
      <div className="main">
        {!online && (
          <div className="offline-banner">
            ⚠️ Đang offline{pending > 0 ? ` — ${pending} đơn chờ đồng bộ` : ' — vẫn bán được, đơn sẽ tự đồng bộ khi có mạng'}
          </div>
        )}
        {online && pending > 0 && <div className="offline-banner online">⏳ Đang đồng bộ {pending} đơn chờ…</div>}
        <header className="topbar">
          <span className="shop-name">{shopName}</span>
          <span className="spacer" />
          <span className="user-chip">
            {user ? `${user.full_name || user.email} · ${user.role === 'owner' ? 'Chủ quán' : 'Nhân viên'}` : ''}
          </span>
          <button className="btn btn-ghost logout-btn" style={{ minHeight: 44, padding: '6px 14px' }} onClick={doLogout}>
            Đăng xuất
          </button>
          <button className="more-btn" onClick={() => setMoreOpen(true)} aria-label="Thêm">
            ☰
          </button>
        </header>
        <main style={{ flex: 1 }}>{children ?? <Outlet />}</main>
      </div>
      <nav className="mobile-nav">
        {MOBILE_TABS.map((n) => (
          <NavLink key={n.to} to={n.to} className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}>
            <span className="ico">{n.ico}</span>
            <span>{n.label}</span>
          </NavLink>
        ))}
      </nav>
      {moreOpen && (
        <Sheet title="☰ Thêm" onClose={() => setMoreOpen(false)}>
          {MORE_LINKS.map((l) => (
            <NavLink key={l.to} to={l.to} className="more-link" onClick={() => setMoreOpen(false)}>
              <span className="ico">{l.ico}</span>
              <span>{l.label}</span>
              <span className="chev">›</span>
            </NavLink>
          ))}
          <button className="btn btn-ghost btn-block" style={{ marginTop: 12 }} onClick={doLogout}>
            Đăng xuất
          </button>
        </Sheet>
      )}
    </div>
  );
}
