import type { ReactNode } from 'react';

// Bottom-sheet dùng chung cho Modifier / Checkout / form
export function Sheet({
  title,
  onClose,
  children,
  footer,
}: {
  title: string;
  onClose: () => void;
  children: ReactNode;
  footer?: ReactNode;
}) {
  return (
    <div
      className="sheet-backdrop"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="sheet" role="dialog" aria-modal="true">
        <div className="sheet-handle" />
        <h3 className="sheet-title">
          <span>{title}</span>
          <button className="btn btn-ghost" style={{ minHeight: 44, padding: '6px 14px' }} onClick={onClose} aria-label="Đóng">
            ✕
          </button>
        </h3>
        <div>{children}</div>
        {footer && <div className="sheet-footer">{footer}</div>}
      </div>
    </div>
  );
}
