// Màn hình Thiết lập lần đầu — chạy 100% trên điện thoại, không cần máy tính.
// Luồng: tạo tài khoản chủ quán (Auth) → nhận quyền owner (ghi meta/owner_claimed
// + users/{uid}) → nạp menu mẫu → vào bán hàng.
import { useEffect, useState } from 'react';
import type { FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { doc, getDoc, serverTimestamp, writeBatch } from 'firebase/firestore';
import { auth, db } from '../lib/firebase';
import { useAuth } from '../lib/auth';
import { DbError, toDbError } from '../lib/db';
import {
  SEED_CATEGORIES,
  SEED_MODIFIER_GROUPS,
  SEED_MODIFIER_OPTIONS,
  SEED_PRODUCTS,
  SEED_SETTINGS,
} from '../lib/seed-data';

type Step = 'account' | 'claim' | 'seed' | 'done';

export function Setup() {
  const { user, pendingUid, refresh, logout, ready } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState<Step>('account');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [seeded, setSeeded] = useState(false);

  // Tự nhận diện trạng thái khi auth sẵn sàng
  useEffect(() => {
    if (!ready) return;
    if (user?.role === 'owner') setStep('seed');
    else if (user) setStep('done'); // staff: không có gì để setup
    else if (pendingUid) setStep('claim');
    else setStep('account');
  }, [ready, user, pendingUid]);

  const submitAccount = async (e: FormEvent) => {
    e.preventDefault();
    if (!email.trim() || password.length < 6 || !fullName.trim()) {
      setErr('Vui lòng nhập tên quán/chủ quán, email và mật khẩu (tối thiểu 6 ký tự).');
      return;
    }
    setBusy(true);
    setErr('');
    try {
      await createUserWithEmailAndPassword(auth, email.trim(), password);
      // onAuthStateChanged sẽ đặt pendingUid → useEffect chuyển sang bước claim
    } catch (ex) {
      const code = (ex as { code?: string })?.code ?? '';
      setErr(
        code === 'auth/email-already-in-use'
          ? 'Email này đã được đăng ký. Hãy đăng nhập rồi quay lại trang này.'
          : code === 'auth/invalid-email'
            ? 'Email không hợp lệ.'
            : code === 'auth/weak-password'
              ? 'Mật khẩu quá yếu (tối thiểu 6 ký tự).'
              : 'Tạo tài khoản thất bại. Kiểm tra kết nối mạng rồi thử lại.',
      );
    } finally {
      setBusy(false);
    }
  };

  const claimOwner = async () => {
    const uid = auth.currentUser?.uid ?? pendingUid;
    if (!uid) {
      setErr('Phiên đăng nhập hết hạn. Vui lòng đăng nhập lại.');
      return;
    }
    setBusy(true);
    setErr('');
    try {
      // Kiểm tra đã có chủ quán chưa để báo lỗi thân thiện trước khi ghi
      const claimed = await getDoc(doc(db, 'meta', 'owner_claimed'));
      if (claimed.exists()) {
        setErr('Quán này đã được thiết lập chủ quán. Hãy liên hệ chủ quán để được thêm tài khoản.');
        setBusy(false);
        return;
      }
      const batch = writeBatch(db);
      batch.set(doc(db, 'meta', 'owner_claimed'), {
        by: uid,
        claimed_at: serverTimestamp(),
      });
      batch.set(doc(db, 'users', uid), {
        id: uid,
        email: auth.currentUser?.email ?? email.trim(),
        full_name: fullName.trim() || 'Chủ quán',
        role: 'owner',
      });
      await batch.commit();
      await refresh();
      setStep('seed');
    } catch (ex) {
      setErr(ex instanceof DbError ? ex.message : `Nhận quyền thất bại: ${toDbError(ex).message}`);
    } finally {
      setBusy(false);
    }
  };

  const seedMenu = async () => {
    setBusy(true);
    setErr('');
    try {
      const batch = writeBatch(db);
      const put = (col: string, id: string, data: Record<string, unknown>) =>
        batch.set(doc(db, col, id), { id, ...data }, { merge: true });
      for (const [key, value] of Object.entries(SEED_SETTINGS)) put('settings', key, { key, value });
      for (const c of SEED_CATEGORIES) put('categories', c.id, { ...c, active: true });
      for (const g of SEED_MODIFIER_GROUPS) put('modifierGroups', g.id, { ...g, active: true });
      for (const o of SEED_MODIFIER_OPTIONS) put('modifierOptions', o.id, { ...o, active: true });
      for (const p of SEED_PRODUCTS)
        put('products', p.id, { ...p, image_url: null, active: true });
      await batch.commit();
      setSeeded(true);
      setStep('done');
    } catch (ex) {
      setErr(`Nạp menu mẫu thất bại: ${toDbError(ex).message}`);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="login-wrap">
      <div className="card login-card">
        <div className="login-logo">
          <img src="/coffee-cup.svg" alt="Beesy Coffee & Tea" />
          <h1>Thiết lập quán mới</h1>
          <div className="muted">Chỉ làm một lần duy nhất, ngay trên điện thoại</div>
        </div>
        {err && <div className="err">{err}</div>}

        {step === 'account' && (
          <form onSubmit={submitAccount}>
            <div className="field">
              <label htmlFor="s-name">Tên chủ quán</label>
              <input
                id="s-name"
                className="input"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="VD: Hoàng"
              />
            </div>
            <div className="field">
              <label htmlFor="s-email">Email đăng nhập</label>
              <input
                id="s-email"
                className="input"
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="VD: chuquan@gmail.com"
              />
            </div>
            <div className="field">
              <label htmlFor="s-pass">Mật khẩu (≥ 6 ký tự)</label>
              <input
                id="s-pass"
                type="password"
                className="input"
                autoComplete="new-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••"
              />
            </div>
            <button type="submit" className="btn btn-block btn-lg" disabled={busy}>
              {busy ? 'Đang tạo…' : '1️⃣ Tạo tài khoản chủ quán'}
            </button>
            <p className="muted small" style={{ marginTop: 12, textAlign: 'center' }}>
              Đã có tài khoản? <Link to="/login">Đăng nhập</Link>
            </p>
          </form>
        )}

        {step === 'claim' && (
          <>
            <p>
              Tài khoản <b>{auth.currentUser?.email}</b> đã được tạo. Bấm nút dưới đây để nhận quyền{' '}
              <b>chủ quán</b> (chỉ người đầu tiên mới nhận được).
            </p>
            <button className="btn btn-block btn-lg" onClick={claimOwner} disabled={busy}>
              {busy ? 'Đang xử lý…' : '2️⃣ Nhận quyền chủ quán'}
            </button>
            <button
              className="btn btn-block btn-ghost"
              style={{ marginTop: 8 }}
              onClick={() => {
                logout();
                setStep('account');
              }}
            >
              Dùng email khác
            </button>
          </>
        )}

        {step === 'seed' && (
          <>
            <p>
              🎉 Xin chào <b>{user?.full_name || 'chủ quán'}</b>! Quán đã có chủ. Giờ hãy nạp menu mẫu
              (12 món cà phê/trà/trà sữa + size/topping) — anh có thể sửa lại sau trong mục Menu.
            </p>
            <button className="btn btn-block btn-lg" onClick={seedMenu} disabled={busy}>
              {busy ? 'Đang nạp…' : '3️⃣ Nạp menu mẫu'}
            </button>
            <button
              className="btn btn-block btn-ghost"
              style={{ marginTop: 8 }}
              onClick={() => navigate('/pos', { replace: true })}
            >
              Bỏ qua, tự tạo menu sau
            </button>
          </>
        )}

        {step === 'done' && (
          <>
            {user?.role === 'owner' ? (
              <>
                <p>
                  ✅ Thiết lập hoàn tất{seeded ? ' — đã nạp menu mẫu' : ''}. Giờ anh có thể bắt đầu bán
                  hàng ngay trên điện thoại.
                </p>
                <button className="btn btn-block btn-lg" onClick={() => navigate('/pos', { replace: true })}>
                  🛒 Vào màn hình bán hàng
                </button>
                <p className="muted small" style={{ marginTop: 12 }}>
                  Nhớ việc: vào Cài đặt để điền số tài khoản nhận VietQR và bật sao lưu Google Drive.
                </p>
              </>
            ) : (
              <>
                <p>Tài khoản này không phải chủ quán nên không cần thiết lập gì thêm.</p>
                <button className="btn btn-block" onClick={() => navigate('/pos', { replace: true })}>
                  Vào màn hình bán hàng
                </button>
              </>
            )}
          </>
        )}
      </div>
    </div>
  );
}
