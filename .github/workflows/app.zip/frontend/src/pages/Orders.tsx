// Đơn hàng — xem / sửa / xóa các đơn đã bán.
// Sửa: chỉ ghi chú + khách hàng (không sửa món/giá để báo cáo không sai).
// Xóa: chỉ chủ quán; đơn ghi nợ được hoàn công nợ, khoản quỹ tự động của đơn bị xóa theo.
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  DbError,
  deleteOrder,
  getAllowedWarehouses,
  getOrder,
  listOrders,
  listPaymentMethods,
  searchCustomers,
  updateOrderMeta,
} from '../lib/db';
import {
  addDaysVN,
  formatDMY,
  formatTime,
  formatVND,
  startOfMonthVN,
  todayVN,
  unsignVietnamese,
} from '../lib/format';
import { Sheet } from '../components/Sheet';
import { BluetoothPrintButton } from '../components/BluetoothPrintButton';
import { PageHead } from '../components/PageHead';
import { CustomerPickSheet } from '../components/CustomerPickSheet';
import { useToast } from '../components/Toast';
import { useAuth } from '../lib/auth';
import type { Customer, Order, Warehouse } from '../lib/types';

type FilterKey = 'today' | 'last7' | 'month' | 'all';
const FILTERS: { key: FilterKey; label: string }[] = [
  { key: 'today', label: 'Hôm nay' },
  { key: 'last7', label: '7 ngày qua' },
  { key: 'month', label: 'Tháng này' },
  { key: 'all', label: 'Tất cả' },
];

const STATUS_LABEL: Record<string, string> = {
  new: 'Mới',
  preparing: 'Đang pha',
  ready: 'Sẵn sàng',
  done: 'Hoàn tất',
  cancelled: 'Đã hủy',
};

function rangeOf(key: FilterKey): [string, string] {
  const t = todayVN();
  switch (key) {
    case 'today':
      return [t, t];
    case 'last7':
      return [addDaysVN(t, -6), t];
    case 'month':
      return [startOfMonthVN(t), t];
    case 'all':
      return ['2020-01-01', t];
  }
}

export function Orders() {
  const toast = useToast();
  const { can } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [custMap, setCustMap] = useState<Map<string, Customer>>(new Map());
  const [kindMap, setKindMap] = useState<Map<string, string>>(new Map());
  const [q, setQ] = useState('');
  const [filter, setFilter] = useState<FilterKey>('today');
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [whFilter, setWhFilter] = useState('all');
  const [busy, setBusy] = useState(true);
  const [detailId, setDetailId] = useState<string | null>(null);
  // Đơn được mở qua deep-link (?open=orderId) từ Sổ quỹ — có thể nằm ngoài khoảng lọc hiện tại
  const [deepOrder, setDeepOrder] = useState<Order | null>(null);
  const [searchParams, setSearchParams] = useSearchParams();

  const load = useCallback(
    async (fk: FilterKey, whId: string = 'all') => {
      setBusy(true);
      try {
        const [from, to] = rangeOf(fk);
        const allowed = await getAllowedWarehouses();
        setWarehouses(allowed.warehouses);
        const ids = whId === 'all' ? allowed.warehouses.map((w) => w.id) : [whId];
        const [list, customers, methods] = await Promise.all([
          listOrders({ from, to, warehouseIds: ids }),
          searchCustomers(''),
          listPaymentMethods(false),
        ]);
        setOrders(list);
        setCustMap(new Map(customers.map((c) => [c.id, c])));
        setKindMap(new Map(methods.map((m) => [m.id, m.kind])));
      } catch (e) {
        toast.show(e instanceof DbError ? e.message : 'Không tải được đơn hàng');
      } finally {
        setBusy(false);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [],
  );

  useEffect(() => {
    void load(filter, whFilter);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filter, whFilter]);

  const changeWh = (id: string) => setWhFilter(id);

  // Deep-link từ Sổ quỹ: /orders?open=<orderId> → mở ngay chi tiết đơn
  useEffect(() => {
    const openId = searchParams.get('open');
    if (!openId) return;
    setSearchParams({}, { replace: true });
    getOrder(openId)
      .then((o) => {
        if (!o) {
          toast.show('Không tìm thấy đơn hàng');
          return;
        }
        setDeepOrder(o);
        setDetailId(o.id);
      })
      .catch(() => toast.show('Không mở được đơn hàng'));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const needle = unsignVietnamese(q.trim()).toLowerCase();
  const filtered = useMemo(
    () =>
      orders.filter((o) => {
        if (!needle) return true;
        const c = o.customer_id ? custMap.get(o.customer_id) : undefined;
        const hay = unsignVietnamese(
          `${o.code} ${o.note ?? ''} ${c ? `${c.name} ${c.phone}` : 'khách lẻ'}`,
        ).toLowerCase();
        return hay.includes(needle);
      }),
    [orders, custMap, needle],
  );

  const detail =
    detailId
      ? deepOrder && deepOrder.id === detailId
        ? deepOrder
        : (orders.find((o) => o.id === detailId) ?? null)
      : null;
  const closeDetail = () => {
    setDetailId(null);
    setDeepOrder(null);
  };

  const payPill = (o: Order) => {
    const kind = kindMap.get(o.payment_method) ?? '';
    const label = o.payment_method_name ?? (kind === 'cash' ? 'Tiền mặt' : kind === 'transfer' ? 'Chuyển khoản' : kind === 'debt' ? 'Ghi nợ' : o.payment_method);
    const cls = kind === 'debt' ? 'sb-status-pill warn' : kind === 'transfer' ? 'sb-status-pill info' : 'sb-status-pill';
    return <span className={cls}>{label}</span>;
  };

  return (
    <div className="page">
      <PageHead title="Đơn hàng" back />

      <div className="sb-search" style={{ marginBottom: 12 }}>
        <span className="sico">🔍</span>
        <input
          placeholder="Tìm mã đơn, tên, SĐT khách…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          aria-label="Tìm đơn hàng"
        />
      </div>

      {warehouses.length > 1 && (
        <div className="row" style={{ gap: 8, marginBottom: 12, flexWrap: 'wrap' }}>
          <button className={`sb-chip${whFilter === 'all' ? ' selected' : ''}`} onClick={() => changeWh('all')}>
            Mọi kho
          </button>
          {warehouses.map((w) => (
            <button key={w.id} className={`sb-chip${whFilter === w.id ? ' selected' : ''}`} onClick={() => changeWh(w.id)}>
              {w.name}
            </button>
          ))}
        </div>
      )}

      <div className="row" style={{ gap: 8, marginBottom: 12, flexWrap: 'wrap' }}>
        {FILTERS.map((f) => (
          <button
            key={f.key}
            className={`sb-chip${filter === f.key ? ' selected' : ''}`}
            onClick={() => setFilter(f.key)}
          >
            {f.label}
          </button>
        ))}
      </div>

      <div className="sb-section" style={{ padding: '4px 16px' }}>
        {busy ? (
          <p className="muted" style={{ textAlign: 'center' }}>
            Đang tải…
          </p>
        ) : filtered.length === 0 ? (
          <div className="sb-empty">
            <div className="eico">🧾</div>
            <p>Chưa có đơn hàng nào trong khoảng này.</p>
          </div>
        ) : (
          filtered.map((o) => {
            const c = o.customer_id ? custMap.get(o.customer_id) : undefined;
            return (
              <button key={o.id} className="sb-row" onClick={() => setDetailId(o.id)}>
                <span className="rbody">
                  <span className="rtitle" style={{ fontSize: 16, fontWeight: 600 }}>
                    {o.code}
                    <span className="rsub" style={{ marginLeft: 8, fontWeight: 400 }}>
                      {formatTime(o.created_at)} · {formatDMY(o.business_date)}
                    </span>
                  </span>
                  <span className="rsub">
                    {c ? c.name : 'Khách lẻ'} · {STATUS_LABEL[o.status] ?? o.status}
                  </span>
                </span>
                <span className="rbody" style={{ alignItems: 'flex-end', flex: '0 0 auto' }}>
                  <span className="ramount text-green">{formatVND(o.total)}</span>
                  {payPill(o)}
                </span>
                <span className="chev muted" style={{ fontSize: 22 }}>
                  ›
                </span>
              </button>
            );
          })
        )}
      </div>

      {detail && (
        <OrderDetail
          order={detail}
          customer={detail.customer_id ? custMap.get(detail.customer_id) ?? null : null}
          canEdit={can('orders.edit')}
          canDelete={can('orders.delete')}
          onClose={closeDetail}
          onChanged={() => {
            closeDetail();
            void load(filter);
          }}
        />
      )}
    </div>
  );
}

function OrderDetail({
  order,
  customer,
  canEdit,
  canDelete,
  onClose,
  onChanged,
}: {
  order: Order;
  customer: Customer | null;
  canEdit: boolean;
  canDelete: boolean;
  onClose: () => void;
  onChanged: () => void;
}) {
  const toast = useToast();
  const [mode, setMode] = useState<'view' | 'edit' | 'confirmDelete'>('view');
  const [note, setNote] = useState(order.note ?? '');
  const [cust, setCust] = useState<Customer | null>(customer);
  const [pickOpen, setPickOpen] = useState(false);
  const [busy, setBusy] = useState(false);

  const doSave = async () => {
    setBusy(true);
    try {
      await updateOrderMeta(order.id, { note: note.trim() || null, customerId: cust ? cust.id : null });
      toast.show(`Đã lưu thay đổi đơn ${order.code}`);
      onChanged();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  const doDelete = async () => {
    setBusy(true);
    try {
      await deleteOrder(order.id);
      toast.show(`Đã xóa đơn ${order.code}`);
      onChanged();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Xóa thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet
      title={mode === 'confirmDelete' ? 'Xóa đơn hàng' : `Đơn ${order.code}`}
      onClose={onClose}
      footer={
        mode === 'view' ? (
          <div className="row" style={{ gap: 8 }}>
            <BluetoothPrintButton order={order} />
            {canEdit && (
              <button className="btn btn-outline btn-block btn-lg" onClick={() => setMode('edit')}>
                Sửa
              </button>
            )}
            {canDelete && (
              <button
                className="btn btn-block btn-lg"
                style={{}}
                onClick={() => setMode('confirmDelete')}
              >
                Xóa đơn
              </button>
            )}
          </div>
        ) : mode === 'edit' ? (
          <div className="row" style={{ gap: 8 }}>
            <button className="btn btn-outline btn-block btn-lg" disabled={busy} onClick={() => setMode('view')}>
              Hủy
            </button>
            <button className="btn btn-block btn-lg" disabled={busy} onClick={doSave}>
              {busy ? 'Đang lưu…' : 'Lưu'}
            </button>
          </div>
        ) : (
          <div className="row" style={{ gap: 8 }}>
            <button className="btn btn-outline btn-block btn-lg" disabled={busy} onClick={() => setMode('view')}>
              Giữ lại
            </button>
            <button
              className="btn btn-block btn-lg"
              style={{}}
              disabled={busy}
              onClick={doDelete}
            >
              {busy ? 'Đang xóa…' : 'Xóa đơn'}
            </button>
          </div>
        )
      }
    >
      {mode === 'confirmDelete' ? (
        <p style={{ margin: '4px 0 8px', lineHeight: 1.6 }}>
          Xóa đơn <b>{order.code}</b> ({formatVND(order.total)})? Doanh thu và công nợ liên quan sẽ
          được hoàn lại. Thao tác này không thể hoàn tác.
        </p>
      ) : mode === 'edit' ? (
        <>
          <div className="field">
            <label>Khách hàng</label>
            <button className="sb-row" type="button" onClick={() => setPickOpen(true)}>
              <span className="avatar">{cust ? cust.name.charAt(0).toUpperCase() : '👤'}</span>
              <span className="rbody">
                <span className="rtitle">{cust ? cust.name : 'Khách lẻ'}</span>
                <span className="rsub">{cust ? cust.phone : 'Bấm để chọn khách'}</span>
              </span>
              <span className="text-green" style={{ fontWeight: 600 }}>
                Đổi ›
              </span>
            </button>
            {cust && (
              <button
                type="button"
                className="btn btn-ghost btn-sm"
                style={{ marginTop: 6 }}
                onClick={() => setCust(null)}
              >
                Bỏ chọn (về khách lẻ)
              </button>
            )}
          </div>
          <div className="field">
            <label>Ghi chú đơn</label>
            <input
              className="input"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Ghi chú…"
              maxLength={1000}
            />
          </div>
          <p className="small muted">Chỉ sửa được ghi chú và khách hàng — món và giá giữ nguyên để báo cáo chính xác.</p>
        </>
      ) : (
        <>
          <div className="sb-section" style={{ marginBottom: 12 }}>
            <div className="row" style={{ justifyContent: 'space-between', marginBottom: 6 }}>
              <span className="muted">Thời gian</span>
              <b>
                {formatTime(order.created_at)} · {formatDMY(order.business_date)}
              </b>
            </div>
            <div className="row" style={{ justifyContent: 'space-between', marginBottom: 6 }}>
              <span className="muted">Khách hàng</span>
              <b>{customer ? `${customer.name} · ${customer.phone}` : 'Khách lẻ'}</b>
            </div>
            <div className="row" style={{ justifyContent: 'space-between', marginBottom: 6 }}>
              <span className="muted">Thanh toán</span>
              <b>{order.payment_method_name ?? order.payment_method}</b>
            </div>
            {order.warehouse_name && (
              <div className="row" style={{ justifyContent: 'space-between', marginBottom: 6 }}>
                <span className="muted">Kho trừ tồn</span>
                <b>🗃️ {order.warehouse_name}</b>
              </div>
            )}
            {order.note && (
              <div className="row" style={{ justifyContent: 'space-between' }}>
                <span className="muted">Ghi chú</span>
                <b style={{ textAlign: 'right', maxWidth: '60%' }}>{order.note}</b>
              </div>
            )}
          </div>

          <div className="sb-section" style={{ marginBottom: 12, padding: '4px 16px' }}>
            <div className="small muted" style={{ fontWeight: 600, padding: '10px 0 2px' }}>
              Món đã bán ({order.items.length})
            </div>
            {order.items.map((it) => (
              <div key={it.id} className="sb-row" style={{ cursor: 'default' }}>
                <span className="rbody">
                  <span className="rtitle">
                    {it.product_name} <span className="muted">× {it.qty}</span>
                  </span>
                  {it.modifiers.length > 0 && (
                    <span className="rsub">
                      {it.modifiers.map((m) => `${m.group}: ${m.option}`).join(' · ')}
                    </span>
                  )}
                  {it.note && <span className="rsub">“{it.note}”</span>}
                </span>
                <span className="ramount">{formatVND(it.line_total)}</span>
              </div>
            ))}
          </div>

          <div className="sb-section">
            {order.discount > 0 && (
              <>
                <div className="row" style={{ justifyContent: 'space-between' }}>
                  <span className="muted">Tạm tính</span>
                  <span>{formatVND(order.subtotal)}</span>
                </div>
                <div className="row" style={{ justifyContent: 'space-between', color: 'var(--green)' }}>
                  <span>
                    Giảm giá{order.discount_label ? ` (${order.discount_label})` : ''}
                  </span>
                  <span>-{formatVND(order.discount)}</span>
                </div>
              </>
            )}
            <div className="row" style={{ justifyContent: 'space-between' }}>
              <b style={{ fontSize: 17 }}>Tổng cộng</b>
              <b className="money text-orange" style={{ fontSize: 24 }}>
                {formatVND(order.total)}
              </b>
            </div>
          </div>
        </>
      )}

      {pickOpen && (
        <CustomerPickSheet
          onClose={() => setPickOpen(false)}
          onPick={(c) => {
            setCust(c);
            setPickOpen(false);
          }}
        />
      )}
    </Sheet>
  );
}
