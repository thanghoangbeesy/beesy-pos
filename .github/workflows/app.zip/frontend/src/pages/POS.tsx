import { useCallback, useEffect, useMemo, useState } from 'react';
import type { FormEvent } from 'react';
import { DbError, createCustomer, listCategories, listModifierGroups, listProducts, searchCustomers } from '../lib/db';
import { formatVND } from '../lib/format';
import { loadMenuCache, saveMenuCache, useOnlineStatus } from '../lib/offline';
import { useToast } from '../components/Toast';
import { Sheet } from '../components/Sheet';
import { ModifierModal } from './ModifierModal';
import { CheckoutModal } from './CheckoutModal';
import type {
  CartLine,
  Category,
  Customer,
  ModifierGroup,
  Order,
  Product,
  SelectedModifier,
} from '../lib/types';


function lineKey(productId: string, mods: SelectedModifier[], note: string): string {
  const ids = mods.map((m) => m.option_id).sort().join(',');
  return `${productId}|${ids}|${note}`;
}



export function POS() {
  const toast = useToast();
  const { online, refreshPending } = useOnlineStatus();
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [modGroups, setModGroups] = useState<ModifierGroup[]>([]);
  const [loading, setLoading] = useState(true);
  const [fromCache, setFromCache] = useState(false);
  const [activeCat, setActiveCat] = useState<string>('all');
  const [query, setQuery] = useState('');

  const [cart, setCart] = useState<CartLine[]>([]);
  const [modProduct, setModProduct] = useState<Product | null>(null);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [cartSheetOpen, setCartSheetOpen] = useState(false);
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [customerSheet, setCustomerSheet] = useState(false);

  // Tải menu: ưu tiên db, rớt mạng → dùng cache localStorage
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [cats, prods, groups] = await Promise.all([
          listCategories(),
          listProducts(),
          listModifierGroups(),
        ]);
        if (cancelled) return;
        setCategories(cats.filter((c) => c.active));
        setProducts(prods.filter((p) => p.active));
        setModGroups(groups.filter((x) => x.active));
        saveMenuCache({ categories: cats, products: prods, modifierGroups: groups });
        setFromCache(false);
      } catch (e) {
        const cache = loadMenuCache();
        if (cache && !cancelled) {
          setCategories(cache.categories.filter((c) => c.active));
          setProducts(cache.products.filter((p) => p.active));
          setModGroups(cache.modifierGroups.filter((x) => x.active));
          setFromCache(true);
          if (e instanceof DbError && e.code === 'unavailable') toast.show('Đang offline — dùng menu đã lưu');
          else toast.show('Không tải được menu, dùng bản lưu');
        } else if (!cancelled) {
          toast.show('Không tải được menu');
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const filtered = useMemo(() => {
    let list = products;
    if (activeCat !== 'all') list = list.filter((p) => p.category_id === activeCat);
    const q = query.trim().toLowerCase();
    if (q) list = list.filter((p) => p.name.toLowerCase().includes(q));
    return [...list].sort((a, b) => a.sort_order - b.sort_order);
  }, [products, activeCat, query]);

  const addLine = useCallback((product: Product, modifiers: SelectedModifier[], note: string, qty = 1) => {
    const key = lineKey(product.id, modifiers, note);
    setCart((prev) => {
      const i = prev.findIndex((l) => l.key === key);
      if (i >= 0) {
        const next = [...prev];
        next[i] = { ...next[i], qty: next[i].qty + qty };
        return next;
      }
      return [...prev, { key, product, qty, modifiers, note }];
    });
  }, []);

  const setQty = useCallback((key: string, qty: number) => {
    setCart((prev) =>
      qty <= 0 ? prev.filter((l) => l.key !== key) : prev.map((l) => (l.key === key ? { ...l, qty } : l)),
    );
  }, []);

  const clearCart = useCallback(() => {
    setCart([]);
    setCustomer(null);
  }, []);

  const totalQty = cart.reduce((s, l) => s + l.qty, 0);
  const grandTotal = cart.reduce((s, l) => s + l.qty * (l.product.base_price + l.modifiers.reduce((a, m) => a + m.price_delta, 0)), 0);

  const unitPrice = (l: CartLine) => l.product.base_price + l.modifiers.reduce((a, m) => a + m.price_delta, 0);

  const openModifier = (p: Product) => {
    if (!modGroups.length) {
      addLine(p, [], '');
      toast.show(`Đã thêm ${p.name}`);
      return;
    }
    setModProduct(p);
  };

  const cartBody = (inSheet: boolean) => (
    <>
      <div className={inSheet ? 'cart-sheet-lines' : 'cart-lines'}>
        {cart.length === 0 ? (
          <div className="cart-empty">🛒 Giỏ hàng trống<br />Chạm vào món để thêm</div>
        ) : (
          cart.map((l) => (
            <div className="cart-line" key={l.key}>
              <div className="grow">
                <div className="lname">{l.product.name}</div>
                {l.modifiers.length > 0 && (
                  <div className="lmods">
                    {l.modifiers.map((m) => m.option).join(' · ')}
                    {l.modifiers.some((m) => m.price_delta > 0) && (
                      <span className="plus"> (+{formatVND(l.modifiers.reduce((a, m) => a + m.price_delta, 0))})</span>
                    )}
                  </div>
                )}
                {l.note && <div className="lmods">📝 {l.note}</div>}
                <div className="money" style={{ fontSize: 14 }}>{formatVND(unitPrice(l))}</div>
              </div>
              <div className="qty-ctl">
                <button className="qty-btn" onClick={() => setQty(l.key, l.qty - 1)} aria-label="Giảm">−</button>
                <span className="qty-num">{l.qty}</span>
                <button className="qty-btn" onClick={() => setQty(l.key, l.qty + 1)} aria-label="Tăng">+</button>
              </div>
            </div>
          ))
        )}
      </div>
      <div className="cart-total">
        {customer && (
          <div className="trow small">
            <span>👤 {customer.name} ({customer.phone})</span>
            <button className="btn btn-ghost" style={{ minHeight: 32, padding: '2px 10px', fontSize: 12 }} onClick={() => setCustomer(null)}>
              Bỏ
            </button>
          </div>
        )}
        <div className="trow grand">
          <span>Tổng cộng</span>
          <span className="money">{formatVND(grandTotal)}</span>
        </div>
      </div>
      <div className="cart-actions">
        <button className="btn btn-outline btn-block" onClick={() => setCustomerSheet(true)}>
          {customer ? '👤 Đổi khách hàng' : '👤 Chọn khách hàng (tích tem)'}
        </button>
        <button className="btn btn-green btn-block btn-lg" disabled={cart.length === 0} onClick={() => setCheckoutOpen(true)}>
          💳 Thanh toán
        </button>
        {cart.length > 0 && (
          <button className="btn btn-ghost btn-block" onClick={clearCart}>
            Xóa giỏ
          </button>
        )}
      </div>
    </>
  );

  return (
    <div className="pos">
      <div className="pos-left">
        <div className="row" style={{ marginBottom: 10 }}>
          <input
            className="input grow"
            placeholder="🔍 Tìm món…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          {fromCache && <span className="small muted">📦 menu offline</span>}
        </div>
        <div className="cat-tabs">
          <button className={`cat-tab${activeCat === 'all' ? ' active' : ''}`} onClick={() => setActiveCat('all')}>
            Tất cả
          </button>
          {categories.map((c) => (
            <button
              key={c.id}
              className={`cat-tab${activeCat === c.id ? ' active' : ''}`}
              onClick={() => setActiveCat(c.id)}
            >
              {c.name}
            </button>
          ))}
        </div>
        {loading ? (
          <div className="card">Đang tải menu…</div>
        ) : filtered.length === 0 ? (
          <div className="card muted">Không có món nào. {online ? 'Thêm món ở trang Menu.' : 'Kiểm tra mạng.'}</div>
        ) : (
          <div className="product-grid">
            {filtered.map((p) => (
              <button key={p.id} className="product-card" onClick={() => openModifier(p)}>
                <span className="pname">{p.name}</span>
                <span className="pprice">{formatVND(p.base_price)}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      <aside className="pos-right">
        <div className="cart">
          <div className="cart-head">
            <span>🧾 Giỏ hàng</span>
            {totalQty > 0 && <span className="money">{totalQty} món</span>}
          </div>
          {cartBody(false)}
        </div>
      </aside>

      {totalQty > 0 && !checkoutOpen && (
        <button className="sb-cart-bar" onClick={() => setCheckoutOpen(true)}>
          <span>
            Số lượng<span className="qty-badge">{totalQty}</span>
          </span>
          <span className="money">{formatVND(grandTotal)} ›</span>
        </button>
      )}

      {cartSheetOpen && (
        <Sheet title={`🧾 Giỏ hàng (${totalQty} món)`} onClose={() => setCartSheetOpen(false)}>
          {cartBody(true)}
        </Sheet>
      )}

      {modProduct && (
        <ModifierModal
          product={modProduct}
          groups={modGroups}
          onClose={() => setModProduct(null)}
          onAdd={(mods, note, qty) => {
            addLine(modProduct, mods, note, qty);
            setModProduct(null);
            toast.show(`Đã thêm ${modProduct.name}`);
          }}
        />
      )}

      {checkoutOpen && (
        <CheckoutModal
          lines={cart}
          customer={customer}
          total={grandTotal}
          onClose={() => setCheckoutOpen(false)}
          onDone={(order: Order | null, queued: boolean) => {
            setCheckoutOpen(false);
            setCartSheetOpen(false);
            clearCart();
            refreshPending();
            if (queued) toast.show('Đã lưu đơn chờ — sẽ tự đồng bộ khi có mạng');
            else if (order) toast.show(`Tạo đơn ${order.code} thành công`);
          }}
        />
      )}

      {customerSheet && (
        <CustomerPickSheet
          onClose={() => setCustomerSheet(false)}
          onPick={(c) => {
            setCustomer(c);
            setCustomerSheet(false);
            toast.show(`Đã chọn khách: ${c.name}`);
          }}
        />
      )}
    </div>
  );
}

function CustomerPickSheet({ onClose, onPick }: { onClose: () => void; onPick: (c: Customer) => void }) {
  const toast = useToast();
  const [q, setQ] = useState('');
  const [list, setList] = useState<Customer[]>([]);
  const [busy, setBusy] = useState(false);
  const [searched, setSearched] = useState(false);
  // Form thêm nhanh khách mới
  const [adding, setAdding] = useState(false);
  const [newName, setNewName] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [saving, setSaving] = useState(false);

  const search = async () => {
    setBusy(true);
    try {
      const data = await searchCustomers(q.trim());
      setList(data);
      setSearched(true);
      if (data.length === 0) toast.show('Không tìm thấy khách hàng');
    } catch {
      toast.show('Không tìm được, kiểm tra mạng');
    } finally {
      setBusy(false);
    }
  };

  const openQuickAdd = () => {
    // Đoán: nhập toàn số → SĐT, ngược lại → tên
    const digits = q.replace(/\D/g, '');
    if (digits.length >= 8 && digits.length === q.replace(/\s/g, '').length) {
      setNewPhone(digits);
      setNewName('');
    } else {
      setNewName(q.trim());
      setNewPhone('');
    }
    setAdding(true);
  };

  const quickAdd = async (e: FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newPhone.trim()) {
      toast.show('Nhập tên và số điện thoại của khách');
      return;
    }
    setSaving(true);
    try {
      const created = await createCustomer({ name: newName.trim(), phone: newPhone.trim() });
      toast.show(`Đã thêm khách: ${created.name}`);
      onPick(created);
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Thêm khách thất bại');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Sheet title="👤 Chọn khách hàng" onClose={onClose}>
      {adding ? (
        <form onSubmit={quickAdd}>
          <p className="small muted" style={{ marginTop: 0 }}>
            Thêm nhanh khách mới — xong sẽ tự chọn luôn để tích tem cho đơn này.
          </p>
          <div className="field">
            <label>Tên khách hàng</label>
            <input className="input" value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="VD: Lan" autoFocus />
          </div>
          <div className="field">
            <label>Số điện thoại</label>
            <input className="input" inputMode="tel" value={newPhone} onChange={(e) => setNewPhone(e.target.value)} placeholder="VD: 0901234567" />
          </div>
          <div className="row" style={{ gap: 8 }}>
            <button type="submit" className="btn grow" disabled={saving}>
              {saving ? 'Đang lưu…' : '✅ Lưu & chọn khách này'}
            </button>
            <button type="button" className="btn btn-ghost" onClick={() => setAdding(false)}>
              Quay lại
            </button>
          </div>
          <p className="small muted">Muốn nhập thêm ngày sinh, địa chỉ: vào mục Khách hàng sau.</p>
        </form>
      ) : (
        <>
          <div className="row" style={{ marginBottom: 12 }}>
            <input
              className="input grow"
              placeholder="Nhập tên hoặc SĐT…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && search()}
            />
            <button className="btn" onClick={search} disabled={busy}>
              Tìm
            </button>
          </div>
          {list.map((c) => (
            <button
              key={c.id}
              className="btn btn-outline btn-block"
              style={{ marginBottom: 8, justifyContent: 'flex-start' }}
              onClick={() => onPick(c)}
            >
              <span className="grow" style={{ textAlign: 'left' }}>
                <b>{c.name}</b> · {c.phone}
                <br />
                <span className="small muted">🎟️ {c.stamps} tem{c.reward_available ? ' · có quà tặng!' : ''}</span>
              </span>
            </button>
          ))}
          {searched && (
            <button className="btn btn-block btn-outline" style={{ marginTop: 4 }} onClick={openQuickAdd}>
              ➕ Thêm khách hàng mới
            </button>
          )}
        </>
      )}
    </Sheet>
  );
}
