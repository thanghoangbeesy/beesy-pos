import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  DbError,
  deleteDraftOrder,
  ensureWarehousesSeeded,
  getCustomer,
  getDefaultWarehouseId,
  getMyProfile,
  listCategories,
  listDraftOrders,
  listModifierGroups,
  listProducts,
  listWarehouses,
  saveDraftOrder,
} from '../lib/db';
import { formatTime, formatVND } from '../lib/format';
import { loadMenuCache, saveMenuCache, useOnlineStatus } from '../lib/offline';
import { useToast } from '../components/Toast';
import { PageHead } from '../components/PageHead';
import { Sheet } from '../components/Sheet';
import { ModifierModal } from './ModifierModal';
import { CheckoutModal } from './CheckoutModal';
import type {
  CartLine,
  Category,
  Customer,
  DraftOrder,
  ModifierGroup,
  Order,
  Product,
  SelectedModifier,
  Warehouse,
} from '../lib/types';


function lineKey(productId: string, mods: SelectedModifier[], note: string): string {
  const ids = mods.map((m) => m.option_id).sort().join(',');
  return `${productId}|${ids}|${note}`;
}



export function POS() {
  const toast = useToast();
  const { online, refreshPending } = useOnlineStatus();
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [modGroups, setModGroups] = useState<ModifierGroup[]>([]);
  const [loading, setLoading] = useState(true);
  const [fromCache, setFromCache] = useState(false);
  const [activeCat, setActiveCat] = useState<string>('all');
  const [query, setQuery] = useState('');

  const [cart, setCart] = useState<CartLine[]>([]);
  const [modProduct, setModProduct] = useState<Product | null>(null);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [cartSheetOpen, setCartSheetOpen] = useState(false);
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [drafts, setDrafts] = useState<DraftOrder[]>([]);
  const [draftSheet, setDraftSheet] = useState(false);
  // Kho bán: trừ tồn ở kho này khi tạo đơn (multi-kho)
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [warehouseId, setWarehouseId] = useState<string>(
    () => localStorage.getItem('beesy_warehouse_id') ?? '',
  );

  const pickWarehouse = useCallback(async () => {
    try {
      const me = await getMyProfile();
      let ws = await listWarehouses();
      if (me.role === 'owner' && ws.length === 0) ws = await ensureWarehousesSeeded();
      const allowed = me.role === 'owner' ? ws : ws.filter((w) => me.warehouse_ids.includes(w.id));
      setWarehouses(allowed);
      if (allowed.length === 0) {
        setWarehouseId('');
        return;
      }
      const saved = localStorage.getItem('beesy_warehouse_id');
      const def = await getDefaultWarehouseId();
      const pick =
        (saved && allowed.some((w) => w.id === saved) ? saved : null) ??
        (def && allowed.some((w) => w.id === def) ? def : null) ??
        allowed[0].id;
      setWarehouseId(pick);
      localStorage.setItem('beesy_warehouse_id', pick);
    } catch {
      // Không chặn bán hàng nếu lỗi tải kho — createOrder sẽ báo rõ
    }
  }, []);

  useEffect(() => {
    void pickWarehouse();
  }, [pickWarehouse]);

  const changeWarehouse = (id: string) => {
    setWarehouseId(id);
    localStorage.setItem('beesy_warehouse_id', id);
  };

  // Tải menu: ưu tiên db, rớt mạng → dùng cache localStorage
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [cats, prods, groups] = await Promise.all([
          listCategories(),
          listProducts(),
          listModifierGroups(),
        ]);
        if (cancelled) return;
        setCategories(cats.filter((c) => c.active));
        setProducts(prods.filter((p) => p.active));
        setModGroups(groups.filter((x) => x.active));
        saveMenuCache({ categories: cats, products: prods, modifierGroups: groups });
        setFromCache(false);
      } catch (e) {
        const cache = loadMenuCache();
        if (cache && !cancelled) {
          setCategories(cache.categories.filter((c) => c.active));
          setProducts(cache.products.filter((p) => p.active));
          setModGroups(cache.modifierGroups.filter((x) => x.active));
          setFromCache(true);
          if (e instanceof DbError && e.code === 'unavailable') toast.show('Đang offline — dùng menu đã lưu');
          else toast.show('Không tải được menu, dùng bản lưu');
        } else if (!cancelled) {
          toast.show('Không tải được menu');
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const filtered = useMemo(() => {
    let list = products;
    if (activeCat !== 'all') list = list.filter((p) => p.category_id === activeCat);
    const q = query.trim().toLowerCase();
    if (q) list = list.filter((p) => p.name.toLowerCase().includes(q));
    return [...list].sort((a, b) => a.sort_order - b.sort_order);
  }, [products, activeCat, query]);

  const addLine = useCallback((product: Product, modifiers: SelectedModifier[], note: string, qty = 1) => {
    const key = lineKey(product.id, modifiers, note);
    setCart((prev) => {
      const i = prev.findIndex((l) => l.key === key);
      if (i >= 0) {
        const next = [...prev];
        next[i] = { ...next[i], qty: next[i].qty + qty };
        return next;
      }
      return [...prev, { key, product, qty, modifiers, note }];
    });
  }, []);

  const setQty = useCallback((key: string, qty: number) => {
    setCart((prev) =>
      qty <= 0 ? prev.filter((l) => l.key !== key) : prev.map((l) => (l.key === key ? { ...l, qty } : l)),
    );
  }, []);

  const clearCart = useCallback(() => {
    setCart([]);
    setCustomer(null);
  }, []);

  const refreshDrafts = useCallback(async () => {
    try {
      setDrafts(await listDraftOrders());
    } catch {
      // Không chặn bán hàng nếu tải hóa đơn tạm thất bại
    }
  }, []);

  useEffect(() => {
    void refreshDrafts();
  }, [refreshDrafts]);

  /** Lưu tạm giỏ hiện tại thành hóa đơn tạm rồi xóa giỏ. */
  const saveDraft = useCallback(async () => {
    if (cart.length === 0) {
      toast.show('Giỏ đang trống');
      return;
    }
    try {
      await saveDraftOrder({
        items: cart.map((l) => ({
          product: l.product,
          qty: l.qty,
          modifiers: l.modifiers,
          note: l.note,
        })),
        customer_id: customer?.id ?? null,
        customer_name: customer?.name ?? null,
      });
      setCart([]);
      setCustomer(null);
      setCheckoutOpen(false);
      void refreshDrafts();
      toast.show('Đã lưu tạm hóa đơn');
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu tạm thất bại');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cart, customer]);

  /** Mở lại hóa đơn tạm vào giỏ (chỉ khi giỏ đang trống). */
  const resumeDraft = useCallback(
    async (d: DraftOrder) => {
      if (cart.length > 0) {
        toast.show('Giỏ đang có món — hãy thanh toán, xóa giỏ hoặc lưu tạm trước');
        return;
      }
      try {
        setCart(
          d.items.map((i) => ({
            key: lineKey(i.product.id, i.modifiers ?? [], i.note ?? ''),
            product: i.product,
            qty: i.qty,
            modifiers: i.modifiers ?? [],
            note: i.note ?? '',
          })),
        );
        if (d.customer_id) {
          try {
            setCustomer(await getCustomer(d.customer_id));
          } catch {
            setCustomer(null);
          }
        } else {
          setCustomer(null);
        }
        await deleteDraftOrder(d.id);
        void refreshDrafts();
        setDraftSheet(false);
        toast.show('Đã mở lại hóa đơn tạm');
      } catch (e) {
        toast.show(e instanceof DbError ? e.message : 'Mở lại thất bại');
      }
    },
    [cart.length],
    // eslint-disable-next-line react-hooks/exhaustive-deps
  );

  const removeDraft = useCallback(
    async (id: string) => {
      try {
        await deleteDraftOrder(id);
        void refreshDrafts();
        toast.show('Đã xóa hóa đơn tạm');
      } catch (e) {
        toast.show(e instanceof DbError ? e.message : 'Xóa thất bại');
      }
    },
    [refreshDrafts],
  );

  const totalQty = cart.reduce((s, l) => s + l.qty, 0);
  const grandTotal = cart.reduce((s, l) => s + l.qty * (l.product.base_price + l.modifiers.reduce((a, m) => a + m.price_delta, 0)), 0);

  const unitPrice = (l: CartLine) => l.product.base_price + l.modifiers.reduce((a, m) => a + m.price_delta, 0);

  // Tổng số lượng từng món (gộp các dòng cùng product id, kể cả khác topping)
  const qtyByProduct = useMemo(() => {
    const m: Record<string, number> = {};
    for (const l of cart) m[l.product.id] = (m[l.product.id] ?? 0) + l.qty;
    return m;
  }, [cart]);

  const openModifier = (p: Product) => {
    if (!modGroups.length) {
      addLine(p, [], '');
      toast.show(`Đã thêm ${p.name}`);
      return;
    }
    setModProduct(p);
  };

  const cartBody = (inSheet: boolean) => (
    <>
      <div className={inSheet ? 'cart-sheet-lines' : 'cart-lines'}>
        {cart.length === 0 ? (
          <div className="cart-empty">🛒 Giỏ hàng trống<br />Chạm vào món để thêm</div>
        ) : (
          cart.map((l) => (
            <div className="cart-line" key={l.key}>
              <div className="grow">
                <div className="lname">{l.product.name}</div>
                {l.modifiers.length > 0 && (
                  <div className="lmods">
                    {l.modifiers.map((m) => m.option).join(' · ')}
                    {l.modifiers.some((m) => m.price_delta > 0) && (
                      <span className="plus"> (+{formatVND(l.modifiers.reduce((a, m) => a + m.price_delta, 0))})</span>
                    )}
                  </div>
                )}
                {l.note && <div className="lmods">📝 {l.note}</div>}
                <div className="money">{formatVND(unitPrice(l))}</div>
              </div>
              <div className="qty-ctl">
                <button className="qty-btn" onClick={() => setQty(l.key, l.qty - 1)} aria-label="Giảm">−</button>
                <span className="qty-num">{l.qty}</span>
                <button className="qty-btn" onClick={() => setQty(l.key, l.qty + 1)} aria-label="Tăng">+</button>
              </div>
            </div>
          ))
        )}
      </div>
      <div className="cart-total">
        {customer && (
          <div className="trow small">
            <span>👤 {customer.name} ({customer.phone})</span>
            <button className="btn btn-ghost btn-sm" onClick={() => setCustomer(null)}>
              Bỏ
            </button>
          </div>
        )}
        <div className="trow grand">
          <span>Tổng cộng</span>
          <span className="money">{formatVND(grandTotal)}</span>
        </div>
      </div>
      <div className="cart-actions">
        <button className="btn btn-green btn-block btn-lg" disabled={cart.length === 0} onClick={() => setCheckoutOpen(true)}>
          💳 Thanh toán
        </button>
        {cart.length > 0 && (
          <div className="row" style={{ gap: 8 }}>
            <button className="btn btn-outline grow" onClick={() => void saveDraft()}>
              📋 Lưu tạm
            </button>
            <button className="btn btn-ghost grow" onClick={clearCart}>
              Xóa giỏ
            </button>
          </div>
        )}
      </div>
    </>
  );

  return (
    <div className="pos">
      <div className="pos-left">
        <PageHead title="Bán hàng" />
        <div className="row" style={{ gap: 8, marginBottom: 10 }}>
          <div className="sb-search grow">
            <span className="sico">🔍</span>
            <input
              placeholder="Tìm theo tên món…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>
          <button
            className="btn btn-outline"
            style={{ minHeight: 48, whiteSpace: 'nowrap' }}
            onClick={() => setDraftSheet(true)}
            aria-label="Hóa đơn tạm"
          >
            🗂 Tạm{drafts.length > 0 ? ` (${drafts.length})` : ''}
          </button>
          {fromCache && <span className="small muted">📦 menu offline</span>}
        </div>
        {warehouses.length > 1 && (
          <div className="row" style={{ gap: 8, marginBottom: 10, flexWrap: 'wrap' }}>
            <span className="small muted" style={{ alignSelf: 'center' }}>🗃️ Kho bán:</span>
            {warehouses.map((w) => (
              <button
                key={w.id}
                type="button"
                className={`sb-chip${warehouseId === w.id ? ' selected' : ''}`}
                style={{ minHeight: 36, padding: '4px 12px', fontSize: 13 }}
                onClick={() => changeWarehouse(w.id)}
              >
                {w.name}
                {w.is_default ? ' ★' : ''}
              </button>
            ))}
          </div>
        )}
        <div className="chip-row">
          <button
            className={`sb-chip${activeCat === 'all' ? ' selected' : ''}`}
            onClick={() => setActiveCat('all')}
          >
            Tất cả
          </button>
          {categories.map((c) => (
            <button
              key={c.id}
              className={`sb-chip${activeCat === c.id ? ' selected' : ''}`}
              onClick={() => setActiveCat(c.id)}
            >
              {c.name}
            </button>
          ))}
        </div>
        {loading ? (
          <div className="card">Đang tải menu…</div>
        ) : filtered.length === 0 ? (
          <div className="card muted">Không có món nào. {online ? 'Thêm món ở trang Menu.' : 'Kiểm tra mạng.'}</div>
        ) : (
          <div className="product-grid">
            {filtered.map((p) => {
              const q = qtyByProduct[p.id] ?? 0;
              const lastLine = q > 0 ? [...cart].reverse().find((l) => l.product.id === p.id) : undefined;
              return (
                <button
                  key={p.id}
                  className={`product-card${q > 0 ? ' in-cart' : ''}`}
                  onClick={() => openModifier(p)}
                >
                  <span className="pname">{p.name}</span>
                  <span className="pprice">{formatVND(p.base_price)}{p.unit ? `/${p.unit}` : ''}</span>
                  {q > 0 && (
                    <span className="pstep">
                      <button
                        aria-label="Giảm"
                        onClick={(e) => {
                          e.stopPropagation();
                          if (lastLine) setQty(lastLine.key, lastLine.qty - 1);
                        }}
                      >
                        −
                      </button>
                      <span className="qty-num">{q}</span>
                      <button
                        aria-label="Tăng"
                        onClick={(e) => {
                          e.stopPropagation();
                          openModifier(p);
                        }}
                      >
                        +
                      </button>
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        )}
      </div>

      <aside className="pos-right">
        <div className="cart">
          <div className="cart-head">
            <span>Giỏ hàng</span>
            {totalQty > 0 && <span className="money">{totalQty} món</span>}
          </div>
          {cartBody(false)}
        </div>
      </aside>

      {totalQty > 0 && !checkoutOpen && (
        <button className="sb-cart-bar" onClick={() => setCheckoutOpen(true)}>
          <span>
            Số lượng<span className="qty-badge">{totalQty}</span>
          </span>
          <span className="money">{formatVND(grandTotal)} ›</span>
        </button>
      )}

      {cartSheetOpen && (
        <Sheet title={`🧾 Giỏ hàng (${totalQty} món)`} onClose={() => setCartSheetOpen(false)}>
          {cartBody(true)}
        </Sheet>
      )}

      {modProduct && (
        <ModifierModal
          product={modProduct}
          groups={modGroups}
          onClose={() => setModProduct(null)}
          onAdd={(mods, note, qty) => {
            addLine(modProduct, mods, note, qty);
            setModProduct(null);
            toast.show(`Đã thêm ${modProduct.name}`);
          }}
        />
      )}

      {checkoutOpen && (
        <CheckoutModal
          lines={cart}
          customer={customer}
          total={grandTotal}
          warehouseId={warehouseId}
          onClose={() => setCheckoutOpen(false)}
          onUpdateQty={setQty}
          onCustomerChange={setCustomer}
          onSaveDraft={() => void saveDraft()}
          onDone={(order: Order | null, queued: boolean) => {
            setCheckoutOpen(false);
            setCartSheetOpen(false);
            clearCart();
            refreshPending();
            if (queued) toast.show('Đã lưu đơn chờ — sẽ tự đồng bộ khi có mạng');
            else if (order) toast.show(`Tạo đơn ${order.code} thành công`);
          }}
        />
      )}

      {draftSheet && (
        <DraftSheet
          drafts={drafts}
          onClose={() => setDraftSheet(false)}
          onResume={(d) => void resumeDraft(d)}
          onDelete={(id) => void removeDraft(id)}
        />
      )}
    </div>
  );
}

function DraftSheet({
  drafts,
  onClose,
  onResume,
  onDelete,
}: {
  drafts: DraftOrder[];
  onClose: () => void;
  onResume: (d: DraftOrder) => void;
  onDelete: (id: string) => void;
}) {
  return (
    <Sheet title={`Hóa đơn tạm (${drafts.length})`} onClose={onClose}>
      {drafts.length === 0 ? (
        <div className="sb-empty">
          <div className="eico">🗂</div>
          <p>Chưa có hóa đơn tạm nào.</p>
        </div>
      ) : (
        drafts.map((d) => {
          const qty = d.items.reduce((s, i) => s + i.qty, 0);
          const total = d.items.reduce(
            (s, i) =>
              s + i.qty * (i.product.base_price + (i.modifiers ?? []).reduce((a, m) => a + m.price_delta, 0)),
            0,
          );
          return (
            <div key={d.id} className="sb-section" style={{ marginBottom: 10 }}>
              <div className="row" style={{ justifyContent: 'space-between', marginBottom: 6 }}>
                <b>{d.customer_name ?? 'Khách lẻ'}</b>
                <span className="small muted">{formatTime(d.created_at)}</span>
              </div>
              <div className="small" style={{ marginBottom: 6 }}>
                {d.items.map((i) => `${i.qty}× ${i.product.name}`).join(', ')}
              </div>
              <div className="small muted" style={{ marginBottom: 10 }}>
                {qty} món · <span className="money">{formatVND(total)}</span>
              </div>
              <div className="row" style={{ gap: 8 }}>
                <button className="btn grow" onClick={() => onResume(d)}>
                  Mở lại
                </button>
                <button className="btn btn-outline" onClick={() => onDelete(d.id)}>
                  Xóa
                </button>
              </div>
            </div>
          );
        })
      )}
      <p className="small muted" style={{ marginTop: 12 }}>
        Mở lại chỉ dùng được khi giỏ đang trống. Hóa đơn tạm giữ nguyên giá món lúc lưu.
      </p>
    </Sheet>
  );
}
