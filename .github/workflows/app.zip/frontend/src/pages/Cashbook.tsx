// Thu chi — sổ ghi thu/chi THỦ CÔNG của quán (nhập hàng, mặt bằng, lương...).
// LƯU Ý: đơn bán KHÔNG tự log vào đây.
import { useCallback, useEffect, useMemo, useState } from 'react';
import { DbError, addCashbookEntry, listCashbookEntries } from '../lib/db';
import { formatTime, formatVND, todayVN } from '../lib/format';
import { Sheet } from '../components/Sheet';
import { useToast } from '../components/Toast';
import type { CashbookEntry, CashbookType } from '../lib/types';

const CATEGORIES = ['Nguyên liệu', 'Mặt bằng', 'Lương', 'Bán hàng', 'Khác'];

type FilterKey = 'today' | 'month' | 'all';
const FILTERS: { key: FilterKey; label: string }[] = [
  { key: 'today', label: 'Hôm nay' },
  { key: 'month', label: 'Tháng này' },
  { key: 'all', label: 'Tất cả' },
];

/** YYYY-MM-DD theo giờ VN từ chuỗi ISO. */
function vnDateKey(iso: string): string {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Ho_Chi_Minh',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date(iso));
}

/** Nhãn ngày kiểu "Thứ Bảy, 10/10" theo giờ VN. */
function vnDayLabel(iso: string): string {
  return new Date(iso).toLocaleDateString('vi-VN', {
    weekday: 'long',
    day: '2-digit',
    month: '2-digit',
    timeZone: 'Asia/Ho_Chi_Minh',
  });
}

export function Cashbook() {
  const toast = useToast();
  const [entries, setEntries] = useState<CashbookEntry[]>([]);
  const [filter, setFilter] = useState<FilterKey>('month');
  const [busy, setBusy] = useState(true);
  const [sheet, setSheet] = useState<CashbookType | null>(null);

  const load = useCallback(async () => {
    setBusy(true);
    try {
      setEntries(await listCashbookEntries(200));
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tải được sổ thu chi');
    } finally {
      setBusy(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const t = todayVN();
  const filtered = useMemo(
    () =>
      entries.filter((e) => {
        const k = vnDateKey(e.created_at);
        if (filter === 'today') return k === t;
        if (filter === 'month') return k.slice(0, 7) === t.slice(0, 7);
        return true;
      }),
    [entries, filter, t],
  );

  const totalThu = filtered.filter((e) => e.type === 'thu').reduce((s, e) => s + e.amount, 0);
  const totalChi = filtered.filter((e) => e.type === 'chi').reduce((s, e) => s + e.amount, 0);

  const groups = useMemo(() => {
    const m = new Map<string, CashbookEntry[]>();
    for (const e of filtered) {
      const k = vnDateKey(e.created_at);
      if (!m.has(k)) m.set(k, []);
      m.get(k)!.push(e);
    }
    return [...m.entries()].sort((a, b) => (a[0] < b[0] ? 1 : -1));
  }, [filtered]);

  return (
    <div className="page with-dual-actions">
      <div className="row" style={{ marginBottom: 12 }}>
        <h1 style={{ margin: 0 }} className="grow">
          💸 Thu chi
        </h1>
      </div>

      <div className="row" style={{ gap: 8, marginBottom: 12, flexWrap: 'wrap' }}>
        {FILTERS.map((f) => (
          <button
            key={f.key}
            className={`sb-chip${filter === f.key ? ' selected' : ''}`}
            onClick={() => setFilter(f.key)}
          >
            {f.label}
          </button>
        ))}
      </div>

      <div className="card" style={{ marginBottom: 12 }}>
        <div className="row" style={{ justifyContent: 'space-between', marginBottom: 10 }}>
          <span className="muted">Chênh lệch</span>
          <b className="money" style={{ fontSize: 22 }}>
            {formatVND(totalThu - totalChi)}
          </b>
        </div>
        <div className="row" style={{ gap: 12 }}>
          <div className="card pastel-green grow" style={{ boxShadow: 'none' }}>
            <div className="small muted">Tổng thu</div>
            <div className="money text-green" style={{ fontSize: 20 }}>
              {formatVND(totalThu)}
            </div>
          </div>
          <div className="card pastel-yellow grow" style={{ boxShadow: 'none' }}>
            <div className="small muted">Tổng chi</div>
            <div className="money text-orange" style={{ fontSize: 20 }}>
              {formatVND(totalChi)}
            </div>
          </div>
        </div>
      </div>

      {busy ? (
        <div className="card muted" style={{ textAlign: 'center' }}>
          Đang tải…
        </div>
      ) : groups.length === 0 ? (
        <div className="card">
          <div className="sb-empty">
            <div className="eico">💸</div>
            <p>
              Chưa có khoản thu chi nào.
              <br />
              Ghi lại mỗi khoản để cuối ngày đối soát dễ dàng.
            </p>
          </div>
        </div>
      ) : (
        groups.map(([day, list]) => (
          <div className="sb-day-group" key={day}>
            <div className="sb-day-label">{vnDayLabel(list[0].created_at)}</div>
            <div className="card" style={{ padding: '4px 16px' }}>
              {list.map((e) => (
                <div key={e.id} className="sb-row" style={{ cursor: 'default' }}>
                  <span
                    className="avatar"
                    style={
                      e.type === 'thu'
                        ? { background: 'var(--green-bg)', color: 'var(--brand-dark)' }
                        : { background: 'var(--orange-bg)', color: 'var(--orange)' }
                    }
                  >
                    {e.type === 'thu' ? '↓' : '↑'}
                  </span>
                  <span className="rbody">
                    <span className="rtitle">{e.category}</span>
                    <span className="rsub">{e.note || formatTime(e.created_at)}</span>
                  </span>
                  <span className={`ramount ${e.type === 'thu' ? 'text-green' : 'text-orange'}`}>
                    {e.type === 'thu' ? '+' : '−'}
                    {formatVND(e.amount)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        ))
      )}

      <div className="sb-dual-actions">
        <div className="inner">
          <button className="btn sb-btn-orange btn-block btn-lg" onClick={() => setSheet('chi')}>
            ➖ Khoản chi
          </button>
          <button className="btn btn-block btn-lg" onClick={() => setSheet('thu')}>
            ➕ Khoản thu
          </button>
        </div>
      </div>

      {sheet && (
        <CashbookSheet
          type={sheet}
          onClose={() => setSheet(null)}
          onDone={() => {
            setSheet(null);
            void load();
          }}
        />
      )}
    </div>
  );
}

function CashbookSheet({
  type,
  onClose,
  onDone,
}: {
  type: CashbookType;
  onClose: () => void;
  onDone: () => void;
}) {
  const toast = useToast();
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [category, setCategory] = useState(type === 'chi' ? 'Nguyên liệu' : 'Bán hàng');
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    const v = parseInt(amount.replace(/\D/g, ''), 10);
    if (!v || v <= 0) {
      toast.show('Nhập số tiền hợp lệ');
      return;
    }
    setBusy(true);
    try {
      await addCashbookEntry(type, v, note.trim() || null, category);
      toast.show(
        type === 'thu' ? `Đã ghi khoản thu ${formatVND(v)}` : `Đã ghi khoản chi ${formatVND(v)}`,
      );
      onDone();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet
      title={type === 'thu' ? '➕ Khoản thu' : '➖ Khoản chi'}
      onClose={onClose}
      footer={
        <button
          className={`btn btn-block btn-lg${type === 'chi' ? ' sb-btn-orange' : ''}`}
          disabled={busy}
          onClick={submit}
        >
          {busy ? 'Đang lưu…' : 'Lưu'}
        </button>
      }
    >
      <div className="field">
        <label>Số tiền</label>
        <input
          className="sb-money-input"
          inputMode="numeric"
          placeholder="0"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          autoFocus
        />
      </div>
      <div className="field">
        <label>Danh mục</label>
        <div className="row" style={{ flexWrap: 'wrap', gap: 8 }}>
          {CATEGORIES.map((c) => (
            <button
              key={c}
              type="button"
              className={`sb-chip${category === c ? ' selected' : ''}`}
              onClick={() => setCategory(c)}
            >
              {c}
            </button>
          ))}
        </div>
      </div>
      <div className="field">
        <label>Ghi chú (không bắt buộc)</label>
        <input
          className="input"
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="VD: nhập sữa tươi…"
        />
      </div>
    </Sheet>
  );
}
