// Đối soát cuối ngày (Z-report): tổng hợp doanh thu theo phương thức thanh toán,
// nhập tiền mặt thực tế trong két → chênh lệch → chốt ngày (mỗi ngày 1 lần).
import { useEffect, useState } from 'react';
import { DbError, getAllowedWarehouses, getDayClose, getDaySummary, getRangeReport, listPaymentMethods, saveDayClose } from '../lib/db';
import { formatVND, todayVN } from '../lib/format';
import { useToast } from '../components/Toast';
import { Sheet } from '../components/Sheet';
import type { DayClose, DayCloseMethod } from '../lib/types';

export function DayCloseSheet({ onClose }: { onClose: () => void }) {
  const toast = useToast();
  const [busy, setBusy] = useState(true);
  const [saving, setSaving] = useState(false);
  const [existing, setExisting] = useState<DayClose | null>(null);
  const [methods, setMethods] = useState<DayCloseMethod[]>([]);
  const [revenue, setRevenue] = useState(0);
  const [orderCount, setOrderCount] = useState(0);
  const [discountTotal, setDiscountTotal] = useState(0);
  const [cashActual, setCashActual] = useState('');
  const [note, setNote] = useState('');
  const [closeDate, setCloseDate] = useState(todayVN());
  const [denomQty, setDenomQty] = useState<Record<string, string>>({});

  const loadData = async (t: string) => {
    setBusy(true);
    try {
      const allowed = await getAllowedWarehouses().catch(() => ({ warehouses: [] as { id: string }[], isOwner: false }));
      const ids = allowed.isOwner ? undefined : allowed.warehouses.map((w) => w.id);
      const [dc, rep, pms, sum] = await Promise.all([
        getDayClose(t),
        getRangeReport(t, t, ids),
        listPaymentMethods(false),
        getDaySummary(t, ids),
      ]);
      setExisting(dc);
      setRevenue(sum.revenue);
      setOrderCount(sum.orders_count);
      setDiscountTotal(sum.discount_total);
      const kindById = new Map(pms.map((m) => [m.id, m.kind]));
      const byMethod: DayCloseMethod[] = Object.entries(rep.by_payment).map(([id, v]) => ({
        method_id: id,
        name: v.name,
        kind: kindById.get(id) ?? 'cash',
        amount: v.revenue,
        count: v.count,
      }));
      setMethods(byMethod);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tải được số liệu');
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => {
    void loadData(closeDate);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [closeDate]);

  const DENOMS = [500000, 200000, 100000, 50000, 20000, 10000, 5000, 2000, 1000];
  const denomTotal = DENOMS.reduce((s, d) => s + d * (parseInt(denomQty[String(d)] ?? '', 10) || 0), 0);
  const applyDenomTotal = () => setCashActual(String(denomTotal));

  const cashExpected = methods.filter((m) => m.kind === 'cash').reduce((s, m) => s + m.amount, 0);
  const actualNum = Math.max(0, parseInt(cashActual.replace(/\D/g, ''), 10) || 0);
  const diff = actualNum - cashExpected;

  const doClose = async () => {
    if (!window.confirm(`Chốt ngày ${closeDate}? Sau khi chốt không sửa được.`)) return;
    setSaving(true);
    try {
      const denoms: Record<string, number> = {};
      for (const d of DENOMS) {
        const q = parseInt(denomQty[String(d)] ?? '', 10) || 0;
        if (q > 0) denoms[String(d)] = q;
      }
      const dc = await saveDayClose({
        business_date: closeDate,
        revenue,
        orders_count: orderCount,
        discount_total: discountTotal,
        by_method: methods,
        cash_expected: cashExpected,
        cash_actual: actualNum,
        cash_denoms: Object.keys(denoms).length > 0 ? denoms : null,
        note: note.trim() || null,
      });
      setExisting(dc);
      toast.show('Đã chốt ngày ✅');
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Chốt ngày thất bại');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Sheet title="🌙 Đối soát cuối ngày" onClose={onClose}>
      {busy ? (
        <div className="muted">Đang tải số liệu…</div>
      ) : existing ? (
        <div className="card" style={{ background: 'var(--green-bg)' }}>
          <div style={{ fontWeight: 700, marginBottom: 8 }}>✅ Đã chốt ngày {existing.business_date}</div>
          <div className="co-total-row"><span>Doanh thu</span><span className="money">{formatVND(existing.revenue)}</span></div>
          <div className="co-total-row"><span>Số đơn</span><span>{existing.orders_count}</span></div>
          <div className="co-total-row"><span>Tiền mặt hệ thống</span><span>{formatVND(existing.cash_expected)}</span></div>
          <div className="co-total-row"><span>Tiền mặt thực tế</span><span>{formatVND(existing.cash_actual)}</span></div>
          <div className="co-total-row grand">
            <span>Chênh lệch két</span>
            <span className="money" style={{ color: existing.cash_diff === 0 ? 'var(--green)' : 'var(--red)' }}>
              {existing.cash_diff > 0 ? '+' : ''}{formatVND(existing.cash_diff)}
            </span>
          </div>
          {existing.cash_denoms && (
            <details className="small" style={{ marginTop: 8 }}>
              <summary className="muted">💵 Chi tiết kiểm tiền</summary>
              <div style={{ marginTop: 6 }}>
                {Object.entries(existing.cash_denoms)
                  .sort((a, b) => Number(b[0]) - Number(a[0]))
                  .map(([d, q]) => (
                    <div className="co-total-row" key={d}>
                      <span>{formatVND(Number(d))} × {q}</span>
                      <span>{formatVND(Number(d) * q)}</span>
                    </div>
                  ))}
              </div>
            </details>
          )}
          {existing.note && <p className="small muted">📝 {existing.note}</p>}
          <p className="small muted">Người chốt: {existing.closed_by_name ?? '—'}</p>
        </div>
      ) : (
        <>
          <div className="field">
            <label>📅 Ngày chốt</label>
            <input
              className="input"
              type="date"
              max={todayVN()}
              value={closeDate}
              onChange={(e) => {
                if (e.target.value) setCloseDate(e.target.value);
              }}
            />
          </div>
          <div className="card" style={{ marginBottom: 12 }}>
            <div className="co-total-row"><span>Doanh thu ngày {closeDate}</span><span className="money">{formatVND(revenue)}</span></div>
            <div className="co-total-row"><span>Số đơn</span><span>{orderCount}</span></div>
            {discountTotal > 0 && (
              <div className="co-total-row"><span>Đã giảm giá</span><span>-{formatVND(discountTotal)}</span></div>
            )}
            {methods.map((m) => (
              <div className="co-total-row" key={m.method_id}>
                <span>{m.name} ({m.count} đơn)</span>
                <span>{formatVND(m.amount)}</span>
              </div>
            ))}
          </div>
          <div className="field">
            <label>Tiền mặt hệ thống ghi nhận</label>
            <input className="input" value={formatVND(cashExpected)} disabled />
          </div>
          <div className="field">
            <label>Tiền mặt thực tế trong két</label>
            <input
              className="input"
              inputMode="numeric"
              placeholder="Đếm két rồi nhập…"
              value={cashActual}
              onChange={(e) => setCashActual(e.target.value)}
            />
          </div>
          <div className="card" style={{ marginBottom: 12 }}>
            <div style={{ fontWeight: 700, marginBottom: 8 }}>💵 Kiểm tiền mặt trong két</div>
            <div className="denom-table">
              <div className="denom-head denom-row">
                <span>Mệnh giá</span>
                <span style={{ textAlign: 'center' }}>Số tờ</span>
                <span style={{ textAlign: 'right' }}>Thành tiền</span>
              </div>
              {DENOMS.map((d) => {
                const q = parseInt(denomQty[String(d)] ?? '', 10) || 0;
                return (
                  <div className="denom-row" key={d}>
                    <span className="money">{formatVND(d)}</span>
                    <input
                      className="input denom-qty"
                      inputMode="numeric"
                      placeholder="0"
                      value={denomQty[String(d)] ?? ''}
                      onChange={(e) => setDenomQty((prev) => ({ ...prev, [String(d)]: e.target.value.replace(/\D/g, '') }))}
                    />
                    <span className="money" style={{ textAlign: 'right' }}>{formatVND(d * q)}</span>
                  </div>
                );
              })}
              <div className="denom-row denom-total">
                <span style={{ fontWeight: 700 }}>Tổng</span>
                <span />
                <span className="money" style={{ textAlign: 'right', fontWeight: 800 }}>{formatVND(denomTotal)}</span>
              </div>
            </div>
            {denomTotal > 0 && (
              <button className="btn btn-block" style={{ marginTop: 8 }} onClick={applyDenomTotal}>
                Dùng {formatVND(denomTotal)} làm tiền thực tế
              </button>
            )}
          </div>
          {cashActual && (
            <div
              className="card"
              style={{
                marginBottom: 12,
                background: diff === 0 ? 'var(--green-bg)' : 'var(--red-bg)',
                color: diff === 0 ? 'var(--green)' : 'var(--red)',
                fontWeight: 700,
              }}
            >
              {diff === 0 ? '✅ Khớp két' : `⚠️ Chênh lệch: ${diff > 0 ? '+' : ''}${formatVND(diff)}`}
            </div>
          )}
          <div className="field">
            <label>Ghi chú (không bắt buộc)</label>
            <input
              className="input"
              placeholder="VD: thừa do khách bo…"
              value={note}
              onChange={(e) => setNote(e.target.value)}
            />
          </div>
          <button className="btn btn-block btn-lg" disabled={saving} onClick={doClose}>
            {saving ? 'Đang chốt…' : '🌙 Chốt ngày'}
          </button>
        </>
      )}
    </Sheet>
  );
}
