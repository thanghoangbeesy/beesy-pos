import { useEffect, useState } from 'react';
import { Sheet } from '../components/Sheet';
import { DbError, createOrder, getSettings } from '../lib/db';
import type { CreateOrderInput } from '../lib/db';
import { buildVietQRUrl, formatVND, uuid } from '../lib/format';
import { queueOrder } from '../lib/offline';
import { useToast } from '../components/Toast';
import { BillPrint } from './BillPrint';
import type { CartLine, Customer, Order, PaymentMethod } from '../lib/types';

const QUICK_CASH = [20000, 50000, 100000, 200000, 500000];

interface BankInfo {
  shop_name: string;
  bank_bin: string;
  bank_account: string;
  bank_account_name: string;
}

export function CheckoutModal({
  lines,
  customer,
  total,
  onClose,
  onDone,
}: {
  lines: CartLine[];
  customer: Customer | null;
  total: number;
  onClose: () => void;
  onDone: (order: Order | null, queued: boolean) => void;
}) {
  const toast = useToast();
  const [method, setMethod] = useState<PaymentMethod>('cash');
  const [received, setReceived] = useState('');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const [bank, setBank] = useState<BankInfo | null>(null);
  const [paidOrder, setPaidOrder] = useState<Order | null>(null);
  const [queuedUuid, setQueuedUuid] = useState<string | null>(null);

  useEffect(() => {
    getSettings()
      .then((s) =>
        setBank({
          shop_name: s.shop_name || 'Beesy Coffee & Tea',
          bank_bin: s.bank_bin || '',
          bank_account: s.bank_account || '',
          bank_account_name: s.bank_account_name || '',
        }),
      )
      .catch(() => {});
  }, []);

  const receivedNum = parseInt(received.replace(/\D/g, ''), 10) || 0;
  const change = receivedNum - total;

  const buildInput = (m: PaymentMethod, clientUuid: string): CreateOrderInput => ({
    clientUuid,
    customerId: customer?.id ?? null,
    items: lines.map((l) => ({
      productId: l.product.id,
      qty: l.qty,
      modifierOptionIds: l.modifiers.map((x) => x.option_id),
      note: l.note || undefined,
    })),
    paymentMethod: m,
    amountReceived: m === 'cash' ? receivedNum : undefined,
    note: note.trim() || null,
  });

  const submit = async (m: PaymentMethod) => {
    if (m === 'cash' && receivedNum < total) {
      toast.show('Tiền khách đưa chưa đủ');
      return;
    }
    setBusy(true);
    const clientUuid = uuid();
    const input = buildInput(m, clientUuid);
    try {
      const order = await createOrder(input);
      setPaidOrder(order);
    } catch (e) {
      if (e instanceof DbError && e.code === 'unavailable') {
        // Offline → lưu outbox, vẫn coi như bán xong
        queueOrder({ clientUuid, createdAt: new Date().toISOString(), payload: input });
        setQueuedUuid(clientUuid);
      } else {
        toast.show(e instanceof DbError ? e.message : 'Tạo đơn thất bại');
      }
    } finally {
      setBusy(false);
    }
  };

  // ---- Màn hình sau thanh toán: QR (chuyển khoản) + in bill ----
  if (paidOrder || queuedUuid) {
    const showQR = paidOrder?.payment_method === 'transfer' && bank?.bank_bin && bank?.bank_account;
    return (
      <Sheet
        title={paidOrder ? `✅ Đơn ${paidOrder.code} thành công` : '✅ Đã lưu đơn chờ'}
        onClose={() => onDone(paidOrder, !!queuedUuid)}
        footer={
          <div className="row">
            {paidOrder && (
              <button className="btn btn-outline grow" onClick={() => window.print()}>
                🖨️ In bill
              </button>
            )}
            <button className="btn grow" onClick={() => onDone(paidOrder, !!queuedUuid)}>
              Đơn mới ➜
            </button>
          </div>
        }
      >
        {showQR && paidOrder && bank && (
          <div className="qr-box">
            <img
              src={buildVietQRUrl(bank.bank_bin, bank.bank_account, bank.bank_account_name || bank.shop_name, paidOrder.total, paidOrder.code)}
              alt={`Mã VietQR đơn ${paidOrder.code}`}
            />
            <p style={{ marginTop: 8 }}>
              <b>{bank.bank_account_name}</b>
              <br />
              <span className="muted">
                STK: {bank.bank_account} · Số tiền: <span className="money">{formatVND(paidOrder.total)}</span>
                <br />
                Nội dung: <b>{paidOrder.code}</b>
              </span>
            </p>
            <p className="small" style={{ color: 'var(--amber)' }}>
              Khách quét mã để chuyển khoản đúng số tiền &amp; nội dung. Nhân viên xác nhận đã nhận tiền rồi bấm “In bill”.
            </p>
          </div>
        )}
        {paidOrder ? (
          <BillPrint order={paidOrder} shopName={bank?.shop_name || 'Beesy Coffee & Tea'} />
        ) : (
          <div className="card">
            <p>📶 Đang offline — đơn đã lưu vào hàng chờ và sẽ <b>tự đồng bộ</b> khi có mạng (mã đơn sẽ hiện sau khi đồng bộ).</p>
            <p className="muted small">Tổng: <span className="money">{formatVND(total)}</span> · {lines.length} dòng món</p>
          </div>
        )}
      </Sheet>
    );
  }

  return (
    <Sheet
      title={`💳 Thanh toán — ${formatVND(total)}`}
      onClose={onClose}
      footer={
        method === 'cash' ? (
          <button className="btn btn-green btn-block btn-lg" disabled={busy || receivedNum < total} onClick={() => submit('cash')}>
            {busy ? 'Đang xử lý…' : `Xác nhận thu ${formatVND(total)}`}
          </button>
        ) : (
          <button
            className="btn btn-green btn-block btn-lg"
            disabled={busy || !bank?.bank_bin || !bank?.bank_account}
            onClick={() => submit('transfer')}
          >
            {busy ? 'Đang tạo đơn…' : 'Tạo đơn & lấy mã QR'}
          </button>
        )
      }
    >
      <div className="pay-tabs">
        <button className={`pay-tab${method === 'cash' ? ' active' : ''}`} onClick={() => setMethod('cash')}>
          💵 Tiền mặt
        </button>
        <button className={`pay-tab${method === 'transfer' ? ' active' : ''}`} onClick={() => setMethod('transfer')}>
          📱 Chuyển khoản
        </button>
      </div>

      {method === 'cash' ? (
        <>
          <div className="field">
            <label htmlFor="received">Tiền khách đưa</label>
            <input
              id="received"
              className="input"
              inputMode="numeric"
              placeholder="Nhập số tiền…"
              value={received}
              onChange={(e) => setReceived(e.target.value)}
            />
          </div>
          <div className="quick-cash">
            {QUICK_CASH.map((v) => (
              <button key={v} className="btn btn-outline" style={{ minHeight: 48 }} onClick={() => setReceived(String(v))}>
                {formatVND(v)}
              </button>
            ))}
            <button className="btn btn-outline" style={{ minHeight: 48 }} onClick={() => setReceived(String(total))}>
              Vừa đủ
            </button>
          </div>
          {receivedNum > 0 && (
            <div className="change-box" style={change < 0 ? { background: 'var(--red-bg)', color: 'var(--red)' } : undefined}>
              {change >= 0 ? `Thối lại: ${formatVND(change)}` : `Còn thiếu: ${formatVND(-change)}`}
            </div>
          )}
        </>
      ) : (
        <div className="card" style={{ marginBottom: 8 }}>
          {bank?.bank_bin && bank?.bank_account ? (
            <p style={{ margin: 0 }}>
              📱 Bấm <b>“Tạo đơn &amp; lấy mã QR”</b> — hệ thống tạo đơn, sinh mã (VD A001) rồi hiện
              mã VietQR đúng số tiền &amp; nội dung để khách quét.
              <br />
              <span className="muted small">{bank.bank_account_name} · {bank.bank_account}</span>
            </p>
          ) : (
            <p className="muted" style={{ margin: 0 }}>Chưa cấu hình ngân hàng — vào Cài đặt để nhập BIN, số tài khoản.</p>
          )}
        </div>
      )}

      <div className="field" style={{ marginTop: 8 }}>
        <label htmlFor="order-note">Ghi chú đơn</label>
        <input id="order-note" className="input" placeholder="VD: khách chờ lấy…" value={note} onChange={(e) => setNote(e.target.value)} />
      </div>
      {customer && (
        <p className="small">👤 Khách: <b>{customer.name}</b> — đơn này được +1 tem 🎟️</p>
      )}
    </Sheet>
  );
}
