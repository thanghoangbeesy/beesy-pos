import { useEffect, useState } from 'react';
import { DbError, createOrder, getSettings, listPaymentMethods } from '../lib/db';
import type { CreateOrderInput } from '../lib/db';
import { buildVietQRUrl, formatVND, uuid } from '../lib/format';
import { queueOrder } from '../lib/offline';
import { useToast } from '../components/Toast';
import { CustomerPickSheet } from '../components/CustomerPickSheet';
import { BillPrint } from './BillPrint';
import type { CartLine, Customer, Order, PaymentMethodDef } from '../lib/types';

const QUICK_CASH = [20000, 50000, 100000, 200000, 500000];

export function CheckoutModal({
  lines,
  customer,
  total,
  warehouseId,
  onClose,
  onUpdateQty,
  onCustomerChange,
  onSaveDraft,
  onDone,
}: {
  lines: CartLine[];
  customer: Customer | null;
  total: number;
  warehouseId: string;
  onClose: () => void;
  onUpdateQty: (key: string, qty: number) => void;
  onCustomerChange: (c: Customer | null) => void;
  onSaveDraft?: () => void;
  onDone: (order: Order | null, queued: boolean) => void;
}) {
  const toast = useToast();
  const [methods, setMethods] = useState<PaymentMethodDef[]>([]);
  const [methodId, setMethodId] = useState('');
  const [received, setReceived] = useState('');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const [fallbackBank, setFallbackBank] = useState({ bin: '', account: '', name: '' });
  const [shopName, setShopName] = useState('Beesy Coffee & Tea');
  const [paidOrder, setPaidOrder] = useState<Order | null>(null);
  const [paidMethod, setPaidMethod] = useState<PaymentMethodDef | null>(null);
  const [queuedUuid, setQueuedUuid] = useState<string | null>(null);
  // 2 bước: xác nhận đơn → thanh toán
  const [step, setStep] = useState<'confirm' | 'pay'>('confirm');
  const [pickingCustomer, setPickingCustomer] = useState(false);
  // Tiền khách trả mặc định = tổng hóa đơn để khỏi nhập tay; chạm vào sửa là giữ nguyên giá trị đã nhập
  const [receivedTouched, setReceivedTouched] = useState(false);
  const goPay = () => {
    if (!receivedTouched) setReceived(String(total));
    setStep('pay');
  };

  useEffect(() => {
    listPaymentMethods(true)
      .then((ms) => {
        setMethods(ms);
        const def = ms.find((m) => m.id === 'cash') ?? ms[0] ?? null;
        if (def) setMethodId(def.id);
      })
      .catch(() => toast.show('Không tải được phương thức thanh toán'));
    getSettings()
      .then((s) => {
        setShopName(s.shop_name || 'Beesy Coffee & Tea');
        // Dự phòng cho dữ liệu cũ: cấu hình ngân hàng trong settings
        setFallbackBank({
          bin: s.bank_bin || '',
          account: s.bank_account || '',
          name: s.bank_account_name || '',
        });
      })
      .catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const method = methods.find((m) => m.id === methodId) ?? null;
  const kind = method?.kind ?? 'cash';
  const bankBin = method?.bank_bin || fallbackBank.bin;
  const bankAccount = method?.bank_account || fallbackBank.account;
  const bankName = method?.bank_account_name || fallbackBank.name || shopName;
  const debtMethod = methods.find((m) => m.kind === 'debt');
  const cashMethod = methods.find((m) => m.kind === 'cash') ?? methods[0];

  const receivedNum = parseInt(received.replace(/\D/g, ''), 10) || 0;
  const change = receivedNum - total;

  const unitPrice = (l: CartLine) => l.product.base_price + l.modifiers.reduce((a, m) => a + m.price_delta, 0);
  const totalItems = lines.reduce((s, l) => s + l.qty, 0);

  const buildInput = (m: PaymentMethodDef, clientUuid: string): CreateOrderInput => ({
    clientUuid,
    customerId: customer?.id ?? null,
    items: lines.map((l) => ({
      productId: l.product.id,
      qty: l.qty,
      modifierOptionIds: l.modifiers.map((x) => x.option_id),
      note: l.note || undefined,
    })),
    paymentMethod: m.id,
    amountReceived: m.kind === 'cash' ? receivedNum : undefined,
    note: note.trim() || null,
    warehouseId: warehouseId || null,
  });

  const submit = async (m: PaymentMethodDef) => {
    if (m.kind === 'cash' && receivedNum < total) {
      toast.show('Tiền khách đưa chưa đủ');
      return;
    }
    if (m.kind === 'debt' && !customer) {
      toast.show('Ghi nợ cần chọn khách hàng cho đơn này');
      return;
    }
    if (!warehouseId) {
      toast.show('Chưa có kho bán — vào Tồn kho để tạo kho trước');
      return;
    }
    setBusy(true);
    const clientUuid = uuid();
    const input = buildInput(m, clientUuid);
    try {
      const order = await createOrder(input);
      setPaidMethod(m);
      setPaidOrder(order);
    } catch (e) {
      if (e instanceof DbError && e.code === 'unavailable') {
        // Offline → lưu outbox, vẫn coi như bán xong
        queueOrder({ clientUuid, createdAt: new Date().toISOString(), payload: input });
        setQueuedUuid(clientUuid);
      } else {
        toast.show(e instanceof DbError ? e.message : 'Tạo đơn thất bại');
      }
    } finally {
      setBusy(false);
    }
  };

  const closeSheet = () => onClose();

  // ---- Màn hình sau thanh toán: thành công + QR (chuyển khoản) + in bill ----
  if (paidOrder || queuedUuid) {
    const showQR = paidOrder && paidMethod?.kind === 'transfer' && bankBin && bankAccount;
    return (
      <div className="fsheet-backdrop">
        <div className="fsheet" role="dialog" aria-modal="true">
          <div className="fsheet-body">
            <div className="sb-success">
              <div className="sico">✅</div>
              <h2>{paidOrder ? 'Thanh toán thành công!' : 'Đã lưu đơn chờ'}</h2>
              <div className="scode">
                {paidOrder
                  ? `Mã đơn: ${paidOrder.code}`
                  : 'Đang offline — đơn sẽ tự đồng bộ khi có mạng.'}
              </div>
            </div>
            {showQR && paidOrder && (
              <div className="qr-box">
                <img
                  src={buildVietQRUrl(bankBin, bankAccount, bankName, paidOrder.total, paidOrder.code)}
                  alt={`Mã VietQR đơn ${paidOrder.code}`}
                />
                <p style={{ marginTop: 8 }}>
                  <b>{bankName}</b>
                  <br />
                  <span className="muted">
                    STK: {bankAccount} · Số tiền: <span className="money">{formatVND(paidOrder.total)}</span>
                    <br />
                    Nội dung: <b>{paidOrder.code}</b>
                  </span>
                </p>
                <p className="small" style={{ color: 'var(--orange)' }}>
                  Khách quét mã để chuyển khoản đúng số tiền &amp; nội dung. Nhân viên xác nhận đã nhận tiền rồi bấm “In bill”.
                </p>
              </div>
            )}
            {paidOrder && paidMethod?.kind === 'debt' && customer && (
              <div className="card" style={{ marginBottom: 8 }}>
                📒 Đã ghi nợ <b className="money">{formatVND(paidOrder.total)}</b> cho <b>{customer.name}</b>.
              </div>
            )}
            {paidOrder ? (
              <BillPrint order={paidOrder} shopName={shopName} />
            ) : (
              <div className="card">
                <p>📶 Đang offline — đơn đã lưu vào hàng chờ và sẽ <b>tự đồng bộ</b> khi có mạng (mã đơn sẽ hiện sau khi đồng bộ).</p>
                <p className="muted small">Tổng: <span className="money">{formatVND(total)}</span> · {lines.length} dòng món</p>
              </div>
            )}
          </div>
          <div className="fsheet-foot">
            <div className="row" style={{ gap: 8 }}>
              {paidOrder && (
                <button className="btn btn-outline grow" onClick={() => window.print()}>
                  🖨️ In bill
                </button>
              )}
              <button className="btn grow" onClick={() => onDone(paidOrder, !!queuedUuid)}>
                Tạo đơn mới
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ---- Bước 1: Xác nhận đơn ----
  if (step === 'confirm') {
    return (
      <div
        className="fsheet-backdrop"
        onClick={(e) => {
          if (e.target === e.currentTarget) closeSheet();
        }}
      >
        <div className="fsheet" role="dialog" aria-modal="true">
          <div className="fsheet-head">
            <button className="fsheet-back" onClick={closeSheet} aria-label="Quay lại">‹</button>
            <div className="fsheet-title">Xác nhận</div>
            <span className="fsheet-side" />
          </div>
          <div className="fsheet-body">
            <button className="btn btn-outline btn-block" style={{ marginBottom: 12 }} onClick={closeSheet}>
              + Thêm sản phẩm
            </button>

            <div className="co-card">
              {lines.length === 0 ? (
                <div className="sb-empty">Chưa có món nào trong đơn.</div>
              ) : (
                lines.map((l) => (
                  <div className="co-line" key={l.key}>
                    <button className="co-remove" onClick={() => onUpdateQty(l.key, 0)} aria-label="Xóa món">
                      ×
                    </button>
                    <div className="cbody">
                      <div className="cname">{l.product.name}</div>
                      {l.modifiers.length > 0 && (
                        <div className="csub">{l.modifiers.map((m) => m.option).join(' · ')}</div>
                      )}
                      {l.note && <div className="csub">📝 {l.note}</div>}
                      <div className="qty-ctl">
                        <button className="qty-btn" onClick={() => onUpdateQty(l.key, l.qty - 1)} aria-label="Giảm">−</button>
                        <span className="qty-num">{l.qty}</span>
                        <button className="qty-btn" onClick={() => onUpdateQty(l.key, l.qty + 1)} aria-label="Tăng">+</button>
                      </div>
                    </div>
                    <div className="cprice">{formatVND(unitPrice(l) * l.qty)}</div>
                  </div>
                ))
              )}
            </div>

            <button className="co-cust" onClick={() => setPickingCustomer(true)}>
              <span>👤</span>
              <span>{customer ? `${customer.name} · ${customer.phone}` : 'Chọn khách hàng'}</span>
              <span className="chev">›</span>
            </button>
            {customer && (
              <button className="sb-link" style={{ marginBottom: 12 }} onClick={() => onCustomerChange(null)}>
                Bỏ chọn khách hàng
              </button>
            )}

            <div className="co-card">
              <div className="co-total-row">
                <span>Tiền hàng ({totalItems} món)</span>
                <span>{formatVND(total)}</span>
              </div>
              <div className="co-total-row grand">
                <span>Tổng cộng</span>
                <span className="money">{formatVND(total)}</span>
              </div>
            </div>

            <div className="sb-note-row">
              <input
                className="input grow"
                placeholder="Nhập ghi chú đơn…"
                value={note}
                onChange={(e) => setNote(e.target.value)}
              />
            </div>
          </div>
          <div className="fsheet-foot">
            <div className="row" style={{ gap: 8 }}>
              {onSaveDraft && (
                <button className="btn btn-outline grow" disabled={lines.length === 0} onClick={onSaveDraft}>
                  📋 Lưu tạm
                </button>
              )}
              <button className="btn btn-block btn-lg grow" disabled={lines.length === 0} onClick={goPay} style={{ flex: 2 }}>
                Tiếp tục thanh toán
              </button>
            </div>
          </div>
        </div>

        {pickingCustomer && (
          <CustomerPickSheet
            onClose={() => setPickingCustomer(false)}
            onPick={(c) => {
              onCustomerChange(c);
              setPickingCustomer(false);
              toast.show(`Đã chọn khách: ${c.name}`);
            }}
          />
        )}
      </div>
    );
  }

  // ---- Bước 2: Thanh toán ----
  return (
    <div
      className="fsheet-backdrop"
      onClick={(e) => {
        if (e.target === e.currentTarget) closeSheet();
      }}
    >
      <div className="fsheet" role="dialog" aria-modal="true">
        <div className="fsheet-head">
          <button className="fsheet-back" onClick={() => setStep('confirm')} aria-label="Quay lại">‹</button>
          <div className="fsheet-title">Thanh toán: {formatVND(total)}</div>
          <span className="fsheet-side" />
        </div>
        <div className="fsheet-body">
          <p className="muted" style={{ textAlign: 'center', margin: '2px 0 6px' }}>Khách trả</p>
          <input
            className="sb-money-input"
            inputMode="numeric"
            placeholder={formatVND(total)}
            value={kind === 'cash' ? received : formatVND(total)}
            disabled={kind !== 'cash'}
            onChange={(e) => { setReceived(e.target.value); setReceivedTouched(true); }}
          />

          {kind === 'cash' && (
            <>
              <div className="quick-cash">
                {QUICK_CASH.map((v) => (
                  <button key={v} className="btn btn-outline" style={{ minHeight: 48 }} onClick={() => { setReceived(String(v)); setReceivedTouched(true); }}>
                    {formatVND(v)}
                  </button>
                ))}
                <button className="btn btn-outline" style={{ minHeight: 48 }} onClick={() => { setReceived(String(total)); setReceivedTouched(true); }}>
                  Vừa đủ
                </button>
              </div>
              {receivedTouched && receivedNum > 0 && (
                <div className="change-box" style={change < 0 ? { background: 'var(--red-bg)', color: 'var(--red)' } : undefined}>
                  {change >= 0 ? `Thối lại: ${formatVND(change)}` : `Còn thiếu: ${formatVND(-change)}`}
                </div>
              )}
            </>
          )}

          <div className="sb-paygrid">
            {methods.map((m) => (
              <button
                key={m.id}
                className={`sb-paycard${m.id === methodId ? ' selected' : ''}`}
                onClick={() => setMethodId(m.id)}
              >
                <span className="pico">{m.icon}</span>
                <span>{m.name}</span>
              </button>
            ))}
          </div>

          {debtMethod && (
            <div className="sb-toggle-row">
              <span className="grow">Ghi nợ đơn</span>
              <label className="switch">
                <input
                  type="checkbox"
                  checked={kind === 'debt'}
                  onChange={(e) => {
                    if (e.target.checked) setMethodId(debtMethod.id);
                    else if (cashMethod) setMethodId(cashMethod.id);
                  }}
                />
                <span className="track" />
              </label>
            </div>
          )}

          {kind === 'transfer' && (
            <div className="card" style={{ marginBottom: 8 }}>
              {bankBin && bankAccount ? (
                <p style={{ margin: 0 }}>
                  📱 Bấm <b>“Xác nhận”</b> — hệ thống tạo đơn rồi hiện mã VietQR đúng số tiền &amp; nội dung để khách quét.
                  <br />
                  <span className="muted small">{bankName} · {bankAccount}</span>
                </p>
              ) : (
                <p className="muted" style={{ margin: 0 }}>Chưa cấu hình ngân hàng cho phương thức này — vào Cài đặt → Phương thức thanh toán để nhập BIN, số tài khoản.</p>
              )}
            </div>
          )}

          {kind === 'debt' && (
            <div className="card" style={{ marginBottom: 8 }}>
              {customer ? (
                <p style={{ margin: 0 }}>
                  📒 Ghi nợ <b className="money">{formatVND(total)}</b> cho <b>{customer.name}</b>.
                  <br />
                  <span className="muted small">
                    Công nợ hiện tại: <span className="money">{formatVND(customer.debt ?? 0)}</span>
                    {' '}→ sau đơn này: <span className="money">{formatVND((customer.debt ?? 0) + total)}</span>
                  </span>
                </p>
              ) : (
                <p className="muted" style={{ margin: 0 }}>⚠️ Ghi nợ cần chọn khách hàng — quay lại bước Xác nhận để chọn khách.</p>
              )}
            </div>
          )}

          <div className="sb-note-row">
            <input
              className="input grow"
              placeholder="Nhập ghi chú đơn…"
              value={note}
              onChange={(e) => setNote(e.target.value)}
            />
          </div>
        </div>
        <div className="fsheet-foot">
          {method && (
            <button
              className="btn btn-block btn-lg"
              disabled={
                busy ||
                (kind === 'cash' && receivedNum < total) ||
                (kind === 'debt' && !customer) ||
                (kind === 'transfer' && (!bankBin || !bankAccount))
              }
              onClick={() => submit(method)}
            >
              {busy ? 'Đang xử lý…' : 'Xác nhận'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
