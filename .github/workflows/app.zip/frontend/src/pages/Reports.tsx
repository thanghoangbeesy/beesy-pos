import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { DbError, downloadFile, exportOrdersCsv, getAllowedWarehouses, getRangeReport } from '../lib/db';
import {
  addDaysVN,
  formatDMY,
  formatVND,
  startOfMonthVN,
  startOfWeekVN,
  todayVN,
} from '../lib/format';
import { useToast } from '../components/Toast';
import { DayCloseSheet } from './DayCloseSheet';
import { useAuth } from '../lib/auth';
import AppIcon, { type AppIconName } from '../components/AppIcon';
import type { DailyReport, Warehouse } from '../lib/types';

type PresetKey =
  | 'today'
  | 'yesterday'
  | 'last7'
  | 'thisWeek'
  | 'lastWeek'
  | 'thisMonth'
  | 'lastMonth'
  | 'custom';

const PRESETS: { key: PresetKey; label: string }[] = [
  { key: 'today', label: 'Hôm nay' },
  { key: 'yesterday', label: 'Hôm qua' },
  { key: 'last7', label: '7 ngày qua' },
  { key: 'thisWeek', label: 'Tuần này' },
  { key: 'lastWeek', label: 'Tuần trước' },
  { key: 'thisMonth', label: 'Tháng này' },
  { key: 'lastMonth', label: 'Tháng trước' },
  { key: 'custom', label: 'Tùy chọn' },
];

/** Tính [start, end] (YYYY-MM-DD) cho từng mốc lọc. */
function presetRange(key: PresetKey, customStart: string, customEnd: string): [string, string] {
  const t = todayVN();
  switch (key) {
    case 'today':
      return [t, t];
    case 'yesterday': {
      const y = addDaysVN(t, -1);
      return [y, y];
    }
    case 'last7':
      return [addDaysVN(t, -6), t];
    case 'thisWeek':
      return [startOfWeekVN(t), t];
    case 'lastWeek': {
      const mondayThis = startOfWeekVN(t);
      const mondayLast = addDaysVN(mondayThis, -7);
      return [mondayLast, addDaysVN(mondayLast, 6)];
    }
    case 'thisMonth':
      return [startOfMonthVN(t), t];
    case 'lastMonth': {
      const firstThisMonth = startOfMonthVN(t);
      const lastDayPrev = addDaysVN(firstThisMonth, -1);
      return [startOfMonthVN(lastDayPrev), lastDayPrev];
    }
    case 'custom':
      return [customStart, customEnd];
  }
}

export function Reports() {
  const toast = useToast();
  const { can } = useAuth();
  const navigate = useNavigate();
  const reportRef = useRef<HTMLDivElement>(null);
  const [preset, setPreset] = useState<PresetKey>('today');
  const [customStart, setCustomStart] = useState(todayVN());
  const [customEnd, setCustomEnd] = useState(todayVN());
  const [range, setRange] = useState<[string, string]>(() => presetRange('today', todayVN(), todayVN()));
  const [report, setReport] = useState<DailyReport | null>(null);
  const [busy, setBusy] = useState(false);
  const [topSort, setTopSort] = useState<'qty' | 'revenue' | 'profit'>('qty');
  const [topDir, setTopDir] = useState<'desc' | 'asc'>('desc');
  const [dayCloseOpen, setDayCloseOpen] = useState(false);
  const [exportBusy, setExportBusy] = useState(false);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [isOwner, setIsOwner] = useState(false);
  const [whFilter, setWhFilter] = useState('all');
  const [whReady, setWhReady] = useState(false);

  const sortedTop = useMemo(() => {
    const arr = [...(report?.top_products ?? [])];
    arr.sort((a, b) => {
      const d = a[topSort] - b[topSort];
      return topDir === 'desc' ? -d : d;
    });
    return arr.slice(0, 10);
  }, [report, topSort, topDir]);
  const [q, setQ] = useState('');
  // Phạm vi kho được xem: chủ quán xem 'Mọi kho' = toàn bộ (kể cả đơn cũ chưa có kho);
  // nhân viên chỉ các kho đã gán.
  const scopeIds =
    whFilter === 'all' ? (isOwner ? undefined : warehouses.map((w) => w.id)) : [whFilter];

  const load = useCallback(
    async (start: string, end: string, ids?: string[]) => {
      if (!start || !end) {
        toast.show('Vui lòng chọn đầy đủ ngày bắt đầu và kết thúc');
        return;
      }
      if (start > end) {
        toast.show('Ngày bắt đầu phải trước ngày kết thúc');
        return;
      }
      setBusy(true);
      try {
        const data = await getRangeReport(start, end, ids ?? scopeIds);
        setReport(data);
        setRange([start, end]);
      } catch (e) {
        toast.show(e instanceof DbError ? e.message : 'Không tải được báo cáo');
      } finally {
        setBusy(false);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [scopeIds],
  );

  useEffect(() => {
    // Nạp danh sách kho được phép xem trước, rồi mới tải báo cáo (tránh lộ số liệu kho khác)
    getAllowedWarehouses()
      .then(({ warehouses: ws, isOwner: ow }) => {
        setWarehouses(ws);
        setIsOwner(ow);
      })
      .catch(() => {})
      .finally(() => setWhReady(true));
  }, []);

  useEffect(() => {
    if (!whReady) return;
    const [s, e] = presetRange('today', todayVN(), todayVN());
    void load(s, e);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [whReady]);

  const changeWh = (id: string) => {
    setWhFilter(id);
    const ids = id === 'all' ? (isOwner ? undefined : warehouses.map((w) => w.id)) : [id];
    void load(range[0], range[1], ids);
  };

  const pickPreset = (key: PresetKey) => {
    setPreset(key);
    const [s, e] = presetRange(key, customStart, customEnd);
    void load(s, e);
  };

  const applyCustom = () => {
    const [s, e] = presetRange('custom', customStart, customEnd);
    void load(s, e);
  };

  const maxHour = Math.max(1, ...(report?.by_hour.map((h) => h.revenue) ?? [1]));
  const rangeLabel =
    range[0] === range[1] ? formatDMY(range[0]) : `${formatDMY(range[0])} → ${formatDMY(range[1])}`;

  const scrollToReport = () => {
    reportRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const goPos = () => {
    navigate('/pos');
  };

  const escapeHtml = (v: string) =>
    String(v ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');

  const doExportExcel = async () => {    setExportBusy(true);
    try {
      const csv = await exportOrdersCsv(range[0], range[1], scopeIds);
      downloadFile(`beesy-don-hang_${range[0]}_${range[1]}.csv`, csv, 'text/csv');
      toast.show('Đã xuất file Excel');
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Xuất file thất bại');
    } finally {
      setExportBusy(false);
    }
  };

  const doPrintPdf = () => {
    if (!report) {
      toast.show('Chưa có dữ liệu báo cáo');
      return;
    }
    let root = document.getElementById('print-root');
    if (!root) {
      root = document.createElement('div');
      root.id = 'print-root';
      document.body.appendChild(root);
    }
    const payRows = Object.values(report.by_payment)
      .map((v) => `<tr><td>${escapeHtml(v.name)}</td><td class="r">${v.count}</td><td class="r">${formatVND(v.revenue)}</td></tr>`)
      .join('');
    const topRows = (report.top_products ?? [])
      .slice(0, 10)
      .map((t) => `<tr><td>${escapeHtml(t.name)}</td><td class="r">${t.qty}</td><td class="r">${formatVND(t.revenue)}</td><td class="r">${formatVND(t.profit)}</td></tr>`)
      .join('');
    root.innerHTML = `<div id="report-print-area">
      <h2>BEESY COFFEE &amp; TEA — BÁO CÁO BÁN HÀNG</h2>
      <p class="center">Kỳ: ${rangeLabel}</p>
      <table>
        <tr><td>Doanh thu</td><td class="r"><b>${formatVND(report.revenue)}</b></td></tr>
        <tr><td>Lợi nhuận</td><td class="r">${formatVND(report.profit)}</td></tr>
        <tr><td>Số đơn</td><td class="r">${report.order_count}</td></tr>
      </table>
      <h3>Theo phương thức thanh toán</h3>
      <table><tr><th>Phương thức</th><th class="r">Số đơn</th><th class="r">Doanh thu</th></tr>${payRows}</table>
      <h3>Món bán chạy (Top 10)</h3>
      <table><tr><th>Món</th><th class="r">SL</th><th class="r">Doanh thu</th><th class="r">Lợi nhuận</th></tr>${topRows}</table>
      <p class="small">In lúc ${new Date().toLocaleString('vi-VN', { timeZone: 'Asia/Ho_Chi_Minh' })}</p>
    </div>`;
    window.print();
  };

  if (!can('reports')) {
    return (
      <div className="page">
        <div className="card">🔒 Chỉ Quản lý trở lên mới được xem báo cáo.</div>
      </div>
    );
  }

  return (
    <div className="page home-page">
      {/* Header xanh lá: tên quán + ô tìm món bán */}
      <div className="pg-home">
        <div className="pg-home-row">
          <span className="pg-shop-av" role="img" aria-label="Cửa hàng">🏪</span>
          <div className="grow">
            <div className="pg-shop-name">Beesy Coffee &amp; Tea</div>
            <div className="pg-shop-sub">Hôm nay, {formatDMY(todayVN())}</div>
          </div>
        </div>
        <div className="sb-search-light">
          <span className="sico" aria-hidden>⌕</span>
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') goPos();
            }}
            placeholder="Tìm món để bán…"
            aria-label="Tìm món để bán"
          />
        </div>
      </div>

      {/* Thẻ doanh thu trắng nổi */}
      <div className="sb-hero">
        <div className="sb-hero-top">
          <span className="sb-hero-label">Doanh thu</span>
          <button className="sb-hero-link" onClick={scrollToReport}>
            Xem chi tiết ›
          </button>
        </div>
        <div className="sb-hero-value">{busy && !report ? '…' : formatVND(report?.revenue ?? 0)}</div>
        <div className="sb-hero-sub">
          {report?.order_count ?? 0} đơn · {rangeLabel}
        </div>
      </div>

      {/* Lưới thao tác nhanh */}
      <div className="sb-action-grid">
        {ACTIONS.map((a) => (
          <button key={a.to} className="sb-action" onClick={() => navigate(a.to)}>
            <span className="sb-action-ico3d">
              <AppIcon name={a.icon} fallback={a.fb} size={46} />
            </span>
            <span className="sb-action-label">{a.label}</span>
          </button>
        ))}
      </div>

      {dayCloseOpen && <DayCloseSheet onClose={() => setDayCloseOpen(false)} />}

      {/* Báo cáo chi tiết */}
      <div ref={reportRef}>
        <div className="sb-section">
          <h3 className="sb-section-title">Báo cáo bán hàng</h3>

          <div className="row" style={{ marginBottom: 10, gap: 8, alignItems: 'center' }}>
            <select
              className="input grow"
              value={preset}
              onChange={(e) => pickPreset(e.target.value as PresetKey)}
              aria-label="Chọn khoảng thời gian"
            >
              {PRESETS.map((p) => (
                <option key={p.key} value={p.key}>
                  {p.label}
                </option>
              ))}
            </select>
          </div>
          {warehouses.length > 1 && (
            <div className="row" style={{ marginBottom: 12, gap: 8, flexWrap: 'wrap' }}>
              <button className={`sb-chip${whFilter === 'all' ? ' selected' : ''}`} onClick={() => changeWh('all')}>
                Mọi kho
              </button>
              {warehouses.map((w) => (
                <button key={w.id} className={`sb-chip${whFilter === w.id ? ' selected' : ''}`} onClick={() => changeWh(w.id)}>
                  {w.name}
                </button>
              ))}
            </div>
          )}
          <div className="row" style={{ marginBottom: 12, gap: 8, flexWrap: 'wrap' }}>
            <button className="btn btn-outline" style={{ minHeight: 44 }} disabled={exportBusy} onClick={doExportExcel}>
              {exportBusy ? 'Đang xuất…' : '⬇ Excel'}
            </button>
            <button className="btn btn-outline" style={{ minHeight: 44 }} onClick={doPrintPdf}>
              🖨 PDF
            </button>
            <button className="btn" style={{ minHeight: 44 }} onClick={() => setDayCloseOpen(true)}>
              🌙 Chốt ngày
            </button>
          </div>

          {preset === 'custom' && (
            <div className="row" style={{ marginBottom: 12, gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
              <span className="small muted">Từ</span>
              <input
                type="date"
                className="input"
                style={{ width: 'auto' }}
                value={customStart}
                max={todayVN()}
                onChange={(e) => setCustomStart(e.target.value)}
              />
              <span className="small muted">đến</span>
              <input
                type="date"
                className="input"
                style={{ width: 'auto' }}
                value={customEnd}
                max={todayVN()}
                onChange={(e) => setCustomEnd(e.target.value)}
              />
              <button className="btn btn-sm" onClick={applyCustom} disabled={busy}>
                Xem
              </button>
            </div>
          )}

          {busy && !report ? (
            <p className="muted small">Đang tải…</p>
          ) : report ? (
            <>
              <div className="stat-cards">
                <div className="stat-card pastel-blue">
                  <div className="label">Số đơn</div>
                  <div className="value">{report.order_count}</div>
                </div>
                <div className="stat-card pastel-green">
                  <div className="label">Lợi nhuận</div>
                  <div className="value text-green" style={{ fontSize: 19 }}>{formatVND(report.profit)}</div>
                  <div className="small muted">doanh thu {formatVND(report.revenue)}</div>
                </div>
                {Object.entries(report.by_payment).map(([key, slot], i) => (
                  <div className={`stat-card ${['pastel-green', 'pastel-yellow', 'pastel-purple'][i % 3]}`} key={key}>
                    <div className="label">{slot.name}</div>
                    <div className="value text-green" style={{ fontSize: 19 }}>{formatVND(slot.revenue)}</div>
                    <div className="small muted">{slot.count} đơn</div>
                  </div>
                ))}
              </div>

              <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center', margin: '4px 0 8px' }}>
                <div className="small muted" style={{ fontWeight: 600 }}>
                  Món bán chạy
                </div>
                <button
                  type="button"
                  className="sb-chip"
                  style={{ minHeight: 36, padding: '4px 12px', fontSize: 13 }}
                  onClick={() => setTopDir((d) => (d === 'desc' ? 'asc' : 'desc'))}
                  aria-label="Đổi thứ tự sắp xếp"
                >
                  {topDir === 'desc' ? '↓ Giảm dần' : '↑ Tăng dần'}
                </button>
              </div>
              <div className="row" style={{ gap: 8, marginBottom: 8 }}>
                {(
                  [
                    ['qty', 'Số lượng'],
                    ['revenue', 'Doanh thu'],
                    ['profit', 'Lợi nhuận'],
                  ] as const
                ).map(([k, label]) => (
                  <button
                    key={k}
                    type="button"
                    className={`sb-chip${topSort === k ? ' selected' : ''}`}
                    style={{ minHeight: 36, padding: '4px 12px', fontSize: 13 }}
                    onClick={() => setTopSort(k)}
                  >
                    {label}
                  </button>
                ))}
              </div>
              {sortedTop.map((p) => (
                <div className="sb-row" key={p.product_id}>
                  <div className="rbody">
                    <span className="rtitle">{p.name}</span>
                    <span className="rsub">
                      {p.qty} món · lãi <span className="text-green" style={{ fontWeight: 600 }}>{formatVND(p.profit)}</span>
                    </span>
                  </div>
                  <span className="ramount">{formatVND(p.revenue)}</span>
                </div>
              ))}
              {sortedTop.length === 0 && <p className="muted small">Chưa có dữ liệu</p>}

              <div className="small muted" style={{ fontWeight: 600, margin: '14px 0 8px' }}>
                Doanh thu theo giờ
              </div>
              <div className="hour-chart">
                {report.by_hour.map((h) => (
                  <div className="hour-bar" key={h.hour} title={`${h.hour}h: ${formatVND(h.revenue)} (${h.count} đơn)`}>
                    <div className="bar" style={{ height: `${Math.round((h.revenue / maxHour) * 120)}px` }} />
                    <div className="h">{h.hour}</div>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <p className="muted">Không có dữ liệu</p>
          )}
        </div>
      </div>
    </div>
  );
}

// Lưới thao tác nhanh trên trang chủ — icon màu trên nền pastel, nhãn bên dưới
const ACTIONS: { to: string; icon: AppIconName; fb: string; label: string }[] = [
  { to: '/pos', icon: 'receipt', fb: '🧾', label: 'Bán hàng' },
  { to: '/orders', icon: 'package', fb: '📦', label: 'Đơn hàng' },
  { to: '/menu', icon: 'clipboard', fb: '📋', label: 'Menu' },
  { to: '/customers', icon: 'users', fb: '👥', label: 'Khách hàng' },
  { to: '/debt', icon: 'ledger', fb: '📒', label: 'Sổ nợ' },
  { to: '/so-quy', icon: 'moneybag', fb: '💰', label: 'Sổ quỹ' },
  { to: '/kds', icon: 'chef', fb: '👨‍🍳', label: 'Pha chế' },
  { to: '/settings', icon: 'gear', fb: '⚙️', label: 'Cài đặt' },
];
