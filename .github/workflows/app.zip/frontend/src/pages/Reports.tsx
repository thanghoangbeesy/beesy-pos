import { useCallback, useEffect, useState } from 'react';
import { DbError, getRangeReport } from '../lib/db';
import {
  addDaysVN,
  formatDMY,
  formatVND,
  startOfMonthVN,
  startOfWeekVN,
  todayVN,
} from '../lib/format';
import { useToast } from '../components/Toast';
import type { DailyReport } from '../lib/types';

type PresetKey =
  | 'today'
  | 'yesterday'
  | 'last7'
  | 'thisWeek'
  | 'lastWeek'
  | 'thisMonth'
  | 'lastMonth'
  | 'custom';

const PRESETS: { key: PresetKey; label: string }[] = [
  { key: 'today', label: 'Hôm nay' },
  { key: 'yesterday', label: 'Hôm qua' },
  { key: 'last7', label: '7 ngày qua' },
  { key: 'thisWeek', label: 'Tuần này' },
  { key: 'lastWeek', label: 'Tuần trước' },
  { key: 'thisMonth', label: 'Tháng này' },
  { key: 'lastMonth', label: 'Tháng trước' },
  { key: 'custom', label: 'Tùy chọn' },
];

/** Tính [start, end] (YYYY-MM-DD) cho từng mốc lọc. */
function presetRange(key: PresetKey, customStart: string, customEnd: string): [string, string] {
  const t = todayVN();
  switch (key) {
    case 'today':
      return [t, t];
    case 'yesterday': {
      const y = addDaysVN(t, -1);
      return [y, y];
    }
    case 'last7':
      return [addDaysVN(t, -6), t];
    case 'thisWeek':
      return [startOfWeekVN(t), t];
    case 'lastWeek': {
      const mondayThis = startOfWeekVN(t);
      const mondayLast = addDaysVN(mondayThis, -7);
      return [mondayLast, addDaysVN(mondayLast, 6)];
    }
    case 'thisMonth':
      return [startOfMonthVN(t), t];
    case 'lastMonth': {
      const firstThisMonth = startOfMonthVN(t);
      const lastDayPrev = addDaysVN(firstThisMonth, -1);
      return [startOfMonthVN(lastDayPrev), lastDayPrev];
    }
    case 'custom':
      return [customStart, customEnd];
  }
}

export function Reports() {
  const toast = useToast();
  const [preset, setPreset] = useState<PresetKey>('today');
  const [customStart, setCustomStart] = useState(todayVN());
  const [customEnd, setCustomEnd] = useState(todayVN());
  const [range, setRange] = useState<[string, string]>(() => presetRange('today', todayVN(), todayVN()));
  const [report, setReport] = useState<DailyReport | null>(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(
    async (start: string, end: string) => {
      if (!start || !end) {
        toast.show('Vui lòng chọn đầy đủ ngày bắt đầu và kết thúc');
        return;
      }
      if (start > end) {
        toast.show('Ngày bắt đầu phải trước ngày kết thúc');
        return;
      }
      setBusy(true);
      try {
        const data = await getRangeReport(start, end);
        setReport(data);
        setRange([start, end]);
      } catch (e) {
        toast.show(e instanceof DbError ? e.message : 'Không tải được báo cáo');
      } finally {
        setBusy(false);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [],
  );

  useEffect(() => {
    const [s, e] = presetRange('today', todayVN(), todayVN());
    void load(s, e);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const pickPreset = (key: PresetKey) => {
    setPreset(key);
    const [s, e] = presetRange(key, customStart, customEnd);
    void load(s, e);
  };

  const applyCustom = () => {
    const [s, e] = presetRange('custom', customStart, customEnd);
    void load(s, e);
  };

  const maxHour = Math.max(1, ...(report?.by_hour.map((h) => h.revenue) ?? [1]));
  const rangeLabel =
    range[0] === range[1] ? formatDMY(range[0]) : `${formatDMY(range[0])} → ${formatDMY(range[1])}`;

  return (
    <div className="page">
      <div className="row" style={{ marginBottom: 10, flexWrap: 'wrap', gap: 8 }}>
        <h1 style={{ margin: 0 }} className="grow">
          📊 Tổng quan
        </h1>
        <span className="muted small">{rangeLabel}</span>
      </div>

      <div className="row" style={{ marginBottom: 8, gap: 8, alignItems: 'center' }}>
        <span className="small muted">🗓️</span>
        <select
          className="input grow"
          value={preset}
          onChange={(e) => pickPreset(e.target.value as PresetKey)}
          aria-label="Chọn khoảng thời gian"
        >
          {PRESETS.map((p) => (
            <option key={p.key} value={p.key}>
              {p.label}
            </option>
          ))}
        </select>
      </div>

      {preset === 'custom' && (
        <div className="row" style={{ marginBottom: 14, gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
          <span className="small muted">Từ</span>
          <input
            type="date"
            className="input"
            style={{ width: 'auto' }}
            value={customStart}
            max={todayVN()}
            onChange={(e) => setCustomStart(e.target.value)}
          />
          <span className="small muted">đến</span>
          <input
            type="date"
            className="input"
            style={{ width: 'auto' }}
            value={customEnd}
            max={todayVN()}
            onChange={(e) => setCustomEnd(e.target.value)}
          />
          <button className="btn btn-sm" onClick={applyCustom} disabled={busy}>
            Xem
          </button>
        </div>
      )}

      {busy && !report ? (
        <div className="card">Đang tải…</div>
      ) : report ? (
        <>
          <div className="hero-card">
            <div className="hero-label">💰 Doanh thu</div>
            <div className="hero-value">{formatVND(report.revenue)}</div>
            <div className="hero-sub">🧾 {report.order_count} đơn · {rangeLabel}</div>
          </div>
          <div className="stat-cards">
            <div className="stat-card pastel-blue">
              <div className="label">🧾 Số đơn</div>
              <div className="value">{report.order_count}</div>
            </div>
            {Object.entries(report.by_payment).map(([key, slot], i) => (
              <div className={`stat-card ${['pastel-green', 'pastel-yellow', 'pastel-purple'][i % 3]}`} key={key}>
                <div className="label">💳 {slot.name}</div>
                <div className="value text-green" style={{ fontSize: 19 }}>{formatVND(slot.revenue)}</div>
                <div className="small muted">{slot.count} đơn</div>
              </div>
            ))}
          </div>

          <div className="card" style={{ marginBottom: 12 }}>
            <span className="section-title">🏆 Top món bán chạy</span>
            <div className="table-wrap">
              <table className="tbl">
                <thead><tr><th>#</th><th>Món</th><th>SL</th><th style={{ textAlign: 'right' }}>Doanh thu</th></tr></thead>
                <tbody>
                  {report.top_products.map((p, i) => (
                    <tr key={p.product_id}>
                      <td>{i + 1}</td>
                      <td>{p.name}</td>
                      <td><b>{p.qty}</b></td>
                      <td style={{ textAlign: 'right' }} className="money">{formatVND(p.revenue)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {report.top_products.length === 0 && <p className="muted small">Chưa có dữ liệu</p>}
          </div>

          <div className="card">
            <span className="section-title">⏰ Doanh thu theo giờ</span>
            <div className="hour-chart">
              {report.by_hour.map((h) => (
                <div className="hour-bar" key={h.hour} title={`${h.hour}h: ${formatVND(h.revenue)} (${h.count} đơn)`}>
                  <div className="bar" style={{ height: `${Math.round((h.revenue / maxHour) * 120)}px` }} />
                  <div className="h">{h.hour}</div>
                </div>
              ))}
            </div>
          </div>
        </>
      ) : (
        <div className="card muted">Không có dữ liệu</div>
      )}
    </div>
  );
}
