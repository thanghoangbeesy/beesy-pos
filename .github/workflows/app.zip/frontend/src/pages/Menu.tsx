import { useCallback, useEffect, useRef, useState } from 'react';
import type { ChangeEvent, FormEvent } from 'react';
import {
  DbError,
  createCategory,
  createModifierOption,
  createProduct,
  listCategories,
  listModifierGroups,
  listProducts,
  updateCategory,
  updateModifierOption,
  updateProduct,
} from '../lib/db';
import { ensureDriveToken, isDriveConfigured, uploadProductImage } from '../lib/drive';
import { formatVND } from '../lib/format';
import { Sheet } from '../components/Sheet';
import { useToast } from '../components/Toast';
import { useAuth } from '../lib/auth';
import type { Category, ModifierGroup, Product } from '../lib/types';

type Tab = 'products' | 'categories' | 'modifiers';

export function Menu() {
  const toast = useToast();
  const { isOwner } = useAuth();
  const [tab, setTab] = useState<Tab>('products');
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [groups, setGroups] = useState<ModifierGroup[]>([]);
  const [loading, setLoading] = useState(true);

  const reload = useCallback(async () => {
    try {
      const [cats, prods, gs] = await Promise.all([
        listCategories(),
        listProducts(),
        listModifierGroups(),
      ]);
      setCategories(cats.sort((a, b) => a.sort_order - b.sort_order));
      setProducts(prods.sort((a, b) => a.sort_order - b.sort_order));
      setGroups(gs.sort((a, b) => a.sort_order - b.sort_order));
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tải được menu');
    } finally {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    void reload();
  }, [reload]);

  if (!isOwner) {
    return (
      <div className="page">
        <div className="card">🔒 Chỉ chủ quán mới được quản lý menu.</div>
      </div>
    );
  }

  return (
    <div className="page">
      <h1>📋 Quản lý menu</h1>
      <div className="cat-tabs" style={{ marginBottom: 14 }}>
        <button className={`cat-tab${tab === 'products' ? ' active' : ''}`} onClick={() => setTab('products')}>🍹 Món</button>
        <button className={`cat-tab${tab === 'categories' ? ' active' : ''}`} onClick={() => setTab('categories')}>📂 Danh mục</button>
        <button className={`cat-tab${tab === 'modifiers' ? ' active' : ''}`} onClick={() => setTab('modifiers')}>🧋 Topping / Tùy chọn</button>
      </div>
      {loading ? (
        <div className="card">Đang tải…</div>
      ) : tab === 'products' ? (
        <ProductsTab products={products} categories={categories} reload={reload} />
      ) : tab === 'categories' ? (
        <CategoriesTab categories={categories} reload={reload} />
      ) : (
        <ModifiersTab groups={groups} reload={reload} />
      )}
    </div>
  );
}

/* ---------------- Món ---------------- */
function ProductsTab({ products, categories, reload }: { products: Product[]; categories: Category[]; reload: () => Promise<void> }) {
  const toast = useToast();
  const [editing, setEditing] = useState<Product | 'new' | null>(null);

  const toggleActive = async (p: Product) => {
    try {
      await updateProduct(p.id, { active: !p.active });
      toast.show(p.active ? `Đã ẩn “${p.name}”` : `Đã hiện “${p.name}”`);
      await reload();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Thất bại');
    }
  };

  const catName = (id: string | null) => categories.find((c) => c.id === id)?.name ?? '—';

  return (
    <>
      <button className="btn" style={{ marginBottom: 12 }} onClick={() => setEditing('new')}>➕ Thêm món</button>
      <div className="card" style={{ padding: 0 }}>
        <div className="table-wrap">
          <table className="tbl">
            <thead>
              <tr><th>Món</th><th>Giá</th><th>Danh mục</th><th>Trạng thái</th><th></th></tr>
            </thead>
            <tbody>
              {products.map((p) => (
                <tr key={p.id} style={p.active ? undefined : { opacity: 0.5 }}>
                  <td><b>{p.name}</b></td>
                  <td className="money">{formatVND(p.base_price)}</td>
                  <td>{catName(p.category_id)}</td>
                  <td>{p.active ? '✅ Đang bán' : '🚫 Đang ẩn'}</td>
                  <td style={{ whiteSpace: 'nowrap' }}>
                    <button className="btn btn-outline" style={{ minHeight: 40, padding: '6px 12px', marginRight: 6 }} onClick={() => toggleActive(p)}>
                      {p.active ? 'Ẩn' : 'Hiện'}
                    </button>
                    <button className="btn btn-ghost" style={{ minHeight: 40, padding: '6px 12px' }} onClick={() => setEditing(p)}>
                      Sửa
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      {editing && (
        <ProductForm product={editing === 'new' ? null : editing} categories={categories} onClose={() => setEditing(null)} reload={reload} />
      )}
    </>
  );
}

function ProductForm({ product, categories, onClose, reload }: { product: Product | null; categories: Category[]; onClose: () => void; reload: () => Promise<void> }) {
  const toast = useToast();
  const [name, setName] = useState(product?.name ?? '');
  const [price, setPrice] = useState(String(product?.base_price ?? ''));
  const [catId, setCatId] = useState(product?.category_id ?? categories[0]?.id ?? '');
  const [busy, setBusy] = useState(false);
  const [imageUrl, setImageUrl] = useState(product?.image_url ?? '');
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const driveOk = isDriveConfigured();

  // Mở popup đăng nhập Google nếu chưa có token, rồi mới cho chọn file ảnh
  const pickImage = async () => {
    try {
      await ensureDriveToken();
      fileInputRef.current?.click();
    } catch (e) {
      toast.show(e instanceof Error ? e.message : 'Đăng nhập Google thất bại');
    }
  };

  const onImagePicked = async (e: ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    e.target.value = '';
    if (!f) return;
    if (!f.type.startsWith('image/')) {
      toast.show('Vui lòng chọn file ảnh.');
      return;
    }
    if (f.size > 5 * 1024 * 1024) {
      toast.show('Ảnh quá lớn — tối đa 5MB.');
      return;
    }
    setUploading(true);
    try {
      const url = await uploadProductImage(f);
      setImageUrl(url);
      toast.show('Đã tải ảnh lên Google Drive');
    } catch (ex) {
      toast.show(ex instanceof Error ? ex.message : 'Tải ảnh thất bại');
    } finally {
      setUploading(false);
    }
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const p = parseInt(price.replace(/\D/g, ''), 10);
    if (!name.trim() || Number.isNaN(p) || p < 0) {
      toast.show('Nhập tên và giá hợp lệ');
      return;
    }
    setBusy(true);
    try {
      if (product) {
        await updateProduct(product.id, {
          name: name.trim(),
          base_price: p,
          category_id: catId || null,
          image_url: imageUrl || null,
        });
      } else {
        const created = await createProduct({ name: name.trim(), base_price: p, category_id: catId || null });
        if (imageUrl) await updateProduct(created.id, { image_url: imageUrl });
      }
      toast.show(product ? 'Đã cập nhật món' : 'Đã thêm món');
      await reload();
      onClose();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet title={product ? `✏️ Sửa món` : '➕ Thêm món'} onClose={onClose}>
      <form onSubmit={submit}>
        <div className="field">
          <label>Tên món</label>
          <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="VD: Trà Sữa Truyền Thống" />
        </div>
        <div className="field">
          <label>Giá bán (VND)</label>
          <input className="input" inputMode="numeric" value={price} onChange={(e) => setPrice(e.target.value)} placeholder="VD: 32000" />
        </div>
        <div className="field">
          <label>Danh mục</label>
          <select className="input" value={catId} onChange={(e) => setCatId(e.target.value)}>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>
        {driveOk && (
          <div className="field">
            <label>Ảnh món</label>
            {imageUrl && (
              <img
                src={imageUrl}
                alt="Ảnh món"
                style={{ width: '100%', maxHeight: 160, objectFit: 'cover', borderRadius: 8, marginBottom: 8 }}
              />
            )}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              style={{ display: 'none' }}
              onChange={onImagePicked}
            />
            <div className="row">
              <button type="button" className="btn btn-outline" disabled={uploading} onClick={pickImage}>
                {uploading ? 'Đang tải ảnh…' : '📷 Tải ảnh lên Google Drive'}
              </button>
              {imageUrl && (
                <button type="button" className="btn btn-ghost" onClick={() => setImageUrl('')}>
                  Xóa ảnh
                </button>
              )}
            </div>
            <p className="small muted" style={{ marginBottom: 0, marginTop: 6 }}>
              Ảnh lưu trên Google Drive của quán (không tốn dung lượng Firebase).
            </p>
          </div>
        )}
        <button type="submit" className="btn btn-block btn-lg" disabled={busy}>{busy ? 'Đang lưu…' : '💾 Lưu'}</button>
      </form>
    </Sheet>
  );
}

/* ---------------- Danh mục ---------------- */
function CategoriesTab({ categories, reload }: { categories: Category[]; reload: () => Promise<void> }) {
  const toast = useToast();
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);

  const add = async (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    setBusy(true);
    try {
      await createCategory(name.trim());
      setName('');
      toast.show('Đã thêm danh mục');
      await reload();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Thêm thất bại');
    } finally {
      setBusy(false);
    }
  };

  const toggle = async (c: Category) => {
    try {
      await updateCategory(c.id, { active: !c.active });
      await reload();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Thất bại');
    }
  };

  return (
    <>
      <form onSubmit={add} className="row" style={{ marginBottom: 12 }}>
        <input className="input grow" placeholder="Tên danh mục mới…" value={name} onChange={(e) => setName(e.target.value)} />
        <button className="btn" disabled={busy}>➕ Thêm</button>
      </form>
      <div className="card" style={{ padding: 0 }}>
        <div className="table-wrap">
          <table className="tbl">
            <tbody>
              {categories.map((c) => (
                <tr key={c.id} style={c.active ? undefined : { opacity: 0.5 }}>
                  <td><b>{c.name}</b></td>
                  <td>{c.active ? '✅' : '🚫'}</td>
                  <td style={{ textAlign: 'right' }}>
                    <button className="btn btn-outline" style={{ minHeight: 40, padding: '6px 12px' }} onClick={() => toggle(c)}>
                      {c.active ? 'Ẩn' : 'Hiện'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

/* ---------------- Modifier ---------------- */
function ModifiersTab({ groups, reload }: { groups: ModifierGroup[]; reload: () => Promise<void> }) {
  const toast = useToast();
  const [newOpt, setNewOpt] = useState<{ groupId: string; name: string; delta: string } | null>(null);
  const [busy, setBusy] = useState(false);

  const toggleOpt = async (optId: string, active: boolean) => {
    try {
      await updateModifierOption(optId, { active: !active });
      await reload();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Thất bại');
    }
  };

  const addOpt = async (e: FormEvent) => {
    e.preventDefault();
    if (!newOpt || !newOpt.name.trim()) return;
    const delta = parseInt(newOpt.delta.replace(/\D/g, ''), 10) || 0;
    setBusy(true);
    try {
      await createModifierOption(newOpt.groupId, { name: newOpt.name.trim(), price_delta: delta });
      toast.show('Đã thêm tùy chọn');
      setNewOpt(null);
      await reload();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Thêm thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      {groups.map((g) => (
        <div className="card" key={g.id} style={{ marginBottom: 12 }}>
          <div className="row" style={{ marginBottom: 8 }}>
            <b className="grow">
              {g.name}{' '}
              <span className="small muted">
                ({g.selection_type === 'single' ? 'chọn 1' : 'chọn nhiều'}{g.required ? ', bắt buộc' : ''})
              </span>
            </b>
            <button className="btn btn-ghost" style={{ minHeight: 40, padding: '6px 12px' }} onClick={() => setNewOpt({ groupId: g.id, name: '', delta: '' })}>
              ➕ Thêm lựa chọn
            </button>
          </div>
          <div className="opt-grid">
            {[...g.options].sort((a, b) => a.sort_order - b.sort_order).map((o) => (
              <div key={o.id} className={`opt-btn${o.active ? ' selected' : ''}`} style={{ cursor: 'default', opacity: o.active ? 1 : 0.5 }}>
                {o.name}
                <span className="delta">{o.price_delta > 0 ? `+${formatVND(o.price_delta)}` : 'miễn phí'}</span>
                <button
                  className="small"
                  style={{ background: 'none', border: 'none', color: 'var(--brand)', fontWeight: 700, cursor: 'pointer', marginTop: 4 }}
                  onClick={() => toggleOpt(o.id, o.active)}
                >
                  {o.active ? 'Ẩn' : 'Hiện'}
                </button>
              </div>
            ))}
          </div>
          {newOpt?.groupId === g.id && (
            <form onSubmit={addOpt} className="row" style={{ marginTop: 10 }}>
              <input className="input grow" placeholder="Tên lựa chọn (VD: Trân châu đen)" value={newOpt.name} onChange={(e) => setNewOpt({ ...newOpt, name: e.target.value })} />
              <input className="input" style={{ width: 130 }} inputMode="numeric" placeholder="+giá (VD: 8000)" value={newOpt.delta} onChange={(e) => setNewOpt({ ...newOpt, delta: e.target.value })} />
              <button className="btn" disabled={busy}>Lưu</button>
              <button type="button" className="btn btn-ghost" onClick={() => setNewOpt(null)}>Hủy</button>
            </form>
          )}
        </div>
      ))}
    </>
  );
}
