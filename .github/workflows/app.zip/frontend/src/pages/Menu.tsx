import { useCallback, useEffect, useState } from 'react';
import type { FormEvent } from 'react';
import {
  DbError,
  createCategory,
  createModifierOption,
  createProduct,
  createProductsBulk,
  deleteCategory,
  deleteModifierOption,
  deleteProduct,
  listCategories,
  listIngredients,
  listModifierGroups,
  listProducts,
  updateCategory,
  updateModifierOption,
  updateProduct,
} from '../lib/db';
import { formatVND } from '../lib/format';
import { PageHead } from '../components/PageHead';
import { Sheet } from '../components/Sheet';
import { useToast } from '../components/Toast';
import { useAuth } from '../lib/auth';
import type { Category, Ingredient, ModifierGroup, Product } from '../lib/types';

type Tab = 'products' | 'modifiers' | 'categories';

export function Menu() {
  const toast = useToast();
  const { isOwner } = useAuth();
  const [tab, setTab] = useState<Tab>('products');
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [groups, setGroups] = useState<ModifierGroup[]>([]);
  const [loading, setLoading] = useState(true);

  const reload = useCallback(async () => {
    try {
      const [cats, prods, gs] = await Promise.all([
        listCategories(),
        listProducts(),
        listModifierGroups(),
      ]);
      setCategories(cats.sort((a, b) => a.sort_order - b.sort_order));
      setProducts(prods.sort((a, b) => a.sort_order - b.sort_order));
      setGroups(gs.sort((a, b) => a.sort_order - b.sort_order));
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tải được menu');
    } finally {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    void reload();
  }, [reload]);

  if (!isOwner) {
    return (
      <div className="page">
        <div className="card">🔒 Chỉ chủ quán mới được quản lý menu.</div>
      </div>
    );
  }

  return (
    <div className="page">
      <PageHead title="Menu" />
      <div className="sb-tabs">
        <button className={`sb-tab${tab === 'products' ? ' active' : ''}`} onClick={() => setTab('products')}>Sản phẩm</button>
        <button className={`sb-tab${tab === 'modifiers' ? ' active' : ''}`} onClick={() => setTab('modifiers')}>Topping</button>
        <button className={`sb-tab${tab === 'categories' ? ' active' : ''}`} onClick={() => setTab('categories')}>Danh mục</button>
      </div>
      {loading ? (
        <div className="card">Đang tải…</div>
      ) : tab === 'products' ? (
        <ProductsTab products={products} categories={categories} reload={reload} />
      ) : tab === 'modifiers' ? (
        <ModifiersTab groups={groups} reload={reload} />
      ) : (
        <CategoriesTab categories={categories} products={products} reload={reload} />
      )}
    </div>
  );
}

/* ---------------- Món ---------------- */
function ProductsTab({ products, categories, reload }: { products: Product[]; categories: Category[]; reload: () => Promise<void> }) {
  const [editing, setEditing] = useState<Product | 'new' | null>(null);
  const [bulkOpen, setBulkOpen] = useState(false);
  const [fabOpen, setFabOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [catFilter, setCatFilter] = useState<string>('all');
  const [ingredients, setIngredients] = useState<Ingredient[]>([]);

  useEffect(() => {
    listIngredients(true).then(setIngredients).catch(() => {});
  }, []);

  const catName = (id: string | null) => categories.find((c) => c.id === id)?.name ?? 'Chưa phân loại';

  const visible = products.filter((p) => {
    const q = query.trim().toLowerCase();
    const okQ = !q || p.name.toLowerCase().includes(q);
    const okC = catFilter === 'all' || p.category_id === catFilter;
    return okQ && okC;
  });

  return (
    <>
      <div className="sb-search" style={{ marginBottom: 10 }}>
        <span className="sico" aria-hidden>🔍</span>
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Tìm tên món…"
          aria-label="Tìm món theo tên"
        />
      </div>
      <div style={{ display: 'flex', gap: 8, overflowX: 'auto', paddingBottom: 6, marginBottom: 4 }}>
        <button className={`sb-chip${catFilter === 'all' ? ' selected' : ''}`} onClick={() => setCatFilter('all')}>
          Tất cả
        </button>
        {categories.map((c) => (
          <button
            key={c.id}
            className={`sb-chip${catFilter === c.id ? ' selected' : ''}`}
            onClick={() => setCatFilter(c.id)}
          >
            {c.name}
          </button>
        ))}
      </div>
      <div className="muted small" style={{ marginBottom: 4 }}>Số lượng: {visible.length}</div>
      {visible.length === 0 ? (
        <div className="sb-empty">
          <div className="eico">🍹</div>
          <p>{products.length === 0 ? 'Chưa có món nào. Bấm nút + để thêm món mới.' : 'Không tìm thấy món nào khớp.'}</p>
        </div>
      ) : (
        <div>
          {visible.map((p) => (
            <button
              key={p.id}
              className="sb-row"
              style={p.active ? undefined : { opacity: 0.5 }}
              onClick={() => setEditing(p)}
            >
              <span className="sb-thumb" aria-hidden>{p.name.trim().charAt(0).toUpperCase() || '?'}</span>
              <span className="rbody">
                <span className="rtitle">{p.name}</span>
                <span className="rsub">{catName(p.category_id)} · {p.active ? 'Đang bán' : 'Đang ẩn'}{p.recipe.length > 0 ? ` · ${p.recipe.length} nguyên liệu` : ''}</span>
              </span>
              <span className="ramount">{formatVND(p.base_price)}{p.unit ? `/${p.unit}` : ''}</span>
              <span style={{ color: 'var(--muted)', fontSize: 24, flexShrink: 0 }} aria-hidden>›</span>
            </button>
          ))}
        </div>
      )}
      {editing && (
        <ProductForm product={editing === 'new' ? null : editing} categories={categories} ingredients={ingredients} onClose={() => setEditing(null)} reload={reload} />
      )}
      {bulkOpen && (
        <BulkAddSheet categories={categories} onClose={() => setBulkOpen(false)} reload={reload} />
      )}
      <button className="fab" onClick={() => setFabOpen(true)} aria-label="Thêm món mới">
        +
      </button>
      {fabOpen && (
        <Sheet title="Thêm món" onClose={() => setFabOpen(false)}>
          <button
            className="sb-menu-row"
            style={{ background: 'var(--surface)', borderRadius: 999, color: 'var(--brand-dark)', border: 'none', boxShadow: 'var(--shadow)', padding: '14px 18px', marginBottom: 10, fontWeight: 600 }}
            onClick={() => {
              setFabOpen(false);
              setEditing('new');
            }}
          >
            <span style={{ fontSize: 20 }}>➕</span> Tạo món mới <span className="chev">›</span>
          </button>
          <button
            className="sb-menu-row"
            style={{ background: 'var(--surface)', borderRadius: 999, color: 'var(--brand-dark)', border: 'none', boxShadow: 'var(--shadow)', padding: '14px 18px', fontWeight: 600 }}
            onClick={() => {
              setFabOpen(false);
              setBulkOpen(true);
            }}
          >
            <span style={{ fontSize: 20 }}>📋</span> Thêm món hàng loạt <span className="chev">›</span>
          </button>
        </Sheet>
      )}
    </>
  );
}

// Thêm nhiều món cùng lúc: mỗi dòng "Tên món | giá | tên danh mục (tùy chọn)".
function BulkAddSheet({ categories, onClose, reload }: { categories: Category[]; onClose: () => void; reload: () => Promise<void> }) {
  const toast = useToast();
  const [text, setText] = useState('');
  const [defaultCat, setDefaultCat] = useState(categories[0]?.id ?? '');
  const [busy, setBusy] = useState(false);

  const catByName = (name: string) => {
    const n = name.trim().toLowerCase();
    return categories.find((c) => c.name.trim().toLowerCase() === n) ?? null;
  };

  const parsed = text
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      const parts = line.split('|').map((s) => s.trim());
      const name = parts[0] ?? '';
      const price = parseInt((parts[1] ?? '').replace(/\D/g, ''), 10);
      const cat = parts[2] ? catByName(parts[2]) : null;
      const ok = !!name && Number.isFinite(price) && price > 0 && (parts[2] ? !!cat : true);
      return { line, name, price, cat, ok, err: !name ? 'thiếu tên' : !Number.isFinite(price) || price <= 0 ? 'giá không hợp lệ' : parts[2] && !cat ? `không có danh mục “${parts[2]}”` : '' };
    });
  const okCount = parsed.filter((p) => p.ok).length;

  const submit = async () => {
    if (okCount === 0) {
      toast.show('Chưa có dòng nào hợp lệ');
      return;
    }
    setBusy(true);
    try {
      const { added } = await createProductsBulk(
        parsed
          .filter((p) => p.ok)
          .map((p) => ({ name: p.name, base_price: p.price, category_id: p.cat ? p.cat.id : defaultCat || null })),
      );
      toast.show(`Đã thêm ${added} món`);
      await reload();
      onClose();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Thêm thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet
      title="Thêm món hàng loạt"
      onClose={onClose}
      footer={
        <button className="btn btn-block btn-lg" onClick={submit} disabled={busy || okCount === 0}>
          {busy ? 'Đang thêm…' : `Thêm ${okCount} món`}
        </button>
      }
    >
      <p className="small muted" style={{ marginTop: 0 }}>
        Mỗi dòng một món theo mẫu: <b>Tên món | giá | tên danh mục</b> (danh mục bỏ trống sẽ dùng danh mục mặc định bên dưới).
      </p>
      <div className="sb-float">
        <select value={defaultCat} onChange={(e) => setDefaultCat(e.target.value)} aria-label="Danh mục mặc định">
          {categories.map((c) => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </select>
        <label>Danh mục mặc định</label>
      </div>
      <div className="sb-float">
        <textarea
          rows={8}
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder={'Trà Sữa Truyền Thống | 32000 | Trà sữa\nCà Phê Sữa Đá | 25000\nBạc Xỉu | 29000 | Cà phê'}
          style={{ fontFamily: 'inherit' }}
        />
        <label>Danh sách món</label>
      </div>
      {parsed.length > 0 && (
        <div style={{ marginBottom: 12 }}>
          <div className="small muted" style={{ marginBottom: 4 }}>Xem trước: {okCount}/{parsed.length} dòng hợp lệ</div>
          {parsed.map((p, i) => (
            <div key={i} className="sb-row" style={{ opacity: p.ok ? 1 : 0.55 }}>
              <span className="rbody">
                <span className="rtitle">{p.name || <i>(trống)</i>}</span>
                <span className="rsub" style={p.ok ? undefined : { color: 'var(--red)' }}>
                  {p.ok ? (p.cat ? p.cat.name : 'Danh mục mặc định') : p.err}
                </span>
              </span>
              <span className="ramount" style={p.ok ? undefined : { color: 'var(--red)' }}>
                {Number.isFinite(p.price) && p.price > 0 ? formatVND(p.price) : '—'}
              </span>
            </div>
          ))}
        </div>
      )}
    </Sheet>
  );
}

const UNIT_SUGGESTIONS = ['Ly', 'Cái', 'Hộp', 'Phần', 'Chai', 'Túi'];

function ProductForm({ product, categories, ingredients, onClose, reload }: { product: Product | null; categories: Category[]; ingredients: Ingredient[]; onClose: () => void; reload: () => Promise<void> }) {
  const toast = useToast();
  const [name, setName] = useState(product?.name ?? '');
  const [price, setPrice] = useState(product?.base_price ? String(product.base_price) : '');
  const [cost, setCost] = useState(product?.cost_price ? String(product.cost_price) : '');
  const [unit, setUnit] = useState(product?.unit ?? '');
  const [catId, setCatId] = useState(product?.category_id ?? categories[0]?.id ?? '');
  const [active, setActive] = useState(product?.active ?? true);
  const [recipeQty, setRecipeQty] = useState<Record<string, string>>(() => {
    const m: Record<string, string> = {};
    for (const r of product?.recipe ?? []) m[r.ingredient_id] = String(r.qty);
    return m;
  });
  const [busy, setBusy] = useState(false);

  const save = async (resetAfter: boolean) => {
    const p = parseInt(price.replace(/\D/g, ''), 10);
    const c = cost.trim() === '' ? 0 : parseInt(cost.replace(/\D/g, ''), 10);
    if (!name.trim() || Number.isNaN(p) || p <= 0) {
      toast.show('Nhập tên và giá bán hợp lệ');
      return;
    }
    if (Number.isNaN(c) || c < 0) {
      toast.show('Giá vốn không hợp lệ');
      return;
    }
    const recipe = Object.entries(recipeQty)
      .map(([ingredient_id, v]) => ({ ingredient_id, qty: parseFloat(String(v).replace(',', '.')) }))
      .filter((r) => Number.isFinite(r.qty) && r.qty > 0);
    setBusy(true);
    try {
      const payload = {
        name: name.trim(),
        base_price: p,
        cost_price: c,
        unit: unit.trim(),
        recipe,
        category_id: catId || null,
      };
      if (product) {
        await updateProduct(product.id, { ...payload, active });
      } else {
        await createProduct(payload);
      }
      toast.show(product ? 'Đã cập nhật món' : 'Đã thêm món');
      await reload();
      if (resetAfter) {
        setName('');
        setPrice('');
        setCost('');
        setUnit('');
        setRecipeQty({});
        setCatId(categories[0]?.id ?? '');
      } else {
        onClose();
      }
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  const toggleActive = async () => {
    if (!product) return;
    try {
      await updateProduct(product.id, { active: !active });
      setActive(!active);
      toast.show(active ? `Đã ẩn “${product.name}”` : `Đã hiện “${product.name}”`);
      await reload();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Thất bại');
    }
  };

  const remove = async () => {
    if (!product) return;
    if (!window.confirm(`Xóa hẳn món “${product.name}” khỏi menu?\nĐơn hàng cũ không bị ảnh hưởng.`)) return;
    try {
      await deleteProduct(product.id);
      toast.show(`Đã xóa “${product.name}”`);
      await reload();
      onClose();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Xóa thất bại');
    }
  };

  return (
    <Sheet
      title={product ? 'Sửa món' : 'Thêm món'}
      onClose={onClose}
      footer={
        <div className="row">
          {!product && (
            <button type="button" className="btn btn-outline grow" disabled={busy} onClick={() => save(true)}>
              Lưu và thêm mới
            </button>
          )}
          <button type="submit" form="product-form" className="btn grow" disabled={busy}>
            {busy ? 'Đang lưu…' : 'Lưu'}
          </button>
        </div>
      }
    >
      <form id="product-form" onSubmit={(e) => { e.preventDefault(); void save(false); }}>
        <div className="sb-float">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="VD: Trà Sữa Truyền Thống"
            autoFocus={!product}
          />
          <label>Tên món <span className="req">*</span></label>
        </div>
        <div className="sb-float">
          <input
            inputMode="numeric"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            placeholder="VD: 32000"
          />
          <label>Giá bán (VND) <span className="req">*</span></label>
        </div>
        <div className="sb-float">
          <input
            inputMode="numeric"
            value={cost}
            onChange={(e) => setCost(e.target.value)}
            placeholder="VD: 12000 (để trống = 0)"
          />
          <label>Giá vốn (VND)</label>
        </div>
        <div className="field">
          <label>Đơn vị</label>
          <div className="row" style={{ flexWrap: 'wrap', gap: 8, marginBottom: 8 }}>
            {UNIT_SUGGESTIONS.map((u) => (
              <button
                key={u}
                type="button"
                className={`sb-chip${unit === u ? ' selected' : ''}`}
                onClick={() => setUnit(u)}
              >
                {u}
              </button>
            ))}
          </div>
          <input
            className="input"
            value={unit}
            onChange={(e) => setUnit(e.target.value)}
            maxLength={20}
            placeholder="Hoặc nhập đơn vị khác…"
          />
        </div>
        <div className="sb-float">
          <select value={catId} onChange={(e) => setCatId(e.target.value)} aria-label="Danh mục">
            {categories.map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
          <label>Danh mục</label>
        </div>
        {ingredients.length > 0 ? (
          <>
            <div className="small muted" style={{ fontWeight: 600, margin: '16px 0 4px' }}>
              Định lượng nguyên liệu{' '}
              <span style={{ fontWeight: 400 }}>(cho 1 {unit.trim() || 'đơn vị'} món)</span>
            </div>
            <p className="small muted" style={{ margin: '0 0 8px' }}>
              Bán 1 món sẽ tự trừ kho theo định lượng này.
            </p>
            {ingredients.map((ing) => (
              <div
                key={ing.id}
                className="row"
                style={{ justifyContent: 'space-between', alignItems: 'center', marginBottom: 8, gap: 8 }}
              >
                <span style={{ fontSize: 15 }}>
                  {ing.name} <span className="muted small">({ing.unit})</span>
                </span>
                <input
                  className="input"
                  style={{ width: 120, textAlign: 'right' }}
                  inputMode="decimal"
                  placeholder="0"
                  value={recipeQty[ing.id] ?? ''}
                  onChange={(e) => setRecipeQty((prev) => ({ ...prev, [ing.id]: e.target.value }))}
                  aria-label={`Định lượng ${ing.name} (${ing.unit})`}
                />
              </div>
            ))}
          </>
        ) : (
          <p className="small muted" style={{ margin: '16px 0 8px' }}>
            💡 Thêm nguyên liệu ở màn <b>Tồn kho</b> rồi quay lại đây để khai định lượng cho món.
          </p>
        )}
        {product && (
          <>
            <div className="row" style={{ marginBottom: 16 }}>
              <span className="grow" style={{ fontWeight: 600, fontSize: 15 }}>Đang bán</span>
              <label className="switch" aria-label="Đang bán">
                <input type="checkbox" checked={active} onChange={(e) => setActive(e.target.checked)} />
                <span className="track" />
              </label>
            </div>
            <div className="row" style={{ marginBottom: 8 }}>
              <button type="button" className="btn btn-outline grow" onClick={toggleActive}>
                {active ? 'Ẩn món' : 'Hiện món'}
              </button>
              <button type="button" className="btn btn-ghost grow" style={{ color: 'var(--red)' }} onClick={remove}>
                Xóa món
              </button>
            </div>
          </>
        )}
      </form>
    </Sheet>
  );
}

/* ---------------- Danh mục ---------------- */
function CategoriesTab({ categories, products, reload }: { categories: Category[]; products: Product[]; reload: () => Promise<void> }) {
  const toast = useToast();
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');

  const count = (id: string) => products.filter((p) => p.category_id === id).length;

  const add = async (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    setBusy(true);
    try {
      await createCategory(name.trim());
      setName('');
      toast.show('Đã thêm danh mục');
      await reload();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Thêm thất bại');
    } finally {
      setBusy(false);
    }
  };

  const toggle = async (c: Category) => {
    try {
      await updateCategory(c.id, { active: !c.active });
      await reload();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Thất bại');
    }
  };

  const saveEdit = async (c: Category) => {
    if (!editName.trim()) {
      toast.show('Tên danh mục không được để trống');
      return;
    }
    try {
      await updateCategory(c.id, { name: editName.trim() });
      setEditingId(null);
      toast.show('Đã đổi tên danh mục');
      await reload();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Lưu thất bại');
    }
  };

  const remove = async (c: Category) => {
    if (!window.confirm(`Xóa danh mục “${c.name}”?\nCác món trong danh mục sẽ chuyển sang “chưa phân loại” (không bị mất).`)) return;
    try {
      const { moved } = await deleteCategory(c.id);
      toast.show(moved > 0 ? `Đã xóa danh mục, chuyển ${moved} món sang chưa phân loại` : 'Đã xóa danh mục');
      await reload();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Xóa thất bại');
    }
  };

  return (
    <>
      <form onSubmit={add} className="row" style={{ marginBottom: 12 }}>
        <input className="input grow" placeholder="Tên danh mục mới…" value={name} onChange={(e) => setName(e.target.value)} />
        <button className="btn" disabled={busy}>Thêm</button>
      </form>
      {categories.length === 0 ? (
        <div className="sb-empty">
          <div className="eico">📂</div>
          <p>Chưa có danh mục nào.</p>
        </div>
      ) : (
        <div>
          {categories.map((c) => (
            <div key={c.id} className="sb-row" style={c.active ? undefined : { opacity: 0.5 }}>
              {editingId === c.id ? (
                <>
                  <span className="rbody">
                    <input
                      className="input"
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      autoFocus
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') void saveEdit(c);
                        if (e.key === 'Escape') setEditingId(null);
                      }}
                    />
                  </span>
                  <button className="btn" style={{ minHeight: 44, padding: '8px 16px' }} onClick={() => saveEdit(c)}>Lưu</button>
                  <button className="btn btn-ghost" style={{ minHeight: 44, padding: '8px 16px' }} onClick={() => setEditingId(null)}>Hủy</button>
                </>
              ) : (
                <>
                  <span className="rbody">
                    <span className="rtitle">{c.name}</span>
                    <span className="rsub">{count(c.id)} món{c.active ? '' : ' · Đang ẩn'}</span>
                  </span>
                  <button
                    className="btn btn-ghost"
                    style={{ minHeight: 44, padding: '8px 16px' }}
                    onClick={() => { setEditingId(c.id); setEditName(c.name); }}
                  >
                    Sửa
                  </button>
                  <button
                    className="btn btn-outline"
                    style={{ minHeight: 44, padding: '8px 16px' }}
                    onClick={() => toggle(c)}
                  >
                    {c.active ? 'Ẩn' : 'Hiện'}
                  </button>
                  <button
                    className="btn btn-ghost"
                    style={{ minHeight: 44, padding: '8px 16px', color: 'var(--red)' }}
                    onClick={() => remove(c)}
                    aria-label={`Xóa danh mục ${c.name}`}
                  >
                    🗑️
                  </button>
                </>
              )}
            </div>
          ))}
        </div>
      )}
    </>
  );
}

/* ---------------- Topping ---------------- */
function ModifiersTab({ groups, reload }: { groups: ModifierGroup[]; reload: () => Promise<void> }) {
  const toast = useToast();
  const [newOpt, setNewOpt] = useState<{ groupId: string; name: string; delta: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editDelta, setEditDelta] = useState('');

  const toggleOpt = async (optId: string, active: boolean) => {
    try {
      await updateModifierOption(optId, { active: !active });
      await reload();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Thất bại');
    }
  };

  const addOpt = async (e: FormEvent) => {
    e.preventDefault();
    if (!newOpt || !newOpt.name.trim()) return;
    const delta = parseInt(newOpt.delta.replace(/\D/g, ''), 10) || 0;
    setBusy(true);
    try {
      await createModifierOption(newOpt.groupId, { name: newOpt.name.trim(), price_delta: delta });
      toast.show('Đã thêm tùy chọn');
      setNewOpt(null);
      await reload();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Thêm thất bại');
    } finally {
      setBusy(false);
    }
  };

  const saveEdit = async (optId: string) => {
    const delta = parseInt(editDelta.replace(/\D/g, ''), 10);
    if (!editName.trim() || Number.isNaN(delta) || delta < 0) {
      toast.show('Nhập tên và phụ thu hợp lệ (≥ 0)');
      return;
    }
    try {
      await updateModifierOption(optId, { name: editName.trim(), price_delta: delta });
      setEditingId(null);
      toast.show('Đã lưu');
      await reload();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Lưu thất bại');
    }
  };

  const removeOpt = async (name: string, optId: string) => {
    if (!window.confirm(`Xóa hẳn “${name}”?\nĐơn hàng cũ không bị ảnh hưởng.`)) return;
    try {
      await deleteModifierOption(optId);
      toast.show(`Đã xóa “${name}”`);
      await reload();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Xóa thất bại');
    }
  };

  if (groups.length === 0) {
    return (
      <div className="sb-empty">
        <div className="eico">🧋</div>
        <p>Chưa có nhóm topping nào.</p>
      </div>
    );
  }

  return (
    <>
      {groups.map((g) => (
        <div className="sb-section" key={g.id}>
          <div className="row" style={{ marginBottom: 4 }}>
            <div className="grow">
              <b style={{ fontSize: 16 }}>{g.name}</b>
              <div className="small muted">
                {g.selection_type === 'single' ? 'Chọn 1' : 'Chọn nhiều'}{g.required ? ' · Bắt buộc' : ''}
              </div>
            </div>
            <button className="btn btn-ghost btn-sm" onClick={() => setNewOpt({ groupId: g.id, name: '', delta: '' })}>
              ➕ Thêm
            </button>
          </div>
          <div>
            {[...g.options].sort((a, b) => a.sort_order - b.sort_order).map((o) => (
              <div key={o.id} className="sb-row" style={{ opacity: o.active ? 1 : 0.5 }}>
                {editingId === o.id ? (
                  <>
                    <span className="rbody" style={{ display: 'flex', gap: 8 }}>
                      <input
                        className="input"
                        style={{ minWidth: 0 }}
                        value={editName}
                        onChange={(e) => setEditName(e.target.value)}
                        placeholder="Tên"
                        autoFocus
                      />
                      <input
                        className="input"
                        style={{ width: 110 }}
                        inputMode="numeric"
                        value={editDelta}
                        onChange={(e) => setEditDelta(e.target.value)}
                        placeholder="+giá"
                      />
                    </span>
                    <button className="btn btn-sm" onClick={() => saveEdit(o.id)}>Lưu</button>
                    <button className="btn btn-ghost btn-sm" onClick={() => setEditingId(null)}>Hủy</button>
                  </>
                ) : (
                  <>
                    <span className="rbody">
                      <span className="rtitle">{o.name}</span>
                      <span className="rsub">
                        {o.price_delta > 0 ? `+${formatVND(o.price_delta)}` : 'Miễn phí'}
                        {o.active ? '' : ' · Đang ẩn'}
                      </span>
                    </span>
                    <button className="btn btn-ghost btn-sm" onClick={() => { setEditingId(o.id); setEditName(o.name); setEditDelta(String(o.price_delta)); }}>
                      Sửa
                    </button>
                    <button className="btn btn-outline btn-sm" onClick={() => toggleOpt(o.id, o.active)}>
                      {o.active ? 'Ẩn' : 'Hiện'}
                    </button>
                    <button className="btn btn-ghost btn-sm" style={{ color: 'var(--red)' }} onClick={() => removeOpt(o.name, o.id)} aria-label={`Xóa ${o.name}`}>
                      🗑️
                    </button>
                  </>
                )}
              </div>
            ))}
          </div>
          {newOpt?.groupId === g.id && (
            <form onSubmit={addOpt} style={{ marginTop: 12 }}>
              <div className="sb-float">
                <input
                  value={newOpt.name}
                  onChange={(e) => setNewOpt({ ...newOpt, name: e.target.value })}
                  placeholder="VD: Trân châu đen"
                  autoFocus
                />
                <label>Tên lựa chọn</label>
              </div>
              <div className="sb-float">
                <input
                  inputMode="numeric"
                  value={newOpt.delta}
                  onChange={(e) => setNewOpt({ ...newOpt, delta: e.target.value })}
                  placeholder="VD: 8000"
                />
                <label>Phụ thu (VND)</label>
              </div>
              <div className="row">
                <button className="btn grow" disabled={busy}>Lưu</button>
                <button type="button" className="btn btn-ghost" onClick={() => setNewOpt(null)}>Hủy</button>
              </div>
            </form>
          )}
        </div>
      ))}
    </>
  );
}
