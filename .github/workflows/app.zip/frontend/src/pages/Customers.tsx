import { useEffect, useState } from 'react';
import type { FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  DbError,
  TIER_LABEL,
  adjustDebt,
  createCustomer,
  getCustomer,
  getSettings,
  listDebtLogs,
  redeemReward,
  getAllowedWarehouses,
  searchCustomers,
  updateCustomer,
} from '../lib/db';
import { formatDateTime, formatVND } from '../lib/format';
import { Sheet } from '../components/Sheet';
import { getZaloConfig, sendZaloBulk, sendZaloMessage, type ZaloConfig } from '../lib/zalo';
import { PageHead } from '../components/PageHead';
import { useToast } from '../components/Toast';
import type { Customer, DebtLog , Warehouse} from '../lib/types';

function zaloPhone(phone: string): string {
  const d = phone.replace(/\D/g, '');
  if (d.startsWith('84')) return d;
  if (d.startsWith('0')) return d;
  return d;
}

function upcomingBirthdays(list: Customer[]): { c: Customer; inDays: number; dateLabel: string }[] {
  const now = new Date();
  const out: { c: Customer; inDays: number; dateLabel: string }[] = [];
  for (const c of list) {
    if (!c.birthday || !/^\d{4}-\d{2}-\d{2}$/.test(c.birthday)) continue;
    const [, m, d] = c.birthday.split('-').map(Number);
    const thisYear = new Date(now.getFullYear(), m - 1, d);
    let next = thisYear;
    if (thisYear.getTime() < new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime()) {
      next = new Date(now.getFullYear() + 1, m - 1, d);
    }
    const inDays = Math.round((next.getTime() - new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime()) / 86400000);
    if (inDays <= 30) {
      out.push({
        c,
        inDays,
        dateLabel: `${String(d).padStart(2, '0')}/${String(m).padStart(2, '0')}`,
      });
    }
  }
  return out.sort((a, b) => a.inDays - b.inDays);
}

function BirthdayZaloTab({ list, shopName }: { list: Customer[]; shopName: string }) {
  const toast = useToast();
  const [copied, setCopied] = useState<string | null>(null);
  const [zaloCfg, setZaloCfg] = useState<ZaloConfig | null>(null);
  const [sending, setSending] = useState<string | null>(null);
  const [confirmSend, setConfirmSend] = useState<{ c: Customer; msg: string } | null>(null);
  // Gui hang loat
  const [bulkOpen, setBulkOpen] = useState(false);
  const [bulkMsg, setBulkMsg] = useState('');
  const [bulkSel, setBulkSel] = useState<string[]>([]);
  const [bulkBusy, setBulkBusy] = useState(false);
  const [bulkProg, setBulkProg] = useState('');

  useEffect(() => {
    getZaloConfig().then(setZaloCfg).catch(() => {});
  }, []);

  const upcoming = upcomingBirthdays(list);
  const zaloReady = (c: Customer) => !!(zaloCfg?.configured && c.zalo_user_id);

  const copyMsg = async (key: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(key);
      setTimeout(() => setCopied(null), 2000);
    } catch {
      /* bo qua */
    }
  };

  const openChatFallback = async (c: Customer, msg: string) => {
    // Chua cau hinh OA hoac khach chua link: tu copy + mo chat
    await copyMsg(`z_${c.id}`, msg);
    if (c.phone) window.open(`https://zalo.me/${zaloPhone(c.phone)}`, '_blank');
    toast.show('Đã chép tin nhắn — dán vào chat Zalo để gửi');
  };

  const doSend = async () => {
    if (!confirmSend) return;
    const { c, msg } = confirmSend;
    setConfirmSend(null);
    if (!zaloReady(c)) {
      await openChatFallback(c, msg);
      return;
    }
    setSending(c.id);
    try {
      const r = await sendZaloMessage(c.zalo_user_id!, msg);
      toast.show(r.ok ? `Đã gửi Zalo cho ${c.name} ✅` : `Gửi thất bại: ${r.error}`);
    } finally {
      setSending(null);
    }
  };

  const templates: { key: string; title: string; text: (name: string) => string }[] = [
    {
      key: 'birthday',
      title: '🎂 Chúc mừng sinh nhật',
      text: (name) =>
        `Chúc mừng sinh nhật ${name}! 🎂 ${shopName} tặng bạn voucher giảm 20% nhân dịp đặc biệt này. Ghé quán nhé!`,
    },
    {
      key: 'promo',
      title: '🎁 Khuyến mãi chung',
      text: (name) =>
        `Chào ${name}! ${shopName} đang có ưu đãi mới, ghé quán thưởng thức nhé. Cảm ơn bạn đã ủng hộ!`,
    },
    {
      key: 'gold',
      title: '🥇 Tri ân hạng Vàng',
      text: (name) =>
        `Chào ${name}! Cảm ơn bạn đã là khách hàng Vàng của ${shopName}. Tuần này bạn được giảm thêm 5% mọi hóa đơn đấy!`,
    },
  ];

  const zaloLinked = list.filter((c) => c.zalo_user_id);

  const doBulkSend = async () => {
    const recips = zaloLinked
      .filter((c) => bulkSel.includes(c.id))
      .map((c) => ({ user_id: c.zalo_user_id!, name: c.name }));
    if (recips.length === 0 || !bulkMsg.trim()) return;
    if (!window.confirm(`Gửi tin nhắn cho ${recips.length} khách qua Zalo OA?`)) return;
    setBulkBusy(true);
    setBulkProg('');
    try {
      const { sent, failed } = await sendZaloBulk(recips, bulkMsg.trim(), (done, total, name, ok) => {
        setBulkProg(`${done}/${total} — ${name}: ${ok ? '✅' : '❌'}`);
      });
      toast.show(`Đã gửi ${sent}/${recips.length} tin` + (failed.length ? `, lỗi ${failed.length}` : ' ✅'));
      if (failed.length) setBulkProg(`Lỗi: ${failed.map((f) => `${f.name} (${f.error})`).join('; ')}`);
      else {
        setBulkOpen(false);
        setBulkSel([]);
        setBulkMsg('');
      }
    } finally {
      setBulkBusy(false);
    }
  };

  return (
    <>
      {!zaloCfg?.configured && (
        <div className="card" style={{ marginBottom: 12, background: 'var(--amber-bg, #FEF3C7)' }}>
          <p className="small" style={{ margin: 0 }}>
            💡 Muốn <b>bấm là gửi luôn</b> (không cần copy tay)? Cấu hình Zalo OA ở <b>Cài đặt → Zalo OA</b> — miễn phí.
            Hiện tại bấm nút sẽ tự chép tin + mở chat.
          </p>
        </div>
      )}
      <div className="card" style={{ marginBottom: 12 }}>
        <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
          <div style={{ fontWeight: 700 }}>🎂 Sinh nhật trong 30 ngày tới ({upcoming.length})</div>
        </div>
        {upcoming.length === 0 ? (
          <p className="small muted" style={{ margin: 0 }}>
            Không có sinh nhật nào sắp tới.
          </p>
        ) : (
          upcoming.map(({ c, inDays, dateLabel }) => {
            const msg = templates[0].text(c.name);
            const auto = zaloReady(c);
            return (
              <div key={c.id} className="sb-section" style={{ marginBottom: 8 }}>
                <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center' }}>
                  <div style={{ fontWeight: 700 }}>
                    {c.name} <span className="small muted">· {dateLabel}</span>
                    {auto && <span className="small" style={{ color: 'var(--green)' }}> · ⚡gửi tự động</span>}
                  </div>
                  <span className={`sb-chip${inDays === 0 ? ' selected' : ''}`} style={{ minHeight: 28 }}>
                    {inDays === 0 ? 'Hôm nay!' : `còn ${inDays} ngày`}
                  </span>
                </div>
                <div className="row" style={{ gap: 8, marginTop: 8 }}>
                  <button
                    type="button"
                    className="btn"
                    style={{ minHeight: 40 }}
                    disabled={sending === c.id}
                    onClick={() => setConfirmSend({ c, msg })}
                  >
                    {sending === c.id ? 'Đang gửi…' : `💬 Nhắn Zalo${auto ? ' (tự động)' : ''}`}
                  </button>
                  <button type="button" className="sb-chip" style={{ minHeight: 40 }} onClick={() => void copyMsg(`b_${c.id}`, msg)}>
                    {copied === `b_${c.id}` ? 'Đã chép ✓' : '📋 Chép lời chúc'}
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      <div className="card" style={{ marginBottom: 12 }}>
        <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
          <div style={{ fontWeight: 700 }}>📣 Gửi Zalo hàng loạt ({zaloLinked.length} khách đã liên kết)</div>
          <button type="button" className="btn btn-outline" style={{ minHeight: 40 }} onClick={() => setBulkOpen(true)}>
            Soạn tin
          </button>
        </div>
        <p className="small muted" style={{ margin: 0 }}>
          Gửi tin khuyến mãi chung tới nhiều khách cùng lúc qua Zalo OA (không cần cấu hình thêm nếu đã xong ở trên).
        </p>
      </div>

      <div className="card">
        <div style={{ fontWeight: 700, marginBottom: 4 }}>📝 Mẫu tin nhắn</div>
        {templates.map((t) => (
          <div key={t.key} className="sb-section" style={{ marginBottom: 8 }}>
            <div style={{ fontWeight: 600, marginBottom: 4 }}>{t.title}</div>
            <p className="small muted" style={{ margin: '0 0 8px' }}>
              {t.text('{Tên khách}')}
            </p>
            <button type="button" className="sb-chip" style={{ minHeight: 36 }} onClick={() => void copyMsg(t.key, t.text('{Tên khách}'))}>
              {copied === t.key ? 'Đã chép ✓' : '📋 Chép mẫu'}
            </button>
          </div>
        ))}
      </div>

      {confirmSend && (
        <Sheet title={`Gửi Zalo cho ${confirmSend.c.name}`} onClose={() => setConfirmSend(null)}>
          <p className="small muted">Tin nhắn sẽ gửi:</p>
          <div className="card" style={{ marginBottom: 12 }}>
            <p style={{ margin: 0, whiteSpace: 'pre-wrap' }}>{confirmSend.msg}</p>
          </div>
          {!zaloReady(confirmSend.c) && (
            <p className="small" style={{ color: 'var(--amber, #b45309)' }}>
              ⚠️ {confirmSend.c.zalo_user_id ? 'Chưa cấu hình Zalo OA' : 'Khách chưa liên kết Zalo'} — hệ thống sẽ tự chép tin + mở chat để bạn dán gửi.
            </p>
          )}
          <button className="btn btn-block btn-lg" onClick={() => void doSend()}>
            {zaloReady(confirmSend.c) ? '✅ Xác nhận gửi' : '📋 Chép tin + mở chat'}
          </button>
        </Sheet>
      )}

      {bulkOpen && (
        <Sheet title="Gửi Zalo hàng loạt" onClose={() => !bulkBusy && setBulkOpen(false)}>
          <div className="field">
            <label>Nội dung tin nhắn (dùng {'{Tên}'} để cá nhân hóa — hiện tại gửi chung 1 nội dung)</label>
            <textarea
              className="input"
              rows={4}
              value={bulkMsg}
              onChange={(e) => setBulkMsg(e.target.value)}
              placeholder="VD: Beesy Coffee tri ân khách hàng! Tuần này giảm 20% mọi hóa đơn..."
            />
          </div>
          <div className="field">
            <label>Chọn khách ({bulkSel.length}/{zaloLinked.length})</label>
            <div className="row" style={{ gap: 8, marginBottom: 8 }}>
              <button type="button" className="sb-chip" onClick={() => setBulkSel(zaloLinked.map((c) => c.id))}>
                Chọn tất cả
              </button>
              <button type="button" className="sb-chip" onClick={() => setBulkSel([])}>
                Bỏ chọn
              </button>
            </div>
            <div style={{ maxHeight: 220, overflowY: 'auto' }}>
              {zaloLinked.map((c) => (
                <label key={c.id} className="sb-row" style={{ cursor: 'pointer', display: 'flex', gap: 8, alignItems: 'center' }}>
                  <input
                    type="checkbox"
                    checked={bulkSel.includes(c.id)}
                    onChange={(e) =>
                      setBulkSel((prev) => (e.target.checked ? [...prev, c.id] : prev.filter((x) => x !== c.id)))
                    }
                  />
                  <span>{c.name} <span className="small muted">· {c.phone}</span></span>
                </label>
              ))}
              {zaloLinked.length === 0 && <p className="small muted">Chưa có khách nào liên kết Zalo.</p>}
            </div>
          </div>
          {bulkProg && <p className="small muted">{bulkProg}</p>}
          <button className="btn btn-block btn-lg" disabled={bulkBusy || bulkSel.length === 0 || !bulkMsg.trim()} onClick={() => void doBulkSend()}>
            {bulkBusy ? 'Đang gửi…' : `📣 Gửi cho ${bulkSel.length} khách`}
          </button>
        </Sheet>
      )}
    </>
  );
}

export function Customers() {
  const navigate = useNavigate();
  const toast = useToast();
  const [q, setQ] = useState('');
  const [list, setList] = useState<Customer[]>([]);
  const [busy, setBusy] = useState(false);
  const [selected, setSelected] = useState<Customer | null>(null);
  const [formOpen, setFormOpen] = useState<Customer | 'new' | null>(null);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [whFilter, setWhFilter] = useState('all');
  const [stampsTarget, setStampsTarget] = useState(9);
  const [custTab, setCustTab] = useState<'list' | 'birthday'>('list');
  const [shopName, setShopName] = useState('quán');

  useEffect(() => {
    getSettings().then((s) => {
      const t = parseInt(s.stamps_target ?? '', 10);
      if (!Number.isNaN(t) && t > 0) setStampsTarget(t);
      if (s.shop_name) setShopName(s.shop_name);
    }).catch(() => {});
    void search('');
    getAllowedWarehouses().then(({ warehouses: ws }) => setWarehouses(ws)).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const search = async (keyword: string) => {
    setBusy(true);
    try {
      const data = await searchCustomers(keyword.trim());
      setList(data.filter((c) => whFilter === 'all' || !c.warehouse_id || c.warehouse_id === whFilter));
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tìm được');
    } finally {
      setBusy(false);
    }
  };

  const openDetail = async (id: string) => {
    try {
      const c = await getCustomer(id);
      setSelected(c);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không mở được');
    }
  };

  const visible = list.filter(
    (c) => whFilter === 'all' || !c.warehouse_id || c.warehouse_id === whFilter,
  );

  return (
    <div className="page">
      <PageHead
        title="Khách hàng"
        right={
          <button className="btn" style={{ minHeight: 40, padding: '6px 14px' }} onClick={() => setFormOpen('new')}>
            ＋ Thêm khách hàng
          </button>
        }
      />

      <div className="row" style={{ gap: 8, marginBottom: 12 }}>
        <button type="button" className={`sb-chip${custTab === 'list' ? ' selected' : ''}`} onClick={() => setCustTab('list')}>
          👥 Danh sách
        </button>
        <button type="button" className={`sb-chip${custTab === 'birthday' ? ' selected' : ''}`} onClick={() => setCustTab('birthday')}>
          🎂 Sinh nhật & Zalo
        </button>
      </div>

      {custTab === 'birthday' ? (
        <BirthdayZaloTab list={visible} shopName={shopName} />
      ) : (
      <>
      <div className="sb-search" style={{ marginBottom: 12 }}>
        <span className="sico">🔍</span>
        <input
          placeholder="Tìm tên, số điện thoại…"
          value={q}
          onChange={(e) => {
            setQ(e.target.value);
            void search(e.target.value);
          }}
          aria-label="Tìm khách hàng"
        />
      </div>

      <button className="sb-menu-row" onClick={() => navigate('/debt')} style={{ marginBottom: 12, borderRadius: 14, background: 'var(--surface)', boxShadow: 'var(--shadow)' }}>
        <span className="sb-ico-box" style={{ background: '#F3E8FF' }}>📒</span>
        <span>Sổ nợ</span>
        <span className="chev">›</span>
      </button>

      {warehouses.length > 1 && (
        <div className="row" style={{ gap: 8, marginBottom: 12, flexWrap: 'wrap' }}>
          <button className={`sb-chip${whFilter === 'all' ? ' selected' : ''}`} onClick={() => setWhFilter('all')}>
            Mọi kho
          </button>
          {warehouses.map((w) => (
            <button key={w.id} className={`sb-chip${whFilter === w.id ? ' selected' : ''}`} onClick={() => setWhFilter(w.id)}>
              {w.name}
            </button>
          ))}
        </div>
      )}

      <div className="sb-section" style={{ padding: '4px 16px' }}>
        {visible.map((c) => (
          <button key={c.id} className="sb-row" onClick={() => openDetail(c.id)}>
            <span className="avatar">{c.name.charAt(0).toUpperCase()}</span>
            <span className="rbody">
              <span className="rtitle">
                {c.name}
                {c.reward_available ? ' 🎁' : ''}
                {c.tier && c.tier !== 'member' && <span className="small"> {TIER_LABEL[c.tier]}</span>}
              </span>
              <span className="rsub">
                {c.phone}
                {warehouses.length > 1 && c.warehouse_id
                  ? ` · ${warehouses.find((w) => w.id === c.warehouse_id)?.name ?? ''}`
                  : ''}
              </span>
            </span>
            <span style={{ textAlign: 'right', flexShrink: 0 }}>
              <span className="small muted" style={{ display: 'block' }}>
                🎟️ {c.stamps}/{stampsTarget} · ⭐ {c.points ?? 0}đ
              </span>
              {c.debt > 0 && (
                <span className="ramount text-orange" style={{ display: 'block', marginTop: 2 }}>
                  {formatVND(c.debt)}
                </span>
              )}
            </span>
            <span className="chev muted" style={{ fontSize: 22 }}>›</span>
          </button>
        ))}
        {visible.length === 0 && !busy && (
          <div className="sb-empty">
            <div className="eico">👥</div>
            <p>
              Chưa có khách hàng nào.
              <br />
              Thêm khách để tích tem và theo dõi công nợ.
            </p>
          </div>
        )}
      </div>

      <button className="fab" onClick={() => setFormOpen('new')} aria-label="Thêm khách hàng mới">
        +
      </button>

      </>
      )}

      {selected && (
        <CustomerDetail
          customer={selected}
          stampsTarget={stampsTarget}
          onClose={() => setSelected(null)}
          onEdit={() => setFormOpen(selected)}
          onChanged={(c) => {
            setSelected(c);
            void search(q);
          }}
        />
      )}
      {formOpen && (
        <CustomerForm
          customer={formOpen === 'new' ? null : formOpen}
          warehouses={warehouses}
          onClose={() => setFormOpen(null)}
          onSaved={() => void search(q)}
        />
      )}
    </div>
  );
}

function CustomerDetail({ customer, stampsTarget, onClose, onEdit, onChanged }: {
  customer: Customer;
  stampsTarget: number;
  onClose: () => void;
  onEdit: () => void;
  onChanged: (c: Customer) => void;
}) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);

  const redeem = async () => {
    const lastOrder = customer.recent_orders?.[0];
    if (!lastOrder) {
      toast.show('Khách chưa có đơn nào để đổi thưởng');
      return;
    }
    if (!window.confirm(`Đổi thưởng cho ${customer.name}? (mua ${stampsTarget} tặng 1)`)) return;
    setBusy(true);
    try {
      await redeemReward(customer.id);
      toast.show('🎁 Đã đổi thưởng thành công!');
      const c = await getCustomer(customer.id);
      if (c) onChanged(c);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Đổi thưởng thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet title={customer.name} onClose={onClose}>
      <div className="sb-section">
        <div className="row" style={{ marginBottom: 8 }}>
          <h3 className="sb-section-title grow" style={{ margin: 0 }}>Thông tin</h3>
          <button className="btn btn-ghost btn-sm" style={{ minHeight: 44, padding: '6px 12px' }} onClick={onEdit}>
            Sửa
          </button>
        </div>
        <div className="row small" style={{ marginBottom: 6 }}>
          <span className="muted grow">Số điện thoại</span>
          <b>{customer.phone}</b>
        </div>
        {customer.birthday && (
          <div className="row small" style={{ marginBottom: 6 }}>
            <span className="muted grow">Ngày sinh</span>
            <b>{customer.birthday}</b>
          </div>
        )}
        {customer.address && (
          <div className="row small" style={{ marginBottom: 6 }}>
            <span className="muted grow">Địa chỉ</span>
            <b>{customer.address}</b>
          </div>
        )}
        {customer.note && <div className="small muted" style={{ marginTop: 6 }}>{customer.note}</div>}
      </div>

      <div className="sb-section">
        <h3 className="sb-section-title">⭐ Tích điểm & hạng</h3>
        <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <div style={{ fontSize: 22, fontWeight: 800 }}>{(customer.points ?? 0).toLocaleString('vi-VN')} <span className="small muted">điểm</span></div>
            <div className="small muted">Đã chi tiêu: {formatVND(customer.total_spent ?? 0)}</div>
          </div>
          <div className="sb-chip selected" style={{ fontSize: 15 }}>{TIER_LABEL[customer.tier ?? 'member']}</div>
        </div>
      </div>

      <div className="sb-section">
        <h3 className="sb-section-title">
          Tích tem <span className="muted">({customer.stamps}/{stampsTarget})</span>
        </h3>
        <div className="stamps">
          {Array.from({ length: stampsTarget }).map((_, i) => (
            <span key={i} className={`stamp${i < customer.stamps ? ' on' : ''}`}>{i < customer.stamps ? '☕' : '·'}</span>
          ))}
        </div>
        {customer.reward_available ? (
          <button className="btn btn-green btn-block" style={{ minHeight: 48, marginTop: 8 }} disabled={busy} onClick={redeem}>
            🎁 Đổi thưởng (mua {stampsTarget} tặng 1)
          </button>
        ) : (
          <p className="small muted" style={{ margin: 0 }}>
            Còn {stampsTarget - customer.stamps} tem nữa để nhận 1 ly miễn phí.
          </p>
        )}
      </div>

      <DebtCard
        customer={customer}
        onChanged={async () => {
          const c = await getCustomer(customer.id);
          if (c) onChanged(c);
        }}
      />

      <div className="sb-section" style={{ padding: '8px 16px' }}>
        <h3 className="sb-section-title" style={{ margin: '6px 0 4px' }}>Đơn gần nhất</h3>
        {(customer.recent_orders ?? []).map((o) => (
          <div key={o.id} className="sb-row" style={{ cursor: 'default' }}>
            <span className="rbody">
              <span className="rtitle">{o.code}</span>
              <span className="rsub">{formatDateTime(o.created_at)}</span>
            </span>
            <span className="ramount">{formatVND(o.total)}</span>
          </div>
        ))}
        {(customer.recent_orders ?? []).length === 0 && (
          <p className="muted small" style={{ margin: '8px 0' }}>Chưa có đơn nào</p>
        )}
      </div>
    </Sheet>
  );
}

function DebtCard({ customer, onChanged }: { customer: Customer; onChanged: () => Promise<void> }) {
  const toast = useToast();
  const [logs, setLogs] = useState<DebtLog[]>([]);
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    listDebtLogs(customer.id).then(setLogs).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [customer.id, customer.debt]);

  const submit = async (isPayment: boolean) => {
    const v = parseInt(amount.replace(/\D/g, ''), 10);
    if (!v || v <= 0) {
      toast.show('Nhập số tiền hợp lệ');
      return;
    }
    setBusy(true);
    try {
      await adjustDebt(customer.id, isPayment ? -v : v, note.trim() || null);
      toast.show(isPayment ? `Đã thu ${formatVND(v)}` : `Đã ghi nợ ${formatVND(v)}`);
      setAmount('');
      setNote('');
      await onChanged();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Cập nhật công nợ thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="sb-section">
      <div className="row" style={{ marginBottom: 12 }}>
        <h3 className="sb-section-title grow" style={{ margin: 0 }}>Công nợ</h3>
        <b className="money text-orange" style={{ fontSize: 20 }}>
          {formatVND(customer.debt)}
        </b>
      </div>
      <div className="sb-float">
        <input
          inputMode="numeric"
          placeholder=" "
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
        <label>Số tiền</label>
      </div>
      <div className="sb-float">
        <input
          placeholder=" "
          value={note}
          onChange={(e) => setNote(e.target.value)}
        />
        <label>Ghi chú (không bắt buộc)</label>
      </div>
      <div className="row" style={{ gap: 12, marginBottom: 4 }}>
        <button className="btn btn btn-block" style={{ minHeight: 48 }} disabled={busy} onClick={() => submit(false)}>
          Ghi nợ
        </button>
        <button className="btn btn-block" style={{ minHeight: 48 }} disabled={busy || customer.debt <= 0} onClick={() => submit(true)}>
          Thu nợ
        </button>
      </div>
      {logs.length > 0 && (
        <div style={{ marginTop: 4 }}>
          {logs.map((l) => (
            <div key={l.id} className="sb-row" style={{ cursor: 'default' }}>
              <span className="rbody">
                <span className="rsub" style={{ marginTop: 0 }}>{formatDateTime(l.created_at)}</span>
                {l.note && <span className="rtitle" style={{ fontSize: 14, fontWeight: 500 }}>{l.note}</span>}
              </span>
              <span style={{ textAlign: 'right', flexShrink: 0 }}>
                <b className={l.amount > 0 ? 'text-red' : 'text-green'}>
                  {l.amount > 0 ? '+' : '−'}{formatVND(Math.abs(l.amount))}
                </b>
                <span className="small muted" style={{ display: 'block' }}>Còn {formatVND(l.balance_after)}</span>
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function CustomerForm({ customer, warehouses, onClose, onSaved }: {
  customer: Customer | null;
  warehouses: Warehouse[];
  onClose: () => void;
  onSaved: () => void;
}) {
  const toast = useToast();
  const [name, setName] = useState(customer?.name ?? '');
  const [phone, setPhone] = useState(customer?.phone ?? '');
  const [birthday, setBirthday] = useState(customer?.birthday ?? '');
  const [zaloId, setZaloId] = useState(customer?.zalo_user_id ?? '');
  const [address, setAddress] = useState(customer?.address ?? '');
  const [note, setNote] = useState(customer?.note ?? '');
  const [whId, setWhId] = useState(customer?.warehouse_id ?? '');
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) {
      toast.show('Nhập tên và SĐT');
      return;
    }
    setBusy(true);
    try {
      const body = { name: name.trim(), phone: phone.trim(), birthday: birthday || null, address: address.trim() || null, note: note.trim() || null, warehouse_id: whId || null, zalo_user_id: zaloId.trim() || null };
      if (customer) await updateCustomer(customer.id, body);
      else await createCustomer(body);
      toast.show(customer ? 'Đã cập nhật' : 'Đã thêm khách hàng');
      onSaved();
      onClose();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet title={customer ? 'Sửa khách hàng' : 'Thêm khách hàng'} onClose={onClose}>
      <form onSubmit={submit}>
        <div className="sb-float">
          <input placeholder=" " value={name} onChange={(e) => setName(e.target.value)} />
          <label>Tên <span className="req">*</span></label>
        </div>
        <div className="sb-float">
          <input placeholder=" " inputMode="tel" value={phone} onChange={(e) => setPhone(e.target.value)} />
          <label>SĐT <span className="req">*</span></label>
        </div>
        <div className="sb-float">
          <input placeholder=" " type="date" value={birthday} onChange={(e) => setBirthday(e.target.value)} />
          <label>Ngày sinh</label>
        </div>
        <div className="sb-float">
          <input placeholder=" " value={zaloId} onChange={(e) => setZaloId(e.target.value)} />
          <label>Zalo user ID (để gửi tin tự động)</label>
        </div>
        <div className="sb-float">
          <input placeholder=" " value={address} onChange={(e) => setAddress(e.target.value)} />
          <label>Địa chỉ</label>
        </div>
        <div className="sb-float">
          <textarea placeholder=" " value={note} onChange={(e) => setNote(e.target.value)} />
          <label>Ghi chú</label>
        </div>
        {warehouses.length > 1 && (
          <div className="sb-float">
            <select value={whId} onChange={(e) => setWhId(e.target.value)} aria-label="Kho của khách">
              <option value="">Mọi kho</option>
              {warehouses.map((w) => (
                <option key={w.id} value={w.id}>{w.name}</option>
              ))}
            </select>
            <label>Kho của khách</label>
          </div>
        )}
        <button type="submit" className="btn btn-block btn-lg" style={{ minHeight: 52 }} disabled={busy}>
          {busy ? 'Đang lưu…' : 'Lưu'}
        </button>
      </form>
    </Sheet>
  );
}
