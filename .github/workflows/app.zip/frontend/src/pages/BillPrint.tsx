import { useEffect, useState } from 'react';
import { formatDateTime, formatVND } from '../lib/format';
import type { Order } from '../lib/types';

// Bill xem trước + vùng in khổ 80mm (render vào #print-root để CSS @media print bắt được)
export function BillPrint({ order, shopName }: { order: Order; shopName: string }) {
  const [now] = useState(() => new Date());

  useEffect(() => {
    let root = document.getElementById('print-root');
    if (!root) {
      root = document.createElement('div');
      root.id = 'print-root';
      document.body.appendChild(root);
    }
    return () => {
      const r = document.getElementById('print-root');
      if (r) r.innerHTML = '';
    };
  }, []);

  useEffect(() => {
    const root = document.getElementById('print-root');
    if (!root) return;
    const lines = order.items
      .map(
        (it) => `
        <div>
          <div class="row"><span>${it.qty} x ${escapeHtml(it.product_name)}</span><span>${formatVND(it.line_total)}</span></div>
          ${(it.modifiers || []).map((m) => `<div class="small">  + ${escapeHtml(m.option)}${m.price_delta ? ` (+${formatVND(m.price_delta)})` : ''}</div>`).join('')}
          ${it.note ? `<div class="small">  📝 ${escapeHtml(it.note)}</div>` : ''}
        </div>`,
      )
      .join('');
    const payLabel = order.payment_method_name
      || (order.payment_method === 'cash' ? 'Tiền mặt' : order.payment_method === 'transfer' ? 'Chuyển khoản' : 'Ghi nợ');
    root.innerHTML = `
      <div id="print-area">
        <h2>${escapeHtml(shopName)}</h2>
        <div class="center">HÓA ĐƠN BÁN HÀNG</div>
        <div class="center">Mã đơn: <b>${escapeHtml(order.code)}</b></div>
        <div class="center small">${formatDateTime(order.created_at)}</div>
        <hr/>
        ${lines}
        <hr/>
        ${order.discount > 0 ? `<div class="row"><span>Giam gia${order.discount_label ? ` (${escapeHtml(order.discount_label)})` : ''}</span><span>-${formatVND(order.discount)}</span></div>` : ''}
        <div class="row"><span>Tổng cộng</span><span class="total">${formatVND(order.total)}</span></div>
        <div class="row"><span>Thanh toán</span><span>${escapeHtml(payLabel)}</span></div>
        ${
          order.payment_method === 'cash' && order.amount_received != null
            ? `<div class="row"><span>Khách đưa</span><span>${formatVND(order.amount_received)}</span></div>
               <div class="row"><span>Thối lại</span><span>${formatVND(order.change_amount ?? 0)}</span></div>`
            : ''
        }
        ${order.note ? `<div class="small">Ghi chú: ${escapeHtml(order.note)}</div>` : ''}
        <hr/>
        <div class="center">Cảm ơn quý khách! Hẹn gặp lại ☕</div>
        <div class="center small">In lúc ${now.toLocaleTimeString('vi-VN')}</div>
      </div>`;
  }, [order, shopName, now]);

  return (
    <div className="card" style={{ marginTop: 12, fontFamily: '"Be Vietnam Pro", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif', fontSize: 14 }}>
      <h3 style={{ textAlign: 'center', margin: '0 0 4px' }}>{shopName}</h3>
      <p style={{ textAlign: 'center', margin: '0 0 8px' }} className="muted small">
        HÓA ĐƠN · Mã <b>{order.code}</b> · {formatDateTime(order.created_at)}
      </p>
      {order.items.map((it) => (
        <div key={it.id} style={{ marginBottom: 6 }}>
          <div className="row">
            <span>{it.qty} x {it.product_name}</span>
            <span className="money">{formatVND(it.line_total)}</span>
          </div>
          {(it.modifiers || []).map((m, i) => (
            <div key={i} className="small muted">
              &nbsp;&nbsp;+ {m.option}{m.price_delta ? ` (+${formatVND(m.price_delta)})` : ''}
            </div>
          ))}
        </div>
      ))}
      <hr style={{ border: 'none', borderTop: '1px dashed var(--line)' }} />
      {order.discount > 0 && (
        <div className="row small" style={{ color: 'var(--green)' }}>
          <span>Giảm giá{order.discount_label ? ` (${order.discount_label})` : ''}</span>
          <span>-{formatVND(order.discount)}</span>
        </div>
      )}
      <div className="row">
        <b>Tổng cộng</b>
        <b className="money" style={{ fontSize: 18 }}>{formatVND(order.total)}</b>
      </div>
      <div className="row small muted">
        <span>{order.payment_method_name ?? (order.payment_method === 'cash' ? '💵 Tiền mặt' : order.payment_method === 'transfer' ? '📱 Chuyển khoản' : '📒 Ghi nợ')}</span>
        {order.payment_method === 'cash' && order.amount_received != null && (
          <span>Đưa {formatVND(order.amount_received)} · Thối {formatVND(order.change_amount ?? 0)}</span>
        )}
      </div>
    </div>
  );
}

function escapeHtml(s: string): string {
  return s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c] ?? c));
}
