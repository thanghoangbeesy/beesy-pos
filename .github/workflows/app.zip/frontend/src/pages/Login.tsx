import { useState } from 'react';
import type { FormEvent } from 'react';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import { useAuth } from '../lib/auth';
import { DbError } from '../lib/db';

export function Login() {
  const { user, login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  if (user) return <Navigate to="/pos" replace />;

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password) {
      setErr('Vui lòng nhập email và mật khẩu');
      return;
    }
    setBusy(true);
    setErr('');
    try {
      await login(email.trim(), password);
      navigate('/pos', { replace: true });
    } catch (ex) {
      setErr(ex instanceof DbError ? ex.message : 'Đăng nhập thất bại, thử lại sau');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="login-wrap">
      <div className="card login-card">
        <div className="login-logo">
          <img src="/coffee-cup.svg" alt="Beesy Coffee & Tea" />
          <h1>Beesy POS</h1>
          <div className="muted">Beesy Coffee &amp; Tea</div>
        </div>
        {err && <div className="err">{err}</div>}
        <form onSubmit={submit}>
          <div className="field">
            <label htmlFor="u">Email</label>
            <input
              id="u"
              className="input"
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="VD: admin@beesy.local"
            />
          </div>
          <div className="field">
            <label htmlFor="p">Mật khẩu</label>
            <input
              id="p"
              type="password"
              className="input"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••"
            />
          </div>
          <button type="submit" className="btn btn-block btn-lg" disabled={busy}>
            {busy ? 'Đang đăng nhập…' : 'Đăng nhập'}
          </button>
        </form>
        <p className="muted small" style={{ marginTop: 12, textAlign: 'center' }}>
          Quán mới chưa có tài khoản? <Link to="/setup">Thiết lập lần đầu →</Link>
        </p>
      </div>
    </div>
  );
}
