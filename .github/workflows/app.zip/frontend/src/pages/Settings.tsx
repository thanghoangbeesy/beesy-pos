import { useEffect, useState } from 'react';
import type { FormEvent } from 'react';
import { initializeApp, getApps } from 'firebase/app';
import { createUserWithEmailAndPassword, getAuth, signOut } from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';
import {
  DbError,
  createPaymentMethod,
  deletePaymentMethod,
  downloadFile,
  exportAllJson,
  exportTableCsv,
  getSettings,
  isSystemPaymentMethod,
  listPaymentMethods,
  paymentKindLabel,
  setSetting,
  updatePaymentMethod,
} from '../lib/db';
import type { PaymentMethodDef, PaymentMethodKind } from '../lib/types';
import { db, firebaseConfig } from '../lib/firebase';
import {
  backupToDrive,
  downloadBackupFile,
  isDriveConfigured,
  listBackupFiles,
  restoreFromData,
  type DriveFileInfo,
} from '../lib/drive';
import { todayVN } from '../lib/format';
import { Sheet } from '../components/Sheet';
import { useToast } from '../components/Toast';
import { useAuth } from '../lib/auth';

const FIELDS = [
  { key: 'shop_name', label: '🏪 Tên quán', placeholder: 'Beesy Coffee & Tea' },
  { key: 'stamps_target', label: '🎟️ Số tem để đổi thưởng', placeholder: 'VD: 9' },
];

const CSV_TABLES = [
  { key: 'orders' as const, label: 'Đơn hàng' },
  { key: 'products' as const, label: 'Sản phẩm' },
  { key: 'customers' as const, label: 'Khách hàng' },
  { key: 'categories' as const, label: 'Danh mục' },
  { key: 'payment_methods' as const, label: 'Thanh toán' },
];

const DRIVE_READY = isDriveConfigured();
const CONFIRM_WORD = 'KHOI PHUC';

function formatSize(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 KB';
  if (bytes >= 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${Math.max(1, Math.round(bytes / 1024))} KB`;
}

function formatDriveTime(iso: string): string {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleString('vi-VN', {
      timeZone: 'Asia/Ho_Chi_Minh',
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return iso;
  }
}

export function Settings() {
  const toast = useToast();
  const { isOwner } = useAuth();
  const [values, setValues] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [backing, setBacking] = useState(false);

  // Google Drive backup
  const [driveBusy, setDriveBusy] = useState(false);
  const [filesOpen, setFilesOpen] = useState(false);
  const [filesLoading, setFilesLoading] = useState(false);
  const [backupFiles, setBackupFiles] = useState<DriveFileInfo[]>([]);
  const [confirmTarget, setConfirmTarget] = useState<DriveFileInfo | null>(null);
  const [confirmText, setConfirmText] = useState('');

  useEffect(() => {
    getSettings()
      .then(setValues)
      .catch(() => toast.show('Không tải được cài đặt'))
      .finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const save = async (e: FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      for (const f of FIELDS) {
        await setSetting(f.key, values[f.key] ?? '');
      }
      toast.show('✅ Đã lưu cài đặt');
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Lưu thất bại');
    } finally {
      setSaving(false);
    }
  };

  const backupJson = async () => {
    setBacking(true);
    try {
      const d = todayVN().replace(/-/g, '');
      const data = await exportAllJson();
      downloadFile(`beesy-backup-${d}.json`, JSON.stringify(data, null, 2), 'application/json');
      toast.show('Đã tải file sao lưu JSON');
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Sao lưu thất bại');
    } finally {
      setBacking(false);
    }
  };

  const backupCsv = async (table: (typeof CSV_TABLES)[number]['key']) => {
    setBacking(true);
    try {
      const d = todayVN().replace(/-/g, '');
      const csv = await exportTableCsv(table);
      downloadFile(`beesy-${table}-${d}.csv`, csv, 'text/csv');
      toast.show(`Đã tải CSV bảng ${table}`);
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Sao lưu thất bại');
    } finally {
      setBacking(false);
    }
  };

  // ------------------------------------------------------- Drive backup ---
  const driveBackup = async () => {
    setDriveBusy(true);
    try {
      const r = await backupToDrive();
      toast.show(`Đã sao lưu ${r.fileName} (${formatSize(r.size)}) lên Google Drive`);
    } catch (ex) {
      toast.show(ex instanceof Error ? ex.message : 'Sao lưu lên Drive thất bại');
    } finally {
      setDriveBusy(false);
    }
  };

  const loadBackupFiles = async () => {
    setFilesLoading(true);
    try {
      setBackupFiles(await listBackupFiles());
    } catch (ex) {
      toast.show(ex instanceof Error ? ex.message : 'Không tải được danh sách file sao lưu');
      setBackupFiles([]);
    } finally {
      setFilesLoading(false);
    }
  };

  const openRestore = () => {
    setConfirmTarget(null);
    setConfirmText('');
    setFilesOpen(true);
    void loadBackupFiles();
  };

  const [staffName, setStaffName] = useState('');
  const [staffEmail, setStaffEmail] = useState('');
  const [staffPass, setStaffPass] = useState('');
  const [staffBusy, setStaffBusy] = useState(false);

  // Chủ quán thêm tài khoản nhân viên ngay trong app (dùng Firebase app phụ để
  // không bị đăng xuất khỏi phiên chủ quán hiện tại).
  const addStaff = async (e: FormEvent) => {
    e.preventDefault();
    if (!staffName.trim() || !staffEmail.trim() || staffPass.length < 6) {
      toast.show('Nhập tên, email và mật khẩu (≥ 6 ký tự) cho nhân viên');
      return;
    }
    setStaffBusy(true);
    try {
      const secondary =
        getApps().find((a) => a.name === 'beesy-secondary') ??
        initializeApp(firebaseConfig, 'beesy-secondary');
      const secondaryAuth = getAuth(secondary);
      const cred = await createUserWithEmailAndPassword(secondaryAuth, staffEmail.trim(), staffPass);
      await signOut(secondaryAuth);
      await setDoc(doc(db, 'users', cred.user.uid), {
        id: cred.user.uid,
        email: staffEmail.trim(),
        full_name: staffName.trim(),
        role: 'staff',
      });
      toast.show(`Đã thêm nhân viên ${staffName.trim()} (${staffEmail.trim()})`);
      setStaffName('');
      setStaffEmail('');
      setStaffPass('');
    } catch (ex) {
      const code = (ex as { code?: string })?.code ?? '';
      toast.show(
        code === 'auth/email-already-in-use'
          ? 'Email này đã được đăng ký.'
          : ex instanceof DbError
            ? ex.message
            : 'Thêm nhân viên thất bại. Kiểm tra mạng rồi thử lại.',
      );
    } finally {
      setStaffBusy(false);
    }
  };

  const doRestore = async () => {
    if (!confirmTarget || confirmText !== CONFIRM_WORD) return;
    setDriveBusy(true);
    try {
      const data = await downloadBackupFile(confirmTarget.id);
      const r = await restoreFromData(data);
      toast.show(`Đã khôi phục ${r.docs} bản ghi (${r.collections} bảng) từ ${confirmTarget.name}`);
      setFilesOpen(false);
      setConfirmTarget(null);
      setConfirmText('');
    } catch (ex) {
      toast.show(ex instanceof Error ? ex.message : 'Khôi phục thất bại');
    } finally {
      setDriveBusy(false);
    }
  };

  if (!isOwner) {
    return (
      <div className="page">
        <div className="card">🔒 Chỉ chủ quán mới được xem cài đặt.</div>
      </div>
    );
  }

  return (
    <div className="page">
      <h1>⚙️ Cài đặt</h1>

      <div className="card" style={{ marginBottom: 14 }}>
        <b className="section-title">🏪 Thông tin quán</b>
        {loading ? (
          <div className="muted">Đang tải…</div>
        ) : (
          <form onSubmit={save}>
            {FIELDS.map((f) => (
              <div className="field" key={f.key}>
                <label htmlFor={`set-${f.key}`}>{f.label}</label>
                <input
                  id={`set-${f.key}`}
                  className="input"
                  placeholder={f.placeholder}
                  value={values[f.key] ?? ''}
                  onChange={(e) => setValues((v) => ({ ...v, [f.key]: e.target.value }))}
                />
              </div>
            ))}
            <button type="submit" className="btn btn-block" disabled={saving}>
              {saving ? 'Đang lưu…' : '💾 Lưu cài đặt'}
            </button>
          </form>
        )}
      </div>

      {isOwner && <PaymentMethodsManager />}

      <div className="card" style={{ marginBottom: 14 }}>
        <b className="section-title">👥 Thêm tài khoản nhân viên</b>
        <form onSubmit={addStaff}>
          <div className="field">
            <label htmlFor="st-name">Tên nhân viên</label>
            <input
              id="st-name"
              className="input"
              value={staffName}
              onChange={(e) => setStaffName(e.target.value)}
              placeholder="VD: Lan"
            />
          </div>
          <div className="field">
            <label htmlFor="st-email">Email đăng nhập</label>
            <input
              id="st-email"
              className="input"
              autoComplete="off"
              value={staffEmail}
              onChange={(e) => setStaffEmail(e.target.value)}
              placeholder="VD: lan@beesy.local"
            />
          </div>
          <div className="field">
            <label htmlFor="st-pass">Mật khẩu (≥ 6 ký tự)</label>
            <input
              id="st-pass"
              type="password"
              className="input"
              autoComplete="new-password"
              value={staffPass}
              onChange={(e) => setStaffPass(e.target.value)}
              placeholder="••••••"
            />
          </div>
          <button type="submit" className="btn btn-block" disabled={staffBusy}>
            {staffBusy ? 'Đang thêm…' : '➕ Thêm nhân viên'}
          </button>
          <p className="small muted" style={{ marginBottom: 0 }}>
            Nhân viên dùng email/mật khẩu này để đăng nhập. Xóa hoặc đổi vai trò: Firebase console →
            Authentication / Firestore.
          </p>
        </form>
      </div>

      <div className="card" style={{ marginBottom: 14 }}>
        <b className="section-title">☁️ Sao lưu Google Drive</b>
        {!DRIVE_READY ? (
          <p className="small muted" style={{ marginBottom: 0 }}>
            Chưa cấu hình Google Client ID — xem README mục <b>“Bật Google Drive backup”</b> để
            lấy Client ID, điền vào <code>frontend/.env</code> (biến{' '}
            <code>VITE_GOOGLE_CLIENT_ID</code>), build lại rồi deploy.
          </p>
        ) : (
          <>
            <button
              className="btn btn-block"
              style={{ marginBottom: 8 }}
              disabled={driveBusy}
              onClick={driveBackup}
            >
              {driveBusy ? 'Đang xử lý…' : '⬆️ Sao lưu lên Google Drive'}
            </button>
            <button
              className="btn btn-outline btn-block"
              disabled={driveBusy}
              onClick={openRestore}
            >
              ⬇️ Khôi phục từ Google Drive
            </button>
            <p className="small muted" style={{ marginBottom: 0, marginTop: 8 }}>
              Sao lưu &amp; khôi phục hoàn toàn trên trình duyệt (không tốn Cloud Functions).
              Lần đầu dùng, Google sẽ hỏi cho phép truy cập Drive.
            </p>
          </>
        )}
      </div>

      <div className="card">
        <b className="section-title">💾 Sao lưu thủ công</b>
        <button className="btn btn-block" style={{ marginBottom: 8 }} disabled={backing} onClick={backupJson}>
          ⬇️ Tải toàn bộ dữ liệu (JSON)
        </button>
        <p className="small muted">Tải từng bảng dạng CSV (tiếng Việt, có header):</p>
        <div className="opt-grid">
          {CSV_TABLES.map((t) => (
            <button key={t.key} className="btn btn-outline" disabled={backing} onClick={() => backupCsv(t.key)}>
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {filesOpen && (
        <Sheet title="⬇️ Khôi phục từ Google Drive" onClose={() => setFilesOpen(false)}>
          {filesLoading ? (
            <div className="muted">Đang tải danh sách file…</div>
          ) : backupFiles.length === 0 ? (
            <div className="muted">Chưa có file sao lưu nào trong thư mục “Beesy POS Backup”.</div>
          ) : (
            backupFiles.map((f) => (
              <div className="row" key={f.id} style={{ marginBottom: 8, alignItems: 'center' }}>
                <span className="grow">
                  <b>{f.name}</b>
                  <br />
                  <span className="small muted">
                    {formatDriveTime(f.createdTime)} · {formatSize(Number(f.size) || 0)}
                  </span>
                </span>
                <button
                  className="btn btn-outline"
                  disabled={driveBusy}
                  style={{ minHeight: 40, padding: '6px 12px' }}
                  onClick={() => {
                    setConfirmTarget(f);
                    setConfirmText('');
                  }}
                >
                  Khôi phục
                </button>
              </div>
            ))
          )}

          {confirmTarget && (
            <div
              className="card"
              style={{ marginTop: 12, border: '2px solid var(--red)', background: 'var(--red-bg)' }}
            >
              <b style={{ color: 'var(--red)' }}>⚠️ NGUY HIỂM — xác nhận khôi phục</b>
              <p className="small">
                Thao tác này sẽ <b>GHI ĐÈ</b> toàn bộ dữ liệu hiện tại bằng dữ liệu trong file{' '}
                <b>{confirmTarget.name}</b>. Đơn hàng, menu, khách hàng… hiện tại sẽ bị thay thế.
                Không thể hoàn tác!
              </p>
              <p className="small">
                Để xác nhận, gõ đúng chữ <b>{CONFIRM_WORD}</b> vào ô bên dưới:
              </p>
              <input
                className="input"
                value={confirmText}
                onChange={(e) => setConfirmText(e.target.value)}
                placeholder={CONFIRM_WORD}
                style={{ marginBottom: 10 }}
              />
              <div className="row">
                <button
                  className="btn"
                  style={{ background: 'var(--red)', borderColor: 'var(--red)' }}
                  disabled={driveBusy || confirmText !== CONFIRM_WORD}
                  onClick={doRestore}
                >
                  {driveBusy ? 'Đang khôi phục…' : 'Xác nhận khôi phục'}
                </button>
                <button
                  type="button"
                  className="btn btn-ghost"
                  disabled={driveBusy}
                  onClick={() => setConfirmTarget(null)}
                >
                  Hủy
                </button>
              </div>
            </div>
          )}
        </Sheet>
      )}
    </div>
  );
}

// ------------------------------------------------- quản lý phương thức thanh toán ---
function PaymentMethodsManager() {
  const toast = useToast();
  const [methods, setMethods] = useState<PaymentMethodDef[]>([]);
  const [loading, setLoading] = useState(true);
  const [formOpen, setFormOpen] = useState<PaymentMethodDef | 'new' | null>(null);

  const reload = async () => {
    setLoading(true);
    try {
      setMethods(await listPaymentMethods(false));
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tải được phương thức thanh toán');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void reload();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const toggleActive = async (m: PaymentMethodDef) => {
    try {
      await updatePaymentMethod(m.id, { active: !m.active });
      await reload();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Cập nhật thất bại');
    }
  };

  const remove = async (m: PaymentMethodDef) => {
    if (!window.confirm(`Xóa phương thức “${m.name}”? Đơn hàng cũ không bị ảnh hưởng.`)) return;
    try {
      await deletePaymentMethod(m.id);
      toast.show('Đã xóa phương thức');
      await reload();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Xóa thất bại');
    }
  };

  return (
    <div className="card" style={{ marginBottom: 14 }}>
      <div className="row" style={{ marginBottom: 10 }}>
        <b className="grow">💳 Phương thức thanh toán</b>
        <button className="btn btn-outline" style={{ minHeight: 40 }} onClick={() => setFormOpen('new')}>
          ➕ Thêm
        </button>
      </div>
      {loading ? (
        <div className="muted">Đang tải…</div>
      ) : methods.length === 0 ? (
        <div className="muted">Chưa có phương thức nào</div>
      ) : (
        <div className="table-wrap">
          <table className="tbl">
            <tbody>
              {methods.map((m) => (
                <tr key={m.id} style={m.active ? undefined : { opacity: 0.5 }}>
                  <td>
                    <b>{m.icon} {m.name}</b>
                    <br />
                    <span className="small muted">{paymentKindLabel(m.kind)}{m.kind === 'transfer' && m.bank_account ? ` · ${m.bank_account}` : ''}</span>
                  </td>
                  <td style={{ textAlign: 'right', whiteSpace: 'nowrap' }}>
                    <button className="btn btn-ghost" style={{ minHeight: 40, padding: '6px 10px', marginRight: 4 }} onClick={() => toggleActive(m)}>
                      {m.active ? '👁️ Ẩn' : '👁️‍🗨️ Hiện'}
                    </button>
                    <button className="btn btn-ghost" style={{ minHeight: 40, padding: '6px 10px', marginRight: 4 }} onClick={() => setFormOpen(m)}>
                      ✏️
                    </button>
                    {!isSystemPaymentMethod(m.id) && (
                      <button className="btn btn-ghost" style={{ minHeight: 40, padding: '6px 10px' }} onClick={() => remove(m)}>
                        🗑️
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <p className="small muted" style={{ marginBottom: 0 }}>
        Phương thức mặc định (Tiền mặt / Chuyển khoản / Ghi nợ) chỉ Ẩn được, không xóa. Thông tin
        ngân hàng của từng phương thức chuyển khoản dùng để sinh mã VietQR khi thanh toán.
      </p>
      {formOpen && (
        <PaymentMethodForm
          method={formOpen === 'new' ? null : formOpen}
          onClose={() => setFormOpen(null)}
          onSaved={() => void reload()}
        />
      )}
    </div>
  );
}

function PaymentMethodForm({ method, onClose, onSaved }: {
  method: PaymentMethodDef | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const toast = useToast();
  const [name, setName] = useState(method?.name ?? '');
  const [kind, setKind] = useState<PaymentMethodKind>(method?.kind ?? 'cash');
  const [icon, setIcon] = useState(method?.icon ?? '💵');
  const [bin, setBin] = useState(method?.bank_bin ?? '');
  const [account, setAccount] = useState(method?.bank_account ?? '');
  const [accountName, setAccountName] = useState(method?.bank_account_name ?? '');
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      toast.show('Nhập tên phương thức');
      return;
    }
    if (kind === 'transfer' && (!bin.trim() || !account.trim())) {
      toast.show('Chuyển khoản cần nhập mã BIN và số tài khoản để sinh VietQR');
      return;
    }
    setBusy(true);
    try {
      const body = {
        name: name.trim(),
        kind,
        icon: icon.trim() || '💳',
        bank_bin: kind === 'transfer' ? bin.trim() : null,
        bank_account: kind === 'transfer' ? account.trim() : null,
        bank_account_name: kind === 'transfer' ? accountName.trim() : null,
      };
      if (method) await updatePaymentMethod(method.id, body);
      else await createPaymentMethod(body);
      toast.show(method ? 'Đã cập nhật' : 'Đã thêm phương thức');
      onSaved();
      onClose();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet title={method ? '✏️ Sửa phương thức' : '➕ Thêm phương thức'} onClose={onClose}>
      <form onSubmit={submit}>
        <div className="field">
          <label>Tên phương thức *</label>
          <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="VD: Momo, VNPay, Chuyển khoản VCB…" />
        </div>
        <div className="field">
          <label>Loại</label>
          <select className="input" value={kind} onChange={(e) => setKind(e.target.value as PaymentMethodKind)}>
            <option value="cash">💵 Tiền mặt (nhập tiền khách đưa, tính thối lại)</option>
            <option value="transfer">📱 Chuyển khoản (hiện mã VietQR)</option>
            <option value="debt">📒 Ghi nợ (cộng vào công nợ khách)</option>
          </select>
        </div>
        <div className="field">
          <label>Biểu tượng</label>
          <input className="input" value={icon} onChange={(e) => setIcon(e.target.value)} placeholder="VD: 💵" maxLength={4} />
        </div>
        {kind === 'transfer' && (
          <>
            <div className="field">
              <label>Mã BIN ngân hàng *</label>
              <input className="input" value={bin} onChange={(e) => setBin(e.target.value)} placeholder="VD: 970422 (MB)" />
            </div>
            <div className="field">
              <label>Số tài khoản *</label>
              <input className="input" value={account} onChange={(e) => setAccount(e.target.value)} placeholder="VD: 0901234567" />
            </div>
            <div className="field">
              <label>Tên chủ tài khoản</label>
              <input className="input" value={accountName} onChange={(e) => setAccountName(e.target.value)} placeholder="VD: BEESY COFFEE" />
            </div>
          </>
        )}
        <button type="submit" className="btn btn-block btn-lg" disabled={busy}>
          {busy ? 'Đang lưu…' : '💾 Lưu'}
        </button>
      </form>
    </Sheet>
  );
}
