import { useEffect, useState } from 'react';
import type { FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { initializeApp, getApps } from 'firebase/app';
import { createUserWithEmailAndPassword, getAuth, signOut } from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';
import {
  DbError,
  createPaymentMethod,
  deletePaymentMethod,
  downloadFile,
  ensureWarehousesSeeded,
  exportAllJson,
  exportTableCsv,
  getDefaultWarehouseId,
  getSettings,
  isSystemPaymentMethod,
  listPaymentMethods,
  listUsers,
  listWarehouses,
  paymentKindLabel,
  setDefaultWarehouse,
  setSetting,
  updatePaymentMethod,
  getPromotions,
  listAuditLogs,
  logAudit,
  savePromotions,
  updateUserRole,
  updateUserWarehouses,
} from '../lib/db';
import type { AuditLog, PaymentMethodDef, PaymentMethodKind, Promotion, RoleKey, User, Warehouse } from '../lib/types';
import { ROLE_LABELS, STAFF_ROLES } from '../lib/permissions';
import { db, firebaseConfig } from '../lib/firebase';
import {
  backupToDrive,
  downloadBackupFile,
  isDriveConfigured,
  listBackupFiles,
  restoreFromData,
  type DriveFileInfo,
} from '../lib/drive';
import { todayVN } from '../lib/format';
import { Sheet } from '../components/Sheet';
import { useToast } from '../components/Toast';
import { useAuth } from '../lib/auth';
import AppIcon from '../components/AppIcon';

const FIELDS = [
  { key: 'shop_name', label: 'Tên quán', placeholder: 'Beesy Coffee & Tea' },
  { key: 'stamps_target', label: 'Số tem để đổi thưởng', placeholder: 'VD: 9' },
];

const CSV_TABLES = [
  { key: 'orders' as const, label: 'Đơn hàng' },
  { key: 'products' as const, label: 'Sản phẩm' },
  { key: 'customers' as const, label: 'Khách hàng' },
  { key: 'categories' as const, label: 'Danh mục' },
  { key: 'payment_methods' as const, label: 'Thanh toán' },
];

const DRIVE_READY = isDriveConfigured();
const CONFIRM_WORD = 'KHOI PHUC';

type SectionKey = 'shop' | 'staff' | 'payment' | 'backup' | 'warehouse' | 'promo' | 'audit';

const AUDIT_LABELS: Record<string, string> = {
  'order.delete': '🗑️ Xóa đơn hàng',
  'order.edit': '✏️ Sửa đơn hàng',
  'product.price': '💲 Đổi giá món',
  'product.update': '📋 Sửa món',
  'product.delete': '🗑️ Xóa món',
  'staff.role': '👤 Đổi vai trò nhân viên',
  'staff.warehouse': '🗃️ Gán kho nhân viên',
  'promo.save': '🎁 Lưu khuyến mãi',
  'day.close': '🌙 Chốt ngày',
};

function formatSize(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 KB';
  if (bytes >= 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${Math.max(1, Math.round(bytes / 1024))} KB`;
}

function formatDriveTime(iso: string): string {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleString('vi-VN', {
      timeZone: 'Asia/Ho_Chi_Minh',
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return iso;
  }
}

export function Settings() {
  const toast = useToast();
  const { isOwner, logout } = useAuth();
  const navigate = useNavigate();
  const [values, setValues] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [backing, setBacking] = useState(false);
  const [openSection, setOpenSection] = useState<SectionKey | null>('shop');

  // Google Drive backup
  const [driveBusy, setDriveBusy] = useState(false);
  const [filesOpen, setFilesOpen] = useState(false);
  const [filesLoading, setFilesLoading] = useState(false);
  const [backupFiles, setBackupFiles] = useState<DriveFileInfo[]>([]);
  const [confirmTarget, setConfirmTarget] = useState<DriveFileInfo | null>(null);
  const [confirmText, setConfirmText] = useState('');
  const [jsonRestore, setJsonRestore] = useState<{ name: string; data: Record<string, unknown[]> } | null>(null);
  const [jsonConfirmText, setJsonConfirmText] = useState('');

  useEffect(() => {
    getSettings()
      .then(setValues)
      .catch(() => toast.show('Không tải được cài đặt'))
      .finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const toggle = (key: SectionKey) => setOpenSection((cur) => (cur === key ? null : key));

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const save = async (e: FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      for (const f of FIELDS) {
        await setSetting(f.key, values[f.key] ?? '');
      }
      toast.show('✅ Đã lưu cài đặt');
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Lưu thất bại');
    } finally {
      setSaving(false);
    }
  };

  const backupJson = async () => {
    setBacking(true);
    try {
      const d = todayVN().replace(/-/g, '');
      const data = await exportAllJson();
      downloadFile(`beesy-backup-${d}.json`, JSON.stringify(data, null, 2), 'application/json');
      toast.show('Đã tải file sao lưu JSON');
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Sao lưu thất bại');
    } finally {
      setBacking(false);
    }
  };

  const pickJsonFile = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json,application/json';
    input.onchange = async () => {
      const file = input.files?.[0];
      if (!file) return;
      try {
        const text = await file.text();
        const data = JSON.parse(text) as unknown;
        if (!data || typeof data !== 'object' || Array.isArray(data)) {
          throw new Error('File không đúng định dạng sao lưu.');
        }
        const rec = data as Record<string, unknown>;
        const hasData = Object.values(rec).some((v) => Array.isArray(v) && v.length > 0);
        if (!hasData) throw new Error('File sao lưu không có dữ liệu nào.');
        setJsonRestore({ name: file.name, data: rec as Record<string, unknown[]> });
        setJsonConfirmText('');
      } catch (ex) {
        toast.show(ex instanceof Error ? ex.message : 'Đọc file thất bại');
      }
    };
    input.click();
  };

  const doJsonRestore = async () => {
    if (!jsonRestore || jsonConfirmText !== CONFIRM_WORD) return;
    setBacking(true);
    try {
      const r = await restoreFromData(jsonRestore.data);
      toast.show(`Đã khôi phục ${r.docs} bản ghi (${r.collections} bảng) từ ${jsonRestore.name}`);
      setJsonRestore(null);
      setJsonConfirmText('');
    } catch (ex) {
      toast.show(ex instanceof Error ? ex.message : 'Khôi phục thất bại');
    } finally {
      setBacking(false);
    }
  };

  const backupCsv = async (table: (typeof CSV_TABLES)[number]['key']) => {
    setBacking(true);
    try {
      const d = todayVN().replace(/-/g, '');
      const csv = await exportTableCsv(table);
      downloadFile(`beesy-${table}-${d}.csv`, csv, 'text/csv');
      toast.show(`Đã tải CSV bảng ${table}`);
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Sao lưu thất bại');
    } finally {
      setBacking(false);
    }
  };

  // ------------------------------------------------------- Drive backup ---
  const driveBackup = async () => {
    setDriveBusy(true);
    try {
      const r = await backupToDrive();
      toast.show(`Đã sao lưu ${r.fileName} (${formatSize(r.size)}) lên Google Drive`);
    } catch (ex) {
      toast.show(ex instanceof Error ? ex.message : 'Sao lưu lên Drive thất bại');
    } finally {
      setDriveBusy(false);
    }
  };

  const loadBackupFiles = async () => {
    setFilesLoading(true);
    try {
      setBackupFiles(await listBackupFiles());
    } catch (ex) {
      toast.show(ex instanceof Error ? ex.message : 'Không tải được danh sách file sao lưu');
      setBackupFiles([]);
    } finally {
      setFilesLoading(false);
    }
  };

  const openRestore = () => {
    setConfirmTarget(null);
    setConfirmText('');
    setFilesOpen(true);
    void loadBackupFiles();
  };

  const [staffName, setStaffName] = useState('');
  const [staffEmail, setStaffEmail] = useState('');
  const [staffPass, setStaffPass] = useState('');
  const [staffRole, setStaffRole] = useState<RoleKey>('seller');
  const [staffBusy, setStaffBusy] = useState(false);
  const [staffListBusy, setStaffListBusy] = useState(false);

  // Khuyến mãi (giờ vàng)
  const [promos, setPromos] = useState<Promotion[]>([]);
  const [promoBusy, setPromoBusy] = useState(false);
  const [promoForm, setPromoForm] = useState<Promotion | 'new' | null>(null);
  // Nhật ký thao tác
  const [audits, setAudits] = useState<AuditLog[]>([]);
  const [auditBusy, setAuditBusy] = useState(false);

  // Multi-kho: kho mặc định + gán kho cho nhân viên
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [defaultWid, setDefaultWid] = useState('');
  const [whBusy, setWhBusy] = useState(false);
  const [whSaving, setWhSaving] = useState(false);

  const loadStaffWarehouse = async (forStaff: boolean) => {
    if (forStaff) setStaffListBusy(true); else setWhBusy(true);
    try {
      let ws = await listWarehouses(false);
      if (ws.length === 0) ws = await ensureWarehousesSeeded();
      const [us, def] = await Promise.all([listUsers(), getDefaultWarehouseId()]);
      setWarehouses(ws);
      setUsers(us);
      setDefaultWid(def ?? '');
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tải được cài đặt kho');
    } finally {
      if (forStaff) setStaffListBusy(false); else setWhBusy(false);
    }
  };

  useEffect(() => {
    if (openSection === 'warehouse') void loadStaffWarehouse(false);
    else if (openSection === 'staff') void loadStaffWarehouse(true);
    else if (openSection === 'promo') void loadPromos();
    else if (openSection === 'audit') void loadAudits();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [openSection]);

  const loadPromos = async () => {
    setPromoBusy(true);
    try {
      setPromos(await getPromotions());
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tải được khuyến mãi');
    } finally {
      setPromoBusy(false);
    }
  };

  const loadAudits = async () => {
    setAuditBusy(true);
    try {
      setAudits(await listAuditLogs(100));
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tải được nhật ký');
    } finally {
      setAuditBusy(false);
    }
  };

  const savePromoForm = async (p: Promotion) => {
    try {
      const next = promoForm === 'new' ? [...promos, p] : promos.map((x) => (x.id === p.id ? p : x));
      await savePromotions(next);
      setPromos(next);
      setPromoForm(null);
      toast.show('Đã lưu khuyến mãi');
      logAudit('promo.save', `Lưu khuyến mãi "${p.name}"`, { type: 'promotion', id: p.id });
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    }
  };

  const deletePromo = async (id: string) => {
    if (!window.confirm('Xóa khuyến mãi này?')) return;
    try {
      const next = promos.filter((x) => x.id !== id);
      await savePromotions(next);
      setPromos(next);
      toast.show('Đã xóa khuyến mãi');
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Xóa thất bại');
    }
  };

  const togglePromo = async (p: Promotion) => {
    try {
      const next = promos.map((x) => (x.id === p.id ? { ...x, active: !x.active } : x));
      await savePromotions(next);
      setPromos(next);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    }
  };

  const saveDefaultWarehouse = async () => {
    if (!defaultWid) {
      toast.show('Chọn kho mặc định');
      return;
    }
    setWhSaving(true);
    try {
      await setDefaultWarehouse(defaultWid);
      toast.show('Đã đặt kho bán hàng mặc định');
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    } finally {
      setWhSaving(false);
    }
  };

  const changeUserRole = async (u: User, role: RoleKey) => {
    if (role === u.role) return;
    try {
      await updateUserRole(u.id, role);
      setUsers((us) => us.map((x) => (x.id === u.id ? { ...x, role } : x)));
      toast.show(`Đã đổi ${u.full_name || u.email} thành ${ROLE_LABELS[role]}`);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Đổi vai trò thất bại');
    }
  };

  const toggleUserWarehouse = async (u: User, wid: string) => {
    const has = (u.warehouse_ids ?? []).includes(wid);
    const next = has
      ? (u.warehouse_ids ?? []).filter((x) => x !== wid)
      : [...(u.warehouse_ids ?? []), wid];
    try {
      await updateUserWarehouses(u.id, next);
      setUsers((us) => us.map((x) => (x.id === u.id ? { ...x, warehouse_ids: next } : x)));
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Cập nhật thất bại');
    }
  };

  // Chủ quán thêm tài khoản nhân viên ngay trong app (dùng Firebase app phụ để
  // không bị đăng xuất khỏi phiên chủ quán hiện tại).
  const addStaff = async (e: FormEvent) => {
    e.preventDefault();
    if (!staffName.trim() || !staffEmail.trim() || staffPass.length < 6) {
      toast.show('Nhập tên, email và mật khẩu (≥ 6 ký tự) cho nhân viên');
      return;
    }
    setStaffBusy(true);
    try {
      const secondary =
        getApps().find((a) => a.name === 'beesy-secondary') ??
        initializeApp(firebaseConfig, 'beesy-secondary');
      const secondaryAuth = getAuth(secondary);
      const cred = await createUserWithEmailAndPassword(secondaryAuth, staffEmail.trim(), staffPass);
      await signOut(secondaryAuth);
      await setDoc(doc(db, 'users', cred.user.uid), {
        id: cred.user.uid,
        email: staffEmail.trim(),
        full_name: staffName.trim(),
        role: staffRole,
        warehouse_ids: [],
      });
      toast.show(`Đã thêm ${ROLE_LABELS[staffRole]} ${staffName.trim()} (${staffEmail.trim()})`);
      setStaffName('');
      setStaffEmail('');
      setStaffPass('');
      setStaffRole('seller');
      void loadStaffWarehouse(true);
    } catch (ex) {
      const code = (ex as { code?: string })?.code ?? '';
      toast.show(
        code === 'auth/email-already-in-use'
          ? 'Email này đã được đăng ký.'
          : ex instanceof DbError
            ? ex.message
            : 'Thêm nhân viên thất bại. Kiểm tra mạng rồi thử lại.',
      );
    } finally {
      setStaffBusy(false);
    }
  };

  const doRestore = async () => {
    if (!confirmTarget || confirmText !== CONFIRM_WORD) return;
    setDriveBusy(true);
    try {
      const data = await downloadBackupFile(confirmTarget.id);
      const r = await restoreFromData(data);
      toast.show(`Đã khôi phục ${r.docs} bản ghi (${r.collections} bảng) từ ${confirmTarget.name}`);
      setFilesOpen(false);
      setConfirmTarget(null);
      setConfirmText('');
    } catch (ex) {
      toast.show(ex instanceof Error ? ex.message : 'Khôi phục thất bại');
    } finally {
      setDriveBusy(false);
    }
  };

  if (!isOwner) {
    return (
      <div className="page">
        <div className="card sb-empty">
          <div className="eico">🔒</div>
          <p style={{ fontWeight: 600, color: 'var(--ink)', marginBottom: 16 }}>
            Chỉ chủ quán mới được xem cài đặt.
          </p>
          <button
            className="btn btn-block"
            style={{}}
            onClick={handleLogout}
          >
            Đăng xuất
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="page">
      <div className="pg-home">
        <div className="pg-home-row">
          <span className="pg-shop-av">🏪</span>
          <span>
            <div className="pg-shop-name">{values.shop_name?.trim() || 'Beesy Coffee & Tea'}</div>
            <div className="pg-shop-sub">Chủ cửa hàng</div>
          </span>
        </div>
        <span className="sb-status-pill">Đã thiết lập</span>
      </div>

      <div className="sb-section" style={{ padding: '4px 16px' }}>
        <button className="sb-menu-row" onClick={() => toggle('shop')}>
          <span className="sb-ico-box3d"><AppIcon name="gear" fallback="🏪" size={34} /></span>
          Thông tin quán
          <span className="chev">›</span>
        </button>
        {openSection === 'shop' && (
          <div style={{ padding: '16px 4px 12px' }}>
            {loading ? (
              <div className="muted">Đang tải…</div>
            ) : (
              <form onSubmit={save}>
                {FIELDS.map((f) => (
                  <div className="sb-float" key={f.key}>
                    <label htmlFor={`set-${f.key}`}>{f.label}</label>
                    <input
                      id={`set-${f.key}`}
                      placeholder={f.placeholder}
                      value={values[f.key] ?? ''}
                      onChange={(e) => setValues((v) => ({ ...v, [f.key]: e.target.value }))}
                    />
                  </div>
                ))}
                <button type="submit" className="btn btn-block" disabled={saving}>
                  {saving ? 'Đang lưu…' : 'Lưu cài đặt'}
                </button>
              </form>
            )}
          </div>
        )}

        <button className="sb-menu-row" onClick={() => toggle('staff')}>
          <span className="sb-ico-box3d"><AppIcon name="users" fallback="👥" size={34} /></span>
          Nhân viên
          <span className="chev">›</span>
        </button>
        {openSection === 'staff' && (
          <div style={{ padding: '16px 4px 12px' }}>
            <form onSubmit={addStaff}>
              <div className="sb-float">
                <label htmlFor="st-name">Tên nhân viên</label>
                <input
                  id="st-name"
                  value={staffName}
                  onChange={(e) => setStaffName(e.target.value)}
                  placeholder="VD: Lan"
                />
              </div>
              <div className="sb-float">
                <label htmlFor="st-email">Email đăng nhập</label>
                <input
                  id="st-email"
                  autoComplete="off"
                  value={staffEmail}
                  onChange={(e) => setStaffEmail(e.target.value)}
                  placeholder="VD: lan@beesy.local"
                />
              </div>
              <div className="sb-float">
                <label htmlFor="st-pass">Mật khẩu (≥ 6 ký tự)</label>
                <input
                  id="st-pass"
                  type="password"
                  autoComplete="new-password"
                  value={staffPass}
                  onChange={(e) => setStaffPass(e.target.value)}
                  placeholder="••••••"
                />
              </div>
              <div className="field">
                <label>Nhóm nhân viên</label>
                <select
                  className="input"
                  value={staffRole}
                  onChange={(e) => setStaffRole(e.target.value as RoleKey)}
                >
                  {STAFF_ROLES.map((r) => (
                    <option key={r} value={r}>
                      {ROLE_LABELS[r]}
                      {r === 'manager'
                        ? ' — quản lý menu, kho, quỹ, báo cáo'
                        : r === 'cashier'
                          ? ' — bán hàng, thu nợ'
                          : ' — bán hàng'}
                    </option>
                  ))}
                </select>
              </div>
              <button type="submit" className="btn btn-block" disabled={staffBusy}>
                {staffBusy ? 'Đang thêm…' : 'Thêm nhân viên'}
              </button>
              <p className="small muted" style={{ marginBottom: 0, marginTop: 10 }}>
                Nhân viên dùng email/mật khẩu này để đăng nhập. Xóa tài khoản: Firebase
                console → Authentication / Firestore.
              </p>
            </form>

            <div style={{ fontWeight: 700, fontSize: 15, margin: '20px 0 8px' }}>
              Danh sách nhân viên
            </div>
            {staffListBusy ? (
              <div className="muted">Đang tải…</div>
            ) : users.filter((u) => u.role !== 'owner').length === 0 ? (
              <p className="small muted">Chưa có tài khoản nhân viên nào.</p>
            ) : (
              users
                .filter((u) => u.role !== 'owner')
                .map((u) => (
                  <div className="sb-section" key={u.id} style={{ marginBottom: 10 }}>
                    <div style={{ fontWeight: 600, fontSize: 15 }}>
                      {u.full_name || u.email}
                      <span className="small muted"> · {u.email}</span>
                    </div>
                    <div className="field" style={{ marginTop: 8, marginBottom: 8 }}>
                      <label>Nhóm</label>
                      <select
                        className="input"
                        value={u.role}
                        onChange={(e) => void changeUserRole(u, e.target.value as RoleKey)}
                      >
                        {STAFF_ROLES.map((r) => (
                          <option key={r} value={r}>
                            {ROLE_LABELS[r]}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="small muted" style={{ marginBottom: 6, fontWeight: 600 }}>
                      Kho được dùng
                    </div>
                    <div className="row" style={{ flexWrap: 'wrap', gap: 8 }}>
                      {warehouses.filter((w) => w.active).length === 0 ? (
                        <span className="small muted">Chưa có kho nào.</span>
                      ) : (
                        warehouses
                          .filter((w) => w.active)
                          .map((w) => {
                            const checked = (u.warehouse_ids ?? []).includes(w.id);
                            return (
                              <label
                                key={w.id}
                                className={`sb-chip${checked ? ' selected' : ''}`}
                                style={{ minHeight: 36, padding: '4px 12px', fontSize: 13, cursor: 'pointer' }}
                              >
                                <input
                                  type="checkbox"
                                  checked={checked}
                                  onChange={() => void toggleUserWarehouse(u, w.id)}
                                  style={{ marginRight: 6 }}
                                />
                                {w.name}
                              </label>
                            );
                          })
                      )}
                    </div>
                  </div>
                ))
            )}
          </div>
        )}

        <button className="sb-menu-row" onClick={() => toggle('warehouse')}>
          <span className="sb-ico-box3d"><AppIcon name="archive" fallback="🗃️" size={34} /></span>
          Kho hàng
          <span className="chev">›</span>
        </button>
        {openSection === 'warehouse' && (
          <div style={{ padding: '16px 4px 12px' }}>
            {whBusy ? (
              <div className="muted">Đang tải…</div>
            ) : (
              <>
                <div className="field">
                  <label>Kho bán hàng mặc định (POS trừ tồn ở kho này)</label>
                  <select
                    className="input"
                    value={defaultWid}
                    onChange={(e) => setDefaultWid(e.target.value)}
                  >
                    <option value="">— Chọn kho —</option>
                    {warehouses
                      .filter((w) => w.active)
                      .map((w) => (
                        <option key={w.id} value={w.id}>
                          {w.name}
                        </option>
                      ))}
                  </select>
                </div>
                <button type="button" className="btn btn-block" disabled={whSaving} onClick={saveDefaultWarehouse}>
                  {whSaving ? 'Đang lưu…' : 'Lưu kho mặc định'}
                </button>

                <div style={{ fontWeight: 700, fontSize: 15, margin: '18px 0 8px' }}>
                  Phân quyền nhân viên
                </div>
                <p className="small muted" style={{ marginTop: 0 }}>
                  Đổi nhóm vai trò và gán kho cho từng nhân viên ở mục{' '}
                  <b>Nhân viên</b> bên trên. Quản lý dùng được mọi kho; Thu ngân/Bán hàng chỉ
                  dùng các kho được gán.
                </p>
                <button
                  type="button"
                  className="btn btn-outline btn-block"
                  style={{ marginTop: 6 }}
                  onClick={() => navigate('/inventory')}
                >
                  Quản lý kho ở màn Tồn kho →
                </button>
              </>
            )}
          </div>
        )}

        <button className="sb-menu-row" onClick={() => toggle('promo')}>
          <span className="sb-ico-box3d"><AppIcon name="gift" fallback="🎁" size={34} /></span>
          Khuyến mãi (giờ vàng)
          <span className="chev">›</span>
        </button>
        {openSection === 'promo' && (
          <div style={{ padding: '16px 4px 12px' }}>
            {promoBusy ? (
              <div className="muted">Đang tải…</div>
            ) : (
              <>
                <p className="small muted" style={{ marginTop: 0 }}>
                  Khuyến mãi đang trong khung giờ sẽ <b>tự áp dụng</b> ở màn thanh toán. Nhân viên
                  vẫn có thể sửa tay mức giảm cho từng đơn.
                </p>
                {promos.length === 0 ? (
                  <p className="small muted">Chưa có khuyến mãi nào.</p>
                ) : (
                  promos.map((p) => (
                    <div className="sb-section" key={p.id} style={{ marginBottom: 10, opacity: p.active ? 1 : 0.6 }}>
                      <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center' }}>
                        <div style={{ fontWeight: 600 }}>
                          {p.name}{' '}
                          <span className="small" style={{ color: 'var(--green)' }}>
                            {p.type === 'percent' ? `-${p.value}%` : `-${p.value.toLocaleString('vi-VN')}đ`}
                          </span>
                        </div>
                        <label className="switch" style={{ flexShrink: 0 }}>
                          <input type="checkbox" checked={p.active} onChange={() => void togglePromo(p)} />
                          <span className="track" />
                        </label>
                      </div>
                      <div className="small muted" style={{ margin: '4px 0 8px' }}>
                        ⏰ {p.start} – {p.end} hằng ngày
                      </div>
                      <div className="row" style={{ gap: 8 }}>
                        <button className="btn btn-outline" style={{ minHeight: 40 }} onClick={() => setPromoForm(p)}>
                          Sửa
                        </button>
                        <button
                          className="btn btn-outline"
                          style={{ minHeight: 40 }}
                          onClick={() => void deletePromo(p.id)}
                        >
                          Xóa
                        </button>
                      </div>
                    </div>
                  ))
                )}
                <button className="btn btn-block" onClick={() => setPromoForm('new')}>
                  ＋ Thêm khuyến mãi
                </button>
              </>
            )}
            {promoForm && (
              <PromoForm
                initial={promoForm === 'new' ? null : promoForm}
                onClose={() => setPromoForm(null)}
                onSave={(p) => void savePromoForm(p)}
              />
            )}
          </div>
        )}

        <button className="sb-menu-row" onClick={() => toggle('audit')}>
          <span className="sb-ico-box3d"><AppIcon name="scroll" fallback="📜" size={34} /></span>
          Nhật ký thao tác
          <span className="chev">›</span>
        </button>
        {openSection === 'audit' && (
          <div style={{ padding: '16px 4px 12px' }}>
            {auditBusy ? (
              <div className="muted">Đang tải…</div>
            ) : audits.length === 0 ? (
              <p className="small muted">Chưa có thao tác nào được ghi.</p>
            ) : (
              audits.map((a) => (
                <div className="sb-section" key={a.id} style={{ marginBottom: 8 }}>
                  <div style={{ fontWeight: 600, fontSize: 14 }}>
                    {AUDIT_LABELS[a.action] ?? a.action}
                  </div>
                  {a.detail && <div className="small" style={{ marginTop: 2 }}>{a.detail}</div>}
                  <div className="small muted" style={{ marginTop: 4 }}>
                    {a.actor_name ?? '—'} ·{' '}
                    {new Date(a.created_at).toLocaleString('vi-VN', { timeZone: 'Asia/Ho_Chi_Minh' })}
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        <button className="sb-menu-row" onClick={() => toggle('payment')}>
          <span className="sb-ico-box3d"><AppIcon name="card" fallback="💳" size={34} /></span>
          Phương thức thanh toán
          <span className="chev">›</span>
        </button>
        {openSection === 'payment' && (
          <div style={{ padding: '8px 4px 12px' }}>
            <PaymentMethodsManager />
          </div>
        )}

        <button className="sb-menu-row" onClick={() => toggle('backup')}>
          <span className="sb-ico-box3d"><AppIcon name="cloud" fallback="☁️" size={34} /></span>
          Sao lưu &amp; khôi phục
          <span className="chev">›</span>
        </button>
        {openSection === 'backup' && (
          <div style={{ padding: '16px 4px 12px' }}>
            {!DRIVE_READY ? (
              <p className="small muted" style={{ marginBottom: 0 }}>
                Chưa cấu hình Google Client ID — xem README mục <b>“Bật Google Drive backup”</b>{' '}
                để lấy Client ID, điền vào <code>frontend/.env</code> (biến{' '}
                <code>VITE_GOOGLE_CLIENT_ID</code>), build lại rồi deploy.
              </p>
            ) : (
              <>
                <button
                  className="btn btn-block"
                  style={{ marginBottom: 8 }}
                  disabled={driveBusy}
                  onClick={driveBackup}
                >
                  {driveBusy ? 'Đang xử lý…' : 'Sao lưu lên Google Drive'}
                </button>
                <button
                  className="btn btn-outline btn-block"
                  style={{ marginBottom: 12 }}
                  disabled={driveBusy}
                  onClick={openRestore}
                >
                  Khôi phục từ Google Drive
                </button>
                <p className="small muted">
                  Sao lưu &amp; khôi phục hoàn toàn trên trình duyệt (không tốn Cloud Functions).
                  Lần đầu dùng, Google sẽ hỏi cho phép truy cập Drive.
                </p>
              </>
            )}
            <div className="row" style={{ margin: '16px 0 8px' }}>
              <b className="grow">Sao lưu thủ công</b>
            </div>
            <button className="btn btn-outline btn-block" style={{ marginBottom: 8 }} disabled={backing} onClick={backupJson}>
              Tải toàn bộ dữ liệu (JSON)
            </button>
            <button className="btn btn-outline btn-block" style={{ marginBottom: 8 }} disabled={backing} onClick={pickJsonFile}>
              Khôi phục từ file JSON
            </button>
            {jsonRestore && (
              <div
                className="card"
                style={{ marginBottom: 8, border: '2px solid var(--red)', background: 'var(--red-bg)' }}
              >
                <b style={{ color: 'var(--red)' }}>NGUY HIỂM — xác nhận khôi phục</b>
                <p className="small">
                  Thao tác này sẽ <b>GHI ĐÈ</b> toàn bộ dữ liệu hiện tại bằng dữ liệu trong file{' '}
                  <b>{jsonRestore.name}</b>. Không thể hoàn tác!
                </p>
                <p className="small">
                  Để xác nhận, gõ đúng chữ <b>{CONFIRM_WORD}</b> vào ô bên dưới:
                </p>
                <input
                  className="input"
                  value={jsonConfirmText}
                  onChange={(e) => setJsonConfirmText(e.target.value)}
                  placeholder={CONFIRM_WORD}
                  style={{ marginBottom: 10 }}
                />
                <div className="row">
                  <button
                    className="btn"
                    style={{}}
                    disabled={backing || jsonConfirmText !== CONFIRM_WORD}
                    onClick={doJsonRestore}
                  >
                    {backing ? 'Đang khôi phục…' : 'Xác nhận khôi phục'}
                  </button>
                  <button
                    type="button"
                    className="btn btn-ghost"
                    disabled={backing}
                    onClick={() => setJsonRestore(null)}
                  >
                    Hủy
                  </button>
                </div>
              </div>
            )}
            <p className="small muted">Tải từng bảng dạng CSV (tiếng Việt, có header):</p>
            <div className="opt-grid">
              {CSV_TABLES.map((t) => (
                <button key={t.key} className="btn btn-outline" disabled={backing} onClick={() => backupCsv(t.key)}>
                  {t.label}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="sb-section" style={{ padding: '4px 16px' }}>
        <button className="sb-menu-row danger" onClick={handleLogout}>
          <span className="sb-ico-box" style={{ background: '#FDECEC' }}>🚪</span>
          Đăng xuất
          <span className="chev">›</span>
        </button>
      </div>

      {filesOpen && (
        <Sheet title="Khôi phục từ Google Drive" onClose={() => setFilesOpen(false)}>
          {filesLoading ? (
            <div className="muted">Đang tải danh sách file…</div>
          ) : backupFiles.length === 0 ? (
            <div className="muted">Chưa có file sao lưu nào trong thư mục “Beesy POS Backup”.</div>
          ) : (
            backupFiles.map((f) => (
              <div className="sb-row" key={f.id}>
                <span className="rbody">
                  <span className="rtitle">{f.name}</span>
                  <span className="rsub">
                    {formatDriveTime(f.createdTime)} · {formatSize(Number(f.size) || 0)}
                  </span>
                </span>
                <button
                  className="btn btn-outline btn-sm"
                  disabled={driveBusy}
                  onClick={() => {
                    setConfirmTarget(f);
                    setConfirmText('');
                  }}
                >
                  Khôi phục
                </button>
              </div>
            ))
          )}

          {confirmTarget && (
            <div
              className="card"
              style={{ marginTop: 12, border: '2px solid var(--red)', background: 'var(--red-bg)' }}
            >
              <b style={{ color: 'var(--red)' }}>NGUY HIỂM — xác nhận khôi phục</b>
              <p className="small">
                Thao tác này sẽ <b>GHI ĐÈ</b> toàn bộ dữ liệu hiện tại bằng dữ liệu trong file{' '}
                <b>{confirmTarget.name}</b>. Đơn hàng, menu, khách hàng… hiện tại sẽ bị thay thế.
                Không thể hoàn tác!
              </p>
              <p className="small">
                Để xác nhận, gõ đúng chữ <b>{CONFIRM_WORD}</b> vào ô bên dưới:
              </p>
              <input
                className="input"
                value={confirmText}
                onChange={(e) => setConfirmText(e.target.value)}
                placeholder={CONFIRM_WORD}
                style={{ marginBottom: 10 }}
              />
              <div className="row">
                <button
                  className="btn"
                  style={{}}
                  disabled={driveBusy || confirmText !== CONFIRM_WORD}
                  onClick={doRestore}
                >
                  {driveBusy ? 'Đang khôi phục…' : 'Xác nhận khôi phục'}
                </button>
                <button
                  type="button"
                  className="btn btn-ghost"
                  disabled={driveBusy}
                  onClick={() => setConfirmTarget(null)}
                >
                  Hủy
                </button>
              </div>
            </div>
          )}
        </Sheet>
      )}
    </div>
  );
}

// ------------------------------------------------- quản lý phương thức thanh toán ---
function PaymentMethodsManager() {
  const toast = useToast();
  const [methods, setMethods] = useState<PaymentMethodDef[]>([]);
  const [loading, setLoading] = useState(true);
  const [formOpen, setFormOpen] = useState<PaymentMethodDef | 'new' | null>(null);

  const reload = async () => {
    setLoading(true);
    try {
      setMethods(await listPaymentMethods(false));
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tải được phương thức thanh toán');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void reload();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const toggleActive = async (m: PaymentMethodDef) => {
    try {
      await updatePaymentMethod(m.id, { active: !m.active });
      await reload();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Cập nhật thất bại');
    }
  };

  const remove = async (m: PaymentMethodDef) => {
    if (!window.confirm(`Xóa phương thức “${m.name}”? Đơn hàng cũ không bị ảnh hưởng.`)) return;
    try {
      await deletePaymentMethod(m.id);
      toast.show('Đã xóa phương thức');
      await reload();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Xóa thất bại');
    }
  };

  return (
    <div>
      <div className="row" style={{ marginBottom: 4 }}>
        <b className="grow">Danh sách phương thức</b>
        <button className="btn btn-sm" onClick={() => setFormOpen('new')}>
          Thêm
        </button>
      </div>
      {loading ? (
        <div className="muted">Đang tải…</div>
      ) : methods.length === 0 ? (
        <div className="sb-empty">Chưa có phương thức nào</div>
      ) : (
        <div style={{ marginBottom: 8 }}>
          {methods.map((m) => (
            <div className="sb-row" key={m.id} style={m.active ? undefined : { opacity: 0.5 }}>
              <span
                className="sb-ico-box"
                style={{ width: 44, height: 44, borderRadius: 12, background: 'var(--gray-bg)' }}
              >
                {m.icon}
              </span>
              <span className="rbody">
                <span className="rtitle">{m.name}</span>
                <span className="rsub">
                  {paymentKindLabel(m.kind)}
                  {m.kind === 'transfer' && m.bank_account ? ` · ${m.bank_account}` : ''}
                  {!m.active ? ' · Đang ẩn' : ''}
                </span>
              </span>
              <button className="btn btn-ghost btn-sm" onClick={() => toggleActive(m)}>
                {m.active ? 'Ẩn' : 'Hiện'}
              </button>
              <button className="btn btn-ghost btn-sm" onClick={() => setFormOpen(m)}>
                Sửa
              </button>
              {!isSystemPaymentMethod(m.id) && (
                <button
                  className="btn btn-ghost btn-sm"
                  onClick={() => remove(m)}
                >
                  Xóa
                </button>
              )}
            </div>
          ))}
        </div>
      )}
      <p className="small muted" style={{ marginBottom: 0 }}>
        Phương thức mặc định (Tiền mặt / Chuyển khoản / Ghi nợ) chỉ Ẩn được, không xóa. Thông tin
        ngân hàng của từng phương thức chuyển khoản dùng để sinh mã VietQR khi thanh toán.
      </p>
      {formOpen && (
        <PaymentMethodForm
          method={formOpen === 'new' ? null : formOpen}
          onClose={() => setFormOpen(null)}
          onSaved={() => void reload()}
        />
      )}
    </div>
  );
}

function PaymentMethodForm({ method, onClose, onSaved }: {
  method: PaymentMethodDef | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const toast = useToast();
  const [name, setName] = useState(method?.name ?? '');
  const [kind, setKind] = useState<PaymentMethodKind>(method?.kind ?? 'cash');
  const [icon, setIcon] = useState(method?.icon ?? '💵');
  const [bin, setBin] = useState(method?.bank_bin ?? '');
  const [account, setAccount] = useState(method?.bank_account ?? '');
  const [accountName, setAccountName] = useState(method?.bank_account_name ?? '');
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      toast.show('Nhập tên phương thức');
      return;
    }
    if (kind === 'transfer' && (!bin.trim() || !account.trim())) {
      toast.show('Chuyển khoản cần nhập mã BIN và số tài khoản để sinh VietQR');
      return;
    }
    setBusy(true);
    try {
      const body = {
        name: name.trim(),
        kind,
        icon: icon.trim() || '💳',
        bank_bin: kind === 'transfer' ? bin.trim() : null,
        bank_account: kind === 'transfer' ? account.trim() : null,
        bank_account_name: kind === 'transfer' ? accountName.trim() : null,
      };
      if (method) await updatePaymentMethod(method.id, body);
      else await createPaymentMethod(body);
      toast.show(method ? 'Đã cập nhật' : 'Đã thêm phương thức');
      onSaved();
      onClose();
    } catch (ex) {
      toast.show(ex instanceof DbError ? ex.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet title={method ? 'Sửa phương thức' : 'Thêm phương thức'} onClose={onClose}>
      <form onSubmit={submit}>
        <div className="sb-float">
          <label>Tên phương thức <span className="req">*</span></label>
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="VD: Momo, VNPay, Chuyển khoản VCB…" />
        </div>
        <div className="sb-float">
          <label>Loại</label>
          <select value={kind} onChange={(e) => setKind(e.target.value as PaymentMethodKind)}>
            <option value="cash">Tiền mặt (nhập tiền khách đưa, tính thối lại)</option>
            <option value="transfer">Chuyển khoản (hiện mã VietQR)</option>
            <option value="debt">Ghi nợ (cộng vào công nợ khách)</option>
          </select>
        </div>
        <div className="sb-float">
          <label>Biểu tượng</label>
          <input value={icon} onChange={(e) => setIcon(e.target.value)} placeholder="VD: 💵" maxLength={4} />
        </div>
        {kind === 'transfer' && (
          <>
            <div className="sb-float">
              <label>Mã BIN ngân hàng <span className="req">*</span></label>
              <input value={bin} onChange={(e) => setBin(e.target.value)} placeholder="VD: 970422 (MB)" />
            </div>
            <div className="sb-float">
              <label>Số tài khoản <span className="req">*</span></label>
              <input value={account} onChange={(e) => setAccount(e.target.value)} placeholder="VD: 0901234567" />
            </div>
            <div className="sb-float">
              <label>Tên chủ tài khoản</label>
              <input value={accountName} onChange={(e) => setAccountName(e.target.value)} placeholder="VD: BEESY COFFEE" />
            </div>
          </>
        )}
        <button type="submit" className="btn btn-block btn-lg" disabled={busy}>
          {busy ? 'Đang lưu…' : 'Lưu'}
        </button>
      </form>
    </Sheet>
  );
}

/** Form thêm/sửa khuyến mãi giờ vàng. */
function PromoForm({
  initial,
  onClose,
  onSave,
}: {
  initial: Promotion | null;
  onClose: () => void;
  onSave: (p: Promotion) => void;
}) {
  const [name, setName] = useState(initial?.name ?? '');
  const [type, setType] = useState<'percent' | 'amount'>(initial?.type ?? 'percent');
  const [value, setValue] = useState(initial ? String(initial.value) : '');
  const [start, setStart] = useState(initial?.start ?? '14:00');
  const [end, setEnd] = useState(initial?.end ?? '17:00');

  const submit = () => {
    const v = Math.max(0, parseInt(value.replace(/\D/g, ''), 10) || 0);
    if (!name.trim()) return;
    if (v <= 0) return;
    onSave({
      id: initial?.id ?? `promo_${Date.now()}`,
      name: name.trim().slice(0, 100),
      type,
      value: type === 'percent' ? Math.min(100, v) : v,
      start,
      end,
      active: initial?.active ?? true,
    });
  };

  return (
    <Sheet title={initial ? 'Sửa khuyến mãi' : 'Thêm khuyến mãi'} onClose={onClose}>
      <div className="field">
        <label>Tên khuyến mãi</label>
        <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="VD: Giờ vàng chiều" />
      </div>
      <div className="field">
        <label>Kiểu giảm</label>
        <div className="row" style={{ gap: 8 }}>
          <button
            type="button"
            className={`sb-chip${type === 'percent' ? ' selected' : ''}`}
            style={{ minHeight: 40, padding: '4px 16px' }}
            onClick={() => setType('percent')}
          >
            Giảm %
          </button>
          <button
            type="button"
            className={`sb-chip${type === 'amount' ? ' selected' : ''}`}
            style={{ minHeight: 40, padding: '4px 16px' }}
            onClick={() => setType('amount')}
          >
            Giảm tiền
          </button>
          <input
            className="input grow"
            inputMode="numeric"
            placeholder={type === 'percent' ? '% (VD: 10)' : 'Số tiền (VD: 5000)'}
            value={value}
            onChange={(e) => setValue(e.target.value)}
          />
        </div>
      </div>
      <div className="row" style={{ gap: 8 }}>
        <div className="field grow">
          <label>Từ giờ</label>
          <input type="time" className="input" value={start} onChange={(e) => setStart(e.target.value)} />
        </div>
        <div className="field grow">
          <label>Đến giờ</label>
          <input type="time" className="input" value={end} onChange={(e) => setEnd(e.target.value)} />
        </div>
      </div>
      <button className="btn btn-block btn-lg" onClick={submit}>
        Lưu khuyến mãi
      </button>
    </Sheet>
  );
}
