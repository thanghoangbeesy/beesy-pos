// Tồn kho — quản lý nguyên liệu: nhập/xuất kho, cảnh báo sắp hết, lịch sử.
// Bán 1 món tự trừ kho theo định lượng khai ở Menu (trong transaction tạo đơn).
import { useCallback, useEffect, useState } from 'react';
import {
  DbError,
  adjustStock,
  createIngredient,
  deleteIngredient,
  listIngredients,
  listStockLogs,
  updateIngredient,
} from '../lib/db';
import { formatTime, formatVND } from '../lib/format';
import { PageHead } from '../components/PageHead';
import { Sheet } from '../components/Sheet';
import { useToast } from '../components/Toast';
import { useAuth } from '../lib/auth';
import type { Ingredient, StockLog } from '../lib/types';

const UNIT_SUGGESTIONS = ['g', 'kg', 'ml', 'lít', 'cái', 'hộp', 'túi', 'gói'];

/** Hiển thị số lượng gọn: bỏ số 0 thừa do float (VD 0.30000000004 → 0.3). */
function formatQty(v: number): string {
  const n = parseFloat(v.toFixed(3));
  return n.toLocaleString('vi-VN', { maximumFractionDigits: 3 });
}

export function Inventory() {
  const toast = useToast();
  const { isOwner } = useAuth();
  const [tab, setTab] = useState<'stock' | 'history'>('stock');
  const [items, setItems] = useState<Ingredient[]>([]);
  const [logs, setLogs] = useState<StockLog[]>([]);
  const [busy, setBusy] = useState(true);
  const [formIng, setFormIng] = useState<Ingredient | 'new' | null>(null);
  const [adjustIng, setAdjustIng] = useState<Ingredient | null>(null);

  const load = useCallback(async () => {
    setBusy(true);
    try {
      const [ings, lg] = await Promise.all([listIngredients(), listStockLogs(100)]);
      setItems(ings);
      setLogs(lg);
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Không tải được tồn kho');
    } finally {
      setBusy(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  if (!isOwner) {
    return (
      <div className="page">
        <div className="card">🔒 Chỉ chủ quán mới được quản lý tồn kho.</div>
      </div>
    );
  }

  const lowCount = items.filter((i) => i.active && i.stock <= i.min_stock).length;

  return (
    <div className="page">
      <PageHead title="Tồn kho" />

      <div className="sb-tabs">
        <button className={`sb-tab${tab === 'stock' ? ' active' : ''}`} onClick={() => setTab('stock')}>
          Nguyên liệu
        </button>
        <button className={`sb-tab${tab === 'history' ? ' active' : ''}`} onClick={() => setTab('history')}>
          Lịch sử
        </button>
      </div>

      {busy ? (
        <div className="card">Đang tải…</div>
      ) : tab === 'stock' ? (
        <>
          <div className="row" style={{ gap: 12, marginBottom: 12 }}>
            <div className="card pastel-blue grow" style={{ boxShadow: 'none' }}>
              <div className="small muted">Nguyên liệu</div>
              <div className="money" style={{ fontSize: 22 }}>{items.filter((i) => i.active).length}</div>
            </div>
            <div className="card pastel-yellow grow" style={{ boxShadow: 'none' }}>
              <div className="small muted">Sắp hết / hết</div>
              <div className={`money ${lowCount > 0 ? 'text-orange' : ''}`} style={{ fontSize: 22 }}>
                {lowCount}
              </div>
            </div>
          </div>

          {items.length === 0 ? (
            <div className="sb-empty">
              <div className="eico">🗃️</div>
              <p>Chưa có nguyên liệu nào.<br />Bấm + để thêm nguyên liệu đầu tiên.</p>
            </div>
          ) : (
            items.map((ing) => {
              const low = ing.stock <= ing.min_stock;
              return (
                <div className="sb-section" key={ing.id} style={{ marginBottom: 10, opacity: ing.active ? 1 : 0.55 }}>
                  <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center' }}>
                    <div>
                      <div style={{ fontWeight: 600, fontSize: 16 }}>
                        {ing.name}
                        {!ing.active && (
                          <span className="sb-status-pill" style={{ marginLeft: 6, fontSize: 11 }}>Đang ẩn</span>
                        )}
                      </div>
                      <div className="small muted">
                        Tồn tối thiểu: {formatQty(ing.min_stock)} {ing.unit}
                        {ing.cost_per_unit > 0 && <> · {formatVND(ing.cost_per_unit)}/{ing.unit}</>}
                      </div>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <div className={`money ${low ? 'text-orange' : 'text-green'}`} style={{ fontSize: 20 }}>
                        {formatQty(ing.stock)}
                      </div>
                      <div className="small muted">{ing.unit}{low ? ' · sắp hết!' : ''}</div>
                    </div>
                  </div>
                  <div className="row" style={{ gap: 8, marginTop: 10 }}>
                    <button className="btn btn-outline grow" onClick={() => setAdjustIng(ing)}>
                      Nhập / Xuất
                    </button>
                    <button className="btn btn-ghost grow" onClick={() => setFormIng(ing)}>
                      Sửa
                    </button>
                  </div>
                </div>
              );
            })
          )}

          <button className="fab" onClick={() => setFormIng('new')} aria-label="Thêm nguyên liệu">
            +
          </button>
        </>
      ) : (
        <>
          {logs.length === 0 ? (
            <div className="sb-empty">
              <div className="eico">📜</div>
              <p>Chưa có lịch sử nhập/xuất kho.</p>
            </div>
          ) : (
            logs.map((l) => (
              <div className="sb-row" key={l.id} style={{ cursor: 'default' }}>
                <span
                  className="avatar"
                  style={
                    l.change > 0
                      ? { background: 'var(--green-bg)', color: 'var(--brand-dark)' }
                      : { background: 'var(--orange-bg)', color: 'var(--orange)' }
                  }
                >
                  {l.change > 0 ? '↓' : '↑'}
                </span>
                <span className="rbody">
                  <span className="rtitle">
                    {l.ingredient_name}
                    {l.ref_type === 'order' && (
                      <span className="sb-status-pill" style={{ marginLeft: 6, fontSize: 11 }}>Tự động</span>
                    )}
                  </span>
                  <span className="rsub">
                    {l.note ? `${l.note} · ` : ''}
                    {formatTime(l.created_at)}
                  </span>
                </span>
                <span style={{ textAlign: 'right' }}>
                  <span className={`ramount ${l.change > 0 ? 'text-green' : 'text-orange'}`}>
                    {l.change > 0 ? '+' : ''}
                    {formatQty(l.change)}
                  </span>
                  <span className="small muted" style={{ display: 'block' }}>
                    còn {formatQty(l.balance_after)}
                  </span>
                </span>
              </div>
            ))
          )}
        </>
      )}

      {formIng && (
        <IngredientForm
          ingredient={formIng === 'new' ? null : formIng}
          onClose={() => setFormIng(null)}
          onDone={() => {
            setFormIng(null);
            void load();
          }}
        />
      )}

      {adjustIng && (
        <AdjustSheet
          ingredient={adjustIng}
          onClose={() => setAdjustIng(null)}
          onDone={() => {
            setAdjustIng(null);
            void load();
          }}
        />
      )}
    </div>
  );
}

function IngredientForm({
  ingredient,
  onClose,
  onDone,
}: {
  ingredient: Ingredient | null;
  onClose: () => void;
  onDone: () => void;
}) {
  const toast = useToast();
  const [name, setName] = useState(ingredient?.name ?? '');
  const [unit, setUnit] = useState(ingredient?.unit ?? 'g');
  const [stock, setStock] = useState(ingredient ? String(ingredient.stock) : '');
  const [minStock, setMinStock] = useState(ingredient?.min_stock ? String(ingredient.min_stock) : '');
  const [cost, setCost] = useState(ingredient?.cost_per_unit ? String(ingredient.cost_per_unit) : '');
  const [active, setActive] = useState(ingredient?.active ?? true);
  const [busy, setBusy] = useState(false);
  const [confirmDel, setConfirmDel] = useState(false);

  const num = (v: string) => parseFloat(String(v).replace(',', '.'));

  const save = async () => {
    if (!name.trim()) {
      toast.show('Nhập tên nguyên liệu');
      return;
    }
    setBusy(true);
    try {
      if (ingredient) {
        await updateIngredient(ingredient.id, {
          name: name.trim(),
          unit: unit.trim() || 'đơn vị',
          min_stock: Number.isFinite(num(minStock)) ? Math.max(0, num(minStock)) : 0,
          cost_per_unit: Number.isFinite(num(cost)) ? Math.max(0, Math.round(num(cost))) : 0,
          active,
        });
        toast.show('Đã cập nhật nguyên liệu');
      } else {
        const s = stock.trim() === '' ? 0 : num(stock);
        if (!Number.isFinite(s)) {
          toast.show('Tồn đầu không hợp lệ');
          setBusy(false);
          return;
        }
        await createIngredient({
          name: name.trim(),
          unit: unit.trim() || 'đơn vị',
          stock: s,
          min_stock: Number.isFinite(num(minStock)) ? Math.max(0, num(minStock)) : 0,
          cost_per_unit: Number.isFinite(num(cost)) ? Math.max(0, Math.round(num(cost))) : 0,
        });
        toast.show('Đã thêm nguyên liệu');
      }
      onDone();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Lưu thất bại');
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    if (!ingredient) return;
    setBusy(true);
    try {
      await deleteIngredient(ingredient.id);
      toast.show('Đã xóa nguyên liệu');
      onDone();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Xóa thất bại');
    } finally {
      setBusy(false);
      setConfirmDel(false);
    }
  };

  return (
    <Sheet
      title={ingredient ? 'Sửa nguyên liệu' : 'Thêm nguyên liệu'}
      onClose={onClose}
      footer={
        <button className="btn btn-block btn-lg" disabled={busy} onClick={save}>
          {busy ? 'Đang lưu…' : 'Lưu'}
        </button>
      }
    >
      <div className="field">
        <label>Tên nguyên liệu *</label>
        <input
          className="input"
          value={name}
          onChange={(e) => setName(e.target.value)}
          maxLength={60}
          placeholder="VD: Cà phê bột"
          autoFocus={!ingredient}
        />
      </div>
      <div className="field">
        <label>Đơn vị</label>
        <div className="row" style={{ flexWrap: 'wrap', gap: 8, marginBottom: 8 }}>
          {UNIT_SUGGESTIONS.map((u) => (
            <button
              key={u}
              type="button"
              className={`sb-chip${unit === u ? ' selected' : ''}`}
              onClick={() => setUnit(u)}
            >
              {u}
            </button>
          ))}
        </div>
        <input
          className="input"
          value={unit}
          onChange={(e) => setUnit(e.target.value)}
          maxLength={20}
          placeholder="Hoặc nhập đơn vị khác…"
        />
      </div>
      {!ingredient && (
        <div className="field">
          <label>Tồn đầu</label>
          <input
            className="input"
            inputMode="decimal"
            value={stock}
            onChange={(e) => setStock(e.target.value)}
            placeholder="0"
          />
        </div>
      )}
      <div className="field">
        <label>Tồn tối thiểu (cảnh báo sắp hết)</label>
        <input
          className="input"
          inputMode="decimal"
          value={minStock}
          onChange={(e) => setMinStock(e.target.value)}
          placeholder="0"
        />
      </div>
      <div className="field">
        <label>Giá vốn / đơn vị (VND, tham khảo)</label>
        <input
          className="input"
          inputMode="numeric"
          value={cost}
          onChange={(e) => setCost(e.target.value)}
          placeholder="0"
        />
      </div>
      {ingredient && (
        <div className="row" style={{ marginBottom: 16 }}>
          <span className="grow" style={{ fontWeight: 600, fontSize: 15 }}>Đang dùng</span>
          <label className="switch" aria-label="Đang dùng">
            <input type="checkbox" checked={active} onChange={(e) => setActive(e.target.checked)} />
            <span className="track" />
          </label>
        </div>
      )}
      {ingredient &&
        (confirmDel ? (
          <div className="row" style={{ gap: 8 }}>
            <button type="button" className="btn grow" style={{ background: 'var(--red)', color: '#fff' }} disabled={busy} onClick={remove}>
              Chắc chắn xóa
            </button>
            <button type="button" className="btn btn-outline grow" onClick={() => setConfirmDel(false)}>
              Hủy
            </button>
          </div>
        ) : (
          <button
            type="button"
            className="btn btn-ghost btn-block"
            style={{ color: 'var(--red)' }}
            onClick={() => setConfirmDel(true)}
          >
            Xóa nguyên liệu
          </button>
        ))}
    </Sheet>
  );
}

function AdjustSheet({
  ingredient,
  onClose,
  onDone,
}: {
  ingredient: Ingredient;
  onClose: () => void;
  onDone: () => void;
}) {
  const toast = useToast();
  const [mode, setMode] = useState<'in' | 'out'>('in');
  const [qty, setQty] = useState('');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    const v = parseFloat(String(qty).replace(',', '.'));
    if (!Number.isFinite(v) || v <= 0) {
      toast.show('Nhập số lượng hợp lệ');
      return;
    }
    setBusy(true);
    try {
      const updated = await adjustStock(ingredient.id, mode === 'in' ? v : -v, note.trim() || null);
      toast.show(
        mode === 'in'
          ? `Đã nhập ${formatQty(v)} ${ingredient.unit} — tồn ${formatQty(updated.stock)}`
          : `Đã xuất ${formatQty(v)} ${ingredient.unit} — tồn ${formatQty(updated.stock)}`,
      );
      onDone();
    } catch (e) {
      toast.show(e instanceof DbError ? e.message : 'Thao tác thất bại');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet
      title={`${ingredient.name} (tồn ${formatQty(ingredient.stock)} ${ingredient.unit})`}
      onClose={onClose}
      footer={
        <button
          className={`btn btn-block btn-lg${mode === 'out' ? ' sb-btn-orange' : ''}`}
          disabled={busy}
          onClick={submit}
        >
          {busy ? 'Đang lưu…' : mode === 'in' ? 'Nhập kho' : 'Xuất kho'}
        </button>
      }
    >
      <div className="row" style={{ gap: 8, marginBottom: 16 }}>
        <button
          type="button"
          className={`sb-chip grow${mode === 'in' ? ' selected' : ''}`}
          onClick={() => setMode('in')}
        >
          ↓ Nhập kho
        </button>
        <button
          type="button"
          className={`sb-chip grow${mode === 'out' ? ' selected' : ''}`}
          onClick={() => setMode('out')}
        >
          ↑ Xuất kho
        </button>
      </div>
      <div className="field">
        <label>Số lượng ({ingredient.unit})</label>
        <input
          className="sb-money-input"
          inputMode="decimal"
          placeholder="0"
          value={qty}
          onChange={(e) => setQty(e.target.value)}
          autoFocus
        />
      </div>
      <div className="field">
        <label>Ghi chú (không bắt buộc)</label>
        <input
          className="input"
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="VD: nhập hàng sáng…"
        />
      </div>
    </Sheet>
  );
}
