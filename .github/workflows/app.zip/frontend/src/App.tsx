import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import type { ReactNode } from 'react';
import { useAuth } from './lib/auth';
import { Layout } from './components/Layout';
import { Login } from './pages/Login';
import { Setup } from './pages/Setup';
import { POS } from './pages/POS';
import { KDS } from './pages/KDS';
import { Menu } from './pages/Menu';
import { Customers } from './pages/Customers';
import { Reports } from './pages/Reports';
import { DebtBook } from './pages/DebtBook';
import { Cashbook } from './pages/Cashbook';
import { Settings } from './pages/Settings';

function RequireAuth({ children }: { children: ReactNode }) {
  const { user, pendingUid } = useAuth();
  const loc = useLocation();
  // Đã đăng nhập Auth nhưng chưa có hồ sơ Firestore → đưa sang màn hình thiết lập
  if (!user && pendingUid) return <Navigate to="/setup" replace />;
  if (!user) return <Navigate to="/login" replace state={{ from: loc.pathname }} />;
  return <>{children}</>;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/setup" element={<Setup />} />
      <Route
        path="/"
        element={
          <RequireAuth>
            <Layout />
          </RequireAuth>
        }
      >
        <Route index element={<Navigate to="/reports" replace />} />
        <Route path="pos" element={<POS />} />
        <Route path="kds" element={<KDS />} />
        <Route path="menu" element={<Menu />} />
        <Route path="customers" element={<Customers />} />
        <Route path="debt" element={<DebtBook />} />
        <Route path="cashbook" element={<Cashbook />} />
        <Route path="reports" element={<Reports />} />
        <Route path="settings" element={<Settings />} />
        <Route path="*" element={<Navigate to="/reports" replace />} />
      </Route>
    </Routes>
  );
}
