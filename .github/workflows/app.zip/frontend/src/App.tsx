import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import type { ReactNode } from 'react';
import { useAuth } from './lib/auth';
import { Layout } from './components/Layout';
import { Login } from './pages/Login';
import { Setup } from './pages/Setup';
import { POS } from './pages/POS';
import { KDS } from './pages/KDS';
import { Menu } from './pages/Menu';
import { Customers } from './pages/Customers';
import { Reports } from './pages/Reports';
import { DebtBook } from './pages/DebtBook';
import { SoQuy } from './pages/SoQuy';
import { Orders } from './pages/Orders';
import { Inventory } from './pages/Inventory';
import { Settings } from './pages/Settings';
import { AuditLogPage } from './pages/AuditLog';
import { OnlineOrderPage } from './pages/OnlineOrder';
import { Purchase } from './pages/Purchase';

function RequireAuth({ children }: { children: ReactNode }) {
  const { user, pendingUid } = useAuth();
  const loc = useLocation();
  // Đã đăng nhập Auth nhưng chưa có hồ sơ Firestore → đưa sang màn hình thiết lập
  if (!user && pendingUid) return <Navigate to="/setup" replace />;
  if (!user) return <Navigate to="/login" replace state={{ from: loc.pathname }} />;
  return <>{children}</>;
}

/** Trang mặc định sau đăng nhập theo vai trò (nhân viên bán hàng vào thẳng POS). */
function HomeRedirect() {
  const { can } = useAuth();
  return <Navigate to={can('reports') ? '/reports' : '/pos'} replace />;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/setup" element={<Setup />} />
      <Route path="/dat-hang" element={<OnlineOrderPage />} />
      <Route
        path="/"
        element={
          <RequireAuth>
            <Layout />
          </RequireAuth>
        }
      >
        <Route index element={<HomeRedirect />} />
        <Route path="pos" element={<POS />} />
        <Route path="kds" element={<KDS />} />
        <Route path="menu" element={<Menu />} />
        <Route path="customers" element={<Customers />} />
        <Route path="debt" element={<DebtBook />} />
        <Route path="so-quy" element={<SoQuy />} />
        <Route path="orders" element={<Orders />} />
        <Route path="reports" element={<Reports />} />
        <Route path="inventory" element={<Inventory />} />
        <Route path="settings" element={<Settings />} />
        <Route path="nhat-ky" element={<AuditLogPage />} />
        <Route path="nhap-hang" element={<Purchase />} />
        <Route path="*" element={<HomeRedirect />} />
      </Route>
    </Routes>
  );
}
