import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { VitePWA } from 'vite-plugin-pwa'

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      includeAssets: ['coffee-cup.svg'],
      manifest: {
        name: 'Beesy POS',
        short_name: 'Beesy POS',
        description: 'Phần mềm bán hàng cho quán Beesy Coffee & Tea',
        lang: 'vi',
        start_url: '/',
        display: 'standalone',
        background_color: '#fff7ed',
        theme_color: '#b45309',
        icons: [
          {
            src: 'coffee-cup.svg',
            sizes: 'any',
            type: 'image/svg+xml',
            purpose: 'any maskable',
          },
        ],
      },
      workbox: {
        navigateFallback: 'index.html',
        runtimeCaching: [
          {
            urlPattern: ({ request }) => request.destination === 'image',
            handler: 'CacheFirst',
            options: {
              cacheName: 'beesy-images',
              expiration: { maxEntries: 100, maxAgeSeconds: 7 * 24 * 3600 },
            },
          },
        ],
      },
    }),
  ],
  server: {
    port: 5173,
  },
})
