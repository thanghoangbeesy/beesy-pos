import { useCallback, useEffect, useMemo, useState } from 'react';
import { DbError, downloadFile, exportOrdersCsv, getAllowedWarehouses, getRangeReport } from '../lib/db';
import {
  addDaysVN,
  formatVND,
  startOfMonthVN,
  startOfWeekVN,
  todayVN,
} from '../lib/format';
import { useToast } from '../components/Toast';
import { useAuth } from '../lib/auth';
import { TIcon } from '../components/TIcon';
import type { DailyReport, Warehouse } from '../lib/types';

type PresetKey = 'today' | 'yesterday' | 'thisWeek' | 'lastWeek' | 'thisMonth' | 'lastMonth' | 'custom';
type TabKey = 'products' | 'hours' | 'promo' | 'export';

const PRESETS: { key: PresetKey; label: string }[] = [
  { key: 'today', label: 'Hôm nay' },
  { key: 'yesterday', label: 'Hôm qua' },
  { key: 'thisWeek', label: 'Tuần này' },
  { key: 'lastWeek', label: 'Tuần trước' },
  { key: 'thisMonth', label: 'Tháng này' },
  { key: 'lastMonth', label: 'Tháng trước' },
  { key: 'custom', label: 'Tùy chọn' },
];

function presetRange(key: PresetKey, cs: string, ce: string): [string, string] {
  const t = todayVN();
  switch (key) {
    case 'today': return [t, t];
    case 'yesterday': { const y = addDaysVN(t, -1); return [y, y]; }
    case 'thisWeek': return [startOfWeekVN(t), t];
    case 'lastWeek': {
      const m = startOfWeekVN(t);
      const ml = addDaysVN(m, -7);
      return [ml, addDaysVN(ml, 6)];
    }
    case 'thisMonth': return [startOfMonthVN(t), t];
    case 'lastMonth': {
      const f = startOfMonthVN(t);
      const l = addDaysVN(f, -1);
      return [startOfMonthVN(l), l];
    }
    case 'custom': return [cs, ce];
  }
}

const TABS: { key: TabKey; label: string; icon: string }[] = [
  { key: 'products', label: 'Món bán', icon: '🧾' },
  { key: 'hours', label: 'Theo giờ', icon: '🕐' },
  { key: 'promo', label: 'Khuyến mại', icon: '🎁' },
  { key: 'export', label: 'Xuất file', icon: '⬇' },
];

export function BaoCao() {
  const toast = useToast();
  const { can } = useAuth();
  const [tab, setTab] = useState<TabKey>('products');
  const [preset, setPreset] = useState<PresetKey>('today');
  const [customStart, setCustomStart] = useState(todayVN());
  const [customEnd, setCustomEnd] = useState(todayVN());
  const [report, setReport] = useState<DailyReport | null>(null);
  const [busy, setBusy] = useState(false);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [isOwner, setIsOwner] = useState(false);
  const [whFilter, setWhFilter] = useState('all');
  const [sortKey, setSortKey] = useState<'qty' | 'revenue' | 'profit'>('revenue');
  const [sortDir, setSortDir] = useState<'desc' | 'asc'>('desc');
  const [exportBusy, setExportBusy] = useState(false);

  const scopeIds = whFilter === 'all' ? (isOwner ? undefined : warehouses.map((w) => w.id)) : [whFilter];

  const load = useCallback(async (key: PresetKey, cs: string, ce: string, ids?: string[]) => {
    const [s, e] = presetRange(key, cs, ce);
    if (!s || !e || s > e) { toast.show('Khoảng ngày không hợp lệ'); return; }
    setBusy(true);
    try {
      const data = await getRangeReport(s, e, ids);
      setReport(data);
    } catch (err) {
      toast.show(err instanceof DbError ? err.message : 'Không tải được báo cáo');
    } finally {
      setBusy(false);
    }
  }, [toast]);

  useEffect(() => {
    getAllowedWarehouses()
      .then(({ warehouses: ws, isOwner: ow }) => {
        setWarehouses(ws);
        setIsOwner(ow);
        const ids = ow ? undefined : ws.map((w) => w.id);
        void load('today', todayVN(), todayVN(), ids);
      })
      .catch(() => { void load('today', todayVN(), todayVN()); });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const pickPreset = (key: PresetKey) => {
    setPreset(key);
    void load(key, customStart, customEnd, scopeIds);
  };

  const changeWh = (id: string) => {
    setWhFilter(id);
    const ids = id === 'all' ? (isOwner ? undefined : warehouses.map((w) => w.id)) : [id];
    void load(preset, customStart, customEnd, ids);
  };

  const sortedProducts = useMemo(() => {
    const arr = [...(report?.top_products ?? [])];
    arr.sort((a, b) => {
      const d = a[sortKey] - b[sortKey];
      return sortDir === 'desc' ? -d : d;
    });
    return arr;
  }, [report, sortKey, sortDir]);

  const maxHour = Math.max(1, ...(report?.by_hour.map((h) => h.revenue) ?? [1]));
  const bestHour = useMemo(() => {
    if (!report) return null;
    return [...report.by_hour].sort((a, b) => b.revenue - a.revenue)[0];
  }, [report]);

  const doExportExcel = async () => {
    setExportBusy(true);
    try {
      const [s, e] = presetRange(preset, customStart, customEnd);
      const csv = await exportOrdersCsv(s, e, scopeIds);
      downloadFile(`beesy-bao-cao_${s}_${e}.csv`, csv, 'text/csv');
      toast.show('Đã xuất file Excel');
    } catch (err) {
      toast.show(err instanceof DbError ? err.message : 'Xuất file thất bại');
    } finally {
      setExportBusy(false);
    }
  };

  if (!can('reports')) {
    return <div className="page"><div className="card">🔒 Chỉ Quản lý trở lên mới được xem báo cáo.</div></div>;
  }

  return (
    <div className="page bc-page">
      <div className="bc-header">
        <h1>Báo cáo chi tiết</h1>
        <select value={preset} onChange={(e) => pickPreset(e.target.value as PresetKey)} className="input" aria-label="Chọn kỳ">
          {PRESETS.map((p) => <option key={p.key} value={p.key}>{p.label}</option>)}
        </select>
      </div>

      {preset === 'custom' && (
        <div className="row" style={{ gap: 8, marginBottom: 12, alignItems: 'center' }}>
          <input type="date" className="input" value={customStart} max={todayVN()} onChange={(e) => setCustomStart(e.target.value)} />
          <span>→</span>
          <input type="date" className="input" value={customEnd} max={todayVN()} onChange={(e) => setCustomEnd(e.target.value)} />
          <button className="btn btn-sm" onClick={() => pickPreset('custom')}>Xem</button>
        </div>
      )}

      {warehouses.length > 1 && (
        <div className="row" style={{ gap: 8, marginBottom: 12, flexWrap: 'wrap' }}>
          <button className={`sb-chip${whFilter === 'all' ? ' selected' : ''}`} onClick={() => changeWh('all')}>Mọi kho</button>
          {warehouses.map((w) => (
            <button key={w.id} className={`sb-chip${whFilter === w.id ? ' selected' : ''}`} onClick={() => changeWh(w.id)}>{w.name}</button>
          ))}
        </div>
      )}

      {/* Tabs */}
      <div className="bc-tabs">
        {TABS.map((t) => (
          <button key={t.key} className={`bc-tab${tab === t.key ? ' active' : ''}`} onClick={() => setTab(t.key)}>
            <TIcon emoji={t.icon} size={18} />
            <span>{t.label}</span>
          </button>
        ))}
      </div>

      {busy && !report ? (
        <p className="muted">Đang tải…</p>
      ) : !report ? (
        <p className="muted">Không có dữ liệu</p>
      ) : (
        <>
          {/* Tổng hợp */}
          <div className="bc-summary">
            <div><span>Doanh thu</span><b>{formatVND(report.revenue)}</b></div>
            <div><span>Giá vốn</span><b>{formatVND(report.cost)}</b></div>
            <div><span>Lợi nhuận</span><b className="text-green">{formatVND(report.profit)}</b></div>
            <div><span>Đơn bán</span><b>{report.order_count}</b></div>
            <div><span>Đơn hủy</span><b>{report.cancelled_count}</b></div>
            <div><span>TB/đơn</span><b>{formatVND(Math.round(report.avg_order))}</b></div>
          </div>

          {tab === 'products' && (
            <div className="card">
              <div className="row" style={{ gap: 8, marginBottom: 10 }}>
                {([['qty', 'Số lượng'], ['revenue', 'Doanh thu'], ['profit', 'Lợi nhuận']] as const).map(([k, label]) => (
                  <button key={k} className={`sb-chip${sortKey === k ? ' selected' : ''}`} onClick={() => setSortKey(k)}>{label}</button>
                ))}
                <button className="sb-chip" onClick={() => setSortDir((d) => d === 'desc' ? 'asc' : 'desc')}>
                  {sortDir === 'desc' ? '↓ Giảm dần' : '↑ Tăng dần'}
                </button>
              </div>
              <table className="pc-table">
                <thead>
                  <tr><th>#</th><th>Món</th><th className="r">SL</th><th className="r">Doanh thu</th><th className="r">Giá vốn</th><th className="r">Lợi nhuận</th></tr>
                </thead>
                <tbody>
                  {sortedProducts.map((p, i) => (
                    <tr key={p.product_id}>
                      <td>{i + 1}</td>
                      <td><b>{p.name}</b></td>
                      <td className="r">{p.qty}</td>
                      <td className="r">{formatVND(p.revenue)}</td>
                      <td className="r">{formatVND(p.cost)}</td>
                      <td className="r" style={{ color: '#16A34A', fontWeight: 600 }}>{formatVND(p.profit)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {sortedProducts.length === 0 && <p className="muted small">Chưa có dữ liệu</p>}
            </div>
          )}

          {tab === 'hours' && (
            <div className="card">
              <h3 style={{ margin: '0 0 12px' }}>Doanh thu theo giờ</h3>
              {bestHour && bestHour.revenue > 0 && (
                <p className="small" style={{ marginBottom: 12 }}>
                  Giờ bán tốt nhất: <b>{bestHour.hour}h</b> — {formatVND(bestHour.revenue)} ({bestHour.count} đơn)
                </p>
              )}
              <div className="hour-chart">
                {report.by_hour.map((h) => (
                  <div className="hour-bar" key={h.hour} title={`${h.hour}h: ${formatVND(h.revenue)} (${h.count} đơn)`}>
                    <div className="bar" style={{ height: `${Math.round((h.revenue / maxHour) * 120)}px` }} />
                    <div className="h">{h.hour}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {tab === 'promo' && (
            <div className="card">
              <h3 style={{ margin: '0 0 12px' }}>Khuyến mại</h3>
              <div className="bc-summary" style={{ marginBottom: 0 }}>
                <div><span>Đơn KM</span><b>{report.promo_count}</b></div>
                <div><span>Tiền giảm</span><b>{formatVND(report.promo_discount)}</b></div>
                <div><span>Tỉ lệ</span><b>{report.order_count > 0 ? Math.round((report.promo_count / report.order_count) * 100) : 0}%</b></div>
              </div>
              <p className="muted small" style={{ marginTop: 12 }}>
                Chi tiết từng chương trình (giờ vàng, voucher, combo) sẽ có ở bản sau.
              </p>
            </div>
          )}

          {tab === 'export' && (
            <div className="card">
              <h3 style={{ margin: '0 0 12px' }}>Xuất báo cáo</h3>
              <p className="small muted" style={{ marginBottom: 12 }}>
                Xuất chi tiết đơn hàng trong kỳ ra file Excel (CSV) để lưu, in và xem.
              </p>
              <button className="btn" disabled={exportBusy} onClick={doExportExcel}>
                {exportBusy ? 'Đang xuất…' : <><TIcon emoji="⬇" size={14} /> Xuất Excel</>}
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
