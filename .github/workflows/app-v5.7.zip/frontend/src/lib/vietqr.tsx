import { useEffect, useState } from 'react';
import { buildVietQRUrl } from './format';

// ============================================================================
// VietQR TU SINH ngay tren may - khong dung anh tu img.vietqr.io nua.
//
// Ly do (phat hien 22/10/2026, don A344): img.vietqr.io da doi dinh dang -
// link .png tra ve 301 sang anh SVG. Trinh duyet hien SVG binh thuong nen
// nhin tren man hinh tuong on, nhung thu vien chup bill (html2canvas) KHONG
// ve duoc anh SVG nap tu link ngoai -> anh bill gui Zalo trong dung cho QR.
// Tu sinh QR tu chuoi EMV/NAPAS thi anh la PNG data URL: hien, in va chup
// deu tot, lai chay ca khi mat mang.
//
// Chuoi EMV da duoc kiem chung: giai ma QR that cua vietqr.io cho don A344
// (MoMo 971025, STK PSP2625815400000051, 15.000d) cho ra chuoi TRUNG KHOP
// 100% voi chuoi module nay sinh, ke ca 4 ky tu CRC cuoi.
// ============================================================================

function tlv(id: string, value: string): string {
  return `${id}${String(value.length).padStart(2, '0')}${value}`;
}

/** CRC16-CCITT (poly 0x1021, gia tri dau 0xFFFF) - chuan EMVCo. */
export function crc16Emv(str: string): string {
  let crc = 0xffff;
  for (let i = 0; i < str.length; i++) {
    crc ^= str.charCodeAt(i) << 8;
    for (let j = 0; j < 8; j++) {
      crc = crc & 0x8000 ? ((crc << 1) ^ 0x1021) & 0xffff : (crc << 1) & 0xffff;
    }
  }
  return crc.toString(16).toUpperCase().padStart(4, '0');
}

/**
 * Chuoi thanh toan VietQR (NAPAS 247 - chuyen tien toi tai khoan/vi):
 * 38 = thong tin nguoi thu (GUID A000000727 + BIN + so tai khoan + QRIBFTTA),
 * 53 = VND (704), 54 = so tien, 58 = VN, 62/08 = noi dung chuyen khoan.
 */
export function buildVietQRPayload(
  bankBin: string,
  account: string,
  amount: number,
  addInfo: string,
): string {
  const beneficiary = tlv('00', bankBin) + tlv('01', account);
  const merchant = tlv('00', 'A000000727') + tlv('01', beneficiary) + tlv('02', 'QRIBFTTA');
  let p = tlv('00', '01') + tlv('01', '12') + tlv('38', merchant) + tlv('53', '704');
  if (amount > 0) p += tlv('54', String(Math.round(amount)));
  p += tlv('58', 'VN');
  if (addInfo) p += tlv('62', tlv('08', addInfo));
  p += '6304';
  return p + crc16Emv(p);
}

/**
 * Sinh anh QR dang PNG data URL tu chuoi VietQR.
 * Loi sinh (rat hiem) thi du phong bang link anh vietqr.io nhu ban cu.
 */
export async function getVietQRImage(
  bankBin: string,
  account: string,
  accountName: string,
  amount: number,
  addInfo: string,
): Promise<string> {
  try {
    const QRCode = (await import('qrcode')).default;
    const payload = buildVietQRPayload(bankBin, account, amount, addInfo);
    return await QRCode.toDataURL(payload, {
      width: 360,
      margin: 1,
      errorCorrectionLevel: 'M',
    });
  } catch {
    return buildVietQRUrl(bankBin, account, accountName, amount, addInfo);
  }
}

/** Hook: tra ve data URL cua ma QR (null khi chua sinh xong hoac thieu thong tin). */
export function useVietQRImage(
  bankBin?: string | null,
  account?: string | null,
  accountName?: string | null,
  amount?: number | null,
  addInfo?: string | null,
): string | null {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => {
    let alive = true;
    if (!bankBin || !account || !amount || amount <= 0) {
      setUrl(null);
      return;
    }
    void (async () => {
      const u = await getVietQRImage(bankBin, account, accountName ?? '', amount, addInfo ?? '');
      if (alive) setUrl(u);
    })();
    return () => {
      alive = false;
    };
  }, [bankBin, account, accountName, amount, addInfo]);
  return url;
}

/** Anh QR tu sinh - dung o man hinh thanh toan va trang dat hang online. */
export function VietQRImg({
  bankBin,
  account,
  accountName,
  amount,
  addInfo,
  alt,
  style,
  className,
}: {
  bankBin: string;
  account: string;
  accountName?: string;
  amount: number;
  addInfo: string;
  alt: string;
  style?: React.CSSProperties;
  className?: string;
}) {
  const url = useVietQRImage(bankBin, account, accountName, amount, addInfo);
  if (!url) return null;
  return <img src={url} alt={alt} style={style} className={className} />;
}
