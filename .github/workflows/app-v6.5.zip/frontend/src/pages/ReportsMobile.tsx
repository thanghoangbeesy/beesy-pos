import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { DbError, getAllowedWarehouses, getDailyBreakdown, getDailyExpenses, getHourlyBreakdown, getRangeReport } from '../lib/db';
import {
  addDaysVN,
  endOfMonthVN,
  formatDMY,
  formatVND,
  startOfMonthVN,
  startOfWeekVN,
  todayVN,
} from '../lib/format';
import { useToast } from '../components/Toast';
import { LowStockPanel, useStockOverview } from '../components/StockOverview';
import { DayCloseSheet } from './DayCloseSheet';
import { useAuth } from '../lib/auth';
import { TIcon } from '../components/TIcon';
import type { DailyReport, Warehouse } from '../lib/types';

type PresetKey = 'today' | 'yesterday' | 'thisWeek' | 'lastWeek' | 'thisMonth' | 'lastMonth';

const PRESETS: { key: PresetKey; label: string }[] = [
  { key: 'today', label: 'Hôm nay' },
  { key: 'yesterday', label: 'Hôm qua' },
  { key: 'thisWeek', label: 'Tuần này' },
  { key: 'lastWeek', label: 'Tuần trước' },
  { key: 'thisMonth', label: 'Tháng này' },
  { key: 'lastMonth', label: 'Tháng trước' },
];

function presetRange(key: PresetKey): [string, string] {
  const t = todayVN();
  switch (key) {
    case 'today': return [t, t];
    case 'yesterday': { const y = addDaysVN(t, -1); return [y, y]; }
    case 'thisWeek': return [startOfWeekVN(t), t];
    case 'lastWeek': {
      const mondayThis = startOfWeekVN(t);
      const mondayLast = addDaysVN(mondayThis, -7);
      return [mondayLast, addDaysVN(mondayLast, 6)];
    }
    case 'thisMonth': return [startOfMonthVN(t), t];
    case 'lastMonth': {
      const firstThisMonth = startOfMonthVN(t);
      const lastDayPrev = addDaysVN(firstThisMonth, -1);
      return [startOfMonthVN(lastDayPrev), lastDayPrev];
    }
  }
}

/** Kỳ trước tương ứng để so sánh. */
function prevRange(key: PresetKey): [string, string] {
  const t = todayVN();
  switch (key) {
    case 'today': { const y = addDaysVN(t, -1); return [y, y]; }
    case 'yesterday': { const y = addDaysVN(t, -2); return [y, y]; }
    case 'thisWeek': {
      const mondayThis = startOfWeekVN(t);
      const mondayLast = addDaysVN(mondayThis, -7);
      return [mondayLast, addDaysVN(mondayLast, 6)];
    }
    case 'lastWeek': {
      const mondayThis = startOfWeekVN(t);
      const mondayLast2 = addDaysVN(mondayThis, -14);
      return [mondayLast2, addDaysVN(mondayLast2, 6)];
    }
    case 'thisMonth': {
      const firstThisMonth = startOfMonthVN(t);
      const lastDayPrev = addDaysVN(firstThisMonth, -1);
      return [startOfMonthVN(lastDayPrev), lastDayPrev];
    }
    case 'lastMonth': {
      const firstThisMonth = startOfMonthVN(t);
      const lastDayPrev = addDaysVN(firstThisMonth, -1);
      const firstPrev = startOfMonthVN(lastDayPrev);
      const lastDayPrev2 = addDaysVN(firstPrev, -1);
      return [startOfMonthVN(lastDayPrev2), lastDayPrev2];
    }
  }
}

/** Nhãn kỳ này / kỳ trước cho tiêu đề biểu đồ so sánh (kỳ trước viết thường
 *  để ghép câu "Kỳ này so với kỳ trước", ví dụ "Hôm nay so với hôm qua"). */
function chartLabels(key: PresetKey): { cur: string; prev: string } {
  switch (key) {
    case 'today': return { cur: 'Hôm nay', prev: 'hôm qua' };
    case 'yesterday': return { cur: 'Hôm qua', prev: 'hôm kia' };
    case 'thisWeek': return { cur: 'Tuần này', prev: 'tuần trước' };
    case 'lastWeek': return { cur: 'Tuần trước', prev: 'tuần trước nữa' };
    case 'thisMonth': return { cur: 'Tháng này', prev: 'tháng trước' };
    case 'lastMonth': return { cur: 'Tháng trước', prev: 'tháng trước nữa' };
  }
}

function cap(s: string): string {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

type LineKey = 'revCur' | 'revPrev' | 'profCur' | 'profPrev' | 'expCur' | 'expPrev';

/** 6 duong bieu do: mau theo loai, net theo ky (ky nay net lien dam,
 *  ky truoc net dut nhat cung mau). */
const LINES: { key: LineKey; label: string; color: string; dash: boolean; period: 'cur' | 'prev' }[] = [
  { key: 'revCur', label: 'Doanh thu', color: '#00B14F', dash: false, period: 'cur' },
  { key: 'revPrev', label: 'Doanh thu', color: '#86EFAC', dash: true, period: 'prev' },
  { key: 'profCur', label: 'Loi nhuan', color: '#2563EB', dash: false, period: 'cur' },
  { key: 'profPrev', label: 'Loi nhuan', color: '#93C5FD', dash: true, period: 'prev' },
  { key: 'expCur', label: 'Chi phi', color: '#DC2626', dash: false, period: 'cur' },
  { key: 'expPrev', label: 'Chi phi', color: '#FCA5A5', dash: true, period: 'prev' },
];

/** 1 điểm trên biểu đồ so sánh: nhãn trục + chi tiết tooltip + 2 cặp số.
 *  Chi phí = chi phí vận hành (tách riêng, không phải giá vốn). */
interface ChartPoint {
  key: string;
  label: string;
  detail: string;
  thisRevenue: number;
  thisProfit: number;
  thisExpense: number;
  lastRevenue: number;
  lastProfit: number;
  lastExpense: number;
}

type ChartMode = 'hour' | 'week' | 'month';

function pctChange(cur: number, prev: number): number | null {
  if (prev === 0) return cur > 0 ? 100 : null;
  return ((cur - prev) / prev) * 100;
}

export function ReportsMobile() {
  const toast = useToast();
  const { can } = useAuth();
  const navigate = useNavigate();
  const [preset, setPreset] = useState<PresetKey>('today');
  const [report, setReport] = useState<DailyReport | null>(null);
  const [prevReport, setPrevReport] = useState<DailyReport | null>(null);
  const [chartData, setChartData] = useState<ChartPoint[]>([]);
  const [chartMeta, setChartMeta] = useState<{ mode: ChartMode; cur: string; prev: string }>({ mode: 'hour', cur: 'Hôm nay', prev: 'hôm qua' });
  const [hiddenLines, setHiddenLines] = useState<Set<LineKey>>(new Set());
  const [selectedIdx, setSelectedIdx] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [isOwner, setIsOwner] = useState(false);
  const [dayCloseOpen, setDayCloseOpen] = useState(false);
  const { low } = useStockOverview(warehouses);
  const [topSort, setTopSort] = useState<'qty' | 'revenue' | 'profit'>('qty');
  const [topDir, setTopDir] = useState<'desc' | 'asc'>('desc');

  const load = useCallback(async (key: PresetKey, ids?: string[]) => {
    setBusy(true);
    try {
      const [s, e] = presetRange(key);
      const [ps, pe] = prevRange(key);
      const t = todayVN();
      const [cur, prev] = await Promise.all([
        getRangeReport(s, e, ids),
        getRangeReport(ps, pe, ids),
      ]);
      setReport(cur);
      setPrevReport(prev);
      // Biểu đồ so sánh chạy theo kỳ đã chọn (v6.4): kỳ 1 ngày -> theo giờ
      // (24 giờ, kỳ trước là ngày liền trước); kỳ nhiều ngày -> theo ngày
      // (tuần: T2-CN, kỳ trước là tuần liền trước; tháng: ngày 1-31, kỳ trước
      // là tháng liền trước, ngày không có trong tháng trước tính 0).
      const meta = chartLabels(key);
      if (key === 'today' || key === 'yesterday') {
        const [day] = presetRange(key);
        const [prevDay] = prevRange(key);
        const hours = await getHourlyBreakdown(day, prevDay, ids);
        setChartData(hours.map((h) => ({
          key: String(h.hour),
          label: String(h.hour),
          detail: `${h.hour}h`,
          thisRevenue: h.curRevenue,
          thisProfit: h.curProfit,
          thisExpense: h.curExpense,
          lastRevenue: h.prevRevenue,
          lastProfit: h.prevProfit,
          lastExpense: h.prevExpense,
        })));
        setChartMeta({ mode: 'hour', ...meta });
      } else if (key === 'thisWeek' || key === 'lastWeek') {
        const mondayThis = startOfWeekVN(t);
        const curMon = key === 'thisWeek' ? mondayThis : addDaysVN(mondayThis, -7);
        const prevMon = addDaysVN(curMon, -7);
        const dayLabels = ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'];
        const [curDays, prevDays, curExp, prevExp] = await Promise.all([
          getDailyBreakdown(curMon, addDaysVN(curMon, 6), ids),
          getDailyBreakdown(prevMon, addDaysVN(prevMon, 6), ids),
          getDailyExpenses(curMon, addDaysVN(curMon, 6), ids),
          getDailyExpenses(prevMon, addDaysVN(prevMon, 6), ids),
        ]);
        setChartData(dayLabels.map((dayLabel, i) => ({
          key: addDaysVN(curMon, i),
          label: dayLabel,
          detail: `${dayLabel} ${formatDMY(addDaysVN(curMon, i))}`,
          thisRevenue: curDays[i]?.revenue ?? 0,
          thisProfit: curDays[i]?.profit ?? 0,
          thisExpense: curExp[i]?.expense ?? 0,
          lastRevenue: prevDays[i]?.revenue ?? 0,
          lastProfit: prevDays[i]?.profit ?? 0,
          lastExpense: prevExp[i]?.expense ?? 0,
        })));
        setChartMeta({ mode: 'week', ...meta });
      } else {
        const firstThisMonth = startOfMonthVN(t);
        const curFirst = key === 'thisMonth' ? firstThisMonth : startOfMonthVN(addDaysVN(firstThisMonth, -1));
        const curLast = endOfMonthVN(curFirst);
        const prevFirst = startOfMonthVN(addDaysVN(curFirst, -1));
        const prevLast = addDaysVN(curFirst, -1);
        const [curDays, prevDays, curExp, prevExp] = await Promise.all([
          getDailyBreakdown(curFirst, curLast, ids),
          getDailyBreakdown(prevFirst, prevLast, ids),
          getDailyExpenses(curFirst, curLast, ids),
          getDailyExpenses(prevFirst, prevLast, ids),
        ]);
        setChartData(curDays.map((d, i) => ({
          key: d.date,
          label: String(i + 1),
          detail: formatDMY(d.date),
          thisRevenue: d.revenue,
          thisProfit: d.profit,
          thisExpense: curExp[i]?.expense ?? 0,
          lastRevenue: prevDays[i]?.revenue ?? 0,
          lastProfit: prevDays[i]?.profit ?? 0,
          lastExpense: prevExp[i]?.expense ?? 0,
        })));
        setChartMeta({ mode: 'month', ...meta });
      }
    } catch (err) {
      toast.show(err instanceof DbError ? err.message : 'Không tải được báo cáo');
    } finally {
      setBusy(false);
    }
  }, [toast]);

  useEffect(() => {
    getAllowedWarehouses()
      .then(({ warehouses: ws, isOwner: ow }) => {
        setWarehouses(ws);
        setIsOwner(ow);
        const ids = ow ? undefined : ws.map((w) => w.id);
        void load('today', ids);
      })
      .catch(() => { void load('today'); });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const pickPreset = (key: PresetKey) => {
    setPreset(key);
    setSelectedIdx(null);
    const ids = isOwner ? undefined : warehouses.map((w) => w.id);
    void load(key, ids);
  };

  const toggleLine = (key: LineKey) => {
    setHiddenLines((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  const kpis = useMemo(() => {
    if (!report) return [];
    const p = prevReport;
    return [
      {
        label: 'Doanh thu',
        value: formatVND(report.revenue),
        icon: '💰',
        change: p ? pctChange(report.revenue, p.revenue) : null,
        changeLabel: 'so với kỳ trước',
      },
      {
        label: 'Lợi nhuận',
        value: formatVND(report.profit),
        icon: '📈',
        change: p ? pctChange(report.profit, p.profit) : null,
        changeLabel: 'so với kỳ trước',
      },
      {
        label: 'Số đơn',
        value: String(report.order_count),
        icon: '🧾',
        change: p ? pctChange(report.order_count, p.order_count) : null,
        changeLabel: 'so với kỳ trước',
      },
      {
        label: 'TB/đơn',
        value: formatVND(Math.round(report.avg_order)),
        icon: '🧮',
        change: p ? pctChange(report.avg_order, p.avg_order) : null,
        changeLabel: 'so với kỳ trước',
      },
    ];
  }, [report, prevReport]);


  // Tong 3 loai cua ky nay / ky truoc tren toan bo cac moc dang hien thi.
  const chartTotals = {
    revCur: chartData.reduce((s, d) => s + d.thisRevenue, 0),
    revPrev: chartData.reduce((s, d) => s + d.lastRevenue, 0),
    profCur: chartData.reduce((s, d) => s + d.thisProfit, 0),
    profPrev: chartData.reduce((s, d) => s + d.lastProfit, 0),
    expCur: chartData.reduce((s, d) => s + d.thisExpense, 0),
    expPrev: chartData.reduce((s, d) => s + d.lastExpense, 0),
  };
  const maxPos = Math.max(1, ...chartData.flatMap((d) => [d.thisRevenue, d.lastRevenue, d.thisProfit, d.lastProfit]));
  const maxNeg = Math.max(1, ...chartData.flatMap((d) => [d.thisExpense, d.lastExpense]));

  // Hinh hoc bieu do duong (v6.4): THANG TUYEN TINH DUY NHAT tu -max(chi phi)
  // den +max(doanh thu/loi nhuan), truc 0 o giua, cung ti le px/dong ca 2
  // phia nen chieu cao khong danh lua mat. Chi phi ve voi gia tri am nen
  // luon nam duoi truc 0; doanh thu/loi nhuan luon tren truc 0.
  const svgW = 360;
  const svgH = 220;
  const svgPadT = 14;
  const svgPadB = 20;
  const svgPadX = 8;
  const svgPlotH = svgH - svgPadT - svgPadB;
  const svgStep = chartData.length > 1 ? (svgW - 2 * svgPadX) / (chartData.length - 1) : 0;
  const svgX = (i: number) => chartData.length > 1 ? svgPadX + i * svgStep : svgW / 2;
  const svgY = (v: number) => svgPadT + ((maxPos - v) / (maxPos + maxNeg)) * svgPlotH;
  const svgZeroY = svgY(0);
  const lineSeries = LINES.map((ln) => ({ ...ln, values: chartData.map((d) =>
    ln.key === 'revCur' ? d.thisRevenue : ln.key === 'revPrev' ? d.lastRevenue
    : ln.key === 'profCur' ? d.thisProfit : ln.key === 'profPrev' ? d.lastProfit
    : ln.key === 'expCur' ? -d.thisExpense : -d.lastExpense) }));
  const linePath = (vals: number[]) => vals.map((v, i) => `${i === 0 ? 'M' : 'L'}${svgX(i).toFixed(1)},${svgY(v).toFixed(1)}`).join(' ');
  const showXLabel = (d: ChartPoint, i: number): boolean => {
    if (chartMeta.mode === 'week') return true;
    if (chartMeta.mode === 'hour') return Number(d.label) % 6 === 0;
    const day = i + 1;
    return day === 1 || day % 5 === 0;
  };
  const xLabelText = (d: ChartPoint) => chartMeta.mode === 'hour' ? `${d.label}h` : d.label;
  const sel = selectedIdx !== null ? chartData[selectedIdx] : undefined;
  // Bieu do tach doi (theo yeu cau 27/10/2026): 1 SVG cho ky nay, 1 SVG cho
  // ky truoc, xep doc trong cung 1 card. CA HAI dung CHUNG maxPos/maxNeg
  // (tinh 1 lan tu toan bo chartData ca 2 ky) nen svgY la chung, khong tinh
  // thang rieng tung bieu do; cung chung svgX (thu tu moc chartData) va
  // chung selectedIdx: bam moc o bieu do nao cung dat cung selectedIdx va
  // ca 2 bieu do deu ve vach dut doc tai moc do. An/hien legend chi an
  // duong do, thang do khong doi nen hinh khong nhay.
  const chartSvg = (period: 'cur' | 'prev') => (
    <div>
      <div style={{ fontSize: 13, fontWeight: 700, padding: '6px 8px 0' }}>{period === 'cur' ? chartMeta.cur : cap(chartMeta.prev)}</div>
      <svg width="100%" viewBox={`0 0 ${svgW} ${svgH}`} role="img" aria-label={period === 'cur' ? `Biểu đồ ${chartMeta.cur}` : `Biểu đồ ${cap(chartMeta.prev)}`}>
        {chartData.map((d, idx) => showXLabel(d, idx) && (
          <line key={`g${period}${d.key}`} x1={svgX(idx)} y1={svgPadT} x2={svgX(idx)} y2={svgH - svgPadB} stroke="#E2E8F0" strokeWidth={1} />
        ))}
        <line x1={svgPadX} y1={svgZeroY} x2={svgW - svgPadX} y2={svgZeroY} stroke="#64748B" strokeWidth={2} />
        <text x={svgPadX} y={svgPadT + 10} fontSize={9} fill="#94A3B8">{formatVND(maxPos)}</text>
        <text x={svgPadX} y={svgH - 4} fontSize={9} fill="#94A3B8">{`-${formatVND(maxNeg)}`}</text>
        {lineSeries.filter((s) => s.period === period && !hiddenLines.has(s.key)).map((s) => (
          <path key={s.key} d={linePath(s.values)} fill="none" stroke={s.color} strokeWidth={s.dash ? 2 : 2.5} strokeDasharray={s.dash ? '6 4' : undefined} strokeLinejoin="round" strokeLinecap="round" />
        ))}
        {chartData.map((d, idx) => (
          <rect key={`h${period}${d.key}`} x={Math.max(svgPadX, svgX(idx) - svgStep / 2)} y={svgPadT} width={svgStep || svgW - 2 * svgPadX} height={svgPlotH} fill="transparent" pointerEvents="all" style={{ cursor: 'pointer' }} onClick={() => setSelectedIdx(idx)} />
        ))}
        {sel && selectedIdx !== null && (
          <line x1={svgX(selectedIdx)} y1={svgPadT} x2={svgX(selectedIdx)} y2={svgH - svgPadB} stroke="#64748B" strokeWidth={1} strokeDasharray="3 3" />
        )}
        {chartData.map((d, idx) => showXLabel(d, idx) && (
          <text key={`x${period}${d.key}`} x={svgX(idx)} y={svgH - 6} fontSize={10} fill="#64748B" textAnchor="middle">{xLabelText(d)}</text>
        ))}
      </svg>
    </div>
  );
  const topProducts = useMemo(() => {
    const arr = [...(report?.top_products ?? [])];
    arr.sort((a, b) => {
      const d = a[topSort] - b[topSort];
      return topDir === 'desc' ? -d : d;
    });
    return arr.slice(0, 5);
  }, [report, topSort, topDir]);

  if (!can('reports')) {
    return (
      <div className="page">
        <div className="card">🔒 Chỉ Quản lý trở lên mới được xem báo cáo.</div>
      </div>
    );
  }

  return (
    <div className="page ov-page">
      {/* Header xanh theo mẫu */}
      <div className="ov-header">
        <div className="ov-header-top">
          <h1 className="ov-title">Tổng quan</h1>
          <div className="ov-header-actions">
            <select
              className="ov-preset"
              value={preset}
              onChange={(e) => pickPreset(e.target.value as PresetKey)}
              aria-label="Chọn kỳ báo cáo"
            >
              {PRESETS.map((p) => (
                <option key={p.key} value={p.key}>{p.label}</option>
              ))}
            </select>
            <button className="ov-icon-btn" onClick={() => setDayCloseOpen(true)} aria-label="Chốt két">
              <TIcon emoji="💰" size={20} />
            </button>
          </div>
        </div>
      </div>

      {/* 4 thẻ KPI */}
      <div className="ov-kpis">
        {kpis.map((k) => (
          <div className="ov-kpi" key={k.label}>
            <div className="ov-kpi-top">
              <span className="ov-kpi-icon"><TIcon emoji={k.icon} size={20} /></span>
              <span className="ov-kpi-label">{k.label}</span>
            </div>
            <div className="ov-kpi-value">{busy && !report ? '…' : k.value}</div>
            {k.change !== null && k.change !== undefined && (
              <div className={`ov-kpi-change ${k.change >= 0 ? 'up' : 'down'}`}>
                {k.change >= 0 ? '↑' : '↓'} {Math.abs(Math.round(k.change))}% {k.changeLabel}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Biểu đồ so sánh theo kỳ đã chọn */}
      <div className="ov-card">
        <div className="ov-card-head">
          <h3>{chartMeta.cur} so với {chartMeta.prev}</h3>
        </div>
        <div style={{ padding: '0 20px', display: 'flex', flexDirection: 'column', gap: 8 }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 2, fontSize: 13 }}>
            <div>Doanh thu: {chartMeta.cur}: <b>{formatVND(chartTotals.revCur)}</b> · {cap(chartMeta.prev)}: <b>{formatVND(chartTotals.revPrev)}</b></div>
            <div>Lợi nhuận: {chartMeta.cur}: <b>{formatVND(chartTotals.profCur)}</b> · {cap(chartMeta.prev)}: <b>{formatVND(chartTotals.profPrev)}</b></div>
            <div>Chi phí: {chartMeta.cur}: <b>{formatVND(chartTotals.expCur)}</b> · {cap(chartMeta.prev)}: <b>{formatVND(chartTotals.expPrev)}</b></div>
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px 8px' }}>
            {LINES.map((ln) => {
              const hidden = hiddenLines.has(ln.key);
              return (
                <button key={ln.key} onClick={() => toggleLine(ln.key)} style={{ display: 'flex', alignItems: 'center', gap: 5, background: 'none', border: '1px solid #E2E8F0', borderRadius: 999, padding: '4px 8px', fontSize: 12, cursor: 'pointer', opacity: hidden ? 0.45 : 1, textDecoration: hidden ? 'line-through' : 'none' }}>
                  <span style={{ width: 14, height: 0, borderTop: `3px ${ln.dash ? 'dashed' : 'solid'} ${ln.color}` }} />
                  {ln.label} {ln.period === 'cur' ? chartMeta.cur : cap(chartMeta.prev)}
                </button>
              );
            })}
            {hiddenLines.size > 0 && (
              <button onClick={() => setHiddenLines(new Set())} style={{ background: 'none', border: 'none', color: '#00B14F', fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>Hiện tất cả</button>
            )}
          </div>
        </div>                <div style={{ padding: '0 12px 4px' }}>
          {chartSvg('cur')}
          {chartSvg('prev')}
          {sel ? (
            <div style={{ fontSize: 13, display: 'flex', flexDirection: 'column', gap: 2, padding: '6px 8px', background: '#F8FAFC', borderRadius: 8 }}>
              <div><b>{sel.detail}</b></div>
              <div>Doanh thu: {chartMeta.cur} {formatVND(sel.thisRevenue)} · {cap(chartMeta.prev)} {formatVND(sel.lastRevenue)}</div>
              <div>Lợi nhuận: {chartMeta.cur} {formatVND(sel.thisProfit)} · {cap(chartMeta.prev)} {formatVND(sel.lastProfit)}</div>
              <div>Chi phí: {chartMeta.cur} {formatVND(sel.thisExpense)} · {cap(chartMeta.prev)} {formatVND(sel.lastExpense)}</div>
            </div>
          ) : (
            <div style={{ fontSize: 12, color: '#64748B', padding: '6px 8px' }}>Chạm vào 1 trong 2 biểu đồ để xem đủ 6 số tại 1 mốc.</div>
          )}
        </div>
      </div>

      {/* Món bán chạy */}
      <div className="ov-card">
        <div className="ov-card-head">
          <h3>Món bán chạy</h3>
        </div>
        <div className="ov-filter-row">
          <select
            className="ov-filter-select"
            value={topSort}
            onChange={(e) => setTopSort(e.target.value as 'qty' | 'revenue' | 'profit')}
            aria-label="Sắp xếp theo"
          >
            <option value="qty">Số lượng</option>
            <option value="revenue">Doanh thu</option>
            <option value="profit">Lợi nhuận gộp</option>
          </select>
          <button
            className="ov-filter-dir"
            onClick={() => setTopDir((d) => (d === 'desc' ? 'asc' : 'desc'))}
            aria-label="Đổi thứ tự"
          >
            {topDir === 'desc' ? '↓ Giảm dần' : '↑ Tăng dần'}
          </button>
        </div>
        {topProducts.length === 0 ? (
          <p className="muted small">Chưa có dữ liệu</p>
        ) : (
          topProducts.map((p, i) => (
            <div className="ov-row" key={p.product_id}>
              <span className="ov-rank">{i + 1}</span>
              <div className="ov-row-body">
                <span className="ov-row-title">{p.name}</span>
                <span className="ov-row-sub">{p.qty} món · lãi gộp {formatVND(p.profit)}</span>
              </div>
              <span className="ov-row-amount">{formatVND(p.revenue)}</span>
            </div>
          ))
        )}
      </div>

      {/* Thao tác nhanh */}
      <div className="ov-card">
        <div className="ov-card-head"><h3>Thao tác nhanh</h3></div>
        <div className="ov-actions">
          <button onClick={() => navigate('/menu')}><TIcon emoji="📋" size={20} /><span>Menu</span></button>
          <button onClick={() => navigate('/customers')}><TIcon emoji="👥" size={20} /><span>Khách hàng</span></button>
          <button onClick={() => navigate('/inventory')}><TIcon emoji="🗃️" size={20} /><span>Tồn kho</span></button>
          <button onClick={() => navigate('/so-quy')}><TIcon emoji="💰" size={20} /><span>Sổ quỹ</span></button>
        </div>
      </div>

      {/* Cảnh báo tồn kho — chuyển xuống cuối trang (Hoàng yêu cầu v5.14) */}
      <LowStockPanel low={low} multiWarehouse={warehouses.length > 1} variant="mobile" />

      {dayCloseOpen && <DayCloseSheet onClose={() => setDayCloseOpen(false)} />}
    </div>
  );
}
